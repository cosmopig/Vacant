def solve(): pass
print('different')