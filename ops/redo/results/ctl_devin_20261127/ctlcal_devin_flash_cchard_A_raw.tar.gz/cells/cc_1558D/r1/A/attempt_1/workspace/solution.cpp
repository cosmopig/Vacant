#include <bits/stdc++.h>
using namespace std;

static const int MOD = 998244353;
static const int MAXF = 400005;

vector<int> fact, invfact;

int modpow(int a, int e) {
    long long r = 1, b = a;
    while (e) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return (int)r;
}

int C(int n, int k) {
    if (k < 0 || k > n || n < 0) return 0;
    return (int)((long long)fact[n] * invfact[k] % MOD * invfact[n - k] % MOD);
}

static uint64_t rng_state = 0x9e3779b97f4a7c15ULL;
uint32_t rnd() {
    uint64_t z = (rng_state += 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    z = z ^ (z >> 31);
    return (uint32_t)(z >> 32);
}

struct Node {
    int lo, hi, len, sz, prio;
    Node *lc, *rc;
    Node(int l, int h) {
        lo = l; hi = h; len = h - l + 1; sz = len;
        prio = (int)rnd(); lc = rc = nullptr;
    }
};

inline int sz(Node* t) { return t ? t->sz : 0; }
void upd(Node* t) { t->sz = t->len + sz(t->lc) + sz(t->rc); }

Node* merge(Node* a, Node* b) {
    if (!a) return b;
    if (!b) return a;
    if (a->prio < b->prio) {
        a->rc = merge(a->rc, b);
        upd(a);
        return a;
    } else {
        b->lc = merge(a, b->lc);
        upd(b);
        return b;
    }
}

// Returns first `k` elements as one treap, rest as another. k is element count.
pair<Node*, Node*> split(Node* t, int k) {
    if (!t) return {nullptr, nullptr};
    if (k <= 0) return {nullptr, t};
    if (k >= t->sz) return {t, nullptr};

    int ls = sz(t->lc);
    if (k < ls) {
        auto pr = split(t->lc, k);
        t->lc = pr.second;
        upd(t);
        return {pr.first, t};
    }

    int rem = k - ls;
    if (rem == 0) {
        Node* L = t->lc;
        t->lc = nullptr;
        upd(t);
        return {L, t};
    }

    if (rem <= t->len) {
        if (rem == t->len) {
            Node* lc = t->lc, *rc = t->rc;
            t->lc = t->rc = nullptr;
            upd(t);
            Node* left = merge(lc, t);
            return {left, rc};
        }
        int cut = rem;
        Node* nl = new Node(t->lo, t->lo + cut - 1);
        Node* nr = new Node(t->lo + cut, t->hi);
        Node* L = merge(t->lc, nl);
        Node* R = merge(nr, t->rc);
        t->lc = t->rc = nullptr;
        upd(t);
        return {L, R};
    }

    int rk = rem - t->len;
    auto pr = split(t->rc, rk);
    Node* lc = t->lc;
    t->lc = t->rc = nullptr;
    upd(t);
    Node* leftBase = merge(lc, t);
    Node* L = merge(leftBase, pr.first);
    return {L, pr.second};
}

int first_val(Node* t) {
    while (t->lc) t = t->lc;
    return t->lo;
}
int last_val(Node* t) {
    while (t->rc) t = t->rc;
    return t->hi;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    fact.resize(MAXF);
    invfact.resize(MAXF);
    fact[0] = 1;
    for (int i = 1; i < MAXF; i++) fact[i] = (int)((long long)fact[i-1] * i % MOD);
    invfact[MAXF-1] = modpow(fact[MAXF-1], MOD-2);
    for (int i = MAXF-1; i > 0; i--) invfact[i-1] = (int)((long long)invfact[i] * i % MOD);

    int t;
    if (!(cin >> t)) return 0;
    while (t--) {
        int n, m;
        cin >> n >> m;
        vector<pair<int,int>> ins(m);
        for (auto &p : ins) cin >> p.first >> p.second;

        Node* root = nullptr;
        long long d = 0;
        int prev_x = 0;
        for (auto [x, y] : ins) {
            int glo = prev_x + 1, ghi = x - 1;
            if (glo <= ghi) {
                Node* g = new Node(glo, ghi);
                root = merge(root, g);
            }
            auto pr = split(root, y - 1);
            Node* Lp = pr.first, *Rp = pr.second;
            int B = first_val(Rp);
            if (!(y > 1 && last_val(Lp) > B)) d++;
            Node* nx = new Node(x, x);
            root = merge(merge(Lp, nx), Rp);
            prev_x = x;
        }

        int N = 2 * n - (int)d - 1;
        int ans = C(N, n);
        cout << ans << '\n';
    }
    return 0;
}
