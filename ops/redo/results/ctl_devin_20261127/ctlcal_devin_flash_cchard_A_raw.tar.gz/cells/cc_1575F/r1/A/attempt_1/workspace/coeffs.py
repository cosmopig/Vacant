from fractions import Fraction
import partsolve

def coeffs(n,k):
    sol=partsolve.solve_part(n,k)
    eqs=[]; rhs=[]
    for p in partsolve.partitions(n):
        if len(p)==1 and p[0]==n: continue
        if len(p)>k: continue
        key=tuple(list(p)+[0]*(k-len(p)))
        row=[Fraction(1)]+[Fraction(0)]*(n-1)  # A, psi1..psi_{n-1}
        for part in p:
            row[part]+=1
        eqs.append(row); rhs.append(sol[key])
    # unknowns A,psi2..psi_{n-1} after setting psi1=0 (columns: A index0, psi_m index m for m>=2)
    # Build reduced system columns [A] + [psi_m for m=2..n-1]
    cols=[0]+list(range(2,n))
    M=[]
    for row,rh in zip(eqs,rhs):
        M.append([row[c] for c in cols]+[rh])
    m=len(M); N=len(cols)
    # gaussian elim solve N unknowns using all equations, check consistency
    r=0; piv=[]
    for c in range(N):
        p=None
        for i in range(r,m):
            if M[i][c]!=0:
                p=i;break
        if p is None: continue
        M[r],M[p]=M[p],M[r]
        pv=M[r][c]
        for i in range(r+1,m):
            if M[i][c]!=0:
                f=M[i][c]/pv
                for cc in range(c,N+1):
                    M[i][cc]-=f*M[r][cc]
        piv.append(c); r+=1
        if r==m: break
    for i in range(m):
        if all(M[i][c]==0 for c in range(N)) and M[i][N]!=0:
            raise Exception('inconsistent')
    if r<N:
        raise Exception(f'rank {r} < {N}')
    x=[Fraction(0)]*N
    for i in range(N-1,-1,-1):
        val=M[i][N]
        for j in range(i+1,N):
            val-=M[i][j]*x[j]
        x[i]=val/M[i][i]
    A=x[0]
    psi={1:Fraction(0)}
    for idx,c in enumerate(cols[1:], start=1):
        psi[c]=x[idx]
    return A,psi

for n in [5,6,7]:
  for k in range(n, n+4):
    A,psi=coeffs(n,k)
    print('n,k',n,k,'A',A,float(A))
    print('psi', {m:(str(v),float(v)) for m,v in sorted(psi.items())})
  print()
