from fractions import Fraction
import partsolve, math

def solve_F(n,k):
    sol=partsolve.solve_part(n,k)
    eqs=[]; rhs=[]
    for p in partsolve.partitions(n):
        if len(p)==1 and p[0]==n: continue
        if len(p)>k: continue
        key=tuple(list(p)+[0]*(k-len(p)))
        row=[Fraction(0)]*(n-1)
        for part in p:
            row[part-1]+=1
        eqs.append(row); rhs.append(sol[key])
    m=len(eqs); N=n-1
    M=[row[:]+[rhs[i]] for i,row in enumerate(eqs)]
    r=0
    for c in range(N):
        p=None
        for i in range(r,m):
            if M[i][c]!=0:
                p=i;break
        if p is None: continue
        M[r],M[p]=M[p],M[r]
        pv=M[r][c]
        for i in range(r+1,m):
            if M[i][c]!=0:
                f=M[i][c]/pv
                for cc in range(c,N+1):
                    M[i][cc]-=f*M[r][cc]
        r+=1
        if r==m: break
    for i in range(m):
        if all(M[i][c]==0 for c in range(N)) and M[i][N]!=0:
            raise Exception('inconsistent')
    if r<N:
        raise Exception(f'rank {r}<{N} eqs {m}')
    F=[Fraction(0)]*(n+1)
    for i in range(N-1,-1,-1):
        val=M[i][N]
        for j in range(i+1,N):
            val-=M[i][j]*F[j+1]
        F[i+1]=val/M[i][i]
    return F

n,k,c=10,9,2
F=solve_F(n,k)
print('F', [str(x) for x in F])
# counts t distribution
tcounts={0:5,1:1,2:2,3:1}
def binom_pmf(c,K,x):
    return Fraction(math.comb(c,x)*math.comb(K-x,c-x) if False else 0)
# X~Bin(c,1/k): P(X=x)=C(c,x)(1/k)^x((k-1)/k)^(c-x)
def E_F(t):
    s=Fraction(0)
    for x in range(c+1):
        p=Fraction(math.comb(c,x), k**x) * Fraction(k-1,k)**(c-x)
        s+=p*F[t+x]
    return s
H=Fraction(0)
for t,cnt in tcounts.items():
    H += cnt*E_F(t)
print('H',H,float(H))
ans=Fraction(k,k-1)*H
print('ans',ans,float(ans))
MOD=10**9+7
print('mod', int(ans.numerator*pow(ans.denominator%MOD,-1,MOD))%MOD)
