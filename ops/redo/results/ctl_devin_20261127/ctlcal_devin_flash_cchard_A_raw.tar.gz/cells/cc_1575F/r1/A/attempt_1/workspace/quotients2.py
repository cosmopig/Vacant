from fractions import Fraction
coeffs={
6:{
1:[Fraction(-1,2),Fraction(1,6),Fraction(1,12),Fraction(1,20),Fraction(1,30),Fraction(1,6)],
2:[Fraction(-4,5),Fraction(2,15),Fraction(1,6),Fraction(1,10),Fraction(1,15),Fraction(1,3)],
3:[Fraction(-9,10),Fraction(0),Fraction(3,20),Fraction(3,20),Fraction(1,10),Fraction(1,2)],
4:[Fraction(-4,5),Fraction(-2,15),Fraction(1,30),Fraction(1,10),Fraction(2,15),Fraction(2,3)],
5:[Fraction(-1,2),Fraction(-1,6),Fraction(-1,12),Fraction(-1,20),Fraction(-1,30),Fraction(5,6)],
},
5:{
1:[Fraction(-1,2),Fraction(1,6),Fraction(1,12),Fraction(1,20),Fraction(1,5)],
2:[Fraction(-3,4),Fraction(1,12),Fraction(1,6),Fraction(1,10),Fraction(2,5)],
3:[Fraction(-3,4),Fraction(-1,12),Fraction(1,12),Fraction(3,20),Fraction(3,5)],
4:[Fraction(-1,2),Fraction(-1,6),Fraction(-1,12),Fraction(-1,20),Fraction(4,5)],
},
4:{
1:[Fraction(-1,2),Fraction(1,6),Fraction(1,12),Fraction(1,4)],
2:[Fraction(-2,3),Fraction(0),Fraction(1,6),Fraction(1,2)],
3:[Fraction(-1,2),Fraction(-1,6),Fraction(-1,12),Fraction(3,4)],
}}

def div_kminus1(p):
    # p ascending length n degree n-1, P(1)=0
    q=[-p[0]]
    for i in range(1,len(p)-1):
        q.append(q[-1]-p[i])
    return q
for n in [4,5,6]:
    print('n',n)
    for m in range(1,n):
        print('m',m,[str(x) for x in div_kminus1(coeffs[n][m])])
    print()
