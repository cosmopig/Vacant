from fractions import Fraction
import partsolve, solveF

def poly_coeffs(vals):
    # vals[i]=F(k0+i), degree len(vals)-1; return coeffs c_j for k^j
    n=len(vals); k0=n # not used; caller passes xs
    return vals

def coeffs_in_k(n, ks):
    # returns for each m 1..n-1 list coeffs c_j (j=0..n-1) s.t. F_m(k)=sum c_j k^j
    Fs=[]
    for k in ks:
        F=solveF.solve_F(n,k)
        Fs.append(F)
    # build Vandermonde for xs=ks, degree n-1 (n coeffs)
    N=n
    # solve for each m
    out={}
    # Precompute inverse of Vandermonde V[i][j]=ks[i]^j
    V=[[Fraction(k)**j for j in range(N)] for k in ks]
    # invert V once via Gauss-Jordan
    aug=[V[i][:]+[Fraction(1 if i==j else 0) for j in range(N)] for i in range(N)]
    for c in range(N):
        p=next(r for r in range(c,N) if aug[r][c]!=0)
        aug[c],aug[p]=aug[p],aug[c]
        pv=aug[c][c]
        aug[c]=[x/pv for x in aug[c]]
        for r in range(N):
            if r!=c and aug[r][c]!=0:
                f=aug[r][c]
                aug[r]=[aug[r][i]-f*aug[c][i] for i in range(2*N)]
    Vinv=[row[N:] for row in aug]
    for m in range(1,n):
        y=[Fs[i][m] for i in range(N)]
        coeff=[sum(Vinv[j][i]*y[i] for i in range(N)) for j in range(N)]
        out[m]=coeff
    return out

for n in [4,5,6]:
    ks=list(range(n,2*n))
    out=coeffs_in_k(n,ks)
    print('n',n,'ks',ks)
    for m in range(1,n):
        print('m',m,[str(x) for x in out[m]])
    print()
