from fractions import Fraction
# hardcode power coeffs from previous output for n=5,6 to convert to binomial basis
# coeffs[j] = coefficient of k^j, j=0..n-1
power={
6:{
1:[Fraction(-1,2),Fraction(1,6),Fraction(1,12),Fraction(1,20),Fraction(1,30),Fraction(1,6)],
2:[Fraction(-4,5),Fraction(2,15),Fraction(1,6),Fraction(1,10),Fraction(1,15),Fraction(1,3)],
3:[Fraction(-9,10),Fraction(0),Fraction(3,20),Fraction(3,20),Fraction(1,10),Fraction(1,2)],
4:[Fraction(-4,5),Fraction(-2,15),Fraction(1,30),Fraction(1,10),Fraction(2,15),Fraction(2,3)],
5:[Fraction(-1,2),Fraction(-1,6),Fraction(-1,12),Fraction(-1,20),Fraction(-1,30),Fraction(5,6)],
},
5:{
1:[Fraction(-1,2),Fraction(1,6),Fraction(1,12),Fraction(1,20),Fraction(1,5)],
2:[Fraction(-3,4),Fraction(1,12),Fraction(1,6),Fraction(1,10),Fraction(2,5)],
3:[Fraction(-3,4),Fraction(-1,12),Fraction(1,12),Fraction(3,20),Fraction(3,5)],
4:[Fraction(-1,2),Fraction(-1,6),Fraction(-1,12),Fraction(-1,20),Fraction(4,5)],
},
4:{
1:[Fraction(-1,2),Fraction(1,6),Fraction(1,12),Fraction(1,4)],
2:[Fraction(-2,3),Fraction(0),Fraction(1,6),Fraction(1,2)],
3:[Fraction(-1,2),Fraction(-1,6),Fraction(-1,12),Fraction(3,4)],
}}

def evalp(coeffs,k):
    return sum(c*(k**j) for j,c in enumerate(coeffs))

def binom_basis(coeffs):
    d=len(coeffs)-1
    P=[evalp(coeffs,k) for k in range(d+1)]
    # Newton forward: b_r = sum_{i=0}^r (-1)^{r-i} C(r,i) P(i)
    from math import comb
    b=[]
    for r in range(d+1):
        s=Fraction(0)
        for i in range(r+1):
            s+=Fraction((-1)**(r-i)*comb(r,i))*P[i]
        b.append(s)
    return b,P
for n in [4,5,6]:
    print('n',n)
    for m in range(1,n):
        b,P=binom_basis(power[n][m])
        print('m',m,'P0..',P)
        print(' b', [str(x) for x in b])
    print()
