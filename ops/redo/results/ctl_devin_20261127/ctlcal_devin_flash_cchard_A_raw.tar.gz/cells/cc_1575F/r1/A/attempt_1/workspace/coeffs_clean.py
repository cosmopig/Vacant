from fractions import Fraction
import partsolve, math

def solve_F(n,k):
    sol=partsolve.solve_part(n,k)
    eqs=[]; rhs=[]
    for p in partsolve.partitions(n):
        if len(p)==1 and p[0]==n: continue
        if len(p)>k: continue
        key=tuple(list(p)+[0]*(k-len(p)))
        row=[Fraction(0)]*(n-1)
        for part in p:
            row[part-1]+=1
        eqs.append(row); rhs.append(sol[key])
    m=len(eqs); N=n-1
    M=[row[:]+[rhs[i]] for i,row in enumerate(eqs)]
    r=0
    for c in range(N):
        p=None
        for i in range(r,m):
            if M[i][c]!=0:
                p=i;break
        if p is None: continue
        M[r],M[p]=M[p],M[r]
        pv=M[r][c]
        for i in range(r+1,m):
            if M[i][c]!=0:
                f=M[i][c]/pv
                for cc in range(c,N+1):
                    M[i][cc]-=f*M[r][cc]
        r+=1
        if r==m: break
    for i in range(m):
        if all(M[i][c]==0 for c in range(N)) and M[i][N]!=0:
            raise Exception('inconsistent')
    if r<N:
        raise Exception(f'rank {r}<{N} eqs {m}')
    F=[Fraction(0)]*(n+1)
    for i in range(N-1,-1,-1):
        val=M[i][N]
        for j in range(i+1,N):
            val-=M[i][j]*F[j+1]
        F[i+1]=val/M[i][i]
    return F

def power_coeffs(n,ks):
    # returns dict m->coeffs ascending length n (degree n-1)
    Fs=[]
    for k in ks:
        Fs.append(solve_F(n,k))
    N=n
    V=[[Fraction(k)**j for j in range(N)] for k in ks]
    # invert Vandermonde
    aug=[V[i][:]+[Fraction(1 if i==j else 0) for j in range(N)] for i in range(N)]
    for c in range(N):
        p=next(r for r in range(c,N) if aug[r][c]!=0)
        aug[c],aug[p]=aug[p],aug[c]
        pv=aug[c][c]
        aug[c]=[x/pv for x in aug[c]]
        for r in range(N):
            if r!=c and aug[r][c]!=0:
                f=aug[r][c]
                aug[r]=[aug[r][i]-f*aug[c][i] for i in range(2*N)]
    Vinv=[row[N:] for row in aug]
    out={}
    for m in range(1,n):
        y=[Fs[i][m] for i in range(N)]
        out[m]=[sum(Vinv[j][i]*y[i] for i in range(N)) for j in range(N)]
    return out

def div_kminus1(p):
    q=[-p[0]]
    for i in range(1,len(p)-1):
        q.append(q[-1]-p[i])
    return q

if __name__=='__main__':
    import sys
    n=int(sys.argv[1]) if len(sys.argv)>1 else 7
    ks=list(range(n,2*n))
    pc=power_coeffs(n,ks)
    print('n',n,'ks',ks)
    for m in range(1,n):
        q=div_kminus1(pc[m])
        print('m',m,[str(x) for x in q])
