from fractions import Fraction

def partitions_at_most(n,k):
    def rec(rem,maxv,cur):
        if rem==0:
            yield tuple(cur)
            return
        for v in range(min(maxv,rem),0,-1):
            yield from rec(rem-v,v,cur+[v])
    for p in rec(n,n,[]):
        if len(p)<=k:
            yield tuple(list(p)+[0]*(k-len(p)))

def solve_part(n,k):
    states=[s for s in partitions_at_most(n,k) if s[0]<n]
    idx={s:i for i,s in enumerate(states)}
    N=len(states)
    A=[[Fraction(0) for _ in range(N)] for __ in range(N)]
    b=[Fraction(1) for _ in range(N)]
    for s in states:
        i=idx[s]
        A[i][i]=Fraction(1)
        for c in range(k):
            mc=s[c]
            if mc==0: continue
            for d in range(k):
                if d==c: continue
                ns=list(s); ns[c]-=1; ns[d]+=1; ns=tuple(sorted(ns,reverse=True))
                if ns[0]==n:
                    continue
                A[i][idx[ns]] -= Fraction(mc,n*(k-1))
    for col in range(N):
        piv=next(r for r in range(col,N) if A[r][col]!=0)
        A[col],A[piv]=A[piv],A[col]
        pv=A[col][col]
        for r in range(col+1,N):
            if A[r][col]!=0:
                f=A[r][col]/pv
                for cc in range(col,N):
                    A[r][cc]-=f*A[col][cc]
                b[r]-=f*b[col]
    g=[Fraction(0) for _ in range(N)]
    for i in range(N-1,-1,-1):
        val=b[i]
        for j in range(i+1,N):
            val-=A[i][j]*g[j]
        g[i]=val/A[i][i]
    return {s:g[i] for i,s in enumerate(states)}

def partitions(n):
    def rec(rem,maxv,cur):
        if rem==0:
            yield tuple(cur); return
        for v in range(min(maxv,rem),0,-1):
            yield from rec(rem-v,v,cur+[v])
    yield from rec(n,n,[])

def test_additive(n,k):
    sol=solve_part(n,k)
    eqs=[]; rhs=[]
    for p in partitions(n):
        if len(p)==1 and p[0]==n:
            continue
        key=tuple(list(p)+[0]*(k-len(p)))
        H=sol[key]
        row=[Fraction(1)] + [Fraction(0)]*(n-1)
        for part in p:
            row[part]+=1
        eqs.append(row); rhs.append(H)
    m=len(eqs); N=n
    M=[row[:]+[rhs[i]] for i,row in enumerate(eqs)]
    r=0
    for c in range(N):
        piv=None
        for rr in range(r,m):
            if M[rr][c]!=0:
                piv=rr;break
        if piv is None: continue
        M[r],M[piv]=M[piv],M[r]
        pv=M[r][c]
        for rr in range(r+1,m):
            if M[rr][c]!=0:
                f=M[rr][c]/pv
                for cc in range(c,N+1):
                    M[rr][cc]-=f*M[r][cc]
        r+=1
        if r==m: break
    consistent=True
    for i in range(m):
        if all(M[i][c]==0 for c in range(N)) and M[i][N]!=0:
            consistent=False; print('inconsistent rhs',M[i][N]); break
    print('n,k',n,k,'eqs',m,'rank',r,'unknowns',N,'consistent',consistent)

if __name__=='__main__':
    for n in range(3,11):
        test_additive(n,n)
