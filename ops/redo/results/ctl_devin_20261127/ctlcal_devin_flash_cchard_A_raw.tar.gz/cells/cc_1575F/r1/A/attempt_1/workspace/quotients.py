from fractions import Fraction
# reuse power coeffs by recomputing via fcoeffs? import triggers solveF noise; instead copy function quickly using saved? 
# We'll just parse by importing fcoeffs (it prints but ok) - no, do our own minimal using partsolve? Too slow.
# Use the printed coefficients manually for n=5,6 from fcoeffs output.
coeffs={
6:{
1:[Fraction(-1,2),Fraction(1,6),Fraction(1,12),Fraction(1,20),Fraction(1,30),Fraction(1,6)],
2:[Fraction(-4,5),Fraction(2,15),Fraction(1,6),Fraction(1,10),Fraction(1,15),Fraction(1,3)],
3:[Fraction(-9,10),Fraction(0),Fraction(3,20),Fraction(3,20),Fraction(1,10),Fraction(1,2)],
4:[Fraction(-4,5),Fraction(-2,15),Fraction(1,30),Fraction(1,10),Fraction(2,15),Fraction(2,3)],
5:[Fraction(-1,2),Fraction(-1,6),Fraction(-1,12),Fraction(-1,20),Fraction(-1,30),Fraction(5,6)],
},
5:{
1:[Fraction(-1,2),Fraction(1,6),Fraction(1,12),Fraction(1,20),Fraction(1,5)],
2:[Fraction(-3,4),Fraction(1,12),Fraction(1,6),Fraction(1,10),Fraction(2,5)],
3:[Fraction(-3,4),Fraction(-1,12),Fraction(1,12),Fraction(3,20),Fraction(3,5)],
4:[Fraction(-1,2),Fraction(-1,6),Fraction(-1,12),Fraction(-1,20),Fraction(4,5)],
},
4:{
1:[Fraction(-1,2),Fraction(1,6),Fraction(1,12),Fraction(1,4)],
2:[Fraction(-2,3),Fraction(0),Fraction(1,6),Fraction(1,2)],
3:[Fraction(-1,2),Fraction(-1,6),Fraction(-1,12),Fraction(3,4)],
}}

def div_kminus1(p):
    # p ascending coeffs length n, returns quotient ascending length n-1 for (k-1)
    n=len(p)
    # synthetic division by root 1 on descending
    desc=p[::-1]
    q=[]; rem=Fraction(0)
    carry=desc[0]
    q.append(carry)
    for i in range(1,n-1):
        carry=desc[i]+carry*1
        q.append(carry)
    # last should rem 0
    return q[::-1]  # ascending? q currently descending coeffs for quotient degrees n-2..0

def show(n):
    print('n',n)
    for m in range(1,n):
        q=div_kminus1(coeffs[n][m])
        # q is descending (degree n-2 ..0); convert ascending
        asc=q[::-1]
        print('m',m,'quot asc',[str(x) for x in asc])
    print()
for n in [4,5,6]: show(n)
