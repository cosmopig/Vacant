from fractions import Fraction
import partsolve

def solve_F(n,k):
    sol=partsolve.solve_part(n,k)
    eqs=[]; rhs=[]
    for p in partsolve.partitions(n):
        if len(p)==1 and p[0]==n: continue
        if len(p)>k: continue
        key=tuple(list(p)+[0]*(k-len(p)))
        row=[Fraction(0)]*(n-1)  # F1..F_{n-1}; parts are < n for non-singleton
        for part in p:
            row[part-1]+=1
        eqs.append(row); rhs.append(sol[key])
    m=len(eqs); N=n-1
    M=[row[:]+[rhs[i]] for i,row in enumerate(eqs)]
    r=0
    for c in range(N):
        p=None
        for i in range(r,m):
            if M[i][c]!=0:
                p=i;break
        if p is None: continue
        M[r],M[p]=M[p],M[r]
        pv=M[r][c]
        for i in range(r+1,m):
            if M[i][c]!=0:
                f=M[i][c]/pv
                for cc in range(c,N+1):
                    M[i][cc]-=f*M[r][cc]
        r+=1
        if r==m: break
    for i in range(m):
        if all(M[i][c]==0 for c in range(N)) and M[i][N]!=0:
            raise Exception('inconsistent')
    if r<N:
        raise Exception(f'rank {r} < {N}, need more k?')
    F=[Fraction(0)]*(n+1)
    for i in range(N-1,-1,-1):
        val=M[i][N]
        for j in range(i+1,N):
            val-=M[i][j]*F[j+1]  # F index = column+1? careful
        # columns correspond F1..F_{n-1}; solution x_i = F_{i+1}
        F[i+1]=val/M[i][i]
    return F

for n in range(3,9):
    for k in range(n, n+3):
        try:
            F=solve_F(n,k)
            print('n,k',n,k)
            print([str(F[i]) for i in range(n+1)])
            print([float(F[i]) for i in range(n+1)])
        except Exception as e:
            print('n,k',n,k,'ERR',e)
    print()
