#include <bits/stdc++.h>
using namespace std;

static inline int bit_length(int x) {
    return 32 - __builtin_clz((unsigned)x);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    if (!(cin >> t)) return 0;
    vector<pair<int,int>> tests(t);
    int nmax = 0;
    for (auto &p : tests) {
        cin >> p.first >> p.second;
        nmax = max(nmax, p.first);
    }
    if (nmax == 0) return 0;

    const int B = min(320, nmax);
    const int QMAX = nmax / (B + 1);

    vector<int> phi(nmax + 1);
    iota(phi.begin(), phi.end(), 0);
    for (int i = 2; i <= nmax; ++i) {
        if (phi[i] == i) {
            for (int j = i; j <= nmax; j += i) phi[j] -= phi[j] / i;
        }
    }
    vector<long long> Phi(nmax + 1, 0);
    {
        long long s = 0;
        for (int x = 1; x <= nmax; ++x) {
            if (x >= 2) s += phi[x];
            Phi[x] = s;
        }
    }

    // Proper divisors q >= 2 of every t, in CSR form, with prefix sums of phi(q).
    vector<int> cnt(nmax + 2, 0), off(nmax + 2, 0);
    for (int d = 2; d <= nmax; ++d)
        for (int x = d; x <= nmax; x += d) ++cnt[x];
    for (int i = 1; i <= nmax; ++i) off[i + 1] = off[i] + cnt[i];
    int total = off[nmax + 1];
    vector<int> dv(total), val(total);
    {
        vector<int> cur(off.begin(), off.end() - 1);
        for (int d = 2; d <= nmax; ++d)
            for (int x = d; x <= nmax; x += d) {
                int p = cur[x]++;
                dv[p] = d;
                val[p] = phi[d];
            }
        for (int x = 1; x <= nmax; ++x) {
            int acc = 0;
            for (int p = off[x]; p < off[x + 1]; ++p) {
                acc += val[p];
                val[p] = acc;
            }
        }
    }
    auto deltaDiv = [&](int x, int M) -> int {
        if (M < 2) return 0;
        int lo = off[x], hi = off[x + 1];
        auto it = upper_bound(dv.begin() + lo, dv.begin() + hi, M);
        int idx = int(it - dv.begin());
        return idx == lo ? 0 : val[idx - 1];
    };

    const long long W = nmax + 1;
    vector<long long> small((size_t)(B + 1) * W, 0);
    auto smallAt = [&](int l, int r) -> long long {
        return small[(size_t)l * W + r];
    };
    for (int l = 2; l <= B; ++l) {
        long long prev = 0;
        long long *row = &small[(size_t)l * W];
        for (int x = l; x <= nmax; ++x) {
            if (x > l) prev += deltaDiv(x, x / l);
            row[x] = prev;
        }
    }
    for (int x = 1; x <= nmax; ++x) small[(size_t)1 * W + x] = (long long)x * (x - 1) / 2;

    vector<int> A;
    if (QMAX > 0) {
        A.assign((size_t)(nmax + 1) * (QMAX + 1), 0);
        for (int r = 1; r <= nmax; ++r) {
            int *row = &A[(size_t)r * (QMAX + 1)];
            long long acc = 0;
            for (int q = 1; q <= QMAX; ++q) {
                if (q >= 2) acc += (long long)phi[q] * (r / q);
                row[q] = (int)acc;
            }
        }
    }

    auto extraCost = [&](int l, int r) -> long long {
        if (l <= B) return smallAt(l, r);
        int q = r / l;
        if (q <= 1) return 0;
        long long a = A[(size_t)r * (QMAX + 1) + q];
        return a - (long long)(l - 1) * Phi[q];
    };
    auto segCost = [&](int l, int r) -> long long {
        return (long long)(r - l + 1) + extraCost(l, r);
    };

    const int K = 16;
    const long long INF = (long long)4e18;
    vector<vector<long long>> dp(K + 1, vector<long long>(nmax + 1, INF));
    dp[0][0] = 0;

    for (int k = 1; k <= K; ++k) {
        vector<long long> &prev = dp[k - 1];
        vector<long long> &cur = dp[k];
        // Iterative divide-and-conquer to avoid deep recursion overhead.
        struct Node { int rlo, rhi, llo, lhi; };
        vector<Node> st;
        st.push_back({k, nmax, k, nmax});
        while (!st.empty()) {
            Node nd = st.back(); st.pop_back();
            if (nd.rlo > nd.rhi) continue;
            int rmid = (nd.rlo + nd.rhi) >> 1;
            long long best = INF;
            int bl = nd.llo;
            int hi = min(nd.lhi, rmid);
            for (int l = nd.llo; l <= hi; ++l) {
                long long pv = prev[l - 1];
                if (pv >= INF) continue;
                long long v = pv + segCost(l, rmid);
                if (v < best) { best = v; bl = l; }
            }
            cur[rmid] = best;
            st.push_back({nd.rlo, rmid - 1, nd.llo, bl});
            st.push_back({rmid + 1, nd.rhi, bl, nd.lhi});
        }
    }

    for (auto [n, k] : tests) {
        int L = bit_length(n);
        if (k >= L) {
            cout << n << '\n';
        } else {
            cout << dp[k][n] << '\n';
        }
    }
    return 0;
}
