import sys
from fractions import Fraction

def solve():
    data = sys.stdin.read().split()
    n = int(data[0])
    a = list(map(int, data[1:1+n]))
    b = data[1+n].strip()
    ans = 0
    for l in range(n):
        # extend r greedily; x must stay integer at every step
        x = Fraction(1, 1)
        r = l
        while r < n:
            ai = a[r]
            if b[r] == '*':
                x = x * ai
            else:
                x = x / ai
            if x.denominator != 1:
                break
            ans += 1
            r += 1
    print(ans)

solve()
