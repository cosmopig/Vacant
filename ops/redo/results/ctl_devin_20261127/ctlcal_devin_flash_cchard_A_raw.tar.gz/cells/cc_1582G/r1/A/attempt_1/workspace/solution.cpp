#include <bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if(!(cin>>n)) return 0;
    vector<int> a(n+1);
    int maxA=1;
    for(int i=1;i<=n;i++){ cin>>a[i]; if(a[i]>maxA) maxA=a[i]; }
    string b; cin>>b;

    // linear sieve for smallest prime factor up to maxA
    vector<int> lp(maxA+1,0);
    vector<int> primes;
    primes.reserve(80000);
    for(int i=2;i<=maxA;i++){
        if(lp[i]==0){ lp[i]=i; primes.push_back(i); }
        for(int p: primes){
            long long v=(long long)i*p;
            if(v>maxA) break;
            lp[v]=p;
            if(i%p==0) break;
        }
    }
    int P=(int)primes.size();
    vector<int> pid(maxA+1,-1);
    for(int i=0;i<P;i++) pid[primes[i]]=i;

    // count events (distinct prime factors) per prime
    vector<int> cnt(P,0);
    for(int i=1;i<=n;i++){
        int x=a[i];
        while(x>1){
            int p=lp[x];
            while(x%p==0) x/=p;
            cnt[pid[p]]++;
        }
    }
    vector<long long> off(P+1,0);
    for(int i=0;i<P;i++) off[i+1]=off[i]+cnt[i];
    long long E=off[P];
    vector<int> ev_pos(E), ev_del(E);
    vector<long long> cur(P);
    for(int i=0;i<P;i++) cur[i]=off[i];
    for(int i=1;i<=n;i++){
        int x=a[i];
        int s=(b[i-1]=='*')?1:-1;
        while(x>1){
            int p=lp[x]; int e=0;
            while(x%p==0){ x/=p; e++; }
            int id=pid[p];
            ev_pos[cur[id]]=i;
            ev_del[cur[id]]=s*e;
            cur[id]++;
        }
    }

    const int INF=n+1;
    // breakpoints: (start_j, pid, value)
    vector<array<int,3>> bp;
    bp.reserve(E+P);
    vector<int> S, nxt, stk;
    for(int id=0; id<P; id++){
        long long lo=off[id], hi=off[id+1];
        int m=(int)(hi-lo);
        if(m==0) continue;
        S.resize(m); nxt.resize(m); stk.clear(); stk.reserve(m);
        long long s=0;
        for(int t=0;t<m;t++){ s+=ev_del[lo+t]; S[t]=(int)s; }
        // baseline region j < pos[0]: T_p(j)=0, need first event with S<0
        int bval=INF;
        for(int t=0;t<m;t++) if(S[t]<0){ bval=ev_pos[lo+t]; break; }
        bp.push_back({0,id,bval});
        // next smaller element to the right on S
        for(int t=m-1;t>=0;t--){
            while(!stk.empty() && S[stk.back()]>=S[t]) stk.pop_back();
            nxt[t]= stk.empty()? -1 : stk.back();
            stk.push_back(t);
        }
        for(int t=0;t<m;t++){
            int start=ev_pos[lo+t];
            if(start>n-1) continue; // region empty (j<=n-1)
            int val=(nxt[t]==-1)? INF : ev_pos[lo+nxt[t]];
            bp.push_back({start,id,val});
        }
    }

    // counting sort breakpoints by start_j in [0,n-1]
    vector<int> cntj(n,0);
    for(auto &e3: bp) cntj[e3[0]]++;
    vector<long long> boff(n+1,0);
    for(int j=0;j<n;j++) boff[j+1]=boff[j]+cntj[j];
    long long B=boff[n];
    vector<int> bpid(B), bval(B);
    vector<long long> c2(n);
    for(int j=0;j<n;j++) c2[j]=boff[j];
    for(auto &e3: bp){
        long long p=c2[e3[0]]++;
        bpid[p]=e3[1]; bval[p]=e3[2];
    }

    // sweep j=0..n-1 with lazy min-heap over primes
    priority_queue<tuple<int,int,int>, vector<tuple<int,int,int>>, greater<tuple<int,int,int>>> pq;
    vector<int> ver(P,0);
    long long ans=0;
    for(int j=0;j<n;j++){
        for(long long idx=boff[j]; idx<boff[j+1]; idx++){
            int id=bpid[idx], v=bval[idx];
            ver[id]++;
            pq.push(make_tuple(v,id,ver[id]));
        }
        while(!pq.empty() && get<2>(pq.top())!=ver[get<1>(pq.top())]) pq.pop();
        int nb = pq.empty()? INF : get<0>(pq.top());
        ans += (long long)nb - j - 1;
    }

    cout<<ans<<"\n";
    return 0;
}
