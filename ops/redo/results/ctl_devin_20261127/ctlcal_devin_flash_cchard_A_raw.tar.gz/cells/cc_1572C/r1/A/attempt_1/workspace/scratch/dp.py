import sys
sys.setrecursionlimit(100000)
from functools import lru_cache
from collections import deque

def solve_bfs(seq):
    seq=tuple(seq)
    if len(seq)<=1: return 0
    dist={seq:0}; dq=deque([seq])
    while dq:
        s=dq.popleft(); d=dist[s]; k=len(s)
        if k==1: return d
        nd=d+1
        for i in range(k):
            l=s[i-1] if i>0 else None
            r=s[i+1] if i<k-1 else None
            if l is not None and r is not None and l==r:
                ns=s[:i-1]+(l,)+s[i+2:]
            else:
                ns=s[:i]+s[i+1:]
            if ns not in dist: dist[ns]=nd; dq.append(ns)
    return None

def solve_dp(seq):
    # seq: tuple colors. g[l][r] = dict color->minops
    k=len(seq)
    if k<=1: return 0
    # dp[l][r] dict
    dp=[[None]*k for _ in range(k)]
    for i in range(k):
        dp[i][i]={seq[i]:0}
    for length in range(2,k+1):
        for l in range(0,k-length+1):
            r=l+length-1
            d={}
            # binary splits
            for m in range(l,r):
                L=dp[l][m]; R=dp[m+1][r]
                if not L or not R: continue
                for lc,lv in L.items():
                    for rc,rv in R.items():
                        if lc==rc: continue
                        c=lv+rv+1
                        for col in (lc,rc):
                            if c<d.get(col,10**9): d[col]=c
                # also lc==rc? not allowed (would be same block)
            # ternary splits
            for m1 in range(l,r-1):
                for m2 in range(m1+1,r):
                    A=dp[l][m1]; B=dp[m1+1][m2]; C=dp[m2+1][r]
                    if not A or not B or not C: continue
                    # need colors (c,x,c)
                    for ca,av in A.items():
                        for cb,bv in B.items():
                            if cb==ca: continue
                            for cc,cv in C.items():
                                if cc!=ca: continue
                                c=av+bv+cv+1
                                if c<d.get(ca,10**9): d[ca]=c
            dp[l][r]=d
    return min(dp[0][k-1].values()) if dp[0][k-1] else 10**9

import random,itertools
def rand_seq(k,P,rng):
    s=[]
    for _ in range(k):
        c=rng.randrange(P)
        if s and s[-1]==c: c=(c+1)%P
        s.append(c)
    return tuple(s)

rng=random.Random(0)
bad=0;tot=0
for k in range(2,8):
    for _ in range(200):
        s=rand_seq(k,k+2,rng)
        a=solve_bfs(s); b=solve_dp(s)
        tot+=1
        if a!=b:
            bad+=1
            print("MISMATCH",s,"bfs",a,"dp",b)
            if bad>10: sys.exit()
print("done",tot,"bad",bad)
