import sys
sys.setrecursionlimit(1000000)
from collections import deque

def solve(seq, P, relabel):
    seq=tuple(seq)
    if len(seq)<=1: return 0
    dist={seq:0}; dq=deque([seq])
    while dq:
        s=dq.popleft(); d=dist[s]; k=len(s)
        if k==1: return d
        nd=d+1
        for i in range(k):
            l=s[i-1] if i>0 else None
            r=s[i+1] if i<k-1 else None
            if l is not None and r is not None and l==r:
                ns=s[:i-1]+(l,)+s[i+2:]
            else:
                ns=s[:i]+s[i+1:]
            if ns not in dist: dist[ns]=nd; dq.append(ns)
        if relabel:
            for i in range(k):
                l=s[i-1] if i>0 else None
                r=s[i+1] if i<k-1 else None
                for c in range(P):
                    if c==s[i] or (l is not None and c==l) or (r is not None and c==r): continue
                    ns=s[:i]+(c,)+s[i+1:]
                    if ns not in dist: dist[ns]=nd; dq.append(ns)
    return None

def gen(k,P):
    if k==0:
        yield (); return
    for rest in gen(k-1,P):
        for c in range(P):
            if rest and rest[-1]==c: continue
            yield rest+(c,)

bad=0;tot=0
for k in range(2,7):
    for s in gen(k,3):
        P=k+1
        a=solve(s,P,True); b=solve(s,P,False)
        tot+=1
        if a!=b:
            bad+=1; print("DIFF",s,a,b)
print("done",tot,"bad",bad)
