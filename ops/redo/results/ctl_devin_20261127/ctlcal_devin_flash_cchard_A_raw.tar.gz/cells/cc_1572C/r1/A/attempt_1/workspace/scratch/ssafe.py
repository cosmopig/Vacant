import sys
sys.setrecursionlimit(1000000)
from collections import deque

def opt(seq):
    seq=tuple(seq)
    if len(seq)<=1: return 0
    dist={seq:0}; dq=deque([seq])
    while dq:
        s=dq.popleft(); d=dist[s]; k=len(s)
        if k==1: return d
        nd=d+1
        for i in range(k):
            l=s[i-1] if i>0 else None
            r=s[i+1] if i<k-1 else None
            if l is not None and r is not None and l==r:
                ns=s[:i-1]+(l,)+s[i+2:]
            else:
                ns=s[:i]+s[i+1:]
            if ns not in dist: dist[ns]=nd; dq.append(ns)
    return None

def gen(k,P):
    if k==0:
        yield (); return
    for rest in gen(k-1,P):
        for c in range(P):
            if rest and rest[-1]==c: continue
            yield rest+(c,)

def stable(s):
    k=len(s)
    return all(not (0<i<k-1 and s[i-1]==s[i+1]) for i in range(k))

# For stable sequences, check if all legal S moves are safe
bad=0;tot=0;ex=[]
for k in range(3,8):
    for s in gen(k,3):
        if not stable(s): continue
        o=opt(s); kk=len(s)
        for i in range(kk):
            l=s[i-1] if i>0 else None
            r=s[i+1] if i<k-1 else None
            if l is not None and r is not None and l==r: continue  # not legal S (it's F)
            ns=s[:i]+s[i+1:]
            if opt(ns)!=o-1:
                bad+=1
                if len(ex)<15: ex.append((s,i,o,opt(ns)))
        tot+=1
print("stable tot",tot,"badS",bad)
for e in ex: print(e)
