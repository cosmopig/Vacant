import sys
sys.setrecursionlimit(1000000)
from functools import lru_cache
from collections import deque

def solve(seq):
    seq=tuple(seq)
    if len(seq)<=1: return 0
    dist={seq:0}; dq=deque([seq])
    while dq:
        s=dq.popleft(); d=dist[s]; k=len(s)
        if k==1: return d
        nd=d+1
        for i in range(k):
            l=s[i-1] if i>0 else None
            r=s[i+1] if i<k-1 else None
            if l is not None and r is not None and l==r:
                ns=s[:i-1]+(l,)+s[i+2:]
            else:
                ns=s[:i]+s[i+1:]
            if ns not in dist: dist[ns]=nd; dq.append(ns)
    return None

# greedy: repeatedly apply F if any exists (choose?), else S-delete... need choice for S too.
# Instead compute max-F via DP? For now compare solve() to simple bounds.

def gen(k,P):
    # all sequences length k over P colors, no adjacent equal
    if k==0:
        yield (); return
    for rest in gen(k-1,P):
        for c in range(P):
            if rest and rest[-1]==c: continue
            yield rest+(c,)

import itertools
for k in range(2,7):
    cnt=0; hist={}
    worst=[]
    for s in gen(k,3):
        v=solve(s)
        hist[v]=hist.get(v,0)+1
        cnt+=1
    print("k",k,"count",cnt,"hist",dict(sorted(hist.items())))
