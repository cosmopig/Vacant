import sys
sys.setrecursionlimit(100000)

def dp_table(seq):
    k=len(seq)
    dp=[[None]*k for _ in range(k)]
    for i in range(k):
        dp[i][i]={seq[i]:0}
    for length in range(2,k+1):
        for l in range(0,k-length+1):
            r=l+length-1
            d={}
            for m in range(l,r):
                L=dp[l][m]; R=dp[m+1][r]
                if not L or not R: continue
                for lc,lv in L.items():
                    for rc,rv in R.items():
                        if lc==rc: continue
                        c=lv+rv+1
                        for col in (lc,rc):
                            if c<d.get(col,10**9): d[col]=c
            for m1 in range(l,r-1):
                for m2 in range(m1+1,r):
                    A=dp[l][m1]; B=dp[m1+1][m2]; C=dp[m2+1][r]
                    if not A or not B or not C: continue
                    for ca,av in A.items():
                        for cb,bv in B.items():
                            if cb==ca: continue
                            for cc,cv in C.items():
                                if cc!=ca: continue
                                c=av+bv+cv+1
                                if c<d.get(ca,10**9): d[ca]=c
            dp[l][r]=d if d else {}
    return dp

seq=(0,1,0,2,1,0,2,1)
dp=dp_table(seq)
k=len(seq)
for l in range(k):
    for r in range(l,k):
        d=dp[l][r]
        cols=sorted(d.keys()) if d else []
        print(l,r,seq[l:r+1],{c:d[c] for c in cols})
