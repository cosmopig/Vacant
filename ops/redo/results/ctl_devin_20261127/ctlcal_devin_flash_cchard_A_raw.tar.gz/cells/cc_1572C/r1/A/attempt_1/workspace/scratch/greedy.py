import sys
sys.setrecursionlimit(1000000)
from collections import deque

def solve_bfs(seq):
    seq=tuple(seq)
    if len(seq)<=1: return 0
    dist={seq:0}; dq=deque([seq])
    while dq:
        s=dq.popleft(); d=dist[s]; k=len(s)
        if k==1: return d
        nd=d+1
        for i in range(k):
            l=s[i-1] if i>0 else None
            r=s[i+1] if i<k-1 else None
            if l is not None and r is not None and l==r:
                ns=s[:i-1]+(l,)+s[i+2:]
            else:
                ns=s[:i]+s[i+1:]
            if ns not in dist: dist[ns]=nd; dq.append(ns)
    return None

def greedy(seq, fchoice='left', schoice='left'):
    s=list(seq); ops=0
    while len(s)>1:
        k=len(s)
        # find F positions
        Fs=[i for i in range(1,k-1) if s[i-1]==s[i+1]]
        if Fs:
            i = Fs[0] if fchoice=='left' else Fs[-1]
            c=s[i-1]
            s = s[:i-1]+[c]+s[i+2:]
            ops+=1; continue
        # must S-delete: candidates = endpoints or interior with unequal neighbors
        cands=[]
        for i in range(k):
            l=s[i-1] if i>0 else None
            r=s[i+1] if i<k-1 else None
            if not (l is not None and r is not None and l==r):
                cands.append(i)
        if not cands:
            return None
        i = cands[0] if schoice=='left' else cands[-1]
        s = s[:i]+s[i+1:]
        ops+=1
    return ops

def gen(k,P):
    if k==0:
        yield (); return
    for rest in gen(k-1,P):
        for c in range(P):
            if rest and rest[-1]==c: continue
            yield rest+(c,)

import itertools
for k in range(2,8):
    for P in [3]:
        bad=0;tot=0
        for s in gen(k,P):
            opt=solve_bfs(s)
            g=greedy(s)
            tot+=1
            if g!=opt:
                bad+=1
                if bad<=5: print("k",k,"seq",s,"opt",opt,"greedy",g)
        print("k",k,"P",P,"tot",tot,"bad",bad)
