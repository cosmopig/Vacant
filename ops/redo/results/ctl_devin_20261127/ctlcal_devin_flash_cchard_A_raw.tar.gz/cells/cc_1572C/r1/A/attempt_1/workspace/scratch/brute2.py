import sys
sys.setrecursionlimit(1000000)
from functools import lru_cache
from collections import deque

def solve(seq, P, relabel):
    seq=tuple(seq)
    if len(seq)<=1: return 0
    dist={seq:0}; dq=deque([seq])
    while dq:
        s=dq.popleft(); d=dist[s]; k=len(s)
        if k==1: return d
        nd=d+1
        for i in range(k):
            l=s[i-1] if i>0 else None
            r=s[i+1] if i<k-1 else None
            if l is not None and r is not None and l==r:
                ns=s[:i-1]+(l,)+s[i+2:]
            else:
                ns=s[:i]+s[i+1:]
            if ns not in dist: dist[ns]=nd; dq.append(ns)
        if relabel:
            for i in range(k):
                l=s[i-1] if i>0 else None
                r=s[i+1] if i<k-1 else None
                for c in range(P):
                    if c==s[i] or (l is not None and c==l) or (r is not None and c==r): continue
                    ns=s[:i]+(c,)+s[i+1:]
                    if ns not in dist: dist[ns]=nd; dq.append(ns)
    return None

import random,itertools
def rand_seq(k,P,rng):
    s=[]
    for _ in range(k):
        c=rng.randrange(P)
        if s and s[-1]==c: c=(c+1)%P
        s.append(c)
    return tuple(s)

rng=random.Random(0)
diff=0; tot=0
for k in range(3,8):
    for _ in range(25):
        s=rand_seq(k,k+1,rng)
        a=solve(s,k+1,True); b=solve(s,k+1,False)
        tot+=1
        if a!=b:
            diff+=1
            print("DIFF",s,"relabel",a,"norelabel",b)
print("done",tot,"diff",diff)
