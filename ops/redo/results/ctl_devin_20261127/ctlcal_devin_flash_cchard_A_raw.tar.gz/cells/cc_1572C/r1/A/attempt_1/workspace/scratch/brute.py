import sys
sys.setrecursionlimit(1000000)
from functools import lru_cache

def make_solver(allow_relabel, P):
    @lru_cache(maxsize=None)
    def f(s):
        k=len(s)
        if k<=1: return 0
        best=10**9
        for i in range(k):
            l=s[i-1] if i>0 else None
            r=s[i+1] if i<k-1 else None
            if l is not None and r is not None and l==r:
                ns=s[:i-1]+(l,)+s[i+2:]
                best=min(best,1+f(ns))
            else:
                ns=s[:i]+s[i+1:]
                best=min(best,1+f(ns))
        if allow_relabel:
            for i in range(k):
                l=s[i-1] if i>0 else None
                r=s[i+1] if i<k-1 else None
                for c in range(P):
                    if c==s[i]: continue
                    if l is not None and c==l: continue
                    if r is not None and c==r: continue
                    ns=s[:i]+(c,)+s[i+1:]
                    v=f(ns)
                    if v<10**8: best=min(best,1+v)
        return best
    return f

# To handle relabel cycles: bound relabel depth by doing DP over length with iterative deepening?
# Simpler: allow relabel only if it strictly helps; use BFS over states with cost, but dedupe by (len,...) — BFS explores finite because each state visited once with min cost; relabel edges go to same-length states but BFS by cost terminates since we stop at first k==1.
from collections import deque
def solve_bfs(seq, P):
    seq=tuple(seq)
    if len(seq)<=1: return 0
    dist={seq:0}; dq=deque([seq])
    while dq:
        s=dq.popleft(); d=dist[s]; k=len(s)
        if k==1: return d
        nd=d+1
        for i in range(k):
            l=s[i-1] if i>0 else None
            r=s[i+1] if i<k-1 else None
            if l is not None and r is not None and l==r:
                ns=s[:i-1]+(l,)+s[i+2:]
            else:
                ns=s[:i]+s[i+1:]
            if ns not in dist: dist[ns]=nd; dq.append(ns)
        for i in range(k):
            l=s[i-1] if i>0 else None
            r=s[i+1] if i<k-1 else None
            for c in range(P):
                if c==s[i] or (l is not None and c==l) or (r is not None and c==r): continue
                ns=s[:i]+(c,)+s[i+1:]
                if ns not in dist: dist[ns]=nd; dq.append(ns)
    return None

import random
def rand_seq(k,P):
    s=[]
    for _ in range(k):
        c=random.randrange(P)
        if s and s[-1]==c: c=(c+1)%P
        s.append(c)
    return tuple(s)

random.seed(1)
for k in range(2,8):
    P=k+1
    vals=[]
    for _ in range(40):
        s=rand_seq(k,P)
        vals.append((solve_bfs(s,P),s))
    print("k",k,"vals",sorted(set(v for v,_ in vals)))
