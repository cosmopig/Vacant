import sys
sys.setrecursionlimit(1000000)
from collections import deque

def solve(seq):
    seq=tuple(seq)
    if len(seq)<=1: return 0
    dist={seq:0}; dq=deque([seq])
    while dq:
        s=dq.popleft(); d=dist[s]; k=len(s)
        if k==1: return d
        nd=d+1
        for i in range(k):
            l=s[i-1] if i>0 else None
            r=s[i+1] if i<k-1 else None
            if l is not None and r is not None and l==r:
                ns=s[:i-1]+(l,)+s[i+2:]
            else:
                ns=s[:i]+s[i+1:]
            if ns not in dist: dist[ns]=nd; dq.append(ns)
    return None

def gen(k,P):
    if k==0:
        yield (); return
    for rest in gen(k-1,P):
        for c in range(P):
            if rest and rest[-1]==c: continue
            yield rest+(c,)

for k,P in [(5,3),(6,3),(6,4),(7,3)]:
    bad=[]
    for s in gen(k,P):
        v=solve(s)
        # max possible b: ops_min = ceil? compute b = k-1-ops... ops = k-1-b -> b=k-1-ops
        b=k-1-v
        maxb=(k-1)//2
        if b<maxb: bad.append((s,v,b))
    print("k",k,"P",P,"numsubmax",len(bad))
    for x in bad[:40]: print("   ",x)
