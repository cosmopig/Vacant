import sys


def main():
    data = sys.stdin.buffer.read().split()
    idx = 0
    n = int(data[idx]); idx += 1
    q = int(data[idx]); idx += 1

    rebuilt = [False] * (n + 1)
    w = list(range(n + 1))      # w[i] = i initially; g_i after rebuild
    rank = [0] * (n + 1)        # rebuild order; 0 = never rebuilt
    timer = 0

    # b[j] = number of stations that can broadcast to city j
    b = [0] * (n + 2)
    pref = [0] * (n + 2)        # prefix sums of b, for range queries
    dirty = True

    def recompute():
        nonlocal dirty
        # p_i = nearest position k > i that is rebuilt with rank_k > rank_i
        # (next greater element to the right over rebuilt positions only)
        # Then station i covers [i, min(w_i, p_i - 1)].
        nge = [0] * (n + 1)
        stack = []
        for i in range(n, 0, -1):
            if not rebuilt[i]:
                continue
            ri = rank[i]
            while stack and rank[stack[-1]] <= ri:
                stack.pop()
            nge[i] = stack[-1] if stack else n + 1
            stack.append(i)

        diff = [0] * (n + 3)
        for i in range(1, n + 1):
            if rebuilt[i]:
                r = w[i]
                if nge[i] - 1 < r:
                    r = nge[i] - 1
                # covers [i, r]
                diff[i] += 1
                diff[r + 1] -= 1
            else:
                # unrebuilt station reaches only itself
                diff[i] += 1
                diff[i + 1] -= 1

        cur = 0
        for j in range(1, n + 1):
            cur += diff[j]
            b[j] = cur
            pref[j] = pref[j - 1] + cur
        dirty = False

    out = []
    for _ in range(q):
        p = int(data[idx]); idx += 1
        if p == 1:
            c = int(data[idx]); idx += 1
            g = int(data[idx]); idx += 1
            rebuilt[c] = True
            w[c] = g
            timer += 1
            rank[c] = timer
            dirty = True
        else:
            l = int(data[idx]); idx += 1
            r = int(data[idx]); idx += 1
            if dirty:
                recompute()
            out.append(str(pref[r] - pref[l - 1]))

    sys.stdout.write("\n".join(out) + ("\n" if out else ""))


main()
