#include <bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n,m;
    if(!(cin>>n>>m)) return 0;
    vector<string> rows(n);
    string line;
    // consume rest of first line
    getline(cin,line);
    for(int i=0;i<n;i++){
        if(!getline(cin,line)) line="";
        if(!line.empty() && line.back()=='\r') line.pop_back();
        rows[i]=line;
    }
    auto marked=[&](int r,int c)->bool{
        if(r<0||r>=n||c<0||c>=m) return true; // out of bounds treated as marked (no constraint)
        if(c>=(int)rows[r].size()) return false;
        return rows[r][c]=='X';
    };
    // value grid: -1 unassigned, else 1 or 4
    vector<vector<int>> val(n,vector<int>(m,1));
    // frontier id map
    vector<vector<int>> id(n,vector<int>(m,-1));
    int N=0;
    // first pass: count unmarked neighbors for marked cells; check parity
    // also collect frontier cells
    // neighbor offsets
    const int dr[4]={-1,1,0,0}, dc[4]={0,0,-1,1};
    bool bad=false;
    // store constraints as pairs of cell coords for coloring
    vector<pair<pair<int,int>,pair<int,int>>> edges;
    edges.reserve(1<<20);
    for(int r=0;r<n && !bad;r++)for(int c=0;c<m;c++){
        if(!marked(r,c)) continue;
        pair<int,int> nb[4]; int cnt=0;
        for(int d=0;d<4;d++){
            int rr=r+dr[d],cc=c+dc[d];
            if(rr>=0&&rr<n&&cc>=0&&cc<m&&!marked(rr,cc)) nb[cnt++]={rr,cc};
        }
        if(cnt==1||cnt==3){ bad=true; break; }
        if(cnt==2){
            // ensure ids
            for(auto&p:nb) if(id[p.first][p.second]<0) id[p.first][p.second]=N++;
            edges.push_back({nb[0],nb[1]});
        } else if(cnt==4){
            // need opposite pairs: identify which neighbor is up/down/left/right
            pair<int,int> up,down,left,right; bool hu=false,hd=false,hl=false,hr=false;
            for(int d=0;d<4;d++){
                int rr=r+dr[d],cc=c+dc[d];
                if(rr>=0&&rr<n&&cc>=0&&cc<m&&!marked(rr,cc)){
                    if(d==0)up={rr,cc},hu=true;
                    if(d==1)down={rr,cc},hd=true;
                    if(d==2)left={rr,cc},hl=true;
                    if(d==3)right={rr,cc},hr=true;
                }
            }
            // cnt==4 means all four unmarked
            for(auto&p:{up,down,left,right}) if(id[p.first][p.second]<0) id[p.first][p.second]=N++;
            edges.push_back({up,down});
            edges.push_back({left,right});
        }
    }
    if(bad){ cout<<"NO\n"; return 0; }
    // build adjacency for coloring
    vector<vector<int>> adj(N);
    // map coord->vertex id already in id[][]; need id->coord
    vector<pair<int,int>> coord(N);
    for(int r=0;r<n;r++)for(int c=0;c<m;c++) if(id[r][c]>=0) coord[id[r][c]]={r,c};
    for(auto&e:edges){
        int a=id[e.first.first][e.first.second];
        int b=id[e.second.first][e.second.second];
        if(a<0||b<0) continue;
        adj[a].push_back(b); adj[b].push_back(a);
    }
    vector<int> color(N,-1);
    // BFS 2-color; components independent
    for(int s=0;s<N;s++){
        if(color[s]!=-1) continue;
        color[s]=0;
        // iterative stack
        vector<int> st={s};
        while(!st.empty()){
            int u=st.back();st.pop_back();
            for(int w:adj[u]){
                if(color[w]==-1){color[w]=color[u]^1;st.push_back(w);}
                else if(color[w]==color[u]){ cout<<"NO\n"; return 0; }
            }
        }
    }
    // assign values: color0->1, color1->4 for frontier cells; non-frontier unmarked->1
    for(int i=0;i<N;i++){
        auto&p=coord[i];
        val[p.first][p.second]=(color[i]==0?1:4);
    }
    // compute marked values and output
    cout<<"YES\n";
    string out;
    out.reserve((size_t)n*m*2);
    for(int r=0;r<n;r++){
        for(int c=0;c<m;c++){
            if(marked(r,c)){
                int s=0;
                for(int d=0;d<4;d++){
                    int rr=r+dr[d],cc=c+dc[d];
                    if(rr>=0&&rr<n&&cc>=0&&cc<m&&!marked(rr,cc)) s+=val[rr][cc];
                }
                // append s
                char buf[16]; int l=sprintf(buf,"%d",s);
                out.append(buf,l);
            } else {
                char buf[16]; int l=sprintf(buf,"%d",val[r][c]);
                out.append(buf,l);
            }
            out.push_back(' ');
        }
        out.push_back('\n');
    }
    cout<<out;
    return 0;
}
