#include <bits/stdc++.h>
using namespace std;
typedef unsigned int u32;
typedef unsigned long long u64;
typedef unsigned __int128 u128;

int n, m, k;
u64 P;

int main() {
    if (scanf("%d %d %d %llu", &n, &m, &k, &P) != 4) return 0;
    // binomial coefficients mod P
    static u64 C[105][105];
    for (int i = 0; i <= n; i++) {
        C[i][0] = 1 % P;
        for (int j = 1; j <= i; j++)
            C[i][j] = (C[i-1][j-1] + C[i-1][j]) % P;
    }

    vector<u64> fact(n + 1);
    fact[0] = 1 % P;
    for (int i = 1; i <= n; i++) fact[i] = fact[i-1] * (u64)i % P;

    int K = k;
    // prev[s] = F[s][r-1], cur[s] = F[s][r]; each poly has degree <= K
    vector<vector<u32>> prev(n + 1, vector<u32>(K + 1, 0)),
                          cur(n + 1, vector<u32>(K + 1, 0));
    vector<int> degPrev(n + 1, 0), degCur(n + 1, 0);

    // row r = 0: F[0][0] = 1 (empty tree), F[s][0] = s! * x for s >= 1
    prev[0][0] = (u32)(1 % P);
    degPrev[0] = 0;
    for (int s = 1; s <= n; s++) {
        if (K >= 1) prev[s][1] = (u32)(fact[s] % P);
        degPrev[s] = (K >= 1 ? 1 : 0);
    }

    // tmp buffer for convolution
    static u64 tmpc[130];

    for (int r = 1; r <= m - 1; r++) {
        cur[0][0] = (u32)(1 % P); // F[0][r] = 1 for all r
        degCur[0] = 0;
        for (int s = 1; s <= n; s++) {
            fill(cur[s].begin(), cur[s].end(), 0);
            degCur[s] = 0;
            if (s <= r) {
                // no node can reach depth r: count is 0, weight = s!
                cur[s][0] = (u32)(fact[s] % P);
                degCur[s] = 0;
                continue;
            }
            int S = s - 1;
            // F[s][r] = sum_{a+b=S} C(S,a) P_a P_b ; use symmetry a<=b
            for (int a = 0; a <= S / 2; a++) {
                int b = S - a;
                u64 ways = C[S][a] % P;
                if (ways == 0) continue;
                u64 coef = ways;
                if (a != b) coef = (2 * ways) % P;
                if (coef == 0) continue;
                const vector<u32> &A = prev[a];
                const vector<u32> &B = prev[b];
                int da = degPrev[a], db = degPrev[b];
                int lim = min(K, da + db);
                // compute product coeffs c = 0..lim
                for (int c = 0; c <= lim; c++) {
                    int i0 = max(0, c - db), i1 = min(da, c);
                    u128 acc = 0;
                    for (int i = i0; i <= i1; i++)
                        acc += (u128)A[i] * (u128)B[c - i];
                    tmpc[c] = (u64)(acc % P);
                }
                for (int c = 0; c <= lim; c++) {
                    u64 v = cur[s][c] + coef * tmpc[c];
                    cur[s][c] = (u32)(v % P);
                }
                if (lim > degCur[s]) degCur[s] = lim;
            }
        }
        swap(prev, cur);
        swap(degPrev, degCur);
        // reset cur for next iteration
        for (int s = 0; s <= n; s++) fill(cur[s].begin(), cur[s].end(), 0);
    }

    // answer: coeff of x^k in F[n][m-1]
    u64 ans = prev[n][k] % P;
    printf("%llu\n", ans);
    return 0;
}
