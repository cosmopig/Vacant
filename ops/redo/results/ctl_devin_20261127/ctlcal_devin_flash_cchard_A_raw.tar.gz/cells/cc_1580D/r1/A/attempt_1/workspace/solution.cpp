#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

static const ll NEG = -(1LL << 60);

int n, m;
vector<ll> a;          // 1-indexed
vector<int> lc, rc;    // Cartesian tree children, 0 = none
int root;

void build_cartesian() {
    vector<int> st;
    st.reserve(n);
    for (int i = 1; i <= n; i++) {
        int last = 0;
        while (!st.empty() && a[st.back()] > a[i]) {
            last = st.back();
            st.pop_back();
        }
        if (!st.empty()) rc[st.back()] = i;
        lc[i] = last;
        st.push_back(i);
    }
    root = st.front();
}

// dp[k] = best value achievable inside subtree of u choosing exactly k nodes,
// where value = (m+1)*sum(a of chosen) - 2*sum over nodes t in subtree of
// a_t * (chosen in [L_t,t]) * (chosen in [t,R_t]).
vector<ll> dfs(int u) {
    vector<ll> L = lc[u] ? dfs(lc[u]) : vector<ll>{0};
    vector<ll> R = rc[u] ? dfs(rc[u]) : vector<ll>{0};
    int sl = (int)L.size(), sr = (int)R.size();
    int maxk = min(m, sl + sr - 1);
    vector<ll> dp(maxk + 1, NEG);
    ll av = a[u];
    ll benefit = (ll)(m + 1) * av;
    for (int c = 0; c <= 1; c++) {
        ll base = c ? benefit : 0;
        for (int i = 0; i < sl; i++) {
            if (L[i] == NEG) continue;
            int k0 = c + i;
            if (k0 > maxk) break;
            for (int j = 0; j < sr; j++) {
                int k = k0 + j;
                if (k > maxk) break;
                if (R[j] == NEG) continue;
                ll cand = L[i] + R[j] + base - 2 * av * (ll)(c + i) * (ll)(c + j);
                if (cand > dp[k]) dp[k] = cand;
            }
        }
    }
    return dp;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    if (!(cin >> n >> m)) return 0;
    a.assign(n + 1, 0);
    for (int i = 1; i <= n; i++) cin >> a[i];

    if (m == 0 || n == 0) {
        cout << 0 << "\n";
        return 0;
    }

    lc.assign(n + 1, 0);
    rc.assign(n + 1, 0);
    build_cartesian();

    vector<ll> dp = dfs(root);
    ll ans = (m < (int)dp.size()) ? dp[m] : NEG;
    if (ans == NEG) ans = 0;
    cout << ans << "\n";
    return 0;
}
