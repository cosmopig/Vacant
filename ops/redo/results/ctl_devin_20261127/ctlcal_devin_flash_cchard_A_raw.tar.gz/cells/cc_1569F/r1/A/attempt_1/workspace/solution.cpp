#include <bits/stdc++.h>
using namespace std;

int n, m, k, h;
int adjm[12]; // adjacency bitmask
int partner_[12];

// For a perfect matching given as pairs[P][2], test if it can be arranged
// into a palindromic Hamiltonian path: order pairs pi_1..pi_h and orient each
// (a_i, b_i) so that a_i-a_{i+1}, b_i-b_{i+1} are edges and a_h-b_h is an edge.
bool matchingValid(const array<array<int,2>,6>& P) {
    // state: (S, lastPair, flip). a_last = P[lp][f], b_last = P[lp][f^1]
    // dp index: S*(6*2) + lp*2 + f  -- but h may be < 6; use h pairs only
    int H = h;
    int stride = H * 2;
    int SZ = (1 << H) * stride;
    static bool dp[64 * 12];
    memset(dp, 0, sizeof(dp));
    for (int p = 0; p < H; p++) {
        for (int f = 0; f < 2; f++) {
            dp[(1 << p) * stride + p * 2 + f] = true;
        }
    }
    int full = (1 << H) - 1;
    for (int S = 1; S <= full; S++) {
        for (int lp = 0; lp < H; lp++) {
            if (!(S & (1 << lp))) continue;
            for (int f = 0; f < 2; f++) {
                if (!dp[S * stride + lp * 2 + f]) continue;
                int a_last = P[lp][f], b_last = P[lp][f ^ 1];
                if (S == full) {
                    // need middle edge a_h - b_h
                    if (adjm[a_last] >> b_last & 1) return true;
                    continue;
                }
                for (int q = 0; q < H; q++) {
                    if (S & (1 << q)) continue;
                    for (int g = 0; g < 2; g++) {
                        int a_new = P[q][g], b_new = P[q][g ^ 1];
                        if ((adjm[a_new] >> a_last & 1) && (adjm[b_new] >> b_last & 1)) {
                            dp[(S | (1 << q)) * stride + q * 2 + g] = true;
                        }
                    }
                }
            }
        }
    }
    return false;
}

// enumerate perfect matchings recursively
vector<array<array<int,2>,6>> validMatchings;
int curPairs[6][2];
int depth_;
void genMatchings2() {
    int v = -1;
    for (int i = 0; i < n; i++) if (partner_[i] == -1) { v = i; break; }
    if (v == -1) {
        array<array<int,2>,6> P{};
        for (int i = 0; i < h; i++) { P[i][0] = curPairs[i][0]; P[i][1] = curPairs[i][1]; }
        if (matchingValid(P)) validMatchings.push_back(P);
        return;
    }
    for (int u = v + 1; u < n; u++) {
        if (partner_[u] != -1) continue;
        partner_[v] = u; partner_[u] = v;
        curPairs[depth_][0] = v; curPairs[depth_][1] = u;
        depth_++;
        genMatchings2();
        depth_--;
        partner_[v] = partner_[u] = -1;
    }
}

// enumerate partitions of h pair-indices via restricted growth strings
// for each coarsening, build canonical vertex coloring key and record #blocks
unordered_map<unsigned long long, int> goodParts;

void enumCoarseningsRec(int idx, int hPairs, vector<int>& blk, int& maxBlk,
                        const array<array<int,2>,6>& P, int* pairIdx) {
    if (idx == hPairs) {
        // vertex colors: pairIdx[v] -> blk[pairIdx[v]]
        int col[12];
        for (int v = 0; v < n; v++) col[v] = blk[pairIdx[v]];
        // canonicalize: remap by first occurrence
        int mapid[16]; memset(mapid, -1, sizeof(mapid));
        int nxt = 0;
        unsigned long long key = 0;
        for (int v = 0; v < n; v++) {
            int c = col[v];
            if (mapid[c] == -1) mapid[c] = nxt++;
            key |= (unsigned long long)mapid[c] << (4 * v);
        }
        auto it = goodParts.find(key);
        if (it == goodParts.end()) goodParts[key] = nxt;
        else if (it->second != nxt) { /* shouldn't happen */ }
        return;
    }
    for (int b = 0; b <= maxBlk + 1; b++) {
        blk[idx] = b;
        int oldMax = maxBlk;
        if (b > maxBlk) maxBlk = b;
        enumCoarseningsRec(idx + 1, hPairs, blk, maxBlk, P, pairIdx);
        maxBlk = oldMax;
    }
}

int main() {
    if (scanf("%d %d %d", &n, &m, &k) != 3) return 0;
    memset(adjm, 0, sizeof(adjm));
    for (int i = 0; i < m; i++) {
        int v, u; scanf("%d %d", &v, &u);
        v--; u--;
        if (v == u) continue;
        adjm[v] |= (1 << u);
        adjm[u] |= (1 << v);
    }
    h = n / 2;
    memset(partner_, -1, sizeof(partner_));
    depth_ = 0;
    genMatchings2();

    for (auto& P : validMatchings) {
        int pairIdx[12];
        for (int i = 0; i < h; i++) {
            pairIdx[P[i][0]] = i;
            pairIdx[P[i][1]] = i;
        }
        vector<int> blk(h, 0);
        int maxBlk = -1;
        enumCoarseningsRec(0, h, blk, maxBlk, P, pairIdx);
    }

    long long ans = 0;
    for (auto& kv : goodParts) {
        int b = kv.second;
        if (b > k) continue;
        long long ways = 1;
        for (int i = 0; i < b; i++) ways *= (k - i);
        ans += ways;
    }
    printf("%lld\n", ans);
    return 0;
}
