import itertools, sys
exec(open('work/explore3.py').read().split('n,k=4,3')[0])

for n,k in [(5,3),(5,4)]:
    subs=subsets(n)
    import random
    random.seed(0)
    configs=list(itertools.product(subs,repeat=k)) if k<=3 else [tuple(random.choice(subs) for _ in range(k)) for _ in range(3000)]
    for w in (2,3):
        mismatch=0
        for steps in configs:
            f=correct_full(n,steps)
            r=correct_w(n,steps,w)
            if f!=r:
                mismatch+=1
                if mismatch<=3:
                    print("n,k,w mismatch",n,k,w,"full=",f,"steps=",[[p+1 for p in s] for s in steps])
        print("n,k,w=",n,k,w,"mismatches=",mismatch,"of",len(configs))
