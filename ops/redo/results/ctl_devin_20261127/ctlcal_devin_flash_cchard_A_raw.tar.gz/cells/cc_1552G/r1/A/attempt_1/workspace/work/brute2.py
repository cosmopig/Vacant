import itertools, sys

def simulate(bits, steps, n):
    a = bits[:]
    for S in steps:
        vals = sorted(a[p] for p in S)
        for p,v in zip(S, vals):
            a[p]=v
    return a

def correct(n, steps, retwitness=False):
    for mask in range(1<<n):
        bits=[(mask>>i)&1 for i in range(n)]
        out=simulate(bits,steps,n)
        if any(out[i]>out[j] for i in range(n) for j in range(i+1,n)):
            if retwitness: return False,bits,out
            return False
    return (True,None,None) if retwitness else True

def subsets(n):
    res=[]
    for r in range(1,n+1):
        for c in itertools.combinations(range(n),r):
            res.append(c)
    return res

n,k=3,3
subs=[s for s in subsets(n) if len(s)<n]
for steps in itertools.product(subs, repeat=k):
    names=[[p+1 for p in s] for s in steps]
    cov=set()
    for s in steps:
        for a,b in itertools.combinations(s,2):
            cov.add((a,b))
    adj=all((i,i+1) in cov for i in range(n-1))
    c=correct(n,steps)
    if adj and not c:
        print("COVERED-BUT-REJ", names, correct(n,steps,True)[1:])
