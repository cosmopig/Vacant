import itertools
exec(open('work/explore3.py').read().split('n,k=4,3')[0])

n=6
steps=[tuple(p-1 for p in s) for s in [[1,2,3,4,6],[1,5],[2,4,5],[3],[2,3,5,6],[1,2,5]]]
# find min weight counterexample
best=None
for mask in range(1<<n):
    z=tuple((mask>>i)&1 for i in range(n))
    o=simulate(z,steps)
    if not issorted(o):
        w=min(sum(z),n-sum(z))
        if best is None or w<best[0]:
            best=(w,z,o)
print("min weight",best)
# distribution: min ones and min zeros separately
for desc,cond in [("ones",lambda z:sum(z)),("zeros",lambda z:n-sum(z))]:
    m=min(cond(z) for mask in range(1<<n) for z in [tuple((mask>>i)&1 for i in range(n))] if not issorted(simulate(z,steps)))
    print(desc,"min",m)
