import itertools, random
exec(open('work/explore3.py').read().split('n,k=4,3')[0])

def runs(z):
    return 1+sum(1 for i in range(1,len(z)) if z[i]!=z[i-1])

def correct_runs(n,steps,maxruns):
    for mask in range(1<<n):
        z=tuple((mask>>i)&1 for i in range(n))
        if runs(z)>maxruns: continue
        if not issorted(simulate(z,steps)): return False
    return True

random.seed(7)
n=6
subs=subsets(n)
tested=0; mism=0
for _ in range(3000):
    k=random.randint(1,6)
    steps=tuple(random.choice(subs) for _ in range(k))
    f=correct_full(n,steps)
    for mr in (2,3,4):
        r=correct_runs(n,steps,mr)
        if f!=r:
            mism+=1
            if mism<=8:
                print("MISMATCH runs<=",mr,"full",f,"steps=",[[p+1 for p in s] for s in steps])
            break
    tested+=1
print("tested",tested,"mismatched configs",mism)
