import itertools, random

def sortS(bits, S):
    a=list(bits)
    vals=sorted(a[p] for p in S)
    for p,v in zip(S,vals): a[p]=v
    return tuple(a)

def image_after(steps, n):
    R=set(itertools.product([0,1],repeat=n))
    for S in steps:
        R=set(sortS(y,S) for y in R)
    return R

def is_implication_set(R,n):
    # R subset of {0,1}^n. Compute forbidden pairs F={(a,b): exists z in R with z_a=1,z_b=0}
    # then check R == {z : no (a,b) in F with z_a=1,z_b=0}
    F=set()
    for z in R:
        ones=[i for i,b in enumerate(z) if b]
        zeros=[i for i,b in enumerate(z) if not b]
        for a in ones:
            for b in zeros:
                F.add((a,b))
    # now check every z not violating F is in R, and every z in R doesn't violate (by construction ok)
    for z in itertools.product([0,1],repeat=n):
        viol=any(z[a]==1 and z[b]==0 for a,b in F)
        if not viol and z not in R:
            return False, F, z
    return True, F, None

random.seed(1)
n=6
subs=[s for s in itertools.chain.from_iterable(itertools.combinations(range(n),r) for r in range(2,n))]
for trial in range(200):
    k=random.randint(1,4)
    steps=[random.choice(subs) for _ in range(k)]
    # compute R after each prefix
    R=set(itertools.product([0,1],repeat=n))
    ok=True
    for t,S in enumerate(steps):
        R=set(sortS(y,S) for y in R)
        good,F,wit=is_implication_set(R,n)
        if not good:
            ok=False
            print("NOT implication set at step",t,"steps=",[[p+1 for p in s] for s in steps],"wit=",wit)
            break
    # if all implication sets, check final R subset sorted
    if ok:
        sortedset={z for z in R if all(z[i]<=z[j] for i in range(n) for j in range(i+1,n))}
        # actually sorted binary = 0*1*
        def issorted(z):
            return all(z[i]<=z[i+1] for i in range(n-1))
        allsorted=all(issorted(z) for z in R)
        print("trial",trial,"steps=",[[p+1 for p in s] for s in steps],"|R|=",len(R),"allsorted=",allsorted)
