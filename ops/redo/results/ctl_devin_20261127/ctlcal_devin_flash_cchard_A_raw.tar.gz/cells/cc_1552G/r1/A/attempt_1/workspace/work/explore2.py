import itertools

def simulate(bits, steps):
    a=list(bits)
    for S in steps:
        vals=sorted(a[p] for p in S)
        for p,v in zip(S,vals): a[p]=v
    return tuple(a)

def issorted(z): return all(z[i]<=z[i+1] for i in range(len(z)-1))

def correct_full(n,steps):
    for mask in range(1<<n):
        z=tuple((mask>>i)&1 for i in range(n))
        if not issorted(simulate(z,steps)): return False
    return True

def correct_w(n,steps,w):
    # only inputs with <=w ones or <=w zeros (i.e., weight<=w or n-weight<=w)
    for mask in range(1<<n):
        ones=bin(mask).count('1')
        if ones>w and n-ones>w: continue
        z=tuple((mask>>i)&1 for i in range(n))
        if not issorted(simulate(z,steps)): return False
    return True

def subsets(n):
    return [c for r in range(1,n+1) for c in itertools.combinations(range(n),r)]

n,k=4,3
subs=subsets(n)
mismatch=0; total=0
for steps in itertools.product(subs,repeat=k):
    total+=1
    f=correct_full(n,steps)
    for w in (1,2):
        r=correct_w(n,steps,w)
        if f!=r:
            mismatch+=1
            if mismatch<10:
                print("mismatch w=",w,"full=",f,"steps=",[[p+1 for p in s] for s in steps])
            break
print("total",total,"mismatch",mismatch)
