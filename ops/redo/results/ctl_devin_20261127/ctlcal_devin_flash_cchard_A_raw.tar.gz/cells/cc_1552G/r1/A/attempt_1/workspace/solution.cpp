#include <bits/stdc++.h>
using namespace std;

struct BDD {
    struct Node { int var, low, high; };
    vector<Node> nodes;
    unordered_map<long long,int> uniq;
    unordered_map<long long,int> cache;   // apply cache
    unordered_map<int,int> negcache;
    unordered_map<long long,int> itecache;

    BDD(int nvars){
        nodes.reserve(1<<16);
        nodes.push_back({-1,-1,-1}); // 0 false
        nodes.push_back({-1,-1,-1}); // 1 true
        for (int v=1; v<=nvars; v++) mk(v,0,1);
    }
    int mk(int var,int low,int high){
        if (low==high) return low;
        long long key = ((long long)var<<42) | ((long long)low<<21) | high;
        auto it=uniq.find(key);
        if (it!=uniq.end()) return it->second;
        int id=nodes.size();
        nodes.push_back({var,low,high});
        uniq[key]=id;
        return id;
    }
    static int evar(const BDD&b,int x){ return x<=1? INT_MAX : b.nodes[x].var; }
    int apply(int op,int a,int b){ // op 0=and 1=or
        if (op==0){
            if (a==0||b==0) return 0;
            if (a==1) return b;
            if (b==1) return a;
        } else {
            if (a==1||b==1) return 1;
            if (a==0) return b;
            if (b==0) return a;
        }
        if (a==b) return a;
        if (a>b) swap(a,b);
        long long key = ((long long)op<<62) | ((long long)a<<31) | b;
        auto it=cache.find(key);
        if (it!=cache.end()) return it->second;
        int va=nodes[a].var, vb=nodes[b].var, v=min(va,vb);
        int aL,aH,bL,bH;
        if (va==v){aL=nodes[a].low;aH=nodes[a].high;}else{aL=aH=a;}
        if (vb==v){bL=nodes[b].low;bH=nodes[b].high;}else{bL=bH=b;}
        int lo=apply(op,aL,bL), hi=apply(op,aH,bH);
        int r=mk(v,lo,hi);
        cache[key]=r;
        return r;
    }
    int neg(int a){
        if (a<=1) return 1-a;
        auto it=negcache.find(a);
        if (it!=negcache.end()) return it->second;
        int r=mk(nodes[a].var, neg(nodes[a].low), neg(nodes[a].high));
        negcache[a]=r;
        return r;
    }
    int ite(int f,int a,int b){
        if (f==1) return a;
        if (f==0) return b;
        if (a==b) return a;
        if (a==1&&b==0) return f;
        if (a==0&&b==1) return neg(f);
        // additional terminal reductions
        if (a==0){ // ~f & b
            return apply(0, neg(f), b);
        }
        if (b==1){ // ite(f,a,1) = ~f | a
            return apply(1, neg(f), a);
        }
        if (a==1){ // ite(f,1,b) = f | b
            return apply(1, f, b);
        }
        if (b==0){ // ite(f,a,0) = f & a
            return apply(0, f, a);
        }
        long long key=((long long)f<<42)|((long long)a<<21)|b;
        auto it=itecache.find(key);
        if (it!=itecache.end()) return it->second;
        int v=min(evar(*this,f),min(evar(*this,a),evar(*this,b)));
        auto cof=[&](int x)->pair<int,int>{
            if (evar(*this,x)>v) return {x,x};
            return {nodes[x].low,nodes[x].high};
        };
        auto cf=cof(f), ca=cof(a), cb=cof(b);
        int lo=ite(cf.first,ca.first,cb.first);
        int hi=ite(cf.second,ca.second,cb.second);
        int r=mk(v,lo,hi);
        itecache[key]=r;
        return r;
    }
};

int main(){
    int n,k;
    if (scanf("%d %d",&n,&k)!=2) return 0;
    vector<vector<int>> steps(k);
    for (int i=0;i<k;i++){
        int q; scanf("%d",&q);
        steps[i].resize(q);
        for (int j=0;j<q;j++){ scanf("%d",&steps[i][j]); steps[i][j]--; }
    }
    if (n<=1){ printf("ACCEPTED\n"); return 0; }

    BDD bdd(n);
    vector<int> g(n);
    for (int p=0;p<n;p++) g[p]=p+2; // var p+1 node id

    for (auto &S : steps){
        int m=S.size();
        vector<int> ch(m);
        for (int i=0;i<m;i++) ch[i]=g[S[i]];
        vector<vector<int>> memo(m+1, vector<int>(m+1,-1));
        function<int(int,int)> T = [&](int i,int r)->int{
            if (r<=0) return 1;
            if (m-i<r) return 0;
            if (i>=m) return 0;
            if (memo[i][r]!=-1) return memo[i][r];
            int res = bdd.ite(ch[i], T(i+1,r-1), T(i+1,r));
            memo[i][r]=res;
            return res;
        };
        vector<int> newg=g;
        for (int r=1;r<=m;r++) newg[S[r-1]] = T(0,r);
        g=newg;
    }

    bool ok=true;
    for (int i=0;i<n-1;i++){
        int ng = bdd.neg(g[i]);
        int bad = bdd.apply(0, g[i+1], ng);
        if (bad!=0){ ok=false; break; }
    }
    printf(ok?"ACCEPTED\n":"REJECTED\n");
    return 0;
}
