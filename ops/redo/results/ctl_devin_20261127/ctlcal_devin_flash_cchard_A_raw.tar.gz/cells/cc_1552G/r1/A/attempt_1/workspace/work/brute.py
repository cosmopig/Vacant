import itertools, sys

def simulate(bits, steps, n):
    a = bits[:]
    for S in steps:
        vals = sorted(a[p] for p in S)
        for p,v in zip(S, vals):
            a[p]=v
    return a

def correct(n, steps):
    for mask in range(1<<n):
        bits=[(mask>>i)&1 for i in range(n)]
        out=simulate(bits,steps,n)
        if any(out[i]>out[j] for i in range(n) for j in range(i+1,n)):
            return False
    return True

def subsets(n):
    res=[]
    for r in range(1,n+1):
        for c in itertools.combinations(range(n),r):
            res.append(c)
    return res

n=int(sys.argv[1]); k=int(sys.argv[2])
subs=subsets(n)
count=0; acc=0
for steps in itertools.product(subs, repeat=k):
    count+=1
    if correct(n,steps):
        acc+=1
        print("ACC", [[p+1 for p in s] for s in steps])
print("total",count,"accepted",acc)
