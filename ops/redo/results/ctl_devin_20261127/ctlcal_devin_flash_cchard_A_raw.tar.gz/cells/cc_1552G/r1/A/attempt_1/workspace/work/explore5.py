import itertools, random
exec(open('work/explore3.py').read().split('n,k=4,3')[0])

random.seed(42)
n=6
subs=subsets(n)
# exhaustive k=3 is 57^3 too many; sample heavily + structured cases
tested=0; mismatch=0
# random configs various k
for _ in range(4000):
    k=random.randint(1,6)
    steps=tuple(random.choice(subs) for _ in range(k))
    f=correct_full(n,steps); r=correct_w(n,steps,2)
    tested+=1
    if f!=r:
        mismatch+=1
        print("MISMATCH",[[p+1 for p in s] for s in steps],"full",f)
        if mismatch>5: break
print("tested",tested,"mismatch",mismatch)
