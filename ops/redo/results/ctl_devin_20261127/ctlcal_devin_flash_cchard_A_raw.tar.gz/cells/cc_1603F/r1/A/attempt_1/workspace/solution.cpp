#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
const ll MOD = 998244353;

static ll pw(ll a, ll e){
    ll r=1%MOD; a%=MOD;
    while(e){ if(e&1) r=r*a%MOD; a=a*a%MOD; e>>=1; }
    return r;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t; cin>>t;
    vector<ll> ns(t), ks(t), xs(t);
    ll kmax=0;
    for(int i=0;i<t;i++){ cin>>ns[i]>>ks[i]>>xs[i]; kmax=max(kmax,ks[i]); }

    vector<ll> invf(kmax+2), P(kmax+2), pref(kmax+2);
    const ll INV2 = (MOD+1)/2;

    for(int i=0;i<t;i++){
        ll n=ns[i], k=ks[i], x=xs[i];
        ll ans;
        if(x==0){
            if(n>k){ ans=0; }
            else{
                ll pk=pw(2,k), p2=1, r=1;
                for(ll j=0;j<n;j++){
                    r = r * ((pk - p2) % MOD + MOD) % MOD;
                    p2 = p2*2 % MOD;
                }
                ans = (r%MOD+MOD)%MOD;
            }
        } else {
            // batch inversion of f_i = 2^i - 1, i=1..k
            pref[0]=1;
            ll p2=1;
            for(ll j=1;j<=k;j++){ p2=p2*2%MOD; pref[j]=pref[j-1]*((p2-1+MOD)%MOD)%MOD; }
            ll qk=p2; // 2^k mod MOD
            ll invp=pw(pref[k], MOD-2);
            ll q=qk;
            for(ll j=k;j>=1;j--){
                invf[j]=pref[j-1]*invp%MOD;
                invp=invp*((q-1+MOD)%MOD)%MOD;
                q=q*INV2%MOD;
            }
            // P[m] = prod_{i=1}^{m-1}(1-2^i), P[0]=0, P[1]=1
            P[0]=0; if(k>=1) P[1]=1;
            ll r2=2;
            for(ll j=2;j<=k;j++){ P[j]=P[j-1]*((1-r2)%MOD+MOD)%MOD; r2=r2*2%MOD; }
            // fused sum: ans = sum_{d=0}^{k} bn^d * P[k-d] * ({k\brack d} - {k-1\brack d-1})
            ll bn=pw(2,n);
            ll bd=1;
            ll gk=1;          // {k \brack d}
            ll pwk=qk;        // 2^{k-d}
            ll g1=0;          // {k-1 \brack d-1}
            ll pvg1=pw(2,k-1); // 2^{k-d} used when advancing g1 at step d>=1
            ll term=0;
            for(ll d=0;;d++){
                term = (term + bd * P[k-d] % MOD * ((gk - g1)%MOD + MOD) % MOD) % MOD;
                if(d==k) break;
                bd = bd*bn % MOD;
                // advance {k\brack d} -> {k\brack d+1}: * (2^{k-d}-1)/(2^{d+1}-1)
                gk = gk * ((pwk-1+MOD)%MOD) % MOD * invf[d+1] % MOD;
                pwk = pwk*INV2 % MOD;
                // advance g1 -> {k-1\brack d}
                if(d==0) g1=1;
                else{
                    g1 = g1 * ((pvg1-1+MOD)%MOD) % MOD * invf[d] % MOD;
                    pvg1 = pvg1*INV2 % MOD;
                }
            }
            ans = (term%MOD+MOD)%MOD;
        }
        cout<<ans<<"\n";
    }
    return 0;
}
