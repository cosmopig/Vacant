#include <bits/stdc++.h>
using namespace std;

int m; // number of compressed vertices
vector<vector<array<int,3>>> adj; // (to, weight, eid)
vector<char> usedE;
vector<char> vis;
bool bad;

void dfs(int u, int s, int xr, int depth) {
    if (bad) return;
    for (auto &e : adj[u]) {
        int w = e[0], wt = e[1], id = e[2];
        if (usedE[id]) continue;
        if (w == s) {
            if (depth >= 2 && (xr ^ wt) != 1) { bad = true; return; }
        } else if (!vis[w] && w > s) {
            vis[w] = 1; usedE[id] = 1;
            dfs(w, s, xr ^ wt, depth + 1);
            usedE[id] = 0; vis[w] = 0;
            if (bad) return;
        }
    }
}

bool hasBadCycle() {
    bad = false;
    for (int s = 0; s < m && !bad; s++) {
        if (adj[s].empty()) continue;
        fill(vis.begin(), vis.end(), 0);
        vis[s] = 1;
        dfs(s, s, 0, 0);
    }
    return bad;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, q;
    if (!(cin >> n >> q)) return 0;
    vector<array<int,3>> qs(q);
    vector<int> verts;
    verts.reserve(2 * q);
    for (int i = 0; i < q; i++) {
        int u, v, x;
        cin >> u >> v >> x;
        qs[i] = {u, v, x};
        verts.push_back(u); verts.push_back(v);
    }
    sort(verts.begin(), verts.end());
    verts.erase(unique(verts.begin(), verts.end()), verts.end());
    m = verts.size();
    unordered_map<int,int> id;
    id.reserve(m * 2);
    for (int i = 0; i < m; i++) id[verts[i]] = i;

    adj.assign(m, {});
    vis.assign(m, 0);
    usedE.assign(q + 1, 0);

    string out;
    out.reserve(q * 4);
    int eid = 0;
    for (int i = 0; i < q; i++) {
        int u = id[qs[i][0]], v = id[qs[i][1]], x = qs[i][2];
        if (u == v) {
            // self-loop: a cycle of length 1 with weight x
            if (x == 1) { out += "YES\n"; }
            else { out += "NO\n"; }
            continue;
        }
        adj[u].push_back({v, x, eid});
        adj[v].push_back({u, x, eid});
        usedE[eid] = 0;
        bool ok = !hasBadCycle();
        if (ok) {
            eid++;
            out += "YES\n";
        } else {
            adj[u].pop_back();
            adj[v].pop_back();
            out += "NO\n";
        }
    }
    fputs(out.c_str(), stdout);
    return 0;
}
