#include <bits/stdc++.h>
using namespace std;

static const long long MOD = 1000000007LL;

static inline long long norm(long long x) {
    x %= MOD;
    if (x < 0) x += MOD;
    return x;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    long long k;
    if (!(cin >> n >> k)) return 0;
    vector<long long> a(n + 1);
    for (int i = 1; i <= n; i++) cin >> a[i];

    vector<vector<pair<int,int>>> adj(n + 1);
    for (int i = 0; i < n - 1; i++) {
        int u, v, t;
        cin >> u >> v >> t;
        adj[u].push_back({v, t});
        adj[v].push_back({u, t});
    }

    vector<long long> am(n + 1);
    long long sumA = 0;
    for (int i = 1; i <= n; i++) {
        am[i] = norm(a[i]);
        sumA = (sumA + am[i]) % MOD;
    }

    long long ans = 0;

    auto add_term = [&](long long ways, long long weight) {
        ans = (ans + (ways % MOD) * (weight % MOD)) % MOD;
    };

    if (n == 1) {
        cout << am[1] << '\n';
        return 0;
    }

    // k=0: paths using only one rail color. Sum separately over the two
    // monochromatic forests, then remove the duplicated singleton terms.
    if (k == 0) {
        long long pairSum = 0;
        for (int color = 0; color <= 1; color++) {
            vector<int> par(n + 1, -1), order;
            vector<int> sz(n + 1, 0);
            vector<vector<int>> cadj(n + 1);
            for (int u = 1; u <= n; u++) {
                for (auto [v, t] : adj[u]) if (t == color) cadj[u].push_back(v);
            }
            for (int s = 1; s <= n; s++) {
                if (par[s] != -1) continue;
                order.clear();
                vector<pair<int,int>> st;
                st.push_back({s, -1});
                par[s] = 0;
                while (!st.empty()) {
                    auto [x, p] = st.back(); st.pop_back();
                    order.push_back(x);
                    for (int y : cadj[x]) if (par[y] == -1) {
                        par[y] = x;
                        st.push_back({y, x});
                    }
                }
                int m = (int)order.size();
                for (int i = m - 1; i >= 0; i--) {
                    int x = order[i];
                    sz[x] = 1;
                    for (int y : cadj[x]) if (par[y] == x) sz[x] += sz[y];
                }
                for (int x : order) {
                    long long side = m - sz[x];
                    long long ssq = side * side;
                    for (int y : cadj[x]) if (par[y] == x) ssq += 1LL * sz[y] * sz[y];
                    long long total = (long long)(m - 1) * (m - 1);
                    long long ways = m + (total - ssq) / 2;
                    pairSum = (pairSum + (ways % MOD) * am[x]) % MOD;
                }
            }
        }
        pairSum = (pairSum - sumA) % MOD;
        if (pairSum < 0) pairSum += MOD;
        cout << pairSum << '\n';
        return 0;
    }

    // If k is at least the maximum possible number of switches on any path,
    // every tour is valid. Then each vertex contributes a_i times the number
    // of endpoint pairs whose tree path contains it.
    if (k >= n - 2) {
        vector<int> par(n + 1, -1), sz(n + 1, 0), order;
        order.reserve(n);
        vector<pair<int,int>> st;
        st.push_back({1, -1});
        par[1] = 0;
        while (!st.empty()) {
            auto [x, p] = st.back(); st.pop_back();
            order.push_back(x);
            for (auto [y, t] : adj[x]) if (par[y] == -1) {
                par[y] = x;
                st.push_back({y, x});
            }
        }
        for (int i = n - 1; i >= 0; i--) {
            int x = order[i];
            sz[x] = 1;
            for (auto [y, t] : adj[x]) if (par[y] == x) sz[x] += sz[y];
        }
        long long totalPairs = 0;
        for (int x = 1; x <= n; x++) {
            long long side = n - sz[x];
            long long ssq = side * side;
            for (auto [y, t] : adj[x]) if (par[y] == x) ssq += 1LL * sz[y] * sz[y];
            long long total = (long long)(n - 1) * (n - 1);
            long long ways = n + (total - ssq) / 2;
            totalPairs = (totalPairs + (ways % MOD) * am[x]) % MOD;
        }
        cout << totalPairs << '\n';
        return 0;
    }

    // General fallback: for every start vertex, one DFS computes the cost and
    // happiness sum of the unique path to every other vertex.
    vector<int> par(n + 1), pcol(n + 1);
    vector<long long> cost(n + 1), wsum(n + 1);
    vector<pair<int,int>> st;
    st.reserve(n);

    for (int s = 1; s <= n; s++) {
        fill(par.begin(), par.end(), -1);
        fill(pcol.begin(), pcol.end(), -1);
        fill(cost.begin(), cost.end(), 0);
        fill(wsum.begin(), wsum.end(), 0);

        ans = (ans + am[s]) % MOD; // tour (s, s)
        par[s] = 0;
        pcol[s] = -1;
        cost[s] = 0;
        wsum[s] = a[s];
        st.clear();
        st.push_back({s, -1});
        while (!st.empty()) {
            auto [x, p] = st.back(); st.pop_back();
            for (auto [y, c] : adj[x]) {
                if (y == p || par[y] != -1) continue;
                par[y] = x;
                pcol[y] = c;
                long long nc = cost[x];
                if (x != s && c != pcol[x]) nc++;
                cost[y] = nc;
                wsum[y] = wsum[x] + a[y];
                if (y >= s && nc <= k) add_term(1, wsum[y]);
                st.push_back({y, x});
            }
        }
    }

    ans = norm(ans);
    cout << ans << '\n';
    return 0;
}
