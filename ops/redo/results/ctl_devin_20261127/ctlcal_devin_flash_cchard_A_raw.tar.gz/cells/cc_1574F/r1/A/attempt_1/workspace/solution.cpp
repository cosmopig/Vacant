#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef vector<int> vi;
const int MOD = 998244353;

// State: sorted vector of (pattern_idx, offset). offset in 1..c-1 = next expected index.
// Empty vector = boundary/zero state.
using State = vector<pair<int,int>>;

int n, m, k;
vector<vi> A;          // kept patterns (pairwise-distinct values, c>=2)
vector<int> csz;
vector<char> banned;   // values banned by repeated-value patterns
vector<vi> valPats;    // value -> kept pattern indices containing it

static inline int getOff(const State& s, int idx){
    for(auto&p:s) if(p.first==idx) return p.second;
    return 0;
}

// forced successor of a nonzero state; false if dead. succ may become empty (=zero).
bool stepNonzero(const State& s, State& succ){
    int v = -1;
    for(auto&p:s){
        int val = A[p.first][p.second];
        if(v==-1) v=val;
        else if(val!=v) return false;
    }
    if(banned[v]) return false;
    succ.clear();
    for(int i : valPats[v]){
        int j = getOff(s, i);
        if(A[i][j] != v) return false;
        int nj = (j+1) % csz[i];
        if(nj>0) succ.push_back({i,nj});
    }
    sort(succ.begin(), succ.end());
    return true;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    if(!(cin>>n>>m>>k)) return 0;
    vector<vi> pats(n);
    for(int i=0;i<n;i++){
        int c; cin>>c;
        pats[i].resize(c);
        for(int j=0;j<c;j++) cin>>pats[i][j];
    }
    banned.assign(k+1,0);
    vector<char> repeat(n,0);
    for(int i=0;i<n;i++){
        if(pats[i].size()<2) continue;
        vi tmp=pats[i]; sort(tmp.begin(),tmp.end());
        for(size_t j=1;j<tmp.size();j++) if(tmp[j]==tmp[j-1]){repeat[i]=1;break;}
    }
    for(int i=0;i<n;i++) if(repeat[i]) for(int v:pats[i]) banned[v]=1;
    for(int i=0;i<n;i++){
        if(pats[i].size()<2 || repeat[i]) continue;
        A.push_back(pats[i]);
    }
    for(auto&p:A) csz.push_back((int)p.size());
    int N=(int)A.size();
    valPats.assign(k+1,{});
    vector<char> used(k+1,0);
    for(int i=0;i<N;i++) for(int v:A[i]){ valPats[v].push_back(i); used[v]=1; }

    ll freeCnt=0;
    for(int v=1;v<=k;v++) if(!used[v] && !banned[v]) freeCnt++;
    freeCnt%=MOD;

    // zero-state transitions: startable values -> first nonzero state (grouped by state, weight=#values)
    vector<char> seen(k+1,0);
    map<State,int> ws;
    for(int i=0;i<N;i++){
        int v=A[i][0];
        if(seen[v]) continue; seen[v]=1;
        if(banned[v] || valPats[v].empty()) continue;
        bool ok=true;
        for(int j:valPats[v]) if(A[j][0]!=v){ok=false;break;}
        if(!ok) continue;
        State s;
        for(int j:valPats[v]) s.push_back({j,1});
        sort(s.begin(),s.end());
        ws[s]+=1;
    }

    // For each distinct first-state, simulate deterministic path until zero/dead/cycle.
    // Petal: (length, weight). length = total positions consumed returning to zero.
    vector<pair<int,int>> petals; // (len, weight)
    for(auto&kv: ws){
        State cur = kv.first;
        int w = kv.second;
        set<State> seenStates;
        seenStates.insert(cur);
        int len = 1; // consumed the startable value already
        bool dead=false, cycled=false;
        while(true){
            State succ;
            if(!stepNonzero(cur, succ)){ dead=true; break; }
            len++;
            if(len>m){ dead=true; break; } // too long to contribute
            if(succ.empty()) break; // returned to zero -> petal complete
            if(seenStates.count(succ)){ cycled=true; break; }
            seenStates.insert(succ);
            cur = succ;
        }
        if(dead||cycled) continue;
        petals.push_back({len,w});
    }

    // Renewal: g[t] = freeCnt*g[t-1] + sum_p w_p * g[t - len_p]
    vector<ll> g(m+1,0);
    g[0]=1;
    // group petals by length
    map<int,ll> byLen;
    for(auto&p:petals) byLen[p.first] = (byLen[p.first] + p.second) % MOD;
    vector<pair<int,ll>> pl(byLen.begin(),byLen.end());
    for(int t=1;t<=m;t++){
        ll val = (ll)((__int128)g[t-1]*freeCnt % MOD);
        for(auto&pr: pl){
            if(pr.first>t) break;
            val = (val + (__int128)g[t-pr.first]*pr.second) % MOD;
        }
        g[t]=val;
    }
    ll ans=g[m]%MOD; if(ans<0)ans+=MOD;
    printf("%lld\n", ans);
    return 0;
}
