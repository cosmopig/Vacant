import json,sys,time
from functools import lru_cache
sys.setrecursionlimit(1000000)
MOD=998244353
cases=json.load(open('cases.json'))

def components(n,big):
    parent={x:x for x in range(1,n+1)}
    def find(x):
        while parent[x]!=x: parent[x]=parent[parent[x]]; x=parent[x]
        return x
    def union(a,b):
        ra,rb=find(a),find(b)
        if ra!=rb: parent[ra]=rb
    for S in big:
        it=list(S)
        for x in it[1:]: union(it[0],x)
    from collections import defaultdict
    comp=defaultdict(set)
    for S in big:
        comp[find(next(iter(S)))]|=S
    return comp,parent,find

def solve_dp_count(n,sets,cap=2000000):
    elems=list(range(1,n+1)); idx={x:i for i,x in enumerate(elems)}
    smasks=[]
    for S in sets:
        m=0
        for x in S: m|=1<<idx[x]
        smasks.append(m)
    full=(1<<n)-1
    cnt=[0]
    @lru_cache(maxsize=None)
    def f(P):
        cnt[0]+=1
        if cnt[0]>cap: raise RuntimeError("cap")
        if P==full: return 1
        inter=-1; has=False
        for sm in smasks:
            if (sm&P) and (sm&~P&full):
                has=True; inter&=sm
        cand=((~P)&full&inter) if has else ((~P)&full)
        total=0; c=cand
        while c:
            lb=c&-c; total=(total+f(P|lb))%MOD; c^=lb
        return total
    try:
        r=f(0)
        return r,cnt[0],len(f.cache_info().__str__())
    except RuntimeError:
        return None,cnt[0],None

for ci in [3,5,8,21,23,25,29,6]:
    c=cases[ci]; lines=c['input'].strip().split('\n')
    n,m=map(int,lines[0].split())
    sets=[]
    for j in range(m):
        p=list(map(int,lines[j+1].split())); sets.append(frozenset(p[1:]))
    big=[S for S in sets if len(S)>=2]
    comp,parent,find=components(n,big)
    for root,U in comp.items():
        if len(U)<15: continue
        loc=sorted(U); mp={x:i+1 for i,x in enumerate(loc)}
        lsets=[frozenset(mp[x] for x in S) for S in big if find(next(iter(S)))==root]
        t=time.time()
        r,states,_=solve_dp_count(len(loc),lsets)
        print(f"case{ci} comp size={len(U)} m={len(lsets)} -> {'TIMEOUT/None' if r is None else r} states={states} t={time.time()-t:.1f}")
