#include <bits/stdc++.h>
using namespace std;
typedef unsigned __int128 u128;
typedef long long ll;
const ll MOD=998244353;

struct H128 {
    size_t operator()(const u128 &x) const {
        uint64_t lo=(uint64_t)x, hi=(uint64_t)(x>>64);
        uint64_t h=lo*0x9E3779B97F4A7C15ULL ^ hi*0xC2B2AE3D27D4EB4FULL;
        h^=h>>33; h*=0xFF51AFD7ED558CCDULL; h^=h>>33;
        return (size_t)h;
    }
};

int n,m;
vector<u128> gsets; // global masks over bits 0..n-1 (element i -> bit i-1)

// per-component DP
struct Solver {
    int N;
    vector<u128> sets;
    u128 full;
    unordered_map<u128,ll,H128> memo;
    long long states=0, cap=(long long)4e8;
    Solver(int n_, vector<u128>&& s):N(n_),sets(move(s)){
        full = N>=128?~(u128)0:(((u128)1<<N)-1);
    }
    ll dfs(u128 P){
        if(P==full) return 1;
        auto it=memo.find(P);
        if(it!=memo.end()) return it->second;
        states++;
        u128 inter=full; bool has=false;
        u128 notP = full & ~P;
        for(u128 sm:sets){
            if((sm&P) && (sm&notP)) { has=true; inter&=sm; }
        }
        u128 cand = has? (notP & inter) : notP;
        ll total=0;
        u128 c=cand;
        while(c){
            u128 lb=c & (~c+1); // lowest bit  (c & -c works for unsigned)
            c^=lb;
            total+=dfs(P|lb);
            if(total>=MOD) total-=MOD;
        }
        if(states>cap){ cerr<<"CAP\n"; exit(3);}
        memo[P]=total;
        return total;
    }
    ll run(){ return dfs(0); }
};

ll fact(int k){ ll r=1; for(int i=2;i<=k;i++){r=r*i%MOD;} return r; }

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cin>>n>>m;
    vector<vector<int>> raw(m);
    for(int i=0;i<m;i++){
        int q; cin>>q; raw[i].resize(q);
        for(int j=0;j<q;j++) cin>>raw[i][j];
    }
    // dedupe sets, drop size<=1
    set<vector<int>> uniq;
    for(auto&v:raw){ sort(v.begin(),v.end()); v.erase(unique(v.begin(),v.end()),v.end()); if(v.size()>=2) uniq.insert(v); }
    vector<vector<int>> sets(uniq.begin(),uniq.end());
    // union-find on singers
    vector<int> par(n+1); iota(par.begin(),par.end(),0);
    function<int(int)> find=[&](int x){return par[x]==x?x:par[x]=find(par[x]);};
    auto uni=[&](int a,int b){a=find(a);b=find(b);if(a!=b)par[a]=b;};
    for(auto&v:sets){ for(size_t i=1;i<v.size();i++) uni(v[0],v[i]); }
    // components: map root->list of local element ids
    map<int,vector<int>> compElems;
    vector<int> covered(n+1,0);
    for(auto&v:sets) for(int x:v){ covered[x]=1; }
    for(int x=1;x<=n;x++) if(covered[x]) compElems[find(x)].push_back(x);
    int k=compElems.size();
    int rfree=0; for(int x=1;x<=n;x++) if(!covered[x]) rfree++;
    ll ans=fact(k+rfree);
    // group sets by component root
    for(auto&kv:compElems){
        int root=kv.first; auto& elems=kv.second;
        // local index
        unordered_map<int,int> loc; loc.reserve(elems.size()*2);
        for(size_t i=0;i<elems.size();i++) loc[elems[i]]=i;
        vector<u128> lsets;
        for(auto&v:sets){
            if(find(v[0])!=root) continue;
            u128 mm=0; for(int x:v) mm|=((u128)1)<<loc[x];
            lsets.push_back(mm);
        }
        // dedupe local masks
        sort(lsets.begin(),lsets.end()); lsets.erase(unique(lsets.begin(),lsets.end()),lsets.end());
        Solver sv(elems.size(), move(lsets));
        ll c=sv.run();
        ans=ans*c%MOD;
        cerr<<"comp size="<<elems.size()<<" sets="<<sv.sets.size()<<" states="<<sv.states<<"\n";
    }
    cout<<ans%MOD<<"\n";
    return 0;
}
