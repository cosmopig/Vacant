import json,itertools,random
cases=json.load(open('cases.json'))

def primal_chordal(n,sets):
    # build adjacency
    adj=[set() for _ in range(n+1)]
    for S in sets:
        if len(S)<2: continue
        L=list(S)
        for i in range(len(L)):
            for j in range(i+1,len(L)):
                adj[L[i]].add(L[j]); adj[L[j]].add(L[i])
    # Maximum Cardinality Search -> check perfect elimination
    weight=[0]*(n+1); numbered=[False]*(n+1); order=[]
    for _ in range(n):
        # pick unnumbered max weight
        v=max((w,i) for i,w in enumerate(weight) if not numbered[i] and i>=1)[1]
        numbered[v]=True; order.append(v)
        for u in adj[v]:
            if not numbered[u]: weight[u]+=1
    # check PEO: for each v, later neighbors form clique
    pos={v:i for i,v in enumerate(order)}
    for v in range(1,n+1):
        later=[u for u in adj[v] if pos[u]>pos[v]]
        if not later: continue
        # parent = earliest later neighbor
        p=min(later,key=lambda u:pos[u])
        for u in later:
            if u!=p and u not in adj[p]:
                return False
    return True

def feasible_brute(n,sets):
    for p in itertools.permutations(range(1,n+1)):
        pos={x:i for i,x in enumerate(p)}
        ok=True
        for S in sets:
            if len(S)<=1: continue
            ps=[pos[x] for x in S]
            if max(ps)-min(ps)!=len(S)-1: ok=False;break
        if ok: return True
    return False

# check test cases chordality per whole instance (primal graph global)
for i in [3,5,6,25]:
    lines=cases[i]['input'].strip().split('\n')
    n,m=map(int,lines[0].split())
    sets=[]
    for j in range(m):
        p=list(map(int,lines[j+1].split())); sets.append(set(p[1:]))
    print('case',i,'chordal=',primal_chordal(n,sets))

# verify necessity on small random: if feasible then chordal?
random.seed(1); bad=0; tot=0
for t in range(2000):
    n=random.randint(2,7); m=random.randint(1,4)
    sets=[set(random.sample(range(1,n+1),random.randint(2,n))) for _ in range(m)]
    f=feasible_brute(n,sets); ch=primal_chordal(n,sets)
    tot+=1
    if f and not ch:
        bad+=1; print('feasible but nonchordal!',n,sets); break
print('checked',tot,'bad',bad)
