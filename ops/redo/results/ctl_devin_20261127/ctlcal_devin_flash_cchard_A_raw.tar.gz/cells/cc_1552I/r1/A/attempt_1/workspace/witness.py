import json,itertools,sys
sys.setrecursionlimit(100000)
cases=json.load(open('cases.json'))

def comps(n,big):
    par={x:x for x in range(1,n+1)}
    def f(x):
        while par[x]!=x: par[x]=par[par[x]]; x=par[x]
        return x
    def u(a,b):
        ra,rb=f(a),f(b)
        if ra!=rb: par[ra]=rb
    for S in big:
        it=list(S)
        for x in it[1:]: u(it[0],x)
    from collections import defaultdict
    comp=defaultdict(set)
    for S in big: comp[f(next(iter(S)))]|=S
    return comp,par,f

def feasible_dp(U,sets):
    # U: list of elements; sets: list of frozenset subsets of U. existence of ordering of U s.t. each set consecutive
    idx={x:i for i,x in enumerate(U)}
    sm=[]
    for S in sets:
        m=0
        for x in S: m|=1<<idx[x]
        sm.append(m)
    full=(1<<len(U))-1
    from functools import lru_cache
    @lru_cache(maxsize=None)
    def g(P):
        if P==full: return True
        inter=(1<<len(U))-1; has=False
        notP=full&~P
        for s in sm:
            if (s&P) and (s&notP): has=True; inter&=s
        cand=(notP&inter) if has else notP
        c=cand
        while c:
            lb=c&-c
            if g(P|lb): return True
            c^=lb
        return False
    return g(0)

def find_witness(sets,maxu=9):
    # sets: list of frozensets (local). find subfamily with union<=maxu that is infeasible
    m=len(sets)
    # enumerate by union size: try all subsets of sets up to size limit, prune by union
    best=None
    # candidate: sort sets; DFS over index, track union; if union>maxu prune
    order=sorted(range(m),key=lambda i:len(sets[i]))
    def dfs(k,chosen,U):
        nonlocal best
        if best is not None: return
        if k==len(order):
            if len(chosen)>=2 and not feasible_dp(sorted(U),[sets[i] for i in chosen]):
                best=list(chosen)
            return
        # option: skip
        dfs(k+1,chosen,U)
        # option: take
        i=order[k]
        U2=U|sets[i]
        if len(U2)<=maxu:
            dfs(k+1,chosen+[i],U2)
    dfs(0,[],set())
    return best

for ci in [3,5,6,25]:
    lines=cases[ci]['input'].strip().split('\n')
    n,m=map(int,lines[0].split())
    raw=[]
    for j in range(m):
        p=list(map(int,lines[j+1].split())); raw.append(frozenset(p[1:]))
    big=[S for S in raw if len(S)>=2]
    comp,par,f=comps(n,big)
    for root,U in comp.items():
        if len(U)<20: continue
        lsets=[S for S in big if f(next(iter(S)))==root]
        # remap to 0..k-1
        loc=sorted(U); mp={x:i for i,x in enumerate(loc)}
        ls=[frozenset(mp[x] for x in S) for S in lsets]
        ls=[frozenset(s) for s in ls if len(s)>=2]
        ls=list(set(ls))
        w=find_witness(ls,9)
        print('case',ci,'comp',len(U),'m',len(ls),'witness',None if w is None else [sorted(ls[i]) for i in w])
