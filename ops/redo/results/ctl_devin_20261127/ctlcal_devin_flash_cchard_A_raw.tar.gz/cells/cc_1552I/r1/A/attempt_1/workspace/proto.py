import sys, itertools
from functools import lru_cache
sys.setrecursionlimit(100000)
MOD=998244353

def brute(n, sets):
    cnt=0
    for p in itertools.permutations(range(1,n+1)):
        pos={x:i for i,x in enumerate(p)}
        ok=True
        for S in sets:
            if len(S)<=1: continue
            ps=[pos[x] for x in S]
            if max(ps)-min(ps)!=len(S)-1:
                ok=False;break
        if ok: cnt+=1
    return cnt

def solve_dp(n, sets):
    # sets: list of frozensets (size>=2), elements 1..n (local)
    elems=list(range(1,n+1))
    idx={x:i for i,x in enumerate(elems)}
    smasks=[]
    for S in sets:
        m=0
        for x in S: m|=1<<idx[x]
        smasks.append(m)
    full=(1<<n)-1
    from functools import lru_cache
    @lru_cache(maxsize=None)
    def f(P):
        if P==full: return 1
        # compute open sets and intersection
        inter=-1  # all ones within n bits
        has_open=False
        for sm in smasks:
            if (sm&P)!=0 and (sm&~P&full)!=0:
                has_open=True
                inter&=sm
        if has_open:
            cand=(~P)&full&inter
        else:
            cand=(~P)&full
        total=0
        c=cand
        while c:
            lb=c&-c
            total=(total+f(P|lb))%MOD
            c^=lb
        return total
    return f(0)

def solve(n, sets):
    # components via singer overlap among size>=2 sets
    parent={x:x for x in range(1,n+1)}
    def find(x):
        while parent[x]!=x: parent[x]=parent[parent[x]]; x=parent[x]
        return x
    def union(a,b):
        ra,rb=find(a),find(b)
        if ra!=rb: parent[ra]=rb
    big=[S for S in sets if len(S)>=2]
    for S in big:
        it=list(S)
        for x in it[1:]: union(it[0],x)
    from collections import defaultdict
    comp=defaultdict(set)
    for S in big:
        r=find(next(iter(S)))
        comp[r]|=S
    covered=set().union(*big) if big else set()
    r_free=n-len(covered)
    k=len(comp)
    # factorial (k+r_free)!
    import math
    fact=math.factorial(k+r_free)%MOD
    prod=1
    for root,U in comp.items():
        loc=sorted(U)
        lsets=[S for S in big if find(next(iter(S)))==root]
        # remap to local indices 1..|U|
        mp={x:i+1 for i,x in enumerate(loc)}
        lsets2=[frozenset(mp[x] for x in S) for S in lsets]
        prod=prod*solve_dp(len(loc),lsets2)%MOD
    return fact*prod%MOD

import random
random.seed(0)
for t in range(300):
    n=random.randint(1,7)
    m=random.randint(1,4)
    sets=[]
    for _ in range(m):
        q=random.randint(1,n)
        S=frozenset(random.sample(range(1,n+1),q))
        sets.append(S)
    b=brute(n,sets)%MOD
    d=solve(n,sets)
    if b!=d:
        print("MISMATCH",n,m,sets,b,d)
        break
else:
    print("all ok")
