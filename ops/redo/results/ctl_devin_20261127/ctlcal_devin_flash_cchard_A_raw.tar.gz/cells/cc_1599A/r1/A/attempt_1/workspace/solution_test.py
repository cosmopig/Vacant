"""Tests for the solution (solution.cpp if present, else solution.py; reads stdin, writes stdout). One test per case;
output compared after whitespace normalisation (whitespace-separated tokens must be equal)."""
import hashlib
import json
import os
import resource
import subprocess
import sys
import tempfile
import unittest

_HERE = os.path.dirname(os.path.abspath(__file__))
_DATA = "cases.json"
_DATA_SHA256 = "16d0b2561b9b4b2ce0e884b98db1a7a50fdb1e998ab06cce4c722530dd5ad850"
_LIMIT_S = 4
_N = 30
_state = {"timeouts": 0, "cases": None, "cmd": None, "cerr": None}


def _cases():
    if _state["cases"] is None:
        raw = open(os.path.join(_HERE, _DATA), "rb").read()
        if hashlib.sha256(raw).hexdigest() != _DATA_SHA256:
            raise AssertionError("data file %s was modified" % _DATA)
        _state["cases"] = json.loads(raw)
    return _state["cases"]


def _prepare():
    if _state["cmd"] is not None or _state["cerr"] is not None:
        return
    src = os.path.join(_HERE, "solution.cpp")
    if os.path.isfile(src):
        out = os.path.join(tempfile.mkdtemp(prefix="solbin-"), "sol")
        try:
            p = subprocess.run(["g++", "-O2", "-std=gnu++17", "-o", out, src], capture_output=True, text=True, timeout=60)
        except subprocess.TimeoutExpired:
            _state["cerr"] = "compile timed out (60s)"
            return
        if p.returncode != 0:
            _state["cerr"] = "compile error: " + p.stderr[:400]
            return
        _state["cmd"] = [out]
    else:
        _state["cmd"] = [sys.executable, "solution.py"]


def _limits():
    resource.setrlimit(resource.RLIMIT_AS, (2 << 30, 2 << 30))


def _clip(s, n=240):
    return s if len(s) <= n else s[:n] + "...(%d chars)" % len(s)


def _run_case(tc, i):
    if _state["timeouts"] >= 3:
        tc.fail("skipped: 3 earlier cases timed out in this run")
    case = _cases()[i]
    _prepare()
    if _state["cerr"]:
        tc.fail(_state["cerr"])
    try:
        p = subprocess.run(_state["cmd"], input=case["input"], capture_output=True, text=True,
                           cwd=_HERE, timeout=_LIMIT_S, preexec_fn=_limits)
    except subprocess.TimeoutExpired:
        _state["timeouts"] += 1
        tc.fail("time limit exceeded (%ss) on case %d" % (_LIMIT_S, i))
    if p.returncode != 0:
        tc.fail("runtime error (exit %d) on case %d: %s" % (p.returncode, i, _clip(p.stderr[-400:])))
    if p.stdout.split() != case["output"].split():
        tc.fail("wrong answer on case %d\ninput: %s\nexpected: %s\ngot: %s"
                % (i, _clip(case["input"]), _clip(case["output"]), _clip(p.stdout)))


class SolutionTest(unittest.TestCase):
    pass


def _mk(i):
    def t(self):
        _run_case(self, i)
    return t


for _i in range(_N):
    setattr(SolutionTest, "test_case_%02d" % _i, _mk(_i))

if __name__ == "__main__":
    unittest.main()
