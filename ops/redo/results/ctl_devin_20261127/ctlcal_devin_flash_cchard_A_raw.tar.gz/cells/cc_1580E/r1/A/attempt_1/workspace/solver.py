import json, heapq, sys
from collections import defaultdict

def load(i):
    c=json.load(open('cases.json'))[i]
    tok=c['input'].split()
    it=iter(tok)
    n=int(next(it)); m=int(next(it)); q=int(next(it))
    w=[int(next(it)) for _ in range(n)]
    edges=[]
    for _ in range(m):
        edges.append((int(next(it)),int(next(it)),int(next(it))))
    qs=[(int(next(it)),int(next(it))) for _ in range(q)]
    return n,m,q,w,edges,qs,c['output']

def dists(n,edges):
    adj=[[] for _ in range(n+1)]
    for u,v,d in edges:
        if 1<=u<=n and 1<=v<=n and u!=v:
            adj[u].append((v,d)); adj[v].append((u,d))
    INF=float('inf'); dist=[INF]*(n+1); dist[1]=0
    pq=[(0,1)]
    while pq:
        dd,u=heapq.heappop(pq)
        if dd>dist[u]: continue
        for v,d in adj[u]:
            nd=dd+d
            if nd<dist[v]: dist[v]=nd; heapq.heappush(pq,(nd,v))
    return dist

def dag_edges(n,edges,dist):
    dag=set()
    for u,v,d in edges:
        if not(1<=u<=n and 1<=v<=n) or u==v: continue
        if dist[v]==dist[u]+d: dag.add((u,v))
        if dist[u]==dist[v]+d: dag.add((v,u))
    return dag

def maxflow2(n, adj, s, t):
    # vertex capacities 1 for internal vertices, edge cap 1.
    # split: x_in->x_out cap (inf for s,t else 1); edges u_out->v_in cap1
    # nodes: id = 2*(x-1) for in, 2*(x-1)+1 for out ; s_out is source? path starts at s: use s_out as source, t_in as sink.
    N=2*n
    g=[[] for _ in range(N)]  # (to, cap, rev_index)
    def add(a,b,c):
        g[a].append([b,c,len(g[b])])
        g[b].append([a,0,len(g[a])-1])
    for x in range(1,n+1):
        cap = 10**9 if x==s or x==t else 1
        add(2*(x-1), 2*(x-1)+1, cap)
    for u,v in adj:
        add(2*(u-1)+1, 2*(v-1), 1)
    S=2*(s-1)+1; T=2*(t-1)
    flow=0
    while flow<2:
        # bfs
        par=[None]*N; par[S]=(S,-1,-1)
        from collections import deque
        dq=deque([S])
        while dq:
            x=dq.popleft()
            if x==T: break
            for i,e in enumerate(g[x]):
                if e[1]>0 and par[e[0]] is None:
                    par[e[0]]=(x,i,-1)
                    dq.append(e[0])
        if par[T] is None: break
        # find bottleneck
        b=10**9; x=T
        while x!=S:
            px,i,_=par[x]
            e=g[px][i]
            b=min(b,e[1]); x=px
        x=T
        while x!=S:
            px,i,_=par[x]
            e=g[px][i]
            e[1]-=b
            g[x][par[x][2] if False else 0] # placeholder
            x=px
        # redo augmentation properly below
        break
    return flow

# simpler correct maxflow
def mf(adj_edges, n, s, t, need=2):
    N=2*n
    g=[[] for _ in range(N)]
    def add(a,b,c):
        g[a].append([b,c,len(g[b])])
        g[b].append([a,0,len(g[a])-1])
    for x in range(1,n+1):
        cap=10**9 if x==s or x==t else 1
        add(2*(x-1),2*(x-1)+1,cap)
    for u,v in adj_edges:
        add(2*(u-1)+1,2*(v-1),1)
    S=2*(s-1)+1; T=2*(t-1)
    flow=0
    from collections import deque
    while flow<need:
        par=[(-1,-1)]*N; par[S]=(S,-1)
        dq=deque([S])
        while dq:
            x=dq.popleft()
            if x==T: break
            for i,e in enumerate(g[x]):
                if e[1]>0 and par[e[0]][0]==-1:
                    par[e[0]]=(x,i); dq.append(e[0])
        if par[T][0]==-1: break
        b=10**9; x=T
        while x!=S:
            px,i=par[x]; b=min(b,g[px][i][1]); x=px
        x=T
        while x!=S:
            px,i=par[x]
            e=g[px][i]; e[1]-=b
            g[x][e[2]][1]+=b
            x=px
        flow+=b
    return flow

def feasible(n, dag, added):
    adj=list(dag)+list(added)
    for t in range(2,n+1):
        if mf(adj,n,1,t,2)<2: return False
    return True

if __name__=='__main__':
    i=int(sys.argv[1]) if len(sys.argv)>1 else 4
    n,m,q,w,edges,qs,out=load(i)
    dist=dists(n,edges)
    dag=dag_edges(n,edges,dist)
    print('dag',sorted(dag))
    # test the known solution for case4
    if i==4:
        added=[(1,2),(1,3),(1,4),(2,8)]
        print('feasible?',feasible(n,dag,added))
        for t in range(2,n+1):
            print(' node',t,'flow',mf(list(dag)+added,n,1,t,2))

def candidates(n,dist):
    c=[]
    for u in range(1,n+1):
        for v in range(1,n+1):
            if u!=v and dist[u]<dist[v]:
                c.append((u,v))
    return c

def solve_exact(n,dag,w,dist,limit_states=2000000):
    cand=candidates(n,dist)
    # index edges; cost of edge = w[u-1]
    ec=[w[u-1] for u,v in cand]
    import heapq as hq
    # state: bitmask -> cost
    start=0
    best={0:0}
    pq=[(0,0)]
    seen=set()
    it=0
    while pq:
        cost,mask=hq.heappop(pq)
        if mask in seen: continue
        seen.add(mask)
        it+=1
        if it>limit_states: return None,it
        added=[cand[i] for i in range(len(cand)) if mask>>i&1]
        if feasible(n,dag,added):
            return (cost,added),it
        for i in range(len(cand)):
            if not (mask>>i)&1:
                nm=mask|(1<<i)
                nc=cost+ec[i]
                if nm not in best or best[nm]>nc:
                    best[nm]=nc
                    hq.heappush(pq,(nc,nm))
    return None,it
