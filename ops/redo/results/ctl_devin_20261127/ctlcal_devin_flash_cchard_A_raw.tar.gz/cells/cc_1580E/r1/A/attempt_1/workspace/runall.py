import solver, time, json
res_all=[]
for i in range(30):
    n,m,q,w,edges,qs,out=solver.load(i)
    dist=solver.dists(n,edges); dag=solver.dag_edges(n,edges,dist)
    t=time.time()
    base,it=solver.solve_exact(n,dag,w,dist)
    dt=time.time()-t
    print(i,'n',n,'q',q,'cost0',base[0] if base else None,'time %.1f'%dt,'iters',it,'exp',out.split()[0] if out else '?')
    res_all.append((i,base))
json.dump([[i,(b[0] if b else None, b[1] if b else None)] for i,b in res_all], open('base_results.json','w'))
