import json, heapq
from collections import defaultdict

def load(i):
    c=json.load(open('cases.json'))[i]
    tok=c['input'].split()
    it=iter(tok)
    n=int(next(it)); m=int(next(it)); q=int(next(it))
    w=[int(next(it)) for _ in range(n)]
    edges=[]
    for _ in range(m):
        u=int(next(it)); v=int(next(it)); d=int(next(it))
        edges.append((u,v,d))
    qs=[]
    for _ in range(q):
        qs.append((int(next(it)),int(next(it))))
    return n,m,q,w,edges,qs,c['output']

def dists(n,edges):
    adj=[[] for _ in range(n+1)]
    for u,v,d in edges:
        if 1<=u<=n and 1<=v<=n and u!=v:
            adj[u].append((v,d)); adj[v].append((u,d))
    INF=float('inf'); dist=[INF]*(n+1); dist[1]=0
    pq=[(0,1)]
    while pq:
        dd,u=heapq.heappop(pq)
        if dd>dist[u]: continue
        for v,d in adj[u]:
            nd=dd+d
            if nd<dist[v]: dist[v]=nd; heapq.heappush(pq,(nd,v))
    return dist

for i in [0,1,4]:
    n,m,q,w,edges,qs,out=load(i)
    dist=dists(n,edges)
    print('case',i,'n',n,'dist',dist[1:],'w',w,'out',out.split()[:3],'...')
    # DAG edges
    dag=defaultdict(list)
    for u,v,d in edges:
        if not(1<=u<=n and 1<=v<=n): continue
        if dist[v]==dist[u]+d: dag[u].append(v)
        if dist[u]==dist[v]+d: dag[v].append(u)
    for u in range(1,n+1):
        if dag[u]: print('  ',u,'->',dag[u])
