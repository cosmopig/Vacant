import solver, time, sys
i=int(sys.argv[1])
n,m,q,w,edges,qs,out=solver.load(i)
dist=solver.dists(n,edges); dag=solver.dag_edges(n,edges,dist)
t=time.time()
base,it=solver.solve_exact(n,dag,w,dist)
print('case',i,'n',n,'cost',base[0] if base else None,'time %.1f'%(time.time()-t),'iters',it,'added',base[1] if base else None)
