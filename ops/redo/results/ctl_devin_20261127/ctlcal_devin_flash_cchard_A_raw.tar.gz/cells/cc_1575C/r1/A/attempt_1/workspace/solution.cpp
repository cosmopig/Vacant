#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef complex<double> cd;
const ll MOD = 1000000007LL;
const double PI = acos(-1.0);

void fft(vector<cd>& a, bool invert) {
    int n = a.size();
    for (int i = 1, j = 0; i < n; i++) {
        int bit = n >> 1;
        for (; j & bit; bit >>= 1) j ^= bit;
        j ^= bit;
        if (i < j) swap(a[i], a[j]);
    }
    for (int len = 2; len <= n; len <<= 1) {
        double ang = 2 * PI / len * (invert ? -1 : 1);
        cd wlen(cos(ang), sin(ang));
        for (int i = 0; i < n; i += len) {
            cd w(1);
            for (int j = 0; j < len / 2; j++) {
                cd u = a[i + j], v = a[i + j + len / 2] * w;
                a[i + j] = u + v;
                a[i + j + len / 2] = u - v;
                w *= wlen;
            }
        }
    }
    if (invert) for (auto& x : a) x /= n;
}

vector<ll> multiply(const vector<ll>& f, const vector<ll>& r) {
    int need = f.size() + r.size() - 1;
    int n = 1;
    while (n < need) n <<= 1;
    vector<cd> fa(n), fb(n);
    for (size_t i = 0; i < f.size(); i++) fa[i] = cd((double)f[i], 0);
    for (size_t i = 0; i < r.size(); i++) fb[i] = cd((double)r[i], 0);
    fft(fa, false); fft(fb, false);
    for (int i = 0; i < n; i++) fa[i] *= fb[i];
    fft(fa, true);
    vector<ll> res(need);
    for (int i = 0; i < need; i++) res[i] = llround(fa[i].real());
    return res;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    ll n, m, k;
    if (!(cin >> n >> m >> k)) return 0;
    vector<ll> a(n);
    for (auto& x : a) cin >> x;

    // c[v] = prefix sum mod k of first v elements (v = 0..n-1 used as positions)
    vector<ll> c(n + 1, 0);
    vector<ll> cnt(k, 0);
    ll sigma = 0;
    for (ll i = 0; i < n; i++) {
        sigma += a[i];
        if (sigma >= k) sigma %= k; // keep small; do proper mod below anyway
        c[i + 1] = (c[i] + a[i]) % k;
    }
    sigma %= k;
    for (ll v = 0; v < n; v++) cnt[c[v]]++;

    // G(s) = sum_x cnt[x]*cnt[(x-s) mod k]
    // = E(s) + E(k-s) for s>=1, G(0)=E(0), where E(d)=sum_x cnt[x]*cnt[x+d].
    // E(d) = conv[k-1-d] of cnt with reversed cnt.
    vector<ll> f(k), r(k);
    for (ll i = 0; i < k; i++) { f[i] = cnt[i]; r[i] = cnt[k - 1 - i]; }
    vector<ll> conv = multiply(f, r); // size 2k-1, index p corresponds to d = k-1-p

    auto E = [&](ll d) -> ll { // d in [-(k-1), k-1]
        return conv[k - 1 - d];
    };
    auto G = [&](ll s) -> ll {
        if (s == 0) return E(0);
        return (E(s) + E(k - s)) % MOD;
    };

    // A0: unordered pairs v<vj with equal residue
    ll A0 = 0;
    for (ll x = 0; x < k; x++) {
        ll t = cnt[x];
        A0 = (A0 + t * (t - 1) / 2) % MOD;
    }

    ll sumA = A0;
    ll step = sigma % k;
    ll cur = 0;
    for (ll d = 1; d <= m - 1; d++) {
        cur = (cur + step) % k;
        sumA = (sumA + G(cur)) % MOD;
    }

    // Am: ordered pairs (v,vj) with vj<=v and c[v]-c[vj] == m*sigma (mod k)
    ll sm = (m % k) * sigma % k;
    vector<ll> seen(k, 0);
    ll Am = 0;
    for (ll v = 0; v < n; v++) {
        seen[c[v]]++;
        ll target = c[v] - sm;
        target %= k; if (target < 0) target += k;
        Am = (Am + seen[target]) % MOD;
    }
    sumA = (sumA + Am) % MOD;

    ll pairs = (m % MOD) * sumA % MOD;
    if (sm == 0) {
        ll T = (n % MOD) * (m % MOD) % MOD;
        pairs = (pairs - (T - 1) % MOD + MOD) % MOD;
    }
    cout << pairs << "\n";
    return 0;
}
