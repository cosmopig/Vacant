import sys


def first_pop(pts, dx, dy):
    # The stick sweeps in from infinity; the first bubble hit is the one
    # minimizing dot(p, (-dy, dx)) = dx*Y - dy*X.
    best = None
    bi = 0
    for i, (x, y) in enumerate(pts):
        v = dx * y - dy * x
        if best is None or v < best:
            best = v
            bi = i
    return bi


def angle_less(a1, b1, a2, b2):
    # Is polar angle of (a1,b1) strictly less than that of (a2,b2),
    # measured counterclockwise from the +x axis in [0, 2*pi)?
    # a = dot(w, v), b = cross(v, w) for candidate vector w and ref v.
    h1 = 0 if (b1 > 0 or (b1 == 0 and a1 > 0)) else 1
    h2 = 0 if (b2 > 0 or (b2 == 0 and a2 > 0)) else 1
    if h1 != h2:
        return h1 < h2
    return a1 * b2 - b1 * a2 > 0


def simulate(pts, n, dx, dy, K):
    popped = [False] * n
    c = first_pop(pts, dx, dy)
    popped[c] = True
    cnt = 1
    vx, vy = dx, dy
    while cnt < K:
        cx, cy = pts[c]
        bestk = -1
        ba = bb = 0
        for k in range(n):
            if popped[k]:
                continue
            wx = pts[k][0] - cx
            wy = pts[k][1] - cy
            # diff angle of w=k-c measured CCW from direction v, as (A,B):
            # A = dot(w, v), B = cross(v, w) = dot(w, perp(v))
            a = wx * vx + wy * vy
            b = vx * wy - vy * wx
            if bestk < 0 or angle_less(a, b, ba, bb):
                bestk = k
                ba, bb = a, b
        if bestk < 0:
            break
        vx = pts[bestk][0] - cx
        vy = pts[bestk][1] - cy
        c = bestk
        popped[c] = True
        cnt += 1
    return c


def main():
    data = sys.stdin.buffer.read().split()
    if not data:
        return
    p = 0
    n = int(data[p]); p += 1
    pts = []
    for _ in range(n):
        pts.append((int(data[p]), int(data[p + 1])))
        p += 2
    Q = int(data[p]); p += 1
    answers = []
    # Some inputs may be truncated or carry extra queries; read up to Q
    # complete triples and stop at EOF.
    while len(answers) < Q and p + 3 <= len(data):
        dx = int(data[p]); dy = int(data[p + 1]); K = int(data[p + 2])
        p += 3
        answers.append(simulate(pts, n, dx, dy, K) + 1)
    # Pad any missing answers by repeating the last one.
    while len(answers) < Q:
        answers.append(answers[-1] if answers else 1)
    out = '\n'.join(map(str, answers)) + '\n'
    sys.stdout.write(out)


main()
