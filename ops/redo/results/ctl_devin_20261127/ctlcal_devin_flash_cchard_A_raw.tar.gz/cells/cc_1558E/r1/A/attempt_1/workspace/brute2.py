import sys, itertools, random, json, subprocess

def min_power_order(order, a, b):
    need = 0
    for v in reversed(order):
        need = max(a[v] + 1, need - b[v])
    return need

def brute(n, adj, a, b):
    verts = list(range(2, n+1))
    best = None
    for perm in itertools.permutations(verts):
        seen = {1}
        ok = True
        for v in perm:
            if not any(u in seen for u in adj[v]):
                ok = False
                break
            seen.add(v)
        if not ok:
            continue
        val = min_power_order(list(perm), a, b)
        if best is None or val < best:
            best = val
    return best

def feasible(n, adj, a, b, P):
    seen = [False]*(n+1)
    seen[1] = True
    B = 0
    cnt = 1
    cand = set(adj[1])
    while cand:
        progress = False
        for v in list(cand):
            if P + B > a[v]:
                cand.discard(v)
                seen[v] = True
                cnt += 1
                B += b[v]
                for u in adj[v]:
                    if not seen[u]:
                        cand.add(u)
                progress = True
                break
        if not progress:
            return False
    return cnt == n

def solve(n, adj, a, b):
    lo, hi = 0, max(a.values()) + 2
    while not feasible(n, adj, a, b, hi):
        hi *= 2
    while lo < hi:
        mid = (lo + hi)//2
        if feasible(n, adj, a, b, mid):
            hi = mid
        else:
            lo = mid + 1
    return lo

def rand_graph(n, extra, mode):
    # returns adjacency dict, ensures connected & min degree>=2
    while True:
        edges = set()
        if mode == 0:
            # hamiltonian cycle + extras
            perm = list(range(1, n+1))
            random.shuffle(perm)
            for i in range(n):
                u, v = perm[i], perm[(i+1) % n]
                edges.add((min(u,v), max(u,v)))
        elif mode == 1:
            # random tree then add edges to fix leaves / min degree
            # random spanning tree via random parent
            for v in range(2, n+1):
                u = random.randint(1, v-1)
                edges.add((min(u,v), max(u,v)))
        # ensure min degree by adding random edges
        adj = {i:set() for i in range(1, n+1)}
        for u,v in edges:
            adj[u].add(v); adj[v].add(u)
        # connectivity: tree mode connected; cycle mode connected
        tries = 0
        target_extra = n + extra
        while tries < 3000:
            tries += 1
            degs = {i: len(adj[i]) for i in range(1,n+1)}
            # fix low-degree vertices first sometimes
            low = [i for i in range(1,n+1) if degs[i] < 2]
            if low and random.random() < 0.7:
                v = random.choice(low)
                u = random.randint(1,n)
                if u!=v:
                    e=(min(u,v),max(u,v))
                    if e not in edges:
                        edges.add(e); adj[u].add(v); adj[v].add(u)
                        continue
            if len(edges) >= target_extra and not low:
                break
            u = random.randint(1, n); v = random.randint(1, n)
            if u != v:
                e=(min(u,v),max(u,v))
                if e not in edges:
                    edges.add(e); adj[u].add(v); adj[v].add(u)
        if all(len(adj[i])>=2 for i in range(1,n+1)) and len(edges)<=2000:
            # check connected
            seen={1}; stack=[1]
            while stack:
                x=stack.pop()
                for y in adj[x]:
                    if y not in seen:
                        seen.add(y); stack.append(y)
            if len(seen)==n:
                return adj, edges
    return adj, edges

def main():
    random.seed(12345)
    mism = 0
    total = 0
    for t in range(1500):
        n = random.randint(3, 9)
        mode = random.randint(0,1)
        extra = random.randint(0, 6)
        adj, edges = rand_graph(n, extra, mode)
        amax = random.choice([10, 100, 10**9])
        bmax = random.choice([10, 100, 10**9])
        a = {i: random.randint(0, amax) for i in range(2, n+1)}; a[1]=0
        b = {i: random.randint(1, bmax) for i in range(2, n+1)}; b[1]=0
        best = brute(n, adj, a, b)
        s = solve(n, adj, a, b)
        total += 1
        if best != s:
            mism += 1
            if mism <= 5:
                print("MISMATCH n=%d mode=%d edges=%s" % (n, mode, sorted(edges)))
                print(" a=%s b=%s brute=%s solve=%s" % ({k:a[k] for k in range(2,n+1)}, {k:b[k] for k in range(2,n+1)}, best, s))
    print("done mismatches:", mism, "/", total)

main()
