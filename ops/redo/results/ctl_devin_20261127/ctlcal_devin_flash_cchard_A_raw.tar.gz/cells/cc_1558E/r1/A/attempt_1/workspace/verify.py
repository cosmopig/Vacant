import itertools, random, sys
from functools import lru_cache
sys.setrecursionlimit(1000000)

def solve_dp(n, adjl, a, b):
    adj = [set(s) for s in adjl]
    # Bmask[mask] = sum of b[v] for v in mask, v!=1
    N = 1 << n
    Bmask = [0]*N
    for mask in range(1, N):
        lsb = mask & (-mask)
        v = lsb.bit_length()  # vertex index (0-based for vertex v+1)
        Bmask[mask] = Bmask[mask ^ lsb] + (b[v] if v != 1 else 0)
    full = N - 1
    INF = float('inf')

    def roam(mask, x, p):
        # BFS over (cur,prev) within mask; vertices 0-based internally? use 1-based labels
        seen = {(x, p)}
        stack = [(x, p)]
        res = []
        while stack:
            cur, prev = stack.pop()
            res.append((cur, prev))
            for y in adj[cur]:
                if (mask >> (y-1)) & 1 and y != prev and (y, cur) not in seen:
                    seen.add((y, cur))
                    stack.append((y, cur))
        return res

    @lru_cache(maxsize=None)
    def g(x, p, mask):
        if mask == full:
            return -10**30
        best = INF
        B = Bmask[mask]
        for (y, q) in roam(mask, x, p):
            for z in adj[y]:
                if not ((mask >> (z-1)) & 1) and z != q:
                    c = a[z] - B
                    val = g(z, y, mask | (1 << (z-1)))
                    if val == INF:
                        continue
                    m = c if c > val else val
                    if m < best:
                        best = m
        return best

    ans = INF
    for w in adj[1]:
        mask = (1 << 0) | (1 << (w-1))
        c = a[w]
        val = g(w, 1, mask)
        if val == INF:
            continue
        m = c if c > val else val
        if m < ans:
            ans = m
    return ans + 1

# ---- brute force over all walks (DFS with memo on state, tracking max cost) ----
def brute(n, adjl, a, b):
    adj = [set(s) for s in adjl]
    full = (1 << n) - 1
    from functools import lru_cache
    Bmask = [0]*(1<<n)
    for mask in range(1, 1<<n):
        lsb = mask & (-mask); v = lsb.bit_length()
        Bmask[mask] = Bmask[mask ^ lsb] + (b[v] if v != 1 else 0)
    INF = float('inf')
    @lru_cache(maxsize=None)
    def g(x, p, mask):
        if mask == full:
            return -10**30
        best = INF
        B = Bmask[mask]
        for y in adj[x]:
            if y == p:
                continue
            if (mask >> (y-1)) & 1:
                # roam move: but must consider that hero may roam arbitrarily;
                # roaming is just moving within mask; g should be min over roam paths.
                # Instead of explicit roam BFS, note roaming = sequence of in-mask moves.
                # g(x,p,mask) via roam = min over reachable (y,q) then discover.
                # We handle roam by iterating in-mask moves recursively? That would loop.
                pass
        # do roam BFS inline
        seen = {(x,p)}; stack=[(x,p)]; res=[]
        while stack:
            cur,prev = stack.pop(); res.append((cur,prev))
            for y in adj[cur]:
                if (mask>>(y-1))&1 and y!=prev and (y,cur) not in seen:
                    seen.add((y,cur)); stack.append((y,cur))
        for (y,q) in res:
            for z in adj[y]:
                if not ((mask>>(z-1))&1) and z!=q:
                    c = a[z]-B
                    val = g(z,y,mask|(1<<(z-1)))
                    if val==INF: continue
                    m = max(c,val)
                    best = min(best,m)
        return best
    ans=INF
    for w in adj[1]:
        mask=(1<<0)|(1<<(w-1))
        val=g(w,1,mask)
        if val==INF: continue
        ans=min(ans, max(a[w],val))
    return ans+1

def brute_orders(n, adjl, a, b):
    # enumerate all non-backtracking walks via DP on (x,p,mask) computing set of achievable
    # discovery-cost-max? Simpler: reuse solve_dp which IS the dp. Instead verify vs
    # explicit walk enumeration for tiny n.
    adj=[set(s) for s in adjl]
    full=(1<<n)-1
    Bmask=[0]*(1<<n)
    for mask in range(1,1<<n):
        lsb=mask&(-mask); v=lsb.bit_length()
        Bmask[mask]=Bmask[mask^lsb]+(b[v] if v!=1 else 0)
    INF=float('inf')
    import sys
    sys.setrecursionlimit(100000)
    memo={}
    def dfs(x,p,mask,maxcost):
        # returns min over completions of max(maxcost, future costs); we want global min of final max
        if mask==full:
            return maxcost
        key=(x,p,mask)
        # can't memo with maxcost param easily; do full recursion returning min achievable final max
        return None
    # do DP: h(x,p,mask) = min over completions of max future discovery cost (excluding past)
    from functools import lru_cache
    @lru_cache(maxsize=None)
    def h(x,p,mask):
        if mask==full: return -10**30
        best=INF; B=Bmask[mask]
        # roam BFS
        seen={(x,p)}; stack=[(x,p)]; res=[]
        while stack:
            cur,prev=stack.pop(); res.append((cur,prev))
            for y in adj[cur]:
                if (mask>>(y-1))&1 and y!=prev and (y,cur) not in seen:
                    seen.add((y,cur)); stack.append((y,cur))
        for (y,q) in res:
            for z in adj[y]:
                if not ((mask>>(z-1))&1) and z!=q:
                    val=h(z,y,mask|(1<<(z-1)))
                    if val==INF: continue
                    m=max(a[z]-B,val)
                    best=min(best,m)
        return best
    ans=INF
    for w in adj[1]:
        mask=(1<<0)|(1<<(w-1))
        val=h(w,1,mask)
        if val==INF: continue
        ans=min(ans,max(a[w],val))
    return ans+1

def rand_graph(n, extra):
    while True:
        edges=set()
        perm=list(range(1,n+1)); random.shuffle(perm)
        for i in range(n):
            u,v=perm[i],perm[(i+1)%n]; edges.add((min(u,v),max(u,v)))
        tries=0
        while len(edges)<n+extra and tries<500:
            tries+=1
            u=random.randint(1,n); v=random.randint(1,n)
            if u!=v: edges.add((min(u,v),max(u,v)))
        adj=[set() for _ in range(n+1)]
        for u,v in edges: adj[u].add(v); adj[v].add(u)
        if all(len(adj[i])>=2 for i in range(1,n+1)): return adj

def main():
    random.seed(7)
    mism=0
    for t in range(300):
        n=random.randint(3,8)
        adj=rand_graph(n,random.randint(0,4))
        a=[0]+[random.randint(0,30) for _ in range(n)]
        b=[0]+[random.randint(0,30) for _ in range(n)]
        a[1]=0; b[1]=0
        s1=solve_dp(n,adj,a,b)
        s2=brute_orders(n,adj,a,b)
        if s1!=s2:
            mism+=1
            if mism<=5:
                print("MISMATCH n=%d s1=%s s2=%s"%(n,s1,s2))
                print(" edges=%s"%sorted((min(u,v),max(u,v)) for u in range(1,n+1) for v in adj[u] if u<v))
                print(" a=%s b=%s"%(a[1:],b[1:]))
    print("done",mism,"/300")

main()
