import sys, itertools, random

def min_power_order(order, a, b):
    need = 0
    for v in reversed(order):
        need = max(a[v] + 1, need - b[v])
    return need

def brute(n, adj, a, b):
    verts = list(range(2, n+1))
    best = None
    for perm in itertools.permutations(verts):
        seen = {1}
        ok = True
        for v in perm:
            if not any(u in seen for u in adj[v]):
                ok = False
                break
            seen.add(v)
        if not ok:
            continue
        val = min_power_order(list(perm), a, b)
        if best is None or val < best:
            best = val
    return best

def feasible(n, adj, a, b, P):
    # returns True if all caves can be first-visited with start power P
    seen = [False]*(n+1)
    seen[1] = True
    B = 0
    cnt = 1
    # simple loop: scan for addable vertex
    # use stack/queue approach: maintain candidate set
    import collections
    cand = set(adj[1])
    while cand:
        # find any v in cand with P + B > a[v]
        # since B only grows, rescan
        progress = False
        # pick any qualifying
        for v in list(cand):
            if P + B > a[v]:
                cand.discard(v)
                seen[v] = True
                cnt += 1
                B += b[v]
                for u in adj[v]:
                    if not seen[u]:
                        cand.add(u)
                progress = True
                break
        if not progress:
            # check if any remaining cand qualifies now? B unchanged, so no.
            return False
    return cnt == n

def solve(n, adj, a, b):
    lo, hi = 1, max(a.values()) + 2
    # ensure hi feasible
    while not feasible(n, adj, a, b, hi):
        hi *= 2
    while lo < hi:
        mid = (lo + hi)//2
        if feasible(n, adj, a, b, mid):
            hi = mid
        else:
            lo = mid + 1
    return lo

def rand_graph(n, extra=0):
    while True:
        edges = set()
        perm = list(range(1, n+1))
        random.shuffle(perm)
        for i in range(n):
            u, v = perm[i], perm[(i+1) % n]
            edges.add((min(u,v), max(u,v)))
        tries = 0
        target = n + extra
        while len(edges) < target and tries < 1000:
            tries += 1
            u = random.randint(1, n); v = random.randint(1, n)
            if u != v:
                edges.add((min(u,v), max(u,v)))
        adj = {i:set() for i in range(1, n+1)}
        for u,v in edges:
            adj[u].add(v); adj[v].add(u)
        if all(len(adj[i])>=2 for i in range(1,n+1)):
            return adj, edges

def main():
    random.seed(1)
    mism = 0
    for t in range(500):
        n = random.randint(3, 8)
        adj, edges = rand_graph(n, random.randint(0,4))
        a = {i: random.randint(0, 40) for i in range(2, n+1)}; a[1]=0
        b = {i: random.randint(1, 40) for i in range(2, n+1)}; b[1]=0
        best = brute(n, adj, a, b)
        s = solve(n, adj, a, b)
        if best != s:
            mism += 1
            if mism <= 5:
                print("MISMATCH n=%d edges=%s" % (n, sorted(edges)))
                print(" a=%s b=%s brute=%s solve=%s" % ({k:a[k] for k in range(2,n+1)}, {k:b[k] for k in range(2,n+1)}, best, s))
    print("done mismatches:", mism, "/500")

main()
