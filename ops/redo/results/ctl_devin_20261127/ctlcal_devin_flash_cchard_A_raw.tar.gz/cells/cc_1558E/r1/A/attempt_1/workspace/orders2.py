import itertools, random, sys
sys.setrecursionlimit(100000)

def achievable_orders(n, adj):
    from functools import lru_cache
    FULL = frozenset(range(1, n+1))
    @lru_cache(maxsize=None)
    def F(cur, prev, vis):
        # returns frozenset of tuples: achievable sequences of newly discovered vertices
        if len(vis) == n:
            return frozenset([()])
        res = set()
        for w in adj[cur]:
            if w == prev:
                continue
            if w in vis:
                for r in F(w, cur, vis):
                    res.add(r)
            else:
                for r in F(w, cur, vis | {w}):
                    res.add((w,) + r)
        return frozenset(res)
    out = set()
    for w in adj[1]:
        for r in F(w, 1, frozenset([1, w])):
            out.add((w,) + r)
    return out

def connected_orders(n, adj):
    res = set()
    verts = list(range(2, n+1))
    for perm in itertools.permutations(verts):
        seen = {1}
        ok = True
        for v in perm:
            if not any(u in seen for u in adj[v]):
                ok = False
                break
            seen.add(v)
        if ok:
            res.add(perm)
    return res

def rand_graph(n, extra):
    while True:
        edges = set()
        perm = list(range(1, n+1))
        random.shuffle(perm)
        for i in range(n):
            u, v = perm[i], perm[(i+1) % n]
            edges.add((min(u,v), max(u,v)))
        tries = 0
        while len(edges) < n + extra and tries < 500:
            tries += 1
            u = random.randint(1, n); v = random.randint(1, n)
            if u != v:
                edges.add((min(u,v), max(u,v)))
        adj = {i:set() for i in range(1, n+1)}
        for u,v in edges:
            adj[u].add(v); adj[v].add(u)
        if all(len(adj[i])>=2 for i in range(1,n+1)):
            return adj

random.seed(0)
diffs = 0
for t in range(40):
    n = random.randint(3, 8)
    adj = rand_graph(n, random.randint(0,3))
    ao = achievable_orders(n, adj)
    co = connected_orders(n, adj)
    if ao != co:
        diffs += 1
        print("n=%d edges=%s |ao|=%d |co|=%d" % (n, sorted((min(u,v),max(u,v)) for u in adj for v in adj[u] if u<v), len(ao), len(co)))
        print("   connected-only:", sorted(co - ao)[:4])
print("diffs:", diffs, "/40")
