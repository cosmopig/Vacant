import itertools, random, sys
from functools import lru_cache
sys.setrecursionlimit(1000000)

def achievable_orders(n, adjl):
    adj = {i: set(adjl[i]) for i in range(1, n+1)}
    FULL = n

    def roam(S, x, p):
        # BFS over (cur,prev) moving only within S (visited), cur!=prev constraint
        seen = {(x, p)}
        stack = [(x, p)]
        res = []
        while stack:
            cur, prev = stack.pop()
            res.append((cur, prev))
            for y in adj[cur]:
                if y in S and y != prev and (y, cur) not in seen:
                    seen.add((y, cur))
                    stack.append((y, cur))
        return res

    @lru_cache(maxsize=None)
    def F(x, p, vis):
        # vis: frozenset visited; returns frozenset of tuples of future discoveries
        if len(vis) == n:
            return frozenset([()])
        res = set()
        for (y, q) in roam(vis, x, p):
            for z in adj[y]:
                if z not in vis and z != q:
                    for r in F(z, y, vis | {z}):
                        res.add((z,) + r)
        return frozenset(res)

    out = set()
    for w in adj[1]:
        for r in F(w, 1, frozenset([1, w])):
            out.add((w,) + r)
    return out

def connected_orders(n, adj):
    res = set()
    verts = list(range(2, n+1))
    for perm in itertools.permutations(verts):
        seen = {1}
        ok = True
        for v in perm:
            if not any(u in seen for u in adj[v]):
                ok = False
                break
            seen.add(v)
        if ok:
            res.add(perm)
    return res

def rand_graph(n, extra):
    while True:
        edges = set()
        perm = list(range(1, n+1))
        random.shuffle(perm)
        for i in range(n):
            u, v = perm[i], perm[(i+1) % n]
            edges.add((min(u,v), max(u,v)))
        tries = 0
        while len(edges) < n + extra and tries < 500:
            tries += 1
            u = random.randint(1, n); v = random.randint(1, n)
            if u != v:
                edges.add((min(u,v), max(u,v)))
        adj = {i:set() for i in range(1, n+1)}
        for u,v in edges:
            adj[u].add(v); adj[v].add(u)
        if all(len(adj[i])>=2 for i in range(1,n+1)):
            return adj

random.seed(0)
diffs = 0
for t in range(60):
    n = random.randint(3, 8)
    adj = rand_graph(n, random.randint(0,3))
    ao = achievable_orders(n, adj)
    co = connected_orders(n, adj)
    if ao != co:
        diffs += 1
        print("n=%d edges=%s |ao|=%d |co|=%d" % (n, sorted((min(u,v),max(u,v)) for u in adj for v in adj[u] if u<v), len(ao), len(co)))
        print("   connected-only:", sorted(co - ao)[:4])
print("diffs:", diffs, "/60")
