import sys
import heapq


def feasible(n, adj, a, b, P):
    # Can all caves be first-visited starting with power P?
    # Closure: S={1}, B=sum of b over visited monsters.
    # Repeatedly add any frontier vertex v with P + B > a[v].
    seen = bytearray(n + 1)
    seen[1] = 1
    B = 0
    cnt = 1
    incand = bytearray(n + 1)
    heap = []
    for v in adj[1]:
        if not incand[v]:
            incand[v] = 1
            heapq.heappush(heap, (a[v], v))
    while heap:
        av, v = heapq.heappop(heap)
        if seen[v]:
            continue
        if P + B <= av:
            # min-a frontier vertex doesn't qualify -> stuck
            return False
        # qualifies: visit it
        seen[v] = 1
        cnt += 1
        B += b[v]
        for u in adj[v]:
            if not seen[u] and not incand[u]:
                incand[u] = 1
                heapq.heappush(heap, (a[u], u))
    return cnt == n


def solve_case(n, m, a, b, edges):
    adj = [[] for _ in range(n + 1)]
    for u, v in edges:
        adj[u].append(v)
        adj[v].append(u)

    lo = 0
    hi = max(a[2:]) + 2
    while not feasible(n, adj, a, b, hi):
        hi *= 2
    while lo < hi:
        mid = (lo + hi) // 2
        if feasible(n, adj, a, b, mid):
            hi = mid
        else:
            lo = mid + 1
    return lo


def main():
    data = sys.stdin.buffer.read().split()
    it = iter(data)
    t = int(next(it))
    out = []
    for _ in range(t):
        n = int(next(it)); m = int(next(it))
        a = [0] * (n + 1)
        b = [0] * (n + 1)
        for i in range(2, n + 1):
            a[i] = int(next(it))
        for i in range(2, n + 1):
            b[i] = int(next(it))
        edges = []
        for _ in range(m):
            u = int(next(it)); v = int(next(it))
            edges.append((u, v))
        out.append(str(solve_case(n, m, a, b, edges)))
    sys.stdout.write("\n".join(out) + "\n")


main()
