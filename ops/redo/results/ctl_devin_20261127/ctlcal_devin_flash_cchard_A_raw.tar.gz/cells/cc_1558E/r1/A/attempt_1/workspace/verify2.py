import itertools, random, sys
from functools import lru_cache
sys.setrecursionlimit(1000000)

def achievable_orders(n, adj):
    adj = {i: set(adj[i]) for i in range(1, n+1)}
    def roam(S, x, p):
        seen = {(x, p)}
        stack = [(x, p)]
        res = []
        while stack:
            cur, prev = stack.pop()
            res.append((cur, prev))
            for y in adj[cur]:
                if y in S and y != prev and (y, cur) not in seen:
                    seen.add((y, cur))
                    stack.append((y, cur))
        return res
    @lru_cache(maxsize=None)
    def F(x, p, vis):
        if len(vis) == n:
            return frozenset([()])
        res = set()
        for (y, q) in roam(vis, x, p):
            for z in adj[y]:
                if z not in vis and z != q:
                    for r in F(z, y, vis | {z}):
                        res.add((z,) + r)
        return frozenset(res)
    out = set()
    for w in adj[1]:
        for r in F(w, 1, frozenset([1, w])):
            out.add((w,) + r)
    return out

def min_power_order(order, a, b):
    need = 0
    for v in reversed(order):
        need = max(a[v] + 1, need - b[v])
    return need

def brute(n, adj, a, b):
    best = None
    for order in achievable_orders(n, adj):
        val = min_power_order(list(order), a, b)
        if best is None or val < best:
            best = val
    return best

def solve_dp(n, adjl, a, b):
    adj = [set(s) for s in adjl]
    N = 1 << n
    Bmask = [0]*N
    for mask in range(1, N):
        lsb = mask & (-mask)
        v = lsb.bit_length()
        Bmask[mask] = Bmask[mask ^ lsb] + (b[v] if v != 1 else 0)
    full = N - 1
    INF = float('inf')
    memo = {}
    def g(x, p, mask):
        if mask == full:
            return -10**30
        key = (x, p, mask)
        if key in memo:
            return memo[key]
        best = INF
        B = Bmask[mask]
        seen = {(x, p)}
        stack = [(x, p)]
        res = []
        while stack:
            cur, prev = stack.pop()
            res.append((cur, prev))
            for y in adj[cur]:
                if (mask >> (y-1)) & 1 and y != prev and (y, cur) not in seen:
                    seen.add((y, cur))
                    stack.append((y, cur))
        for (y, q) in res:
            for z in adj[y]:
                if not ((mask >> (z-1)) & 1) and z != q:
                    c = a[z] - B
                    val = g(z, y, mask | (1 << (z-1)))
                    if val == INF:
                        continue
                    m = c if c > val else val
                    if m < best:
                        best = m
        memo[key] = best
        return best
    ans = INF
    for w in adj[1]:
        mask = (1 << 0) | (1 << (w-1))
        val = g(w, 1, mask)
        if val == INF:
            continue
        m = a[w] if a[w] > val else val
        if m < ans:
            ans = m
    return ans + 1

def rand_graph(n, extra):
    while True:
        edges = set()
        perm = list(range(1, n+1))
        random.shuffle(perm)
        for i in range(n):
            u, v = perm[i], perm[(i+1) % n]
            edges.add((min(u,v), max(u,v)))
        tries = 0
        while len(edges) < n + extra and tries < 500:
            tries += 1
            u = random.randint(1, n); v = random.randint(1, n)
            if u != v:
                edges.add((min(u,v), max(u,v)))
        adj = [set() for _ in range(n+1)]
        for u,v in edges:
            adj[u].add(v); adj[v].add(u)
        if all(len(adj[i])>=2 for i in range(1,n+1)):
            return adj

def main():
    random.seed(7)
    mism = 0
    for t in range(300):
        n = random.randint(3, 8)
        adj = rand_graph(n, random.randint(0, 4))
        a = [0]*(n+1); b = [0]*(n+1)
        for i in range(2, n+1):
            a[i] = random.randint(0, 30)
            b[i] = random.randint(0, 30)
        s1 = solve_dp(n, adj, a, b)
        s2 = brute(n, adj, a, b)
        if s1 != s2:
            mism += 1
            if mism <= 5:
                print("MISMATCH n=%d dp=%s brute=%s" % (n, s1, s2))
                print(" edges=%s" % sorted((min(u,v),max(u,v)) for u in range(1,n+1) for v in adj[u] if u<v))
                print(" a=%s b=%s" % (a[1:], b[1:]))
    print("done", mism, "/300")

main()
