import itertools, random
from collections import deque

def discovery_orders(n, adj):
    # BFS over (cur, prev, visited_frozenset); record orders of first visits to 2..n
    # state: (cur, prev) where prev is previous vertex (0 for start)
    start = (1, 0)
    # visited includes 1
    q = deque()
    q.append((1, 0, frozenset([1]), ()))
    orders = set()
    seen_states = set()
    while q:
        cur, prev, vis, order = q.popleft()
        if len(vis) == n:
            orders.add(order)
            continue
        key = (cur, prev, vis)
        # don't dedupe on vis fully? different orders with same vis matter for output only;
        # but future possibilities depend only on (cur,prev,vis) -> dedupe ok for reachability
        if key in seen_states:
            continue
        seen_states.add(key)
        for w in adj[cur]:
            if w == prev:
                continue  # cannot use same tunnel twice in a row
            if w in vis:
                q.append((w, cur, vis, order))
            else:
                q.append((w, cur, vis | {w}, order + (w,)))
    return orders

def connected_orders(n, adj):
    res = []
    verts = list(range(2, n+1))
    for perm in itertools.permutations(verts):
        seen = {1}
        ok = True
        for v in perm:
            if not any(u in seen for u in adj[v]):
                ok = False
                break
            seen.add(v)
        if ok:
            res.append(perm)
    return set(res)

def rand_graph(n, extra):
    while True:
        edges = set()
        perm = list(range(1, n+1))
        random.shuffle(perm)
        for i in range(n):
            u, v = perm[i], perm[(i+1) % n]
            edges.add((min(u,v), max(u,v)))
        tries = 0
        while len(edges) < n + extra and tries < 500:
            tries += 1
            u = random.randint(1, n); v = random.randint(1, n)
            if u != v:
                edges.add((min(u,v), max(u,v)))
        adj = {i:set() for i in range(1, n+1)}
        for u,v in edges:
            adj[u].add(v); adj[v].add(u)
        if all(len(adj[i])>=2 for i in range(1,n+1)):
            return adj

random.seed(0)
diffs = 0
for t in range(30):
    n = random.randint(3, 7)
    adj = rand_graph(n, random.randint(0,3))
    do = discovery_orders(n, adj)
    co = connected_orders(n, adj)
    if do != co:
        diffs += 1
        print("n=%d edges=%s" % (n, sorted((min(u,v),max(u,v)) for u in adj for v in adj[u] if u<v)))
        print("  discovery-only:", sorted(do - co)[:5])
        print("  connected-only:", sorted(co - do)[:5])
        print("  |do|=%d |co|=%d" % (len(do), len(co)))
print("diffs:", diffs, "/30")
