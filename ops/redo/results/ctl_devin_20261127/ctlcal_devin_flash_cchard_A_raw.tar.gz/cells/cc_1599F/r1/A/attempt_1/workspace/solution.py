import sys

MOD = 1000000007


def main() -> None:
    data = sys.stdin.buffer.read().split()
    if not data:
        return

    pos = 0
    n = int(data[pos])
    pos += 1
    q = int(data[pos])
    pos += 1

    a = [0] * n
    for i in range(n):
        a[i] = int(data[pos]) % MOD
        pos += 1

    out = []
    append = out.append

    for _ in range(q):
        l = int(data[pos])
        r = int(data[pos + 1])
        d = int(data[pos + 2]) % MOD
        pos += 3

        if l > r or r < 1 or l > n:
            append("No")
            continue
        if l < 1:
            l = 1
        if r > n:
            r = n
        if l > r:
            append("No")
            continue

        values = set(a[l - 1:r])
        m = len(values)
        if m <= 1:
            append("Yes")
            continue
        if d == 0:
            append("No")
            continue

        edges = 0
        for x in values:
            y = x + d
            if y >= MOD:
                y -= MOD
            if y in values:
                edges += 1

        append("Yes" if edges == m - 1 else "No")

    sys.stdout.write("\n".join(out))
    if out:
        sys.stdout.write("\n")


if __name__ == "__main__":
    main()
