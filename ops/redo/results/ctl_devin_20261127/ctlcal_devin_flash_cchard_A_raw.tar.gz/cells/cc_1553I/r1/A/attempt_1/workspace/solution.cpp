#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MOD = 998244353;

int n, k;
vector<int> a, sz;
vector<int> Lv, Rv, ov;
vector<char> placed;
ll ans = 0;

void dfs(int t, int cum) {
    if (t == k) { ans = (ans + 1) % MOD; return; }
    for (int b = 0; b < k; b++) if (!placed[b]) {
        int dom = (sz[b] == 1) ? 1 : 3; // singleton: orientation irrelevant
        for (int ob = 0; ob < 2; ob++) if (dom >> ob & 1) {
            int Lb = cum + 1, Rb = cum + sz[b];
            bool ok = true;
            if (b > 0 && placed[b - 1]) {
                // pair (b-1, b): u = right end of b-1, v = left end of b
                int u = (ov[b - 1] == 0 ? Rv[b - 1] : Lv[b - 1]);
                int v = (ob == 0 ? Lb : Rb);
                if (abs(u - v) == 1) ok = false;
            }
            if (ok && b + 1 < k && placed[b + 1]) {
                // pair (b, b+1): u = right end of b, v = left end of b+1
                int u = (ob == 0 ? Rb : Lb);
                int v = (ov[b + 1] == 0 ? Lv[b + 1] : Rv[b + 1]);
                if (abs(u - v) == 1) ok = false;
            }
            if (!ok) continue;
            Lv[b] = Lb; Rv[b] = Rb; ov[b] = ob; placed[b] = 1;
            dfs(t + 1, cum + sz[b]);
            placed[b] = 0;
        }
    }
}

int main() {
    if (scanf("%d", &n) != 1) return 0;
    a.resize(n + 1);
    for (int i = 1; i <= n; i++) scanf("%d", &a[i]);

    // greedy unique block partition: block starting at i has length a[i]
    sz.clear();
    int i = 1;
    while (i <= n) {
        int L = a[i];
        if (L < 1 || i + L - 1 > n) { printf("0\n"); return 0; }
        for (int j = i; j < i + L; j++)
            if (a[j] != L) { printf("0\n"); return 0; }
        sz.push_back(L);
        i += L;
    }
    k = sz.size();

    // Special case: all blocks singletons (a_i = 1). Count permutations of
    // [n] with no two consecutive values adjacent, via inclusion-exclusion
    // over the n-1 bonds (i, i+1).
    if (k == n) {
        // dp[m][p]: processed some bonds, m included, p = last bond included
        // weight: (-1)^m * 2^(number of runs of included bonds)
        vector<array<ll,2>> dp(n, {0,0}), ndp(n, {0,0});
        dp[0][0] = 1;
        for (int i = 0; i < n - 1; i++) {
            for (auto &x : ndp) x = {0,0};
            for (int m = 0; m <= i; m++) {
                // skip bond i+1
                ndp[m][0] = (ndp[m][0] + dp[m][0] + dp[m][1]) % MOD;
                // take bond: new run if previous not taken (-2), else -1
                ndp[m+1][1] = (ndp[m+1][1] + dp[m][0] * (MOD - 2) + dp[m][1] * (MOD - 1)) % MOD;
            }
            dp = ndp;
        }
        vector<ll> fact(n + 1, 1);
        for (int i = 1; i <= n; i++) fact[i] = fact[i-1] * i % MOD;
        ll res = 0;
        for (int m = 0; m <= n - 1; m++)
            res = (res + (dp[m][0] + dp[m][1]) % MOD * fact[n - m]) % MOD;
        printf("%lld\n", res);
        return 0;
    }

    Lv.assign(k, 0); Rv.assign(k, 0); ov.assign(k, 0);
    placed.assign(k, 0);
    dfs(0, 0);
    printf("%lld\n", ans % MOD);
    return 0;
}
