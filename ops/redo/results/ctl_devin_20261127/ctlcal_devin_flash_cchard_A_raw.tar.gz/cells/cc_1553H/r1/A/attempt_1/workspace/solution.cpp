#include <bits/stdc++.h>
using namespace std;

const int INF = 1 << 29;

struct Res {
    vector<int> F, mn, mx;
};

// S: distinct values in [0, 2^p). For each y in [0, 2^p):
//   F[y] = min over pairs |(s1^y)-(s2^y)|   (INF if |S|<2)
//   mn[y] = min(s^y), mx[y] = max(s^y)
Res solve(const vector<int>& e, int p) {
    int sz = 1 << p;
    Res r;
    r.F.assign(sz, INF);
    r.mn.assign(sz, INF);
    r.mx.assign(sz, -INF);
    if (e.empty()) return r;
    if (e.size() == 1) {
        int v = e[0];
        for (int i = 0; i < sz; i++) r.mn[i] = r.mx[i] = v ^ i;
        return r;
    }
    int half = 1 << (p - 1);
    vector<int> e0, e1;
    e0.reserve(e.size()); e1.reserve(e.size());
    for (int v : e) {
        if (v & half) e1.push_back(v & (half - 1));
        else e0.push_back(v);
    }
    Res r0 = solve(e0, p - 1);
    Res r1 = solve(e1, p - 1);
    for (int z = 0; z < half; z++) {
        int f0 = r0.F[z], f1 = r1.F[z];
        int m0 = r0.mn[z], M0 = r0.mx[z];
        int m1 = r1.mn[z], M1 = r1.mx[z];
        // y = z        (top bit of y is 0): bit-(p-1) of results is 0 for e0, 1 for e1
        r.F[z]      = min({f0, f1, half + m1 - M0});
        r.mn[z]     = min(m0, half + m1);
        r.mx[z]     = max(M0, half + M1);
        // y = half+z  (top bit of y is 1): bit-(p-1) of results is 1 for e0, 0 for e1
        r.F[half+z] = min({f0, f1, half + m0 - M1});
        r.mn[half+z] = min(half + m0, m1);
        r.mx[half+z] = max(half + M0, M1);
    }
    return r;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n, k;
    if (!(cin >> n >> k)) return 0;
    vector<int> a(n);
    for (auto& v : a) cin >> v;
    Res r = solve(a, k);
    for (int i = 0; i < (1 << k); i++) {
        if (i) cout << ' ';
        cout << r.F[i];
    }
    cout << '\n';
    return 0;
}
