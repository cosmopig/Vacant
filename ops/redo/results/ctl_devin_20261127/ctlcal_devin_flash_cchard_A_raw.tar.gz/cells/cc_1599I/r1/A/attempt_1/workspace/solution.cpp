#include <bits/stdc++.h>
using namespace std;

int N, M, V;
vector<pair<int,int>> E;

// Check whether edges E[L..R] (0-indexed, inclusive) form a desert:
// every biconnected component is a bridge or a simple cycle.
bool isDesert(int L, int R) {
    int k = R - L + 1;
    vector<vector<pair<int,int>>> adj(V + 1);
    vector<pair<int,int>> ed(k);
    for (int i = 0; i < k; i++) {
        ed[i] = E[L + i];
        adj[ed[i].first].push_back({ed[i].second, i});
        adj[ed[i].second].push_back({ed[i].first, i});
    }

    vector<int> disc(V + 1, 0), low(V + 1, 0), pe(V + 1, -1);
    vector<char> vis(V + 1, 0);
    int timer = 0;
    vector<array<int,3>> stk;          // edge stack: (u, v, eid)
    vector<pair<int,int>> call;        // DFS stack: (vertex, next adjacency index)

    for (int s = 0; s <= V; s++) {
        if (vis[s] || adj[s].empty()) continue;
        vis[s] = 1; disc[s] = low[s] = ++timer;
        call.push_back({s, 0});
        while (!call.empty()) {
            int u = call.back().first;
            int &i = call.back().second;
            if (i < (int)adj[u].size()) {
                auto [v, eid] = adj[u][i++];
                if (eid == pe[u]) continue;
                if (!vis[v]) {
                    vis[v] = 1; disc[v] = low[v] = ++timer; pe[v] = eid;
                    stk.push_back({u, v, eid});
                    call.push_back({v, 0});
                } else if (disc[v] < disc[u]) {
                    stk.push_back({u, v, eid});
                    low[u] = min(low[u], disc[v]);
                }
            } else {
                call.pop_back();
                if (!call.empty()) {
                    int p = call.back().first;
                    low[p] = min(low[p], low[u]);
                    if (low[u] >= disc[p]) {
                        int te = pe[u];
                        vector<int> comp;
                        while (true) {
                            auto e = stk.back(); stk.pop_back();
                            comp.push_back(e[2]);
                            if (e[2] == te) break;
                        }
                        if (comp.size() > 1) {
                            // must be a simple cycle: #edges == #vertices, all degrees 2
                            unordered_map<int,int> dg;
                            dg.reserve(comp.size() * 2);
                            for (int id : comp) {
                                dg[ed[id].first]++;
                                dg[ed[id].second]++;
                            }
                            if ((int)dg.size() != (int)comp.size()) return false;
                            for (auto &kv : dg)
                                if (kv.second != 2) return false;
                        }
                    }
                }
            }
        }
    }
    return true;
}

int main() {
    if (scanf("%d %d", &N, &M) != 2) return 0;
    E.resize(M);
    V = N;
    for (int i = 0; i < M; i++) {
        int u, v;
        if (scanf("%d %d", &u, &v) != 2) return 0;
        E[i] = {u, v};
        V = max(V, max(u, v));
    }

    long long ans = 0;
    for (int L = 0; L < M; L++) {
        for (int R = L; R < M; R++) {
            if (isDesert(L, R)) ans++;
            else break; // adding more edges cannot restore the desert property
        }
    }
    printf("%lld\n", ans);
    return 0;
}
