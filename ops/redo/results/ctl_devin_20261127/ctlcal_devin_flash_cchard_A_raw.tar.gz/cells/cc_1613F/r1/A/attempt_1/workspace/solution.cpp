#include <bits/stdc++.h>
using namespace std;

const int MOD = 998244353;
const int G = 3;

int pw(int a, long long e) {
    long long r = 1, b = a;
    while (e) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return (int)r;
}

const int MAXN = 1 << 19;
int rt[MAXN + 1];

void ntt(vector<int>& a, bool invert) {
    int n = (int)a.size();
    for (int i = 1, j = 0; i < n; i++) {
        int bit = n >> 1;
        for (; j & bit; bit >>= 1) j ^= bit;
        j ^= bit;
        if (i < j) swap(a[i], a[j]);
    }
    for (int len = 2; len <= n; len <<= 1) {
        int wlen = rt[len];
        if (invert) wlen = pw(wlen, MOD - 2);
        for (int i = 0; i < n; i += len) {
            long long w = 1;
            int half = len >> 1;
            for (int j = 0; j < half; j++) {
                long long u = a[i + j];
                long long v = (long long)a[i + j + half] * w % MOD;
                long long x = u + v;
                if (x >= MOD) x -= MOD;
                long long y = u - v;
                if (y < 0) y += MOD;
                a[i + j] = (int)x;
                a[i + j + half] = (int)y;
                w = w * wlen % MOD;
            }
        }
    }
    if (invert) {
        int invn = pw(n, MOD - 2);
        for (int& x : a) x = (int)((long long)x * invn % MOD);
    }
}

// multiply a*b, exact, no truncation
vector<int> mul(const vector<int>& a, const vector<int>& b) {
    if (a.empty() || b.empty()) return {};
    // naive for small
    if ((long long)a.size() * b.size() <= 4096) {
        vector<int> c(a.size() + b.size() - 1, 0);
        for (int i = 0; i < (int)a.size(); i++) {
            long long ai = a[i];
            if (!ai) continue;
            for (int j = 0; j < (int)b.size(); j++) {
                c[i + j] = (int)((c[i + j] + ai * b[j]) % MOD);
            }
        }
        return c;
    }
    int need = (int)a.size() + (int)b.size() - 1;
    int n = 1;
    while (n < need) n <<= 1;
    vector<int> fa(n, 0), fb(n, 0);
    copy(a.begin(), a.end(), fa.begin());
    copy(b.begin(), b.end(), fb.begin());
    ntt(fa, false);
    ntt(fb, false);
    for (int i = 0; i < n; i++) fa[i] = (int)((long long)fa[i] * fb[i] % MOD);
    ntt(fa, true);
    fa.resize(need);
    return fa;
}

int main() {
    for (int len = 2; len <= MAXN; len <<= 1)
        rt[len] = pw(G, (MOD - 1) / len);

    int n;
    if (scanf("%d", &n) != 1) return 0;
    vector<vector<int>> adj(n + 1);
    for (int i = 0; i < n - 1; i++) {
        int x, y;
        scanf("%d %d", &x, &y);
        adj[x].push_back(y);
        adj[y].push_back(x);
    }

    // iterative DFS from root 1: parent and child counts
    vector<int> par(n + 1, 0), k(n + 1, 0);
    vector<int> st;
    st.reserve(n);
    st.push_back(1);
    par[1] = -1;
    vector<int> order;
    order.reserve(n);
    while (!st.empty()) {
        int v = st.back();
        st.pop_back();
        order.push_back(v);
        for (int u : adj[v]) {
            if (u == par[v]) continue;
            par[u] = v;
            st.push_back(u);
        }
    }
    for (int i = (int)order.size() - 1; i >= 0; i--) {
        int v = order[i];
        if (par[v] > 0) k[par[v]]++;
    }

    // leaves: (1 + k_v x) for each vertex with k_v > 0
    vector<vector<int>> polys;
    polys.reserve(n);
    for (int v = 1; v <= n; v++)
        if (k[v]) polys.push_back({1, k[v]});

    // pairwise product tree
    while (polys.size() > 1) {
        vector<vector<int>> nxt;
        nxt.reserve((polys.size() + 1) / 2);
        for (size_t i = 0; i + 1 < polys.size(); i += 2)
            nxt.push_back(mul(polys[i], polys[i + 1]));
        if (polys.size() & 1)
            nxt.push_back(std::move(polys.back()));
        polys = std::move(nxt);
    }
    vector<int> P = polys.empty() ? vector<int>{1} : std::move(polys[0]);

    // factorials
    vector<int> fact(n + 1, 1);
    for (int i = 1; i <= n; i++) fact[i] = (int)((long long)fact[i - 1] * i % MOD);

    long long ans = 0;
    for (int kk = 0; kk < (int)P.size(); kk++) {
        long long term = (long long)P[kk] * fact[n - kk] % MOD;
        if (kk & 1) term = (MOD - term) % MOD;
        ans += term;
        if (ans >= (1LL << 62)) ans %= MOD;
    }
    ans %= MOD;
    printf("%d\n", (int)ans);
    return 0;
}
