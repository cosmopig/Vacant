#include <bits/stdc++.h>
using namespace std;

struct Fenwick {
    int n = 0, pw = 1;
    vector<int> bit;
    void init(int n_) {
        n = n_;
        bit.assign(n + 1, 0);
        pw = 1;
        while ((pw << 1) <= n) pw <<= 1;
    }
    void add(int idx, int delta) {
        for (int i = idx + 1; i <= n; i += i & -i) bit[i] += delta;
    }
    // smallest 0-based position whose prefix sum is >= k (1 <= k <= total)
    int kth(int k) const {
        int idx = 0;
        for (int d = pw; d; d >>= 1) {
            int nxt = idx + d;
            if (nxt <= n && bit[nxt] < k) {
                k -= bit[nxt];
                idx = nxt;
            }
        }
        return idx;
    }
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n)) return 0;
    vector<int> xs(n), ys(n), cs(n);
    for (int i = 0; i < n; i++) {
        cin >> xs[i] >> ys[i] >> cs[i];
        cs[i]--;
    }
    int m = n / 3;

    // Exact search for the small cases (m <= 6).
    if (n <= 18) {
        vector<vector<pair<int,int>>> pc(3);
        for (int i = 0; i < n; i++) pc[cs[i]].push_back({xs[i], ys[i]});
        auto inside = [&](pair<int,int> p, const array<int,4>& b) {
            return b[0] <= p.first && p.first <= b[1] && b[2] <= p.second && p.second <= b[3];
        };
        auto disjoint = [&](const array<int,4>& a, const array<int,4>& b) {
            return min(a[1], b[1]) - max(a[0], b[0]) <= 0 ||
                   min(a[3], b[3]) - max(a[2], b[2]) <= 0;
        };
        int ans = 0;
        for (int t = m; t >= 1 && ans == 0; t--) {
            vector<vector<pair<unsigned, array<int,4>>>> opt(3);
            for (int c = 0; c < 3; c++) {
                for (unsigned mask = 0; mask < (1u << m); mask++) {
                    if (__builtin_popcount(mask) != t) continue;
                    array<int,4> b = {INT_MAX, INT_MIN, INT_MAX, INT_MIN};
                    for (int i = 0; i < m; i++) if (mask >> i & 1u) {
                        auto p = pc[c][i];
                        b[0] = min(b[0], p.first); b[1] = max(b[1], p.first);
                        b[2] = min(b[2], p.second); b[3] = max(b[3], p.second);
                    }
                    opt[c].push_back({mask, b});
                }
            }
            bool found = false;
            for (auto &a0 : opt[0]) for (auto &a1 : opt[1]) for (auto &a2 : opt[2]) {
                unsigned masks[3] = {a0.first, a1.first, a2.first};
                array<int,4> bs[3] = {a0.second, a1.second, a2.second};
                bool ok = true;
                for (int i = 0; i < 3 && ok; i++) {
                    for (int j = 0; j < 3 && ok; j++) {
                        if (i == j) continue;
                        if (!disjoint(bs[i], bs[j])) { ok = false; break; }
                        for (int q = 0; q < m && ok; q++) if (masks[j] >> q & 1u) {
                            if (inside(pc[j][q], bs[i])) ok = false;
                        }
                    }
                }
                if (ok) { found = true; break; }
            }
            if (found) ans = t;
        }
        cout << 3 * ans << '\n';
        return 0;
    }

    int best = 0;

    // compressed coordinates for x and y
    vector<int> ux = xs, uy = ys;
    sort(ux.begin(), ux.end()); ux.erase(unique(ux.begin(), ux.end()), ux.end());
    sort(uy.begin(), uy.end()); uy.erase(unique(uy.begin(), uy.end()), uy.end());
    vector<int> cx(n), cy(n);
    for (int i = 0; i < n; i++) {
        cx[i] = lower_bound(ux.begin(), ux.end(), xs[i]) - ux.begin();
        cy[i] = lower_bound(uy.begin(), uy.end(), ys[i]) - uy.begin();
    }

    // ---------- parallel strips ----------
    // For axis a in {0=x,1=y}, group points by coordinate, then try all color orders.
    for (int axis = 0; axis < 2; axis++) {
        vector<int> ord(n);
        iota(ord.begin(), ord.end(), 0);
        if (axis == 0) sort(ord.begin(), ord.end(), [&](int a, int b){ return xs[a] < xs[b]; });
        else sort(ord.begin(), ord.end(), [&](int a, int b){ return ys[a] < ys[b]; });

        vector<array<int,3>> cnt;
        cnt.reserve(n);
        for (int i = 0; i < n;) {
            int j = i;
            array<int,3> c = {0,0,0};
            int coord = (axis == 0 ? xs[ord[i]] : ys[ord[i]]);
            while (j < n && (axis == 0 ? xs[ord[j]] : ys[ord[j]]) == coord) {
                c[cs[ord[j]]]++;
                j++;
            }
            cnt.push_back(c);
            i = j;
        }
        int G = (int)cnt.size();
        vector<vector<int>> pref(3, vector<int>(G + 1, 0));
        for (int g = 0; g < G; g++)
            for (int c = 0; c < 3; c++)
                pref[c][g + 1] = pref[c][g] + cnt[g][c];

        int perm[6][3] = {{0,1,2},{0,2,1},{1,0,2},{1,2,0},{2,0,1},{2,1,0}};
        for (auto &pm : perm) {
            int p = pm[0], q = pm[1], r = pm[2];
            auto check = [&](int t) -> bool {
                if (t == 0) return true;
                int i0 = lower_bound(pref[p].begin(), pref[p].end(), t) - pref[p].begin();
                if (i0 > G) return false;
                int target = pref[q][i0] + t;
                int j = lower_bound(pref[q].begin() + i0, pref[q].end(), target) - pref[q].begin();
                if (j > G) return false;
                return pref[r][G] - pref[r][j] >= t;
            };
            int lo = 0, hi = m;
            while (lo < hi) {
                int mid = (lo + hi + 1) >> 1;
                if (check(mid)) lo = mid; else hi = mid - 1;
            }
            best = max(best, lo);
        }
    }

    // ---------- perpendicular cuts ----------
    // First cut along axis u isolates color A on one side; second cut along v splits the other two.
    for (int u = 0; u < 2; u++) {
        int v = 1 - u;
        const vector<int>& U = (u == 0 ? xs : ys);
        const vector<int>& V = (u == 0 ? ys : xs);
        const vector<int>& posV = (v == 0 ? cx : cy);
        int GV = (int)(v == 0 ? ux.size() : uy.size());

        for (int A = 0; A < 3; A++) {
            int B = (A + 1) % 3, C = (A + 2) % 3;
            // the two non-A colors in fixed order; both below/above possibilities are checked
            vector<int> aVals;
            aVals.reserve(m);
            for (int i = 0; i < n; i++) if (cs[i] == A) aVals.push_back(U[i]);
            sort(aVals.begin(), aVals.end());

            for (int side = 0; side < 2; side++) {
                // r[p] = how many A-points lie strictly on the far side of p along u.
                // side 0: A keeps low side (u <= val), B/C use u > val -> r = #A with u < U[p]
                // side 1: A keeps high side (u >= val), B/C use u < val -> r = #A with u > U[p]
                vector<int> rcnt(m + 1, 0), r(n, 0);
                vector<int> items;
                items.reserve(2 * m);
                for (int i = 0; i < n; i++) {
                    if (cs[i] == A) continue;
                    int rr;
                    if (side == 0) {
                        rr = lower_bound(aVals.begin(), aVals.end(), U[i]) - aVals.begin();
                    } else {
                        rr = (int)(aVals.end() - upper_bound(aVals.begin(), aVals.end(), U[i]));
                    }
                    r[i] = rr;
                    rcnt[rr]++;
                    items.push_back(i);
                }
                vector<int> off(m + 2, 0);
                for (int i = 0; i <= m; i++) off[i + 1] = off[i] + rcnt[i];
                vector<int> ord(items.size());
                vector<int> fill(off.begin(), off.end() - 1);
                for (int i : items) ord[fill[r[i]]++] = i;

                Fenwick fb, fc;
                fb.init(GV); fc.init(GV);
                int cntB = 0, cntC = 0;

                for (int t = m; t >= 1; t--) {
                    for (int idx = off[t]; idx < off[t + 1]; idx++) {
                        int p = ord[idx];
                        int pos = posV[p];
                        if (cs[p] == B) { fb.add(pos, 1); cntB++; }
                        else { fc.add(pos, 1); cntC++; }
                    }
                    if (cntB < t || cntC < t) continue;
                    // order 1: B below v, C above v
                    int bs = fb.kth(t);
                    int cl = fc.kth(cntC - t + 1);
                    bool ok = bs < cl;
                    // order 2: C below v, B above v
                    if (!ok) {
                        int csidx = fc.kth(t);
                        int bl = fb.kth(cntB - t + 1);
                        ok = csidx < bl;
                    }
                    if (ok) {
                        best = max(best, t);
                        break;
                    }
                }
            }
        }
    }

    cout << 3 * best << '\n';
    return 0;
}
