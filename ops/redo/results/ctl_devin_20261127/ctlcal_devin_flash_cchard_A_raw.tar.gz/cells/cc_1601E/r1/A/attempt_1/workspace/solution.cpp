#include <bits/stdc++.h>
using namespace std;

int main() {
    int n, q, k;
    if (scanf("%d %d %d", &n, &q, &k) != 3) return 0;
    vector<long long> a(n + 1);
    for (int i = 1; i <= n; i++) scanf("%lld", &a[i]);
    while (q--) {
        int l, r;
        scanf("%d %d", &l, &r);
        long long len = r - l + 1;
        long long m = (len + k - 1) / k;
        long long ans = 0, cur = LLONG_MAX;
        int i = l;
        for (long long j = 0; j < m; j++) {
            long long x = l + j * (long long)k;
            while (i <= x) { cur = min(cur, a[i]); i++; }
            ans += cur;
        }
        printf("%lld\n", ans);
    }
    return 0;
}
