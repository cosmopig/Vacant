import sys
import bisect


def main():
    data = sys.stdin.buffer.read().split()
    idx = 0
    n = int(data[idx]); idx += 1
    a = [0] * (n + 1)
    b = [0] * (n + 1)
    for k in range(1, n + 1):
        a[k] = int(data[idx]); b[k] = int(data[idx + 1]); idx += 2
    t = int(data[idx]); idx += 1
    need = set()
    for _ in range(t):
        need.add(a[int(data[idx])]); idx += 1

    events = sorted((b[k], k) for k in range(1, n + 1))
    bvals = [e[0] for e in events]

    completed = set()
    pos = 0
    travels = 0
    m = len(events)
    while True:
        j = bisect.bisect_right(bvals, pos)
        if j == m:
            break
        bk, k = events[j]
        if a[k] in completed:
            pos = bk
            continue
        travels += 1
        completed = {a[k]} | {x for x in completed if x < a[k]}
        if need <= completed:
            print(travels)
            return
        pos = a[k]


main()
