#include <bits/stdc++.h>
using namespace std;

static const long long MOD = 1000000007LL;

static inline long long norm(long long x) {
    x %= MOD;
    if (x < 0) x += MOD;
    return x;
}

static inline long long mulmod(long long a, long long b) {
    return (long long)((__int128)a * b % MOD);
}

static pair<long long,long long> fib2(long long n) {
    if (n == 0) return {0, 1};
    auto p = fib2(n >> 1);
    long long a = p.first, b = p.second;
    long long c = mulmod(a, norm(2 * b - a));
    long long d = norm(a * a % MOD + mulmod(b, b));
    if ((n & 1LL) == 0) return {c, d};
    return {d, norm(c + d)};
}

static long long fib(long long n) {
    if (n >= 0) return fib2(n).first;
    long long m = -n;
    long long v = fib2(m).first;
    return (m & 1LL) ? v : norm(-v);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N, Q;
    if (!(cin >> N >> Q)) return 0;
    vector<long long> a1(N), a2(N);
    for (int i = 0; i < N; i++) cin >> a1[i];
    for (int i = 0; i < N; i++) cin >> a2[i];

    string out;
    out.reserve(1 << 20);
    char buf[64];

    for (int qi = 0; qi < Q; qi++) {
        int type;
        cin >> type;
        if (type == 4) {
            int l, r;
            cin >> l >> r;
            --l; --r;
            long long sum = 0;
            for (int i = l; i <= r; i++) {
                sum += fib(a1[i] + a2[i]);
                if (sum >= MOD) sum -= MOD;
            }
            int len = snprintf(buf, sizeof(buf), "%lld\n", sum);
            out.append(buf, len);
        } else {
            int k, l, r;
            long long x;
            cin >> k >> l >> r >> x;
            --l; --r;
            vector<long long>& a = (k == 1 ? a1 : a2);
            if (type == 1) {
                for (int i = l; i <= r; i++) a[i] = min(a[i], x);
            } else if (type == 2) {
                for (int i = l; i <= r; i++) a[i] = max(a[i], x);
            } else {
                for (int i = l; i <= r; i++) a[i] += x;
            }
        }
    }

    fputs(out.c_str(), stdout);
    return 0;
}
