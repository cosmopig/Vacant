#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int,int> pii;

int n, m;
vector<unordered_map<int,ll>> adj;

struct P3 { ll w; int a, b; };

// Dijkstra on local adjacency
static void dijkstra(int s, const vector<vector<pair<int,ll>>>& g, vector<ll>& d){
    int k = g.size();
    fill(d.begin(), d.end(), LLONG_MAX/4);
    priority_queue<pair<ll,int>, vector<pair<ll,int>>, greater<pair<ll,int>>> pq;
    d[s]=0; pq.push({0,s});
    while(!pq.empty()){
        auto [du,u]=pq.top(); pq.pop();
        if(du!=d[u]) continue;
        for(auto [v,w]: g[u]){
            ll nd=du+w;
            if(nd<d[v]){ d[v]=nd; pq.push({nd,v}); }
        }
    }
}

ll compute(){
    // find connected components
    vector<int> cid(n+1,-1);
    vector<vector<int>> members;
    vector<int> st;
    for(int s=1;s<=n;s++) if(cid[s]<0){
        int id=(int)members.size();
        members.push_back({});
        st.push_back(s); cid[s]=id;
        while(!st.empty()){
            int v=st.back(); st.pop_back();
            members[id].push_back(v);
            for(auto &kv: adj[v]){
                int u=kv.first;
                if(cid[u]<0){ cid[u]=id; st.push_back(u); }
            }
        }
    }

    ll ans = LLONG_MAX;

    // Case A: two pairs in different components.
    // Min pair distance inside a component = min edge weight in it.
    vector<ll> f;
    for(auto &mem: members){
        if(mem.size()<2) continue;
        ll mn = LLONG_MAX;
        for(int v: mem) for(auto &kv: adj[v]) mn = min(mn, kv.second);
        f.push_back(mn);
    }
    sort(f.begin(), f.end());
    if(f.size()>=2) ans = f[0]+f[1];

    // Case B: two disjoint pairs inside one component (needs >=4 vertices).
    vector<int> loc(n+1,-1);
    for(auto &mem: members){
        int k=(int)mem.size();
        if(k<4) continue;
        for(int i=0;i<k;i++) loc[mem[i]]=i;
        vector<vector<pair<int,ll>>> g(k);
        for(int v: mem){
            int lv=loc[v];
            for(auto &kv: adj[v]) g[lv].push_back({loc[kv.first], kv.second});
        }
        // all-pairs distances within component
        vector<vector<ll>> D(k, vector<ll>(k));
        vector<ll> d(k);
        for(int s=0;s<k;s++){
            dijkstra(s,g,d);
            for(int i=0;i<k;i++) D[s][i]=d[i];
        }
        // enumerate unordered pairs
        vector<P3> pairs;
        pairs.reserve(k*(k-1)/2);
        for(int a=0;a<k;a++) for(int b=a+1;b<k;b++)
            pairs.push_back({D[a][b],a,b});
        sort(pairs.begin(), pairs.end(), [](const P3&x,const P3&y){return x.w<y.w;});
        int M=pairs.size();
        // g = min over i of w_i + (min weight pair vertex-disjoint from i)
        ll best=LLONG_MAX;
        for(int i=0;i<M;i++){
            int a=pairs[i].a,b=pairs[i].b;
            for(int j=0;j<M;j++){
                int c=pairs[j].a,d=pairs[j].b;
                if(c!=a && c!=b && d!=a && d!=b){
                    ll cand=pairs[i].w+pairs[j].w;
                    if(cand<best) best=cand;
                    break; // sorted: first disjoint j is minimal
                }
            }
        }
        if(best<ans) ans=best;
        for(int v: mem) loc[v]=-1;
    }
    return ans;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cin>>n>>m;
    adj.assign(n+1,{});
    for(int i=0;i<m;i++){
        int v,u; ll w; cin>>v>>u>>w;
        adj[v][u]=w; adj[u][v]=w;
    }
    int q; cin>>q;
    cout<<compute()<<"\n";
    for(int i=0;i<q;i++){
        int t,v,u; cin>>t>>v>>u;
        if(t==0){
            adj[v].erase(u); adj[u].erase(v);
        }else{
            ll w; cin>>w;
            adj[v][u]=w; adj[u][v]=w;
        }
        cout<<compute()<<"\n";
    }
    return 0;
}
