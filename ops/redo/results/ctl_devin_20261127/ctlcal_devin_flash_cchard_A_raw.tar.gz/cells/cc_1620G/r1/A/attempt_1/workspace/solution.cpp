#include <bits/stdc++.h>
using namespace std;

typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned long long u64;
typedef long long i64;

static const int MOD = 998244353;

int main() {
    int n;
    if (scanf("%d", &n) != 1) return 0;

    // cnt[i*26 + c] = number of letter c in string i
    vector<u16> cnt((size_t)n * 26, 0);
    {
        // read strings fast
        static char buf[1 << 16];
        for (int i = 0; i < n; ++i) {
            if (scanf("%65535s", buf) != 1) return 0;
            for (char* p = buf; *p; ++p) cnt[(size_t)i * 26 + (*p - 'a')]++;
        }
    }

    size_t N = (size_t)1 << n;

    // mn[T*26 + c] = min over i in T of cnt[i][c]  (only for T != 0)
    u16* mn = (u16*)malloc(N * 26 * sizeof(u16));
    int* f = (int*)malloc(N * sizeof(int));       // a[T], later h[S] = f(S) mod MOD
    u16* sumIdx = (u16*)malloc(N * sizeof(u16));  // sum of 1-based indices in S
    if (!mn || !f || !sumIdx) return 1;

    f[0] = 0;
    sumIdx[0] = 0;
    memset(mn, 0xFF, 26 * sizeof(u16)); // empty set: componentwise min = +inf

    for (size_t T = 1; T < N; ++T) {
        int b = __builtin_ctzll(T);
        size_t src = T & (T - 1);
        const u16* srow = mn + src * 26;
        const u16* crow = cnt.data() + (size_t)b * 26;
        u16* drow = mn + T * 26;

        u64 acc = 1;
        for (int c = 0; c < 26; c += 4) {
            int lim = c + 4 < 26 ? c + 4 : 26;
            u64 p = 1;
            for (int j = c; j < lim; ++j) {
                u16 v = srow[j] < crow[j] ? srow[j] : crow[j];
                drow[j] = v;
                p *= (u64)(v + 1);
            }
            acc = acc * (p % MOD) % MOD;
        }

        int val = (int)acc;
        f[T] = (__builtin_popcountll(T) & 1) ? val : (val ? MOD - val : 0);
        sumIdx[T] = (u16)(sumIdx[src] + (u16)(b + 1));
    }

    // subset zeta transform: f[S] = sum_{T subseteq S} a[T]
    for (int i = 0; i < n; ++i) {
        size_t half = (size_t)1 << i;
        size_t full = half << 1;
        for (size_t base = 0; base < N; base += full) {
            int* lo = f + base;
            int* hi = f + base + half;
            for (size_t j = 0; j < half; ++j) {
                int s = hi[j] + lo[j];
                hi[j] = s >= MOD ? s - MOD : s;
            }
        }
    }

    free(mn);

    u64 ans = 0;
    for (size_t S = 1; S < N; ++S) {
        u64 w = (u64)__builtin_popcountll(S) * (u64)sumIdx[S];
        ans ^= (u64)f[S] * w;
    }

    printf("%llu\n", (unsigned long long)ans);
    return 0;
}
