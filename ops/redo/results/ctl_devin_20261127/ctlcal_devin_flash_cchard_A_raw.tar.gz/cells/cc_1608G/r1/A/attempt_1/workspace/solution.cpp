#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m, q;
    if (!(cin >> n >> m >> q)) return 0;

    vector<vector<pair<int,char>>> adj(n + 1);
    for (int i = 0; i < n - 1; i++) {
        int u, v; char c;
        cin >> u >> v >> c;
        adj[u].push_back({v, c});
        adj[v].push_back({u, c});
    }

    vector<string> strs(m + 1);
    for (int i = 1; i <= m; i++) cin >> strs[i];

    // For each query, BFS from u to v to recover the path string.
    vector<int> par(n + 1), pe(n + 1);
    vector<char> vis(n + 1);

    for (int qi = 0; qi < q; qi++) {
        int u, v, l, r;
        cin >> u >> v >> l >> r;

        // BFS from u to v
        fill(vis.begin(), vis.end(), 0);
        queue<int> bfs;
        bfs.push(u);
        vis[u] = 1;
        par[u] = -1;
        while (!bfs.empty() && !vis[v]) {
            int x = bfs.front(); bfs.pop();
            for (auto &e : adj[x]) {
                if (!vis[e.first]) {
                    vis[e.first] = 1;
                    par[e.first] = x;
                    pe[e.first] = e.second; // label of edge x--e.first
                    bfs.push(e.first);
                }
            }
        }

        // Reconstruct path u -> v: climb from v to u, then reverse.
        // Edge label stored at node is the label of edge to its parent.
        string path;
        for (int x = v; x != u; x = par[x]) path.push_back(pe[x]);
        reverse(path.begin(), path.end());

        // Count occurrences of `path` in strs[l..r] (overlapping allowed).
        long long ans = 0;
        if (!path.empty()) {
            // KMP prefix function for pattern
            int L = path.size();
            vector<int> pi(L, 0);
            for (int i = 1, j = 0; i < L; i++) {
                while (j && path[i] != path[j]) j = pi[j - 1];
                if (path[i] == path[j]) j++;
                pi[i] = j;
            }
            for (int i = l; i <= r; i++) {
                const string &s = strs[i];
                int j = 0;
                for (char ch : s) {
                    while (j && ch != path[j]) j = pi[j - 1];
                    if (ch == path[j]) j++;
                    if (j == L) {
                        ans++;
                        j = pi[j - 1];
                    }
                }
            }
        }
        cout << ans << '\n';
    }
    return 0;
}
