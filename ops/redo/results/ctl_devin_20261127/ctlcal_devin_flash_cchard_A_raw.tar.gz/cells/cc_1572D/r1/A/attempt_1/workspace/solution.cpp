#include <bits/stdc++.h>
using namespace std;

struct Edge {
    int to;
    int rev;
    int cap;
    int cost;
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, k;
    if (!(cin >> n >> k)) return 0;
    int N = 1 << n;
    vector<long long> a(N);
    for (int i = 0; i < N; ++i) {
        if (!(cin >> a[i])) a[i] = 0;
    }

    int half = N / 2;
    int m = min<long long>(k, half);
    if (m <= 0) {
        cout << 0 << "\n";
        return 0;
    }

    // Bipartition by parity of popcount(mask). Even -> left, odd -> right.
    vector<int> node(N, -1);
    int leftCnt = 0, rightCnt = 0;
    for (int mask = 0; mask < N; ++mask) {
        if (__builtin_popcount((unsigned)mask) & 1) {
            node[mask] = 1 + half + rightCnt++;
        } else {
            node[mask] = 1 + leftCnt++;
        }
    }
    const int S = 0;
    const int T = N + 1;
    const int NN = N + 2;

    vector<vector<Edge>> g(NN);
    auto add_edge = [&](int s, int t, int cap, int cost) {
        Edge a{t, (int)g[t].size(), cap, cost};
        Edge b{s, (int)g[s].size(), 0, -cost};
        g[s].push_back(a);
        g[t].push_back(b);
    };

    for (int mask = 0; mask < N; ++mask) {
        if (__builtin_popcount((unsigned)mask) & 1) {
            add_edge(node[mask], T, 1, 0);
        } else {
            add_edge(S, node[mask], 1, 0);
        }
    }
    for (int mask = 0; mask < N; ++mask) {
        if (__builtin_popcount((unsigned)mask) & 1) continue;
        int u = node[mask];
        for (int b = 0; b < n; ++b) {
            int vm = mask ^ (1 << b);
            long long w = a[mask] + a[vm];
            add_edge(u, node[vm], 1, (int)(-w));
        }
    }

    const long long INF = (1LL << 60);
    vector<long long> pot(NN, 0), dist(NN);
    vector<int> pv(NN), pe(NN);

    // Initial potentials via DAG shortest paths (node ids are topologically ordered).
    fill(dist.begin(), dist.end(), INF);
    dist[S] = 0;
    for (int u = 0; u < NN; ++u) {
        if (dist[u] == INF) continue;
        for (int i = 0; i < (int)g[u].size(); ++i) {
            Edge &e = g[u][i];
            if (e.cap > 0 && dist[e.to] > dist[u] + e.cost)
                dist[e.to] = dist[u] + e.cost;
        }
    }
    for (int i = 0; i < NN; ++i)
        if (dist[i] < INF) pot[i] = dist[i];

    auto dijkstra = [&]() -> bool {
        fill(dist.begin(), dist.end(), INF);
        dist[S] = 0;
        priority_queue<pair<long long,int>, vector<pair<long long,int>>, greater<pair<long long,int>>> pq;
        pq.push({0, S});
        while (!pq.empty()) {
            auto [du, u] = pq.top(); pq.pop();
            if (du != dist[u]) continue;
            for (int i = 0; i < (int)g[u].size(); ++i) {
                Edge &e = g[u][i];
                if (e.cap <= 0) continue;
                long long nd = du + e.cost + pot[u] - pot[e.to];
                if (nd < dist[e.to]) {
                    dist[e.to] = nd;
                    pv[e.to] = u;
                    pe[e.to] = i;
                    pq.push({nd, e.to});
                }
            }
        }
        return dist[T] < INF;
    };

    long long total = 0;
    long long best = 0;
    for (int f = 1; f <= m; ++f) {
        if (!dijkstra()) break;
        long long real = dist[T] + pot[T] - pot[S];
        int add = 1;
        for (int v = T; v != S; v = pv[v]) {
            Edge &e = g[pv[v]][pe[v]];
            add = min(add, e.cap);
        }
        if (add <= 0) break;
        for (int v = T; v != S; v = pv[v]) {
            Edge &e = g[pv[v]][pe[v]];
            e.cap -= add;
            g[v][e.rev].cap += add;
        }
        total += real * add;
        for (int i = 0; i < NN; ++i)
            if (dist[i] < INF) pot[i] += dist[i];
        long long profit = -total;
        if (profit > best) best = profit;
    }

    cout << best << "\n";
    return 0;
}
