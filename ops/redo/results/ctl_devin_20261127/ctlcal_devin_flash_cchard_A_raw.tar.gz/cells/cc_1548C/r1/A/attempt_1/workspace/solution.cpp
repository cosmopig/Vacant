#include <bits/stdc++.h>
using namespace std;

static const int MOD = 1000000007;

static inline int norm(long long x) {
    x %= MOD;
    if (x < 0) x += MOD;
    return (int)x;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, q;
    if (!(cin >> n >> q)) return 0;

    vector<int> queries(q);
    for (int i = 0; i < q; ++i) cin >> queries[i];

    const int N3 = 3 * n;
    const int M = N3 + 3; // row length for C(3n+3, j)

    vector<int> inv(M + 1);
    inv[1] = 1;
    for (int i = 2; i <= M; ++i) {
        inv[i] = (int)((long long)MOD - (long long)MOD / i * inv[MOD % i] % MOD);
    }

    // R[x] = coeff of t^x in ((1+t)^(3n+3) - (1+t)^3) / t
    //       = C(3n+3, x+1) - C(3, x+1)
    vector<int> R(N3 + 3, 0); // x = 0..3n+2
    long long b = 1;
    for (int j = 1; j <= M; ++j) {
        b = b * (M - j + 1) % MOD * inv[j] % MOD;
        int x = j - 1;
        int sub = 0;
        if (j == 1) sub = 3;
        else if (j == 2) sub = 3;
        else if (j == 3) sub = 1;
        R[x] = (int)((b - sub + MOD) % MOD);
    }

    // A(t) * (t^2 + 3t + 3) = R(t), solve coefficients from high degree down.
    vector<int> a(N3 + 3, 0); // a[0..3n] used; a[3n+1], a[3n+2] stay 0
    for (int x = N3 + 2; x >= 2; --x) {
        long long val = R[x] - 3LL * a[x - 1] - 3LL * a[x];
        a[x - 2] = norm(val);
    }

    string out;
    out.reserve((size_t)q * 11);
    char buf[16];
    for (int x : queries) {
        int v = (x <= N3) ? a[x] : 0;
        int len = snprintf(buf, sizeof(buf), "%d\n", v);
        out.append(buf, len);
    }
    cout << out;
    return 0;
}
