import sys


def feasible(p, m, n, alpha):
    # p[i][j]: joy for friend j in shop i. Friend j is covered if some shop
    # has p[i][j] >= alpha. Feasible iff every friend is covered and some
    # shop covers at least 2 friends (then <= n-1 shops suffice).
    covered = [False] * n
    max_cover = 0
    for i in range(m):
        row = p[i]
        cnt = 0
        for j in range(n):
            if row[j] >= alpha:
                cnt += 1
                covered[j] = True
        if cnt > max_cover:
            max_cover = cnt
    if max_cover < 2:
        return False
    return all(covered)


def solve():
    data = sys.stdin.buffer.read().split()
    idx = 0
    t = int(data[idx]); idx += 1
    out = []
    for _ in range(t):
        m = int(data[idx]); n = int(data[idx + 1]); idx += 2
        p = []
        vals = []
        for i in range(m):
            row = [int(data[idx + j]) for j in range(n)]
            idx += n
            p.append(row)
            vals.extend(row)
        uniq = sorted(set(vals))
        lo, hi = 0, len(uniq) - 1
        # feasible at the minimum value always holds
        while lo < hi:
            mid = (lo + hi + 1) // 2
            if feasible(p, m, n, uniq[mid]):
                lo = mid
            else:
                hi = mid - 1
        out.append(str(uniq[lo]))
    sys.stdout.write("\n".join(out) + "\n")


solve()
