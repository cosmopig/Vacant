import sys
import heapq


def main() -> None:
    data = sys.stdin.buffer.read().split()
    pos = 0
    t = int(data[pos]); pos += 1
    out_lines = []
    for _ in range(t):
        n = int(data[pos]); pos += 1
        cnt = [0] * (n + 1)
        for _ in range(n):
            cnt[int(data[pos])] += 1
            pos += 1

        res = [0] * (n + 1)
        # MEX = 0: every element equal to 0 must be incremented.
        res[0] = cnt[0]

        heap = []          # max-heap of surplus element values (stored negated)
        cum = 0            # minimal ops to cover values 0..i-1
        feasible = True
        for i in range(1, n + 1):
            k = i - 1
            if cnt[k] == 0:
                if not heap:
                    feasible = False
                else:
                    v = -heapq.heappop(heap)
                    cum += k - v
            else:
                for _ in range(cnt[k] - 1):
                    heapq.heappush(heap, -k)
            if not feasible:
                for j in range(i, n + 1):
                    res[j] = -1
                break
            res[i] = cum + cnt[i]

        out_lines.append(' '.join(map(str, res)))

    sys.stdout.write('\n'.join(out_lines) + '\n')


main()
