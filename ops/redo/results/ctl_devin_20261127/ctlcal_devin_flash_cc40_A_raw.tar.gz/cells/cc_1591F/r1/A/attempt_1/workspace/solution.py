import sys

MOD = 998244353


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    a = list(map(int, data[1:1 + n]))

    # segs: list of [value, length] covering c = 1..a_i contiguously,
    # where value = number of ways for the processed prefix ending with b_i = c.
    segs = [[1, a[0]]]
    total = a[0] % MOD  # S_i = sum_c dp_i(c)

    for i in range(1, n):
        ai = a[i]
        S_prev = total
        new_segs = []
        covered = 0
        for v, ln in segs:
            if covered >= ai:
                break
            take = ln if covered + ln <= ai else ai - covered
            nv = S_prev - v
            if new_segs and new_segs[-1][0] == nv % MOD:
                new_segs[-1][1] += take
            else:
                new_segs.append([nv % MOD, take])
            covered += take
            if covered >= ai:
                break
        if covered < ai:
            # c in (cur_a, ai]: dp_{i-1}(c) = 0, so dp_i(c) = S_prev
            nv = S_prev % MOD
            if new_segs and new_segs[-1][0] == nv:
                new_segs[-1][1] += ai - covered
            else:
                new_segs.append([nv, ai - covered])
        segs = new_segs
        total = 0
        for v, ln in segs:
            total = (total + v * (ln % MOD)) % MOD

    print(total % MOD)


main()
