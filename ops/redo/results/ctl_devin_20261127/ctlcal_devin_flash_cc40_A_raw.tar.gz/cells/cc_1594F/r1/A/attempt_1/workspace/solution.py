import sys


def solve(s, n, k):
    # Distributions of s animals into n positive parts correspond to choosing
    # n+1 prefix sums 0 = p0 < p1 < ... < pn = s. A contiguous segment sums to
    # k iff two prefix sums differ by k. The farm fails to be ideal iff there
    # is a size-(n+1) subset of [0, s] containing 0 and s with no two elements
    # differing by k.
    if k > s:
        return "NO"
    if k == s:
        return "YES"
    # k < s. Group [0, s] into chains by residue mod k; forbidden pairs are
    # adjacent elements within a chain. With s = q*k + rem, chain lengths are
    # q+1 (rem+1 chains) and q (k-rem-1 chains). Max subset avoiding diff k is
    # sum of ceil(len/2) = (s+1 + O)/2, where O = number of odd-length chains.
    q, rem = divmod(s, k)
    odd = (rem + 1) if q % 2 == 0 else (k - rem - 1)
    max_size = (s + 1 + odd) // 2
    return "YES" if n + 1 > max_size else "NO"


def main():
    data = sys.stdin.buffer.read().split()
    t = int(data[0])
    out = []
    idx = 1
    for _ in range(t):
        s, n, k = int(data[idx]), int(data[idx + 1]), int(data[idx + 2])
        idx += 3
        if s <= 0 or n <= 0 or n > s or k <= 0:
            out.append("NO")
        else:
            out.append(solve(s, n, k))
    sys.stdout.write("\n".join(out) + "\n")


main()
