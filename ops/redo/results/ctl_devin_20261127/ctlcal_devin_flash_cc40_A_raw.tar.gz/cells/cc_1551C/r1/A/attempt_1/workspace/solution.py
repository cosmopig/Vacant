import sys


def solve() -> None:
    data = sys.stdin.buffer.read().split()
    pos = 0
    t = int(data[pos])
    pos += 1
    out = []

    for _ in range(t):
        n = int(data[pos])
        pos += 1

        margins = [0] * 5
        base = [0] * 5
        negatives = [[] for _ in range(5)]

        for _ in range(n):
            w = data[pos]
            pos += 1
            length = len(w)
            counts = [0] * 5
            for ch in w:
                counts[ch - 97] += 1

            for letter in range(5):
                value = counts[letter] * 2 - length
                if value >= 0:
                    margins[letter] += value
                    base[letter] += 1
                else:
                    negatives[letter].append(-value)

        best = 0
        for letter in range(5):
            margin = margins[letter]
            if margin <= 0:
                continue
            costs = negatives[letter]
            costs.sort()
            used = 0
            extra = 0
            for cost in costs:
                if used + cost >= margin:
                    break
                used += cost
                extra += 1
            best = max(best, base[letter] + extra)

        out.append(str(best))

    sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    solve()
