import sys


def main():
    data = sys.stdin.buffer.read().split()
    it = iter(data)
    t = int(next(it))
    out = []
    for _ in range(t):
        n = int(next(it))
        q = int(next(it))
        s = next(it).decode()
        # e_i = (-1)^(i-1) * a_i, prefix sums D
        D = [0] * (n + 1)
        for i, ch in enumerate(s, 1):
            a = 1 if ch == '+' else -1
            e = a if i % 2 == 1 else -a
            D[i] = D[i - 1] + e
        for _ in range(q):
            l = int(next(it))
            r = int(next(it))
            m = r - l + 1
            if m % 2 == 1:
                out.append('1')
            elif D[r] == D[l - 1]:
                out.append('0')
            else:
                out.append('2')
    sys.stdout.write('\n'.join(out) + '\n')


main()
