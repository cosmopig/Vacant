import sys

MOD = 998244353


def main():
    data = sys.stdin.read().split()
    if not data:
        return
    n = int(data[0])
    x = int(data[1])

    if x < n:
        print(pow(x, n, MOD))
        return

    N = n
    E = x - n

    # inv[i] = inverse of i mod MOD for i >= 1
    inv = [0] * (N + 2)
    inv[1] = 1
    for i in range(2, N + 2):
        inv[i] = MOD - MOD // i * inv[MOD % i] % MOD

    # coeff[k] for fixed n is built on the fly below; store per n.
    # coeff[n][k] = C(n-1, k-1) * (n-1)^(n-k), for 2 <= k <= n
    coeff = [None] * (N + 1)
    base = [0] * (N + 1)
    for nn in range(2, N + 1):
        B = nn - 1
        base[nn] = nn * pow(B, B, MOD) % MOD
        arr = [0] * (nn + 1)
        # k = 2: C(B,1) * B^(nn-2) = B^(nn-1)
        cur = pow(B, nn - 1, MOD)
        arr[2] = cur
        invB = inv[B]
        for k in range(2, nn):
            # move from k to k+1:
            # ratio = (B-k+1)/k * 1/B
            cur = cur * (B - k + 1) % MOD * inv[k] % MOD * invB % MOD
            arr[k + 1] = cur
        coeff[nn] = arr

    # H[e][nn] = number of ordered nn-tuples with values in [1, nn+e]
    # having a unique maximum nn+e and producing a winner.
    H = [[0] * (N + 1) for _ in range(E + 1)]
    for nn in range(2, N + 1):
        H[0][nn] = base[nn]

    for e in range(1, E + 1):
        He = H[e]
        lim_e = e + 1
        for nn in range(2, N + 1):
            coeff_n = coeff[nn]
            limit = nn if nn < lim_e else lim_e
            s = 0
            # children are H[e+1-k][k], k = 2..limit
            for k in range(2, limit + 1):
                d = e + 1 - k
                term = coeff_n[k] * H[d][k] % MOD
                term = term * inv[k] % MOD
                s += term
            He[nn] = (base[nn] + nn * (s % MOD)) % MOD

    winners = 0
    for e in range(E + 1):
        winners = (winners + H[e][N]) % MOD

    ans = (pow(x, n, MOD) - winners) % MOD
    print(ans)


if __name__ == "__main__":
    main()
