import sys


def main():
    data = sys.stdin.buffer.read().split()
    t = int(data[0])
    out = []

    # P[i] = 10^i, R[i] = repunit with i ones (111...1)
    P = [1] * 12
    R = [0] * 12
    for i in range(1, 12):
        P[i] = P[i - 1] * 10
        R[i] = R[i - 1] + P[i - 1]

    idx = 1
    for _ in range(t):
        n = int(data[idx])
        k = int(data[idx + 1])
        idx += 2

        s = str(n)
        L = len(s)
        nd = [c - 48 for c in s.encode()]

        # pmask[j] / pval[j]: bitmask and integer value of the first j digits
        pmask = [0] * (L + 1)
        pval = [0] * (L + 1)
        m = 0
        v = 0
        for i, d in enumerate(nd):
            pmask[i] = m
            pval[i] = v
            m |= 1 << d
            v = v * 10 + d
        pmask[L] = m
        pval[L] = v

        if m.bit_count() <= k:
            out.append(str(n))
            continue

        # Smallest (L+1)-digit k-beautiful number: always > n.
        best = R[L + 1] if k == 1 else P[L]

        for j in range(L):
            pj = pmask[j]
            base = pval[j]
            nj = nd[j]
            rem = L - 1 - j
            mult_hi = P[rem + 1]
            mult_mid = P[rem]
            rrem = R[rem]
            for sd in range(nj + 1, 10):
                um = pj | (1 << sd)
                u = um.bit_count()
                if u > k:
                    continue
                if (um & 1) or u < k:
                    sv = 0
                else:
                    sv = ((um & -um).bit_length() - 1) * rrem
                c = base * mult_hi + sd * mult_mid + sv
                if c < best:
                    best = c

        out.append(str(best))

    sys.stdout.write("\n".join(out) + "\n")


main()
