import sys

MOD = 998244353


def main():
    data = sys.stdin.buffer.read().split()
    if not data:
        return
    n = int(data[0])
    doms = data[1:1 + n]

    a = b = c = d = e = 0
    forced_b = forced_w = 0

    for s in doms:
        x, y = s[0], s[1]
        if x == 63 and y == 63:
            e += 1
        elif x == 66 and y == 66:
            a += 1
        elif x == 87 and y == 87:
            b += 1
        elif x == 66 and y == 63:
            c += 1
            forced_b += 1
        elif x == 63 and y == 66:
            c += 1
            forced_w += 1
        elif x == 63 and y == 87:
            d += 1
            forced_b += 1
        elif x == 87 and y == 63:
            d += 1
            forced_w += 1
        elif x == 66 and y == 87:
            forced_b += 1
        else:
            forced_w += 1

    k = c + d + 2 * e
    r = b + d + e - a

    max_k = 2 * n
    fact = [1] * (max_k + 1)
    for i in range(1, max_k + 1):
        fact[i] = fact[i - 1] * i % MOD
    inv_fact = [1] * (max_k + 1)
    inv_fact[max_k] = pow(fact[max_k], MOD - 2, MOD)
    for i in range(max_k, 0, -1):
        inv_fact[i - 1] = inv_fact[i] * i % MOD

    if 0 <= r <= k:
        ct = fact[k] * inv_fact[r] % MOD * inv_fact[k - r] % MOD
    else:
        ct = 0

    ans = ct
    if a == 0 and b == 0:
        c00 = pow(2, e, MOD)
        bad = c00
        if forced_b == 0:
            bad -= 1
        if forced_w == 0:
            bad -= 1
        ans = (ct - bad) % MOD

    sys.stdout.write(str(ans) + "\n")


main()
