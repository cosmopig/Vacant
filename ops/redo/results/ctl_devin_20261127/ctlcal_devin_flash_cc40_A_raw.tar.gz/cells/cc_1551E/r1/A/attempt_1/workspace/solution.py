import sys


def main():
    data = sys.stdin.buffer.read().split()
    it = iter(data)
    t = int(next(it))
    out = []
    NEG = -10**9
    for _ in range(t):
        n = int(next(it))
        k = int(next(it))
        a = [0] * (n + 1)
        for i in range(1, n + 1):
            a[i] = int(next(it))

        # dp[d] = max number of fixed points after processing a prefix,
        # with exactly d deletions so far (d deletions among processed elems).
        dp = [NEG] * (n + 1)
        dp[0] = 0
        for p in range(1, n + 1):
            v = a[p]
            # valid prior states: d in [0, p-1]
            carry = dp[p - 1]          # delete element p -> d' = p
            d0 = p - v                  # keep gives fixed point iff d == p - v
            g_old = dp[d0] if 0 <= d0 <= p - 1 else NEG
            # delete-shift: new[d] = max(old[d], old[d-1]) for d in [1, p-1]
            for d in range(p - 1, 0, -1):
                if dp[d - 1] > dp[d]:
                    dp[d] = dp[d - 1]
            dp[p] = carry
            # keep-with-gain at d0: candidate old[d0] + 1
            if g_old != NEG and g_old + 1 > dp[d0]:
                dp[d0] = g_old + 1

        ans = -1
        for d in range(n + 1):
            if dp[d] >= k:
                ans = d
                break
        out.append(str(ans))

    sys.stdout.write("\n".join(out) + "\n")


main()
