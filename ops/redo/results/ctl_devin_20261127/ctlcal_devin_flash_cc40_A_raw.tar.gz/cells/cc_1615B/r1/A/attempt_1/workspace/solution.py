import sys


def count_with_bit(upto: int, bit: int) -> int:
    period = 1 << (bit + 1)
    half = 1 << bit
    full, rem = divmod(upto, period)
    return full * half + max(0, rem - half + 1)


def main() -> None:
    data = sys.stdin.buffer.read().split()
    t = int(data[0])
    pos = 1
    out = []
    for _ in range(t):
        l = int(data[pos])
        r = int(data[pos + 1])
        pos += 2
        n = r - l + 1
        best = 0
        bit = 0
        while (1 << bit) <= r:
            cnt = count_with_bit(r, bit) - count_with_bit(l - 1, bit)
            if cnt > best:
                best = cnt
                if best == n:
                    break
            bit += 1
        out.append(str(n - best))
    sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
