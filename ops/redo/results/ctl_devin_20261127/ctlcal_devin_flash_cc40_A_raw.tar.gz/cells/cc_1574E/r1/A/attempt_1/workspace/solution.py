import sys

MOD = 998244353
INV2 = (MOD + 1) // 2


def main() -> None:
    data = sys.stdin.buffer.read().split()
    if not data:
        return
    it = iter(data)
    n = int(next(it))
    m = int(next(it))
    k = int(next(it))

    cells = {}
    col = {}
    row = {}
    wcnt = [0, 0]
    bad_cols = 0
    bad_rows = 0
    distinct_cols = 0
    distinct_rows = 0
    edge_count = 0

    def touch_col(y: int, key: int, d: int) -> None:
        nonlocal bad_cols, distinct_cols
        a = col.get(y)
        if a is None:
            a = [0, 0]
            col[y] = a
        old_bad = a[0] != 0 and a[1] != 0
        old_tot = a[0] + a[1]
        if key:
            a[1] += d
        else:
            a[0] += d
        new_bad = a[0] != 0 and a[1] != 0
        bad_cols += int(new_bad) - int(old_bad)
        new_tot = a[0] + a[1]
        if old_tot == 0 and new_tot != 0:
            distinct_cols += 1
        elif old_tot != 0 and new_tot == 0:
            distinct_cols -= 1

    def touch_row(x: int, key: int, d: int) -> None:
        nonlocal bad_rows, distinct_rows
        a = row.get(x)
        if a is None:
            a = [0, 0]
            row[x] = a
        old_bad = a[0] != 0 and a[1] != 0
        old_tot = a[0] + a[1]
        if key:
            a[1] += d
        else:
            a[0] += d
        new_bad = a[0] != 0 and a[1] != 0
        bad_rows += int(new_bad) - int(old_bad)
        new_tot = a[0] + a[1]
        if old_tot == 0 and new_tot != 0:
            distinct_rows += 1
        elif old_tot != 0 and new_tot == 0:
            distinct_rows -= 1

    def add_edge(x: int, y: int, t: int, d: int) -> None:
        nonlocal edge_count
        rx = (x - 1) & 1
        ry = (y - 1) & 1
        ck = t ^ rx
        rk = t ^ ry
        touch_col(y, ck, d)
        touch_row(x, rk, d)
        wcnt[t ^ rx ^ ry] += d
        edge_count += d

    out = []
    append = out.append
    for _ in range(k):
        x = int(next(it))
        y = int(next(it))
        t = int(next(it))
        key = (x - 1) * m + (y - 1)
        if t == -1:
            old = cells.pop(key, None)
            if old is not None:
                add_edge(x, y, old, -1)
        else:
            old = cells.get(key)
            if old == t:
                pass
            else:
                if old is not None:
                    add_edge(x, y, old, -1)
                cells[key] = t
                add_edge(x, y, t, 1)

        u = 0
        if bad_cols == 0:
            u = pow(2, m - distinct_cols + 1, MOD)
        v = 0
        if bad_rows == 0:
            v = pow(2, n - distinct_rows + 1, MOD)
        if edge_count == 0:
            both = 4
        elif wcnt[0] == 0 or wcnt[1] == 0:
            both = 2
        else:
            both = 0
        append(((u + v - both) % MOD) * INV2 % MOD)

    sys.stdout.write("\n".join(map(str, out)) + "\n")


if __name__ == "__main__":
    main()
