import sys


def main():
    data = sys.stdin.buffer.read().split()
    q = int(data[0])
    queries = []
    maxv = 0
    idx = 1
    for _ in range(q):
        t = int(data[idx])
        idx += 1
        if t == 1:
            x = int(data[idx])
            idx += 1
            queries.append((1, x, 0))
            if x > maxv:
                maxv = x
        else:
            x = int(data[idx])
            y = int(data[idx + 1])
            idx += 2
            queries.append((2, x, y))
            if x > maxv:
                maxv = x
            if y > maxv:
                maxv = y

    nd = list(range(maxv + 1))
    res = []
    for t, x, y in reversed(queries):
        if t == 1:
            res.append(nd[x])
        else:
            nd[x] = nd[y]

    res.reverse()
    sys.stdout.write(" ".join(map(str, res)))


main()
