import sys


def main() -> None:
    data = sys.stdin.buffer.read().split()
    if not data:
        return
    it = iter(data)
    n = int(next(it))
    m = int(next(it))
    q = int(next(it))
    a = [int(next(it)) for _ in range(n)]
    b = [int(next(it)) for _ in range(m)]
    ks = [int(next(it)) for _ in range(q)]

    items = [(x, 1) for x in a] + [(x, 0) for x in b]
    items.sort()

    N = n + m
    prices = [0] * N
    lab = [0] * N
    for i, (p, is_a) in enumerate(items):
        prices[i] = p
        lab[i] = is_a

    pref = [0] * (N + 1)
    for i, p in enumerate(prices):
        pref[i + 1] = pref[i] + p

    parent = list(range(N))
    right = list(range(N))
    cnt = lab[:]

    def find(x: int) -> int:
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def contrib(x: int) -> int:
        r = right[x]
        t = cnt[x]
        return pref[r + 1] - pref[r - t + 1]

    total = sum(a)

    edges = [(prices[i] - prices[i - 1], i) for i in range(1, N)]
    edges.sort()

    order = sorted(range(q), key=lambda i: ks[i])
    ep = 0
    E = len(edges)
    ans = [0] * q

    for qi in order:
        k = ks[qi]
        while ep < E and edges[ep][0] <= k:
            _, i = edges[ep]
            ep += 1
            L = find(i - 1)
            R = find(i)
            if L == R:
                continue
            old = contrib(L) + contrib(R)
            parent[R] = L
            right[L] = right[R]
            cnt[L] += cnt[R]
            total += contrib(L) - old
        ans[qi] = total

    out = "\n".join(map(str, ans))
    sys.stdout.write(out + "\n")


if __name__ == "__main__":
    main()
