import sys


def main():
    data = sys.stdin.buffer.read().split()
    t = int(data[0])
    idx = 1
    out = []
    for _ in range(t):
        n = int(data[idx])
        idx += 1
        s = data[idx]
        idx += 1
        if s == s[::-1]:
            out.append("0")
            continue
        best = -1
        for c in set(s):
            l = 0
            r = n - 1
            cost = 0
            ok = True
            while l < r:
                a = s[l]
                b = s[r]
                if a == b:
                    l += 1
                    r -= 1
                elif a == c:
                    l += 1
                    cost += 1
                elif b == c:
                    r -= 1
                    cost += 1
                else:
                    ok = False
                    break
            if ok and (best == -1 or cost < best):
                best = cost
        out.append(str(best))
    sys.stdout.write("\n".join(out) + "\n")


main()
