import sys
from math import gcd


def main() -> None:
    data = sys.stdin.buffer.read().split()
    it = iter(data)
    t = int(next(it))

    # bad_mod[p] = lcm(2, 3, ..., p + 1), for p = 1..21.
    # For p >= 22 this lcm already exceeds 1e9, so every position has
    # at least one legal rank.
    bad_mod = [0] * 22
    l = 1
    for m in range(2, 23):
        l = l * m // gcd(l, m)
        bad_mod[m - 1] = l

    out = []
    for _ in range(t):
        n = int(next(it))
        ok = True
        for i in range(1, n + 1):
            a = int(next(it))
            if i <= 21 and a % bad_mod[i] == 0:
                ok = False
                # Still consume the rest of this test case.
                for _ in range(n - i):
                    next(it)
                break
        out.append("YES" if ok else "NO")

    sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
