import sys


def solve() -> None:
    data = sys.stdin.buffer.read().split()
    pos = 0
    t = int(data[pos])
    pos += 1
    out = []
    for _ in range(t):
        n = int(data[pos])
        pos += 1
        caves = []
        for _ in range(n):
            k = int(data[pos])
            pos += 1
            req = -10**30
            for j in range(k):
                a = int(data[pos])
                pos += 1
                # before fighting monster j (0-indexed), hero power is
                # entry_power + j; need entry_power + j > a -> entry_power >= a - j + 1
                val = a - j + 1
                if val > req:
                    req = val
            caves.append((req, k))
        caves.sort()
        gained = 0
        ans = 0
        for req, k in caves:
            need = req - gained
            if need > ans:
                ans = need
            gained += k
        out.append(str(ans))
    sys.stdout.write("\n".join(out))


solve()
