import sys

MOD = 10**9 + 7


def solve() -> None:
    data = sys.stdin.buffer.read().split()
    t = int(data[0])
    idx = 1
    out = []
    for _ in range(t):
        n = int(data[idx])
        k = int(data[idx + 1])
        idx += 2

        half = pow(2, n - 1, MOD)
        # For one bit position, choose the subset of elements having bit 1.
        # (and_bit, xor_bit, multiplicity)
        if n & 1:
            # all-ones -> (1,1); even non-all -> (0,0); odd non-all -> (0,1)
            types = ((1, 1, 1), (0, 0, half), (0, 1, half - 1))
        else:
            # all-ones -> (1,0); odd subsets -> (0,1); even non-all -> (0,0)
            types = ((1, 0, 1), (0, 1, half), (0, 0, half - 1))
        total = (1 + half + half - 1) % MOD  # = 2^n mod MOD

        # DP over bit positions (MSB -> LSB):
        # state 0: AND == XOR so far, 1: AND > XOR, 2: AND < XOR
        eq, gt, lt = 1, 0, 0
        for _ in range(k):
            neq = ngt = nlt = 0
            for a, x, w in types:
                if a > x:
                    ngt = (ngt + eq * w) % MOD
                elif a < x:
                    nlt = (nlt + eq * w) % MOD
                else:
                    neq = (neq + eq * w) % MOD
            gt = (gt * total + ngt) % MOD
            lt = (lt * total + nlt) % MOD
            eq = neq
        out.append(str((gt + eq) % MOD))
    sys.stdout.write("\n".join(out) + "\n")


solve()
