import sys


def solve() -> None:
    data = sys.stdin.buffer.read().split()
    it = iter(data)
    t = int(next(it))
    out_lines = []
    for _ in range(t):
        n = int(next(it))
        a = [int(next(it)) for _ in range(n)]
        b = [int(next(it)) for _ in range(n)]

        # Rank players by strength on map 1, descending.
        # In this order, x beats y on some map iff rank(x) < rank(y)
        # (map 1) or b[x] > b[y] (map 2, only relevant when rank(x) > rank(y)).
        order = sorted(range(n), key=lambda i: -a[i])
        B = [b[i] for i in order]

        # SM[m] = max B[j] for j >= m
        SM = [0] * (n + 1)
        for m in range(n - 1, -1, -1):
            SM[m] = SM[m + 1] if SM[m + 1] > B[m] else B[m]

        # f(m) = smallest index w < m with B[w] < SM[m]; m itself if none.
        # Answer all queries offline: sort positions by B, queries by SM[m].
        pos_by_b = sorted(range(n), key=lambda w: B[w])
        queries = sorted(range(n), key=lambda m: SM[m])
        f = [0] * n
        p = 0
        min_added = n + 1
        for m in queries:
            thr = SM[m]
            while p < n and B[pos_by_b[p]] < thr:
                w = pos_by_b[p]
                if w < min_added:
                    min_added = w
                p += 1
            # min_added is the smallest index with B < thr overall;
            # it is a valid target iff it is < m.
            f[m] = min_added if min_added < m else m

        # Follow the functional graph f (indices only decrease) to its root.
        # Player at rank i wins iff the orbit reaches rank 0.
        root = [0] * n
        for m in range(n):
            fm = f[m]
            root[m] = m if fm == m else root[fm]

        ans = ['0'] * n
        for i in range(n):
            if root[i] == 0:
                ans[order[i]] = '1'
        out_lines.append(''.join(ans))

    sys.stdout.write('\n'.join(out_lines) + '\n')


solve()
