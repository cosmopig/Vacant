import sys


def main():
    data = sys.stdin.buffer.read().split()
    if not data:
        return
    n = int(data[0])
    vals = [int(x) for x in data[1:1 + n]]
    maxv = max(vals) if vals else 0

    # XOR of numbers < 2^L stays < 2^L; bitsets have B = 2^L bits.
    L = maxv.bit_length()
    B = 1 << L if L else 1
    full = (1 << B) - 1

    # M0[b]/M1[b]: masks of bit indices y in [0,B) with bit b of y equal 0/1.
    # Swapping index bit b of a bitset Q: ((Q&M0)<<s) | ((Q&M1)>>s), s=2^b.
    M0 = [0] * L
    M1 = [0] * L
    for b in range(L):
        s = 1 << b
        per = s << 1
        p = ((1 << s) - 1) << s          # one period: bits s..2s-1 set
        R = full // ((1 << per) - 1)     # 1 + 2^per + 2^(2per) + ...
        m1 = p * R                       # tiled mask, no carries (disjoint bits)
        M1[b] = m1
        M0[b] = full ^ m1

    N = maxv + 1                        # fenwick positions 1..N for values 0..maxv
    tree = [0] * (N + 1)
    M = [0] * N                         # M[v]: bitset of xors of chains ending at value v
    ans = 1                              # bit 0: empty subsequence

    for v in vals:
        # OR of M[u] over u < v  (positions 1..v cover values 0..v-1)
        Q = 1                            # bit 0: empty prefix chain
        j = v
        while j:
            Q |= tree[j]
            j -= j & -j
        # permute bit indices by v: bit y -> y ^ v
        P = Q
        vv = v
        b = 0
        while vv:
            if vv & 1:
                s = 1 << b
                P = ((P & M0[b]) << s) | ((P & M1[b]) >> s)
            vv >>= 1
            b += 1
        nb = P & ~M[v]
        if nb:
            M[v] |= nb
            ans |= nb
            j = v + 1
            while j <= N:
                tree[j] |= nb
                j += j & -j

    out = []
    t = ans
    while t:
        lsb = t & -t
        out.append(str(lsb.bit_length() - 1))
        t ^= lsb
    sys.stdout.write(str(len(out)) + "\n" + " ".join(out) + "\n")


main()
