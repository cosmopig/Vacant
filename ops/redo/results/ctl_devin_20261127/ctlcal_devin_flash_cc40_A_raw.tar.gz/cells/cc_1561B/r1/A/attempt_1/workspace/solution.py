import sys


def solve(a: int, b: int):
    n = a + b
    res = set()
    for sb in (n // 2, (n + 1) // 2):
        t_min = max(0, sb - a)
        t_max = min(sb, b)
        if t_min > t_max:
            continue
        base = b + sb
        klo = base - 2 * t_max
        khi = base - 2 * t_min
        res.update(range(klo, khi + 1, 2))
    return sorted(res)


def main() -> None:
    data = list(map(int, sys.stdin.read().split()))
    t = data[0]
    out = []
    idx = 1
    for _ in range(t):
        a, b = data[idx], data[idx + 1]
        idx += 2
        ks = solve(a, b)
        out.append(str(len(ks)))
        out.append(" ".join(map(str, ks)))
    sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
