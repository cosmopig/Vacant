import sys


def main() -> None:
    data = sys.stdin.buffer.read().split()
    it = iter(data)
    t = int(next(it))
    out = []
    for _ in range(t):
        n = int(next(it))
        h = int(next(it))
        a = [int(next(it)) for _ in range(n)]
        gaps = [a[i + 1] - a[i] for i in range(n - 1)]

        def damage(k: int) -> int:
            total = k
            for g in gaps:
                total += g if g < k else k
            return total

        lo, hi = 1, h
        while lo < hi:
            mid = (lo + hi) // 2
            if damage(mid) >= h:
                hi = mid
            else:
                lo = mid + 1
        out.append(str(lo))
    sys.stdout.write("\n".join(out) + "\n")


main()
