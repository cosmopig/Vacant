import sys


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    m = int(data[1])
    rows = data[2:2 + n]
    idx = 2 + n
    q = int(data[idx])
    queries = data[idx + 1: idx + 1 + 2 * q]

    INF = 10 ** 9
    # lam[y][x] = smallest left boundary l in [1..x] for which cell (y,x)
    # (empty) is exitable; INF for filled cells. Recurrence for empty cells:
    #   lam = min(x, lam[y-1][x], lam[y][x-1])   (y >= 2)
    #   lam = 1 for y == 1 (top row) or x == 1
    # lam[0][x] = 1 (virtual row above), lam[y][0] = INF.
    #
    # A subgrid of columns [l, r] is NOT determinable iff there is a cell
    # (y, x), y >= 2, l + 1 <= x <= r, such that (y,x), (y-1,x), (y,x-1)
    # are all non-exitable, i.e. l < min(lam of the three).
    # For column x define M[x] = max over y >= 2 of that min.
    # Query (l, r) is determinable iff max M[x] over x in [l+1, r] <= l.

    M = [0] * (m + 1)
    prev = [1] * (m + 1)  # lam[0][x] = 1
    DOT = 46

    for y in range(1, n + 1):
        row = rows[y - 1]
        curr = [0] * (m + 1)
        if y == 1:
            for x in range(1, m + 1):
                if row[x - 1] == DOT:
                    curr[x] = 1
                else:
                    curr[x] = INF
            prev = curr
            continue
        up = prev
        left = INF  # lam[y][0]
        for x in range(1, m + 1):
            if row[x - 1] == DOT:
                lam = up[x]
                if left < lam:
                    lam = left
                if x < lam:
                    lam = x
            else:
                lam = INF
            curr[x] = lam
            if x >= 2:
                t = lam if lam < up[x] else up[x]
                if left < t:
                    t = left
                if t > M[x]:
                    M[x] = t
            left = lam
        prev = curr

    # iterative segment tree for range max over M[0..m]
    size = 1
    while size < m + 1:
        size <<= 1
    tree = [0] * (2 * size)
    base = size
    for i in range(m + 1):
        tree[base + i] = M[i]
    for i in range(base - 1, 0, -1):
        a = tree[2 * i]
        b = tree[2 * i + 1]
        tree[i] = a if a >= b else b

    out = []
    ap = out.append
    qi = 0
    for _ in range(q):
        l = int(queries[qi]); r = int(queries[qi + 1]); qi += 2
        # max M[x] for x in [l+1, r]
        lo = l + 1 + base
        hi = r + base
        mx = 0
        while lo <= hi:
            if lo & 1:
                v = tree[lo]
                if v > mx:
                    mx = v
                lo += 1
            if not (hi & 1):
                v = tree[hi]
                if v > mx:
                    mx = v
                hi -= 1
            lo >>= 1
            hi >>= 1
        ap("YES" if mx <= l else "NO")
    sys.stdout.write("\n".join(out) + "\n")


main()
