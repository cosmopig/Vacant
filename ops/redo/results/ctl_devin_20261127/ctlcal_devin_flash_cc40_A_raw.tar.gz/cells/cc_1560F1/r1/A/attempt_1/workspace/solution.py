import sys


def _make_set(digits):
    mask = 0
    for d in digits:
        mask |= 1 << d
    min_d = min(digits)
    ngt = [-1] * 10
    for x in range(10):
        for d in digits:
            if d > x:
                if ngt[x] == -1 or d < ngt[x]:
                    ngt[x] = d
    return mask, min_d, tuple(ngt)


def _subsets(k):
    if k == 1:
        return [_make_set((d,)) for d in range(1, 10)]
    res = [_make_set((d,)) for d in range(1, 10)]
    for a in range(10):
        for b in range(a + 1, 10):
            res.append(_make_set((a, b)))
    return res


SETS1 = _subsets(1)
SETS2 = _subsets(2)


def solve(n, k):
    s = str(n)
    if len(set(s)) <= k:
        return n
    ds = [ord(c) - 48 for c in s]
    L = len(ds)
    sets = SETS1 if k == 1 else SETS2
    best = None
    for mask, min_d, ngt in sets:
        p = L
        for i, d in enumerate(ds):
            if not (mask >> d) & 1:
                p = i
                break
        if p == L:
            return n
        md = str(min_d)
        for j in range(p, -1, -1):
            g = ngt[ds[j]]
            if g != -1:
                cand = int(s[:j] + str(g) + md * (L - j - 1))
                if best is None or cand < best:
                    best = cand
                break
    return best


def main():
    data = sys.stdin.buffer.read().split()
    t = int(data[0])
    out = []
    idx = 1
    for _ in range(t):
        n = int(data[idx])
        k = int(data[idx + 1])
        idx += 2
        out.append(str(solve(n, k)))
    sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
