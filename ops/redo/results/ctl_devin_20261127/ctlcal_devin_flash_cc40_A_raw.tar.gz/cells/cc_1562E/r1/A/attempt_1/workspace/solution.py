import sys
from bisect import bisect_left


def solve(s):
    n = len(s)
    subs = set()
    for i in range(n):
        for j in range(i + 1, n + 1):
            subs.add(s[i:j])
    rank = {v: k for k, v in enumerate(sorted(subs))}
    tails = []
    for i in range(n):
        for j in range(i + 1, n + 1):
            r = rank[s[i:j]]
            k = bisect_left(tails, r)
            if k == len(tails):
                tails.append(r)
            else:
                tails[k] = r
    return len(tails)


def main():
    data = sys.stdin.read().split()
    t = int(data[0])
    pos = 1
    out = []
    for _ in range(t):
        n = int(data[pos]); pos += 1
        s = data[pos]; pos += 1
        out.append(str(solve(s)))
    sys.stdout.write("\n".join(out) + "\n")


main()
