import sys


def feasible(h, T):
    p = 0  # x_{i+1}
    q = 0  # x_{i+2}
    for i in range(len(h), 2, -1):
        hi = h[i - 1]
        B = hi + p + 2 * q - T
        if B < 0:
            return False
        u = B // 3
        a = hi // 3
        if u > a:
            u = a
        q = p
        p = u
    return h[0] + 2 * p >= T and h[1] + p + 2 * q >= T


def solve(h):
    lo = 0
    hi = sum(h) // len(h)
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if feasible(h, mid):
            lo = mid
        else:
            hi = mid - 1
    return lo


def main():
    data = sys.stdin.buffer.read().split()
    it = iter(data)
    t = int(next(it))
    out = []
    for _ in range(t):
        n = int(next(it))
        h = [int(next(it)) for _ in range(n)]
        out.append(str(solve(h)))
    sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
