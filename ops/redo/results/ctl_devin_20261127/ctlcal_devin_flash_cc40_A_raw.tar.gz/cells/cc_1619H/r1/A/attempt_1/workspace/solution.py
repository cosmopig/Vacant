import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos])
    q = int(data[pos + 1])
    pos += 2

    # p[i] = p_i, 1-indexed
    p = [0] * (n + 1)
    for i in range(1, n + 1):
        p[i] = int(data[pos])
        pos += 1

    out = []
    for _ in range(q):
        t = int(data[pos])
        x = int(data[pos + 1])
        y = int(data[pos + 2])
        pos += 3
        if t == 1:
            p[x], p[y] = p[y], p[x]
        else:
            i, k = x, y
            v = i
            for _ in range(k):
                v = p[v]
            out.append(str(v))

    sys.stdout.write("\n".join(out) + "\n")


main()
