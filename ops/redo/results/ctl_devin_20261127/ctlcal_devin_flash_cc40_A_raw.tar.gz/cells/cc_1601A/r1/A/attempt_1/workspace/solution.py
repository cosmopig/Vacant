import sys
from math import gcd, isqrt


def main():
    data = sys.stdin.buffer.read().split()
    it = iter(data)
    t = int(next(it))
    out = []
    for _ in range(t):
        n = int(next(it))
        cnt = [0] * 30
        for _ in range(n):
            x = int(next(it))
            for b in range(30):
                if (x >> b) & 1:
                    cnt[b] += 1
        g = 0
        for c in cnt:
            g = gcd(g, c)
        if g == 0:
            out.append(" ".join(map(str, range(1, n + 1))))
        else:
            divs = []
            for d in range(1, isqrt(g) + 1):
                if g % d == 0:
                    divs.append(d)
                    if d * d != g:
                        divs.append(g // d)
            divs.sort()
            out.append(" ".join(map(str, divs)))
    sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
