import sys


def main():
    data = sys.stdin.buffer.read().split()
    idx = 0
    t = int(data[idx]); idx += 1
    out = []
    for _ in range(t):
        n = int(data[idx]); k = int(data[idx + 1]); idx += 2
        a = list(map(int, data[idx:idx + n])); idx += n
        total = sum(a)
        R = total - k
        if R <= 0:
            out.append('0')
            continue
        a.sort()
        b1 = a[0]
        # suff[c] = sum of c largest elements
        suff = [0] * (n + 1)
        s = 0
        for i in range(n - 1, -1, -1):
            s += a[i]
            suff[n - i] = s
        best = None
        for c in range(n):  # c = number of copied (largest) elements, 0..n-1
            Sc = suff[c]
            # (c+1)*v <= b1 + Sc - R, and v <= b1
            q = (b1 + Sc - R) // (c + 1)
            v = q if q < b1 else b1
            cost = b1 - v + c
            if best is None or cost < best:
                best = cost
        out.append(str(best))
    sys.stdout.write('\n'.join(out) + '\n')


main()
