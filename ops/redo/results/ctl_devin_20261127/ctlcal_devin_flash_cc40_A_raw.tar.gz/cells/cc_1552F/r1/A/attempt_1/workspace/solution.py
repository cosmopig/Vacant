import sys
from bisect import bisect_right

MOD = 998244353


def main():
    data = sys.stdin.buffer.read().split()
    it = iter(data)
    n = int(next(it))
    xs = [0] * (n + 1)
    ys = [0] * (n + 1)
    ss = [0] * (n + 1)
    for i in range(1, n + 1):
        xs[i] = int(next(it))
        ys[i] = int(next(it))
        ss[i] = int(next(it))

    xlist = xs[1:]
    r = [0] * (n + 1)
    for i in range(1, n + 1):
        r[i] = bisect_right(xlist, ys[i]) + 1

    bit = [0] * (n + 2)
    ans = (xlist[-1] + 1) % MOD

    for i in range(n, 0, -1):
        q = 0
        p = i
        while p:
            q += bit[p]
            p -= p & -p
        q %= MOD
        ci = ss[i] + q
        if ci >= MOD:
            ci -= MOD

        p = r[i]
        while p <= n:
            v = bit[p] + ci
            bit[p] = v - MOD if v >= MOD else v
            p += p & -p

        ans += ci * (xs[i] - ys[i])
        ans %= MOD

    sys.stdout.write(str(ans) + "\n")


if __name__ == "__main__":
    main()
