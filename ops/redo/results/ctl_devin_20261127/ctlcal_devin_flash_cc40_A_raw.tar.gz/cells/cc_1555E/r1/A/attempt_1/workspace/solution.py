import sys


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    m = int(data[1])
    segs = []
    p = 2
    for _ in range(n):
        l = int(data[p])
        r = int(data[p + 1])
        w = int(data[p + 2])
        p += 3
        segs.append((w, l, r))
    segs.sort()
    W = [s[0] for s in segs]
    LL = [s[1] for s in segs]
    RR = [s[2] for s in segs]

    def connected(i, j):
        # Do segments i..j (in weight order) let us reach m from 1?
        arr = sorted(zip(LL[i:j + 1], RR[i:j + 1]))
        f = 1
        for l, r in arr:
            if l > f:
                break
            if r > f:
                f = r
                if f >= m:
                    return True
        return False

    ans = None
    for i in range(n):
        for j in range(i, n):
            if connected(i, j):
                c = W[j] - W[i]
                if ans is None or c < ans:
                    ans = c
                break
    print(ans)


main()
