from collections import defaultdict

def masks_for_row(row):
    n=len(row); out=[]
    for m in range(1<<n):
        ok=True
        for j,ch in enumerate(row):
            if ch=='.': continue
            want = 1 if ch=='S' else 0
            if ((m>>j)&1)!=want: ok=False; break
        if ok: out.append(m)
    return out

def check_row(up, selfm, down, n):
    for j in range(n):
        c=(selfm>>j)&1; cnt=0
        if up is not None and ((up>>j)&1)==c: cnt+=1
        if down is not None and ((down>>j)&1)==c: cnt+=1
        if j>0 and ((selfm>>(j-1))&1)==c: cnt+=1
        if j<n-1 and ((selfm>>(j+1))&1)==c: cnt+=1
        if cnt!=2: return False
    return True

def solve_all(grid, cap=10**9, keep_parent=False):
    n=len(grid)
    if n==1: return 0,None
    allowed=[masks_for_row(r) for r in grid]
    if any(not a for a in allowed): return 0,None
    # dp[(m_{k-1},m_k)] = count ; parent for reconstruction
    dp=defaultdict(int); par={}
    for m0 in allowed[0]:
        for m1 in allowed[1]:
            if check_row(None,m0,m1,n):
                dp[(m0,m1)]+=1
                if keep_parent: par[(m0,m1)]=(None,m0,m1)
    for k in range(1,n-1):
        nd=defaultdict(int); npar={}
        for (a,b),cnt in dp.items():
            for c in allowed[k+1]:
                if check_row(a,b,c,n):
                    key=(b,c)
                    nd[key]=min(cap,nd[key]+cnt)
                    if keep_parent and key not in npar:
                        npar[key]=((a,b),b,c)
        dp=nd
        if keep_parent: par=npar  # only last layer kept; need full history -> store per layer
        if not dp: return 0,None
    total=0; finals=[]
    for (a,b),cnt in dp.items():
        if check_row(a,b,None,n):
            total=min(cap,total+cnt); finals.append((a,b,cnt))
    return total,(dp,finals,allowed,par)

def reconstruct(grid):
    # returns one solution grid (list of str) assuming >=1 solution
    n=len(grid)
    allowed=[masks_for_row(r) for r in grid]
    # redo DP storing full parent layers
    layers=[]
    dp={(m0,m1):1 for m0 in allowed[0] for m1 in allowed[1] if check_row(None,m0,m1,n)}
    layer_par=[{} for _ in range(n)]
    # store parents: for state at step k (rows 0..k+1 fixed?), key=(m_{k},m_{k+1})
    # We'll keep list of dicts par[k] mapping key->(prevkey)
    pars=[]
    cur=dp
    parlist=[]
    # initial layer index 0 corresponds to rows (0,1)
    pl={key:None for key in cur}
    parlist.append(pl)
    for k in range(1,n-1):
        nd=defaultdict(int); pl={}
        for (a,b),cnt in cur.items():
            for c in allowed[k+1]:
                if check_row(a,b,c,n):
                    key=(b,c)
                    if key not in nd:
                        nd[key]=0; pl[key]=(a,b)
                    nd[key]+=1
        cur=nd; parlist.append(pl)
        if not cur: return None
    # find final state passing last-row check
    final=None
    for (a,b) in cur:
        if check_row(a,b,None,n): final=(a,b); break
    if final is None: return None
    # walk back: parlist[k] maps key at layer k -> prev key at layer k-1
    masks=[None]*n
    key=final
    # key=(m_{n-2},m_{n-1}) at layer index n-2
    masks[n-2],masks[n-1]=key
    for k in range(n-2,0,-1):
        prev=parlist[k][key]
        # prev=(m_{k-1},m_k); we know m_k = masks[k] already; set masks[k-1]
        masks[k-1]=prev[0]
        key=prev
    # layer0 key=(m0,m1): parlist[0] values None; set masks[0],masks[1]
    masks[0],masks[1]=key
    return [''.join('S' if (masks[i]>>j)&1 else 'G' for j in range(n)) for i in range(n)]
