from explore2 import masks_for_row, check_row
from collections import defaultdict

def all_solutions(grid):
    n=len(grid)
    allowed=[masks_for_row(r) for r in grid]
    cur={(m0,m1) for m0 in allowed[0] for m1 in allowed[1] if check_row(None,m0,m1,n)}
    # store paths: dict key->list of mask sequences (memory heavy but small n ok)
    paths={key:[key] for key in cur}  # key=(m_{k-1},m_k); store full mask list
    for k in range(1,n-1):
        nd=defaultdict(list)
        for (a,b),pls in paths.items():
            for c in allowed[k+1]:
                if check_row(a,b,c,n):
                    nd[(b,c)].extend([p+(c,) for p in pls])
        paths=nd
        if not paths: return []
    sols=[]
    for (a,b),pls in paths.items():
        if check_row(a,b,None,n):
            for p in pls:
                masks=list(p)  # p has masks for rows 0..n-1? length n
                sols.append([''.join('S' if (masks[i]>>j)&1 else 'G' for j in range(n)) for i in range(n)])
    return sols
