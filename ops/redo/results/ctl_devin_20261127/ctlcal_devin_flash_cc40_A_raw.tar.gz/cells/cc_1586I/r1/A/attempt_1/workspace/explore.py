import sys
from functools import lru_cache

def masks_for_row(row):
    n=len(row); out=[]
    for m in range(1<<n):
        ok=True
        for j,ch in enumerate(row):
            if ch=='.': continue
            bit=(m>>j)&1
            want = 1 if ch=='S' else 0
            if bit!=want: ok=False; break
        if ok: out.append(m)
    return out

def row_ok(prev2, prev, cur, n):
    # check cells of 'prev' row (row index i): neighbors up=prev2, down=cur, left/right within prev
    # prev2 may be None for top row? we handle boundaries: for row 0, up neighbor absent.
    # We'll call this only for interior rows where all three rows exist? Boundary rows need care.
    for j in range(n):
        c=(prev>>j)&1
        cnt=0
        # up
        if prev2 is not None:
            if ((prev2>>j)&1)==c: cnt+=1
        # down
        if ((cur>>j)&1)==c: cnt+=1
        # left
        if j>0 and ((prev>>(j-1))&1)==c: cnt+=1
        # right
        if j<n-1 and ((prev>>(j+1))&1)==c: cnt+=1
        if cnt!=2: return False
    return True

def solve(grid, cap=3):
    n=len(grid)
    allowed=[masks_for_row(r) for r in grid]
    # state: (mask_{i-1}, mask_i) -> count, plus store one path
    # iterate i from 0..n-1 choosing mask_i; check row i-1 when we have mask_{i+1}? 
    # Simplify: state = (prev2, prev1) masks of last two rows; extend with cur=mask_i.
    # When adding row i, we can check row i-2? no...
    # Let's think: after choosing rows 0..k, cells of row k-1 are fully determined
    # (up=k-2, self=k-1, down=k). So when we add row k, check row k-1 using rows k-2,k-1,k.
    # Thus state needs rows k-1 and k? To check row k-1 we need k-2 too -> keep last two? 
    # When extending state (a=mask_{k-1}, b=mask_k) with c=mask_{k+1}: check row k-1 needs a? 
    # row k-1's up is row k-2 = ? not in state. Hmm keep three? 
    # Actually when we have rows ...,k-2,k-1,k and add k+1: check row k-1? its down is row k (known), up row k-2.
    # So to check row r we need rows r-1,r,r+1. With state = last two rows (k-1,k) and adding k+1,
    # we can check row k-1 only if we know k-2. So state must be last THREE? No:
    # check row k when adding row k+1 requires rows k-1,k,k+1. If state=(mask_{k-1},mask_k) then adding mask_{k+1} checks row k. Yes! state=last two rows.
    from collections import defaultdict
    # initial: choose row0, row1 -> state (m0,m1); but rows 0 and n-1 are boundaries (missing neighbor)
    # Handle boundary by treating missing neighbor as "not same".
    def check_row(r, up, selfm, down, n):
        # up/down may be None meaning no neighbor
        for j in range(n):
            c=(selfm>>j)&1; cnt=0
            if up is not None and ((up>>j)&1)==c: cnt+=1
            if down is not None and ((down>>j)&1)==c: cnt+=1
            if j>0 and ((selfm>>(j-1))&1)==c: cnt+=1
            if j<n-1 and ((selfm>>(j+1))&1)==c: cnt+=1
            if cnt!=2: return False
        return True
    # dp over (m_{k-1}, m_k) after processing k rows? Let's do iterative:
    # states after choosing rows 0..k: key=(mask_{k-1},mask_k) meaning we've fixed through row k,
    # and all rows <= k-2 fully checked.
    dp=defaultdict(int); parent={}
    # start: choose row0 and row1? For n>=2. For n==1 handle separately.
    if n==1:
        # single cell needs 2 same neighbors -> impossible always
        return 0,None
    for m0 in allowed[0]:
        for m1 in allowed[1]:
            # check row0 with up=None,down=m1
            if check_row(0,None,m0,m1,n):
                dp[(m0,m1)]=1
                parent[(0,(m0,m1))]=None
    # extend
    for k in range(1,n-1):
        # we have states (mask_{k-1},mask_k); add mask_{k+1}, check row k
        nd=defaultdict(int)
        for (a,b),cnt in dp.items():
            for c in allowed[k+1]:
                if check_row(k,a,b,c,n):
                    key=(b,c)
                    nd[key]=min(cap,nd[key]+cnt)
        dp=nd
        if not dp: return 0,None
    # after loop, states (mask_{n-2},mask_{n-1}); check last row n-1 with down=None
    total=0; lastkey=None
    for (a,b),cnt in dp.items():
        if check_row(n-1,a,b,None,n):
            total=min(cap,total+cnt); lastkey=(a,b)
    return total, dp, lastkey, allowed

def count_only(grid,cap=3):
    n=len(grid)
    if n%2==1: return 0
    r=solve(grid,cap)
    if r[0]==0: return 0
    total=0
    for (a,b),cnt in r[1].items():
        pass
    return r
