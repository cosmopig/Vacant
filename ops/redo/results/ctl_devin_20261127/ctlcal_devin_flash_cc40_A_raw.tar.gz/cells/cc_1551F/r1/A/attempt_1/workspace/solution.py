import sys
from collections import defaultdict

MOD = 10**9 + 7


def solve() -> None:
    data = sys.stdin.read().split()
    pos = 0
    t = int(data[pos]); pos += 1
    out = []
    for _ in range(t):
        n = int(data[pos]); k = int(data[pos + 1]); pos += 2
        adj = [[] for _ in range(n)]
        for _ in range(n - 1):
            u = int(data[pos]) - 1; v = int(data[pos + 1]) - 1; pos += 2
            adj[u].append(v)
            adj[v].append(u)

        if k == 2:
            out.append(str(n * (n - 1) // 2 % MOD))
            continue

        ans = 0
        for m in range(n):
            dist = [-1] * n
            comp = [-1] * n
            dist[m] = 0
            for nb in adj[m]:
                stack = [nb]
                dist[nb] = 1
                comp[nb] = nb
                while stack:
                    x = stack.pop()
                    for y in adj[x]:
                        if dist[y] < 0:
                            dist[y] = dist[x] + 1
                            comp[y] = comp[x]
                            stack.append(y)

            # counts[r][comp] = #vertices at distance r from m in component comp
            by_r = defaultdict(lambda: defaultdict(int))
            for v in range(n):
                if v != m:
                    by_r[dist[v]][comp[v]] += 1

            for cd in by_r.values():
                dp = [0] * (k + 1)
                dp[0] = 1
                for val in cd.values():
                    for j in range(k, 0, -1):
                        dp[j] = (dp[j] + dp[j - 1] * val) % MOD
                ans = (ans + dp[k]) % MOD

        out.append(str(ans))

    sys.stdout.write("\n".join(out) + "\n")


solve()
