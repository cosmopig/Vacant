import sys


def solve(n, k, a):
    # denominations are 10**a[i], a[0]=0, sorted ascending, a[-1] <= 9
    # f(s) = sum of decimal-digit block values of s, blocks split at exponents a[i]
    # s = V * 10**a[-1] + R, 0 <= R < 10**a[-1]
    # f(s) = V + g(R), where g(R) = sum of block values of R
    # lower blocks i=0..n-2 cover digit positions [a[i], a[i+1])
    #   block value v_i in [0, cap_i], cap_i = 10**(a[i+1]-a[i]) - 1
    #   R = sum v_i * 10**a[i],  g(R) = sum v_i,  M = sum cap_i = max g(R)
    an = a[-1]
    B = 10 ** an
    M = 0
    caps = []
    coeffs = []
    for i in range(n - 1):
        cap = 10 ** (a[i + 1] - a[i]) - 1
        caps.append(cap)
        coeffs.append(10 ** a[i])
        M += cap

    # need V + g(R) > k  =>  g(R) >= k - V + 1
    # smallest feasible V (s is increasing in V)
    V = max(0, k + 1 - M)
    tau = k - V + 1  # == min(k + 1, M), always <= M

    # min R with g(R) >= tau: fill cheapest coefficient (smallest a[i]) first
    R = 0
    rem = tau
    for cap, coeff in zip(caps, coeffs):
        if rem <= 0:
            break
        take = cap if cap < rem else rem
        R += take * coeff
        rem -= take
    return V * B + R


def main():
    data = sys.stdin.buffer.read().split()
    idx = 0
    t = int(data[idx]); idx += 1
    out = []
    for _ in range(t):
        n = int(data[idx]); k = int(data[idx + 1]); idx += 2
        a = [int(data[idx + j]) for j in range(n)]
        idx += n
        out.append(str(solve(n, k, a)))
    sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
