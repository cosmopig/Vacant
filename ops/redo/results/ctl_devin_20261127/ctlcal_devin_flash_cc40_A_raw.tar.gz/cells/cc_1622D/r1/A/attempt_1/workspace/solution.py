import sys

MOD = 998244353


def main():
    data = sys.stdin.read().split()
    n = int(data[0])
    k = int(data[1])
    s = data[2]
    m = s.count('1')

    if m == 0 or m == n:
        print(1)
        return
    if k == 0 or k > m:
        print(1)
        return
    if k == m:
        # The whole string can be shuffled.
        fact = [1] * (n + 1)
        for i in range(1, n + 1):
            fact[i] = fact[i - 1] * i % MOD
        invf = [1] * (n + 1)
        invf[n] = pow(fact[n], MOD - 2, MOD)
        for i in range(n, 0, -1):
            invf[i - 1] = invf[i] * i % MOD
        print(fact[n] * invf[m] % MOD * invf[n - m] % MOD)
        return

    bits = [1 if c == '1' else 0 for c in s]
    zf = [1 - b for b in bits]
    pref = [0] * (n + 1)
    for i, b in enumerate(bits):
        pref[i + 1] = pref[i] + b
    # g[r] = pref[r] - (s_r == 0), for 1-based r.
    g = [0] * (n + 1)
    for r in range(1, n + 1):
        g[r] = pref[r] - zf[r - 1]

    # positions of ones, 0-based indices into 1..n
    pos1 = [i + 1 for i, b in enumerate(bits) if b]

    fact = [1] * (n + 1)
    for i in range(1, n + 1):
        fact[i] = fact[i - 1] * i % MOD
    invf = [1] * (n + 1)
    invf[n] = pow(fact[n], MOD - 2, MOD)
    for i in range(n, 0, -1):
        invf[i - 1] = invf[i] * i % MOD

    ans = 1
    pref_l = pref
    fact_l = fact
    invf_l = invf
    g_l = g

    for l in range(1, n):
        const_l = pref_l[l - 1] + zf[l - 1]
        v = pref_l[l - 1] + k
        rmax = n if v >= m else pos1[v] - 1
        if rmax <= l:
            continue
        h = 0
        for r in range(l + 1, rmax + 1):
            z = g_l[r] - const_l
            if 0 <= z <= h:
                ans += fact_l[h] * invf_l[z] % MOD * invf_l[h - z] % MOD
            h += 1

    print(ans % MOD)


if __name__ == '__main__':
    main()
