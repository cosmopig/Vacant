import sys


def main():
    data = sys.stdin.buffer.read().split()
    it = iter(data)
    t = int(next(it))
    out = []
    for _ in range(t):
        n = int(next(it))
        a = [int(next(it)) for _ in range(n)]
        if n == 1:
            out.append("YES")
            continue
        if n == 2:
            out.append("YES" if a[0] <= a[1] else "NO")
            continue
        # duplicates let an odd effective permutation be realized
        seen = set()
        dup = False
        for v in a:
            if v in seen:
                dup = True
                break
            seen.add(v)
        if dup:
            out.append("YES")
            continue
        # distinct values: parity of permutation i -> rank of a[i]
        # rank[v] = number of elements strictly smaller than v
        cnt = [0] * (n + 1)
        for v in a:
            cnt[v] += 1
        rank = [0] * (n + 1)
        s = 0
        for v in range(1, n + 1):
            rank[v] = s
            s += cnt[v]
        f = [rank[v] for v in a]
        visited = bytearray(n)
        cycles = 0
        for i in range(n):
            if not visited[i]:
                cycles += 1
                j = i
                while not visited[j]:
                    visited[j] = 1
                    j = f[j]
        out.append("YES" if (n - cycles) % 2 == 0 else "NO")
    sys.stdout.write("\n".join(out) + "\n")


main()
