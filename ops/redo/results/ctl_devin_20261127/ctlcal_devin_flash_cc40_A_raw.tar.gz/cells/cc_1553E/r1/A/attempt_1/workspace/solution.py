import sys


def main() -> None:
    data = sys.stdin.buffer.read().split()
    it = iter(data)
    t = int(next(it))
    out = []

    for _ in range(t):
        n = int(next(it))
        m = int(next(it))
        p = [int(next(it)) - 1 for _ in range(n)]

        cnt = [0] * n
        for i, v in enumerate(p):
            cnt[(i - v) % n] += 1

        need = n - 2 * m
        ans = []
        if need <= n:
            pos = [0] * n
            for i, v in enumerate(p):
                pos[v] = i

            for k in range(n):
                if cnt[k] < need:
                    continue
                seen = bytearray(n)
                cycles = 0
                for s in range(n):
                    if seen[s]:
                        continue
                    cycles += 1
                    j = s
                    while not seen[j]:
                        seen[j] = 1
                        j = pos[(j - k) % n]
                if n - cycles <= m:
                    ans.append(k)

        out.append(str(len(ans)))
        out.extend(map(str, ans))

    sys.stdout.write(" ".join(out))


if __name__ == "__main__":
    main()
