import sys
from collections import defaultdict


def solve(s: str) -> int:
    n = len(s)
    # dp[(mod25, x_value)] = count; x_value is -1 until the first X is chosen
    dp = {(0, -1): 1}

    for i, ch in enumerate(s):
        ndp = defaultdict(int)
        first = i == 0 and n > 1
        for (mod, xv), cnt in dp.items():
            if ch == "X":
                digits = (range(10) if xv == -1 else (xv,))
            elif ch == "_":
                digits = range(10)
            else:
                digits = (ord(ch) - 48,)

            for d in digits:
                if first and d == 0:
                    continue
                nx = xv if ch != "X" else (d if xv == -1 else xv)
                if ch == "X" and xv != -1 and d != xv:
                    continue
                nm = (mod * 10 + d) % 25
                ndp[(nm, nx)] += cnt
        dp = ndp

    return sum(cnt for (mod, _), cnt in dp.items() if mod == 0)


def main() -> None:
    s = sys.stdin.readline().strip()
    print(solve(s))


if __name__ == "__main__":
    main()
