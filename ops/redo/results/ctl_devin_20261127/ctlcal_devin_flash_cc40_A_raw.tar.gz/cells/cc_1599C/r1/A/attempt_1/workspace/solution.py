import sys
from fractions import Fraction
from math import comb


def main():
    data = sys.stdin.read().split()
    n = int(data[0])
    p = Fraction(data[1])

    denom = 2 * comb(n, 3)
    for k in range(n + 1):
        un = n - k
        # success count x2 to stay integral:
        # T with 2 studied + 1 unstudied -> always win (1)
        # T with 3 studied -> always win (1)
        # T with 1 studied + 2 unstudied -> win with prob 1/2
        # T with 0 studied -> lose
        num = 2 * (comb(k, 2) * un + comb(k, 3)) + comb(k, 1) * comb(un, 2)
        if Fraction(num, denom) >= p:
            print(k)
            return


main()
