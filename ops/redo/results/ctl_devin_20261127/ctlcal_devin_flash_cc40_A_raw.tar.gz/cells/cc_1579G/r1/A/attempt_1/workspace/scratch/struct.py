def reach(a, cap=None):
    states={(0,0)}
    out=[states]
    for x in a:
        ns=set()
        for (h,d) in states:
            ns.add((h+x, max(d-x,0)))   # up
            ns.add((max(h-x,0), d+x))   # down
        if cap:
            ns={(h,d) for (h,d) in ns if h+d<=cap}
        states=ns
        out.append(states)
    return out

def show(a,cap=None):
    for k,S in enumerate(reach(a,cap)):
        print('step',k,'states',len(S))
        # print as grid: rows h, cols d
        hs=sorted(set(h for h,d in S)); ds=sorted(set(d for h,d in S))
        for h in hs:
            row=''.join('#' if (h,d) in S else '.' for d in range(0,max(ds)+1))
            print(f'{h:3d} {row}')
        print()

show([2,3,2])
