import random, time

def step_frontier(F, x):
    # F: list of (h,d) pareto-minimal, sorted by h asc (d desc)
    cand=[]
    for h,d in F:
        cand.append((h+x, max(d-x,0)))  # up
        cand.append((max(h-x,0), d+x))  # down
    # pareto-min filter: sort by h asc, keep decreasing d
    cand.sort()
    out=[]; bestd=None
    # we want minimal: iterate h asc, d should be strictly decreasing to be minimal
    # state (h,d) is dominated if exists (h'<=h, d'<=d). Sort by h asc, then d asc;
    # keep those with d < all previous d's? Let's do: sort by h asc, d asc; scan keeping min d seen.
    cand.sort(key=lambda t:(t[0],t[1]))
    mind=None
    for h,d in cand:
        if mind is None or d<mind:
            out.append((h,d)); mind=d
    return out

def solve(a):
    F=[(0,0)]
    for x in a:
        F=step_frontier(F,x)
    return min(h+d for h,d in F), len(F)

random.seed(0)
mx=0
for _ in range(200):
    n=random.randint(1,2000)
    a=[random.randint(1,1000) for _ in range(n)]
    t=time.time(); ans,fs=solve(a); dt=time.time()-t
    mx=max(mx,fs)
    if dt>0.5: print('slow',n,dt,fs,ans)
print('max frontier',mx)
# specific tests
tests=[[6,8,4,5],[5,3,5,3,5],[1,2,4,6,7,7,3],[8,6,5,1,2,2,3,6]]
for a in tests: print(a, solve(a))
