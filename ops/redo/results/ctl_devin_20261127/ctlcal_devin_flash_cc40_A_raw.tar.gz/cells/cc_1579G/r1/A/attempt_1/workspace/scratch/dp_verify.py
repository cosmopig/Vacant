import itertools, random

def brute(a):
    n=len(a); best=None
    for bits in itertools.product([1,-1], repeat=n-1):
        s=[1]+list(bits)
        p=0; mn=0; mx=0
        for i in range(n):
            p+=s[i]*a[i]
            mn=min(mn,p); mx=max(mx,p)
        r=mx-mn
        if best is None or r<best: best=r
    return best

def dp_ab(a):
    states={(0,0)}
    for x in a:
        ns=set()
        for (A,B) in states:
            ns.add((max(A-x,0), B+x))
            ns.add((A+x, max(B-x,0)))
        states=ns
    return min(A+B for (A,B) in states)

random.seed(2)
ok=True
for _ in range(500):
    n=random.randint(1,9)
    a=[random.randint(0,9) for _ in range(n)]
    b=brute(a); d=dp_ab(a)
    if b!=d:
        print('MISMATCH',a,b,d); ok=False; break
print('all ok' if ok else 'fail')
