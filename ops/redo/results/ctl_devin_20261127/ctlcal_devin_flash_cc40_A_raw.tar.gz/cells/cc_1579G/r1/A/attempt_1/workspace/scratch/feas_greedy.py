import itertools, random
from collections import deque

def exact_feas(a, C):
    # BFS over (h,d) with h+d<=C
    start=(0,0)
    seen={start}
    for x in a:
        ns=set()
        for h,d in seen:
            for nh,nd in ((h+x,max(d-x,0)),(max(h-x,0),d+x)):
                if nh+nd<=C: ns.add((nh,nd))
        if not ns: return False
        seen=ns
    return True

def greedy_feas(a, C, rule):
    h=d=0
    for x in a:
        opts=[]
        for nh,nd in ((h+x,max(d-x,0)),(max(h-x,0),d+x)):
            if nh+nd<=C: opts.append((nh,nd))
        if not opts: return False
        if len(opts)==1: h,d=opts[0]
        else:
            if rule=='minsum': h,d=min(opts,key=lambda t:t[0]+t[1])
            elif rule=='minmax': h,d=min(opts,key=lambda t:max(t))
            elif rule=='minimb': h,d=min(opts,key=lambda t:abs(t[0]-t[1]))
            elif rule=='maxmin': h,d=max(opts,key=lambda t:min(t))
    return True

rules=['minsum','minmax','minimb','maxmin']
random.seed(11)
res={r:[0,0] for r in rules}; ex={r:None for r in rules}
for _ in range(4000):
    n=random.randint(1,9)
    a=[random.randint(0,9) for _ in range(n)]
    # pick C around answer
    for C in range(0, 2*max(a)+2):
        e=exact_feas(a,C)
        for r in rules:
            g=greedy_feas(a,C,r)
            if g!=e:
                res[r][1]+=1
                if ex[r] is None: ex[r]=(a,C,e,g)
            else: res[r][0]+=1
for r in rules:
    print(r,'correct',res[r][0],'wrong',res[r][1],'ex',ex[r])
