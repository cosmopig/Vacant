import itertools, random

def brute(a):
    n=len(a); best=None
    for bits in itertools.product([1,-1], repeat=n-1):
        s=[1]+list(bits)
        p=0; mn=0; mx=0
        for i in range(n):
            p+=s[i]*a[i]
            mn=min(mn,p); mx=max(mx,p)
        r=mx-mn
        if best is None or r<best: best=r
    return best

# ratio search
random.seed(0)
worst=0; wa=None
for _ in range(3000):
    n=random.randint(2,9)
    a=[random.randint(1,9) for _ in range(n)]
    b=brute(a); m=max(a)
    if b>m:
        r=b/m
        if r>worst: worst=r; wa=a
print('worst ratio', worst, wa, brute(wa) if wa else None)

# also check: is answer always <= 2*max?
bad=[]
for _ in range(3000):
    n=random.randint(2,9)
    a=[random.randint(1,9) for _ in range(n)]
    b=brute(a)
    if b>2*max(a): bad.append((a,b))
print('exceed 2max:', bad[:5], len(bad))
