import random
def reach(a):
    states={(0,0)}
    for x in a:
        ns=set()
        for (h,d) in states:
            ns.add((h+x, max(d-x,0)))
            ns.add((max(h-x,0), d+x))
        states=ns
    return states

random.seed(5)
for _ in range(5):
    n=random.randint(6,9)
    a=[random.randint(1,9) for _ in range(n)]
    S=reach(a)
    print('a=',a,'states',len(S))
    from collections import defaultdict
    diag=defaultdict(list)
    for h,d in S: diag[h+d].append(h)
    for c in sorted(diag):
        hs=sorted(diag[c])
        # check interval
        intervals=[]; s=hs[0]; prev=hs[0]
        for v in hs[1:]:
            if v==prev+1: prev=v
            else: intervals.append((s,prev)); s=prev=v
        intervals.append((s,prev))
        print('  C=%d h-range %s count=%d intervals=%s'%(c,(min(hs),max(hs)),len(hs),intervals if len(intervals)<=4 else 'many(%d)'%len(intervals)))
