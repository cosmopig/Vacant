import itertools, random

def brute(a):
    n=len(a); best=None
    for bits in itertools.product([1,-1], repeat=n-1):
        s=[1]+list(bits)
        p=0; mn=0; mx=0
        for i in range(n):
            p+=s[i]*a[i]
            mn=min(mn,p); mx=max(mx,p)
        r=mx-mn
        if best is None or r<best: best=r
    return best

def dp_ab(a):
    states={(0,0)}
    for x in a:
        ns=set()
        for (A,B) in states:
            ns.add((max(A-x,0), B+x))
            ns.add((A+x, max(B-x,0)))
        states=ns
    return min(A+B for (A,B) in states), states

def greedy(a, rule):
    h=d=0
    for x in a:
        # up: h'=h+x, d'=max(d-x,0); down: h'=max(h-x,0), d'=d+x
        up=(h+x, max(d-x,0)); dn=(max(h-x,0), d+x)
        cu=up[0]+up[1]; cd=dn[0]+dn[1]
        if rule=='minC':
            h,d = up if cu<=cd else dn
        elif rule=='minC_bal':
            if cu!=cd: h,d = up if cu<cd else dn
            else: h,d = up if abs(up[0]-up[1])<=abs(dn[0]-dn[1]) else dn
        elif rule=='minC_maxmin':
            if cu!=cd: h,d = up if cu<cd else dn
            else: h,d = up if min(up)<=min(dn) else dn
    return h+d

rules=['minC','minC_bal','minC_maxmin']
random.seed(3)
res={r:[0,0] for r in rules}
fails={r:[] for r in rules}
for _ in range(2000):
    n=random.randint(1,9)
    a=[random.randint(0,9) for _ in range(n)]
    b=brute(a)
    for r in rules:
        g=greedy(a,r)
        if g==b: res[r][0]+=1
        else:
            res[r][1]+=1
            if len(fails[r])<3: fails[r].append((a,b,g))
for r in rules:
    print(r, res[r], fails[r])
