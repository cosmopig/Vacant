import random
from collections import Counter

def step_frontier(F, x):
    cand=[]
    for h,d in F:
        cand.append((h+x, max(d-x,0)))
        cand.append((max(h-x,0), d+x))
    cand.sort(key=lambda t:(t[0],t[1]))
    out=[]; mind=None
    for h,d in cand:
        if mind is None or d<mind:
            out.append((h,d)); mind=d
    return out

def solve_dbg(a):
    F=[(0,0)]
    for x in a:
        F=step_frontier(F,x)
    return F

for a in [[5,3,5,3,5],[6,8,4,5],[1,2,4,6,7,7,3],[2,1,4,3,0],[4,7,4,9,9,5]]:
    F=solve_dbg(a)
    print(a,'->',F, 'sums',Counter(h+d for h,d in F))

random.seed(7)
multi=0
for _ in range(300):
    n=random.randint(1,12)
    a=[random.randint(0,9) for _ in range(n)]
    F=solve_dbg(a)
    sums=set(h+d for h,d in F)
    if len(sums)>1:
        multi+=1
        if multi<=5: print('multi',a,sorted(sums),F)
print('multi count',multi,'/300')
