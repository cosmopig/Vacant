import itertools, random

def brute(a):
    n=len(a)
    best=None
    for bits in itertools.product([1,-1], repeat=n-1):
        s=[1]+list(bits)
        p=0; mn=0; mx=0
        for i in range(n):
            p+=s[i]*a[i]
            mn=min(mn,p); mx=max(mx,p)
        r=mx-mn
        if best is None or r<best: best=r
    return best

random.seed(1)
for _ in range(40):
    n=random.randint(1,10)
    a=[random.randint(0,6) for _ in range(n)]
    print(a, brute(a))
