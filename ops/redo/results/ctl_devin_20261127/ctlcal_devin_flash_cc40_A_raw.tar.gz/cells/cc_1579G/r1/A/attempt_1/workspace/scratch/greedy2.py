import itertools, random

def brute(a):
    n=len(a); best=None
    for bits in itertools.product([1,-1], repeat=n-1):
        s=[1]+list(bits)
        p=0; mn=0; mx=0
        for i in range(n):
            p+=s[i]*a[i]
            mn=min(mn,p); mx=max(mx,p)
        r=mx-mn
        if best is None or r<best: best=r
    return best

def dp_ab(a):
    states={(0,0)}
    for x in a:
        ns=set()
        for (h,d) in states:
            ns.add((h+x, max(d-x,0)))
            ns.add((max(h-x,0), d+x))
        states=ns
    return min(h+d for (h,d) in states)

def greedy(a, rule):
    h=d=0
    for x in a:
        up=(h+x, max(d-x,0)); dn=(max(h-x,0), d+x)
        cu=up[0]+up[1]; cd=dn[0]+dn[1]
        iu=abs(up[0]-up[1]); idn=abs(dn[0]-dn[1])
        if rule=='C_then_imb':
            key=lambda t:(t[0]+t[1], abs(t[0]-t[1]))
            h,d = min([up,dn], key=key)
        elif rule=='imb_then_C':
            key=lambda t:(abs(t[0]-t[1]), t[0]+t[1])
            h,d = min([up,dn], key=key)
        elif rule=='balance_dir':
            # move to reduce imbalance; ties -> min C
            if h<d: h,d=up
            elif h>d: h,d=dn
            else:
                h,d = up if cu<=cd else dn
    return h+d

rules=['C_then_imb','imb_then_C','balance_dir']
random.seed(4)
for r in rules:
    bad=0; ex=None
    for _ in range(3000):
        n=random.randint(1,9)
        a=[random.randint(0,9) for _ in range(n)]
        b=brute(a); g=greedy(a,r)
        if g!=b:
            bad+=1
            if ex is None: ex=(a,b,g)
    print(r,'bad',bad,'ex',ex)
