import random

def step_frontier(F, x):
    cand=[]
    for h,d in F:
        cand.append((h+x, max(d-x,0)))
        cand.append((max(h-x,0), d+x))
    cand.sort(key=lambda t:(t[0],t[1]))
    out=[]; mind=None
    for h,d in cand:
        if mind is None or d<mind:
            out.append((h,d)); mind=d
    return out

def solve_dbg(a):
    F=[(0,0)]
    for x in a:
        F=step_frontier(F,x)
    return F

random.seed(1)
a=[random.randint(1,1000) for _ in range(300)]
F=solve_dbg(a)
print('n=300 frontier size',len(F))
hs=[h for h,d in F]; ds=[d for h,d in F]
print('h range',min(hs),max(hs),'d range',min(ds),max(ds))
# gaps in h
gaps=[hs[i+1]-hs[i] for i in range(len(hs)-1)]
from collections import Counter
print('gap counts',Counter(gaps).most_common(10))
print('first 30:',F[:30])
print('last 10:',F[-10:])
# are h,d related linearly?
print('sample mid:',F[len(F)//2-5:len(F)//2+5])
