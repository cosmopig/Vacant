import itertools

def brute(a):
    n=len(a); best=None
    for bits in itertools.product([1,-1], repeat=n-1):
        s=[1]+list(bits)
        p=0; mn=0; mx=0
        for i in range(n):
            p+=s[i]*a[i]
            mn=min(mn,p); mx=max(mx,p)
        r=mx-mn
        if best is None or r<best: best=r
    return best

for B in [3,5,8]:
    for x in range(0,B+1):
        print([B,x,B], brute([B,x,B]))
print('---')
for a in [[5,2,5,2,5],[5,5,5],[5,1,5,1,5],[6,4,6],[7,3,7,3,7],[4,4,4,4],[3,1,3,1,3,1,3]]:
    print(a, brute(a))
