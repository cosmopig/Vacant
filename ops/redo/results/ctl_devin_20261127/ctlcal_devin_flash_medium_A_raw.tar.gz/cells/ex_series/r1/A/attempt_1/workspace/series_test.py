# These tests are auto-generated with test data from:
# https://github.com/exercism/problem-specifications/tree/main/exercises/series/canonical-data.json
# File last updated on 2023-07-19

import unittest

from series import (
    slices,
)


class SeriesTest(unittest.TestCase):
    def test_slices_of_one_from_one(self):
        self.assertEqual(slices("1", 1), ["1"])

    def test_slices_of_one_from_two(self):
        self.assertEqual(slices("12", 1), ["1", "2"])





    def test_slice_length_is_too_large(self):
        with self.assertRaises(ValueError) as err:
            slices("12345", 6)
        self.assertEqual(type(err.exception), ValueError)
        self.assertEqual(
            err.exception.args[0], "slice length cannot be greater than series length"
        )

    def test_slice_length_is_way_too_large(self):
        with self.assertRaises(ValueError) as err:
            slices("12345", 42)
        self.assertEqual(type(err.exception), ValueError)
        self.assertEqual(
            err.exception.args[0], "slice length cannot be greater than series length"
        )


    def test_slice_length_cannot_be_negative(self):
        with self.assertRaises(ValueError) as err:
            slices("123", -1)
        self.assertEqual(type(err.exception), ValueError)
        self.assertEqual(err.exception.args[0], "slice length cannot be negative")

