DIGITS = {
    (" _ ", "| |", "|_|", "   "): "0",
    ("   ", "  |", "  |", "   "): "1",
    (" _ ", " _|", "|_ ", "   "): "2",
    (" _ ", " _|", " _|", "   "): "3",
    ("   ", "|_|", "  |", "   "): "4",
    (" _ ", "|_ ", " _|", "   "): "5",
    (" _ ", "|_ ", "|_|", "   "): "6",
    (" _ ", "  |", "  |", "   "): "7",
    (" _ ", "|_|", "|_|", "   "): "8",
    (" _ ", "|_|", " _|", "   "): "9",
}


def _is_blank(row):
    return all(c == " " for c in row)


def convert(input_grid):
    height = len(input_grid)
    if height == 0 or height % 4 != 0:
        raise ValueError("Number of input lines is not a multiple of four")

    width = len(input_grid[0])
    if width % 3 != 0:
        raise ValueError("Number of input columns is not a multiple of three")

    lines = []

    for block_start in range(0, height, 4):
        block = [row.ljust(width) for row in input_grid[block_start:block_start + 4]]
        if all(_is_blank(row) for row in block):
            continue

        line = ""
        for cell in range(width // 3):
            key = tuple(row[cell * 3:(cell + 1) * 3] for row in block)
            line += DIGITS.get(key, "?")
        lines.append(line)

    return ",".join(lines)
