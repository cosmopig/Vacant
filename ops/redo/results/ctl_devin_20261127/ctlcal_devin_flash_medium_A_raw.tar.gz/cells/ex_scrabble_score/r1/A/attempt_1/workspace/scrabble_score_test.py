# These tests are auto-generated with test data from:
# https://github.com/exercism/problem-specifications/tree/main/exercises/scrabble-score/canonical-data.json
# File last updated on 2023-07-19

import unittest

from scrabble_score import (
    score,
)


class ScrabbleScoreTest(unittest.TestCase):
    def test_lowercase_letter(self):
        self.assertEqual(score("a"), 1)

    def test_uppercase_letter(self):
        self.assertEqual(score("A"), 1)


    def test_short_word(self):
        self.assertEqual(score("at"), 2)





    def test_english_like_word(self):
        self.assertEqual(score("pinata"), 8)

    def test_empty_input(self):
        self.assertEqual(score(""), 0)

