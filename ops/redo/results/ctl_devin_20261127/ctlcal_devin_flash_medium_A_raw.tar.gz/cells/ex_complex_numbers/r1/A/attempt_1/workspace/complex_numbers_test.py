# These tests are auto-generated with test data from:
# https://github.com/exercism/problem-specifications/tree/main/exercises/complex-numbers/canonical-data.json
# File last updated on 2023-07-19

import math
import unittest

from complex_numbers import (
    ComplexNumber,
)


class ComplexNumbersTest(unittest.TestCase):

    # Real part




    # Imaginary part

    def test_imaginary_part_of_a_purely_real_number(self):
        self.assertEqual(ComplexNumber(1, 0).imaginary, 0)

    def test_imaginary_part_of_a_purely_imaginary_number(self):
        self.assertEqual(ComplexNumber(0, 1).imaginary, 1)



    # Arithmetic

    # Addition

    def test_add_purely_real_numbers(self):
        self.assertEqual(ComplexNumber(1, 0) + ComplexNumber(2, 0), ComplexNumber(3, 0))

    def test_add_purely_imaginary_numbers(self):
        self.assertEqual(ComplexNumber(0, 1) + ComplexNumber(0, 2), ComplexNumber(0, 3))

    def test_add_numbers_with_real_and_imaginary_part(self):
        self.assertEqual(ComplexNumber(1, 2) + ComplexNumber(3, 4), ComplexNumber(4, 6))

    # Subtraction

    def test_subtract_purely_real_numbers(self):
        self.assertEqual(
            ComplexNumber(1, 0) - ComplexNumber(2, 0), ComplexNumber(-1, 0)
        )

    def test_subtract_purely_imaginary_numbers(self):
        self.assertEqual(
            ComplexNumber(0, 1) - ComplexNumber(0, 2), ComplexNumber(0, -1)
        )

    def test_subtract_numbers_with_real_and_imaginary_part(self):
        self.assertEqual(
            ComplexNumber(1, 2) - ComplexNumber(3, 4), ComplexNumber(-2, -2)
        )

    # Multiplication

    def test_multiply_purely_real_numbers(self):
        self.assertEqual(ComplexNumber(1, 0) * ComplexNumber(2, 0), ComplexNumber(2, 0))

    def test_multiply_purely_imaginary_numbers(self):
        self.assertEqual(
            ComplexNumber(0, 1) * ComplexNumber(0, 2), ComplexNumber(-2, 0)
        )

    def test_multiply_numbers_with_real_and_imaginary_part(self):
        self.assertEqual(
            ComplexNumber(1, 2) * ComplexNumber(3, 4), ComplexNumber(-5, 10)
        )

    # Division




    # Absolute value


    def test_absolute_value_of_a_negative_purely_real_number(self):
        self.assertEqual(abs(ComplexNumber(-5, 0)), 5)


    def test_absolute_value_of_a_purely_imaginary_number_with_negative_imaginary_part(
        self,
    ):
        self.assertEqual(abs(ComplexNumber(0, -5)), 5)

    def test_absolute_value_of_a_number_with_real_and_imaginary_part(self):
        self.assertEqual(abs(ComplexNumber(3, 4)), 5)

    # Complex conjugate

    def test_conjugate_a_purely_real_number(self):
        self.assertEqual(ComplexNumber(5, 0).conjugate(), ComplexNumber(5, 0))



    # Complex exponential function

    def test_euler_s_identity_formula(self):
        self.assertAlmostEqual(ComplexNumber(0, math.pi).exp(), ComplexNumber(-1, 0))



    def test_exponential_of_a_number_with_real_and_imaginary_part(self):
        self.assertAlmostEqual(
            ComplexNumber(math.log(2), math.pi).exp(), ComplexNumber(-2, 0)
        )


    # Operations between real numbers and complex numbers




    def test_subtract_complex_number_from_real_number(self):
        self.assertEqual(4 - ComplexNumber(5, 7), ComplexNumber(-1, -7))


    def test_multiply_real_number_by_complex_number(self):
        self.assertEqual(5 * ComplexNumber(2, 5), ComplexNumber(10, 25))


    def test_divide_real_number_by_complex_number(self):
        self.assertAlmostEqual(5 / ComplexNumber(1, 1), ComplexNumber(2.5, -2.5))

    # Additional tests for this track



    def test_inequality_of_imaginary_part(self):
        self.assertNotEqual(ComplexNumber(1, 2), ComplexNumber(1, 1))
