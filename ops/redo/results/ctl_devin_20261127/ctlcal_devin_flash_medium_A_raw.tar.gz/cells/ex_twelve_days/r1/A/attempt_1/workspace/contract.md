# Contract

Write your solution to `twelve_days.py` in the root of this workspace. The file does not exist
yet; create it. Start from this skeleton and keep these names, because the tests import them:

```python
def recite(start_verse, end_verse):
    pass
```

- Put all of your code in `twelve_days.py`. Only use the Python standard library; do not
  install packages.
- Don't change the names of existing functions or classes, as they may be referenced from
  other code like unit tests.
- The tests for this task are in `twelve_days_test.py`. The tests are correct; don't change them. Run them
  with:

      python3 -m pytest -q twelve_days_test.py

  or, without pytest:

      python3 -m unittest twelve_days_test.py
