DAYS = [
    "first", "second", "third", "fourth", "fifth", "sixth",
    "seventh", "eighth", "ninth", "tenth", "eleventh", "twelfth",
]

GIFTS = [
    "a Partridge in a Pear Tree",
    "two Turtle Doves",
    "three French Hens",
    "four Calling Birds",
    "five Gold Rings",
    "six Geese-a-Laying",
    "seven Swans-a-Swimming",
    "eight Maids-a-Milking",
    "nine Ladies Dancing",
    "ten Lords-a-Leaping",
    "eleven Pipers Piping",
    "twelve Drummers Drumming",
]


def recite(start_verse, end_verse):
    verses = []
    for day in range(start_verse, end_verse + 1):
        parts = [GIFTS[i] for i in range(day - 1, -1, -1)]
        if len(parts) > 1:
            verses.append(
                f"On the {DAYS[day - 1]} day of Christmas my true love gave to me: "
                + ", ".join(parts[:-1])
                + f", and {parts[-1]}."
            )
        else:
            verses.append(
                f"On the {DAYS[day - 1]} day of Christmas my true love gave to me: {parts[0]}."
            )
    return verses
