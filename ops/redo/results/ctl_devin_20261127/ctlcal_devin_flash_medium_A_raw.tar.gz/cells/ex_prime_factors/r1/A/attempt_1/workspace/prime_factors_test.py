# These tests are auto-generated with test data from:
# https://github.com/exercism/problem-specifications/tree/main/exercises/prime-factors/canonical-data.json
# File last updated on 2026-02-19

import unittest

from prime_factors import (
    factors,
)


class PrimeFactorsTest(unittest.TestCase):


    def test_prime_number(self):
        self.assertEqual(factors(2), [2])





    def test_product_of_second_prime(self):
        self.assertEqual(factors(27), [3, 3, 3])

    def test_product_of_third_prime(self):
        self.assertEqual(factors(625), [5, 5, 5, 5])


    def test_product_of_primes_and_non_primes(self):
        self.assertEqual(factors(12), [2, 2, 3])

    def test_product_of_primes(self):
        self.assertEqual(factors(901255), [5, 17, 23, 461])

    def test_factors_include_a_large_prime(self):
        self.assertEqual(factors(93819012551), [11, 9539, 894119])
