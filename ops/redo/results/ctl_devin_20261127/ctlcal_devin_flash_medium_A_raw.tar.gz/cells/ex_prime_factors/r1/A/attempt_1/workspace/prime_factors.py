def factors(value):
    """Return the prime factors of the natural number `value`."""
    if value < 2:
        return []
    factors = []
    divisor = 2
    remaining = value
    while divisor * divisor <= remaining:
        while remaining % divisor == 0:
            factors.append(divisor)
            remaining //= divisor
        divisor += 1
    if remaining > 1:
        factors.append(remaining)
    return factors
