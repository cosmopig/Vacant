def find_fewest_coins(coins, target):
    if target < 0:
        raise ValueError("target can't be negative")

    # dp[amount] = (fewest number of coins, list of coin values)
    dp = [None] * (target + 1)
    dp[0] = (0, [])

    for amount in range(1, target + 1):
        best = None
        for coin in coins:
            if coin > 0 and coin <= amount and dp[amount - coin] is not None:
                count, solution = dp[amount - coin]
                candidate = (count + 1, solution + [coin])
                if best is None or candidate[0] < best[0]:
                    best = candidate
        dp[amount] = best

    if dp[target] is None:
        raise ValueError("can't make target with given coins")

    return sorted(dp[target][1])
