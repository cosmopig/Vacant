# These tests are auto-generated with test data from:
# https://github.com/exercism/problem-specifications/tree/main/exercises/flower-field/canonical-data.json
# File last updated on 2025-12-30

import unittest

from flower_field import (
    annotate,
)


class FlowerFieldTest(unittest.TestCase):
    def test_no_rows(self):
        self.assertEqual(annotate([]), [])

    def test_no_columns(self):
        self.assertEqual(annotate([""]), [""])


    def test_garden_full_of_flowers(self):
        self.assertEqual(annotate(["***", "***", "***"]), ["***", "***", "***"])

    def test_flower_surrounded_by_spaces(self):
        self.assertEqual(annotate(["   ", " * ", "   "]), ["111", "1*1", "111"])

    def test_space_surrounded_by_flowers(self):
        self.assertEqual(annotate(["***", "* *", "***"]), ["***", "*8*", "***"])


    def test_horizontal_line_flowers_at_edges(self):
        self.assertEqual(annotate(["*   *"]), ["*1 1*"])

    def test_vertical_line(self):
        self.assertEqual(annotate([" ", "*", " ", "*", " "]), ["1", "*", "2", "*", "1"])





    # Additional tests for this track

    def test_different_len(self):
        with self.assertRaises(ValueError) as err:
            annotate([" ", "*  ", "  "])
        self.assertEqual(type(err.exception), ValueError)
        self.assertEqual(
            err.exception.args[0], "The board is invalid with current input."
        )

