def annotate(garden):
    if not garden:
        return []

    width = len(garden[0])
    for row in garden:
        if len(row) != width or any(cell not in "* " for cell in row):
            raise ValueError("The board is invalid with current input.")

    annotated = []
    height = len(garden)

    for row_index, row in enumerate(garden):
        annotated_row = []
        for column_index, cell in enumerate(row):
            if cell != " ":
                annotated_row.append(cell)
                continue

            flower_count = sum(
                garden[row_index + row_offset][column_index + column_offset] == "*"
                for row_offset in range(-1, 2)
                for column_offset in range(-1, 2)
                if (row_offset or column_offset)
                and 0 <= row_index + row_offset < height
                and 0 <= column_index + column_offset < width
            )
            annotated_row.append(str(flower_count) if flower_count else " ")

        annotated.append("".join(annotated_row))

    return annotated
