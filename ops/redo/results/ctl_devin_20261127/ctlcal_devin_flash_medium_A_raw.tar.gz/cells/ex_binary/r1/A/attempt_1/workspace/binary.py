def parse_binary(binary_string):
    """Convert a binary string to its decimal equivalent."""
    for char in binary_string:
        if char not in "01":
            raise ValueError("Invalid binary literal: " + binary_string)

    result = 0
    for char in binary_string:
        result = result * 2 + int(char)
    return result
