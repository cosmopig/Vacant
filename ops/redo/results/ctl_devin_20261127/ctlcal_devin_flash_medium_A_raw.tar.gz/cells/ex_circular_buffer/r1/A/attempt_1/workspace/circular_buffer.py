class BufferFullException(BufferError):
    """Exception raised when CircularBuffer is full.

    message: explanation of the error.

    """
    def __init__(self, message):
        super().__init__(message)
        self.message = message


class BufferEmptyException(BufferError):
    """Exception raised when CircularBuffer is empty.

    message: explanation of the error.

    """
    def __init__(self, message):
        super().__init__(message)
        self.message = message


class CircularBuffer:
    def __init__(self, capacity):
        self.capacity = capacity
        self.buffer = [None] * capacity
        self.read_pos = 0
        self.write_pos = 0
        self.count = 0

    def read(self):
        if self.count == 0:
            raise BufferEmptyException("Circular buffer is empty")
        data = self.buffer[self.read_pos]
        self.buffer[self.read_pos] = None
        self.read_pos = (self.read_pos + 1) % self.capacity
        self.count -= 1
        return data

    def write(self, data):
        if self.count == self.capacity:
            raise BufferFullException("Circular buffer is full")
        self.buffer[self.write_pos] = data
        self.write_pos = (self.write_pos + 1) % self.capacity
        self.count += 1

    def overwrite(self, data):
        if self.count == self.capacity:
            self.buffer[self.read_pos] = data
            self.read_pos = (self.read_pos + 1) % self.capacity
            self.write_pos = self.read_pos
        else:
            self.buffer[self.write_pos] = data
            self.write_pos = (self.write_pos + 1) % self.capacity
            self.count += 1

    def clear(self):
        self.buffer = [None] * self.capacity
        self.read_pos = 0
        self.write_pos = 0
        self.count = 0
