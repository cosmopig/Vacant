PLANTS = {
    "G": "Grass",
    "C": "Clover",
    "R": "Radishes",
    "V": "Violets",
}

DEFAULT_STUDENTS = [
    "Alice", "Bob", "Charlie", "David", "Eve", "Fred",
    "Ginny", "Harriet", "Ileana", "Joseph", "Kincaid", "Larry",
]


class Garden:
    def __init__(self, diagram, students=DEFAULT_STUDENTS):
        self.students = sorted(students)
        rows = diagram.split("\n")
        self.plants_by_student = {
            name: [] for name in self.students
        }
        for row_index, row in enumerate(rows):
            for i, student in enumerate(self.students):
                cups = row[2 * i: 2 * i + 2]
                for cup in cups:
                    if cup in PLANTS:
                        self.plants_by_student[student].append(PLANTS[cup])

    def plants(self, student):
        return self.plants_by_student[student]
