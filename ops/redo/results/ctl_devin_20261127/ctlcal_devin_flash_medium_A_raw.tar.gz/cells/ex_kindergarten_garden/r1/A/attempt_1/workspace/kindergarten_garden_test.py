# These tests are auto-generated with test data from:
# https://github.com/exercism/problem-specifications/tree/main/exercises/kindergarten-garden/canonical-data.json
# File last updated on 2023-07-19

import unittest

from kindergarten_garden import (
    Garden,
)


class KindergartenGardenTest(unittest.TestCase):



    def test_partial_garden_second_student_s_garden(self):
        garden = Garden("VVCCGG\nVVCCGG")
        self.assertEqual(garden.plants("Bob"), ["Clover", "Clover", "Clover", "Clover"])

    def test_partial_garden_third_student_s_garden(self):
        garden = Garden("VVCCGG\nVVCCGG")
        self.assertEqual(garden.plants("Charlie"), ["Grass", "Grass", "Grass", "Grass"])


    def test_full_garden_for_bob_second_student_s_garden(self):
        garden = Garden("VRCGVVRVCGGCCGVRGCVCGCGV\nVRCCCGCRRGVCGCRVVCVGCGCV")
        self.assertEqual(garden.plants("Bob"), ["Clover", "Grass", "Clover", "Clover"])

    def test_full_garden_for_charlie(self):
        garden = Garden("VRCGVVRVCGGCCGVRGCVCGCGV\nVRCCCGCRRGVCGCRVVCVGCGCV")
        self.assertEqual(
            garden.plants("Charlie"), ["Violets", "Violets", "Clover", "Grass"]
        )

    def test_full_garden_for_david(self):
        garden = Garden("VRCGVVRVCGGCCGVRGCVCGCGV\nVRCCCGCRRGVCGCRVVCVGCGCV")
        self.assertEqual(
            garden.plants("David"), ["Radishes", "Violets", "Clover", "Radishes"]
        )



    def test_full_garden_for_ginny(self):
        garden = Garden("VRCGVVRVCGGCCGVRGCVCGCGV\nVRCCCGCRRGVCGCRVVCVGCGCV")
        self.assertEqual(garden.plants("Ginny"), ["Clover", "Grass", "Grass", "Clover"])

    def test_full_garden_for_harriet(self):
        garden = Garden("VRCGVVRVCGGCCGVRGCVCGCGV\nVRCCCGCRRGVCGCRVVCVGCGCV")
        self.assertEqual(
            garden.plants("Harriet"), ["Violets", "Radishes", "Radishes", "Violets"]
        )


    def test_full_garden_for_joseph(self):
        garden = Garden("VRCGVVRVCGGCCGVRGCVCGCGV\nVRCCCGCRRGVCGCRVVCVGCGCV")
        self.assertEqual(
            garden.plants("Joseph"), ["Violets", "Clover", "Violets", "Grass"]
        )



    # Additional tests for this track


    def test_students_are_unordered_last_student(self):
        garden = Garden(
            "VCRRGVRG\nRVGCCGCV", students=["Samantha", "Patricia", "Xander", "Roger"]
        )
        self.assertEqual(
            garden.plants("Xander"), ["Radishes", "Grass", "Clover", "Violets"]
        )
