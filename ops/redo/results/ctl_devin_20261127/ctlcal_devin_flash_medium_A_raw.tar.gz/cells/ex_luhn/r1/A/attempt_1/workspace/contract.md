# Contract

Write your solution to `luhn.py` in the root of this workspace. The file does not exist
yet; create it. Start from this skeleton and keep these names, because the tests import them:

```python
class Luhn:
    def __init__(self, card_num):
        pass

    def valid(self):
        pass
```

- Put all of your code in `luhn.py`. Only use the Python standard library; do not
  install packages.
- Don't change the names of existing functions or classes, as they may be referenced from
  other code like unit tests.
- The tests for this task are in `luhn_test.py`. The tests are correct; don't change them. Run them
  with:

      python3 -m pytest -q luhn_test.py

  or, without pytest:

      python3 -m unittest luhn_test.py
