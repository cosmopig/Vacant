# Contract

Write your solution to `word_search.py` in the root of this workspace. The file does not exist
yet; create it. Start from this skeleton and keep these names, because the tests import them:

```python
class Point:
    def __init__(self, x, y):
        self.x = None
        self.y = None

    def __eq__(self, other):
        return self.x == other.x and self.y == other.y


class WordSearch:
    def __init__(self, puzzle):
        pass

    def search(self, word):
        pass
```

- Put all of your code in `word_search.py`. Only use the Python standard library; do not
  install packages.
- Don't change the names of existing functions or classes, as they may be referenced from
  other code like unit tests.
- The tests for this task are in `word_search_test.py`. The tests are correct; don't change them. Run them
  with:

      python3 -m pytest -q word_search_test.py

  or, without pytest:

      python3 -m unittest word_search_test.py
