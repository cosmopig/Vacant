class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def __eq__(self, other):
        return self.x == other.x and self.y == other.y


class WordSearch:
    def __init__(self, puzzle):
        self.puzzle = puzzle
        self.height = len(puzzle)
        self.width = len(puzzle[0]) if puzzle else 0

    def _in_bounds(self, x, y):
        return 0 <= x < self.width and 0 <= y < self.height

    def search(self, word):
        directions = [
            (1, 0), (-1, 0), (0, 1), (0, -1),
            (1, 1), (1, -1), (-1, 1), (-1, -1),
        ]
        for y in range(self.height):
            for x in range(self.width):
                if self.puzzle[y][x] != word[0]:
                    continue
                for dx, dy in directions:
                    end_x, end_y = x, y
                    ok = True
                    for ch in word[1:]:
                        end_x += dx
                        end_y += dy
                        if not self._in_bounds(end_x, end_y) or \
                                self.puzzle[end_y][end_x] != ch:
                            ok = False
                            break
                    if ok:
                        return Point(x, y), Point(end_x, end_y)
        return None
