# Contract

Write your solution to `meetup.py` in the root of this workspace. The file does not exist
yet; create it. Start from this skeleton and keep these names, because the tests import them:

```python
# subclassing the built-in ValueError to create MeetupDayException
class MeetupDayException(ValueError):
    """Exception raised when the Meetup weekday and count do not result in a valid date.

    message: explanation of the error.

    """
    def __init__(self):
        pass


def meetup(year, month, week, day_of_week):
    pass
```

- Put all of your code in `meetup.py`. Only use the Python standard library; do not
  install packages.
- Don't change the names of existing functions or classes, as they may be referenced from
  other code like unit tests.
- The tests for this task are in `meetup_test.py`. The tests are correct; don't change them. Run them
  with:

      python3 -m pytest -q meetup_test.py

  or, without pytest:

      python3 -m unittest meetup_test.py
