import calendar
from datetime import date

# subclassing the built-in ValueError to create MeetupDayException
class MeetupDayException(ValueError):
    """Exception raised when the Meetup weekday and count do not result in a valid date.

    message: explanation of the error.

    """
    def __init__(self, message="That day does not exist."):
        self.message = message
        super().__init__(message)


_WEEKDAYS = {
    "Monday": 0,
    "Tuesday": 1,
    "Wednesday": 2,
    "Thursday": 3,
    "Friday": 4,
    "Saturday": 5,
    "Sunday": 6,
}


def meetup(year, month, week, day_of_week):
    if day_of_week not in _WEEKDAYS:
        raise MeetupDayException(f"Invalid weekday: {day_of_week}")
    if week not in ("first", "second", "third", "fourth", "fifth",
                    "last", "teenth"):
        raise MeetupDayException(f"Invalid week: {week}")

    first = date(year, month, 1)
    weekday = _WEEKDAYS[day_of_week]
    offset = (weekday - first.weekday()) % 7
    first_occurrence = 1 + offset

    if week == "teenth":
        day = first_occurrence + 7
        if day < 13:
            day += 7
    elif week == "last":
        last = date(year, month, calendar.monthrange(year, month)[1])
        day = last.day - ((last.weekday() - weekday) % 7)
    elif week == "fifth":
        day = first_occurrence + 28
        if day > calendar.monthrange(year, month)[1]:
            raise MeetupDayException("That day does not exist.")
    else:
        index = {"first": 1, "second": 2, "third": 3, "fourth": 4}[week]
        day = first_occurrence + 7 * (index - 1)

    return date(year, month, day)
