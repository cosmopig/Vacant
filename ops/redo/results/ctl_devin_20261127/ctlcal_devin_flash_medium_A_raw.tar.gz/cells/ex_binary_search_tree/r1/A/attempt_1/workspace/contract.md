# Contract

Write your solution to `binary_search_tree.py` in the root of this workspace. The file does not exist
yet; create it. Start from this skeleton and keep these names, because the tests import them:

```python
class TreeNode:
    def __init__(self, data, left=None, right=None):
        self.data = None
        self.left = None
        self.right = None

    def __str__(self):
        return f'TreeNode(data={self.data}, left={self.left}, right={self.right})'


class BinarySearchTree:
    def __init__(self, tree_data):
        pass

    def data(self):
        pass

    def sorted_data(self):
        pass
```

- Put all of your code in `binary_search_tree.py`. Only use the Python standard library; do not
  install packages.
- Don't change the names of existing functions or classes, as they may be referenced from
  other code like unit tests.
- The tests for this task are in `binary_search_tree_test.py`. The tests are correct; don't change them. Run them
  with:

      python3 -m pytest -q binary_search_tree_test.py

  or, without pytest:

      python3 -m unittest binary_search_tree_test.py
