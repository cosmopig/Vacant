class TreeNode:
    def __init__(self, data, left=None, right=None):
        self.data = data
        self.left = left
        self.right = right

    def __str__(self):
        return f'TreeNode(data={self.data}, left={self.left}, right={self.right})'


def _key(value):
    try:
        return (0, int(value))
    except (TypeError, ValueError):
        return (1, str(value))


class BinarySearchTree:
    def __init__(self, tree_data):
        self.root = None
        for item in tree_data:
            self.root = self._insert(self.root, item)

    @staticmethod
    def _insert(node, data):
        if node is None:
            return TreeNode(data)
        if _key(data) <= _key(node.data):
            node.left = BinarySearchTree._insert(node.left, data)
        else:
            node.right = BinarySearchTree._insert(node.right, data)
        return node

    def data(self):
        return self.root

    def sorted_data(self):
        result = []
        self._inorder(self.root, result)
        return result

    @staticmethod
    def _inorder(node, result):
        if node is None:
            return
        BinarySearchTree._inorder(node.left, result)
        result.append(node.data)
        BinarySearchTree._inorder(node.right, result)
