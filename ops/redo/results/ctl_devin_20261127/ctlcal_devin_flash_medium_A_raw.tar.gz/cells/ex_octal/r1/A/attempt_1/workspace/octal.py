def parse_octal(digits):
    if not digits:
        raise ValueError("empty input is not a valid octal number")
    result = 0
    for ch in digits:
        if ch < '0' or ch > '7':
            raise ValueError("invalid octal digit: %r" % ch)
        result = result * 8 + (ord(ch) - ord('0'))
    return result
