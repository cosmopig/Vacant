"""
This exercise stub and the test suite contain several enumerated constants.

Enumerated constants can be done with a NAME assigned to an arbitrary,
but unique value. An integer is traditionally used because it’s memory
efficient.
It is a common practice to export both constants and functions that work with
those constants (ex. the constants in the os, subprocess and re modules).

You can learn more here: https://en.wikipedia.org/wiki/Enumerated_type
"""

# Possible sublist categories.
# Change the values as you see fit.
SUBLIST = "SUBLIST"
SUPERLIST = "SUPERLIST"
EQUAL = "EQUAL"
UNEQUAL = "UNEQUAL"


def _contains(haystack, needle):
    """Return True if needle occurs as a contiguous subsequence of haystack."""
    n = len(needle)
    if n == 0:
        return True
    if n > len(haystack):
        return False
    for i in range(len(haystack) - n + 1):
        if haystack[i : i + n] == needle:
            return True
    return False


def sublist(list_one, list_two):
    if list_one == list_two:
        return EQUAL
    if len(list_one) > len(list_two):
        return SUPERLIST if _contains(list_one, list_two) else UNEQUAL
    return SUBLIST if _contains(list_two, list_one) else UNEQUAL
