# These tests are auto-generated with test data from:
# https://github.com/exercism/problem-specifications/tree/main/exercises/dnd-character/canonical-data.json
# File last updated on 2023-12-27

import unittest

from dnd_character import (
    Character,
    modifier,
)


class DndCharacterTest(unittest.TestCase):


    def test_ability_modifier_for_score_5_is_n3(self):
        self.assertEqual(modifier(5), -3)


    def test_ability_modifier_for_score_7_is_n2(self):
        self.assertEqual(modifier(7), -2)





    def test_ability_modifier_for_score_12_is_1(self):
        self.assertEqual(modifier(12), 1)

    def test_ability_modifier_for_score_13_is_1(self):
        self.assertEqual(modifier(13), 1)

    def test_ability_modifier_for_score_14_is_2(self):
        self.assertEqual(modifier(14), 2)


    def test_ability_modifier_for_score_16_is_3(self):
        self.assertEqual(modifier(16), 3)

    def test_ability_modifier_for_score_17_is_3(self):
        self.assertEqual(modifier(17), 3)

    def test_ability_modifier_for_score_18_is_4(self):
        self.assertEqual(modifier(18), 4)

    def test_random_ability_is_within_range(self):
        score = Character().ability()
        self.assertIs(score >= 3 and score <= 18, True)


