"""Detect palindrome products in a given range."""


def _validate(min_factor, max_factor):
    if min_factor > max_factor:
        raise ValueError("min must be <= max")


def _is_palindrome(n):
    s = str(n)
    return s == s[::-1]


def _find(min_factor, max_factor, want_largest):
    _validate(min_factor, max_factor)
    if min_factor < 1:
        min_factor = 1

    candidates = []
    for a in range(min_factor, max_factor + 1):
        for b in range(a, max_factor + 1):
            product = a * b
            if _is_palindrome(product):
                candidates.append((product, (a, b)))

    if not candidates:
        return None, []

    target = max(p[0] for p in candidates) if want_largest else min(p[0] for p in candidates)
    factors = sorted({tuple(sorted((a, b))) for p, (a, b) in candidates if p == target})
    return target, [list(pair) for pair in factors]


def largest(min_factor, max_factor):
    """Given a range of numbers, find the largest palindromes which
       are products of two numbers within that range.

    :param min_factor: int with a default value of 0
    :param max_factor: int
    :return: tuple of (palindrome, iterable).
             Iterable should contain both factors of the palindrome in an arbitrary order.
    """
    return _find(min_factor, max_factor, want_largest=True)


def smallest(min_factor, max_factor):
    """Given a range of numbers, find the smallest palindromes which
    are products of two numbers within that range.

    :param min_factor: int with a default value of 0
    :param max_factor: int
    :return: tuple of (palindrome, iterable).
    Iterable should contain both factors of the palindrome in an arbitrary order.
    """
    return _find(min_factor, max_factor, want_largest=False)
