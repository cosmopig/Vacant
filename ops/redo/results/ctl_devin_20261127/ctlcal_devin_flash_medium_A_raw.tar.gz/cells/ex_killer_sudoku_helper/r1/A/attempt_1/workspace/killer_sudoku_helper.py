def combinations(target, size, exclude):
    """Return all valid digit combinations for a cage of `size` cells
    summing to `target`, avoiding digits in `exclude` and repeats."""
    digits = [d for d in range(1, 10) if d not in exclude]
    results = []
    _search(target, size, digits, 0, [], results)
    return results


def _search(target, remaining, digits, start, current, results):
    if remaining == 0:
        if target == 0:
            results.append(current[:])
        return
    for i in range(start, len(digits)):
        d = digits[i]
        if d > target:
            break
        if len(digits) - i < remaining:
            break
        current.append(d)
        _search(target - d, remaining - 1, digits, i + 1, current, results)
        current.pop()
