# Contract

Write your solution to `killer_sudoku_helper.py` in the root of this workspace. The file does not exist
yet; create it. Start from this skeleton and keep these names, because the tests import them:

```python
def combinations(target, size, exclude):
    pass
```

- Put all of your code in `killer_sudoku_helper.py`. Only use the Python standard library; do not
  install packages.
- Don't change the names of existing functions or classes, as they may be referenced from
  other code like unit tests.
- The tests for this task are in `killer_sudoku_helper_test.py`. The tests are correct; don't change them. Run them
  with:

      python3 -m pytest -q killer_sudoku_helper_test.py

  or, without pytest:

      python3 -m unittest killer_sudoku_helper_test.py
