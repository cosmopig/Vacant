"""Atbash cipher implementation."""


def _atbash(text):
    result = []
    for char in text:
        if "a" <= char <= "z":
            result.append(chr(ord("z") - (ord(char) - ord("a"))))
        else:
            result.append(char)
    return "".join(result)


def encode(plain_text):
    cleaned = []
    for char in plain_text.lower():
        if "a" <= char <= "z" or char.isdigit():
            cleaned.append(char)
    encoded = _atbash("".join(cleaned))
    return " ".join(encoded[i:i + 5] for i in range(0, len(encoded), 5))


def decode(ciphered_text):
    cleaned = []
    for char in ciphered_text:
        if "a" <= char <= "z" or char.isdigit():
            cleaned.append(char)
    return _atbash("".join(cleaned))
