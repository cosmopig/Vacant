def annotate(minefield):
    if not minefield:
        return []

    width = len(minefield[0])
    for row in minefield:
        if len(row) != width or any(c not in " *" for c in row):
            raise ValueError("The board is invalid with current input.")

    height = len(minefield)
    result = []
    for r, row in enumerate(minefield):
        annotated = []
        for c, cell in enumerate(row):
            if cell == "*":
                annotated.append("*")
                continue
            count = 0
            for dr in (-1, 0, 1):
                for dc in (-1, 0, 1):
                    if dr == 0 and dc == 0:
                        continue
                    nr, nc = r + dr, c + dc
                    if 0 <= nr < height and 0 <= nc < width and minefield[nr][nc] == "*":
                        count += 1
            annotated.append(str(count) if count else " ")
        result.append("".join(annotated))
    return result
