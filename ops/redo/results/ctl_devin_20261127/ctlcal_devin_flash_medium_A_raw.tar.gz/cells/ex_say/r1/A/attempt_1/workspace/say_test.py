# These tests are auto-generated with test data from:
# https://github.com/exercism/problem-specifications/tree/main/exercises/say/canonical-data.json
# File last updated on 2023-07-19

import unittest

from say import (
    say,
)


class SayTest(unittest.TestCase):


    def test_fourteen(self):
        self.assertEqual(say(14), "fourteen")

    def test_twenty(self):
        self.assertEqual(say(20), "twenty")

    def test_twenty_two(self):
        self.assertEqual(say(22), "twenty-two")




    def test_one_hundred_twenty_three(self):
        self.assertEqual(say(123), "one hundred twenty-three")

    def test_two_hundred(self):
        self.assertEqual(say(200), "two hundred")


    def test_one_thousand(self):
        self.assertEqual(say(1000), "one thousand")


    def test_one_million(self):
        self.assertEqual(say(1000000), "one million")


    def test_one_billion(self):
        self.assertEqual(say(1000000000), "one billion")

    def test_a_big_number(self):
        self.assertEqual(
            say(987654321123),
            "nine hundred eighty-seven billion six hundred fifty-four million three hundred twenty-one thousand one hundred twenty-three",
        )



    # Additional tests for this track
    def test_one_hundred_seventy(self):
        self.assertEqual(say(170), "one hundred seventy")
