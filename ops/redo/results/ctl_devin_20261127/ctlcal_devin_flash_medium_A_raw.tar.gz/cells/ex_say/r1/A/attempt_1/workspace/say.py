ONES = [
    "zero", "one", "two", "three", "four", "five", "six", "seven",
    "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen",
    "fifteen", "sixteen", "seventeen", "eighteen", "nineteen",
]

TENS = [
    "", "", "twenty", "thirty", "forty", "fifty",
    "sixty", "seventy", "eighty", "ninety",
]

SCALES = [
    (10**12, "trillion"),
    (10**9, "billion"),
    (10**6, "million"),
    (10**3, "thousand"),
]


def _say_under_1000(n):
    parts = []
    hundreds, rem = divmod(n, 100)
    if hundreds:
        parts.append(f"{ONES[hundreds]} hundred")
    if rem:
        if rem < 20:
            parts.append(ONES[rem])
        else:
            tens, ones = divmod(rem, 10)
            parts.append(TENS[tens] + (f"-{ONES[ones]}" if ones else ""))
    return " ".join(parts)


def say(number):
    if not isinstance(number, int) or isinstance(number, bool):
        raise ValueError("input must be an integer")
    if number < 0 or number > 999_999_999_999:
        raise ValueError("input out of range")

    if number == 0:
        return "zero"

    parts = []
    for value, name in SCALES:
        if number >= value:
            quotient, number = divmod(number, value)
            parts.append(f"{_say_under_1000(quotient)} {name}")
    if number:
        parts.append(_say_under_1000(number))
    return " ".join(parts)
