class Node:
    def __init__(self, value, succeeding=None, previous=None):
        self.value = value
        self.succeeding = succeeding
        self.previous = previous


class LinkedList:
    def __init__(self):
        self.head = None
        self.tail = None
        self.length = 0

    def push(self, value):
        node = Node(value, previous=self.tail)
        if self.tail is not None:
            self.tail.succeeding = node
        else:
            self.head = node
        self.tail = node
        self.length += 1

    def unshift(self, value):
        node = Node(value, succeeding=self.head)
        if self.head is not None:
            self.head.previous = node
        else:
            self.tail = node
        self.head = node
        self.length += 1

    def pop(self):
        if self.length == 0:
            raise IndexError("List is empty")
        value = self.tail.value
        self.tail = self.tail.previous
        if self.tail is not None:
            self.tail.succeeding = None
        else:
            self.head = None
        self.length -= 1
        return value

    def shift(self):
        if self.length == 0:
            raise IndexError("List is empty")
        value = self.head.value
        self.head = self.head.succeeding
        if self.head is not None:
            self.head.previous = None
        else:
            self.tail = None
        self.length -= 1
        return value

    def delete(self, value):
        node = self.head
        while node is not None:
            if node.value == value:
                if node.previous is not None:
                    node.previous.succeeding = node.succeeding
                else:
                    self.head = node.succeeding
                if node.succeeding is not None:
                    node.succeeding.previous = node.previous
                else:
                    self.tail = node.previous
                self.length -= 1
                return
            node = node.succeeding
        raise ValueError("Value not found")

    def __iter__(self):
        node = self.head
        while node is not None:
            yield node.value
            node = node.succeeding

    def __len__(self):
        return self.length
