# These tests are auto-generated with test data from:
# https://github.com/exercism/problem-specifications/tree/main/exercises/linked-list/canonical-data.json
# File last updated on 2025-08-24

import unittest

from linked_list import (
    LinkedList,
)


class LinkedListTest(unittest.TestCase):
    def test_pop_gets_element_from_the_list(self):
        lst = LinkedList()
        lst.push(7)
        self.assertEqual(lst.pop(), 7)

    def test_push_pop_respectively_add_remove_at_the_end_of_the_list(self):
        lst = LinkedList()
        lst.push(11)
        lst.push(13)
        self.assertEqual(lst.pop(), 13)
        self.assertEqual(lst.pop(), 11)






    def test_count_a_list_with_items(self):
        lst = LinkedList()
        lst.push(37)
        lst.push(1)
        self.assertEqual(len(lst), 2)




    def test_deletes_the_only_element(self):
        lst = LinkedList()
        lst.push(61)
        lst.delete(61)
        self.assertEqual(len(lst), 0)

    def test_deletes_the_element_with_the_specified_value_from_the_list(self):
        lst = LinkedList()
        lst.push(71)
        lst.push(83)
        lst.push(79)
        lst.delete(83)
        self.assertEqual(len(lst), 2)
        self.assertEqual(lst.pop(), 79)
        self.assertEqual(lst.shift(), 71)


    def test_deletes_the_element_with_the_specified_value_from_the_list_re_assigns_head(
        self,
    ):
        lst = LinkedList()
        lst.push(71)
        lst.push(83)
        lst.push(79)
        lst.delete(83)
        self.assertEqual(len(lst), 2)
        self.assertEqual(lst.shift(), 71)
        self.assertEqual(lst.shift(), 79)



    def test_deletes_only_the_first_occurrence(self):
        lst = LinkedList()
        lst.push(73)
        lst.push(9)
        lst.push(9)
        lst.push(107)
        lst.delete(9)
        self.assertEqual(len(lst), 3)
        self.assertEqual(lst.pop(), 107)
        self.assertEqual(lst.pop(), 9)
        self.assertEqual(lst.pop(), 73)

    # Additional tests for this track
    def test_using_pop_raises_an_error_if_the_list_is_empty(self):
        lst = LinkedList()
        with self.assertRaises(IndexError) as err:
            lst.pop()

        to_validate = err.exception
        to_validate_msg = err.exception.args[0]

        self.assertEqual(type(to_validate), IndexError)
        self.assertEqual(to_validate_msg, "List is empty")


    def test_using_shift_raises_an_error_if_the_list_is_empty(self):
        lst = LinkedList()
        with self.assertRaises(IndexError) as err:
            lst.shift()

        to_validate = err.exception
        to_validate_msg = err.exception.args[0]

        self.assertEqual(type(to_validate), IndexError)
        self.assertEqual(to_validate_msg, "List is empty")

    def test_can_return_with_shift_and_then_raise_an_error_if_empty(self):
        lst = LinkedList()
        lst.push(1)
        lst.unshift(5)
        self.assertEqual(lst.pop(), 1)
        self.assertEqual(lst.shift(), 5)
        with self.assertRaises(IndexError) as err:
            lst.shift()

        to_validate = err.exception
        to_validate_msg = err.exception.args[0]

        self.assertEqual(type(to_validate), IndexError)
        self.assertEqual(to_validate_msg, "List is empty")

    def test_using_delete_raises_an_error_if_the_list_is_empty(self):
        lst = LinkedList()
        with self.assertRaises(ValueError) as err:
            lst.delete(0)

        to_validate = err.exception
        to_validate_msg = err.exception.args[0]

        self.assertEqual(type(to_validate), ValueError)
        self.assertEqual(to_validate_msg, "Value not found")

    def test_using_delete_raises_an_error_if_the_value_is_not_found(self):
        lst = LinkedList()
        lst.push(5)
        lst.push(7)
        self.assertEqual(lst.pop(), 7)
        with self.assertRaises(ValueError) as err:
            lst.delete(0)

        to_validate = err.exception
        to_validate_msg = err.exception.args[0]

        self.assertEqual(type(to_validate), ValueError)
        self.assertEqual(to_validate_msg, "Value not found")
