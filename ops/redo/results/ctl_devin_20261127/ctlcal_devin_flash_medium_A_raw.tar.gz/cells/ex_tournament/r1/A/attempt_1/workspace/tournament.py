def tally(rows):
    table = {}
    for row in rows:
        team_a, team_b, result = row.split(";")
        for team in (team_a, team_b):
            table.setdefault(team, {"MP": 0, "W": 0, "D": 0, "L": 0})
        table[team_a]["MP"] += 1
        table[team_b]["MP"] += 1
        if result == "draw":
            table[team_a]["D"] += 1
            table[team_b]["D"] += 1
        elif result == "win":
            table[team_a]["W"] += 1
            table[team_b]["L"] += 1
        elif result == "loss":
            table[team_a]["L"] += 1
            table[team_b]["W"] += 1

    lines = ["Team                           | MP |  W |  D |  L |  P"]
    teams = sorted(table, key=lambda t: (-((table[t]["W"] * 3) + table[t]["D"]), t))
    for team in teams:
        stats = table[team]
        points = stats["W"] * 3 + stats["D"]
        lines.append(
            f"{team:<30} | {stats['MP']:>2} | {stats['W']:>2} | {stats['D']:>2} | {stats['L']:>2} | {points:>2}"
        )
    return lines
