import calendar
import re
from datetime import datetime, timedelta


def delivery_date(start, description):
    start_dt = datetime.strptime(start, "%Y-%m-%dT%H:%M:%S")

    if description == "NOW":
        return (start_dt + timedelta(hours=2)).strftime("%Y-%m-%dT%H:%M:%S")

    if description == "ASAP":
        if start_dt.hour < 13:
            return start_dt.replace(hour=17, minute=0, second=0).strftime(
                "%Y-%m-%dT%H:%M:%S"
            )
        return (start_dt + timedelta(days=1)).replace(
            hour=13, minute=0, second=0
        ).strftime("%Y-%m-%dT%H:%M:%S")

    if description == "EOW":
        if start_dt.weekday() < 3:  # Monday, Tuesday, Wednesday
            days_ahead = 4 - start_dt.weekday()  # to Friday
            hour = 17
        else:  # Thursday, Friday
            days_ahead = (6 - start_dt.weekday()) % 7 or 7  # to Sunday
            hour = 20
        target = (start_dt + timedelta(days=days_ahead)).replace(
            hour=hour, minute=0, second=0
        )
        return target.strftime("%Y-%m-%dT%H:%M:%S")

    month_match = re.fullmatch(r"(\d+)M", description)
    if month_match:
        month = int(month_match.group(1))
        year = start_dt.year + 1 if start_dt.month >= month else start_dt.year
        day = _first_workday(year, month)
        return datetime(year, month, day, 8).strftime("%Y-%m-%dT%H:%M:%S")

    quarter_match = re.fullmatch(r"Q(\d+)", description)
    if quarter_match:
        quarter = int(quarter_match.group(1))
        current_quarter = (start_dt.month - 1) // 3 + 1
        year = start_dt.year + 1 if current_quarter > quarter else start_dt.year
        last_month = quarter * 3
        last_day = calendar.monthrange(year, last_month)[1]
        day = _last_workday(year, last_month, last_day)
        return datetime(year, last_month, day, 8).strftime("%Y-%m-%dT%H:%M:%S")

    raise ValueError(f"Unknown delivery date description: {description}")


def _first_workday(year, month):
    day = 1
    while datetime(year, month, day).weekday() >= 5:
        day += 1
    return day


def _last_workday(year, month, last_day):
    day = last_day
    while datetime(year, month, day).weekday() >= 5:
        day -= 1
    return day
