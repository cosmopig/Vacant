# These tests are auto-generated with test data from:
# https://github.com/exercism/problem-specifications/tree/main/exercises/swift-scheduling/canonical-data.json
# File last updated on 2026-09-30

import unittest

from swift_scheduling import (
    delivery_date,
)


class SwiftSchedulingTest(unittest.TestCase):

    def test_now_translates_to_two_hours_later(self):
        self.assertEqual(
            delivery_date("2012-02-13T09:00:00", "NOW"), "2012-02-13T11:00:00"
        )

    def test_asap_before_one_in_the_afternoon_translates_to_today_at_five_in_the_afternoon(
        self,
    ):
        self.assertEqual(
            delivery_date("1999-06-03T09:45:00", "ASAP"), "1999-06-03T17:00:00"
        )


    def test_asap_after_one_in_the_afternoon_translates_to_tomorrow_at_one_in_the_afternoon(
        self,
    ):
        self.assertEqual(
            delivery_date("2008-12-21T14:50:00", "ASAP"), "2008-12-22T13:00:00"
        )



    def test_eow_on_wednesday_translates_to_friday_at_five_in_the_afternoon(self):
        self.assertEqual(
            delivery_date("2005-09-14T11:00:00", "EOW"), "2005-09-16T17:00:00"
        )



    def test_eow_translates_to_leap_day(self):
        self.assertEqual(
            delivery_date("2008-02-25T10:30:00", "EOW"), "2008-02-29T17:00:00"
        )


    def test_11_m_in_the_eleventh_month_translates_to_the_first_workday_of_the_eleventh_month_of_next_year(
        self,
    ):
        self.assertEqual(
            delivery_date("2013-11-21T15:30:00", "11M"), "2014-11-03T08:00:00"
        )


    def test_q1_in_the_first_quarter_translates_to_the_last_workday_of_the_first_quarter_of_this_year(
        self,
    ):
        self.assertEqual(
            delivery_date("2003-01-01T10:45:00", "Q1"), "2003-03-31T08:00:00"
        )



    def test_q2_starting_in_the_last_month_of_the_second_quarter_translates_to_the_last_workday_of_the_second_quarter_of_this_year(
        self,
    ):
        self.assertEqual(
            delivery_date("2019-06-15T09:50:00", "Q2"), "2019-06-28T08:00:00"
        )
