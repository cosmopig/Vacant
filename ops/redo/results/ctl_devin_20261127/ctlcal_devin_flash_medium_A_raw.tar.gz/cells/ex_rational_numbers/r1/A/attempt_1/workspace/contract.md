# Contract

Write your solution to `rational_numbers.py` in the root of this workspace. The file does not exist
yet; create it. Start from this skeleton and keep these names, because the tests import them:

```python
class Rational:
    def __init__(self, numer, denom):
        self.numer = None
        self.denom = None

    def __eq__(self, other):
        return self.numer == other.numer and self.denom == other.denom

    def __repr__(self):
        return f'{self.numer}/{self.denom}'

    def __add__(self, other):
        pass

    def __sub__(self, other):
        pass

    def __mul__(self, other):
        pass

    def __truediv__(self, other):
        pass

    def __abs__(self):
        pass

    def __pow__(self, power):
        pass

    def __rpow__(self, base):
        pass
```

- Put all of your code in `rational_numbers.py`. Only use the Python standard library; do not
  install packages.
- Don't change the names of existing functions or classes, as they may be referenced from
  other code like unit tests.
- The tests for this task are in `rational_numbers_test.py`. The tests are correct; don't change them. Run them
  with:

      python3 -m pytest -q rational_numbers_test.py

  or, without pytest:

      python3 -m unittest rational_numbers_test.py
