from math import gcd


class Rational:
    def __init__(self, numer, denom):
        if denom == 0:
            raise ZeroDivisionError('denominator cannot be zero')
        g = gcd(abs(numer), abs(denom))
        numer //= g
        denom //= g
        if denom < 0:
            numer = -numer
            denom = -denom
        self.numer = numer
        self.denom = denom

    def __eq__(self, other):
        return self.numer == other.numer and self.denom == other.denom

    def __repr__(self):
        return f'{self.numer}/{self.denom}'

    def __add__(self, other):
        return Rational(self.numer * other.denom + other.numer * self.denom,
                        self.denom * other.denom)

    def __sub__(self, other):
        return Rational(self.numer * other.denom - other.numer * self.denom,
                        self.denom * other.denom)

    def __mul__(self, other):
        return Rational(self.numer * other.numer, self.denom * other.denom)

    def __truediv__(self, other):
        return Rational(self.numer * other.denom, self.denom * other.numer)

    def __abs__(self):
        return Rational(abs(self.numer), self.denom)

    def __pow__(self, power):
        if isinstance(power, int):
            if power >= 0:
                return Rational(self.numer ** power, self.denom ** power)
            m = abs(power)
            return Rational(self.denom ** m, self.numer ** m)
        return self.numer ** power / self.denom ** power

    def __rpow__(self, base):
        return (base ** self.numer) ** (1.0 / self.denom)
