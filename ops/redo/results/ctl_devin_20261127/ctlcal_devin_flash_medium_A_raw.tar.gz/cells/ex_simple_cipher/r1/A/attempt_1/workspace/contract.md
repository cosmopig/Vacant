# Contract

Write your solution to `simple_cipher.py` in the root of this workspace. The file does not exist
yet; create it. Start from this skeleton and keep these names, because the tests import them:

```python
class Cipher:
    def __init__(self, key=None):
        pass

    def encode(self, text):
        pass

    def decode(self, text):
        pass
```

- Put all of your code in `simple_cipher.py`. Only use the Python standard library; do not
  install packages.
- Don't change the names of existing functions or classes, as they may be referenced from
  other code like unit tests.
- The tests for this task are in `simple_cipher_test.py`. The tests are correct; don't change them. Run them
  with:

      python3 -m pytest -q simple_cipher_test.py

  or, without pytest:

      python3 -m unittest simple_cipher_test.py
