# These tests are auto-generated with test data from:
# https://github.com/exercism/problem-specifications/tree/main/exercises/simple-cipher/canonical-data.json
# File last updated on 2023-07-20

import re
import unittest

from simple_cipher import (
    Cipher,
)


class RandomKeyCipherTest(unittest.TestCase):

    def test_can_decode(self):
        cipher = Cipher()
        self.assertEqual(cipher.decode(cipher.key[0 : len("aaaaaaaaaa")]), "aaaaaaaaaa")

    def test_is_reversible(self):
        cipher = Cipher()
        plaintext = "abcdefghij"
        self.assertEqual(cipher.decode(cipher.encode(plaintext)), plaintext)



class SubstitutionCipherTest(unittest.TestCase):
    def test_can_encode(self):
        cipher = Cipher("abcdefghij")
        plaintext = "aaaaaaaaaa"
        self.assertEqual(cipher.encode(plaintext), cipher.key)


    def test_is_reversible(self):
        cipher = Cipher("abcdefghij")
        plaintext = "abcdefghij"
        self.assertEqual(cipher.decode(cipher.encode(plaintext)), plaintext)

    def test_can_double_shift_encode(self):
        cipher = Cipher("iamapandabear")
        plaintext = "iamapandabear"
        self.assertEqual(cipher.encode(plaintext), "qayaeaagaciai")


    def test_can_wrap_on_decode(self):
        cipher = Cipher("abcdefghij")
        self.assertEqual(cipher.decode("zabcdefghi"), "zzzzzzzzzz")


