import secrets
import string


class Cipher:
    def __init__(self, key=None):
        if key is None:
            key = "".join(
                secrets.choice(string.ascii_lowercase) for _ in range(100)
            )
        if not key or not key.isalpha() or not key.islower():
            raise ValueError("key must contain only lowercase letters")
        self.key = key

    def _shift(self, text, direction):
        result = []
        for i, ch in enumerate(text):
            if "a" <= ch <= "z":
                shift = ord(self.key[i % len(self.key)]) - ord("a")
                ch = chr((ord(ch) - ord("a") + direction * shift) % 26 + ord("a"))
            result.append(ch)
        return "".join(result)

    def encode(self, text):
        return self._shift(text, 1)

    def decode(self, text):
        return self._shift(text, -1)
