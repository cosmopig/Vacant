# Contract

Write your solution to `high_scores.py` in the root of this workspace. The file does not exist
yet; create it. Start from this skeleton and keep these names, because the tests import them:

```python
class HighScores:
    def __init__(self, scores):
        pass
```

- Put all of your code in `high_scores.py`. Only use the Python standard library; do not
  install packages.
- Don't change the names of existing functions or classes, as they may be referenced from
  other code like unit tests.
- The tests for this task are in `high_scores_test.py`. The tests are correct; don't change them. Run them
  with:

      python3 -m pytest -q high_scores_test.py

  or, without pytest:

      python3 -m unittest high_scores_test.py
