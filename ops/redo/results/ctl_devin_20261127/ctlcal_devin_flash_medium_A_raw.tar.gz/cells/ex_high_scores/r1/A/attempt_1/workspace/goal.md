# Instructions

Manage a game player's High Score list.

Your task is to build a high-score component of the classic Frogger game, one of the highest selling and most addictive games of all time, and a classic of the arcade era.
Your task is to write methods that return the highest score from the list, the last added score and the three highest scores.
# Instructions append

In this exercise, you're going to use and manipulate [`lists`][lists].
Python lists are very versatile, and you'll find yourself using them again and again in problems both simple and complex.

- [**Data Structures (Python 3 Documentation Tutorial)**](https://docs.python.org/3/tutorial/datastructures.html)
- [**Lists and Tuples in Python (Real Python)**](https://realpython.com/python-lists-tuples/)
- [**Python Lists (Google for Education)**](https://developers.google.com/edu/python/lists)

[lists]: https://docs.python.org/3/library/stdtypes.html#lists
