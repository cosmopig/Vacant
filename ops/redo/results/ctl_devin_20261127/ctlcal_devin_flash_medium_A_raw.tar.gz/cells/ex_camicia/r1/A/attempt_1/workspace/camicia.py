PAYMENT_VALUES = {"J": 1, "Q": 2, "K": 3, "A": 4}


def _signature(deck):
    return tuple("N" if card not in PAYMENT_VALUES else card for card in deck)


def simulate_game(player_a, player_b):
    decks = [list(player_a), list(player_b)]
    pile = []
    cards_played = 0
    tricks = 0
    total = len(decks[0]) + len(decks[1])

    seen = {(_signature(decks[0]), _signature(decks[1]))}
    starter = 0

    while True:
        turn = starter
        debtor = -1
        remaining = 0
        collector = -1

        while True:
            deck = decks[turn]
            if not deck:
                collector = 1 - turn
                break

            card = deck.pop(0)
            pile.append(card)
            cards_played += 1

            if card in PAYMENT_VALUES:
                collector = turn
                debtor = 1 - turn
                remaining = PAYMENT_VALUES[card]
                turn = debtor
            elif debtor != -1:
                remaining -= 1
                if remaining == 0:
                    break
            else:
                turn = 1 - turn

        decks[collector].extend(pile)
        pile.clear()
        tricks += 1

        if len(decks[0]) == total or len(decks[1]) == total:
            return {"status": "finished", "cards": cards_played, "tricks": tricks}

        signature = (_signature(decks[0]), _signature(decks[1]))
        if signature in seen:
            return {"status": "loop", "cards": cards_played, "tricks": tricks}
        seen.add(signature)
        starter = collector
