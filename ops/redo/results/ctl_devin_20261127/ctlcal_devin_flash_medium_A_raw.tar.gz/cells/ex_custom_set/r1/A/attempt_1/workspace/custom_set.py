class CustomSet:
    def __init__(self, elements=[]):
        self.elements = set(elements)

    def isempty(self):
        return not self.elements

    def __contains__(self, element):
        return element in self.elements

    def issubset(self, other):
        return self.elements <= other.elements

    def isdisjoint(self, other):
        return self.elements.isdisjoint(other.elements)

    def __eq__(self, other):
        if not isinstance(other, CustomSet):
            return NotImplemented
        return self.elements == other.elements

    def add(self, element):
        self.elements.add(element)

    def intersection(self, other):
        return CustomSet(self.elements & other.elements)

    def __sub__(self, other):
        return CustomSet(self.elements - other.elements)

    def __add__(self, other):
        return CustomSet(self.elements | other.elements)
