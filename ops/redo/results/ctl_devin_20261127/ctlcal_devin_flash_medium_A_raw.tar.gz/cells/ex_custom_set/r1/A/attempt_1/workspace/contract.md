# Contract

Write your solution to `custom_set.py` in the root of this workspace. The file does not exist
yet; create it. Start from this skeleton and keep these names, because the tests import them:

```python
class CustomSet:
    def __init__(self, elements=[]):
        pass

    def isempty(self):
        pass

    def __contains__(self, element):
        pass

    def issubset(self, other):
        pass

    def isdisjoint(self, other):
        pass

    def __eq__(self, other):
        pass

    def add(self, element):
        pass

    def intersection(self, other):
        pass

    def __sub__(self, other):
        pass

    def __add__(self, other):
        pass
```

- Put all of your code in `custom_set.py`. Only use the Python standard library; do not
  install packages.
- Don't change the names of existing functions or classes, as they may be referenced from
  other code like unit tests.
- The tests for this task are in `custom_set_test.py`. The tests are correct; don't change them. Run them
  with:

      python3 -m pytest -q custom_set_test.py

  or, without pytest:

      python3 -m unittest custom_set_test.py
