# These tests are auto-generated with test data from:
# https://github.com/exercism/problem-specifications/tree/main/exercises/custom-set/canonical-data.json
# File last updated on 2024-07-08

import unittest

from custom_set import (
    CustomSet,
)


class CustomSetTest(unittest.TestCase):

    def test_sets_with_elements_are_not_empty(self):
        sut = CustomSet([1])
        self.assertIs(sut.isempty(), False)

    def test_nothing_is_contained_in_an_empty_set(self):
        sut = CustomSet()
        self.assertNotIn(1, sut)


    def test_when_the_element_is_not_in_the_set(self):
        sut = CustomSet([1, 2, 3])
        self.assertNotIn(4, sut)

    def test_empty_set_is_a_subset_of_another_empty_set(self):
        set1 = CustomSet()
        set2 = CustomSet()
        self.assertIs(set1.issubset(set2), True)


    def test_non_empty_set_is_not_a_subset_of_empty_set(self):
        set1 = CustomSet([1])
        set2 = CustomSet()
        self.assertIs(set1.issubset(set2), False)

    def test_set_is_a_subset_of_set_with_exact_same_elements(self):
        set1 = CustomSet([1, 2, 3])
        set2 = CustomSet([1, 2, 3])
        self.assertIs(set1.issubset(set2), True)

    def test_set_is_a_subset_of_larger_set_with_same_elements(self):
        set1 = CustomSet([1, 2, 3])
        set2 = CustomSet([4, 1, 2, 3])
        self.assertIs(set1.issubset(set2), True)

    def test_set_is_not_a_subset_of_set_that_does_not_contain_its_elements(self):
        set1 = CustomSet([1, 2, 3])
        set2 = CustomSet([4, 1, 3])
        self.assertIs(set1.issubset(set2), False)



    def test_non_empty_set_is_disjoint_with_empty_set(self):
        set1 = CustomSet([1])
        set2 = CustomSet()
        self.assertIs(set1.isdisjoint(set2), True)


    def test_sets_are_disjoint_if_they_share_no_elements(self):
        set1 = CustomSet([1, 2])
        set2 = CustomSet([3, 4])
        self.assertIs(set1.isdisjoint(set2), True)

    def test_empty_sets_are_equal(self):
        set1 = CustomSet()
        set2 = CustomSet()
        self.assertEqual(set1, set2)


    def test_non_empty_set_is_not_equal_to_empty_set(self):
        set1 = CustomSet([1, 2, 3])
        set2 = CustomSet()
        self.assertNotEqual(set1, set2)




    def test_set_is_equal_to_a_set_constructed_from_an_array_with_duplicates(self):
        set1 = CustomSet([1])
        set2 = CustomSet([1, 1])
        self.assertEqual(set1, set2)

    def test_add_to_empty_set(self):
        sut = CustomSet()
        expected = CustomSet([3])
        sut.add(3)
        self.assertEqual(sut, expected)


    def test_adding_an_existing_element_does_not_change_the_set(self):
        sut = CustomSet([1, 2, 3])
        expected = CustomSet([1, 2, 3])
        sut.add(3)
        self.assertEqual(sut, expected)


    def test_intersection_of_an_empty_set_and_non_empty_set_is_an_empty_set(self):
        set1 = CustomSet()
        set2 = CustomSet([3, 2, 5])
        expected = CustomSet()
        self.assertEqual(set1.intersection(set2), expected)


    def test_intersection_of_two_sets_with_no_shared_elements_is_an_empty_set(self):
        set1 = CustomSet([1, 2, 3])
        set2 = CustomSet([4, 5, 6])
        expected = CustomSet()
        self.assertEqual(set1.intersection(set2), expected)


    def test_difference_of_two_empty_sets_is_an_empty_set(self):
        set1 = CustomSet()
        set2 = CustomSet()
        expected = CustomSet()
        self.assertEqual(set1 - set2, expected)



    def test_difference_of_two_non_empty_sets_is_a_set_of_elements_that_are_only_in_the_first_set(
        self,
    ):
        set1 = CustomSet([3, 2, 1])
        set2 = CustomSet([2, 4])
        expected = CustomSet([1, 3])
        self.assertEqual(set1 - set2, expected)



    def test_union_of_an_empty_set_and_non_empty_set_is_the_non_empty_set(self):
        set1 = CustomSet()
        set2 = CustomSet([2])
        expected = CustomSet([2])
        self.assertEqual(set1 + set2, expected)


