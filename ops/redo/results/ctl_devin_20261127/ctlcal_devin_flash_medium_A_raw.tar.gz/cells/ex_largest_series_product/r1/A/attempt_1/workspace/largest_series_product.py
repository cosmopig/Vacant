from functools import reduce
from operator import mul


def largest_product(series, size):
    if size < 0:
        raise ValueError("span must not be negative")
    if size > len(series):
        raise ValueError("span must not exceed string length")
    if not series.isdigit():
        raise ValueError("digits input must only contain digits")

    return max(
        reduce(mul, map(int, series[i:i + size]))
        for i in range(len(series) - size + 1)
    )
