# These tests are auto-generated with test data from:
# https://github.com/exercism/problem-specifications/tree/main/exercises/largest-series-product/canonical-data.json
# File last updated on 2025-06-20

import unittest

from largest_series_product import (
    largest_product,
)


class LargestSeriesProductTest(unittest.TestCase):



    def test_can_find_the_largest_product_of_3_with_numbers_in_order(self):
        self.assertEqual(largest_product("0123456789", 3), 504)

    def test_can_find_the_largest_product_of_3(self):
        self.assertEqual(largest_product("1027839564", 3), 270)


    def test_can_get_the_largest_product_of_a_big_number(self):
        self.assertEqual(
            largest_product("73167176531330624919225119674426574742355349194934", 6),
            23520,
        )


    def test_reports_zero_if_all_spans_include_zero(self):
        self.assertEqual(largest_product("99099", 3), 0)

    def test_rejects_span_longer_than_string_length(self):
        with self.assertRaises(ValueError) as err:
            largest_product("123", 4)
        self.assertEqual(type(err.exception), ValueError)
        self.assertEqual(err.exception.args[0], "span must not exceed string length")


    def test_rejects_invalid_character_in_digits(self):
        with self.assertRaises(ValueError) as err:
            largest_product("1234a5", 2)
        self.assertEqual(type(err.exception), ValueError)
        self.assertEqual(err.exception.args[0], "digits input must only contain digits")

    def test_rejects_negative_span(self):
        with self.assertRaises(ValueError) as err:
            largest_product("12345", -1)
        self.assertEqual(type(err.exception), ValueError)
        self.assertEqual(err.exception.args[0], "span must not be negative")

    # Additional tests for this track
