# Contract

Write your solution to `bank_account.py` in the root of this workspace. The file does not exist
yet; create it. Start from this skeleton and keep these names, because the tests import them:

```python
class BankAccount:
    def __init__(self):
        pass

    def get_balance(self):
        pass

    def open(self):
        pass

    def deposit(self, amount):
        pass

    def withdraw(self, amount):
        pass

    def close(self):
        pass
```

- Put all of your code in `bank_account.py`. Only use the Python standard library; do not
  install packages.
- Don't change the names of existing functions or classes, as they may be referenced from
  other code like unit tests.
- The tests for this task are in `bank_account_test.py`. The tests are correct; don't change them. Run them
  with:

      python3 -m pytest -q bank_account_test.py

  or, without pytest:

      python3 -m unittest bank_account_test.py
