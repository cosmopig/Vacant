import itertools
from collections import Counter

def good(sub):
    return max(sub)*min(sub) >= sum(sub)

def perfect(t):
    n=len(t)
    for mask in range(1,1<<n):
        sub=[t[i] for i in range(n) if mask>>i&1]
        if not good(sub):
            return False
    return True

n=6
cnt_all=0; cnt_restr=0; bad=0
for t in itertools.product(range(1,n+2), repeat=n):
    if perfect(t):
        cnt_all+=1
        if min(t)>=n-1: cnt_restr+=1
        else: bad+=1
print("all",cnt_all,"restr",cnt_restr,"bad",bad)
# distribution of counts over {5,6,7}
ms=Counter()
for t in itertools.product(range(n-1,n+2), repeat=n):
    if perfect(t):
        ms[tuple(sorted(Counter(t).items()))]+=1
print(len(ms),"multisets")
for k,v in sorted(ms.items()): print(k,v)
