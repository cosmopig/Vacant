from math import factorial

def valid_counts(n):
    vals=list(range(2,n+2))
    m=len(vals)
    counts=[0]*m
    res=[]
    def rec(i,left):
        if i==m:
            if left==0:
                sup=[vals[j] for j in range(m) if counts[j]>0]
                ok=True
                for x in range(len(sup)):
                    for y in range(x,len(sup)):
                        l,h=sup[x],sup[y]
                        s=sum(vals[j]*counts[j] for j in range(m) if l<=vals[j]<=h)
                        if s>l*h: ok=False;break
                    if not ok:break
                if ok: res.append(tuple(counts))
            return
        for c in range(left+1):
            counts[i]=c; rec(i+1,left-c)
        counts[i]=0
    rec(0,n)
    return res

for n in [4,5,6]:
    r=valid_counts(n)
    print('n=',n,'num count vectors=',len(r))
    for c in r: print('  ',c)
