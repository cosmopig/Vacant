import sys
M=998244353
P=1000000007
def solve(n):
    a=sorted(range(1,n+1), key=lambda x: str(x))
    s=0
    for i,v in enumerate(a,1):
        s=(s+((i-v)%M))%P
    return s
for n in [1,2,3,12,21,100,1000]:
    print(n, solve(n))
