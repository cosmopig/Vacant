from itertools import combinations_with_replacement
from collections import defaultdict

def multisets_by_c(n):
    V=n+1; res=defaultdict(int)
    for comb in combinations_with_replacement(range(1,V+1),n):
        c=comb[0]; S=0; ok=True
        for v in comb:
            S+=v
            if S>c*v: ok=False; break
        if ok: res[c]+=1
    return res

for n in range(2,10):
    print(n, dict(sorted(multisets_by_c(n).items())))
