#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int n; ll ans;
int c[64];
ll fact[64];
ll multinom(){
    ll r=fact[n];
    for(int v=1;v<=n+1;v++) if(c[v]) r/=fact[c[v]];
    return r;
}
// check constraints: c_v<=v; for x<y present: sum_{v=x..y} v*c_v <= x*y
bool ok(){
    for(int v=1;v<=n+1;v++) if(c[v]>v) return false;
    // prefix weighted sums
    static ll pref[70]; pref[0]=0;
    for(int v=1;v<=n+1;v++) pref[v]=pref[v-1]+(ll)v*c[v];
    for(int x=1;x<=n+1;x++) if(c[x]){
        for(int y=x+1;y<=n+1;y++) if(c[y]){
            if(pref[y]-pref[x-1] > (ll)x*y) return false;
        }
    }
    return true;
}
void rec(int v,int left){
    if(v==n+2){ if(left==0 && ok()) ans+=multinom(); return;}
    for(int k=0;k<=min(v,left);k++){ c[v]=k; rec(v+1,left-k);} c[v]=0;
}
int main(int argc,char**argv){
    n=atoi(argv[1]); fact[0]=1; for(int i=1;i<64;i++)fact[i]=fact[i-1]*i;
    rec(1,n); printf("n=%d ans=%lld\n",n,ans);
}
