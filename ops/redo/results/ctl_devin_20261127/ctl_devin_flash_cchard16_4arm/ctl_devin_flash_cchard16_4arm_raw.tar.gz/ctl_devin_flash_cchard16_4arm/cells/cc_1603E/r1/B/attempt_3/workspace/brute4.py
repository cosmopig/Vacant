from math import factorial

def compositions(n, k):
    vals=list(range(2,k+2))
    res=[]
    def rec(i, rem, cur):
        if i==len(vals):
            if rem==0: res.append(tuple(cur))
            return
        v=vals[i]
        for c in range(rem+1):
            cur.append(c)
            rec(i+1, rem-c, cur)
            cur.pop()
    rec(0,n,[])
    return res

def perfect_counts(counts):
    vals=[i+2 for i in range(len(counts)) if counts[i]>0]
    for mi,m in enumerate(vals):
        for M in vals[mi:]:
            s=sum((i+2)*counts[i] for i in range(len(counts)) if m<=i+2<=M)
            if m*M < s: return False
    return True

n=5
for counts in compositions(n,n):
    if perfect_counts(counts):
        items=[]
        for i,c in enumerate(counts):
            if c: items.append(f"{i+2}x{c}")
        print(" ".join(items))
