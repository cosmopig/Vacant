import sys
from math import factorial
sys.setrecursionlimit(10000)

def valid(counts):
    vals = sorted(counts)
    for i,x in enumerate(vals):
        s = 0
        for j in range(i, len(vals)):
            z = vals[j]
            s += z*counts[z]
            if s > x*z:
                return False
    return True

def count(n):
    vals = list(range(2, n+2))
    total = 0
    counts = {}
    def rec(idx, rem):
        nonlocal total
        if idx == len(vals):
            if rem == 0 and valid(counts):
                w = factorial(n)
                for c in counts.values():
                    w //= factorial(c)
                total += w
            return
        v = vals[idx]
        for c in range(rem+1):
            if c: counts[v]=c
            else: counts.pop(v, None)
            rec(idx+1, rem-c)
        counts.pop(v, None)
    rec(0, n)
    return total

for n in range(1, 9):
    print(n, count(n))
