#include <bits/stdc++.h>
using namespace std;

static const int MOD = 998244353;

struct Mask {
    uint64_t w[2];
    Mask() { w[0]=w[1]=0; }
    bool operator==(const Mask& o) const { return w[0]==o.w[0] && w[1]==o.w[1]; }
};
struct MaskHash {
    size_t operator()(const Mask& m) const {
        uint64_t h = m.w[0] + 0x9e3779b97f4a7c15ULL;
        h ^= m.w[1] + 0x9e3779b97f4a7c15ULL + (h<<6) + (h>>2);
        return (size_t)h;
    }
};
static inline Mask mand(const Mask&a,const Mask&b){Mask r;r.w[0]=a.w[0]&b.w[0];r.w[1]=a.w[1]&b.w[1];return r;}
static inline Mask mor(const Mask&a,const Mask&b){Mask r;r.w[0]=a.w[0]|b.w[0];r.w[1]=a.w[1]|b.w[1];return r;}
static inline Mask mnot(const Mask&a){Mask r;r.w[0]=~a.w[0];r.w[1]=~a.w[1];return r;}
static inline bool mempty(const Mask&a){return (a.w[0]|a.w[1])==0;}
static inline void mset(Mask&a,int i){a.w[i>>6]|=1ULL<<(i&63);}
static inline bool meq(const Mask&a,const Mask&b){return a.w[0]==b.w[0]&&a.w[1]==b.w[1];}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n,m;
    if(!(cin>>n>>m)) return 0;
    vector<vector<int>> fr(m);
    vector<char> used(n+1,0);
    for(int i=0;i<m;i++){
        int q;cin>>q;
        fr[i].resize(q);
        for(int j=0;j<q;j++) cin>>fr[i][j];
        sort(fr[i].begin(),fr[i].end());
        fr[i].erase(unique(fr[i].begin(),fr[i].end()),fr[i].end());
        if((int)fr[i].size()>=2) for(int e:fr[i]) used[e]=1;
    }
    vector<int> par(m); iota(par.begin(),par.end(),0);
    function<int(int)> find=[&](int x){return par[x]==x?x:par[x]=find(par[x]);};
    auto unite=[&](int a,int b){a=find(a);b=find(b);if(a!=b)par[a]=b;};
    unordered_map<int,int> seen;
    for(int i=0;i<m;i++){
        if(fr[i].size()<2) continue;
        for(int e:fr[i]){
            auto it=seen.find(e);
            if(it==seen.end()) seen[e]=i; else unite(i,it->second);
        }
    }
    unordered_map<int,vector<int>> compFriends;
    for(int i=0;i<m;i++) if(fr[i].size()>=2) compFriends[find(i)].push_back(i);

    vector<long long> fact(n+2);
    fact[0]=1; for(int i=1;i<=n+1;i++) fact[i]=fact[i-1]*i%MOD;

    long long prodV=1;
    int numBlocks=0, freeElems=0;
    for(int e=1;e<=n;e++) if(!used[e]) freeElems++;

    for(auto& kv: compFriends){
        auto& fl=kv.second;
        vector<int> elems; unordered_map<int,int> eidx;
        for(int fi:fl) for(int e:fr[fi]) if(!eidx.count(e)){eidx[e]=(int)elems.size();elems.push_back(e);}
        int k=(int)elems.size();
        vector<Mask> F;
        for(int fi:fl){
            Mask mk;
            for(int e:fr[fi]) mset(mk,eidx[e]);
            F.push_back(mk);
        }
        int mf=(int)F.size();
        vector<Mask> cont(k);
        for(int i=0;i<mf;i++){
            for(int wd=0;wd<2;wd++){
                uint64_t bits=F[i].w[wd];
                while(bits){int b=__builtin_ctzll(bits);bits&=bits-1;int y=wd*64+b;mset(cont[y],i);}
            }
        }
        Mask full; for(int i=0;i<k;i++) mset(full,i);

        // cur: P -> counts per last element x
        unordered_map<Mask, vector<int>, MaskHash> cur, nxt;
        cur.reserve(1<<15); nxt.reserve(1<<15);
        for(int y=0;y<k;y++){ Mask P; mset(P,y); vector<int> v(k,0); v[y]=1; cur.emplace(P,move(v)); }
        long long compAns=0;
        for(int size=1;size<k;size++){
            nxt.clear();
            for(auto& kv:cur){
                const Mask&P=kv.first; vector<int>&lst=kv.second;
                Mask meetP;
                Mask openInter=full;
                bool hasOpen=false;
                Mask notP=mand(mnot(P),full);
                for(int i=0;i<mf;i++){
                    if(!mempty(mand(F[i],P))){
                        mset(meetP,i);
                        if(!mempty(mand(F[i],notP))){
                            if(!hasOpen){openInter=F[i];hasOpen=true;}
                            else openInter=mand(openInter,F[i]);
                        }
                    }
                }
                Mask cand=mand(mnot(P),full);
                cand=mand(cand,openInter);
                // iterate x
                for(int x=0;x<k;x++){
                    int v=lst[x]; if(!v) continue;
                    Mask cx=cont[x];
                    Mask cy=cand;
                    for(int wd=0;wd<2;wd++){
                        uint64_t bits=cy.w[wd];
                        while(bits){
                            int b=__builtin_ctzll(bits);bits&=bits-1;int y=wd*64+b;
                            Mask bad=mand(cont[y],meetP);
                            bad=mand(bad,mnot(cx));
                            if(!mempty(bad)) continue;
                            Mask P2=P; mset(P2,y);
                            auto& vec=nxt[P2];
                            if(vec.empty()) vec.assign(k,0);
                            vec[y]=(vec[y]+v)%MOD;
                        }
                    }
                }
            }
            cur.swap(nxt);
        }
        // answer = sum over x of cur[full][x]
        Mask fu=full;
        auto it=cur.find(fu);
        if(it!=cur.end()) for(int x=0;x<k;x++) compAns=(compAns+it->second[x])%MOD;
        prodV=prodV*compAns%MOD;
        numBlocks++;
    }
    numBlocks+=freeElems;
    long long ans=fact[numBlocks]*prodV%MOD;
    cout<<ans<<"\n";
    return 0;
}
