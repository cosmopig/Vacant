import sys
from math import factorial
sys.setrecursionlimit(100000)

def gen(n):
    vals=list(range(2,n+2))
    c=[0]*(n+2)
    out=[]
    def rec(i, rem):
        if i==len(vals):
            if rem==0:
                present=[v for v in vals if c[v]>0]
                if not present: return
                m=present[0]
                for v in vals:
                    if c[v]>v: return
                P=0; ok=True
                for v in vals:
                    P+=v*c[v]
                    if c[v]>0 and v>m and P>m*v: ok=False;break
                if ok: out.append((m,tuple(c[v] for v in vals)))
            return
        v=vals[i]
        for k in range(0,min(v,rem)+1):
            c[v]=k; rec(i+1,rem-k)
        c[v]=0
    rec(0,n)
    return out

for n in [3,4,5]:
    print("=== n",n)
    for m,cv in sorted(gen(n)):
        print("m=",m, cv)
