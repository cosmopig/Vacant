import sys
sys.setrecursionlimit(100000)
def gen(n,k,idx,cur,rem,out):
    if idx==k-1:
        cur[idx]=rem; out.append(list(cur)); return
    for x in range(rem+1):
        cur[idx]=x; gen(n,k,idx+1,cur,rem-x,out)
def valid(c):
    for i,ci in enumerate(c):
        if ci>i+1: return False
    vals=[i+1 for i,ci in enumerate(c) if ci>0]
    for x in range(len(vals)):
        for y in range(x+1,len(vals)):
            u,v=vals[x],vals[y]
            if u*v < sum(c[w-1]*w for w in range(u,v+1)): return False
    return True
for n in [7,8]:
    out=[]; gen(n,n+1,0,[0]*(n+1),n,out)
    noMax=0; tot=0
    for c in out:
        if valid(c):
            tot+=1
            if c[n]==0: # value n+1 count is index n
                noMax+=1
                if noMax<5: print("n",n,"no n+1:",[ (i+1,c[i]) for i in range(n+1) if c[i]>0])
    print("n",n,"valid profiles",tot,"without n+1:",noMax)
