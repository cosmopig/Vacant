#include <bits/stdc++.h>
using namespace std;
int n;
vector<int> c;
bool ok(){
 for(int v=1;v<=n+1;v++) if(c[v]>v) return false;
 vector<int> pref(n+3); for(int v=1;v<=n+1;v++) pref[v]=pref[v-1]+c[v]*v;
 for(int x=1;x<=n+1;x++) if(c[x]) for(int y=x+1;y<=n+1;y++) if(c[y]){
   if(pref[y]-pref[x-1] > 1LL*x*y) return false;
 }
 return true;
}
void rec(int v,int left){
 if(v==n+2){ if(left==0 && ok()){
   int mn=1; while(mn<=n+1&&!c[mn])mn++;
   cout<<"min "<<mn<<" counts"; for(int i=1;i<=n+1;i++)if(c[i])cout<<" "<<i<<":"<<c[i]; cout<<"\n";
 } return; }
 for(int k=0;k<=min(v,left);k++){c[v]=k;rec(v+1,left-k);} c[v]=0;
}
int main(){cin>>n;c.assign(n+3,0);rec(1,n);}
