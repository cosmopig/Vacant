M = 998244353

def lex_order(n):
    return sorted(range(1, n+1), key=lambda x: str(x))

prev = None
for n in list(range(1, 200)) + [500, 1000, 5000, 10000, 20000, 100000]:
    a = lex_order(n)
    C = sum(1 for i, v in enumerate(a, 1) if i % M < v % M)
    print(n, C)
