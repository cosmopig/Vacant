#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int n; vector<int> vals,cnt,sup;
bool ok(){
    sup.clear();
    for(int i=0;i<(int)vals.size();i++) if(cnt[i]) sup.push_back(vals[i]);
    int m=sup.size(),V=vals.size();
    static ll P[305]; P[0]=0;
    for(int i=0;i<V;i++)P[i+1]=P[i]+(ll)vals[i]*cnt[i];
    for(int x=0;x<m;x++)for(int y=x;y<m;y++){
        int l=sup[x],h=sup[y];
        int il=lower_bound(vals.begin(),vals.end(),l)-vals.begin();
        int ih=lower_bound(vals.begin(),vals.end(),h)-vals.begin();
        if(P[ih+1]-P[il]>(ll)l*h)return false;
    }
    return true;
}
void rec(int i,int left){
    if(i==(int)vals.size()){ if(left==0&&ok()){
        for(int j=0;j<(int)vals.size();j++) if(cnt[j]) printf("(%d,%d)",vals[j],cnt[j]);
        printf("\n");
    } return;}
    for(int c=0;c<=left;c++){cnt[i]=c;rec(i+1,left-c);} cnt[i]=0;
}
int main(int argc,char**argv){
    n=atoi(argv[1]);
    for(int i=2;i<=n+1;i++)vals.push_back(i);
    cnt.assign(vals.size(),0); rec(0,n);
}
