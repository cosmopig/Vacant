#include <bits/stdc++.h>
using namespace std;
int n; long long ans;
bool good(vector<int>& s){
    long long mx=*max_element(s.begin(),s.end()), mn=*min_element(s.begin(),s.end()), sum=0; for(int x:s)sum+=x; return mx*mn>=sum;
}
bool perfect(vector<int>& a){
    int N=a.size();
    for(int mask=1;mask<(1<<N);mask++){
        vector<int> s; for(int i=0;i<N;i++) if(mask>>i&1) s.push_back(a[i]);
        if(!good(s)) return false;
    }
    return true;
}
void rec(int i, vector<int>& a){
    if(i==n){ if(perfect(a)) ans++; return;}
    for(int v=1;v<=n+1;v++){ a[i]=v; rec(i+1,a);}
}
int main(int argc,char**argv){ n=atoi(argv[1]); vector<int> a(n); rec(0,a); printf("n=%d ans=%lld\n",n,ans); }
