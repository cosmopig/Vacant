import itertools, sys
sys.setrecursionlimit(100000)

def valid(p, sets):
    pos={x:i for i,x in enumerate(p)}
    for S in sets:
        ps=[pos[x] for x in S]
        if max(ps)-min(ps)!=len(S)-1: return False
    return True

def atoms(n, sets):
    sig={}
    for x in range(1,n+1):
        s=frozenset(i for i,S in enumerate(sets) if x in S)
        sig.setdefault(s,[]).append(x)
    return sig

# search for a valid perm where same-atom elements are non-contiguous
import random
random.seed(1)
found=0
for trial in range(200000):
    n=random.randint(4,7)
    m=random.randint(2,3)
    sets=[]
    for _ in range(m):
        q=random.randint(2,n)
        sets.append(set(random.sample(range(1,n+1),q)))
    # dedupe, require connected-ish
    perms=list(itertools.permutations(range(1,n+1)))
    val=[p for p in perms if valid(p,sets)]
    if not val: continue
    sig=atoms(n,sets)
    for p in val:
        pos={x:i for i,x in enumerate(p)}
        for s,xs in sig.items():
            if len(xs)>=2:
                ps=sorted(pos[x] for x in xs)
                if ps[-1]-ps[0]!=len(xs)-1:
                    print('NONCONTIG atom',xs,'sig',s,'perm',p,'sets',sets)
                    found=1;break
        if found:break
    if found:break
print('done',found)
