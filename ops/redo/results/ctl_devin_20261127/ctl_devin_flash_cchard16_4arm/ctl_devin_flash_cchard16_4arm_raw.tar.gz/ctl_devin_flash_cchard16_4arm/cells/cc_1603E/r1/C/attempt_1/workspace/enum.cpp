#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef __int128 lll;
int n;
vector<int> vals; // values 2..n+1
vector<int> cnt;
lll fact[305];
lll total=0;
vector<int> sup;
// check validity of current count vector
bool ok(){
    sup.clear();
    for(int i=0;i<(int)vals.size();i++) if(cnt[i]) sup.push_back(vals[i]);
    int m=sup.size();
    // precompute range sums T(l,h) via prefix over value index
    // T over values in [l,h]
    int V=vals.size();
    // prefix sums P[i]=sum_{j<=i} vals[j]*cnt[j]
    static ll P[305];
    P[0]=0;
    for(int i=0;i<V;i++) P[i+1]=P[i]+(ll)vals[i]*cnt[i];
    // map value->index
    for(int x=0;x<m;x++)for(int y=x;y<m;y++){
        int l=sup[x],h=sup[y];
        // find indices
        int il=lower_bound(vals.begin(),vals.end(),l)-vals.begin();
        int ih=lower_bound(vals.begin(),vals.end(),h)-vals.begin();
        ll s=P[ih+1]-P[il];
        if(s>(ll)l*h) return false;
    }
    return true;
}
void rec(int i,int left){
    if(i==(int)vals.size()){
        if(left==0 && ok()){
            // weight n!/prod c!
            lll w=fact[n];
            for(int c:cnt) w/=fact[c];
            total+=w;
        }
        return;
    }
    for(int c=0;c<=left;c++){cnt[i]=c;rec(i+1,left-c);}
    cnt[i]=0;
}
int main(int argc,char**argv){
    n=atoi(argv[1]);
    for(int i=2;i<=n+1;i++) vals.push_back(i);
    cnt.assign(vals.size(),0);
    fact[0]=1;for(int i=1;i<305;i++)fact[i]=fact[i-1]*i;
    rec(0,n);
    // print total and mod small
    printf("n=%d total=",n);
    // print lll
    lll t=total; string s;
    if(t==0)s="0";while(t>0){s+=char('0'+t%10);t/=10;}
    reverse(s.begin(),s.end());
    printf("%s\n",s.c_str());
    return 0;
}
