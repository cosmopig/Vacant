import sys

def lex_sorted(n):
    return sorted(range(1, n+1), key=lambda x: str(x))

def pos_formula(v, n, len_n, C):
    # C[lu] = count of lu-digit numbers <= n, for lu=1..len_n
    L = len(str(v))
    # tiebreak: trailing zeros of v
    tz = 0
    t = v
    while t % 10 == 0:
        tz += 1
        t //= 10
    total = 1 + tz
    lv = L
    for lu in range(1, len_n+1):
        U = min(10**lu - 1, n)
        Clu = U - 10**(lu-1) + 1
        if Clu <= 0:
            continue
        if lu >= lv:
            X = v * (10**(lu-lv))
            cnt = min(max(X - 10**(lu-1), 0), Clu)
        else:
            m = lv - lu
            f = (v-1)//(10**m) - 10**(lu-1) + 1
            cnt = min(max(f, 0), Clu)
        total += cnt
    return total

for n in [12, 100, 1000, 5000]:
    a = lex_sorted(n)
    len_n = len(str(n))
    C = [0]*(len_n+2)
    for lu in range(1, len_n+1):
        U = min(10**lu - 1, n)
        C[lu] = U - 10**(lu-1) + 1
    # verify pos(v) for all v
    ok = True
    for i, v in enumerate(a):
        p = pos_formula(v, n, len_n, C)
        if p != i+1:
            print("MISMATCH", n, v, p, i+1)
            ok = False
            break
    print(n, "pos formula:", "OK" if ok else "FAIL")
