import sys
from itertools import combinations_with_replacement
from math import factorial

def good(b):
    return max(b)*min(b) >= sum(b)

def perfect(mult):
    m = list(mult)
    n = len(m)
    for mask in range(1, 1<<n):
        s = [m[i] for i in range(n) if mask>>i & 1]
        if not good(s):
            return False
    return True

def count(n):
    V = n+1
    total = 0
    multisets = []
    for comb in combinations_with_replacement(range(1,V+1), n):
        if perfect(comb):
            multisets.append(comb)
            cnt = {}
            for x in comb: cnt[x]=cnt.get(x,0)+1
            ways = factorial(n)
            for k in cnt.values(): ways //= factorial(k)
            total += ways
    return total, multisets

for n in range(1,7):
    t, ms = count(n)
    print(n, t)
    if n<=4:
        for m in ms: print('   ', m)
