#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int n; vector<int> c; ll pre[256]; int valsbuf[256];
int minspread;
void gen(int idx,int rem){
    if(idx==n){ c[idx]=rem;
        for(int i=0;i<=n;i++) if(c[i]>i+1) return;
        pre[0]=0; for(int i=1;i<=n+1;i++) pre[i]=pre[i-1]+(ll)c[i-1]*i;
        int k=0; for(int i=0;i<=n;i++) if(c[i]>0) valsbuf[k++]=i+1;
        bool a=true;
        for(int x=0;x<k&&a;x++)for(int y=x+1;y<k;y++)
            if((ll)valsbuf[x]*valsbuf[y] < pre[valsbuf[y]]-pre[valsbuf[x]-1]){a=false;break;}
        if(!a) return;
        int sp=valsbuf[k-1]-valsbuf[0];
        if(sp>=minspread){ printf("spread=%d: ",sp); for(int i=0;i<k;i++) printf("(%d,%d) ",valsbuf[i],c[valsbuf[i]-1]); printf("\n"); }
        return;}
    for(int x=0;x<=rem;x++){c[idx]=x;gen(idx+1,rem-x);}
}
int main(int argc,char**argv){ n=atoi(argv[1]); minspread=atoi(argv[2]); c.assign(n+1,0); gen(0,n);}
