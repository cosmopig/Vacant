#include <bits/stdc++.h>
using namespace std;
// enumerate multisets (count vectors c[2..n+1], sum=n) satisfying interval condition
int n, c[210];
long long cnt=0;
vector<int> supp;
// check incrementally: after assigning all, verify. Prune partial?
bool full(){
    supp.clear();
    for(int x=2;x<=n+1;x++) if(c[x]) supp.push_back(x);
    for(int u:supp) for(int v:supp) if(u<=v){
        long long s=0;
        for(int x=u;x<=v;x++) s += (long long)x*c[x];
        if(s > (long long)u*v) return false;
    }
    return true;
}
void rec(int x, int left){
    if(x==n+2){ if(left==0 && full()) cnt++; return; }
    if(x==n+2) return;
    for(int k=0;k<=min(x,left);k++){ c[x]=k; rec(x+1,left-k); }
    c[x]=0;
}
int main(int argc,char**argv){
    n=atoi(argv[1]);
    // values 2..n+1 => x from 2 to n+1 inclusive; fix rec bound
    // redo: x in [2, n+1]
    cnt=0;
    // simple recursion
    function<void(int,int)> r=[&](int x,int left){
        if(x>n+1){ if(left==0 && full()) cnt++; return; }
        int hi=min(x,left);
        for(int k=0;k<=hi;k++){c[x]=k;r(x+1,left-k);} 
        c[x]=0;
    };
    r(2,n);
    printf("n=%d multisets=%lld\n",n,cnt);
}
