from itertools import combinations_with_replacement
from math import factorial

def good(b):
    return max(b)*min(b) >= sum(b)

def perfect(mult):
    m = list(mult); n=len(m)
    for mask in range(1,1<<n):
        s=[m[i] for i in range(n) if mask>>i&1]
        if not good(s): return False
    return True

def char_ok(mult):
    # sorted tuple; check S_j <= x1*x_j for all j
    x = sorted(mult); c = x[0]; S=0
    for j,v in enumerate(x):
        S += v
        if S > c*v: return False
    return True

for n in range(1,8):
    bad=0
    for comb in combinations_with_replacement(range(1,n+2), n):
        if perfect(comb) != char_ok(comb):
            bad+=1
            if bad<5: print('MISMATCH', n, comb, perfect(comb), char_ok(comb))
    print(n, 'mismatches:', bad)
