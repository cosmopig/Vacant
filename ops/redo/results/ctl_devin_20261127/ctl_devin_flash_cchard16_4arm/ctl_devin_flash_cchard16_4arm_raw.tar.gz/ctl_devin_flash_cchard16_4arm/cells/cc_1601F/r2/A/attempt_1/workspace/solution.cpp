#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef __int128 lll;

static const ll M = 998244353LL;
static const ll P = 1000000007LL;

ll n;
ll p10[20];
ll Asum[20]; // sum_{i=0}^h 10^i exact
ll Amod;

static inline ll pmod(ll x){ x%=P; if(x<0)x+=P; return x; }
static inline ll addmod(ll a,ll b){ a+=b; if(a>=P)a-=P; return a; }

ll ds(ll r){ ll s=0; while(r){ s+=r%10; r/=10; } return s; }

// B_r for a complete-subtree level: ((F*r)-ds(r))/9, F=10^m-9
static inline ll Br(ll F, ll r){ return (F*r - ds(r))/9; }

struct LevelRes { ll A,B; };

// For one level s of a complete subtree height h rooted value y:
// nodes z = y*10^s + r, r in [0,N), N=10^s.
// rank offset o = s+1 + (E*r - ds(r))/9, E=10^{h-s+1}
// deficit D = z - (R0+o) = C - B_r, nonincreasing in r.
// E2 = rank - z = B_r - C, nondecreasing.
void process_level(ll base_val, ll R0, int s, int h, LevelRes &res){
    ll N = p10[s];
    int m = h - s + 1;
    ll E = p10[m];
    ll F = E - 9;
    ll C = base_val - R0 - (s + 1);

    // A part: thresholds t=j*M+1, count prefix with B_r <= C-t.
    if (C > 0) {
        for (ll j=0;;j++){
            lll t = (lll)j*M + 1;
            lll limit = (lll)C - t;
            if (limit < 0) break;
            ll lim = (ll)limit;
            // first r in [0,N) with B_r > lim
            ll lo=0, hi=N;
            while(lo<hi){
                ll mid=lo+(hi-lo)/2;
                if (Br(F,mid) > lim) hi=mid; else lo=mid+1;
            }
            if (lo==0) break;
            res.A = addmod(res.A, pmod(lo));
        }
    }

    // B part: thresholds t=k*M, count suffix with B_r >= C+t.
    for (ll k=1;;k++){
        lll need = (lll)C + (lll)k*M;
        ll pos;
        if (need <= 0) pos = 0;
        else {
            ll lim2 = (ll)need;
            // first r with B_r >= lim2
            ll lo=0, hi=N;
            while(lo<hi){
                ll mid=lo+(hi-lo)/2;
                if (Br(F,mid) >= lim2) hi=mid; else lo=mid+1;
            }
            pos=lo;
        }
        ll cnt = N - pos;
        if (cnt<=0) break;
        res.B = addmod(res.B, pmod(cnt));
    }
}

// emit whole complete subtree height h rooted at y, R0 nodes before it.
void emit_complete(ll y, int h, ll R0, LevelRes &res){
    for(int s=0;s<=h;s++){
        ll base_val = y * p10[s];
        process_level(base_val, R0, s, h, res);
    }
}

struct Info { int h; ll base,cnt,size; bool complete; };

Info get_info(ll y){
    Info in; in.h=0; ll cur=y;
    while (cur <= n/10){ cur*=10; in.h++; }
    in.base=cur;
    ll rem = n - cur + 1;
    in.cnt = min(p10[in.h], rem);
    in.complete = (in.cnt == p10[in.h]);
    if (in.complete) in.size = Asum[in.h];
    else in.size = (in.h==0 ? 1 : Asum[in.h-1] + in.cnt);
    return in;
}

inline void add_node(ll val, ll rank, LevelRes &res){
    // single node: deficit D=val-rank, excess E=rank-val
    ll D = val - rank;
    if (D>0){ res.A = addmod(res.A, pmod((D-1)/M + 1)); }
    ll E = rank - val;
    if (E>0){ res.B = addmod(res.B, pmod(E/M)); }
}

// boundary node y: emit y itself, then process children.
ll dfs(ll y, ll R0, LevelRes &res){
    Info in = get_info(y); // boundary
    add_node(y, R0+1, res);
    ll Rchild = R0 + 1;
    ll m = 0;
    if (10*y <= n) m = min(10LL, n - 10*y + 1);
    for(ll d=0; d<m; d++){
        ll c = 10*y + d;
        Info ci = get_info(c);
        if (ci.complete){
            emit_complete(c, ci.h, Rchild, res);
            Rchild += ci.size;
        } else {
            Rchild += dfs(c, Rchild, res);
        }
    }
    return in.size;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    if(!(cin>>n)) return 0;
    p10[0]=1;
    for(int i=1;i<20;i++) p10[i]=p10[i-1]*10LL;
    Asum[0]=1;
    for(int i=1;i<20;i++) Asum[i]=Asum[i-1]+p10[i];

    LevelRes res{0,0};
    ll R0=0;
    ll upto = min(9LL,n);
    for(ll y=1;y<=upto;y++){
        Info in=get_info(y);
        if (in.complete){
            emit_complete(y, in.h, R0, res);
            R0 += in.size;
        } else {
            R0 += dfs(y, R0, res);
        }
    }
    ll T = pmod(res.A - res.B);
    ll ans = pmod( (M%P) * T % P );
    cout << ans << "\n";
    return 0;
}
