#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll M = 998244353LL;
int main(int argc, char** argv){
    // read n from argv or stdin; compute a_i = lex sorted values, then C
    ll n;
    if(argc>1) n = atoll(argv[1]); else cin>>n;
    vector<int> a(n);
    iota(a.begin(), a.end(), 1);
    sort(a.begin(), a.end(), [](int x,int y){
        // compare decimal strings
        char sx[20], sy[20];
        int lx=0, ly=0;
        int tx=x, ty=y;
        while(tx){sx[lx++]='0'+tx%10; tx/=10;}
        while(ty){sy[ly++]='0'+ty%10; ty/=10;}
        reverse(sx,sx+lx); reverse(sy,sy+ly);
        return lexicographical_compare(sx,sx+lx,sy,sy+ly);
    });
    ll C=0;
    for(ll i=0;i<n;i++){
        ll pos=i+1, val=a[i];
        ll u=pos%M, v=val%M;
        if(u<v) C++;
    }
    cout<<C<<"\n";
    return 0;
}
