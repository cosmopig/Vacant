#include <bits/stdc++.h>
using namespace std;
int main(int argc,char**argv){
    int n=atoi(argv[1]);
    set<vector<int>> seen;
    vector<int> a(n);
    function<void(int)> rec=[&](int i){
        if(i==n){
            int c[205]={0}; for(int x:a)c[x]++;
            vector<int> sup; for(int x=1;x<=n+1;x++) if(c[x])sup.push_back(x);
            for(int u:sup)for(int v:sup) if(u<=v){
                long long s=0; for(int x=u;x<=v;x++) s+=(long long)x*c[x];
                if(s>(long long)u*v) return;
            }
            vector<int> b=a; sort(b.begin(),b.end());
            seen.insert(b); return;}
        for(int x=1;x<=n+1;x++){a[i]=x;rec(i+1);}
    };
    rec(0);
    for(auto&b:seen){for(int x:b)printf("%d ",x);printf("\n");}
    fprintf(stderr,"distinct sorted: %zu\n",seen.size());
}
