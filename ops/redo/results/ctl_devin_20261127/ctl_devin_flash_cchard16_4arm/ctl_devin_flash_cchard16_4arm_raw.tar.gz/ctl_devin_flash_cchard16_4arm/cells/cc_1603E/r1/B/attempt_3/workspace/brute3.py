import itertools
from functools import lru_cache

def compositions(n, k):
    # multisets of size n from values 2..k+1 -> counts c[2..k+1] sum n
    vals=list(range(2,k+2))
    res=[]
    def rec(i, rem, cur):
        if i==len(vals):
            if rem==0: res.append(tuple(cur))
            return
        v=vals[i]
        for c in range(rem+1):
            cur.append(c)
            rec(i+1, rem-c, cur)
            cur.pop()
    rec(0,n,[])
    return res

def perfect_counts(counts):
    # values 2.. ; counts list aligned to values 2,3,...
    vals=[i+2 for i in range(len(counts)) if counts[i]>0]
    # for each pair of present values m<=M, sum of elements in [m,M] <= m*M
    for mi,m in enumerate(vals):
        for M in vals[mi:]:
            s=sum((i+2)*counts[i] for i in range(len(counts)) if m<=i+2<=M)
            if m*M < s: return False
    return True

def seq_count(counts):
    from math import factorial
    n=sum(counts)
    r=factorial(n)
    for c in counts: r//=factorial(c)
    return r

for n in range(1,7):
    total=0
    ms=[]
    for counts in compositions(n,n):
        if perfect_counts(counts):
            total+=seq_count(counts)
            ms.append(counts)
    print("n",n,"count",total,"multisets",len(ms))
