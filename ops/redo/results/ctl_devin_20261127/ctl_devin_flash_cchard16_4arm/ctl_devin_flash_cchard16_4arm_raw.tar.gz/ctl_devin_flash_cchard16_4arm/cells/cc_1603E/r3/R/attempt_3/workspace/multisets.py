import sys
sys.setrecursionlimit(10000)

def gen_counts(n, vals, idx, remaining, cur, out):
    # vals: list of allowed values, assign counts summing to n, each 1<=c<=val
    if idx==len(vals):
        if remaining==0:
            out.append(tuple(cur))
        return
    v=vals[idx]
    for c in range(1, min(v,remaining)+1):
        cur.append(c)
        gen_counts(n, vals, idx+1, remaining-c, cur, out)
        cur.pop()

def valid(counts, vals):
    # counts aligned with vals (only present values); check c_v<=v and prefix constraints with m=vals[0]
    m=vals[0]
    S=0
    for v,c in zip(vals,counts):
        if c>v: return False
        S+=v*c
        if v>m and S>m*v: return False
    return True

for n in range(2,9):
    vals=list(range(2,n+2))
    out=[]
    gen_counts(n,vals,0,n,[],out)
    mins=set()
    tot=0
    for counts in out:
        # present values are those with count>0 -- but gen requires >=1, and vals may include unused?
        # gen_counts forces every val count>=1; need subsets instead. Quick fix: iterate over subsets.
        pass
    # instead: enumerate subsets of vals of size>=1 containing... do recursively over include/skip
    results=[]
    def rec(i, chosen_vals, chosen_counts, rem):
        if i==len(vals):
            if chosen_vals and rem==0:
                results.append((tuple(chosen_vals),tuple(chosen_counts)))
            return
        v=vals[i]
        # skip
        rec(i+1, chosen_vals, chosen_counts, rem)
        # take with count c
        for c in range(1, min(v,rem)+1):
            rec(i+1, chosen_vals+[v], chosen_counts+[c], rem-c)
    rec(0,[],[],n)
    seqcount=0
    from math import factorial
    f=factorial(n)
    inv=[0]*(n+1)
    for i in range(n+1): inv[i]=f//factorial(i)  # not modular, exact multinomial later
    tot=0
    for vs,cs in results:
        if valid(cs,vs):
            # weight = n! / prod c!
            w=f
            for c in cs: w//=factorial(c)
            tot+=w
            mins.add(vs[0])
    print(n,"answer",tot,"min values seen",sorted(mins))
