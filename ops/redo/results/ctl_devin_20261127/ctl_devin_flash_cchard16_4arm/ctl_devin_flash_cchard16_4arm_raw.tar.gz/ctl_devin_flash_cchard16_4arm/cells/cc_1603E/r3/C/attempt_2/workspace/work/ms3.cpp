#include <bits/stdc++.h>
using namespace std;
int n,c[210]; vector<int> supp;
bool full(){
    supp.clear();
    for(int x=2;x<=n+1;x++) if(c[x]) supp.push_back(x);
    for(int u:supp) for(int v:supp) if(u<=v){
        long long s=0; for(int x=u;x<=v;x++) s+=(long long)x*c[x];
        if(s>(long long)u*v) return false;
    }
    return true;
}
map<int,int> minhist; long long cnt=0;
void rec(int x,int left){
    if(x>n+1){ if(left==0&&full()){
        cnt++;
        int mn=999; for(int y=2;y<=n+1;y++) if(c[y]) mn=min(mn,y);
        minhist[mn]++;
    } return; }
    for(int k=0;k<=min(x,left);k++){c[x]=k;rec(x+1,left-k);} c[x]=0;
}
int main(int argc,char**argv){ n=atoi(argv[1]); rec(2,n);
    printf("n=%d total=%lld minvals:",n,cnt);
    for(auto&p:minhist)printf(" %d:%d",p.first,p.second);
    printf("\n"); }
