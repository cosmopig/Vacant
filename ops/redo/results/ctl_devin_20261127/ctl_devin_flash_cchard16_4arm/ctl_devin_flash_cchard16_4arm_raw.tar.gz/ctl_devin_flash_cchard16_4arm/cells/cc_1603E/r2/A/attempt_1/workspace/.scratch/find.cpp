#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int n; vector<int> c; ll pre[256]; int valsbuf[256];
bool full(vector<pair<int,int>>&bad){
    for(int i=0;i<=n;i++) if(c[i]>i+1) return false;
    int k=0; for(int i=0;i<=n;i++) if(c[i]>0) valsbuf[k++]=i+1;
    for(int x=0;x<k;x++)for(int y=x+1;y<k;y++)
        if((ll)valsbuf[x]*valsbuf[y] < pre[valsbuf[y]]-pre[valsbuf[x]-1]){bad.push_back({valsbuf[x],valsbuf[y]});return false;}
    return true;
}
bool restr(){
    for(int i=0;i<=n;i++) if(c[i]>i+1) return false;
    int k=0; for(int i=0;i<=n;i++) if(c[i]>0) valsbuf[k++]=i+1;
    int L=valsbuf[k-1];
    for(int x=0;x+1<k;x++){
        int u=valsbuf[x],v=valsbuf[x+1];
        if((ll)u*v < pre[v]-pre[u-1]) return false;
        if((ll)u*L < pre[L]-pre[u-1]) return false;
    }
    return true;
}
void gen(int idx,int rem){
    if(idx==n){ c[idx]=rem;
        pre[0]=0; for(int i=1;i<=n+1;i++) pre[i]=pre[i-1]+(ll)c[i-1]*i;
        vector<pair<int,int>> bad;
        bool a=full(bad), b=restr();
        if(a!=b){ printf("DIFF c:"); for(int i=0;i<=n;i++) if(c[i]) printf(" (%d,%d)",i+1,c[i]); printf("  badpair=(%d,%d)\n",bad[0].first,bad[0].second);}
        return;}
    for(int x=0;x<=rem;x++){c[idx]=x;gen(idx+1,rem-x);}
}
int main(int argc,char**argv){ n=atoi(argv[1]); c.assign(n+1,0); gen(0,n);}
