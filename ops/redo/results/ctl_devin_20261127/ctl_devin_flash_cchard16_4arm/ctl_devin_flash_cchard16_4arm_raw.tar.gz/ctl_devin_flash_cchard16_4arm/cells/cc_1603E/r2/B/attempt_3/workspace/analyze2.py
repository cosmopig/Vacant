from analyze import multisets, crit_full, crit_minmax, crit_adj
for n in range(5,9):
    ms=multisets(n,1,n+1)
    mism_mm=[]; mism_adj=0
    for c in ms:
        f=crit_full(c)
        if f!=crit_minmax(c): mism_mm.append((c,f))
        if f!=crit_adj(c): mism_adj+=1
    print("n",n,"multisets",len(ms),"minmax mismatches",len(mism_mm),"adj mismatches",mism_adj)
    for c,f in mism_mm[:10]: print("   ",c,"full",f)
