import itertools, sys
from collections import Counter

def good(sub):
    return max(sub)*min(sub) >= sum(sub)

def perfect(seq):
    n=len(seq)
    for mask in range(1,1<<n):
        sub=[seq[i] for i in range(n) if mask>>i&1]
        if not good(sub): return False
    return True

for n in range(1,6):
    cnt=0
    multisets={}
    for seq in itertools.product(range(1,n+2),repeat=n):
        if perfect(seq):
            cnt+=1
            multisets[tuple(sorted(seq))]=multisets.get(tuple(sorted(seq)),0)+1
    print("n=",n,"count=",cnt)
    for k in sorted(multisets): print("   ",k)
