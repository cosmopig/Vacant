import sys, json
M = 998244353
P = 1000000007

def brute(n):
    a = sorted(range(1, n+1), key=lambda x: str(x))
    s = 0
    for i, v in enumerate(a, 1):
        s = (s + (i - v) % M) % P
    return s

def C_count(n):
    order = sorted(range(1, n+1), key=lambda x: str(x))
    C = 0
    for i, v in enumerate(order, 1):
        if i % M < v % M:
            C += 1
    return C

def formula(n):
    C = C_count(n)
    return (M * C) % P, C

for n in [3, 12, 21, 100, 272, 985]:
    b = brute(n)
    f, C = formula(n)
    print(n, b, f, C, "OK" if b==f else "MISMATCH")
