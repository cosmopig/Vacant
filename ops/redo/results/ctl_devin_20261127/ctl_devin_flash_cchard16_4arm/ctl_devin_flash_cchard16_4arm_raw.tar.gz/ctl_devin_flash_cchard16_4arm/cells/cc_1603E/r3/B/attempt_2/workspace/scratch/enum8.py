import sys
sys.setrecursionlimit(10000)

def valid(counts):
    vals = sorted(counts)
    for i,x in enumerate(vals):
        s = 0
        for j in range(i, len(vals)):
            z = vals[j]
            s += z*counts[z]
            if s > x*z:
                return False
    return True

def enum(n):
    vals = list(range(2, n+2))
    counts = {}
    out=[]
    def rec(idx, rem):
        if idx == len(vals):
            if rem == 0 and valid(counts):
                out.append(tuple(counts.get(v,0) for v in vals))
            return
        v = vals[idx]
        for c in range(rem+1):
            if c: counts[v]=c
            else: counts.pop(v,None)
            rec(idx+1, rem-c)
        counts.pop(v,None)
    rec(0,n)
    return out

for n in [8]:
    res = enum(n)
    print("=== n=",n,"count:",len(res))
    for r in res:
        pres = [2+i for i,c in enumerate(r) if c]
        print("  present:", pres, "counts:", r)
