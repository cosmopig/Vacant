import itertools
from collections import Counter

def good(sub):
    return max(sub)*min(sub) >= sum(sub)

def perfect(vals):
    n=len(vals)
    for mask in range(1,1<<n):
        sub=[vals[i] for i in range(n) if mask>>i&1]
        if not good(sub): return False
    return True

n=3
ms=Counter()
for vals in itertools.product(range(1,n+2),repeat=n):
    if perfect(vals):
        ms[tuple(sorted(vals))]+=1
for k,v in sorted(ms.items()):
    print(k, v)
