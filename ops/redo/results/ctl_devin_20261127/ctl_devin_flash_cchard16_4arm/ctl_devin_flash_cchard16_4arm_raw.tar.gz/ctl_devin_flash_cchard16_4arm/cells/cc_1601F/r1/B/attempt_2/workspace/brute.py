M=998244353
P=10**9+7
def ans(n):
    vals=list(map(int,sorted(map(str,range(1,n+1)))))
    Q=0; S=0
    for i,x in enumerate(vals,1):
        d=i-x
        S += d - M*(d//M)
        Q += -(d//M)
    return S%P, Q, S, vals
for n in [3,12,21,99,100,101,999,1000,10000]:
    s,q,S,vals=ans(n)
    print(n, 'ans',s,'Q',q,'check', (M*q)%P, 'S',S)
