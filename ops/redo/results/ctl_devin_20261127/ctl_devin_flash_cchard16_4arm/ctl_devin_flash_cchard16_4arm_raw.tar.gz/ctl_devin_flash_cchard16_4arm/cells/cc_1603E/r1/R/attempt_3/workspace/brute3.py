import itertools
from collections import Counter

def good(sub):
    return max(sub)*min(sub) >= sum(sub)

def perfect(t):
    n=len(t)
    for mask in range(1,1<<n):
        sub=[t[i] for i in range(n) if mask>>i&1]
        if not good(sub):
            return False
    return True

# n=5: check all tuples with values only in {4,5,6} are perfect, and count how many perfect tuples have min value >=4
n=5
cnt_all=0; cnt_restricted=0; bad_ex=[]
for t in itertools.product(range(4,7), repeat=n):
    if perfect(t): cnt_restricted+=1
print("restricted count", cnt_restricted)
# full count already 97; check if any perfect tuple contains value <=3
for t in itertools.product(range(1,n+2), repeat=n):
    if perfect(t):
        cnt_all+=1
        if min(t)<4: bad_ex.append(t)
print("all",cnt_all,"with small",len(bad_ex), bad_ex[:10])
