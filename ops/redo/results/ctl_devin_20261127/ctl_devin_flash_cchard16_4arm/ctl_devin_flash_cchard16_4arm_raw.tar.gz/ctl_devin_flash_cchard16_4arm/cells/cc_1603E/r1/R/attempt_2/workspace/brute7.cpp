#include <bits/stdc++.h>
using namespace std;
int n, vals;
vector<int> a;
bool perfect(){
    int N=1<<n;
    static int sum[1<<8], mn[1<<8], mx[1<<8];
    sum[0]=0; mn[0]=1000000000; mx[0]=-1;
    for(int mask=1; mask<N; mask++){
        int b=__builtin_ctz(mask); int prev=mask&(mask-1); int v=a[b];
        sum[mask]=sum[prev]+v; mn[mask]=min(mn[prev],v); mx[mask]=max(mx[prev],v);
        if((long long)mn[mask]*mx[mask] < sum[mask]) return false;
    }
    return true;
}
int main(int argc,char**argv){n=atoi(argv[1]); vals=n+1; map<vector<int>,long long> hist; vector<int> cur(n,1);
    while(true){
        vector<int> c(vals+1); for(int x:cur)c[x]++; a=cur;
        if(perfect()) hist[c]++;
        int p=n-1; while(p>=0 && cur[p]==vals){cur[p]=1;p--;} if(p<0) break; cur[p]++;
    }
    long long total=0; for(auto &kv:hist) total+=kv.second;
    cout<<"n "<<n<<" count "<<total<<" distinct countvecs "<<hist.size()<<"\n";
    for(auto &kv:hist){ cout<<"counts:"; for(int v=1;v<=vals;v++) if(kv.first[v]) cout<<" "<<v<<"x"<<kv.first[v]; cout<<"  seqs "<<kv.second<<"\n"; }
}
