import sys, itertools
from math import factorial
sys.setrecursionlimit(10000)

def good(b):
    return max(b)*min(b) >= sum(b)

def perfect_seq(a):
    n=len(a)
    for mask in range(1,1<<n):
        b=[a[i] for i in range(n) if mask>>i&1]
        if not good(b): return False
    return True

def count_brute(n, mod):
    tot=0
    for a in itertools.product(range(1,n+2), repeat=n):
        if perfect_seq(list(a)): tot+=1
    return tot%mod

def count_char(n, mod):
    vals=list(range(2,n+2))
    tot=0
    c=[0]*(n+2)
    def rec(i, rem):
        nonlocal tot
        if i==len(vals):
            if rem==0:
                present=[v for v in vals if c[v]>0]
                if not present: return
                m=present[0]
                for v in vals:
                    if c[v]>v: return
                P=0
                ok=True
                for v in vals:
                    P+=v*c[v]
                    if c[v]>0 and v>m:
                        if P> m*v: ok=False;break
                if not ok: return
                ways=factorial(n)
                for v in vals:
                    ways//=factorial(c[v])
                tot=(tot+ways)%mod
            return
        v=vals[i]
        for k in range(0,min(v,rem)+1):
            c[v]=k
            rec(i+1, rem-k)
        c[v]=0
    rec(0,n)
    return tot%mod

for n in range(1,6):
    b=count_brute(n,10**9+7)
    c=count_char(n,10**9+7)
    print(n, b, c, "OK" if b==c else "MISMATCH")
