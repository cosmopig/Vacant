import sys, itertools, json
from collections import defaultdict

MOD = 998244353

def brute(n, friends):
    # count permutations of 1..n where each friend's set is consecutive
    cnt = 0
    for perm in itertools.permutations(range(1, n+1)):
        pos = {v: i for i, v in enumerate(perm)}
        ok = True
        for S in friends:
            ps = [pos[v] for v in S]
            if max(ps) - min(ps) != len(S) - 1:
                ok = False
                break
        if ok:
            cnt += 1
    return cnt

def solve_decomp(n, friends):
    # signatures
    sig = defaultdict(list)
    for v in range(1, n+1):
        s = frozenset(j for j, S in enumerate(friends) if v in S)
        sig[s].append(v)
    # friend components via union-find
    m = len(friends)
    par = list(range(m))
    def find(x):
        while par[x] != x:
            par[x] = par[par[x]]; x = par[x]
        return x
    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb: par[ra] = rb
    owner = {}
    for j, S in enumerate(friends):
        for v in S:
            if v in owner: union(j, owner[v])
            else: owner[v] = j
    # group singers by (component, signature)
    # free singers: signature empty
    free = len(sig.get(frozenset(), []))
    # components: map comp root -> list of (sig, count)
    comp_types = defaultdict(lambda: defaultdict(int))
    comp_friends = defaultdict(set)
    for j, S in enumerate(friends):
        comp_friends[find(j)].add(j)
    for s, members in sig.items():
        if not s: continue
        comp = find(next(iter(s)))
        comp_types[comp][s] += len(members)
    # for each component compute w_C = number of valid type-sequences (multiset arrangements)
    # brute force over multiset permutations for small N
    def w_comp(types):
        # types: dict label->mult ; labels are frozensets of friend indices (global), but only coords in comp matter
        # coords = union of labels
        items = []
        for L, c in types.items():
            items += [L] * c
        N = len(items)
        # unique permutations of multiset
        seen = set()
        total = 0
        # generate distinct permutations via itertools on indices with dedup
        for perm in set(itertools.permutations(items)):
            # check each coord consecutive
            ok = True
            coords = set()
            for L in perm: coords |= set(L)
            for i in coords:
                idxs = [t for t, L in enumerate(perm) if i in L]
                if idxs and max(idxs) - min(idxs) != len(idxs) - 1:
                    ok = False; break
            if ok: total += 1
        return total
    k = len(comp_types)
    ans = 1
    # (k+f)! * prod_C (w_C * prod c_j!)
    fact = [1]
    for i in range(1, n+2): fact.append(fact[-1]*i % MOD)
    ans = fact[k+free]
    for comp, types in comp_types.items():
        w = w_comp(types)
        internal = w
        for L, c in types.items():
            internal = internal * fact[c] % MOD
        ans = ans * internal % MOD
    return ans

def main():
    import random
    random.seed(1)
    for trial in range(300):
        n = random.randint(1, 7)
        m = random.randint(1, 4)
        friends = []
        for _ in range(m):
            q = random.randint(1, n)
            S = sorted(random.sample(range(1, n+1), q))
            friends.append(set(S))
        b = brute(n, friends)
        d = solve_decomp(n, friends)
        if b != d:
            print('MISMATCH', n, m, friends, 'brute', b, 'decomp', d)
            return
    print('all ok')

main()
