#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int n;
long long counts[205];
int vals[205], nv;
long long total;
long long minval_seen=999;
void rec(int v,int rem){
    if(v==n+2){
        if(rem!=0) return;
        nv=0;
        for(int i=1;i<=n+1;i++) if(counts[i]>0) vals[nv++]=i;
        for(int i=0;i<nv;i++){
            for(int j=i+1;j<nv;j++){
                long long s=0;
                for(int k=0;k<nv;k++) if(vals[k]>=vals[i]&&vals[k]<=vals[j]) s+=vals[k]*counts[vals[k]];
                if(s>(long long)vals[i]*vals[j]) return;
            }
        }
        long long num=1;
        for(int i=2;i<=n;i++) num*=i;
        long long den=1;
        for(int i=1;i<=n+1;i++){ long long f=1; for(int j=2;j<=counts[i];j++) f*=j; den*=f; }
        total += num/den;
        if(vals[0]<minval_seen) minval_seen=vals[0];
        return;
    }
    int maxc = v<rem?v:rem;
    for(int c=0;c<=maxc;c++){ counts[v]=c; rec(v+1,rem-c); }
    counts[v]=0;
}
int main(int argc,char**argv){
    n=atoi(argv[1]);
    rec(1,n);
    printf("n=%d total=%lld minval=%lld\n",n,total,minval_seen);
    return 0;
}
