#include <stdio.h>
#include <stdlib.h>
int n;
long long counts[205];
int vals[205], nv;
// for each min m, track min/max of r=n-c_m and count of multisets
long long bymin[205][205]; // [m][r]
int rmin[205], rmax[205];
int valid(){
    nv=0;
    for(int i=1;i<=n+1;i++) if(counts[i]>0) vals[nv++]=i;
    for(int i=0;i<nv;i++) if(counts[vals[i]]>vals[i]) return 0;
    int m=vals[0], M=vals[nv-1];
    static long long w[205],pre[205],suf[205];
    for(int i=1;i<=n+1;i++) w[i]=i*counts[i];
    pre[0]=0; for(int i=1;i<=n+1;i++) pre[i]=pre[i-1]+w[i];
    suf[n+2]=0; for(int i=n+1;i>=1;i--) suf[i]=suf[i+1]+w[i];
    for(int i=0;i<nv;i++){
        int y=vals[i];
        if(y>m && pre[y]>(long long)m*y) return 0;
        int x=vals[i];
        if(x<M && suf[x]>(long long)x*M) return 0;
    }
    return 1;
}
void rec(int v,int rem){
    if(v==n+2){
        if(rem!=0) return;
        if(!valid()) return;
        int mn=1; while(counts[mn]==0) mn++;
        int r=n-(int)counts[mn];
        bymin[mn][r]++;
        if(rmin[mn]==0||r<rmin[mn])rmin[mn]=r;
        if(r>rmax[mn])rmax[mn]=r;
        return;
    }
    int maxc = v<rem?v:rem;
    for(int c=0;c<=maxc;c++){ counts[v]=c; rec(v+1,rem-c); }
    counts[v]=0;
}
int main(int argc,char**argv){
    n=atoi(argv[1]);
    for(int i=0;i<205;i++){rmin[i]=0;rmax[i]=-1;}
    rec(1,n);
    for(int m=1;m<=n+1;m++){
        long long tot=0; for(int r=0;r<=n;r++) tot+=bymin[m][r];
        if(tot) printf("m=%d r in [%d,%d] mults=%lld\n",m,rmin[m],rmax[m],tot);
    }
    return 0;
}
