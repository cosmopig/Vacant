#include <bits/stdc++.h>
using namespace std;
typedef long long ll; typedef __int128 lll;
int n; lll ans, vecs;
int c[70];
ll fact[70];
lll multinom(){ lll r=fact[n]; for(int v=1;v<=n+1;v++) if(c[v]) r/=fact[c[v]]; return r; }
bool ok(){
    static ll pref[80]; pref[0]=0;
    for(int v=1;v<=n+1;v++) pref[v]=pref[v-1]+(ll)v*c[v];
    for(int x=1;x<=n+1;x++) if(c[x])
        for(int y=x+1;y<=n+1;y++) if(c[y])
            if(pref[y]-pref[x-1] > (ll)x*y) return false;
    return true;
}
void rec(int v,int left){
    if(v==n+2){ if(left==0 && ok()){ ans+=multinom(); vecs++; } return;}
    for(int k=0;k<=min(v,left);k++){ c[v]=k; rec(v+1,left-k);} c[v]=0;
}
int main(int argc,char**argv){ n=atoi(argv[1]); fact[0]=1; for(int i=1;i<70;i++)fact[i]=fact[i-1]*i; rec(1,n);
    // print ans mod small and vecs
    printf("n=%d vecs=%lld ans=%lld\n",n,(ll)vecs,(ll)(ans%1000000007)); }
