from itertools import combinations_with_replacement
from math import factorial

def count(n):
    V=n+1; total=0
    for comb in combinations_with_replacement(range(1,V+1),n):
        x=comb; c=x[0]; S=0; ok=True
        for v in x:
            S+=v
            if S>c*v: ok=False; break
        if ok:
            cnt={}
            for v in x: cnt[v]=cnt.get(v,0)+1
            ways=factorial(n)
            for k in cnt.values(): ways//=factorial(k)
            total+=ways
    return total

for n in range(1,11):
    print(n, count(n))
