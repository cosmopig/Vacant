import itertools

def perfect(seq):
    n=len(seq)
    for mask in range(1,1<<n):
        vals=[seq[i] for i in range(n) if mask>>i&1]
        if max(vals)*min(vals) < sum(vals): return False
    return True

def char_ok(seq):
    # conjectured characterization for n>=3
    n=len(seq)
    vals=set(seq)
    if min(seq) < n-1 or max(seq) > n+1:
        return False
    # values must be subset of {n-1,n,n+1}; count x,y,z
    x=seq.count(n-1); y=seq.count(n); z=seq.count(n+1)
    if x==n: return False  # all n-1
    if x==0:
        return True  # values in {n,n+1} all perfect? need y+z=n, at least one present
    if z==0:
        # contains n-1 and n (y>=1 since not all n-1), no n+1 -> never perfect
        return False
    # all three present (y could be 0? if y==0 then z==0 handled; here z>=1)
    if y==0:
        # {n-1,n+1}: need z <= (n-1)/2 i.e. 2z <= n-1
        return 2*z <= n-1
    # x,y,z >=1
    return z <= x-1 and (n-1)*z >= y

for n in range(3,7):
    bad=0; cnt=0; ccnt=0
    for seq in itertools.product(range(1,n+2),repeat=n):
        p=perfect(seq); c=char_ok(seq)
        if p: cnt+=1
        if c: ccnt+=1
        if p!=c:
            bad+=1
            if bad<10: print("MISMATCH n",n,seq,"perfect",p,"char",c)
    print("n",n,"perfect",cnt,"char",ccnt,"mismatches",bad)
