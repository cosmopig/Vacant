import json, sys
from collections import defaultdict
cases=json.load(open('cases.json'))
c=cases[23]
inp=c['input'].split(); n=int(inp[0]); m=int(inp[1]); pos=2; sets=[]
for i in range(m):
    q=int(inp[pos]); pos+=1
    sets.append(set(map(int,inp[pos:pos+q]))); pos+=q
# find big comp
parent=list(range(m))
def find(x):
    while parent[x]!=x: parent[x]=parent[parent[x]]; x=parent[x]
    return x
def union(a,b):
    ra,rb=find(a),find(b)
    if ra!=rb: parent[ra]=rb
seen={}
for i,s in enumerate(sets):
    for e in s:
        if e in seen: union(i,seen[e])
        else: seen[e]=i
comps={}
for i in range(m): comps.setdefault(find(i),[]).append(i)
big=None
for idxs in comps.values():
    U=set().union(*[sets[i] for i in idxs])
    if len(U)>20: big=(idxs,U)
idxs,U=big
elems=sorted(U); k=len(elems); ix={e:i for i,e in enumerate(elems)}
F=[]
for si in idxs:
    mask=0
    for e in sets[si]:
        if e in ix: mask|=1<<ix[e]
    F.append(mask)
print('k',k,'m',len(F))
cont=[0]*k
for i,S in enumerate(F):
    mm=S
    while mm:
        lsb=mm&-mm; y=lsb.bit_length()-1; mm^=lsb
        cont[y]|=1<<i
full=(1<<k)-1
cur=defaultdict(set)  # P -> set of x
for y in range(k): cur[1<<y].add(y)
for size in range(1,k):
    nxt=defaultdict(set)
    for P,xs in cur.items():
        meetP=0; openlist=[]; notP=(~P)&full
        for i,S in enumerate(F):
            if S&P:
                meetP|=1<<i
                if S&notP: openlist.append(S)
        if openlist:
            inter=openlist[0]
            for S in openlist[1:]: inter&=S
        else: inter=full
        for x in xs:
            cand=((~P)&full)&inter; cx=cont[x]; mm=meetP
            while cand:
                lsb=cand&-cand; y=lsb.bit_length()-1; cand^=lsb
                if (cont[y]&mm)&~cx: continue
                nxt[P|lsb].add(y)
    cur=nxt
    print('size',size+1,'states(P)',len(cur),'xstates',sum(len(v) for v in cur.values()))
    if len(cur)>3000000:
        print('explode'); break
