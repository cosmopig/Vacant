import sys
sys.setrecursionlimit(10000)

def valid(counts):
    vals = sorted(counts)
    for i,x in enumerate(vals):
        s = 0
        for j in range(i, len(vals)):
            z = vals[j]
            s += z*counts[z]
            if s > x*z:
                return False
    return True

def analyze(n):
    vals = list(range(2, n+2))
    counts = {}
    bad_min = set()
    good = 0
    minvals = set()
    def rec(idx, rem):
        nonlocal good
        if idx == len(vals):
            if rem == 0 and valid(counts):
                good += 1
                mn = min(counts)
                minvals.add(mn)
                if mn < n-1:
                    bad_min.add(tuple(counts.get(v,0) for v in vals))
            return
        v = vals[idx]
        for c in range(rem+1):
            if c: counts[v]=c
            else: counts.pop(v,None)
            rec(idx+1, rem-c)
        counts.pop(v,None)
    rec(0,n)
    return good, minvals, bad_min

for n in range(2, 9):
    g, mv, bm = analyze(n)
    print("n=",n,"valid multisets:",g,"min values seen:",sorted(mv),"with min<n-1:",len(bm))
    for b in list(bm)[:5]: print("   ", b)
