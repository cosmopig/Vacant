import itertools, random
from collections import defaultdict
MOD=998244353

def count_component(k, F):
    # F: list of element-bitmasks over k elements
    full=(1<<k)-1
    cont=[0]*k
    for i,S in enumerate(F):
        mm=S
        while mm:
            lsb=mm&-mm; y=lsb.bit_length()-1; mm^=lsb
            cont[y]|=1<<i
    cur=defaultdict(list)
    for y in range(k):
        cur[1<<y].append((y,1))
    for size in range(1,k):
        nxt=defaultdict(list)
        for P,lst in cur.items():
            meetP=0; openlist=[]
            notP=(~P)&full
            for i,S in enumerate(F):
                if S&P:
                    meetP|=1<<i
                    if S&notP: openlist.append(S)
            if openlist:
                inter=openlist[0]
                for S in openlist[1:]: inter&=S
            else:
                inter=full
            for x,v in lst:
                cand=((~P)&full)&inter
                cx=cont[x]; mm=meetP
                while cand:
                    lsb=cand&-cand; y=lsb.bit_length()-1; cand^=lsb
                    if (cont[y]&mm)&~cx: continue
                    nxt[P|lsb].append((y,v))
        cur=nxt
    return sum(v for x,v in cur.get(full,[]))%MOD

def brute(k, F):
    cnt=0
    for perm in itertools.permutations(range(k)):
        pos=[0]*k
        for i,e in enumerate(perm): pos[e]=i
        ok=True
        for S in F:
            ps=[pos[y] for y in range(k) if S>>y&1]
            if max(ps)-min(ps)!=len(ps)-1: ok=False;break
        if ok: cnt+=1
    return cnt

random.seed(0)
bad=0
for t in range(500):
    k=random.randint(1,7); m=random.randint(1,4)
    U=list(range(k))
    F=[]
    for _ in range(m):
        mask=0
        for e in U:
            if random.random()<0.6: mask|=1<<e
        if bin(mask).count('1')>=2: F.append(mask)
    if not F: continue
    d=count_component(k,F)
    b=brute(k,F)
    if d!=b:
        print('MISMATCH',k,F,'dp',d,'brute',b); bad+=1
        if bad>3: break
print('done bad=',bad)
