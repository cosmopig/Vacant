import itertools, sys, math, random
sys.setrecursionlimit(10000)

def count(n, sets):
    cnt = 0
    for perm in itertools.permutations(range(1, n+1)):
        pos = {v:i for i,v in enumerate(perm)}
        ok = True
        for S in sets:
            ps = [pos[v] for v in S]
            if max(ps)-min(ps) != len(S)-1:
                ok = False; break
        if ok: cnt += 1
    return cnt

def components(n, sets):
    parent = list(range(n+1))
    def find(a):
        while parent[a]!=a: parent[a]=parent[parent[a]]; a=parent[a]
        return a
    def union(a,b):
        ra,rb=find(a),find(b)
        if ra!=rb: parent[ra]=rb
    for S in sets:
        it=iter(S)
        first=next(it)
        for v in it: union(first, v)
    comp = {}
    for v in range(1,n+1): comp.setdefault(find(v),[]).append(v)
    return list(comp.values())

random.seed(1)
for trial in range(300):
    n = random.randint(2,7)
    m = random.randint(1,4)
    sets=[]
    for _ in range(m):
        k=random.randint(1,n)
        S=frozenset(random.sample(range(1,n+1),k))
        sets.append(S)
    sets=list(set(sets))
    c=count(n,sets)
    comps=components(n,sets)
    prod=math.factorial(len(comps))
    for C in comps:
        Cset=set(C)
        sub=[S for S in sets if S<=Cset]
        mp={v:i+1 for i,v in enumerate(sorted(C))}
        sub2=[frozenset(mp[v] for v in S) for S in sub]
        g=count(len(C), sub2)
        prod*=g
    if prod!=c:
        print("MISMATCH", n, sets, c, prod, comps); break
else:
    print("component factorization holds on 300 trials")
