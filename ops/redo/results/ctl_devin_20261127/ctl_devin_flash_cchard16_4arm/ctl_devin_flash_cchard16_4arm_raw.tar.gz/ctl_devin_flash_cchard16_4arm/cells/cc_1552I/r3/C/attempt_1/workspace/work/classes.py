import json
from collections import defaultdict
d=json.load(open('cases.json'))
for ci in [5,3,8,23]:
    c=d[ci]
    lines=c['input'].strip().split('\n')
    n,m=map(int,lines[0].split())
    sets=[frozenset(map(int,ln.split()[1:])) for ln in lines[1:]]
    big=[j for j,S in enumerate(sets) if len(S)>=2]
    parent=list(range(m))
    def find(a):
        while parent[a]!=a: parent[a]=parent[parent[a]];a=parent[a]
        return a
    def union(a,b):
        ra,rb=find(a),find(b)
        if ra!=rb:parent[ra]=rb
    owner={}
    for j in big:
        for x in sets[j]:
            if x in owner: union(j,owner[x])
            else: owner[x]=j
    comp=defaultdict(list)
    for j in big: comp[find(j)].append(j)
    for r,fs in comp.items():
        U=set().union(*[sets[f] for f in fs])
        if len(U)<15: continue
        sig=defaultdict(list)
        for x in U:
            s=frozenset(f for f in fs if x in sets[f])
            sig[s].append(x)
        print('=== case',ci,'U',len(U),'friends',len(fs))
        # relabel friends 0..k-1
        idx={f:i for i,f in enumerate(fs)}
        for s,xs in sorted(sig.items(),key=lambda kv:-len(kv[1])):
            print('  class',sorted(idx[f] for f in s),'size',len(xs))
        print('  friend->classes:')
        for f in fs:
            cl=[i for i,(s,xs) in enumerate(sorted(sig.items(),key=lambda kv:-len(kv[1]))) if f in s]
        # friend incidence by class index
        items=sorted(sig.items(),key=lambda kv:-len(kv[1]))
        for i,f in enumerate(fs):
            cls=[j for j,(s,xs) in enumerate(items) if f in s]
            print('   friend',i,'|S|',len(sets[f]),'classes',cls,'sizes',[len(items[j][1]) for j in cls])
