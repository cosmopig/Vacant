import itertools, sys

def perfect(seq):
    n=len(seq)
    for mask in range(1,1<<n):
        vals=[seq[i] for i in range(n) if mask>>i&1]
        mn=min(vals); mx=max(vals); s=sum(vals)
        if mx*mn < s: return False
    return True

for n in range(1,6):
    cnt=0
    examples=[]
    for seq in itertools.product(range(1,n+2),repeat=n):
        if perfect(seq):
            cnt+=1
            if len(examples)<10: examples.append(seq)
    print(n,cnt,examples)
