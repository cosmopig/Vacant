#include <bits/stdc++.h>
using namespace std;
int n;
bool perfect(vector<int>&a){
    int N=1<<n;
    for(int mask=1;mask<N;mask++){
        int mn=1e9,mx=0; long long s=0;
        for(int i=0;i<n;i++) if(mask>>i&1){mn=min(mn,a[i]);mx=max(mx,a[i]);s+=a[i];}
        if((long long)mx*mn<s) return false;
    }
    return true;
}
int main(int argc,char**argv){
    n=atoi(argv[1]);
    long long total=0;
    vector<int> a(n);
    function<void(int)> rec=[&](int i){
        if(i==n){ if(perfect(a)) total++; return;}
        for(int v=1;v<=n+1;v++){a[i]=v;rec(i+1);}
    };
    rec(0);
    printf("%lld\n",total);
}
