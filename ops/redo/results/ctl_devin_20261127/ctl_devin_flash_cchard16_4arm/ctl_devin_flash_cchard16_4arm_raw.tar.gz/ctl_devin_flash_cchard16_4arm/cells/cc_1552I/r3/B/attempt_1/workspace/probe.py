import json, sys
sys.setrecursionlimit(100000)
d=json.load(open('/var/ctlws_devin/redo-a_uc7sf3/w/cases.json'))

def probe(idx, cap=300000):
    c=d[idx]
    lines=c['input'].strip().split('\n')
    n,m=map(int,lines[0].split())
    sets=[]
    for l in lines[1:]:
        t=list(map(int,l.split()))
        sets.append(set(t[1:]))
    full=(1<<n)-1
    fmask=[]
    for s in sets:
        mk=0
        for x in s: mk|=1<<(x-1)
        fmask.append(mk)
    start=0
    seen={0}
    frontier=[0]
    steps=0
    while frontier:
        nf=[]
        for P in frontier:
            allowed=full
            anyopen=False
            for mk in fmask:
                inter=P&mk
                if inter and inter!=mk:
                    anyopen=True
                    allowed&=mk
            if not anyopen:
                allowed=full
            avail=allowed & ~P & full
            a=avail
            while a:
                lb=a&-a
                a^=lb
                Q=P|lb
                if Q not in seen:
                    seen.add(Q); nf.append(Q)
                    if len(seen)>cap:
                        return len(seen), 'CAP'
        frontier=nf
        steps+=1
    return len(seen), steps

for i in [0,2,4,10,18,7]:
    print(i, probe(i), flush=True)
