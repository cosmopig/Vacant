import itertools, sys
def count(n, sets):
    c=0; perms=[]
    for p in itertools.permutations(range(1,n+1)):
        pos={x:i for i,x in enumerate(p)}
        ok=True
        for S in sets:
            ps=[pos[x] for x in S]
            if max(ps)-min(ps)!=len(S)-1: ok=False;break
        if ok: c+=1; perms.append(p)
    return c,perms
n=4; sets=[{1,2,3}]
c,ps=count(n,sets)
print('single {1,2,3} n=4:',c)
print(sorted(ps))
n=5; sets=[{1,2},{3,4},{2,3}]
c,ps=count(n,sets)
print('chain n=5:',c)
print(sorted(ps))
