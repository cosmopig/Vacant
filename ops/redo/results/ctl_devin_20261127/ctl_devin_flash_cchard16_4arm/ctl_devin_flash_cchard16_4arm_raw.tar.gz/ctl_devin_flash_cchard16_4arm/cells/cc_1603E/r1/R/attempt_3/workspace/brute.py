import itertools, sys

def good(sub):
    return max(sub)*min(sub) >= sum(sub)

def perfect(t):
    n=len(t)
    for mask in range(1,1<<n):
        sub=[t[i] for i in range(n) if mask>>i&1]
        if not good(sub):
            return False
    return True

for n in range(1,7):
    cnt=0
    for t in itertools.product(range(1,n+2), repeat=n):
        if perfect(t): cnt+=1
    print(n, cnt)
