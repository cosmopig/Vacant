import itertools, sys, math
sys.setrecursionlimit(10000)

def count_brute(n, sets):
    cnt=0
    for p in itertools.permutations(range(1,n+1)):
        pos={x:i for i,x in enumerate(p)}
        ok=True
        for S in sets:
            ps=[pos[x] for x in S]
            if max(ps)-min(ps)!=len(S)-1: ok=False;break
        if ok: cnt+=1
    return cnt

def decompose(n, sets):
    big=[i for i,S in enumerate(sets) if len(S)>=2]
    parent=list(range(len(sets)))
    def find(a):
        while parent[a]!=a: parent[a]=parent[parent[a]];a=parent[a]
        return a
    def union(a,b):
        ra,rb=find(a),find(b)
        if ra!=rb:parent[ra]=rb
    owner={}
    for i in big:
        for x in sets[i]:
            if x in owner: union(i,owner[x])
            else: owner[x]=i
    from collections import defaultdict
    comp=defaultdict(list)
    for i in big: comp[find(i)].append(i)
    covered=set().union(*[sets[i] for i in big]) if big else set()
    free=n-len(covered)
    total=math.factorial(len(comp)+free)
    for r,fs in comp.items():
        U=sorted(set().union(*[sets[f] for f in fs]))
        cnt=0
        for p in itertools.permutations(U):
            pos={x:i for i,x in enumerate(p)}
            if all(max(pos[x] for x in sets[f])-min(pos[x] for x in sets[f])==len(sets[f])-1 for f in fs):
                cnt+=1
        total=total*cnt%998244353
    return total

cases=[
 (3,[{1,3}]),
 (5,[{1,2},{2,3},{3,4},{4,5},{1,5}]),
 (5,[{1,2,3,4,5}]),
 (2,[{1},{2},{1},{1},{1}]),
 (4,[{1,2},{2,3}]),
 (4,[{1,2},{3,4}]),
 (4,[{1,2},{2,3},{3,4}]),
 (4,[{1,2},{1,3}]),
 (5,[{1,3},{3,5}]),
 (5,[{1,2},{2,3},{1,3}]),
]
for n,sets0 in cases:
    sets=[frozenset(s) for s in sets0]
    c=count_brute(n,sets)
    d=decompose(n,sets)
    print(n,[sorted(s) for s in sets],'brute',c,'decomp',d)
