import sys
sys.setrecursionlimit(10000)

def count_vectors(n, limit=None):
    vals=n+1
    cnts=[0]*(vals+1)
    support=[]
    sols=[]
    def dfs(v, rem, pref_before):
        if v>vals:
            if rem==0: sols.append(tuple(cnts[1:]))
            return
        if limit and len(sols)>=limit: return
        for c in range(0,min(v, rem)+1):
            newpref=pref_before+v*c
            ok=True
            if c>0:
                for i,pref_i in support:
                    if newpref-pref_i > i*v:
                        ok=False;break
                if not ok: continue
                support.append((v,pref_before))
            cnts[v]=c
            dfs(v+1, rem-c, newpref)
            if c>0: support.pop()
            cnts[v]=0
            if limit and len(sols)>=limit: return
    dfs(1,n,0)
    return sols

for n in range(1,13):
    s=count_vectors(n)
    print(n,len(s),'maxsupp',max(sum(x>0 for x in t) for t in s) if s else 0)
