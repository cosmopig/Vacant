from itertools import combinations, product

def good(sub):
    return max(sub)*min(sub) >= sum(sub)

def perfect(seq):
    n=len(seq)
    for r in range(1,n+1):
        for idx in combinations(range(n),r):
            if not good([seq[i] for i in idx]):
                return False
    return True

for n in range(1,5):
    cnt=0
    sols=[]
    for seq in product(range(1,n+2), repeat=n):
        if perfect(seq):
            cnt+=1
            sols.append(seq)
    print(n,cnt)
    if n<=3:
        print(sorted(set(tuple(sorted(s)) for s in sols)))
