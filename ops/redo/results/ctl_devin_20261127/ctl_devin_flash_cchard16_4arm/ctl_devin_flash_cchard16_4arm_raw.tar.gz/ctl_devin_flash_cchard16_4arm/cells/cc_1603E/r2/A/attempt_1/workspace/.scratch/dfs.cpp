#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
int n;
ll MOD;
vector<int> cnt;
vector<ll> suf; // suf[v] = sum_{x>v} c_x*x
ll fact[205], invfact[205];
ll nodes=0, leaves=0;
ll answer=0;
ull mulmod(ull a, ull b){ return (ull)((__uint128_t)a*b%MOD); }
ll powmod(ll a,ll e){ ll r=1; while(e){if(e&1)r=mulmod(r,a);a=mulmod(a,a);e>>=1;} return r; }

void dfs(int v, int rem, ll wprod){
    // wprod = prod invfact[c_x] for x>v  (mod MOD)
    if(v==0){
        if(rem==0){ leaves++; answer = (answer + mulmod(fact[n], wprod))%MOD; }
        return;
    }
    nodes++;
    // compute upper bound for c_v from pairs (v,w), w>v attained
    // c_v*v <= v*w - suf[v] + suf[w]  => c_v <= w - ceil((suf[v]-suf[w])/v)
    ll bound = LLONG_MAX;
    // iterate attained w>v: we stored cnt[]
    for(int w=v+1; w<=n+1; w++) if(cnt[w]>0){
        ll diff = suf[v]-suf[w]; // weight in (v,w]
        // need c_v*v <= v*w - diff  => c_v <= (v*w - diff)/v floor
        ll num = (ll)v*w - diff;
        if(num < 0){ bound = -1; break; }
        ll b = num / v; // floor since num>=0
        if(b < bound) bound = b;
    }
    ll bb;
    if(bound < 1) bb = 0; else bb = min<ll>(bound, (ll)min(v,rem));
    int maxc = (int)bb;
    // also if bound<1 then c_v must be 0
    for(int c=0;c<=maxc;c++){
        cnt[v]=c;
        // update suf for next level: suf[v-1] = suf[v] + c*v
        ll old = suf[v-1];
        suf[v-1] = suf[v] + (ll)c*v;
        dfs(v-1, rem-c, mulmod(wprod, invfact[c]));
        suf[v-1]=old;
        cnt[v]=0;
        if(c==0 && bound<1) break; // only c=0 possible anyway (maxc would be <=0? ensure)
    }
}
int main(int argc,char**argv){
    n=atoi(argv[1]); MOD=atoll(argv[2]);
    fact[0]=1; for(int i=1;i<=n+2;i++) fact[i]=(ll)fact[i-1]*i%MOD;
    invfact[n+2]=powmod(fact[n+2], MOD-2);
    for(int i=n+1;i>=0;i--) invfact[i]=(ll)invfact[i+1]*(i+1)%MOD;
    cnt.assign(n+3,0); suf.assign(n+3,0);
    // suf[v] for v=n+1: weight above n+1 = 0; but values only to n+1.
    // We'll call dfs(n+1, n, 1). suf array: suf[x] must equal sum_{y>x} c_y y at time of use.
    // Initialize suf[n+2]=0; when at v, suf[v] should be weight of values >v = suf[v+1]+c_{v+1}(v+1)? 
    // Simpler: maintain suf[v] as we descend: before dfs(v), suf[v] must be correct = sum_{x>v} c_x x.
    // We set suf[v-1]=suf[v]+c_v*v inside loop. Initially need suf[n+1]=0 (no values >n+1).
    suf[n+1]=0; suf[n+2]=0;
    // but inside dfs(v) we use suf[v] (weight >v) and suf[w] for w>v (weight >w). Those were set when processing w? 
    // When we chose c_w at level w, we set suf[w-1]=suf[w]+c_w*w. So suf[w] remains = weight > w? 
    // suf[w] was set at level w+1's iteration as suf[(w+1)-1]=suf[w+1]+c_{w+1}(w+1) = weight >= w+1 = weight > w. YES correct.
    dfs(n+1, n, 1%MOD);
    printf("n=%d answer=%lld nodes=%lld leaves=%lld\n", n, answer%MOD, nodes, leaves);
}
