import sys
sys.setrecursionlimit(100000)
def gen(n,k,idx,cur,rem,out):
    if idx==k-1:
        cur[idx]=rem; out.append(list(cur)); return
    for x in range(rem+1):
        cur[idx]=x; gen(n,k,idx+1,cur,rem-x,out)

def full(c):
    for i,ci in enumerate(c):
        if ci>i+1: return False
    vals=[i+1 for i,ci in enumerate(c) if ci>0]
    for x in range(len(vals)):
        for y in range(x+1,len(vals)):
            u,v=vals[x],vals[y]
            if u*v < sum(c[w-1]*w for w in range(u,v+1)): return False
    return True

def only_max(c):
    for i,ci in enumerate(c):
        if ci>i+1: return False
    vals=[i+1 for i,ci in enumerate(c) if ci>0]
    L=vals[-1]
    for u in vals[:-1]:
        s=sum(c[w-1]*w for w in range(u,L+1))
        if u*L < s: return False
    return True

def only_adj_pairs_diff(c):
    pass

n=int(sys.argv[1])
out=[]
gen(n,n+1,0,[0]*(n+1),n,out)
diff=0
for c in out:
    if full(c)!=only_max(c):
        diff+=1
        if diff<10: print("c",c,"full",full(c),"maxonly",only_max(c))
print("total diffs",diff)
