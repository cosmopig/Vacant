import json
from collections import defaultdict, Counter
d=json.load(open('cases.json'))
for i,c in enumerate(d):
    lines=c['input'].strip().split('\n')
    n,m=map(int,lines[0].split())
    sets=[]
    for ln in lines[1:]:
        p=list(map(int,ln.split()))
        sets.append(frozenset(p[1:]))
    big=[j for j,S in enumerate(sets) if len(S)>=2]
    parent=list(range(m))
    def find(a):
        while parent[a]!=a: parent[a]=parent[parent[a]];a=parent[a]
        return a
    def union(a,b):
        ra,rb=find(a),find(b)
        if ra!=rb:parent[ra]=rb
    owner={}
    for j in big:
        for x in sets[j]:
            if x in owner: union(j,owner[x])
            else: owner[x]=j
    comp=defaultdict(list)
    for j in big: comp[find(j)].append(j)
    # biggest component
    for r,fs in comp.items():
        U=set().union(*[sets[f] for f in fs])
        if len(U)<15: continue
        sig=defaultdict(list)
        for x in U:
            s=frozenset(f for f in fs if x in sets[f])
            sig[s].append(x)
        sizes=sorted((len(v) for v in sig.values()),reverse=True)
        print('case',i,'U=',len(U),'friends=',len(fs),'sig classes=',len(sig),'top sizes',sizes[:8],'|S|=',sorted(len(sets[f]) for f in fs))
