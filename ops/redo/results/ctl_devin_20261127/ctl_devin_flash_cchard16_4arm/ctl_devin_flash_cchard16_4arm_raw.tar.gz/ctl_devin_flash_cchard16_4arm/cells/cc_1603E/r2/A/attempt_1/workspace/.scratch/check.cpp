#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int n;
vector<int> c;
ll diffs=0, tot=0;
// returns validity under mode: 0=full,1=restricted
bool check(bool restr){
    for(int i=0;i<=n;i++) if(c[i]>i+1) return false;
    vector<int> vals;
    for(int i=0;i<=n;i++) if(c[i]>0) vals.push_back(i+1);
    int L=vals.back();
    auto T=[&](int u,int v){ ll s=0; for(int w=u;w<=v;w++) s+=(ll)c[w-1]*w; return s; };
    if(!restr){
        for(size_t x=0;x<vals.size();x++)for(size_t y=x+1;y<vals.size();y++)
            if((ll)vals[x]*vals[y]<T(vals[x],vals[y])) return false;
        return true;
    } else {
        for(size_t x=0;x+1<vals.size();x++){
            int u=vals[x],v=vals[x+1];
            if((ll)u*v<T(u,v)) return false;
            if((ll)u*L<T(u,L)) return false;
        }
        return true;
    }
}
void gen(int idx,int rem){
    if(idx==n){ c[idx]=rem; tot++;
        if(check(false)!=check(true)) diffs++;
        return;}
    for(int x=0;x<=rem;x++){c[idx]=x;gen(idx+1,rem-x);}
}
int main(int argc,char**argv){ n=atoi(argv[1]); c.assign(n+1,0); gen(0,n); printf("n=%d profiles=%lld diffs=%lld\n",n,tot,diffs);}
