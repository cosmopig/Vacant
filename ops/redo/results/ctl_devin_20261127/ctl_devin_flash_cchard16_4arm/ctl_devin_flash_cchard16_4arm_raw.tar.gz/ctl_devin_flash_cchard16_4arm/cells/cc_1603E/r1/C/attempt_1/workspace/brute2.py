from itertools import combinations_with_replacement
from math import factorial

def count_multiset(n):
    # values 2..n+1 (c1=0 for n>=2). enumerate count vectors via recursion
    vals=list(range(2,n+2))
    m=len(vals)
    counts=[0]*m
    total=0
    examples=[]
    def rec(i, left):
        nonlocal total
        if i==m:
            if left==0:
                # check constraints
                # support values
                sup=[vals[j] for j in range(m) if counts[j]>0]
                ok=True
                # prefix sums of v*c_v
                for x in range(len(sup)):
                    for y in range(x,len(sup)):
                        l,h=sup[x],sup[y]
                        s=sum(vals[j]*counts[j] for j in range(m) if l<=vals[j]<=h)
                        if s> l*h:
                            ok=False; break
                    if not ok: break
                if ok:
                    # weight = n! / prod c!
                    w=factorial(n)
                    for c in counts:
                        w//=factorial(c)
                    total+=w
                    if len(examples)<5:
                        examples.append((counts[:],w))
            return
        for c in range(left+1):
            counts[i]=c
            rec(i+1,left-c)
        counts[i]=0
    rec(0,n)
    return total,examples

for n in range(2,9):
    t,ex=count_multiset(n)
    print(n,t)
    for c,w in ex[:3]: print('   ',c,w)
