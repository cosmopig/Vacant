#include <bits/stdc++.h>
using namespace std;
int main(){
    int n=4;
    vector<vector<int>> ms={{3,3,3,5},{3,3,4,5},{4,4,4,4},{4,4,4,5},{4,4,5,5},{4,5,5,5},{5,5,5,5}};
    for(auto&b:ms){
        map<int,int> c; for(int x:b)c[x]++;
        // interval check
        vector<int> sup; for(auto&p:c)sup.push_back(p.first);
        bool ok=true;
        for(int u:sup)for(int v:sup)if(u<=v){
            long long s=0; for(int x=u;x<=v;x++) if(c.count(x)) s+=(long long)x*c[x];
            if(s>(long long)u*v){ok=false;}
        }
        // multinomial
        long long ways=1; // n! / prod c!
        // compute via multiplicities
        map<int,int> cc=c; int rem=n;
        // simple: permutations = n! / prod c[x]!
        long long num=1; for(int i=2;i<=n;i++)num*=i;
        long long den=1; for(auto&p:cc){long long f=1;for(int i=2;i<=p.second;i++)f*=i;den*=f;}
        printf("%d%d%d%d ok=%d ways=%lld\n",b[0],b[1],b[2],b[3],(int)ok,num/den);
    }
}
