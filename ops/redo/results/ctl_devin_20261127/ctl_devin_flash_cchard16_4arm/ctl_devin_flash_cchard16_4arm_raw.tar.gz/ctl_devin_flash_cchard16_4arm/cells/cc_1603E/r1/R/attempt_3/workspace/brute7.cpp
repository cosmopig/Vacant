#include <bits/stdc++.h>
using namespace std;
int n, a[10];
bool good(const vector<int>& idx){
    int mn=1e9,mx=-1; long long sum=0;
    for(int i:idx){mn=min(mn,a[i]);mx=max(mx,a[i]);sum+=a[i];}
    return (long long)mx*mn>=sum;
}
void rec(int pos){
    if(pos==n){
        int total=1<<n;
        for(int mask=1;mask<total;mask++){
            vector<int> idx;
            for(int i=0;i<n;i++) if(mask>>i&1) idx.push_back(i);
            if(!good(idx)) return;
        }
        for(int i=0;i<n;i++) printf("%d ",a[i]);
        printf("\n");
        return;
    }
    for(int v=1;v<=n+1;v++){a[pos]=v;rec(pos+1);}
}
int main(){cin>>n;rec(0);}
