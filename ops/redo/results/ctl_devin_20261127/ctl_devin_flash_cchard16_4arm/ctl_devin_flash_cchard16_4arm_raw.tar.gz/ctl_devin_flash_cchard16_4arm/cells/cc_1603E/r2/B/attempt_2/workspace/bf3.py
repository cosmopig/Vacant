import itertools

def perfect(seq):
    n=len(seq)
    for mask in range(1,1<<n):
        vals=[seq[i] for i in range(n) if mask>>i&1]
        if max(vals)*min(vals) < sum(vals): return False
    return True

for n in range(2,7):
    minv=99; maxv=0; cnt=0
    haslow=set()
    for seq in itertools.product(range(1,n+2),repeat=n):
        if perfect(seq):
            cnt+=1
            minv=min(minv,min(seq)); maxv=max(maxv,max(seq))
            haslow.add(min(seq))
    print("n",n,"count",cnt,"overall min",minv,"max",maxv,"distinct mins",sorted(haslow))
