#include <bits/stdc++.h>
using namespace std;

int n;
int cnt[64];
vector<int> vals;

bool full_ok(){
    int m=vals.size();
    for(int i=0;i<m;i++)for(int j=i;j<m;j++){
        long long x=vals[i], y=vals[j], s=0;
        for(int l=i;l<=j;l++) s += (long long)cnt[vals[l]]*vals[l];
        if(x*y < s) return false;
    }
    return true;
}

void rec(int v, int rem){
    if(v==n+2){
        if(rem!=0) return;
        vals.clear();
        for(int i=1;i<=n+1;i++) if(cnt[i]) vals.push_back(i);
        if(full_ok()){
            for(int x: vals) printf("%d ", cnt[x]);
            // print as value:count
            printf(" |");
            for(int x: vals) printf(" %d:%d", x, cnt[x]);
            printf("\n");
        }
        return;
    }
    for(int c=0;c<=rem;c++){ cnt[v]=c; rec(v+1, rem-c); }
    cnt[v]=0;
}

int main(int argc,char**argv){
    n=atoi(argv[1]);
    memset(cnt,0,sizeof cnt);
    rec(1,n);
    return 0;
}
