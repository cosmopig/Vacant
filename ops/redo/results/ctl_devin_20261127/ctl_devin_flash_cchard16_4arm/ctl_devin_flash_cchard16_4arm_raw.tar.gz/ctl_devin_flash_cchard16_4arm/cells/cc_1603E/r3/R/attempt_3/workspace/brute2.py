import itertools, sys
from itertools import product, combinations
from collections import Counter

def perfect_fast(seq):
    cnt=Counter(seq)
    sv=sorted(cnt)
    # multiplicity constraint for every value: c_v <= v
    for v in sv:
        if cnt[v] > v:
            return False
    if len(sv)==1:
        return True
    pref=[0]
    for v in sv:
        pref.append(pref[-1]+v*cnt[v])
    t=len(sv)
    for i in range(t):
        for j in range(i+1,t):
            m,M=sv[i],sv[j]
            if m*M < pref[j+1]-pref[i]:
                return False
    return True

def good(sub):
    return max(sub)*min(sub) >= sum(sub)
def perfect_brute(seq):
    n=len(seq)
    for r in range(1,n+1):
        for idx in combinations(range(n),r):
            if not good([seq[i] for i in idx]):
                return False
    return True

for n in range(1,5):
    bad=0
    for seq in product(range(1,n+2),repeat=n):
        if perfect_fast(seq)!=perfect_brute(seq):
            bad+=1
            print("MISMATCH",seq,perfect_fast(seq),perfect_brute(seq))
            if bad>3: break
    print("n",n,"mismatches",bad)

for n in range(1,8):
    cnt=0
    for seq in product(range(1,n+2),repeat=n):
        if perfect_fast(seq):
            cnt+=1
    print(n,cnt,flush=True)
