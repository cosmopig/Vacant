#include <bits/stdc++.h>
using namespace std;
int n, vmax;
vector<int> c;
long long fullbad=0, cgbad=0, tot=0;

bool full_ok(){
    vector<int> P;
    for(int v=1;v<=vmax;v++) if(c[v]>0) P.push_back(v);
    int k=P.size();
    // prefix sums of c_v*v over all integer v
    // S(i,j) over [P[i],P[j]]
    vector<long long> pre(vmax+2,0);
    for(int v=1;v<=vmax;v++) pre[v+1]=pre[v]+(long long)c[v]*v;
    for(int i=0;i<k;i++)for(int j=i;j<k;j++){
        long long s=pre[P[j]+1]-pre[P[i]];
        if(s>(long long)P[i]*P[j]) return false;
    }
    return true;
}
bool cg_ok(){
    vector<int> P;
    for(int v=1;v<=vmax;v++) if(c[v]>0) P.push_back(v);
    int k=P.size();
    vector<long long> pre(vmax+2,0);
    for(int v=1;v<=vmax;v++) pre[v+1]=pre[v]+(long long)c[v]*v;
    // p=q caps: c_p*p <= p*p i.e. c_p<=p (guaranteed by gen, skip)
    for(int i=0;i<k;i++){
        for(int j=i+1;j<k;j++){
            // only consecutive and global
            if(j!=i+1 && !(i==0&&j==k-1)) continue;
            long long s=pre[P[j]+1]-pre[P[i]];
            if(s>(long long)P[i]*P[j]) return false;
        }
    }
    return true;
}
void rec(int v,int rem){
    if(v==vmax+1){
        if(rem==0){
            tot++;
            bool f=full_ok(), g=cg_ok();
            if(f!=g){ cgbad++; if(cgbad<=5){ for(int x=1;x<=vmax;x++)printf("%d ",c[x]); printf(" full=%d cg=%d\n",f,g);} }
        }
        return;
    }
    for(int kk=0;kk<=min(v,rem);kk++){c[v]=kk; rec(v+1,rem-kk);}
    c[v]=0;
}
int main(int argc,char**argv){
    n=atoi(argv[1]); vmax=n+1; c.assign(vmax+1,0);
    rec(1,n);
    printf("n=%d tot=%lld mismatches=%lld\n",n,tot,cgbad);
}
