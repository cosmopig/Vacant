M=998244353
P=1000000007
def solve_brute(n):
    a=sorted(range(1,n+1), key=lambda x: str(x))
    tot=0
    C=0
    for i,val in enumerate(a,1):
        u=i%M; v=val%M
        tot=(tot+(u-v)%M)%P
        if u<v: C+=1
    return tot, (M*C)%P, C
for n in [3,12,21,100,272,2888]:
    print(n, solve_brute(n))
print([solve_brute(n)[2] for n in range(1,130)])
