import sys

def main():
    data = sys.stdin.read().split()
    n = int(data[0]); M = int(data[1])
    if n == 1:
        print(2 % M)
        return
    fact = [1] * (n + 1)
    for i in range(1, n + 1):
        fact[i] = fact[i - 1] * i % M
    invfact = [1] * (n + 1)
    invfact[n] = pow(fact[n], M - 2, M)
    for i in range(n, 0, -1):
        invfact[i - 1] = invfact[i] * i % M

    def multinomial(a, b, c):
        return fact[a + b + c] * invfact[a] % M * invfact[b] % M * invfact[c] % M

    ans = pow(2, n, M)
    # p = count of n-1, q = count of n, r = count of n+1
    # perfect iff p == 0, or (r >= 1 and p > r)
    for r in range(1, (n - 1) // 2 + 1):
        for p in range(r + 1, n - r + 1):
            q = n - p - r
            ans = (ans + multinomial(p, q, r)) % M
    print(ans)

main()
