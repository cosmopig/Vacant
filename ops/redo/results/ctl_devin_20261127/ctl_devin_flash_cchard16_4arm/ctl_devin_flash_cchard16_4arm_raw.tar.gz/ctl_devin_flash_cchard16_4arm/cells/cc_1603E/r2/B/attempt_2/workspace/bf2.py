import itertools

def perfect(seq):
    n=len(seq)
    for mask in range(1,1<<n):
        vals=[seq[i] for i in range(n) if mask>>i&1]
        if max(vals)*min(vals) < sum(vals): return False
    return True

for n in (3,4):
    print("=== n",n)
    for seq in itertools.product(range(1,n+2),repeat=n):
        if perfect(seq):
            print(''.join(map(str,seq)))
