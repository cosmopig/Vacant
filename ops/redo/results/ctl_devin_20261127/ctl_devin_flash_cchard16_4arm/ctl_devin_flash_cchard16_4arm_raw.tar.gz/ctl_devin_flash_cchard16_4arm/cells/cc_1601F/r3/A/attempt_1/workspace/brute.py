import sys
M = 998244353
P = 1000000007

def brute(n):
    a = sorted(range(1, n+1), key=lambda x: str(x))
    s = 0
    C = 0
    for i, v in enumerate(a, 1):
        s = (s + (i - v) % M) % P
        if i % M < v % M:
            C += 1
    return s, C

for n in [3, 12, 21, 100, 272, 985, 1395]:
    s, C = brute(n)
    print(n, s, C, "check:", (M * (C % P)) % P == s)
