#include <stdio.h>
#include <stdlib.h>
int n;
long long counts[205];
int vals[205], nv;
long long c2only=0, c3only=0, neither=0, both=0, tot=0;
void rec(int v,int rem){
    if(v==n+2){
        if(rem!=0) return;
        nv=0;
        for(int i=1;i<=n+1;i++) if(counts[i]>0) vals[nv++]=i;
        for(int i=0;i<nv;i++) if(counts[vals[i]]>vals[i]) return;
        int m=vals[0], M=vals[nv-1];
        static long long w[205],pre[205],suf[205];
        for(int i=1;i<=n+1;i++) w[i]=i*counts[i];
        pre[0]=0; for(int i=1;i<=n+1;i++) pre[i]=pre[i-1]+w[i];
        suf[n+2]=0; for(int i=n+1;i>=1;i--) suf[i]=suf[i+1]+w[i];
        int ok2=1,ok3=1;
        for(int i=0;i<nv;i++){
            int y=vals[i];
            if(y>m && pre[y]>(long long)m*y) ok2=0;
            int x=vals[i];
            if(x<M && suf[x]>(long long)x*M) ok3=0;
        }
        tot++;
        if(ok2&&ok3)both++; else if(ok2)c2only++; else if(ok3)c3only++; else neither++;
        if(ok2&&!ok3 && c2only<=5){printf("C2only n=%d: ",n);for(int i=0;i<nv;i++)printf("%d:%lld ",vals[i],counts[vals[i]]);printf("\n");}
        return;
    }
    int maxc = v<rem?v:rem;
    for(int c=0;c<=maxc;c++){ counts[v]=c; rec(v+1,rem-c); }
    counts[v]=0;
}
int main(int argc,char**argv){
    n=atoi(argv[1]);
    rec(1,n);
    printf("n=%d tot=%lld both=%lld c2only=%lld c3only=%lld neither=%lld\n",n,tot,both,c2only,c3only,neither);
    return 0;
}
