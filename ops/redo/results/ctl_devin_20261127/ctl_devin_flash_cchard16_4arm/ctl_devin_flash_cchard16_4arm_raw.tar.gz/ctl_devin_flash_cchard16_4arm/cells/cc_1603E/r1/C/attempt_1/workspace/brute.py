from itertools import product

def good(sub):
    return max(sub)*min(sub) >= sum(sub)

def perfect(a):
    n=len(a)
    for mask in range(1,1<<n):
        sub=[a[i] for i in range(n) if mask>>i&1]
        if not good(sub):
            return False
    return True

for n in range(1,6):
    vals=list(range(1,n+2))
    cnt=0
    seqs=[]
    for a in product(vals,repeat=n):
        if perfect(list(a)):
            cnt+=1
            if n<=4: seqs.append(a)
    print(n,cnt)
    if n<=4:
        for s in seqs: print(' ',s)
