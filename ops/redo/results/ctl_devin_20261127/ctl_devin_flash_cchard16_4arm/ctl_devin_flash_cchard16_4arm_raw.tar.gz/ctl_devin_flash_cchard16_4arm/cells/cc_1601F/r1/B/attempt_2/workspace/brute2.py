M=998244353
P=10**9+7
def Q(n):
    vals=sorted(map(str,range(1,n+1)))
    q=0
    for i,s in enumerate(vals,1):
        x=int(s)
        d=i-x
        q += -(d//M)
    return q
for n in [9,10,11,19,20,99,100,101,109,110,199,200,999,1000,1001,9999,10000,10001,99999,100000]:
    print(n, Q(n))
