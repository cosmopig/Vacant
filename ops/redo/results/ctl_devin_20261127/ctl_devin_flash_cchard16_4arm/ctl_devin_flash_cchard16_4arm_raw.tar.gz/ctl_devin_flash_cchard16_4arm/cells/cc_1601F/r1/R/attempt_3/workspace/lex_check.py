def digits(x): return list(map(int,str(x)))
def solve_pos(n,v):
    K=len(str(n))
    if v < 10**(K-1):
        ds=digits(v); L=len(ds)
        R0=(ds[0]-1)*((10**(K-1)-1)//9) + (L-1)
        for j in range(2,L+1):
            T=(10**(K-j)-1)//9
            R0 += ds[j-1]*T
        A=10**(K-2); Pmax=n//10; r=n%10
        s=K-1-L
        B=v*(10**s)
        U=min(Pmax,B-1)
        E=0
        if U>=A:
            if U<Pmax:
                E=10*(U-A+1)
            else:
                E=10*(Pmax-A)+(r+1)
        return R0+E+1
    else:
        p=v//10; d=v%10; ds=digits(p); L=len(ds)
        assert L==K-1
        R0=(ds[0]-1)*((10**(K-1)-1)//9) + (L-1)
        for j in range(2,L+1):
            T=(10**(K-j)-1)//9
            R0 += ds[j-1]*T
        A=10**(K-2); Pmax=n//10; r=n%10
        U=min(Pmax,p-1); E=0
        if U>=A:
            if U<Pmax:
                E=10*(U-A+1)
            else:
                E=10*(Pmax-A)+(r+1)
        return R0+E+1+d+1

def pos_all(n):
    a=[None]*(n+1)
    for v in range(1,n+1):
        if len(str(n))==1:
            a[v]=v
        else:
            a[solve_pos(n,v)]=v
    return a[1:]
if __name__=='__main__':
    for n in [1,3,9,10,12,20,21,99,100,200,999,1000,12345]:
        got=pos_all(n)
        exp=[int(x) for x in sorted(map(str,range(1,n+1)))]
        ok=exp==got
        print(n,ok)
        if not ok:
            for i,(x,y) in enumerate(zip(got,exp),1):
                if x!=y: print('first diff',i,x,y); break
