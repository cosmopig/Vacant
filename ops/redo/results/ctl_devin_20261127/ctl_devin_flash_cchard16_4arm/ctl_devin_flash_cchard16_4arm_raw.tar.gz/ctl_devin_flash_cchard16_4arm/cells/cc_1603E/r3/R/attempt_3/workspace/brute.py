import itertools

def good(sub):
    return max(sub)*min(sub) >= sum(sub)

def perfect(seq):
    n=len(seq)
    for r in range(1,n+1):
        for idx in itertools.combinations(range(n),r):
            sub=[seq[i] for i in idx]
            if not good(sub):
                return False
    return True

for n in range(1,6):
    cnt=0
    vals=range(1,n+2)
    for seq in itertools.product(vals,repeat=n):
        if perfect(seq):
            cnt+=1
    print(n,cnt, flush=True)
