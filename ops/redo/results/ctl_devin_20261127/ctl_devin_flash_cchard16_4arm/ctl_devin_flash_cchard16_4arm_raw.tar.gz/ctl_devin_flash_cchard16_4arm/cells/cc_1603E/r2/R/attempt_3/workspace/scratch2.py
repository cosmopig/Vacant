import sys
from itertools import product
sys.setrecursionlimit(10000)

def gen_multisets(n, vmax):
    # multiplicity vectors c[1..vmax], sum n, c_v <= v
    res=[]
    c=[0]*(vmax+1)
    def rec(v, rem):
        if v==vmax+1:
            if rem==0: res.append(tuple(c[1:]))
            return
        for k in range(0, min(v,rem)+1):
            c[v]=k
            rec(v+1, rem-k)
        c[v]=0
    rec(1,n)
    return res

def present(c):
    return [i+1 for i,x in enumerate(c) if x>0]

def full_ok(c):
    P=present(c)
    for p in P:
        for q in P:
            if p>q: continue
            s=sum(c[v-1]*v for v in range(p,q+1))
            if s>p*q: return False
    return True

def consec_ok(c):
    P=present(c)
    # only consecutive present pairs + p=q
    for i,p in enumerate(P):
        for q in P[i:]:
            if q!=p and P.index(q)!=P.index(p)+1: pass
    # simpler: check p=q and consecutive
    for p in P:
        s=c[p-1]*p
        if s>p*p: return False
    for i in range(len(P)-1):
        p,q=P[i],P[i+1]
        s=sum(c[v-1]*v for v in range(p,q+1))
        if s>p*q: return False
    return True

def consec_global_ok(c):
    P=present(c)
    for p in P:
        s=c[p-1]*p
        if s>p*p: return False
    for i in range(len(P)-1):
        p,q=P[i],P[i+1]
        s=sum(c[v-1]*v for v in range(p,q+1))
        if s>p*q: return False
    # global min-max
    p,q=P[0],P[-1]
    s=sum(c[v-1]*v for v in range(p,q+1))
    if s>p*q: return False
    return True

n=int(sys.argv[1]) if len(sys.argv)>1 else 8
vmax=n+1
bad_consec=0
bad_cg=0
tot=0
for c in gen_multisets(n,vmax):
    tot+=1
    f=full_ok(c)
    if f!=consec_ok(c):
        bad_consec+=1
        if bad_consec<=3: print("consec mismatch",c,full_ok(c),consec_ok(c))
    if f!=consec_global_ok(c):
        bad_cg+=1
        if bad_cg<=3: print("cg mismatch",c,full_ok(c),consec_global_ok(c))
print("n",n,"total",tot,"consec mismatches",bad_consec,"cg mismatches",bad_cg)
