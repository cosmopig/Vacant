import itertools, sys
from collections import Counter

def perfect(seq):
    n=len(seq)
    # precompute all subset masks' (min,max,sum) incrementally? just brute
    for mask in range(1,1<<n):
        mn=10**9; mx=0; s=0
        for i in range(n):
            if mask>>i&1:
                v=seq[i]; mn=min(mn,v); mx=max(mx,v); s+=v
        if mx*mn < s: return False
    return True

n=int(sys.argv[1])
cnt=0
valset=set()
multisets={}
for seq in itertools.product(range(1,n+2),repeat=n):
    if perfect(seq):
        cnt+=1
        valset|=set(seq)
        t=tuple(sorted(seq))
        multisets[t]=multisets.get(t,0)+1
print("n=",n,"count=",cnt,"values used:",sorted(valset))
for k in sorted(multisets): print("   ",k)
