import sys
from math import factorial
sys.setrecursionlimit(100000)
MOD=10**9+7

def count_char(n, mod=MOD):
    vals=list(range(2,n+2))
    tot=0
    c=[0]*(n+2)
    fact=[factorial(i) for i in range(n+1)]
    def rec(i, rem):
        nonlocal tot
        if i==len(vals):
            if rem==0:
                present=[v for v in vals if c[v]>0]
                if not present: return
                m=present[0]
                for v in vals:
                    if c[v]>v: return
                P=0
                ok=True
                for v in vals:
                    P+=v*c[v]
                    if c[v]>0 and v>m:
                        if P> m*v: ok=False;break
                if not ok: return
                ways=fact[n]
                for v in vals:
                    ways=ways*pow(fact[c[v]],mod-2,mod)%mod
                tot=(tot+ways)%mod
            return
        v=vals[i]
        for k in range(0,min(v,rem)+1):
            c[v]=k
            rec(i+1, rem-k)
        c[v]=0
    rec(0,n)
    return tot

for n in range(2,13):
    print(n, count_char(n))
