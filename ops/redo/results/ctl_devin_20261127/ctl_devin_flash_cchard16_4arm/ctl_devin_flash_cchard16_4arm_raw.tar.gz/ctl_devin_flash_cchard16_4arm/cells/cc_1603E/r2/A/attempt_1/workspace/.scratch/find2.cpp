#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int n; vector<int> c; ll pre[256]; int valsbuf[256];
int K; // how many successors to check
bool restr(){
    for(int i=0;i<=n;i++) if(c[i]>i+1) return false;
    int k=0; for(int i=0;i<=n;i++) if(c[i]>0) valsbuf[k++]=i+1;
    int L=valsbuf[k-1];
    for(int x=0;x<k;x++){
        int u=valsbuf[x];
        for(int d=1; d<=K && x+d<k; d++){
            int v=valsbuf[x+d];
            if((ll)u*v < pre[v]-pre[u-1]) return false;
        }
        if(x+1<k && (ll)u*L < pre[L]-pre[u-1]) return false;
    }
    return true;
}
ll diffs=0,tot=0;
void gen(int idx,int rem){
    if(idx==n){ c[idx]=rem;
        pre[0]=0; for(int i=1;i<=n+1;i++) pre[i]=pre[i-1]+(ll)c[i-1]*i;
        // full check
        for(int i=0;i<=n;i++) if(c[i]>i+1){tot++;return;}
        int k=0; for(int i=0;i<=n;i++) if(c[i]>0) valsbuf[k++]=i+1;
        bool a=true;
        for(int x=0;x<k&&a;x++)for(int y=x+1;y<k;y++)
            if((ll)valsbuf[x]*valsbuf[y] < pre[valsbuf[y]]-pre[valsbuf[x]-1]){a=false;break;}
        tot++;
        if(a!=restr()) diffs++;
        return;}
    for(int x=0;x<=rem;x++){c[idx]=x;gen(idx+1,rem-x);}
}
int main(int argc,char**argv){ n=atoi(argv[1]); K=atoi(argv[2]); c.assign(n+1,0); gen(0,n); printf("n=%d K=%d profiles=%lld diffs=%lld\n",n,K,tot,diffs);}
