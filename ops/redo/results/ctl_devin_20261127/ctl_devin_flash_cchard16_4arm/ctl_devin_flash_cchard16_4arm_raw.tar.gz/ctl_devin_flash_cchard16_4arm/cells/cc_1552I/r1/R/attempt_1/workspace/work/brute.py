import itertools, sys
from functools import lru_cache

def count_valid(elems, sets):
    idx = {e:i for i,e in enumerate(elems)}
    smasks = []
    for S in sets:
        m=0
        for e in S: m|=1<<idx[e]
        smasks.append(m)
    full=(1<<len(elems))-1
    @lru_cache(maxsize=None)
    def dp(mask):
        if mask==full: return 1
        inter = full
        for sm in smasks:
            inter_s = sm & mask
            if inter_s!=0 and inter_s!=sm:
                inter &= sm
        allowed = (~mask) & full & inter
        total=0
        a=allowed
        while a:
            b=a&-a; a^=b
            total+=dp(mask|b)
        return total
    return dp(0)

# brute force check vs permutations
def brute_perm(elems, sets):
    c=0
    for p in itertools.permutations(elems):
        pos={e:i for i,e in enumerate(p)}
        ok=True
        for S in sets:
            ps=sorted(pos[e] for e in S)
            if ps[-1]-ps[0]!=len(S)-1: ok=False;break
        if ok:c+=1
    return c

import random
random.seed(1)
for trial in range(300):
    s=random.randint(2,7)
    elems=list(range(s))
    # random family covering elems, connected-ish
    sets=[]
    k=random.randint(1,4)
    allsubs=[frozenset(c) for r in range(2,s+1) for c in itertools.combinations(elems,r)]
    for _ in range(k):
        sets.append(random.choice(allsubs))
    # ensure cover
    cov=set().union(*sets) if sets else set()
    if cov!=set(elems): continue
    a=count_valid(elems,sets)
    b=brute_perm(elems,sets)
    if a!=b:
        print('MISMATCH',elems,sets,a,b); break
else:
    print('all ok')
