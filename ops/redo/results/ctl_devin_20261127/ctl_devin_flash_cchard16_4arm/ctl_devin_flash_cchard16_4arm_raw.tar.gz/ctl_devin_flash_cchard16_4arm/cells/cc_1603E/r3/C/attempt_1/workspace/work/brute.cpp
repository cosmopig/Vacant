#include <bits/stdc++.h>
using namespace std;
long long check_subset(int n, vector<int>& a){
    int N=1<<n;
    for(int m=1;m<N;m++){
        int mn=1e9,mx=-1; long long s=0;
        for(int i=0;i<n;i++) if(m>>i&1){mn=min(mn,a[i]);mx=max(mx,a[i]);s+=a[i];}
        if((long long)mx*mn < s) return 0;
    }
    return 1;
}
long long check_interval(int n, vector<int>& a){
    int c[205]={0};
    for(int x:a)c[x]++;
    vector<int> sup;
    for(int x=1;x<=n+1;x++) if(c[x])sup.push_back(x);
    for(int u:sup)for(int v:sup) if(u<=v){
        long long s=0;
        for(int x=u;x<=v;x++) s += (long long)x*c[x];
        if(s > (long long)u*v) return 0;
    }
    return 1;
}
int main(){
    for(int n=1;n<=7;n++){
        long long cnt=0, cntI=0;
        vector<int> a(n);
        function<void(int)> rec=[&](int i){
            if(i==n){ cnt += check_subset(n,a); cntI += check_interval(n,a); return;}
            for(int x=1;x<=n+1;x++){a[i]=x;rec(i+1);}
        };
        rec(0);
        printf("n=%d count=%lld interval=%lld\n",n,cnt,cntI);
    }
}
