#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int n;
vector<int> c;
ll diffs=0, tot=0, minval=1e18, cntmin=0;
ll pre[256];
int valsbuf[256];
bool checkfull(int &mn){
    for(int i=0;i<=n;i++) if(c[i]>i+1) return false;
    int k=0;
    for(int i=0;i<=n;i++) if(c[i]>0) valsbuf[k++]=i+1;
    mn=valsbuf[0];
    for(int x=0;x<k;x++)for(int y=x+1;y<k;y++)
        if((ll)valsbuf[x]*valsbuf[y] < pre[valsbuf[y]]-pre[valsbuf[x]-1]) return false;
    return true;
}
bool checkrestr(){
    for(int i=0;i<=n;i++) if(c[i]>i+1) return false;
    int k=0;
    for(int i=0;i<=n;i++) if(c[i]>0) valsbuf[k++]=i+1;
    int L=valsbuf[k-1];
    for(int x=0;x+1<k;x++){
        int u=valsbuf[x],v=valsbuf[x+1];
        if((ll)u*v < pre[v]-pre[u-1]) return false;
        if((ll)u*L < pre[L]-pre[u-1]) return false;
    }
    return true;
}
void gen(int idx,int rem){
    if(idx==n){ c[idx]=rem;
        pre[0]=0; for(int i=1;i<=n+1;i++) pre[i]=pre[i-1]+(ll)c[i-1]*i;
        tot++;
        int mn; bool a=checkfull(mn), b=checkrestr();
        if(a!=b) diffs++;
        if(a){ if(mn<minval){minval=mn;cntmin=1;} else if(mn==minval) cntmin++; }
        return;}
    for(int x=0;x<=rem;x++){c[idx]=x;gen(idx+1,rem-x);}
}
int main(int argc,char**argv){ n=atoi(argv[1]); c.assign(n+1,0); gen(0,n); printf("n=%d profiles=%lld diffs=%lld minval=%lld cntmin=%lld\n",n,tot,diffs,minval,cntmin);}
