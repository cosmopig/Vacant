#include <stdio.h>
#include <stdlib.h>
int n;
long long counts[205];
int vals[205], nv;
long long bad=0, tot=0;
void rec(int v,int rem){
    if(v==n+2){
        if(rem!=0) return;
        nv=0;
        for(int i=1;i<=n+1;i++) if(counts[i]>0) vals[nv++]=i;
        int m=vals[0], M=vals[nv-1];
        int anchor_ok=1, full_ok=1;
        // multiplicity
        for(int i=0;i<nv;i++) if(counts[vals[i]]>vals[i]){anchor_ok=full_ok=0;break;}
        // prefix sums P(t)=sum_{v<=t} v c_v ; suffix Q(t)=sum_{v>=t}
        // compute arrays indexed by value
        static long long w[205];
        for(int i=1;i<=n+1;i++) w[i]=i*counts[i];
        // prefix
        static long long pre[205]; pre[0]=0;
        for(int i=1;i<=n+1;i++) pre[i]=pre[i-1]+w[i];
        static long long suf[205]; suf[n+2]=0;
        for(int i=n+1;i>=1;i--) suf[i]=suf[i+1]+w[i];
        // anchor: for each present y>m: pre[y]<=m*y ; for each present x<M: suf[x]<=x*M
        for(int i=0;i<nv;i++){
            int y=vals[i];
            if(y>m && pre[y]>(long long)m*y) anchor_ok=0;
            int x=vals[i];
            if(x<M && suf[x]>(long long)x*M) anchor_ok=0;
        }
        // full: all pairs
        for(int i=0;i<nv && full_ok;i++)
            for(int j=i+1;j<nv;j++){
                long long s=pre[vals[j]]-pre[vals[i]-1];
                if(s>(long long)vals[i]*vals[j]){full_ok=0;break;}
            }
        if(anchor_ok&&!full_ok){bad++; if(bad<=5){printf("BAD n=%d: ",n);for(int i=0;i<nv;i++)printf("%d:%lld ",vals[i],counts[vals[i]]);printf("\n");}}
        tot++;
        return;
    }
    int maxc = v<rem?v:rem;
    for(int c=0;c<=maxc;c++){ counts[v]=c; rec(v+1,rem-c); }
    counts[v]=0;
}
int main(int argc,char**argv){
    n=atoi(argv[1]);
    rec(1,n);
    printf("n=%d vectors=%lld anchor_not_full=%lld\n",n,tot,bad);
    return 0;
}
