#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long u64;
const ll MOD = 998244353;

static ll fact[256];

// Count permutations of `elems` (original singer ids, all in one component)
// such that every set in `sets` (each a subset of elems, size>=2) is contiguous.
// Returns count mod MOD, counting element-level permutations.
ll solveComponent(const vector<int>& elems, vector<vector<int>> sets){
    int E = elems.size();
    unordered_map<int,int> pos;
    for(int i=0;i<E;i++) pos[elems[i]]=i;

    // Iteratively: group elements into atoms by signature over current sets;
    // drop sets whose atom-mask has popcount<=1 (auto-satisfied); repeat.
    vector<int> atomOfElem;   // per element position -> atom id
    vector<int> atomSize;     // per atom -> number of elements
    vector<u64> setMasks;     // per set -> atom bitmask (requires NA<=63)
    bool smallAtoms = true;

    while(true){
        int W = sets.size();
        int words = (W+63)/64;
        vector<vector<u64>> sig(E, vector<u64>(words,0));
        for(int j=0;j<W;j++)
            for(int e:sets[j]) sig[pos[e]][j>>6] |= (1ULL<<(j&63));

        map<vector<u64>,int> sigMap;
        vector<int> aOE(E,-1);
        vector<int> sizes;
        for(int i=0;i<E;i++){
            auto it=sigMap.find(sig[i]);
            if(it==sigMap.end()){
                int id=(int)sigMap.size();
                sigMap[sig[i]]=id;
                sizes.push_back(0);
                aOE[i]=id;
            } else aOE[i]=it->second;
            sizes[aOE[i]]++;
        }
        int NA = sigMap.size();

        vector<u64> masks(W,0);
        bool dropped=false;
        vector<vector<int>> nextSets;
        for(int j=0;j<W;j++){
            u64 mk=0;
            for(int e:sets[j]) mk |= (1ULL<<aOE[pos[e]]);
            masks[j]=mk;
            if(__builtin_popcountll(mk)<=1) dropped=true;
            else nextSets.push_back(sets[j]);
        }

        if(NA>62){
            // fallback: every element its own atom (correct, possibly slower)
            smallAtoms=false;
            NA=E;
            aOE.resize(E);
            for(int i=0;i<E;i++) aOE[i]=i;
            sizes.assign(E,1);
            masks.assign(W,0);
            for(int j=0;j<W;j++){
                u64 mk=0;
                for(int e:sets[j]) mk|=(1ULL<<aOE[pos[e]]);
                masks[j]=mk;
            }
            atomOfElem=aOE; atomSize=sizes; setMasks=masks;
            break;
        }

        if(!dropped){
            atomOfElem=aOE; atomSize=sizes; setMasks=masks;
            break;
        }
        sets=nextSets;
        if(sets.empty()){
            // no effective constraints: all E! permutations valid
            return fact[E];
        }
    }

    int NA = atomSize.size();
    u64 full = (1ULL<<NA)-1;

    // DP over subsets of atoms: dp[P] = # orderings of P as valid prefix
    unordered_map<u64,ll> dp, ndp;
    dp.reserve(1<<15);
    dp[0]=1;
    int T = setMasks.size();
    // Precompute for speed: for each state we need intersection of partially-covered sets.
    for(int lev=0; lev<NA; lev++){
        ndp.clear();
        for(auto&pr:dp){
            u64 P=pr.first; ll v=pr.second;
            u64 inter=~0ULL; bool open=false;
            for(int j=0;j<T;j++){
                u64 S=setMasks[j];
                u64 cov=S&P;
                if(cov && cov!=S){ inter&=S; open=true; }
            }
            u64 allowed = open ? (inter & ~P & full) : (~P & full);
            while(allowed){
                int b=__builtin_ctzll(allowed);
                allowed&=allowed-1;
                u64 NP=P|(1ULL<<b);
                ll& ref=ndp[NP];
                ref+=v; if(ref>=MOD) ref-=MOD;
            }
        }
        dp.swap(ndp);
        if(dp.empty()) return 0;
    }
    ll ways = dp.count(full)?dp[full]:0;
    // expand atoms to elements: each atom of size s contributes s! orderings
    for(int s:atomSize) ways=ways*fact[s]%MOD;
    return ways;
}

int main(){
    fact[0]=1;
    for(int i=1;i<256;i++) fact[i]=fact[i-1]*i%MOD;

    int n,m;
    if(!(cin>>n>>m)) return 0;
    vector<vector<int>> sets(m);
    for(int i=0;i<m;i++){
        int q; cin>>q;
        sets[i].resize(q);
        for(int j=0;j<q;j++) cin>>sets[i][j];
    }

    vector<vector<int>> big;
    for(auto&s:sets) if(s.size()>1) big.push_back(s);

    // union-find on elements appearing in non-singleton sets
    vector<int> par(n+1);
    iota(par.begin(),par.end(),0);
    function<int(int)> find=[&](int x){return par[x]==x?x:par[x]=find(par[x]);};
    auto uni=[&](int a,int b){a=find(a);b=find(b);if(a!=b)par[a]=b;};
    for(auto&s:big) for(size_t i=1;i<s.size();i++) uni(s[0],s[i]);

    vector<char> inBig(n+1,0);
    for(auto&s:big) for(int e:s) inBig[e]=1;

    map<int,vector<int>> compElems;
    for(int e=1;e<=n;e++) if(inBig[e]) compElems[find(e)].push_back(e);
    map<int,vector<vector<int>>> compSets;
    for(auto&s:big) compSets[find(s[0])].push_back(s);

    int numBlocks = (int)compElems.size();
    for(int e=1;e<=n;e++) if(!inBig[e]) numBlocks++;

    ll answer=1;
    for(auto&kv:compElems){
        ll ways = solveComponent(kv.second, compSets[kv.first]);
        answer = answer*ways%MOD;
    }
    answer = answer*fact[numBlocks]%MOD;
    cout<<answer<<"\n";
    return 0;
}
