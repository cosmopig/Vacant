import itertools
from collections import Counter

def subsets_good(counts):
    # counts: dict value->count. Check every subset good via pair criterion:
    # for all present x<=y: x*y >= sum of values in [x,y]
    vals=sorted(counts)
    for i,x in enumerate(vals):
        for y in vals[i:]:
            s=sum(v*c for v,c in counts.items() if x<=v<=y)
            if x*y < s: return False,(x,y,s)
    return True,None

def perfect(seq):
    n=len(seq)
    for mask in range(1,1<<n):
        sub=[seq[i] for i in range(n) if mask>>i&1]
        if max(sub)*min(sub) < sum(sub): return False
    return True

# enumerate multisets for n up to 6, values 1..n+1, compare criteria
def crit_full(counts):
    return subsets_good(counts)[0]

def crit_minmax(counts):
    vals=sorted(counts); T=sum(v*c for v,c in counts.items())
    return vals[0]*vals[-1]>=T

def crit_adj(counts):
    # singles c_v<=v, adjacent distinct pairs, and (min,max)
    vals=sorted(counts)
    for v,c in counts.items():
        if c>v: return False
    T=sum(v*c for v,c in counts.items())
    if vals[0]*vals[-1]<T: return False
    for i in range(len(vals)-1):
        x,y=vals[i],vals[i+1]
        s=sum(v*c for v,c in counts.items() if x<=v<=y)
        if x*y<s: return False
    return True

import math
def multisets(n, lo, hi):
    # generate count vectors
    res=[]
    def rec(v, rem, cur):
        if v==hi+1:
            if rem==0: res.append(dict(cur))
            return
        for c in range(rem+1):
            if c: cur[v]=c
            rec(v+1, rem-c, cur)
            if c: del cur[v]
    rec(lo, n, {})
    return res

for n in range(1,7):
    ms=multisets(n,1,n+1)
    mism_mm=0; mism_adj=0
    for c in ms:
        f=crit_full(c)
        if f!=crit_minmax(c): mism_mm+=1
        if f!=crit_adj(c):
            mism_adj+=1
            if mism_adj<=5:
                print("n",n,"adj-mismatch",c,"full",f)
    print("n",n,"multisets",len(ms),"minmax mismatches",mism_mm,"adj mismatches",mism_adj)
