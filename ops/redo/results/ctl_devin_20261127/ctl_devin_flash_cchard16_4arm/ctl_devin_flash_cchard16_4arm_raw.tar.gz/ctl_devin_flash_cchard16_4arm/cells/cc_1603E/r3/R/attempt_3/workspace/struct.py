from itertools import product, combinations
from collections import Counter

def perfect_fast(seq):
    cnt=Counter(seq)
    sv=sorted(cnt)
    for v in sv:
        if cnt[v] > v:
            return False
    if len(sv)==1:
        return True
    pref=[0]
    for v in sv:
        pref.append(pref[-1]+v*cnt[v])
    t=len(sv)
    for i in range(t):
        for j in range(i+1,t):
            m,M=sv[i],sv[j]
            if m*M < pref[j+1]-pref[i]:
                return False
    return True

for n in [3,4,5]:
    seen={}
    for seq in product(range(1,n+2),repeat=n):
        if perfect_fast(seq):
            key=tuple(sorted(Counter(seq).items()))
            seen[key]=seen.get(key,0)+1
    print("=== n",n,"distinct multisets:",len(seen))
    for k,v in sorted(seen.items()):
        print("  ",k,"->",v,"seqs")
