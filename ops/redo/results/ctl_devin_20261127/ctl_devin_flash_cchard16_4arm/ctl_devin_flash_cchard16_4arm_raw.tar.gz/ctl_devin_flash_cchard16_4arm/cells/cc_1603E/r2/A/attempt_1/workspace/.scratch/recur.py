from fractions import Fraction
a=[2,4,11,32,97,295,940,3148,10901,38324,135313,478989,1704939]
# guess a(n)=sum_{i=1..k} c_i a(n-i), solve using last k+? equations
for k in range(1,7):
    # use equations for n=k+1..2k+2 (need enough)
    import itertools
    # build linear system over rationals
    eqs=[]
    for n in range(k, len(a)):
        row=[Fraction(a[n-i-1]) for i in range(k)]
        eqs.append((row, Fraction(a[n])))
    # take first k independent eqs
    M=[r[:] + [b] for r,b in eqs[:k]]
    # gaussian elim
    ok=True
    for col in range(k):
        piv=None
        for r in range(col,k):
            if M[r][col]!=0: piv=r;break
        if piv is None: ok=False;break
        M[col],M[piv]=M[piv],M[col]
        for r in range(k):
            if r!=col and M[r][col]!=0:
                f=M[r][col]/M[col][col]
                M[r]=[x-f*y for x,y in zip(M[r],M[col])]
    if not ok: print(k,"singular");continue
    coef=[M[i][k]/M[i][i] for i in range(k)]
    # verify
    good=all(sum(coef[i]*a[n-i-1] for i in range(k))==a[n] for n in range(k,len(a)))
    print(k,coef,"verified" if good else "no")
