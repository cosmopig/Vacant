#include <bits/stdc++.h>
using namespace std;

int n;
vector<int> cnt; // cnt[v] for v=1..n+1
int k; // distinct count
vector<int> vals;

// full criterion: for all present x<=y: x*y >= sum_{v in [x,y]} cnt[v]*v
bool full_ok(){
    int m=vals.size();
    for(int i=0;i<m;i++)for(int j=i;j<m;j++){
        long long x=vals[i], y=vals[j], s=0;
        for(int l=i;l<=j;l++) s += (long long)cnt[vals[l]]*vals[l];
        if(x*y < s) return false;
    }
    return true;
}

long long checked=0, perfect=0, badmin=0;
int minval_seen=1e9, maxval_seen=0;

void rec(int v, int rem){
    if(v==n+2){
        if(rem!=0) return;
        checked++;
        // recompute vals
        vals.clear();
        for(int i=1;i<=n+1;i++) if(cnt[i]) vals.push_back(i);
        if(full_ok()){
            perfect++;
            minval_seen=min(minval_seen,vals.front());
            maxval_seen=max(maxval_seen,vals.back());
            // check all values >= n-1
            for(int x: vals) if(x < n-1){ badmin++; printf("COUNTEREX n=%d vals:",n); for(int x:vals)printf(" %d",x); printf("\n"); break;}
        }
        return;
    }
    for(int c=0;c<=rem;c++){
        cnt[v]=c;
        rec(v+1, rem-c);
    }
    cnt[v]=0;
}

int main(int argc,char**argv){
    n=atoi(argv[1]);
    cnt.assign(n+3,0);
    rec(1,n);
    printf("n=%d checked=%lld perfect=%lld minval=%d maxval=%d badmin=%lld\n",n,checked,perfect,minval_seen,maxval_seen,badmin);
    return 0;
}
