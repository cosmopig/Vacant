import sys
from math import factorial
sys.setrecursionlimit(100000)

def valid(counts, vals):
    m=vals[0]; S=0
    for v,c in zip(vals,counts):
        if c>v: return False
        S+=v*c
        if v>m and S>m*v: return False
    return True

def rec_enum(n, min_m=None):
    vals=list(range(2,n+2))
    results=[]
    def rec(i, cv, cc, rem):
        if i==len(vals):
            if cv and rem==0:
                results.append((tuple(cv),tuple(cc)))
            return
        v=vals[i]
        rec(i+1, cv, cc, rem)
        for c in range(1, min(v,rem)+1):
            rec(i+1, cv+[v], cc+[c], rem-c)
    rec(0,[],[],n)
    out=[]
    f=factorial(n)
    for vs,cs in results:
        if valid(cs,vs):
            w=f
            for c in cs: w//=factorial(c)
            out.append((vs,cs,w))
    return out

for n in [6,7,8]:
    out=rec_enum(n)
    print("==== n",n,"total",sum(w for _,_,w in out))
    for vs,cs,w in out:
        if vs[0] <= n-2:
            print("   LOWMIN", list(zip(vs,cs)), "weight",w)
