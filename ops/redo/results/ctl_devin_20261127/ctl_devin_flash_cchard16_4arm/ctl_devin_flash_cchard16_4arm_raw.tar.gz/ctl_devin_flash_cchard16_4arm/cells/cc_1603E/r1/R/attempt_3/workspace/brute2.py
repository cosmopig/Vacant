import itertools
from collections import Counter

def good(sub):
    return max(sub)*min(sub) >= sum(sub)

def perfect(t):
    n=len(t)
    for mask in range(1,1<<n):
        sub=[t[i] for i in range(n) if mask>>i&1]
        if not good(sub):
            return False
    return True

for n in [3,4]:
    ms=Counter()
    for t in itertools.product(range(1,n+2), repeat=n):
        if perfect(t):
            ms[tuple(sorted(Counter(t).items()))]+=1
    print("n=",n)
    for k,v in sorted(ms.items()):
        print("  ",k,v)
