#include <bits/stdc++.h>
using namespace std;
int n;
vector<int> a;
bool perfect(){
    int N=1<<n;
    static int sum[1<<7], mn[1<<7], mx[1<<7];
    sum[0]=0; mn[0]=1000000000; mx[0]=-1;
    for(int mask=1; mask<N; mask++){
        int b=__builtin_ctz(mask); int prev=mask&(mask-1); int v=a[b];
        sum[mask]=sum[prev]+v; mn[mask]=min(mn[prev],v); mx[mask]=max(mx[prev],v);
        if((long long)mn[mask]*mx[mask] < sum[mask]) return false;
    }
    return true;
}
int main(int argc,char**argv){n=atoi(argv[1]); int vals=n+1; long long total=0; vector<int> cnt(vals+1); vector<array<int,8>> groups; int minv=999,maxv=-1;
    // enumerate mixed radix
    vector<int> idx(n,1);
    function<void(int)> rec=[&](int pos){ if(pos==n){ a.assign(idx.begin(),idx.end()); if(perfect()){ total++; for(int x:a){minv=min(minv,x);maxv=max(maxv,x);} } return;} for(int v=1;v<=vals;v++){idx[pos]=v; rec(pos+1);} };
    // too slow recursion? use iterative odometer
    vector<int> cur(n,1);
    while(true){
        a=cur;
        if(perfect()){ total++; for(int x:a){minv=min(minv,x);maxv=max(maxv,x);} }
        int p=n-1; while(p>=0 && cur[p]==vals){cur[p]=1;p--;} if(p<0) break; cur[p]++;
    }
    cout<<"n "<<n<<" count "<<total<<" minv "<<minv<<" maxv "<<maxv<<"\n";
}
