from itertools import combinations_with_replacement
from math import factorial
from collections import defaultdict

def count_by_c(n):
    V=n+1; res=defaultdict(int)
    for comb in combinations_with_replacement(range(1,V+1),n):
        c=comb[0]; S=0; ok=True
        for v in comb:
            S+=v
            if S>c*v: ok=False; break
        if ok:
            cnt={}
            for v in comb: cnt[v]=cnt.get(v,0)+1
            ways=factorial(n)
            for k in cnt.values(): ways//=factorial(k)
            res[c]+=ways
    return res

for n in range(2,9):
    print(n, dict(sorted(count_by_c(n).items())))
