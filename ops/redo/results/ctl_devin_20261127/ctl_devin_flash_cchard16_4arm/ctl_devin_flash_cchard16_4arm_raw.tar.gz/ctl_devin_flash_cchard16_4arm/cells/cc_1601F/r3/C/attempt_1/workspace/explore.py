M = 998244353

def lex_order(n):
    return sorted(range(1, n+1), key=lambda x: str(x))

for n in range(1, 61):
    a = lex_order(n)
    C = sum(1 for i, v in enumerate(a, 1) if i % M < v % M)
    print(n, C)
