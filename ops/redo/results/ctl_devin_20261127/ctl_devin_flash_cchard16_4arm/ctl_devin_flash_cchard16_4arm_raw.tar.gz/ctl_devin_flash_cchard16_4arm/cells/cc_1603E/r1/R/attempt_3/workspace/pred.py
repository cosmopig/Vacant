import sys
from math import factorial, comb

def count(n):
    L,M,H=n-1,n,n+1
    vals=[L,M,H]
    total=0
    for x in range(n+1):
        for y in range(n+1-x):
            z=n-x-y
            c=[x,y,z]
            P=[i for i in range(3) if c[i]>0]
            ok=True
            # constraints for every pair p<=q in P (indices into vals)
            for ii in range(len(P)):
                for jj in range(ii,len(P)):
                    i,j=P[ii],P[jj]
                    p,q=vals[i],vals[j]
                    T=sum(c[k]*vals[k] for k in range(3) if p<=vals[k]<=q and c[k]>0)
                    # note: elements with values strictly between p,q also counted if present
                    if T>p*q: ok=False;break
                if not ok:break
            if not ok:continue
            total+=factorial(n)//(factorial(x)*factorial(y)*factorial(z))
    return total

for n in range(1,8):
    print(n,count(n))
