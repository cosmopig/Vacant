#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int n;
long long counts[205];
int vals[205], nv;
long long minval_wanted;
int shown=0, maxshow=200;
int valid(){
    nv=0;
    for(int i=1;i<=n+1;i++) if(counts[i]>0) vals[nv++]=i;
    for(int i=0;i<nv;i++){
        for(int j=i+1;j<nv;j++){
            long long s=0;
            for(int k=0;k<nv;k++) if(vals[k]>=vals[i]&&vals[k]<=vals[j]) s+=vals[k]*counts[vals[k]];
            if(s>(long long)vals[i]*vals[j]) return 0;
        }
    }
    return 1;
}
void rec(int v,int rem){
    if(shown>=maxshow) return;
    if(v==n+2){
        if(rem!=0) return;
        if(!valid()) return;
        // find min
        int mn=1; while(counts[mn]==0) mn++;
        if(mn!=minval_wanted) return;
        shown++;
        for(int i=1;i<=n+1;i++) if(counts[i]) printf("%d:%lld ",i,counts[i]);
        printf("\n");
        return;
    }
    int maxc = v<rem?v:rem;
    for(int c=0;c<=maxc;c++){ counts[v]=c; rec(v+1,rem-c); }
    counts[v]=0;
}
int main(int argc,char**argv){
    n=atoi(argv[1]); minval_wanted=atoi(argv[2]);
    rec(1,n);
    fprintf(stderr,"shown=%d\n",shown);
    return 0;
}
