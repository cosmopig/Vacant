#include <bits/stdc++.h>
using namespace std;
int n;
typedef long long ll;
int c[64];
bool ok(){
    static ll pref[70]; pref[0]=0;
    for(int v=1;v<=n+1;v++) pref[v]=pref[v-1]+(ll)v*c[v];
    for(int x=1;x<=n+1;x++) if(c[x])
        for(int y=x+1;y<=n+1;y++) if(c[y])
            if(pref[y]-pref[x-1] > (ll)x*y) return false;
    return true;
}
void rec(int v,int left){
    if(v==n+2){ if(left==0 && ok()){ for(int i=2;i<=n+1;i++) if(c[i]) printf("%d^%d ",i,c[i]); printf("\n"); } return;}
    for(int k=0;k<=min(v,left);k++){ c[v]=k; rec(v+1,left-k);} c[v]=0;
}
int main(int argc,char**argv){ n=atoi(argv[1]); rec(1,n); }
