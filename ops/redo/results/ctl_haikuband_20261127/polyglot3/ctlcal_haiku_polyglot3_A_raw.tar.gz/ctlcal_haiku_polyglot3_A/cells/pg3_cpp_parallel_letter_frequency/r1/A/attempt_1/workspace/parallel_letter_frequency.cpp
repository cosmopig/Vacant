#include "parallel_letter_frequency.h"

#include <algorithm>
#include <array>
#include <cstddef>
#include <thread>

namespace parallel_letter_frequency {

namespace {

using Counts = std::array<std::size_t, 26>;

// Adds the letter counts of texts[begin, end) into `counts`.
void count_range(std::vector<std::string_view> const& texts, std::size_t begin,
                 std::size_t end, Counts& counts) {
    for (std::size_t i = begin; i < end; ++i) {
        for (char c : texts[i]) {
            if (c >= 'a' && c <= 'z') {
                ++counts[static_cast<std::size_t>(c - 'a')];
            } else if (c >= 'A' && c <= 'Z') {
                ++counts[static_cast<std::size_t>(c - 'A')];
            }
        }
    }
}

}  // namespace

std::map<char, std::size_t> frequency(std::vector<std::string_view> const& texts) {
    std::size_t const hw = std::max(1u, std::thread::hardware_concurrency());
    std::size_t const workers = std::min(hw, texts.size());

    std::vector<Counts> partial(workers, Counts{});

    if (workers <= 1) {
        if (workers == 1) {
            count_range(texts, 0, texts.size(), partial[0]);
        }
    } else {
        // Split the texts into contiguous chunks, one per worker. Each worker
        // writes only to its own Counts, so no synchronization is needed.
        std::vector<std::thread> threads;
        threads.reserve(workers);
        std::size_t const chunk = (texts.size() + workers - 1) / workers;
        for (std::size_t w = 0; w < workers; ++w) {
            std::size_t const begin = std::min(w * chunk, texts.size());
            std::size_t const end = std::min(begin + chunk, texts.size());
            threads.emplace_back([&texts, &partial, w, begin, end] {
                count_range(texts, begin, end, partial[w]);
            });
        }
        for (auto& t : threads) {
            t.join();
        }
    }

    Counts total{};
    for (Counts const& p : partial) {
        for (std::size_t i = 0; i < total.size(); ++i) {
            total[i] += p[i];
        }
    }

    std::map<char, std::size_t> result;
    for (std::size_t i = 0; i < total.size(); ++i) {
        if (total[i] > 0) {
            result['a' + static_cast<char>(i)] = total[i];
        }
    }
    return result;
}

}  // namespace parallel_letter_frequency
