#[derive(Debug, PartialEq, Eq)]
pub enum Error {
    IncompleteNumber,
    Overflow,
}

/// Convert a list of numbers to a stream of bytes encoded with variable length encoding.
pub fn to_bytes(values: &[u32]) -> Vec<u8> {
    let mut out = Vec::with_capacity(values.len());
    for &value in values {
        // Emit 7-bit groups most-significant first; set the continuation bit
        // on every byte except the last one.
        let mut groups = [0u8; 5];
        let mut n = 0;
        let mut v = value;
        loop {
            groups[n] = (v & 0x7f) as u8;
            n += 1;
            v >>= 7;
            if v == 0 {
                break;
            }
        }
        for i in (0..n).rev() {
            let cont = if i > 0 { 0x80 } else { 0x00 };
            out.push(groups[i] | cont);
        }
    }
    out
}

/// Given a stream of bytes, extract all numbers which are encoded in there.
pub fn from_bytes(bytes: &[u8]) -> Result<Vec<u32>, Error> {
    let mut values = Vec::new();
    let mut acc: u32 = 0;
    let mut in_progress = false;
    for &byte in bytes {
        if in_progress && acc > (u32::MAX >> 7) {
            return Err(Error::Overflow);
        }
        acc = (acc << 7) | u32::from(byte & 0x7f);
        in_progress = true;
        if byte & 0x80 == 0 {
            values.push(acc);
            acc = 0;
            in_progress = false;
        }
    }
    if in_progress {
        return Err(Error::IncompleteNumber);
    }
    Ok(values)
}
