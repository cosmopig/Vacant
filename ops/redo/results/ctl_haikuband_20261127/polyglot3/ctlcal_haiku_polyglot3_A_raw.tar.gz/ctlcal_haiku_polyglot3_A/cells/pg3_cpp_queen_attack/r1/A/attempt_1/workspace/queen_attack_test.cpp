#include "queen_attack.h"
#ifdef EXERCISM_TEST_SUITE
#include <catch2/catch.hpp>
#else
#include "test/catch.hpp"
#endif














TEST_CASE("queens_cannot_attack")
{
    const queen_attack::chess_board board{std::make_pair(2, 4), std::make_pair(6, 6)};

    REQUIRE_FALSE(board.can_attack());
}



TEST_CASE("queens_can_attack_on_same_column")
{
    const queen_attack::chess_board board{std::make_pair(4, 5), std::make_pair(2, 5)};

    REQUIRE(board.can_attack());
}

TEST_CASE("queens_can_attack_on_first_diagonal")
{
    const queen_attack::chess_board board{std::make_pair(2, 2), std::make_pair(0, 4)};

    REQUIRE(board.can_attack());
}

TEST_CASE("queens_can_attack_on_second_diagonal")
{
    const queen_attack::chess_board board{std::make_pair(2, 2), std::make_pair(3, 1)};

    REQUIRE(board.can_attack());
}

TEST_CASE("queens_can_attack_on_third_diagonal")
{
    const queen_attack::chess_board board{std::make_pair(2, 2), std::make_pair(1, 1)};

    REQUIRE(board.can_attack());
}

TEST_CASE("queens_can_attack_on_fourth_diagonal")
{
    const queen_attack::chess_board board{std::make_pair(1, 7), std::make_pair(0, 6)};

    REQUIRE(board.can_attack());
}

TEST_CASE("queens_cannot_attack_if_falling_diagonals_are_only_the_same_when_reflected_across_the_longest_falling_diagonal")
{
    const queen_attack::chess_board board{std::make_pair(4, 1), std::make_pair(2, 5)};

    REQUIRE_FALSE(board.can_attack());
}
