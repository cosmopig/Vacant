pub struct Luhn {
    input: String,
}

impl Luhn {
    pub fn is_valid(&self) -> bool {
        // Spaces are allowed as separators; anything else must be a digit.
        let digits: Vec<u32> = {
            let mut digits = Vec::with_capacity(self.input.len());
            for c in self.input.chars() {
                if c == ' ' {
                    continue;
                }
                match c.to_digit(10) {
                    Some(d) => digits.push(d),
                    None => return false,
                }
            }
            digits
        };

        if digits.len() <= 1 {
            return false;
        }

        // Walk from the rightmost digit; double every second digit,
        // subtracting 9 when the doubled value exceeds 9.
        let sum: u32 = digits
            .iter()
            .rev()
            .enumerate()
            .map(|(i, &d)| {
                if i % 2 == 1 {
                    let doubled = d * 2;
                    if doubled > 9 {
                        doubled - 9
                    } else {
                        doubled
                    }
                } else {
                    d
                }
            })
            .sum();

        sum % 10 == 0
    }
}

/// Here is the example of how the From trait could be implemented
/// for the &str type. Naturally, you can implement this trait
/// by hand for every other type presented in the test suite,
/// but your solution will fail if a new type is presented.
/// Perhaps there exists a better solution for this problem?
impl From<&str> for Luhn {
    fn from(input: &str) -> Self {
        Luhn {
            input: input.to_string(),
        }
    }
}

/// Implements `From` for each unsigned integer type by converting the
/// number to its decimal string representation.
macro_rules! impl_from_unsigned {
    ($($t:ty),*) => {
        $(
            impl From<$t> for Luhn {
                fn from(input: $t) -> Self {
                    Luhn {
                        input: input.to_string(),
                    }
                }
            }
        )*
    };
}

impl_from_unsigned!(u8, u16, u32, u64, u128, usize);
