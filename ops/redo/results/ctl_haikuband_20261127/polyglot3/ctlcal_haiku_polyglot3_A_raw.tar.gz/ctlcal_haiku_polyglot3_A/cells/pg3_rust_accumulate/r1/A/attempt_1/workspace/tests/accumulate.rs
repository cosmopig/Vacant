use accumulate::map;

fn square(x: i32) -> i32 {
    x * x
}



#[test]
fn func_single() {
    let input = vec![2];
    let expected = vec![4];
    assert_eq!(map(input, square), expected);
}



#[test]
fn closure() {
    let input = vec![2, 3, 4, 5];
    let expected = vec![4, 9, 16, 25];
    assert_eq!(map(input, |x| x * x), expected);
}

#[test]
fn closure_floats() {
    let input = vec![2.0, 3.0, 4.0, 5.0];
    let expected = vec![4.0, 9.0, 16.0, 25.0];
    assert_eq!(map(input, |x| x * x), expected);
}

#[test]
fn strings() {
    let input = vec!["1".to_string(), "2".into(), "3".into()];
    let expected = vec!["11".to_string(), "22".into(), "33".into()];
    assert_eq!(map(input, |s| s.repeat(2)), expected);
}





#[test]
fn accumulate_recursively() {
    let input = vec!["a", "b", "c"];
    let expected = vec![
        vec!["a1", "a2", "a3"],
        vec!["b1", "b2", "b3"],
        vec!["c1", "c2", "c3"],
    ];
    assert_eq!(
        map(input, |x| map(vec!["1", "2", "3"], |y| [x, y].join(""))),
        expected
    );
}





#[test]
fn minimal_bounds_on_input_and_output() {
    // must be able to accept arbitrary input and output types
    struct Foo;
    struct Bar;
    map(vec![Foo], |_| Bar);
}
