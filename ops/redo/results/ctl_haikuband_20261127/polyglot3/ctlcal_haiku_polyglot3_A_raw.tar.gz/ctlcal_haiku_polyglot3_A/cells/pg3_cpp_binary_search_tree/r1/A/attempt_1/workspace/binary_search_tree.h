#if !defined(BINARY_SEARCH_TREE_H)
#define BINARY_SEARCH_TREE_H

#include <cstddef>
#include <iterator>
#include <memory>
#include <stack>
#include <utility>

namespace binary_search_tree {

template<typename T>
class binary_tree {
    using node_ptr = std::unique_ptr<binary_tree<T>>;

public:
    explicit binary_tree(T value) : data_(std::move(value)) {}

    // In-order (sorted) forward iterator over the tree's values.
    class const_iterator {
    public:
        using iterator_category = std::forward_iterator_tag;
        using value_type = T;
        using difference_type = std::ptrdiff_t;
        using pointer = const T*;
        using reference = const T&;

        const_iterator() = default;

        reference operator*() const { return stack_.top()->data_; }
        pointer operator->() const { return &stack_.top()->data_; }

        const_iterator& operator++() {
            const binary_tree* node = stack_.top();
            stack_.pop();
            push_left_spine(node->right_.get());
            return *this;
        }

        const_iterator operator++(int) {
            const_iterator copy(*this);
            ++(*this);
            return copy;
        }

        friend bool operator==(const const_iterator& a, const const_iterator& b) {
            if (a.stack_.empty() || b.stack_.empty())
                return a.stack_.empty() == b.stack_.empty();
            return a.stack_.top() == b.stack_.top();
        }

        friend bool operator!=(const const_iterator& a, const const_iterator& b) {
            return !(a == b);
        }

    private:
        friend class binary_tree<T>;

        // Pushes `node` and its entire left spine (nodes not yet visited).
        void push_left_spine(const binary_tree* node) {
            for (; node != nullptr; node = node->left_.get())
                stack_.push(node);
        }

        std::stack<const binary_tree*> stack_;
    };

    using iterator = const_iterator;

    const T& data() const { return data_; }
    const node_ptr& left() const { return left_; }
    const node_ptr& right() const { return right_; }

    // Inserts a value. Values less than or equal to a node's data go left;
    // greater values go right.
    void insert(T value) {
        binary_tree* node = this;
        for (;;) {
            node_ptr& child = (value <= node->data_) ? node->left_ : node->right_;
            if (!child) {
                child = std::make_unique<binary_tree<T>>(std::move(value));
                return;
            }
            node = child.get();
        }
    }

    const_iterator begin() const {
        const_iterator it;
        it.push_left_spine(this);
        return it;
    }

    const_iterator end() const { return const_iterator(); }

private:
    T data_;
    node_ptr left_;
    node_ptr right_;
};

}  // namespace binary_search_tree

#endif // BINARY_SEARCH_TREE_H
