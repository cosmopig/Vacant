package react

// Define reactor, cell and canceler types here.
// These types will implement the Reactor, Cell and Canceler interfaces, respectively.

// reactor owns every cell created through it. Cells are kept in creation
// order, which is a valid topological order: a compute cell can only depend
// on cells that already existed when it was created.
type reactor struct {
	cells []*cell
}

// callback is a registered change notification on a compute cell.
type callback struct {
	id int
	fn func(int)
}

// cell is used for both input and compute cells.
type cell struct {
	reactor *reactor
	value   int
	isInput bool

	// deps and recompute are only set for compute cells.
	deps      []*cell
	recompute func() int

	// prev is the value in the previous stable state; changed reports whether
	// value differs from prev after the most recent propagation.
	prev    int
	changed bool

	callbacks []callback
	nextID    int
}

// canceler removes a single callback from a compute cell.
type canceler struct {
	c  *cell
	id int
}

func (c *canceler) Cancel() {
	cbs := c.c.callbacks
	for i, cb := range cbs {
		if cb.id == c.id {
			c.c.callbacks = append(cbs[:i:i], cbs[i+1:]...)
			return
		}
	}
}

func (c *cell) Value() int {
	return c.value
}

// SetValue changes an input cell and propagates the change through the
// reactor until it reaches a new stable state, then calls the callbacks of
// every compute cell whose value differs from the previous stable state.
func (c *cell) SetValue(value int) {
	if !c.isInput {
		panic("SetValue called on a compute cell")
	}
	r := c.reactor

	for _, x := range r.cells {
		x.prev = x.value
	}
	c.value = value

	for _, x := range r.cells {
		if x.isInput {
			x.changed = x.value != x.prev
			continue
		}
		// Only recompute when a dependency actually changed. Dependencies
		// come earlier in creation order, so their changed flags are final.
		if x.depsChanged() {
			x.value = x.recompute()
		}
		x.changed = x.value != x.prev
	}

	for _, x := range r.cells {
		if x.isInput || !x.changed {
			continue
		}
		// Copy so callbacks may safely cancel themselves or others.
		cbs := append([]callback(nil), x.callbacks...)
		for _, cb := range cbs {
			cb.fn(x.value)
		}
	}
}

func (c *cell) depsChanged() bool {
	for _, d := range c.deps {
		if d.changed {
			return true
		}
	}
	return false
}

func (c *cell) AddCallback(fn func(int)) Canceler {
	id := c.nextID
	c.nextID++
	c.callbacks = append(c.callbacks, callback{id: id, fn: fn})
	return &canceler{c: c, id: id}
}

// New returns an empty reactor.
func New() Reactor {
	return &reactor{}
}

func (r *reactor) add(c *cell) *cell {
	c.reactor = r
	r.cells = append(r.cells, c)
	return c
}

func (r *reactor) CreateInput(initial int) InputCell {
	return r.add(&cell{value: initial, prev: initial, isInput: true})
}

func (r *reactor) CreateCompute1(dep Cell, compute func(int) int) ComputeCell {
	d := dep.(*cell)
	c := &cell{deps: []*cell{d}}
	c.recompute = func() int { return compute(d.value) }
	c.value = c.recompute()
	c.prev = c.value
	return r.add(c)
}

func (r *reactor) CreateCompute2(dep1, dep2 Cell, compute func(int, int) int) ComputeCell {
	d1 := dep1.(*cell)
	d2 := dep2.(*cell)
	c := &cell{deps: []*cell{d1, d2}}
	c.recompute = func() int { return compute(d1.value, d2.value) }
	c.value = c.recompute()
	c.prev = c.value
	return r.add(c)
}
