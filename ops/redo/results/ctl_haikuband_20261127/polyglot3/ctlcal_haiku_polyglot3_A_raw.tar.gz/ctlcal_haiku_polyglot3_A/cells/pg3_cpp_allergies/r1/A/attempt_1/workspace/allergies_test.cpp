#include "allergies.h"
#ifdef EXERCISM_TEST_SUITE
#include <catch2/catch.hpp>
#else
#include "test/catch.hpp"
#endif

TEST_CASE("testing for eggs allergy -> not allergic to anything", "[17fc7296-2440-4ac4-ad7b-d07c321bc5a0]") {
	REQUIRE(false == allergies::allergy_test(0).is_allergic_to("eggs"));
}


TEST_CASE("testing for eggs allergy -> allergic only to eggs", "[07ced27b-1da5-4c2e-8ae2-cb2791437546]") {
	REQUIRE(true == allergies::allergy_test(1).is_allergic_to("eggs"));
}





TEST_CASE("testing for eggs allergy -> allergic to everything", "[90c8f484-456b-41c4-82ba-2d08d93231c6]") {
	REQUIRE(true == allergies::allergy_test(255).is_allergic_to("eggs"));
}





TEST_CASE("testing for peanuts allergy -> allergic to peanuts and something else", "[eac69ae9-8d14-4291-ac4b-7fd2c73d3a5b]") {
	REQUIRE(true == allergies::allergy_test(7).is_allergic_to("peanuts"));
}

TEST_CASE("testing for peanuts allergy -> allergic to something, but not peanuts", "[9152058c-ce39-4b16-9b1d-283ec6d25085]") {
	REQUIRE(false == allergies::allergy_test(5).is_allergic_to("peanuts"));
}

TEST_CASE("testing for peanuts allergy -> allergic to everything", "[d2d71fd8-63d5-40f9-a627-fbdaf88caeab]") {
	REQUIRE(true == allergies::allergy_test(255).is_allergic_to("peanuts"));
}

TEST_CASE("testing for shellfish allergy -> not allergic to anything", "[b948b0a1-cbf7-4b28-a244-73ff56687c80]") {
	REQUIRE(false == allergies::allergy_test(0).is_allergic_to("shellfish"));
}







TEST_CASE("testing for shellfish allergy -> allergic to everything", "[cc789c19-2b5e-4c67-b146-625dc8cfa34e]") {
	REQUIRE(true == allergies::allergy_test(255).is_allergic_to("shellfish"));
}

TEST_CASE("testing for strawberries allergy -> not allergic to anything", "[651bde0a-2a74-46c4-ab55-02a0906ca2f5]") {
	REQUIRE(false == allergies::allergy_test(0).is_allergic_to("strawberries"));
}

TEST_CASE("testing for strawberries allergy -> allergic only to strawberries", "[b649a750-9703-4f5f-b7f7-91da2c160ece]") {
	REQUIRE(true == allergies::allergy_test(8).is_allergic_to("strawberries"));
}







TEST_CASE("testing for tomatoes allergy -> not allergic to anything", "[c49a91ef-6252-415e-907e-a9d26ef61723]") {
	REQUIRE(false == allergies::allergy_test(0).is_allergic_to("tomatoes"));
}

TEST_CASE("testing for tomatoes allergy -> allergic only to tomatoes", "[b69c5131-b7d0-41ad-a32c-e1b2cc632df8]") {
	REQUIRE(true == allergies::allergy_test(16).is_allergic_to("tomatoes"));
}

TEST_CASE("testing for tomatoes allergy -> allergic to tomatoes and something else", "[1ca50eb1-f042-4ccf-9050-341521b929ec]") {
	REQUIRE(true == allergies::allergy_test(56).is_allergic_to("tomatoes"));
}



TEST_CASE("testing for tomatoes allergy -> allergic to everything", "[b2414f01-f3ad-4965-8391-e65f54dad35f]") {
	REQUIRE(true == allergies::allergy_test(255).is_allergic_to("tomatoes"));
}





TEST_CASE("testing for chocolate allergy -> allergic to chocolate and something else", "[b0a7c07b-2db7-4f73-a180-565e07040ef1]") {
	REQUIRE(true == allergies::allergy_test(112).is_allergic_to("chocolate"));
}





TEST_CASE("testing for pollen allergy -> not allergic to anything", "[17f4a42b-c91e-41b8-8a76-4797886c2d96]") {
	REQUIRE(false == allergies::allergy_test(0).is_allergic_to("pollen"));
}



TEST_CASE("testing for pollen allergy -> allergic to pollen and something else", "[9a49aec5-fa1f-405d-889e-4dfc420db2b6]") {
	REQUIRE(true == allergies::allergy_test(224).is_allergic_to("pollen"));
}

TEST_CASE("testing for pollen allergy -> allergic to something, but not pollen", "[3cb8e79f-d108-4712-b620-aa146b1954a9]") {
	REQUIRE(false == allergies::allergy_test(160).is_allergic_to("pollen"));
}





TEST_CASE("testing for cats allergy -> allergic only to cats", "[eba541c3-c886-42d3-baef-c048cb7fcd8f]") {
	REQUIRE(true == allergies::allergy_test(128).is_allergic_to("cats"));
}

TEST_CASE("testing for cats allergy -> allergic to cats and something else", "[ba718376-26e0-40b7-bbbe-060287637ea5]") {
	REQUIRE(true == allergies::allergy_test(192).is_allergic_to("cats"));
}







TEST_CASE("list when: -> just eggs", "[9e1a4364-09a6-4d94-990f-541a94a4c1e8]") {
	std::unordered_set<std::string> expected ={"eggs"};
	REQUIRE(expected == allergies::allergy_test(1).get_allergies());
}





TEST_CASE("list when: -> eggs and peanuts", "[6fa95d26-044c-48a9-8a7b-9ee46ec32c5c]") {
	std::unordered_set<std::string> expected ={"eggs", "peanuts"};
	REQUIRE(expected == allergies::allergy_test(3).get_allergies());
}



TEST_CASE("list when: -> lots of stuff", "[4b68f470-067c-44e4-889f-c9fe28917d2f]") {
	std::unordered_set<std::string> expected ={"strawberries", "tomatoes", "chocolate", "pollen", "cats"};
	REQUIRE(expected == allergies::allergy_test(248).get_allergies());
}



TEST_CASE("list when: -> no allergen score parts", "[12ce86de-b347-42a0-ab7c-2e0570f0c65b]") {
	std::unordered_set<std::string> expected ={"eggs", "shellfish", "strawberries", "tomatoes", "chocolate", "pollen", "cats"};
	REQUIRE(expected == allergies::allergy_test(509).get_allergies());
}

TEST_CASE("list when: -> no allergen score parts without highest valid score", "[93c2df3e-4f55-4fed-8116-7513092819cd]") {
	std::unordered_set<std::string> expected ={"eggs"};
	REQUIRE(expected == allergies::allergy_test(257).get_allergies());
}

