package linkedlist

import "errors"

// Element is a single node in a singly linked list.
type Element struct {
	data int
	next *Element
}

// List is a singly linked list of song IDs.
type List struct {
	head *Element
	size int
}

// New builds a list containing elements in the same order they are given.
func New(elements []int) *List {
	l := &List{}
	var tail *Element
	for _, v := range elements {
		e := &Element{data: v}
		if tail == nil {
			l.head = e
		} else {
			tail.next = e
		}
		tail = e
		l.size++
	}
	return l
}

// Size returns the number of elements in the list.
func (l *List) Size() int {
	return l.size
}

// Push adds an element to the head of the list.
func (l *List) Push(element int) {
	l.head = &Element{data: element, next: l.head}
	l.size++
}

// Pop removes and returns the element at the head of the list.
// It returns an error if the list is empty.
func (l *List) Pop() (int, error) {
	if l.head == nil {
		return 0, errors.New("pop from empty list")
	}
	e := l.head
	l.head = e.next
	l.size--
	return e.data, nil
}

// Array returns the elements of the list in order, head first.
func (l *List) Array() []int {
	out := make([]int, 0, l.size)
	for e := l.head; e != nil; e = e.next {
		out = append(out, e.data)
	}
	return out
}

// Reverse reverses the list in place and returns it.
func (l *List) Reverse() *List {
	var prev *Element
	cur := l.head
	for cur != nil {
		next := cur.next
		cur.next = prev
		prev = cur
		cur = next
	}
	l.head = prev
	return l
}
