#pragma once

namespace dnd_character {

// Rolls four 6-sided dice and returns the sum of the largest three.
int ability();

// Returns the modifier for an ability score: floor((score - 10) / 2).
int modifier(int score);

struct Character {
    Character();

    int strength;
    int dexterity;
    int constitution;
    int intelligence;
    int wisdom;
    int charisma;
    int hitpoints;
};

}  // namespace dnd_character
