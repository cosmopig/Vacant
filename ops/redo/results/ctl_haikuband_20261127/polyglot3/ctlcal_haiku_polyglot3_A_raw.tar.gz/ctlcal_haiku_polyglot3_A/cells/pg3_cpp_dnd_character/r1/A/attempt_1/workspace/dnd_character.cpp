#include "dnd_character.h"

#include <algorithm>
#include <array>
#include <functional>
#include <numeric>
#include <random>

namespace dnd_character {

namespace {

std::mt19937& rng() {
    static std::random_device device;
    static std::mt19937 engine{device()};
    return engine;
}

int roll_die() {
    static std::uniform_int_distribution<int> dist{1, 6};
    return dist(rng());
}

}  // namespace

int ability() {
    std::array<int, 4> dice{};
    std::generate(dice.begin(), dice.end(), roll_die);
    std::sort(dice.begin(), dice.end(), std::greater<int>());
    return dice[0] + dice[1] + dice[2];
}

int modifier(int score) {
    // Floor division by 2 (C++ integer division truncates toward zero).
    int diff = score - 10;
    return diff >= 0 ? diff / 2 : -((-diff + 1) / 2);
}

Character::Character()
    : strength{ability()},
      dexterity{ability()},
      constitution{ability()},
      intelligence{ability()},
      wisdom{ability()},
      charisma{ability()},
      hitpoints{10 + modifier(constitution)} {}

}  // namespace dnd_character
