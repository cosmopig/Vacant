#if !defined(PERFECT_NUMBERS_H)
#define PERFECT_NUMBERS_H

namespace perfect_numbers {

enum class classification { deficient, perfect, abundant };

// Classifies a positive integer by its aliquot sum.
// Throws std::domain_error if number is not positive.
classification classify(int number);

}  // namespace perfect_numbers

#endif  // PERFECT_NUMBERS_H
