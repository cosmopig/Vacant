use std::collections::HashMap;

/// Count occurrences of words.
///
/// Words are maximal runs of ASCII letters, digits, and apostrophes, with
/// leading and trailing apostrophes stripped (so quotes like `'can't'` yield
/// `can't`). Any other character separates words. Counting is case-insensitive.
pub fn word_count(words: &str) -> HashMap<String, u32> {
    let mut counts: HashMap<String, u32> = HashMap::new();

    for token in words.split(|c: char| !(c.is_ascii_alphanumeric() || c == '\'')) {
        let word = token.trim_matches('\'');
        if word.is_empty() {
            continue;
        }
        *counts.entry(word.to_ascii_lowercase()).or_insert(0) += 1;
    }

    counts
}
