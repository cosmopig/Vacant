#include "complex_numbers.h"

#include <cmath>

namespace complex_numbers {

Complex::Complex(double real, double imag) : real_(real), imag_(imag) {}

double Complex::real() const {
    return real_;
}

double Complex::imag() const {
    return imag_;
}

double Complex::abs() const {
    return std::sqrt(real_ * real_ + imag_ * imag_);
}

Complex Complex::conj() const {
    return Complex(real_, -imag_);
}

Complex Complex::exp() const {
    const double scale = std::exp(real_);
    return Complex(scale * std::cos(imag_), scale * std::sin(imag_));
}

Complex Complex::operator+(const Complex& other) const {
    return Complex(real_ + other.real_, imag_ + other.imag_);
}

Complex Complex::operator-(const Complex& other) const {
    return Complex(real_ - other.real_, imag_ - other.imag_);
}

Complex Complex::operator*(const Complex& other) const {
    return Complex(real_ * other.real_ - imag_ * other.imag_,
                   imag_ * other.real_ + real_ * other.imag_);
}

Complex Complex::operator/(const Complex& other) const {
    const double denom = other.real_ * other.real_ + other.imag_ * other.imag_;
    return Complex((real_ * other.real_ + imag_ * other.imag_) / denom,
                   (imag_ * other.real_ - real_ * other.imag_) / denom);
}

Complex Complex::operator+(double other) const {
    return Complex(real_ + other, imag_);
}

Complex Complex::operator-(double other) const {
    return Complex(real_ - other, imag_);
}

Complex Complex::operator*(double other) const {
    return Complex(real_ * other, imag_ * other);
}

Complex Complex::operator/(double other) const {
    return Complex(real_ / other, imag_ / other);
}

Complex operator+(double lhs, const Complex& rhs) {
    return rhs + lhs;
}

Complex operator-(double lhs, const Complex& rhs) {
    return Complex(lhs - rhs.real(), -rhs.imag());
}

Complex operator*(double lhs, const Complex& rhs) {
    return rhs * lhs;
}

Complex operator/(double lhs, const Complex& rhs) {
    return Complex(lhs, 0.0) / rhs;
}

}  // namespace complex_numbers
