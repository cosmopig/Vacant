use word_count::*;

#[test]
fn count_one_word() {
    let input = "word";
    let mut output = word_count(input);
    let expected = [("word", 1)];
    for (word, count) in expected {
        assert_eq!((word, output.remove(word).unwrap_or(0)), (word, count));
    }
    assert_eq!(output.into_iter().collect::<Vec<_>>(), vec![]);
}

#[test]
fn count_one_of_each_word() {
    let input = "one of each";
    let mut output = word_count(input);
    let expected = [("one", 1), ("of", 1), ("each", 1)];
    for (word, count) in expected {
        assert_eq!((word, output.remove(word).unwrap_or(0)), (word, count));
    }
    assert_eq!(output.into_iter().collect::<Vec<_>>(), vec![]);
}



#[test]
fn handles_cramped_lists() {
    let input = "one,two,three";
    let mut output = word_count(input);
    let expected = [("one", 1), ("two", 1), ("three", 1)];
    for (word, count) in expected {
        assert_eq!((word, output.remove(word).unwrap_or(0)), (word, count));
    }
    assert_eq!(output.into_iter().collect::<Vec<_>>(), vec![]);
}

#[test]
fn handles_expanded_lists() {
    let input = "one,\ntwo,\nthree";
    let mut output = word_count(input);
    let expected = [("one", 1), ("two", 1), ("three", 1)];
    for (word, count) in expected {
        assert_eq!((word, output.remove(word).unwrap_or(0)), (word, count));
    }
    assert_eq!(output.into_iter().collect::<Vec<_>>(), vec![]);
}

#[test]
fn ignore_punctuation() {
    let input = "car: carpet as java: javascript!!&@$%^&";
    let mut output = word_count(input);
    let expected = [
        ("car", 1),
        ("carpet", 1),
        ("as", 1),
        ("java", 1),
        ("javascript", 1),
    ];
    for (word, count) in expected {
        assert_eq!((word, output.remove(word).unwrap_or(0)), (word, count));
    }
    assert_eq!(output.into_iter().collect::<Vec<_>>(), vec![]);
}

#[test]
fn include_numbers() {
    let input = "testing, 1, 2 testing";
    let mut output = word_count(input);
    let expected = [("testing", 2), ("1", 1), ("2", 1)];
    for (word, count) in expected {
        assert_eq!((word, output.remove(word).unwrap_or(0)), (word, count));
    }
    assert_eq!(output.into_iter().collect::<Vec<_>>(), vec![]);
}













#[test]
fn quotation_for_word_with_apostrophe() {
    let input = "can, can't, 'can't'";
    let mut output = word_count(input);
    let expected = [("can", 1), ("can't", 2)];
    for (word, count) in expected {
        assert_eq!((word, output.remove(word).unwrap_or(0)), (word, count));
    }
    assert_eq!(output.into_iter().collect::<Vec<_>>(), vec![]);
}
