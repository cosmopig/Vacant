#include "yacht.h"

#include <algorithm>
#include <array>
#include <functional>
#include <map>
#include <numeric>
#include <string>

namespace yacht {

namespace {

int sum_of(const std::array<int, 5>& dice) {
    return std::accumulate(dice.begin(), dice.end(), 0);
}

// Number of dice showing `face`, multiplied by the face value.
int single_face(const std::array<int, 5>& dice, int face) {
    return face * static_cast<int>(std::count(dice.begin(), dice.end(), face));
}

// Count of each face, indexed 1..6 (index 0 unused).
std::array<int, 7> counts(const std::array<int, 5>& dice) {
    std::array<int, 7> c{};
    for (int d : dice) {
        ++c[static_cast<std::size_t>(d)];
    }
    return c;
}

int full_house(const std::array<int, 5>& dice) {
    auto c = counts(dice);
    bool three = false;
    bool two = false;
    for (int face = 1; face <= 6; ++face) {
        if (c[face] == 3) three = true;
        if (c[face] == 2) two = true;
    }
    return (three && two) ? sum_of(dice) : 0;
}

int four_of_a_kind(const std::array<int, 5>& dice) {
    auto c = counts(dice);
    for (int face = 1; face <= 6; ++face) {
        if (c[face] >= 4) return 4 * face;
    }
    return 0;
}

int little_straight(const std::array<int, 5>& dice) {
    auto c = counts(dice);
    for (int face = 1; face <= 5; ++face) {
        if (c[face] != 1) return 0;
    }
    return 30;
}

int big_straight(const std::array<int, 5>& dice) {
    auto c = counts(dice);
    for (int face = 2; face <= 6; ++face) {
        if (c[face] != 1) return 0;
    }
    return 30;
}

int yacht_score(const std::array<int, 5>& dice) {
    auto c = counts(dice);
    for (int face = 1; face <= 6; ++face) {
        if (c[face] == 5) return 50;
    }
    return 0;
}

}  // namespace

int score(const std::array<int, 5>& dice, const std::string& category) {
    static const std::map<std::string, std::function<int(const std::array<int, 5>&)>> scorers = {
        {"ones",             [](const std::array<int, 5>& d) { return single_face(d, 1); }},
        {"twos",             [](const std::array<int, 5>& d) { return single_face(d, 2); }},
        {"threes",           [](const std::array<int, 5>& d) { return single_face(d, 3); }},
        {"fours",            [](const std::array<int, 5>& d) { return single_face(d, 4); }},
        {"fives",            [](const std::array<int, 5>& d) { return single_face(d, 5); }},
        {"sixes",            [](const std::array<int, 5>& d) { return single_face(d, 6); }},
        {"full house",       full_house},
        {"four of a kind",   four_of_a_kind},
        {"little straight",  little_straight},
        {"big straight",     big_straight},
        {"choice",           sum_of},
        {"yacht",            yacht_score},
    };

    auto it = scorers.find(category);
    if (it == scorers.end()) {
        return 0;
    }
    return it->second(dice);
}

}  // namespace yacht
