#include "circular_buffer.h"

// The circular_buffer template is implemented in circular_buffer.h.
