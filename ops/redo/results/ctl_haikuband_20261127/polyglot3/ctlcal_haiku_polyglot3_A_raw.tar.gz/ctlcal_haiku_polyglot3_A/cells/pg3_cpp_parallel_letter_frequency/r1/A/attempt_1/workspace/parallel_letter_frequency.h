#if !defined(PARALLEL_LETTER_FREQUENCY_H)
#define PARALLEL_LETTER_FREQUENCY_H

#include <cstddef>
#include <map>
#include <string_view>
#include <vector>

namespace parallel_letter_frequency {

// Counts how often each letter occurs across all texts, computing partial
// counts in parallel. Letters are case-insensitive (stored lowercase); only
// ASCII letters are counted. Letters that never occur are not present.
std::map<char, std::size_t> frequency(std::vector<std::string_view> const& texts);

}  // namespace parallel_letter_frequency

#endif
