use std::collections::HashMap;
use std::thread;

/// Counts the frequency of each letter across all `input` texts, using
/// `worker_count` threads. Only alphabetic characters are counted, and they
/// are case-folded to lowercase.
pub fn frequency(input: &[&str], worker_count: usize) -> HashMap<char, usize> {
    if input.is_empty() {
        return HashMap::new();
    }

    let workers = worker_count.max(1);
    // Ceiling division so that at most `workers` chunks are produced.
    let chunk_size = input.len().div_ceil(workers);

    thread::scope(|scope| {
        let handles: Vec<_> = input
            .chunks(chunk_size)
            .map(|chunk| scope.spawn(move || count_chunk(chunk)))
            .collect();

        let mut total: HashMap<char, usize> = HashMap::new();
        for handle in handles {
            let partial = handle.join().expect("worker thread panicked");
            for (letter, count) in partial {
                *total.entry(letter).or_insert(0) += count;
            }
        }
        total
    })
}

fn count_chunk(texts: &[&str]) -> HashMap<char, usize> {
    let mut counts: HashMap<char, usize> = HashMap::new();
    for text in texts {
        for ch in text.chars().filter(|c| c.is_alphabetic()) {
            for lower in ch.to_lowercase() {
                *counts.entry(lower).or_insert(0) += 1;
            }
        }
    }
    counts
}
