#include "perfect_numbers.h"
#ifdef EXERCISM_TEST_SUITE
#include <catch2/catch.hpp>
#else
#include "test/catch.hpp"
#endif

// improves error messages with enum text instead of integers:
CATCH_REGISTER_ENUM(perfect_numbers::classification,
        perfect_numbers::classification::perfect,
        perfect_numbers::classification::abundant,
        perfect_numbers::classification::deficient)

TEST_CASE("Smallest perfect number is classified correctly", "[163e8e86-7bfd-4ee2-bd68-d083dc3381a3]") {
	REQUIRE(perfect_numbers::classification::perfect == perfect_numbers::classify(6));
}




TEST_CASE("Large perfect number is classified correctly", "[ee3627c4-7b36-4245-ba7c-8727d585f402]") {
	REQUIRE(perfect_numbers::classification::perfect == perfect_numbers::classify(33550336));
}

TEST_CASE("Smallest abundant number is classified correctly", "[80ef7cf8-9ea8-49b9-8b2d-d9cb3db3ed7e]") {
	REQUIRE(perfect_numbers::classification::abundant == perfect_numbers::classify(12));
}

TEST_CASE("Medium abundant number is classified correctly", "[3e300e0d-1a12-4f11-8c48-d1027165ab60]") {
	REQUIRE(perfect_numbers::classification::abundant == perfect_numbers::classify(30));
}











TEST_CASE("Edge case (no factors other than itself) is classified correctly", "[a696dec8-6147-4d68-afad-d38de5476a56]") {
	REQUIRE(perfect_numbers::classification::deficient == perfect_numbers::classify(1));
}

TEST_CASE("Zero is rejected (as it is not a positive integer)", "[72445cee-660c-4d75-8506-6c40089dc302]") {
	REQUIRE_THROWS_AS(perfect_numbers::classify(0),std::domain_error);
}



