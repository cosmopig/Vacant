"""Tests for this exercise (rust). Runs the language's own test suite once and reports one result per original test function:
15 test methods here. Run with `python3 -m unittest solution_test` (or run the native command in contract.md)."""
import hashlib
import os
import re
import shutil
import subprocess
import tempfile
import unittest

_HERE = os.path.dirname(os.path.abspath(__file__))
_LANG = "rust"
_DEST = "tests/bowling.rs"
_HIDDEN_SRC = None
_EXPECT_SHA = "04288cbcde6cddd12ce3bd4e16a4a13797234304841f9c9e29066a6966eaed23"
_NAMES = ["a_game_score_is_some_if_ten_frames_have_been_rolled", "twenty_zero_pin_rolls_scores_zero", "points_scored_in_the_roll_after_a_spare_are_counted_twice_as_a_bonus", "consecutive_spares_each_get_a_one_roll_bonus", "a_spare_with_the_two_roll_bonus_does_not_get_a_bonus_roll", "strikes_with_the_two_roll_bonus_do_not_get_a_bonus_roll", "a_strike_with_the_one_roll_bonus_after_a_spare_in_the_last_frame_does_not_get_a_bonus", "all_strikes_is_a_perfect_score_of_300", "first_bonus_ball_after_a_final_strike_cannot_score_an_invalid_number_of_pins", "the_two_balls_after_a_final_strike_cannot_score_an_invalid_number_of_pins", "the_two_balls_after_a_final_strike_cannot_be_a_non_strike_followed_by_a_strike", "if_the_last_frame_is_a_strike_you_cannot_score_before_the_extra_rolls_are_taken", "if_the_last_frame_is_a_spare_you_cannot_create_a_score_before_extra_roll_is_taken", "cannot_roll_after_bonus_roll_for_spare", "last_two_strikes_followed_by_only_last_bonus_with_non_strike_points"]
_FILTERS = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", ""]
_NAME = "bowling"
_state = {"res": None}
_ENV = {"PATH": "/opt/polytools/rust/bin:/usr/local/go/bin:/usr/local/bin:/usr/bin:/bin", "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8",
        "GOPROXY": "off", "GOFLAGS": "-mod=mod", "GOTOOLCHAIN": "local", "CARGO_NET_OFFLINE": "true"}
_SKIP = {".git", "node_modules", "target", "__pycache__", ".polycache"}


def _run(cmd, cwd, env, timeout):
    p = subprocess.Popen(cmd, cwd=cwd, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                         start_new_session=True)
    try:
        out, _ = p.communicate(timeout=timeout)
        return p.returncode, out.decode("utf-8", "replace"), False
    except subprocess.TimeoutExpired:
        try:
            os.killpg(p.pid, 9)
        except OSError:
            pass
        out, _ = p.communicate()
        return None, out.decode("utf-8", "replace"), True


def _execute():
    tmp = tempfile.mkdtemp(prefix="poly-")
    env = dict(_ENV, HOME=tmp, GOCACHE=os.path.join(tmp, "gocache"), GOPATH=os.path.join(tmp, "gopath"), CARGO_HOME=os.path.join(tmp, "cargo"))
    try:
        w = os.path.join(tmp, "w")
        shutil.copytree(_HERE, w, symlinks=True, ignore=shutil.ignore_patterns(*_SKIP))
        dest = os.path.join(w, _DEST)
        if _HIDDEN_SRC:
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            shutil.copyfile(os.path.join(_HERE, _HIDDEN_SRC), dest)
        else:
            if not os.path.isfile(dest) or hashlib.sha256(open(dest, "rb").read()).hexdigest() != _EXPECT_SHA:
                return {"fatal": "the test file %s was modified or is missing" % _DEST}
        res = {}
        if _LANG == "rust":
            rc, out, to = _run(["cargo", "test", "--offline", "--", "--include-ignored", "--test-threads=4"], w, env, 240)
            for m in re.finditer(r"^test (\S+) \.\.\. (ok|FAILED|ignored)", out, re.M):
                res[m.group(1)] = m.group(2) == "ok"
            res["_out"] = out[-1500:]
            res["_timeout"] = to
        elif _LANG == "go":
            rc, out, to = _run(["go", "test", "-v", "-timeout", "120s", "./..."], w, env, 240)
            for m in re.finditer(r"^--- (PASS|FAIL|SKIP): (\S+)", out, re.M):
                res[m.group(2)] = m.group(1) == "PASS"
            res["_out"] = out[-1500:]
            res["_timeout"] = to
        else:
            exe = os.path.join(w, "polybin")
            srcs = [os.path.join(w, f) for f in os.listdir(w) if f.endswith(".cpp") and f != "polybin.cpp"]
            main_o = _catch_main(w, env)
            if main_o is None:
                return {"_out": "could not build the Catch main", "_timeout": False}
            cmd = ["g++", "-std=c++17", "-Wall", "-Wextra", "-Wpedantic", "-Werror", "-DEXERCISM_RUN_ALL_TESTS", "-I", w, "-o", exe] + srcs + [main_o]
            rc, out, to = _run(cmd, w, env, 240)
            if rc != 0:
                res["_out"] = ("compile error: " + out)[-1500:]
                res["_timeout"] = to
                res["_compile_error"] = True
            else:
                res["_out"] = ""
                for name, flt in zip(_NAMES, _FILTERS):
                    rc2, out2, to2 = _run([exe, flt], w, env, 20)
                    res[name] = (rc2 == 0)
                    if rc2 != 0:
                        res["_out"] += "--- %s: %s\n" % (name, "timeout (20s)" if to2 else out2[-300:])
                res["_out"] = res["_out"][-1500:]
                res["_timeout"] = False
        return res
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _catch_main(w, env):
    """tests-main.cpp (CATCH_CONFIG_MAIN) compiled once per catch.hpp content; cached under /var/tmp."""
    src = os.path.join(w, "test", "tests-main.cpp")
    hdr = os.path.join(w, "test", "catch.hpp")
    if not (os.path.isfile(src) and os.path.isfile(hdr)):
        return None
    key = hashlib.sha256(open(src, "rb").read() + open(hdr, "rb").read()).hexdigest()[:16]
    cache = "/var/tmp/poly_catch_main_%s.o" % key
    if not os.path.isfile(cache):
        tmpo = cache + ".%d.tmp" % os.getpid()
        rc, out, to = _run(["g++", "-std=c++17", "-c", "-I", os.path.join(w, "test"), "-o", tmpo, src], w, env, 240)
        if rc != 0:
            return None
        os.replace(tmpo, cache)
    return cache


def _results():
    if _state["res"] is None:
        _state["res"] = _execute()
    return _state["res"]


def _check(tc, name):
    r = _results()
    if "fatal" in r:
        tc.fail(r["fatal"])
    if name in r and isinstance(r[name], bool) and r[name]:
        return
    if r.get("_compile_error"):
        tc.fail(r["_out"])
    tc.fail("test %s did not pass%s\n%s" % (name, " (timed out)" if r.get("_timeout") else "", r.get("_out", "")))


class SolutionTest(unittest.TestCase):
    pass


def _mk(name):
    def t(self):
        _check(self, name)
    return t


for _i, _n in enumerate(_NAMES):
    setattr(SolutionTest, "test_%02d_%s" % (_i, re.sub(r"\W+", "_", _n)[:60]), _mk(_n))

if __name__ == "__main__":
    unittest.main()
