#include "phone_number.h"

#include <cctype>
#include <stdexcept>

namespace phone_number {

namespace {

bool is_allowed_punctuation(char c) {
    return c == ' ' || c == '\t' || c == '(' || c == ')' || c == '-' ||
           c == '.' || c == '+';
}

// NANP digit rules: the first digit of both the area code and the exchange
// code must be from 2 through 9.
bool is_valid_leading_digit(char c) {
    return c >= '2' && c <= '9';
}

}  // namespace

phone_number::phone_number(const std::string& raw) {
    std::string digits;
    digits.reserve(raw.size());

    for (char c : raw) {
        if (std::isdigit(static_cast<unsigned char>(c))) {
            digits.push_back(c);
        } else if (!is_allowed_punctuation(c)) {
            throw std::domain_error("punctuation or letters not permitted");
        }
    }

    // Strip the NANP country code if present.
    if (digits.size() == 11) {
        if (digits[0] != '1') {
            throw std::domain_error("11 digits must start with country code 1");
        }
        digits.erase(0, 1);
    }

    if (digits.size() != 10) {
        throw std::domain_error("incorrect number of digits");
    }

    if (!is_valid_leading_digit(digits[0])) {
        throw std::domain_error("area code cannot start with this digit");
    }

    if (!is_valid_leading_digit(digits[3])) {
        throw std::domain_error("exchange code cannot start with this digit");
    }

    number_ = digits;
}

std::string phone_number::number() const {
    return number_;
}

}  // namespace phone_number
