use std::collections::HashMap;

/// Price in cents of a group of `n` distinct books (index = group size).
/// Each book costs 800 cents; discounts are 0%, 0%, 5%, 10%, 20%, 25%.
const GROUP_PRICE: [u32; 6] = [0, 800, 1520, 2160, 2560, 3000];

/// Minimal price (in cents) for the given counts of each of the five titles.
/// The price of a group depends only on its size, and titles are symmetric,
/// so the memo key is the sorted (descending) count vector.
fn best(counts: [u32; 5], memo: &mut HashMap<[u32; 5], u32>) -> u32 {
    if counts.iter().all(|&c| c == 0) {
        return 0;
    }
    let mut key = counts;
    key.sort_unstable_by(|a, b| b.cmp(a));
    if let Some(&v) = memo.get(&key) {
        return v;
    }

    let mut result = u32::MAX;
    // Every nonempty subset of titles that still has copies forms one group.
    for mask in 1u32..32 {
        let mut ok = true;
        let mut next = counts;
        for i in 0..5 {
            if mask & (1 << i) != 0 {
                if counts[i] == 0 {
                    ok = false;
                    break;
                }
                next[i] -= 1;
            }
        }
        if !ok {
            continue;
        }
        let size = mask.count_ones() as usize;
        let cost = GROUP_PRICE[size] + best(next, memo);
        result = result.min(cost);
    }

    memo.insert(key, result);
    result
}

pub fn lowest_price(books: &[u32]) -> u32 {
    let mut counts = [0u32; 5];
    for &b in books {
        assert!((1..=5).contains(&b), "book id must be in 1..=5, got {b}");
        counts[(b - 1) as usize] += 1;
    }
    let mut memo = HashMap::new();
    best(counts, &mut memo)
}
