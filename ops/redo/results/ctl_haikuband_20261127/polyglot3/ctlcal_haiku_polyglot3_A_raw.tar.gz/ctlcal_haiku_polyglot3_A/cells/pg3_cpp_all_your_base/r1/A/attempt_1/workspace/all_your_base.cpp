#include "all_your_base.h"

#include <cstdint>

namespace all_your_base {

std::vector<unsigned int> convert(unsigned int from_base,
                                  const std::vector<unsigned int>& digits,
                                  unsigned int to_base) {
    if (from_base < 2) {
        throw std::invalid_argument("input base must be >= 2");
    }
    if (to_base < 2) {
        throw std::invalid_argument("output base must be >= 2");
    }

    // Horner's method: value = value * from_base + digit, accumulated in a
    // wide integer type, then repeatedly divided by to_base to get the digits.
    // The value is kept as a little-endian big number in base 2^32 limbs so
    // that arbitrarily long inputs are supported without overflow.
    std::vector<std::uint32_t> limbs;  // little-endian, base 2^32

    for (unsigned int digit : digits) {
        if (digit >= from_base) {
            throw std::invalid_argument("digit out of range for input base");
        }
        // limbs = limbs * from_base + digit
        std::uint64_t carry = digit;
        for (auto& limb : limbs) {
            std::uint64_t prod = static_cast<std::uint64_t>(limb) * from_base + carry;
            limb = static_cast<std::uint32_t>(prod & 0xFFFFFFFFu);
            carry = prod >> 32;
        }
        while (carry != 0) {
            limbs.push_back(static_cast<std::uint32_t>(carry & 0xFFFFFFFFu));
            carry >>= 32;
        }
    }

    // Strip high zero limbs so that zero is represented by an empty vector.
    while (!limbs.empty() && limbs.back() == 0) {
        limbs.pop_back();
    }

    std::vector<unsigned int> result;
    // Repeated division of the big number by to_base; remainders are the
    // output digits, least significant first.
    while (!limbs.empty()) {
        std::uint64_t remainder = 0;
        for (std::size_t i = limbs.size(); i-- > 0;) {
            std::uint64_t cur = (remainder << 32) | limbs[i];
            limbs[i] = static_cast<std::uint32_t>(cur / to_base);
            remainder = cur % to_base;
        }
        result.push_back(static_cast<unsigned int>(remainder));
        while (!limbs.empty() && limbs.back() == 0) {
            limbs.pop_back();
        }
    }

    // Digits were produced least significant first; reverse them.
    std::vector<unsigned int> out(result.rbegin(), result.rend());
    return out;
}

}  // namespace all_your_base
