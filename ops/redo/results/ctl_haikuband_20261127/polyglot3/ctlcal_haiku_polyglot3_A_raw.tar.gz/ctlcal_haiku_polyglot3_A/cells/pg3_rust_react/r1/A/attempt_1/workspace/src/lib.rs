/// `InputCellId` is a unique identifier for an input cell.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct InputCellId(usize);
/// `ComputeCellId` is a unique identifier for a compute cell.
/// Values of type `InputCellId` and `ComputeCellId` should not be mutually assignable,
/// demonstrated by the following tests:
///
/// ```compile_fail
/// let mut r = react::Reactor::new();
/// let input: react::ComputeCellId = r.create_input(111);
/// ```
///
/// ```compile_fail
/// let mut r = react::Reactor::new();
/// let input = r.create_input(111);
/// let compute: react::InputCellId = r.create_compute(&[react::CellId::Input(input)], |_| 222).unwrap();
/// ```
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct ComputeCellId(usize);
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct CallbackId(usize);

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum CellId {
    Input(InputCellId),
    Compute(ComputeCellId),
}

#[derive(Debug, PartialEq, Eq)]
pub enum RemoveCallbackError {
    NonexistentCell,
    NonexistentCallback,
}

struct ComputeCell<'a, T> {
    dependencies: Vec<CellId>,
    compute_func: Box<dyn Fn(&[T]) -> T + 'a>,
    value: T,
    callbacks: Vec<(CallbackId, Box<dyn FnMut(T) + 'a>)>,
}

pub struct Reactor<'a, T> {
    inputs: Vec<T>,
    computes: Vec<ComputeCell<'a, T>>,
    next_callback_id: usize,
}

// You are guaranteed that Reactor will only be tested against types that are Copy + PartialEq.
impl<'a, T: Copy + PartialEq> Reactor<'a, T> {
    pub fn new() -> Self {
        Reactor {
            inputs: Vec::new(),
            computes: Vec::new(),
            next_callback_id: 0,
        }
    }

    // Creates an input cell with the specified initial value, returning its ID.
    pub fn create_input(&mut self, initial: T) -> InputCellId {
        self.inputs.push(initial);
        InputCellId(self.inputs.len() - 1)
    }

    // Creates a compute cell with the specified dependencies and compute function.
    // The compute function is expected to take in its arguments in the same order as specified in
    // `dependencies`.
    // You do not need to reject compute functions that expect more arguments than there are
    // dependencies (how would you check for this, anyway?).
    //
    // If any dependency doesn't exist, returns an Err with that nonexistent dependency.
    // (If multiple dependencies do not exist, exactly which one is returned is not defined and
    // will not be tested)
    //
    // Notice that there is no way to *remove* a cell.
    // This means that you may assume, without checking, that if the dependencies exist at creation
    // time they will continue to exist as long as the Reactor exists.
    pub fn create_compute<F: Fn(&[T]) -> T + 'a>(
        &mut self,
        dependencies: &[CellId],
        compute_func: F,
    ) -> Result<ComputeCellId, CellId> {
        let mut args = Vec::with_capacity(dependencies.len());
        for &dep in dependencies {
            match self.value(dep) {
                Some(v) => args.push(v),
                None => return Err(dep),
            }
        }
        let value = compute_func(&args);
        self.computes.push(ComputeCell {
            dependencies: dependencies.to_vec(),
            compute_func: Box::new(compute_func),
            value,
            callbacks: Vec::new(),
        });
        // Dependencies always have smaller indices than the cell that depends on them, so the
        // order of `computes` is a valid topological order.
        Ok(ComputeCellId(self.computes.len() - 1))
    }

    // Retrieves the current value of the cell, or None if the cell does not exist.
    //
    // You may wonder whether it is possible to implement `get(&self, id: CellId) -> Option<&Cell>`
    // and have a `value(&self)` method on `Cell`.
    //
    // It turns out this introduces a significant amount of extra complexity to this exercise.
    // We chose not to cover this here, since this exercise is probably enough work as-is.
    pub fn value(&self, id: CellId) -> Option<T> {
        match id {
            CellId::Input(InputCellId(i)) => self.inputs.get(i).copied(),
            CellId::Compute(ComputeCellId(i)) => self.computes.get(i).map(|c| c.value),
        }
    }

    // Sets the value of the specified input cell.
    //
    // Returns false if the cell does not exist.
    //
    // Similarly, you may wonder about `get_mut(&mut self, id: CellId) -> Option<&mut Cell>`, with
    // a `set_value(&mut self, new_value: T)` method on `Cell`.
    //
    // As before, that turned out to add too much extra complexity.
    pub fn set_value(&mut self, id: InputCellId, new_value: T) -> bool {
        match self.inputs.get_mut(id.0) {
            Some(slot) => *slot = new_value,
            None => return false,
        }
        self.propagate();
        true
    }

    // Adds a callback to the specified compute cell.
    //
    // Returns the ID of the just-added callback, or None if the cell doesn't exist.
    //
    // Callbacks on input cells will not be tested.
    //
    // The semantics of callbacks (as will be tested):
    // For a single set_value call, each compute cell's callbacks should each be called:
    // * Zero times if the compute cell's value did not change as a result of the set_value call.
    // * Exactly once if the compute cell's value changed as a result of the set_value call.
    //   The value passed to the callback should be the final value of the compute cell after the
    //   set_value call.
    pub fn add_callback<F: FnMut(T) + 'a>(
        &mut self,
        id: ComputeCellId,
        callback: F,
    ) -> Option<CallbackId> {
        let cell = self.computes.get_mut(id.0)?;
        let callback_id = CallbackId(self.next_callback_id);
        self.next_callback_id += 1;
        cell.callbacks.push((callback_id, Box::new(callback)));
        Some(callback_id)
    }

    // Removes the specified callback, using an ID returned from add_callback.
    //
    // Returns an Err if either the cell or callback does not exist.
    //
    // A removed callback should no longer be called.
    pub fn remove_callback(
        &mut self,
        cell: ComputeCellId,
        callback: CallbackId,
    ) -> Result<(), RemoveCallbackError> {
        let cell = self
            .computes
            .get_mut(cell.0)
            .ok_or(RemoveCallbackError::NonexistentCell)?;
        let pos = cell
            .callbacks
            .iter()
            .position(|(id, _)| *id == callback)
            .ok_or(RemoveCallbackError::NonexistentCallback)?;
        let _removed = cell.callbacks.remove(pos);
        Ok(())
    }

    // Recomputes every compute cell from the current inputs, then fires callbacks for each compute
    // cell whose value differs from the value it had before the change.
    fn propagate(&mut self) {
        let old_values: Vec<T> = self.computes.iter().map(|c| c.value).collect();

        for i in 0..self.computes.len() {
            let args: Vec<T> = self.computes[i]
                .dependencies
                .iter()
                .map(|&dep| self.value(dep).expect("dependency must exist"))
                .collect();
            let new_value = (self.computes[i].compute_func)(&args);
            self.computes[i].value = new_value;
        }

        for (i, old) in old_values.into_iter().enumerate() {
            let cell = &mut self.computes[i];
            if cell.value != old {
                let value = cell.value;
                for (_, callback) in cell.callbacks.iter_mut() {
                    callback(value);
                }
            }
        }
    }
}
