#include "parallel_letter_frequency.h"

#include <algorithm>
#include <array>
#include <random>
#include <string>
#include <string_view>

#ifdef EXERCISM_TEST_SUITE
#include <catch2/catch.hpp>
#else
#include "test/catch.hpp"
#endif

TEST_CASE("no texts",
          "[calculateFrequencies][c054d642-c1fa-4234-8007-9339f2337886]") {
    std::vector<std::string_view> const texts = {};
    auto freqs = parallel_letter_frequency::frequency(texts);
    CHECK(freqs.empty());
}

TEST_CASE("one text with one letter",
          "[calculateFrequencies][818031be-49dc-4675-b2f9-c4047f638a2a]") {
    std::vector<std::string_view> const texts = {
        "a",
    };
    auto freqs = parallel_letter_frequency::frequency(texts);
    CHECK(freqs['a'] == 1);
}



TEST_CASE("two texts with one letter",
          "[calculateFrequencies][708ff1e0-f14a-43fd-adb5-e76750dcf108]") {
    std::vector<std::string_view> const texts = {
        "e",
        "f",
    };
    auto freqs = parallel_letter_frequency::frequency(texts);
    CHECK(freqs['e'] == 1);
    CHECK(freqs['f'] == 1);
}





TEST_CASE("ignore whitespace",
          "[calculateFrequencies][92ebcbb0-9181-4421-a784-f6f5aa79f75b]") {
    std::vector<std::string_view> const texts = {
        "   ",
        "	",
        "\n",
    };
    auto freqs = parallel_letter_frequency::frequency(texts);
    CHECK(freqs.empty());
}



TEST_CASE("ignore numbers",
          "[calculateFrequencies][68032b8b-346b-4389-a380-e397618f6831]") {
    std::vector<std::string_view> const texts = {
        "1", "2", "3", "4", "5", "6", "7", "8", "9",
    };
    auto freqs = parallel_letter_frequency::frequency(texts);
    CHECK(freqs.empty());
}







#if defined(EXERCISM_INCLUDE_BENCHMARK)
TEST_CASE("benchmark") {
    std::vector<std::string> texts;
    std::vector<std::string_view> views;
    std::mt19937 rng;
    std::uniform_int_distribution<> distrib(32, 126);
    for (auto i = 0; i < 10; ++i) {
        texts.emplace_back(10 * 1024, 'x');
        std::generate_n(
            texts.back().begin(), texts.back().length(),
            [&rng, &distrib]() { return static_cast<char>(distrib(rng)); });
        views.emplace_back(texts.back());
    }

    BENCHMARK("10 random texts with 10 KiB each") {
        return parallel_letter_frequency::frequency(views);
    };
}
#endif
