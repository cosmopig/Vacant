# Contract

Implement the exercise in `src/lib.rs` (a stub; keep the names the tests use). Standard library only, no network; do not change `Cargo.toml`.

- The tests are in `tests/nucleotide_codons.rs`. The tests are correct; don't change them. Run them with:

      cargo test

  (the same suite is also run by `python3 -m unittest solution_test`, one test method per test function).
