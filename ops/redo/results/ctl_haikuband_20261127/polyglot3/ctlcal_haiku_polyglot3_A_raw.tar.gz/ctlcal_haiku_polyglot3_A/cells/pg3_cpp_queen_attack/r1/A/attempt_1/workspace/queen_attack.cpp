#include "queen_attack.h"

#include <cstdlib>

namespace queen_attack {

chess_board::chess_board(std::pair<int, int> white, std::pair<int, int> black)
    : white_{white}, black_{black} {}

bool chess_board::can_attack() const {
    const int dr = white_.first - black_.first;
    const int dc = white_.second - black_.second;

    if (dr == 0 || dc == 0) {
        return true;  // same row or same column
    }
    return std::abs(dr) == std::abs(dc);  // same diagonal
}

}  // namespace queen_attack
