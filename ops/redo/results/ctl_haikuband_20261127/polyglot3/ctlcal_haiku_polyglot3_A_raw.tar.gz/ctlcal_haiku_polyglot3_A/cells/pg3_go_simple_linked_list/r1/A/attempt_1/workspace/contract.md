# Contract

Implement the exercise in the existing Go source files of this directory (stubs; keep the names the tests use). Standard library only, no network.

- The tests are in `simple_linked_list_test.go`. The tests are correct; don't change them. Run them with:

      go test ./...

  (the same suite is also run by `python3 -m unittest solution_test`, one test method per Go test function).
