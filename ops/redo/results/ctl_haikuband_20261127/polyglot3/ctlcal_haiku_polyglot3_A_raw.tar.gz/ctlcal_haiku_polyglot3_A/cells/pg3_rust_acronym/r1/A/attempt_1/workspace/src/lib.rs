pub fn abbreviate(phrase: &str) -> String {
    phrase
        .split(|c: char| c.is_whitespace() || c == '-')
        .filter_map(|word| {
            word.chars()
                .find(|c| c.is_alphabetic())
                .map(|c| c.to_ascii_uppercase())
        })
        .collect()
}
