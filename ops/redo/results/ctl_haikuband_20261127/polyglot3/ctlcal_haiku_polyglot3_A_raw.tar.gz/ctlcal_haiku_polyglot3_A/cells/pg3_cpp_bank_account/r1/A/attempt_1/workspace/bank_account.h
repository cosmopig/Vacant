#if !defined(BANK_ACCOUNT_H)
#define BANK_ACCOUNT_H

#include <cstdint>
#include <mutex>
#include <stdexcept>

namespace Bankaccount {

// A bank account that may be used concurrently from multiple threads.
// Every operation holds an internal mutex for its whole read-check-update
// sequence, so balance reads and updates cannot interleave.
class Bankaccount {
public:
    Bankaccount() = default;
    Bankaccount(const Bankaccount&) = delete;
    Bankaccount& operator=(const Bankaccount&) = delete;

    // Opens the account. Throws std::runtime_error if already open.
    void open();

    // Closes the account. Throws std::runtime_error if not open.
    void close();

    // Returns the current balance. Throws std::runtime_error if not open.
    std::int64_t balance() const;

    // Adds amount to the balance. Throws if not open or amount is negative.
    void deposit(std::int64_t amount);

    // Removes amount from the balance. Throws if not open, amount is
    // negative, or amount exceeds the balance.
    void withdraw(std::int64_t amount);

private:
    mutable std::mutex mutex_;
    bool is_open_ = false;
    std::int64_t balance_ = 0;
};

}  // namespace Bankaccount

#endif  // BANK_ACCOUNT_H
