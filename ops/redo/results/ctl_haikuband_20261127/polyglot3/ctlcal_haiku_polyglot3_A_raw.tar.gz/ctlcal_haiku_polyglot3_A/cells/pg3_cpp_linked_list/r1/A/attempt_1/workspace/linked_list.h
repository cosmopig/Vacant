#pragma once

#include <cstddef>
#include <stdexcept>
#include <utility>

namespace linked_list {

// A doubly linked list of values of type T.
// Each node links to both its predecessor and its successor.
template <typename T>
class List {
   public:
    List() = default;

    List(const List&) = delete;
    List& operator=(const List&) = delete;

    List(List&& other) noexcept
        : head_(other.head_), tail_(other.tail_), size_(other.size_) {
        other.head_ = nullptr;
        other.tail_ = nullptr;
        other.size_ = 0;
    }

    List& operator=(List&& other) noexcept {
        if (this != &other) {
            clear();
            head_ = other.head_;
            tail_ = other.tail_;
            size_ = other.size_;
            other.head_ = nullptr;
            other.tail_ = nullptr;
            other.size_ = 0;
        }
        return *this;
    }

    ~List() { clear(); }

    // Adds an element to the end of the list.
    void push(const T& value) { insert_after(tail_, new Node{value, nullptr, nullptr}); }
    void push(T&& value) { insert_after(tail_, new Node{std::move(value), nullptr, nullptr}); }

    // Removes and returns the last element. Throws std::out_of_range if empty.
    T pop() {
        if (tail_ == nullptr) {
            throw std::out_of_range("pop on empty list");
        }
        Node* node = tail_;
        T value = std::move(node->value);
        unlink(node);
        return value;
    }

    // Removes and returns the first element. Throws std::out_of_range if empty.
    T shift() {
        if (head_ == nullptr) {
            throw std::out_of_range("shift on empty list");
        }
        Node* node = head_;
        T value = std::move(node->value);
        unlink(node);
        return value;
    }

    // Adds an element to the start of the list.
    void unshift(const T& value) { insert_before(head_, new Node{value, nullptr, nullptr}); }
    void unshift(T&& value) { insert_before(head_, new Node{std::move(value), nullptr, nullptr}); }

    // Removes the first occurrence of value. Returns true if an element was removed.
    bool erase(const T& value) {
        for (Node* node = head_; node != nullptr; node = node->next) {
            if (node->value == value) {
                unlink(node);
                return true;
            }
        }
        return false;
    }

    // Returns the number of elements in the list.
    std::size_t count() const { return size_; }

   private:
    struct Node {
        T value;
        Node* prev;
        Node* next;
    };

    // Links node into the list directly after pos (or as the sole element if pos is null).
    void insert_after(Node* pos, Node* node) {
        if (pos == nullptr) {
            head_ = tail_ = node;
        } else {
            node->prev = pos;
            node->next = pos->next;
            if (pos->next != nullptr) {
                pos->next->prev = node;
            } else {
                tail_ = node;
            }
            pos->next = node;
        }
        ++size_;
    }

    // Links node into the list directly before pos (or as the sole element if pos is null).
    void insert_before(Node* pos, Node* node) {
        if (pos == nullptr) {
            head_ = tail_ = node;
        } else {
            node->next = pos;
            node->prev = pos->prev;
            if (pos->prev != nullptr) {
                pos->prev->next = node;
            } else {
                head_ = node;
            }
            pos->prev = node;
        }
        ++size_;
    }

    // Removes node from the list and deletes it.
    void unlink(Node* node) {
        if (node->prev != nullptr) {
            node->prev->next = node->next;
        } else {
            head_ = node->next;
        }
        if (node->next != nullptr) {
            node->next->prev = node->prev;
        } else {
            tail_ = node->prev;
        }
        delete node;
        --size_;
    }

    void clear() {
        while (head_ != nullptr) {
            unlink(head_);
        }
    }

    Node* head_ = nullptr;
    Node* tail_ = nullptr;
    std::size_t size_ = 0;
};

}  // namespace linked_list
