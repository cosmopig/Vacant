use book_store::*;

#[test]
fn only_a_single_book() {
    let input = &[1];
    let output = lowest_price(input);
    let expected = 800;
    assert_eq!(output, expected);
}

#[test]
fn two_of_the_same_book() {
    let input = &[2, 2];
    let output = lowest_price(input);
    let expected = 1600;
    assert_eq!(output, expected);
}



#[test]
fn two_different_books() {
    let input = &[1, 2];
    let output = lowest_price(input);
    let expected = 1520;
    assert_eq!(output, expected);
}



#[test]
fn four_different_books() {
    let input = &[1, 2, 3, 4];
    let output = lowest_price(input);
    let expected = 2560;
    assert_eq!(output, expected);
}

#[test]
fn five_different_books() {
    let input = &[1, 2, 3, 4, 5];
    let output = lowest_price(input);
    let expected = 3000;
    assert_eq!(output, expected);
}







#[test]
fn two_each_of_first_four_books_and_one_copy_each_of_rest() {
    let input = &[1, 1, 2, 2, 3, 3, 4, 4, 5];
    let output = lowest_price(input);
    let expected = 5560;
    assert_eq!(output, expected);
}



#[test]
fn three_copies_of_first_book_and_two_each_of_remaining() {
    let input = &[1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 1];
    let output = lowest_price(input);
    let expected = 6800;
    assert_eq!(output, expected);
}



#[test]
fn four_groups_of_four_are_cheaper_than_two_groups_each_of_five_and_three() {
    let input = &[1, 1, 2, 2, 3, 3, 4, 5, 1, 1, 2, 2, 3, 3, 4, 5];
    let output = lowest_price(input);
    let expected = 10240;
    assert_eq!(output, expected);
}

#[test]
fn check_that_groups_of_four_are_created_properly_even_when_there_are_more_groups_of_three_than_groups_of_five(
) {
    let input = &[
        1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 5, 5,
    ];
    let output = lowest_price(input);
    let expected = 14560;
    assert_eq!(output, expected);
}




