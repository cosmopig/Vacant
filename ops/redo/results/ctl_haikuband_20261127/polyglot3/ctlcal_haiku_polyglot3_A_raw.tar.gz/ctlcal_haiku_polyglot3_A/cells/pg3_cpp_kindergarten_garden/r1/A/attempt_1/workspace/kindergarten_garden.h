#pragma once

#include <array>
#include <string>

namespace kindergarten_garden {

enum class Plants { clover, grass, violets, radishes };

// `diagram` is the two rows of cups, nearest the windows first, separated by '\n'.
// Returns the four plants belonging to `student`.
// Throws std::invalid_argument if the student is not in the class or the diagram is malformed.
std::array<Plants, 4> plants(const std::string& diagram, const std::string& student);

}  // namespace kindergarten_garden
