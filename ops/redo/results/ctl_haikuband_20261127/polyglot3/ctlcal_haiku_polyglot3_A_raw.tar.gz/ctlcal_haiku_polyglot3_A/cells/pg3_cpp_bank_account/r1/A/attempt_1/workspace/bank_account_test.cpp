#include "bank_account.h"
#ifdef EXERCISM_TEST_SUITE
#include <catch2/catch.hpp>
#else
#include "test/catch.hpp"
#endif
#include <chrono>
#include <string>
#include <thread>

TEST_CASE("Newly opened account has zero balance", "[983a1528-4ceb-45e5-8257-8ce01aceb5ed]") {
    Bankaccount::Bankaccount account{};
    account.open();
    REQUIRE(account.balance() == 0);
}



TEST_CASE("Multiple deposits", "[3d9147d4-63f4-4844-8d2b-1fee2e9a2a0d]") {
    Bankaccount::Bankaccount account{};
    account.open();
    account.deposit(100);
    account.deposit(50);
    REQUIRE(account.balance() == 150);
}



TEST_CASE("Withdraw twice", "[6f6d242f-8c31-4ac6-8995-a90d42cad59f]") {
    Bankaccount::Bankaccount account{};
    account.open();
    account.deposit(100);
    account.withdraw(80);
    account.withdraw(20);
    REQUIRE(account.balance() == 0);
}



TEST_CASE("annot check balance of closed account", "[f9facfaa-d824-486e-8381-48832c4bbffd]") {
    Bankaccount::Bankaccount account{};
    account.open();
    account.close();

    REQUIRE_THROWS_AS(account.balance(), std::runtime_error);
}

TEST_CASE("Cannot deposit into closed account", "[7a65ba52-e35c-4fd2-8159-bda2bde6e59c]") {
    Bankaccount::Bankaccount account{};
    account.open();
    account.close();

    REQUIRE_THROWS_AS(account.deposit(50), std::runtime_error);
}





TEST_CASE("Cannot close an account that was not opened", "[c396d233-1c49-4272-98dc-7f502dbb9470]") {
    Bankaccount::Bankaccount account;

    REQUIRE_THROWS_AS(account.close(), std::runtime_error);
}

TEST_CASE("Cannot open an already opened account", "[c06f534f-bdc2-4a02-a388-1063400684de]") {
    Bankaccount::Bankaccount account;
    account.open();

    REQUIRE_THROWS_AS(account.open(), std::runtime_error);
}






TEST_CASE("Cannot withdraw negative", "[4f381ef8-10ef-4507-8e1d-0631ecc8ee72]") {
    Bankaccount::Bankaccount account;
    account.open();
    account.deposit(100);
    REQUIRE_THROWS_AS(account.withdraw(-50), std::runtime_error);
}



