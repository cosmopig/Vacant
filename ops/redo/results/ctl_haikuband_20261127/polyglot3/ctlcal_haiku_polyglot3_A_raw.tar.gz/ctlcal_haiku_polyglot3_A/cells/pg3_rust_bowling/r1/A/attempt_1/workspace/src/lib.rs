#[derive(Debug, PartialEq, Eq)]
pub enum Error {
    NotEnoughPinsLeft,
    GameComplete,
}

#[derive(Default)]
pub struct BowlingGame {
    rolls: Vec<u16>,
}

impl BowlingGame {
    pub fn new() -> Self {
        Self { rolls: Vec::new() }
    }

    pub fn roll(&mut self, pins: u16) -> Result<(), Error> {
        let standing = self.pins_standing().ok_or(Error::GameComplete)?;
        if pins > standing {
            return Err(Error::NotEnoughPinsLeft);
        }
        self.rolls.push(pins);
        Ok(())
    }

    pub fn score(&self) -> Option<u16> {
        if self.pins_standing().is_some() {
            return None;
        }

        let at = |i: usize| self.rolls.get(i).copied().unwrap_or(0);
        let mut total = 0;
        let mut i = 0;
        for _ in 0..9 {
            if at(i) == 10 {
                total += 10 + at(i + 1) + at(i + 2);
                i += 1;
            } else {
                let frame = at(i) + at(i + 1);
                total += if frame == 10 { 10 + at(i + 2) } else { frame };
                i += 2;
            }
        }
        // Tenth frame: its rolls (including any fill balls) are the score.
        total += self.rolls.get(i..).unwrap_or(&[]).iter().sum::<u16>();
        Some(total)
    }

    /// Number of pins that can still be knocked down by the next ball,
    /// or `None` if the game is complete.
    fn pins_standing(&self) -> Option<u16> {
        let rolls = &self.rolls;
        let mut i = 0;
        for _ in 0..9 {
            if i >= rolls.len() {
                return Some(10);
            }
            if rolls[i] == 10 {
                i += 1;
            } else if i + 1 >= rolls.len() {
                return Some(10 - rolls[i]);
            } else {
                i += 2;
            }
        }

        // Tenth frame.
        let tenth = &rolls[i..];
        match *tenth {
            [] => Some(10),
            [first] => Some(if first == 10 { 10 } else { 10 - first }),
            [10, second] => Some(if second == 10 { 10 } else { 10 - second }),
            [first, second] if first + second == 10 => Some(10),
            _ => None,
        }
    }
}
