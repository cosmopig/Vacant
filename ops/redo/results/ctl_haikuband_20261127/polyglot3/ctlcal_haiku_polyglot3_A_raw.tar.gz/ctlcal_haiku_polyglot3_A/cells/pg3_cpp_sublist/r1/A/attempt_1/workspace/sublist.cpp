#include "sublist.h"

#include <algorithm>

namespace sublist {

namespace {

// Returns true if `needle` appears as a contiguous sub-sequence of `haystack`.
bool contains_block(const std::vector<int>& haystack, const std::vector<int>& needle) {
    if (needle.empty()) {
        return true;
    }
    return std::search(haystack.begin(), haystack.end(),
                       needle.begin(), needle.end()) != haystack.end();
}

}  // namespace

List_comparison sublist(const std::vector<int>& a, const std::vector<int>& b) {
    if (a == b) {
        return List_comparison::equal;
    }
    if (a.size() < b.size() && contains_block(b, a)) {
        return List_comparison::sublist;
    }
    if (a.size() > b.size() && contains_block(a, b)) {
        return List_comparison::superlist;
    }
    return List_comparison::unequal;
}

}  // namespace sublist
