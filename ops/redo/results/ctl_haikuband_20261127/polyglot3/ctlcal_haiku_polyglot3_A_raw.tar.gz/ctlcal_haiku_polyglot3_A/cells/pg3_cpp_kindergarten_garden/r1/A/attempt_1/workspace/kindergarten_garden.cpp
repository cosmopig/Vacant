#include "kindergarten_garden.h"

#include <cstddef>
#include <stdexcept>
#include <string>
#include <vector>

namespace kindergarten_garden {

namespace {

const std::vector<std::string> kStudents{
    "Alice", "Bob", "Charlie", "David", "Eve", "Fred",
    "Ginny", "Harriet", "Ileana", "Joseph", "Kincaid", "Larry"};

Plants plant_from_code(char code) {
    switch (code) {
        case 'C': return Plants::clover;
        case 'G': return Plants::grass;
        case 'V': return Plants::violets;
        case 'R': return Plants::radishes;
        default: throw std::invalid_argument("unknown plant code");
    }
}

}  // namespace

std::array<Plants, 4> plants(const std::string& diagram, const std::string& student) {
    std::size_t index = kStudents.size();
    for (std::size_t i = 0; i < kStudents.size(); ++i) {
        if (kStudents[i] == student) {
            index = i;
            break;
        }
    }
    if (index == kStudents.size()) {
        throw std::invalid_argument("unknown student");
    }

    const std::size_t newline = diagram.find('\n');
    if (newline == std::string::npos) {
        throw std::invalid_argument("diagram must have two rows");
    }
    const std::string first = diagram.substr(0, newline);
    const std::string second = diagram.substr(newline + 1);
    const std::size_t start = 2 * index;
    if (first.size() < start + 2 || second.size() < start + 2) {
        throw std::invalid_argument("diagram row too short");
    }

    return {plant_from_code(first[start]), plant_from_code(first[start + 1]),
            plant_from_code(second[start]), plant_from_code(second[start + 1])};
}

}  // namespace kindergarten_garden
