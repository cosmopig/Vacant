use say::*;





#[test]
fn fourteen() {
    let input = 14;
    let output = encode(input);
    let expected = "fourteen";
    assert_eq!(output, expected);
}

#[test]
fn twenty() {
    let input = 20;
    let output = encode(input);
    let expected = "twenty";
    assert_eq!(output, expected);
}











#[test]
fn two_hundred() {
    let input = 200;
    let output = encode(input);
    let expected = "two hundred";
    assert_eq!(output, expected);
}

#[test]
fn nine_hundred_ninety_nine() {
    let input = 999;
    let output = encode(input);
    let expected = "nine hundred ninety-nine";
    assert_eq!(output, expected);
}

#[test]
fn one_thousand() {
    let input = 1_000;
    let output = encode(input);
    let expected = "one thousand";
    assert_eq!(output, expected);
}

#[test]
fn one_thousand_two_hundred_thirty_four() {
    let input = 1_234;
    let output = encode(input);
    let expected = "one thousand two hundred thirty-four";
    assert_eq!(output, expected);
}

#[test]
fn one_million() {
    let input = 1_000_000;
    let output = encode(input);
    let expected = "one million";
    assert_eq!(output, expected);
}

#[test]
fn one_million_two_thousand_three_hundred_forty_five() {
    let input = 1_002_345;
    let output = encode(input);
    let expected = "one million two thousand three hundred forty-five";
    assert_eq!(output, expected);
}

#[test]
fn one_billion() {
    let input = 1_000_000_000;
    let output = encode(input);
    let expected = "one billion";
    assert_eq!(output, expected);
}






