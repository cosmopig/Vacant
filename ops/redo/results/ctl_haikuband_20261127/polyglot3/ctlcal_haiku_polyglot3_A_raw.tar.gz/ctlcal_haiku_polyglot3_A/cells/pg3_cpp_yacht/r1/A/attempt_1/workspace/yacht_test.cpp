#include "yacht.h"
#ifdef EXERCISM_TEST_SUITE
#include <catch2/catch.hpp>
#else
#include "test/catch.hpp"
#endif


/*
The dice are represented always as a list of exactly five integers
with values between 1 and 6 inclusive. The category is a string.
the categories are 'ones' to 'sixes',
Then 'full house',
     'four of a kind'
     'little straight' 1-5
     'big straight' 2-6
     'choice', sometimes called Chance
     'yacht', or five of a kind
*/








TEST_CASE("Ones, out of order", "[023a07c8-6c6e-44d0-bc17-efc5e1b8205a]") {
	REQUIRE(3 == yacht::score({3, 1, 1, 5, 1}, "ones"));
}





TEST_CASE("Fours", "[dc41bceb-d0c5-4634-a734-c01b4233a0c6]") {
	REQUIRE(8 == yacht::score({1, 4, 1, 4, 1}, "fours"));
}







TEST_CASE("Sixes", "[e8a036e0-9d21-443a-8b5f-e15a9e19a761]") {
	REQUIRE(6 == yacht::score({2, 3, 4, 5, 6}, "sixes"));
}



TEST_CASE("Full house three small, two big", "[1822ca9d-f235-4447-b430-2e8cfc448f0c]") {
	REQUIRE(19 == yacht::score({5, 3, 3, 5, 3}, "full house"));
}

TEST_CASE("Two pair is not a full house", "[b208a3fc-db2e-4363-a936-9e9a71e69c07]") {
	REQUIRE(0 == yacht::score({2, 2, 4, 4, 5}, "full house"));
}

TEST_CASE("Four of a kind is not a full house", "[b90209c3-5956-445b-8a0b-0ac8b906b1c2]") {
	REQUIRE(0 == yacht::score({1, 4, 4, 4, 4}, "full house"));
}

TEST_CASE("Yacht is not a full house", "[32a3f4ee-9142-4edf-ba70-6c0f96eb4b0c]") {
	REQUIRE(0 == yacht::score({2, 2, 2, 2, 2}, "full house"));
}



TEST_CASE("Yacht can be scored{s Four of a Kind", "[f25c0c90-5397}732-9779-b1e9b5f612ca]") {
	REQUIRE(12 == yacht::score({3, 3, 3, 3, 3}, "four of a kind"));
}



TEST_CASE("Little Straight", "[b4743c82-1eb8-4a65-98f7-33ad126905cd]") {
	REQUIRE(30 == yacht::score({3, 5, 4, 1, 2}, "little straight"));
}



TEST_CASE("Four in order but not a little straight", "[97bde8f7-9058-43ea-9de7-0bc3ed6d3002]") {
	REQUIRE(0 == yacht::score({1, 1, 2, 3, 4}, "little straight"));
}



TEST_CASE("Minimum is 1, maximum is 5, but not a little straight", "[fd785ad2-c060-4e45-81c6-ea2bbb781b9d]") {
	REQUIRE(0 == yacht::score({1, 1, 3, 4, 5}, "little straight"));
}



TEST_CASE("Big Straight as little straight", "[87c67e1e-3e87-4f3a-a9b1-62927822b250]") {
	REQUIRE(0 == yacht::score({6, 5, 4, 3, 2}, "little straight"));
}

TEST_CASE("No pairs but not a big straight", "[c1fa0a3a-40ba-4153-a42d-32bc34d2521e]") {
	REQUIRE(0 == yacht::score({6, 5, 4, 3, 1}, "big straight"));
}

TEST_CASE("Choice", "[207e7300-5d10-43e5-afdd-213e3ac8827d]") {
	REQUIRE(23 == yacht::score({3, 3, 5, 6, 6}, "choice"));
}



