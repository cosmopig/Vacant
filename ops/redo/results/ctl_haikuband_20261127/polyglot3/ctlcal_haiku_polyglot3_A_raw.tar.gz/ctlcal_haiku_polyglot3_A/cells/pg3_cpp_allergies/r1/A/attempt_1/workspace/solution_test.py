"""Tests for this exercise (cpp). Runs the language's own test suite once and reports one result per original test function:
25 test methods here. Run with `python3 -m unittest solution_test` (or run the native command in contract.md)."""
import hashlib
import os
import re
import shutil
import subprocess
import tempfile
import unittest

_HERE = os.path.dirname(os.path.abspath(__file__))
_LANG = "cpp"
_DEST = "allergies_test.cpp"
_HIDDEN_SRC = None
_EXPECT_SHA = "13c96fd4ac67a849c82a18d1bcda0f1ba78f907435c35562666015b22d207b8e"
_NAMES = ["testing for eggs allergy -> not allergic to anything", "testing for eggs allergy -> allergic only to eggs", "testing for eggs allergy -> allergic to everything", "testing for peanuts allergy -> allergic to peanuts and something else", "testing for peanuts allergy -> allergic to something, but not peanuts", "testing for peanuts allergy -> allergic to everything", "testing for shellfish allergy -> not allergic to anything", "testing for shellfish allergy -> allergic to everything", "testing for strawberries allergy -> not allergic to anything", "testing for strawberries allergy -> allergic only to strawberries", "testing for tomatoes allergy -> not allergic to anything", "testing for tomatoes allergy -> allergic only to tomatoes", "testing for tomatoes allergy -> allergic to tomatoes and something else", "testing for tomatoes allergy -> allergic to everything", "testing for chocolate allergy -> allergic to chocolate and something else", "testing for pollen allergy -> not allergic to anything", "testing for pollen allergy -> allergic to pollen and something else", "testing for pollen allergy -> allergic to something, but not pollen", "testing for cats allergy -> allergic only to cats", "testing for cats allergy -> allergic to cats and something else", "list when: -> just eggs", "list when: -> eggs and peanuts", "list when: -> lots of stuff", "list when: -> no allergen score parts", "list when: -> no allergen score parts without highest valid score"]
_FILTERS = ["[17fc7296-2440-4ac4-ad7b-d07c321bc5a0]", "[07ced27b-1da5-4c2e-8ae2-cb2791437546]", "[90c8f484-456b-41c4-82ba-2d08d93231c6]", "[eac69ae9-8d14-4291-ac4b-7fd2c73d3a5b]", "[9152058c-ce39-4b16-9b1d-283ec6d25085]", "[d2d71fd8-63d5-40f9-a627-fbdaf88caeab]", "[b948b0a1-cbf7-4b28-a244-73ff56687c80]", "[cc789c19-2b5e-4c67-b146-625dc8cfa34e]", "[651bde0a-2a74-46c4-ab55-02a0906ca2f5]", "[b649a750-9703-4f5f-b7f7-91da2c160ece]", "[c49a91ef-6252-415e-907e-a9d26ef61723]", "[b69c5131-b7d0-41ad-a32c-e1b2cc632df8]", "[1ca50eb1-f042-4ccf-9050-341521b929ec]", "[b2414f01-f3ad-4965-8391-e65f54dad35f]", "[b0a7c07b-2db7-4f73-a180-565e07040ef1]", "[17f4a42b-c91e-41b8-8a76-4797886c2d96]", "[9a49aec5-fa1f-405d-889e-4dfc420db2b6]", "[3cb8e79f-d108-4712-b620-aa146b1954a9]", "[eba541c3-c886-42d3-baef-c048cb7fcd8f]", "[ba718376-26e0-40b7-bbbe-060287637ea5]", "[9e1a4364-09a6-4d94-990f-541a94a4c1e8]", "[6fa95d26-044c-48a9-8a7b-9ee46ec32c5c]", "[4b68f470-067c-44e4-889f-c9fe28917d2f]", "[12ce86de-b347-42a0-ab7c-2e0570f0c65b]", "[93c2df3e-4f55-4fed-8116-7513092819cd]"]
_NAME = "allergies"
_state = {"res": None}
_ENV = {"PATH": "/opt/polytools/rust/bin:/usr/local/go/bin:/usr/local/bin:/usr/bin:/bin", "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8",
        "GOPROXY": "off", "GOFLAGS": "-mod=mod", "GOTOOLCHAIN": "local", "CARGO_NET_OFFLINE": "true"}
_SKIP = {".git", "node_modules", "target", "__pycache__", ".polycache"}


def _run(cmd, cwd, env, timeout):
    p = subprocess.Popen(cmd, cwd=cwd, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                         start_new_session=True)
    try:
        out, _ = p.communicate(timeout=timeout)
        return p.returncode, out.decode("utf-8", "replace"), False
    except subprocess.TimeoutExpired:
        try:
            os.killpg(p.pid, 9)
        except OSError:
            pass
        out, _ = p.communicate()
        return None, out.decode("utf-8", "replace"), True


def _execute():
    tmp = tempfile.mkdtemp(prefix="poly-")
    env = dict(_ENV, HOME=tmp, GOCACHE=os.path.join(tmp, "gocache"), GOPATH=os.path.join(tmp, "gopath"), CARGO_HOME=os.path.join(tmp, "cargo"))
    try:
        w = os.path.join(tmp, "w")
        shutil.copytree(_HERE, w, symlinks=True, ignore=shutil.ignore_patterns(*_SKIP))
        dest = os.path.join(w, _DEST)
        if _HIDDEN_SRC:
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            shutil.copyfile(os.path.join(_HERE, _HIDDEN_SRC), dest)
        else:
            if not os.path.isfile(dest) or hashlib.sha256(open(dest, "rb").read()).hexdigest() != _EXPECT_SHA:
                return {"fatal": "the test file %s was modified or is missing" % _DEST}
        res = {}
        if _LANG == "rust":
            rc, out, to = _run(["cargo", "test", "--offline", "--", "--include-ignored", "--test-threads=4"], w, env, 240)
            for m in re.finditer(r"^test (\S+) \.\.\. (ok|FAILED|ignored)", out, re.M):
                res[m.group(1)] = m.group(2) == "ok"
            res["_out"] = out[-1500:]
            res["_timeout"] = to
        elif _LANG == "go":
            rc, out, to = _run(["go", "test", "-v", "-timeout", "120s", "./..."], w, env, 240)
            for m in re.finditer(r"^--- (PASS|FAIL|SKIP): (\S+)", out, re.M):
                res[m.group(2)] = m.group(1) == "PASS"
            res["_out"] = out[-1500:]
            res["_timeout"] = to
        else:
            exe = os.path.join(w, "polybin")
            srcs = [os.path.join(w, f) for f in os.listdir(w) if f.endswith(".cpp") and f != "polybin.cpp"]
            main_o = _catch_main(w, env)
            if main_o is None:
                return {"_out": "could not build the Catch main", "_timeout": False}
            cmd = ["g++", "-std=c++17", "-Wall", "-Wextra", "-Wpedantic", "-Werror", "-DEXERCISM_RUN_ALL_TESTS", "-I", w, "-o", exe] + srcs + [main_o]
            rc, out, to = _run(cmd, w, env, 240)
            if rc != 0:
                res["_out"] = ("compile error: " + out)[-1500:]
                res["_timeout"] = to
                res["_compile_error"] = True
            else:
                res["_out"] = ""
                for name, flt in zip(_NAMES, _FILTERS):
                    rc2, out2, to2 = _run([exe, flt], w, env, 20)
                    res[name] = (rc2 == 0)
                    if rc2 != 0:
                        res["_out"] += "--- %s: %s\n" % (name, "timeout (20s)" if to2 else out2[-300:])
                res["_out"] = res["_out"][-1500:]
                res["_timeout"] = False
        return res
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _catch_main(w, env):
    """tests-main.cpp (CATCH_CONFIG_MAIN) compiled once per catch.hpp content; cached under /var/tmp."""
    src = os.path.join(w, "test", "tests-main.cpp")
    hdr = os.path.join(w, "test", "catch.hpp")
    if not (os.path.isfile(src) and os.path.isfile(hdr)):
        return None
    key = hashlib.sha256(open(src, "rb").read() + open(hdr, "rb").read()).hexdigest()[:16]
    cache = "/var/tmp/poly_catch_main_%s.o" % key
    if not os.path.isfile(cache):
        tmpo = cache + ".%d.tmp" % os.getpid()
        rc, out, to = _run(["g++", "-std=c++17", "-c", "-I", os.path.join(w, "test"), "-o", tmpo, src], w, env, 240)
        if rc != 0:
            return None
        os.replace(tmpo, cache)
    return cache


def _results():
    if _state["res"] is None:
        _state["res"] = _execute()
    return _state["res"]


def _check(tc, name):
    r = _results()
    if "fatal" in r:
        tc.fail(r["fatal"])
    if name in r and isinstance(r[name], bool) and r[name]:
        return
    if r.get("_compile_error"):
        tc.fail(r["_out"])
    tc.fail("test %s did not pass%s\n%s" % (name, " (timed out)" if r.get("_timeout") else "", r.get("_out", "")))


class SolutionTest(unittest.TestCase):
    pass


def _mk(name):
    def t(self):
        _check(self, name)
    return t


for _i, _n in enumerate(_NAMES):
    setattr(SolutionTest, "test_%02d_%s" % (_i, re.sub(r"\W+", "_", _n)[:60]), _mk(_n))

if __name__ == "__main__":
    unittest.main()
