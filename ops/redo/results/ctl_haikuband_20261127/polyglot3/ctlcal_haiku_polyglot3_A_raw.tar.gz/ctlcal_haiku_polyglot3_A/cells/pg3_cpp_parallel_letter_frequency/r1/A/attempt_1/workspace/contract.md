# Contract

Implement the exercise in `parallel_letter_frequency.h` and `parallel_letter_frequency.cpp` (both exist as stubs; keep the names the tests use).
C++17, standard library only.

- The tests for this task are in `parallel_letter_frequency_test.cpp` (Catch2, with `test/catch.hpp` and `test/tests-main.cpp`). The tests are correct;
  don't change them or anything under `test/`. Build and run them with:

      g++ -std=c++17 -Wall -Wextra -Wpedantic -Werror -DEXERCISM_RUN_ALL_TESTS -o polybin parallel_letter_frequency_test.cpp parallel_letter_frequency.cpp test/tests-main.cpp && ./polybin

  (the same suite is also run by `python3 -m unittest solution_test`, one test method per Catch test case).
- Warnings are errors in that build.
