#include "perfect_numbers.h"

#include <stdexcept>

namespace perfect_numbers {

classification classify(int number) {
    if (number <= 0) {
        throw std::domain_error("number must be a positive integer");
    }
    if (number == 1) {
        return classification::deficient;
    }

    // Sum divisors in pairs (i, number / i) for i up to sqrt(number).
    // Start the sum at 1, since 1 is a proper divisor of every number > 1.
    long long sum = 1;
    for (long long i = 2; i * i <= number; ++i) {
        if (number % i == 0) {
            long long other = number / i;
            sum += i;
            if (other != i) {
                sum += other;
            }
        }
    }

    if (sum == number) {
        return classification::perfect;
    }
    return sum > number ? classification::abundant : classification::deficient;
}

}  // namespace perfect_numbers
