#if !defined(ALL_YOUR_BASE_H)
#define ALL_YOUR_BASE_H

#include <cstddef>
#include <stdexcept>
#include <vector>

namespace all_your_base {

// Converts the digits of a number written in `from_base` (most significant
// digit first) into the digits of the same number in `to_base`.
//
// Throws std::invalid_argument if either base is less than 2, or if any input
// digit is not smaller than `from_base`.
// Leading zeros are not emitted; zero (or an empty input) yields an empty vector.
std::vector<unsigned int> convert(unsigned int from_base,
                                  const std::vector<unsigned int>& digits,
                                  unsigned int to_base);

}  // namespace all_your_base

#endif // ALL_YOUR_BASE_H
