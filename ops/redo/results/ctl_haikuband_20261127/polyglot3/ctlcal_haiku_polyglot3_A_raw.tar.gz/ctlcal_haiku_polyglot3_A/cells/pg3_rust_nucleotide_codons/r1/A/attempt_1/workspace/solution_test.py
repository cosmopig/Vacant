"""Tests for this exercise (rust). Runs the language's own test suite once and reports one result per original test function:
5 test methods here. Run with `python3 -m unittest solution_test` (or run the native command in contract.md)."""
import hashlib
import os
import re
import shutil
import subprocess
import tempfile
import unittest

_HERE = os.path.dirname(os.path.abspath(__file__))
_LANG = "rust"
_DEST = "tests/nucleotide-codons.rs"
_HIDDEN_SRC = None
_EXPECT_SHA = "32fdf08ba4519582cdfd5b4edaf28dc17154dcc80b7f7077c25b987eb74a73af"
_NAMES = ["cysteine_tgt", "valine", "isoleucine", "empty_is_invalid", "too_short_is_invalid"]
_FILTERS = ["", "", "", "", ""]
_NAME = "nucleotide-codons"
_state = {"res": None}
_ENV = {"PATH": "/opt/polytools/rust/bin:/usr/local/go/bin:/usr/local/bin:/usr/bin:/bin", "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8",
        "GOPROXY": "off", "GOFLAGS": "-mod=mod", "GOTOOLCHAIN": "local", "CARGO_NET_OFFLINE": "true"}
_SKIP = {".git", "node_modules", "target", "__pycache__", ".polycache"}


def _run(cmd, cwd, env, timeout):
    p = subprocess.Popen(cmd, cwd=cwd, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                         start_new_session=True)
    try:
        out, _ = p.communicate(timeout=timeout)
        return p.returncode, out.decode("utf-8", "replace"), False
    except subprocess.TimeoutExpired:
        try:
            os.killpg(p.pid, 9)
        except OSError:
            pass
        out, _ = p.communicate()
        return None, out.decode("utf-8", "replace"), True


def _execute():
    tmp = tempfile.mkdtemp(prefix="poly-")
    env = dict(_ENV, HOME=tmp, GOCACHE=os.path.join(tmp, "gocache"), GOPATH=os.path.join(tmp, "gopath"), CARGO_HOME=os.path.join(tmp, "cargo"))
    try:
        w = os.path.join(tmp, "w")
        shutil.copytree(_HERE, w, symlinks=True, ignore=shutil.ignore_patterns(*_SKIP))
        dest = os.path.join(w, _DEST)
        if _HIDDEN_SRC:
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            shutil.copyfile(os.path.join(_HERE, _HIDDEN_SRC), dest)
        else:
            if not os.path.isfile(dest) or hashlib.sha256(open(dest, "rb").read()).hexdigest() != _EXPECT_SHA:
                return {"fatal": "the test file %s was modified or is missing" % _DEST}
        res = {}
        if _LANG == "rust":
            rc, out, to = _run(["cargo", "test", "--offline", "--", "--include-ignored", "--test-threads=4"], w, env, 240)
            for m in re.finditer(r"^test (\S+) \.\.\. (ok|FAILED|ignored)", out, re.M):
                res[m.group(1)] = m.group(2) == "ok"
            res["_out"] = out[-1500:]
            res["_timeout"] = to
        elif _LANG == "go":
            rc, out, to = _run(["go", "test", "-v", "-timeout", "120s", "./..."], w, env, 240)
            for m in re.finditer(r"^--- (PASS|FAIL|SKIP): (\S+)", out, re.M):
                res[m.group(2)] = m.group(1) == "PASS"
            res["_out"] = out[-1500:]
            res["_timeout"] = to
        else:
            exe = os.path.join(w, "polybin")
            srcs = [os.path.join(w, f) for f in os.listdir(w) if f.endswith(".cpp") and f != "polybin.cpp"]
            main_o = _catch_main(w, env)
            if main_o is None:
                return {"_out": "could not build the Catch main", "_timeout": False}
            cmd = ["g++", "-std=c++17", "-Wall", "-Wextra", "-Wpedantic", "-Werror", "-DEXERCISM_RUN_ALL_TESTS", "-I", w, "-o", exe] + srcs + [main_o]
            rc, out, to = _run(cmd, w, env, 240)
            if rc != 0:
                res["_out"] = ("compile error: " + out)[-1500:]
                res["_timeout"] = to
                res["_compile_error"] = True
            else:
                res["_out"] = ""
                for name, flt in zip(_NAMES, _FILTERS):
                    rc2, out2, to2 = _run([exe, flt], w, env, 20)
                    res[name] = (rc2 == 0)
                    if rc2 != 0:
                        res["_out"] += "--- %s: %s\n" % (name, "timeout (20s)" if to2 else out2[-300:])
                res["_out"] = res["_out"][-1500:]
                res["_timeout"] = False
        return res
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _catch_main(w, env):
    """tests-main.cpp (CATCH_CONFIG_MAIN) compiled once per catch.hpp content; cached under /var/tmp."""
    src = os.path.join(w, "test", "tests-main.cpp")
    hdr = os.path.join(w, "test", "catch.hpp")
    if not (os.path.isfile(src) and os.path.isfile(hdr)):
        return None
    key = hashlib.sha256(open(src, "rb").read() + open(hdr, "rb").read()).hexdigest()[:16]
    cache = "/var/tmp/poly_catch_main_%s.o" % key
    if not os.path.isfile(cache):
        tmpo = cache + ".%d.tmp" % os.getpid()
        rc, out, to = _run(["g++", "-std=c++17", "-c", "-I", os.path.join(w, "test"), "-o", tmpo, src], w, env, 240)
        if rc != 0:
            return None
        os.replace(tmpo, cache)
    return cache


def _results():
    if _state["res"] is None:
        _state["res"] = _execute()
    return _state["res"]


def _check(tc, name):
    r = _results()
    if "fatal" in r:
        tc.fail(r["fatal"])
    if name in r and isinstance(r[name], bool) and r[name]:
        return
    if r.get("_compile_error"):
        tc.fail(r["_out"])
    tc.fail("test %s did not pass%s\n%s" % (name, " (timed out)" if r.get("_timeout") else "", r.get("_out", "")))


class SolutionTest(unittest.TestCase):
    pass


def _mk(name):
    def t(self):
        _check(self, name)
    return t


for _i, _n in enumerate(_NAMES):
    setattr(SolutionTest, "test_%02d_%s" % (_i, re.sub(r"\W+", "_", _n)[:60]), _mk(_n))

if __name__ == "__main__":
    unittest.main()
