package linkedlist

import (
	"reflect"
	"testing"
)

var array1To10 = []int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10}



func TestSingletonListHasSizeOne(t *testing.T) {
	list := New([]int{1})
	if size := list.Size(); size != 1 {
		t.Fatalf("Size of singleton list: %d, expected: %d", size, 1)
	}
}

func TestNonEmptyListHasCorrectSize(t *testing.T) {
	list := New([]int{1, 2, 3})
	if size := list.Size(); size != 3 {
		t.Fatalf("Size of list from [1, 2, 3]: %d, expected: %d", size, 3)
	}
}

func TestListHasCorrectSizeAfterPop(t *testing.T) {
	list := New([]int{1, 2, 3})

	_, _ = list.Pop()
	_, _ = list.Pop()
	_, _ = list.Pop()

	if size := list.Size(); size != 0 {
		t.Fatalf("Size of list from [1, 2, 3] after 3 calls to pop(): got %d, expected: %d", size, 0)
	}
}

func TestListHasCorrectSizeAfterPush(t *testing.T) {
	list := New([]int{})

	list.Push(1)
	list.Push(2)
	list.Push(3)

	if size := list.Size(); size != 3 {
		t.Fatalf("Size of list from [] after 3 calls to push(): got %d, expected: %d", size, 3)
	}
}

func TestEmptyListToEmptyArray(t *testing.T) {
	list := New([]int{})
	if array := list.Array(); len(array) != 0 {
		t.Fatalf("Test empty list to array: %v, want empty array", array)
	}
	list = New(nil)
	if array := list.Array(); len(array) != 0 {
		t.Fatalf("Test empty list to array: %v, want empty array", array)
	}
}

func TestNonEmptyListToArray(t *testing.T) {
	expected := []int{1, 2, 3}
	list := New(expected)
	array := list.Array()
	if !reflect.DeepEqual(array, expected) {
		t.Fatalf("Test non empty list to array: %v, want %v", array, expected)
	}
}













func TestReverseNonEmptyList(t *testing.T) {
	list := New([]int{1, 2, 3})
	actual := list.Reverse().Array()
	expected := []int{3, 2, 1}
	if !reflect.DeepEqual(actual, expected) {
		t.Fatalf("Reverse non empty list: %v, want %v", actual, expected)
	}
}

func BenchmarkNewList(b *testing.B) {
	if testing.Short() {
		b.Skip("skipping benchmark in short mode.")
	}
	for i := 0; i < b.N; i++ {
		_ = New(array1To10)
	}
}

func BenchmarkListSize(b *testing.B) {
	if testing.Short() {
		b.Skip("skipping benchmark in short mode.")
	}
	list := New(array1To10)
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_ = list.Size()
	}
}

func BenchmarkListPush(b *testing.B) {
	if testing.Short() {
		b.Skip("skipping benchmark in short mode.")
	}
	for i := 0; i < b.N; i++ {
		b.StopTimer()
		list := New([]int{})
		b.StartTimer()
		for k := 0; k < 1000; k++ {
			list.Push(k)
		}
	}
}

func BenchmarkListPop(b *testing.B) {
	if testing.Short() {
		b.Skip("skipping benchmark in short mode.")
	}
	for i := 0; i < b.N; i++ {
		b.StopTimer()
		list := New([]int{})
		for k := 0; k < 1000; k++ {
			list.Push(k)
		}
		b.StartTimer()
		for k := 0; k < 1000; k++ {
			_, _ = list.Pop()
		}
	}
}

func BenchmarkListToArray(b *testing.B) {
	if testing.Short() {
		b.Skip("skipping benchmark in short mode.")
	}
	list := New(array1To10)
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_ = list.Array()
	}
}

func BenchmarkListReverse(b *testing.B) {
	if testing.Short() {
		b.Skip("skipping benchmark in short mode.")
	}
	list := New(array1To10)
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_ = list.Reverse()
	}
}
