/// Applies `function` to each element of `input`, returning a new vector of the results.
///
/// Implemented with a plain loop rather than the standard library's iterator
/// adapters, per the exercise restrictions.
pub fn map<T, U, F>(input: Vec<T>, mut function: F) -> Vec<U>
where
    F: FnMut(T) -> U,
{
    let mut output = Vec::with_capacity(input.len());
    for item in input {
        output.push(function(item));
    }
    output
}
