#include "linked_list.h"
#ifdef EXERCISM_TEST_SUITE
#include <catch2/catch.hpp>
#else
#include "test/catch.hpp"
#endif

/*
`delete`cannot be used as a name in C++ as it is reserved.
This track implements `erase` instead.
The tests have been renamed accordingly.
*/

TEST_CASE("pop gets element from the list", "[7f7e3987-b954-41b8-8084-99beca08752c]") {
    linked_list::List<int> llist{};
    llist.push(7);
    REQUIRE(7 == llist.pop());
}


TEST_CASE("push/pop respectively add/remove at the end of the list", "[c3f67e5d-cfa2-4c3e-a18f-7ce999c3c885]") {
    linked_list::List<int> llist{};
    llist.push(11);
    llist.push(13);
    REQUIRE(13 == llist.pop());
    REQUIRE(11 == llist.pop());
}









TEST_CASE("count an empty list", "[88f65c0c-4532-4093-8295-2384fb2f37df]") {
    linked_list::List<int> llist{};
    REQUIRE(0 == llist.count());
}





TEST_CASE("popping to empty doesn't break the list", "[229b8f7a-bd8a-4798-b64f-0dc0bb356d95]") {
    linked_list::List<int> llist{};
    llist.push(41);
    llist.push(59);
    llist.pop();
    llist.pop();
    llist.push(47);
    REQUIRE(1 == llist.count());
    REQUIRE(47 == llist.pop());
}

TEST_CASE("shifting to empty doesn't break the list", "[4e1948b4-514e-424b-a3cf-a1ebbfa2d1ad]") {
    linked_list::List<int> llist{};
    llist.push(41);
    llist.push(59);
    llist.shift();
    llist.shift();
    llist.push(47);
    REQUIRE(1 == llist.count());
    REQUIRE(47 == llist.shift());
}



TEST_CASE("erases the element with the specified value from the list", "[fd65e422-51f3-45c0-9fd0-c33da638f89b]") {
    linked_list::List<int> llist{};
    llist.push(71);
    llist.push(83);
    llist.push(79);
    llist.erase(83);
    REQUIRE(2 == llist.count());
    REQUIRE(79 == llist.pop());
    REQUIRE(71 == llist.shift());
}



TEST_CASE("erases the element with the specified value from the list, re-assigns head", "[58242222-5d39-415b-951d-8128247f8993]") {
	linked_list::List<int> llist{};
    llist.push(71);
    llist.push(83);
    llist.push(79);
    llist.erase(83);
    REQUIRE(2 == llist.count());
    REQUIRE(71 == llist.shift());
    REQUIRE(79 == llist.shift());
}

TEST_CASE("erases the first of two elements", "[ee3729ee-3405-4bd2-9bad-de0d4aa5d647]") {
	linked_list::List<int> llist{};
    llist.push(97);
    llist.push(101);
    llist.erase(97);
    REQUIRE(1 == llist.count());
    REQUIRE(101 == llist.pop());
}

TEST_CASE("erases the second of two elements", "[47e3b3b4-b82c-4c23-8c1a-ceb9b17cb9fb]") {
	linked_list::List<int> llist{};
    llist.push(97);
    llist.push(101);
    llist.erase(101);
    REQUIRE(1 == llist.count());
    REQUIRE(97 == llist.pop());
}





