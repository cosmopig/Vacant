use std::collections::{BTreeMap, BTreeSet, HashSet};

pub struct School {
    // grade -> sorted set of student names in that grade
    grades: BTreeMap<u32, BTreeSet<String>>,
    // every student currently enrolled anywhere in the school
    enrolled: HashSet<String>,
}

impl School {
    pub fn new() -> School {
        School {
            grades: BTreeMap::new(),
            enrolled: HashSet::new(),
        }
    }

    /// Adds `student` to `grade`. A student may only appear once in the whole
    /// roster, so adding a name that is already enrolled (in any grade) is
    /// rejected and the roster is left unchanged. Returns `true` if the student
    /// was added, `false` if they were already enrolled.
    pub fn add(&mut self, grade: u32, student: &str) -> bool {
        if self.enrolled.contains(student) {
            return false;
        }
        self.enrolled.insert(student.to_string());
        self.grades
            .entry(grade)
            .or_default()
            .insert(student.to_string());
        true
    }

    /// All grades that currently have at least one student, in ascending order.
    pub fn grades(&self) -> Vec<u32> {
        self.grades
            .iter()
            .filter(|(_, students)| !students.is_empty())
            .map(|(grade, _)| *grade)
            .collect()
    }

    // If `grade` returned a reference, `School` would be forced to keep a `Vec<String>`
    // internally to lend out. By returning an owned vector of owned `String`s instead,
    // the internal structure can be completely arbitrary. The tradeoff is that some data
    // must be copied each time `grade` is called.
    /// Students enrolled in `grade`, sorted alphabetically.
    pub fn grade(&self, grade: u32) -> Vec<String> {
        self.grades
            .get(&grade)
            .map(|students| students.iter().cloned().collect())
            .unwrap_or_default()
    }
}
