#[derive(Debug, PartialEq, Eq)]
pub enum Error {
    InvalidRowCount(usize),
    InvalidColumnCount(usize),
}

/// Each digit is a 3x3 glyph of pipes, underscores and spaces (the fourth
/// row of every entry is always blank and is ignored).
const DIGITS: [([&str; 3], char); 10] = [
    ([" _ ", "| |", "|_|"], '0'),
    ([("   "), "  |", "  |"], '1'),
    ([" _ ", " _|", "|_ "], '2'),
    ([" _ ", " _|", " _|"], '3'),
    (["   ", "|_|", "  |"], '4'),
    ([" _ ", "|_ ", " _|"], '5'),
    ([" _ ", "|_ ", "|_|"], '6'),
    ([" _ ", "  |", "  |"], '7'),
    ([" _ ", "|_|", "|_|"], '8'),
    ([" _ ", "|_|", " _|"], '9'),
];

const ROWS_PER_NUMBER: usize = 4;
const COLS_PER_DIGIT: usize = 3;

pub fn convert(input: &str) -> Result<String, Error> {
    let lines: Vec<&str> = input.lines().collect();

    if lines.len() % ROWS_PER_NUMBER != 0 {
        return Err(Error::InvalidRowCount(lines.len()));
    }
    for line in &lines {
        let width = line.chars().count();
        if width % COLS_PER_DIGIT != 0 {
            return Err(Error::InvalidColumnCount(width));
        }
    }

    let numbers: Vec<String> = lines
        .chunks(ROWS_PER_NUMBER)
        .map(|block| {
            let rows: Vec<Vec<char>> = block.iter().map(|l| l.chars().collect()).collect();
            let width = rows.iter().map(Vec::len).max().unwrap_or(0);
            (0..width / COLS_PER_DIGIT)
                .map(|col| decode_cell(&rows, col * COLS_PER_DIGIT))
                .collect()
        })
        .collect();

    Ok(numbers.join(","))
}

/// Decodes the 3x3 glyph starting at column `start` of a four-row block.
/// Returns '?' if the glyph is not a known digit.
fn decode_cell(rows: &[Vec<char>], start: usize) -> char {
    let glyph: Vec<String> = (0..3)
        .map(|r| {
            (start..start + COLS_PER_DIGIT)
                .map(|c| rows.get(r).and_then(|row| row.get(c)).copied().unwrap_or(' '))
                .collect()
        })
        .collect();

    DIGITS
        .iter()
        .find(|(pattern, _)| pattern.iter().zip(&glyph).all(|(p, g)| *p == g))
        .map(|(_, digit)| *digit)
        .unwrap_or('?')
}
