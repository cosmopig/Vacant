// This exercise is deprecated.
// Consider working on protein-translation instead.

use std::collections::HashMap;

pub struct CodonsInfo<'a> {
    codons: HashMap<&'a str, &'a str>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Error;

/// The concrete nucleotides a (possibly shorthand) nucleotide symbol stands for.
fn expand_base(c: char) -> Option<&'static [char]> {
    Some(match c {
        'A' => &['A'],
        'C' => &['C'],
        'G' => &['G'],
        'T' | 'U' => &['T'],
        'W' => &['A', 'T'],
        'S' => &['C', 'G'],
        'M' => &['A', 'C'],
        'K' => &['G', 'T'],
        'R' => &['A', 'G'],
        'Y' => &['C', 'T'],
        'B' => &['C', 'G', 'T'],
        'D' => &['A', 'G', 'T'],
        'H' => &['A', 'C', 'T'],
        'V' => &['A', 'C', 'G'],
        'N' => &['A', 'C', 'G', 'T'],
        _ => return None,
    })
}

/// All concrete (non-shorthand) codons that a codon string may stand for.
fn expand_codon(codon: &str) -> Option<Vec<String>> {
    let mut results: Vec<String> = vec![String::new()];
    for c in codon.chars() {
        let bases = expand_base(c.to_ascii_uppercase())?;
        results = results
            .iter()
            .flat_map(|prefix| {
                bases.iter().map(move |&b| {
                    let mut s = prefix.clone();
                    s.push(b);
                    s
                })
            })
            .collect();
    }
    Some(results)
}

impl<'a> CodonsInfo<'a> {
    pub fn name_for(&self, codon: &str) -> Result<&'a str, Error> {
        if codon.chars().count() != 3 {
            return Err(Error);
        }
        let expansions = expand_codon(codon).ok_or(Error)?;
        let mut name: Option<&'a str> = None;
        for concrete in &expansions {
            if let Some(&found) = self.codons.get(concrete.as_str()) {
                match name {
                    None => name = Some(found),
                    // Ambiguous shorthand that maps to different amino acids.
                    Some(existing) if existing != found => return Err(Error),
                    Some(_) => {}
                }
            }
        }
        name.ok_or(Error)
    }

    pub fn of_rna(&self, rna: &str) -> Result<Vec<&'a str>, Error> {
        if rna.len() % 3 != 0 || !rna.is_ascii() {
            return Err(Error);
        }
        let mut names = Vec::new();
        for i in (0..rna.len()).step_by(3) {
            let name = self.name_for(&rna[i..i + 3])?;
            if name == "stop codon" {
                break;
            }
            names.push(name);
        }
        Ok(names)
    }
}

pub fn parse<'a>(pairs: Vec<(&'a str, &'a str)>) -> CodonsInfo<'a> {
    CodonsInfo {
        codons: pairs.into_iter().collect(),
    }
}
