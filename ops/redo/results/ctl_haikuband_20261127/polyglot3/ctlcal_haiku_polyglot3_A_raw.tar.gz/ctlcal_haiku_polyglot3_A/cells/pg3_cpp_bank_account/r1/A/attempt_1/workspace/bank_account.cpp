#include "bank_account.h"

namespace Bankaccount {

void Bankaccount::open() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (is_open_) {
        throw std::runtime_error("account already open");
    }
    is_open_ = true;
    balance_ = 0;
}

void Bankaccount::close() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!is_open_) {
        throw std::runtime_error("account not open");
    }
    is_open_ = false;
    balance_ = 0;
}

std::int64_t Bankaccount::balance() const {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!is_open_) {
        throw std::runtime_error("account not open");
    }
    return balance_;
}

void Bankaccount::deposit(std::int64_t amount) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!is_open_) {
        throw std::runtime_error("account not open");
    }
    if (amount < 0) {
        throw std::runtime_error("deposit amount must not be negative");
    }
    balance_ += amount;
}

void Bankaccount::withdraw(std::int64_t amount) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!is_open_) {
        throw std::runtime_error("account not open");
    }
    if (amount < 0) {
        throw std::runtime_error("withdrawal amount must not be negative");
    }
    if (amount > balance_) {
        throw std::runtime_error("insufficient funds");
    }
    balance_ -= amount;
}

}  // namespace Bankaccount
