# Contract

Implement the exercise in `allergies.h` and `allergies.cpp` (both exist as stubs; keep the names the tests use).
C++17, standard library only.

- The tests for this task are in `allergies_test.cpp` (Catch2, with `test/catch.hpp` and `test/tests-main.cpp`). The tests are correct;
  don't change them or anything under `test/`. Build and run them with:

      g++ -std=c++17 -Wall -Wextra -Wpedantic -Werror -DEXERCISM_RUN_ALL_TESTS -o polybin allergies_test.cpp allergies.cpp test/tests-main.cpp && ./polybin

  (the same suite is also run by `python3 -m unittest solution_test`, one test method per Catch test case).
- Warnings are errors in that build.
