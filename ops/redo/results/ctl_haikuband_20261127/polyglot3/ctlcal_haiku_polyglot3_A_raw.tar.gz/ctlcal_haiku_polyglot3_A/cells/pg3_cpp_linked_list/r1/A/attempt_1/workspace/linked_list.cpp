#include "linked_list.h"

// List is a class template, so its implementation lives in linked_list.h.
// This translation unit only exists to satisfy the build command in contract.md.
