#if !defined(PHONE_NUMBER_H)
#define PHONE_NUMBER_H

#include <string>

namespace phone_number {

class phone_number {
public:
    // Cleans up a user-entered NANP phone number. Throws std::domain_error
    // if the input cannot be a valid NANP number.
    explicit phone_number(const std::string& raw);

    // Returns the ten-digit NANP number (area code + subscriber number).
    std::string number() const;

private:
    std::string number_;
};

}  // namespace phone_number

#endif // PHONE_NUMBER_H
