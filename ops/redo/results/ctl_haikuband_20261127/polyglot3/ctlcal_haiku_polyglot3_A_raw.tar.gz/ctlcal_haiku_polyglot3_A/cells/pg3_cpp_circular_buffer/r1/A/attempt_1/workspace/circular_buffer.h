#if !defined(CIRCULAR_BUFFER_H)
#define CIRCULAR_BUFFER_H

#include <cstddef>
#include <optional>
#include <stdexcept>
#include <utility>
#include <vector>

namespace circular_buffer {

template <typename T>
class circular_buffer {
public:
    explicit circular_buffer(std::size_t capacity)
        : buffer_(capacity) {}

    // Removes and returns the oldest element. Throws std::domain_error if empty.
    T read() {
        if (count_ == 0) {
            throw std::domain_error("circular buffer is empty");
        }
        T value = std::move(*buffer_[head_]);
        buffer_[head_].reset();
        head_ = next(head_);
        --count_;
        return value;
    }

    // Appends an element. Throws std::domain_error if the buffer is full.
    void write(T value) {
        if (full()) {
            throw std::domain_error("circular buffer is full");
        }
        buffer_[tail_] = std::move(value);
        tail_ = next(tail_);
        ++count_;
    }

    // Appends an element, overwriting the oldest one if the buffer is full.
    void overwrite(T value) {
        if (full()) {
            buffer_[tail_] = std::move(value);
            tail_ = next(tail_);
            head_ = tail_;  // oldest element was replaced; the new oldest is next slot
            return;
        }
        write(std::move(value));
    }

    // Discards all contents. Does nothing on an empty buffer.
    void clear() noexcept {
        for (auto& slot : buffer_) {
            slot.reset();
        }
        head_ = 0;
        tail_ = 0;
        count_ = 0;
    }

private:
    bool full() const noexcept {
        return count_ == buffer_.size();
    }

    std::size_t next(std::size_t index) const noexcept {
        return buffer_.empty() ? 0 : (index + 1) % buffer_.size();
    }

    std::vector<std::optional<T>> buffer_;
    std::size_t head_ = 0;   // index of oldest element
    std::size_t tail_ = 0;   // index where next element goes
    std::size_t count_ = 0;  // number of stored elements
};

}  // namespace circular_buffer

#endif // CIRCULAR_BUFFER_H
