#pragma once

#include <array>
#include <string>

namespace yacht {

// Scores five dice (each 1-6, any order) in the given category.
// Returns 0 when the dice do not satisfy the category (or the category is unknown).
int score(const std::array<int, 5>& dice, const std::string& category);

}  // namespace yacht
