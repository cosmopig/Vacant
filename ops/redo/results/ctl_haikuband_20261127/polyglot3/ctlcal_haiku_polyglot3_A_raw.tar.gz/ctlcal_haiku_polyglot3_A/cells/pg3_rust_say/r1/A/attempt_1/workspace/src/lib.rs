const ONES: [&str; 20] = [
    "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten",
    "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen",
    "nineteen",
];

const TENS: [&str; 10] = [
    "", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety",
];

// Scale words for each group of three digits, least significant first.
// Index 6 (quintillion) is needed to cover the full u64 range.
const SCALES: [&str; 7] = [
    "",
    "thousand",
    "million",
    "billion",
    "trillion",
    "quadrillion",
    "quintillion",
];

/// Spell out 0..=99.
fn below_100(n: u64) -> String {
    if n < 20 {
        ONES[n as usize].to_string()
    } else {
        let tens = TENS[(n / 10) as usize];
        match n % 10 {
            0 => tens.to_string(),
            ones => format!("{}-{}", tens, ONES[ones as usize]),
        }
    }
}

/// Spell out 0..=999 (no scale word).
fn below_1000(n: u64) -> String {
    let hundreds = n / 100;
    let rest = n % 100;
    let mut parts: Vec<String> = Vec::new();
    if hundreds > 0 {
        parts.push(format!("{} hundred", ONES[hundreds as usize]));
    }
    if rest > 0 {
        parts.push(below_100(rest));
    }
    parts.join(" ")
}

/// Spell out any u64 in English words, e.g. 1_234 -> "one thousand two hundred thirty-four".
pub fn encode(n: u64) -> String {
    if n == 0 {
        return ONES[0].to_string();
    }

    // Split into groups of three digits, least significant first.
    let mut groups: Vec<u64> = Vec::new();
    let mut rest = n;
    while rest > 0 {
        groups.push(rest % 1000);
        rest /= 1000;
    }

    // Walk from most significant group down, skipping empty groups.
    let mut words: Vec<String> = Vec::new();
    for (idx, &group) in groups.iter().enumerate().rev() {
        if group == 0 {
            continue;
        }
        let mut text = below_1000(group);
        if !SCALES[idx].is_empty() {
            text.push(' ');
            text.push_str(SCALES[idx]);
        }
        words.push(text);
    }

    words.join(" ")
}
