#include <bits/stdc++.h>
using namespace std;

// Structure of an optimal solution: the three bounding boxes are pairwise
// separable by a line.  Either one colour is cut off by a line from the other
// two, which are then split by a perpendicular line ("H" pattern), or all three
// are ordered by a chain of two parallel lines ("chain" pattern).
// Cuts are only allowed between distinct coordinates (strict separation).

struct P { long long x, y; int c; };

struct BIT {
    int n = 0, LOG = 1;
    vector<int> t;
    void init(int N) {
        n = N; t.assign(N + 1, 0); LOG = 1;
        while ((1 << LOG) <= N) LOG++;
    }
    void add(int i, int v) { for (; i <= n; i += i & -i) t[i] += v; }
    // 1-based index of the k-th smallest element (k >= 1, k <= total)
    int kth(int k) const {
        int pos = 0;
        for (int pw = 1 << LOG; pw; pw >>= 1) {
            if (pos + pw <= n && t[pos + pw] < k) { pos += pw; k -= t[pos]; }
        }
        return pos + 1;
    }
};

// Groups of points with equal x (after sorting by x).
struct Groups {
    vector<vector<P>> g;      // points per group, sorted by x
    vector<array<int, 4>> pre; // pre[k][c] = count of colour c among groups [0,k)
};

static Groups makeGroups(vector<P> pts) {
    sort(pts.begin(), pts.end(), [](const P &a, const P &b) { return a.x < b.x; });
    Groups G;
    for (size_t i = 0; i < pts.size();) {
        size_t j = i;
        vector<P> grp;
        while (j < pts.size() && pts[j].x == pts[i].x) grp.push_back(pts[j++]);
        G.g.push_back(grp);
        i = j;
    }
    G.pre.assign(G.g.size() + 1, array<int, 4>{0, 0, 0, 0});
    for (size_t k = 0; k < G.g.size(); k++) {
        G.pre[k + 1] = G.pre[k];
        for (auto &p : G.g[k]) G.pre[k + 1][p.c]++;
    }
    return G;
}

// H pattern: vertical cut, colour A entirely left; colours B (upper) and C
// (lower) entirely right, separated by a horizontal cut.  pts are already
// transformed so that this is the orientation being tested.
static long long hPattern(const vector<P> &pts, int A, int B, int C) {
    vector<long long> ys;
    for (auto &p : pts) ys.push_back(p.y);
    sort(ys.begin(), ys.end());
    ys.erase(unique(ys.begin(), ys.end()), ys.end());
    vector<P> q = pts;
    for (auto &p : q) p.y = lower_bound(ys.begin(), ys.end(), p.y) - ys.begin() + 1;

    Groups G = makeGroups(q);
    int NG = G.g.size();
    BIT bB, bC;
    bB.init(ys.size());
    bC.init(ys.size());
    int cntB = 0, cntC = 0;
    long long M = 0, best = 0;
    // cut after group g: left = groups [0..g], right = groups [g+1..NG-1]
    for (int g = NG - 2; g >= 0; g--) {
        for (auto &p : G.g[g + 1]) {
            if (p.c == B) { bB.add((int)p.y, 1); cntB++; }
            else if (p.c == C) { bC.add((int)p.y, 1); cntC++; }
        }
        // feasible(m): m-th smallest C y < m-th largest B y (strict)
        while (M + 1 <= min(cntB, cntC)) {
            long long m = M + 1;
            int cs = bC.kth((int)m);
            int bl = bB.kth((int)(cntB - m + 1));
            if (cs < bl) M = m; else break;
        }
        long long leftA = G.pre[g + 1][A];
        best = max(best, min(leftA, M));
    }
    return best;
}

// Chain pattern over groups sorted by x: colour X, then Y, then Z.
static bool chainOK(const Groups &G, int X, int Y, int Z, long long m) {
    int NG = G.g.size();
    if (NG < 3) return false;
    int i = -1;
    for (int k = 0; k < NG; k++) if (G.pre[k + 1][X] >= m) { i = k; break; }
    if (i < 0 || i + 2 > NG - 1) return false;
    for (int j = i + 1; j <= NG - 2; j++) {
        if (G.pre[j + 1][Y] - G.pre[i + 1][Y] >= m) {
            return G.pre[NG][Z] - G.pre[j + 1][Z] >= m;
        }
    }
    return false;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    vector<P> pts(n);
    for (auto &p : pts) cin >> p.x >> p.y >> p.c;

    long long best = 0;
    // H patterns over the four transforms that map every orientation onto
    // "A on the left, horizontal cut inside the right part".
    for (int t = 0; t < 4; t++) {
        vector<P> q = pts;
        for (auto &p : q) {
            long long x = p.x, y = p.y;
            long long nx, ny;
            switch (t) {
                case 0: nx = x;  ny = y;  break;
                case 1: nx = -x; ny = y;  break;
                case 2: nx = y;  ny = x;  break;
                default: nx = -y; ny = x; break;
            }
            p.x = nx; p.y = ny;
        }
        for (int A = 1; A <= 3; A++) {
            for (int B = 1; B <= 3; B++) for (int C = 1; C <= 3; C++) {
                if (A == B || B == C || A == C) continue;
                best = max(best, hPattern(q, A, B, C));
            }
        }
    }

    // Chain patterns: along x (t=0) and along y (t=2, swap).
    long long hi = n / 3;
    for (int t = 0; t < 4; t += 2) {
        vector<P> q = pts;
        if (t == 2) for (auto &p : q) swap(p.x, p.y);
        Groups G = makeGroups(q);
        int perm[3] = {1, 2, 3};
        do {
            long long lo = 0, h = hi;
            while (lo < h) {
                long long mid = (lo + h + 1) / 2;
                if (chainOK(G, perm[0], perm[1], perm[2], mid)) lo = mid; else h = mid - 1;
            }
            best = max(best, lo);
        } while (next_permutation(perm, perm + 3));
    }

    cout << 3 * best << "\n";
    return 0;
}
