// Desert: count windows [L,R] of edges whose graph is a cactus per component.
//
// Validity is monotone (sub-windows of a valid window are valid), so R(L) is
// nondecreasing. We compute R(L) with divide and conquer over "add edge" /
// "rollback" operations:
//   * DSU with rollback tells whether an edge joins two components.
//   * A link-cut tree maintains a spanning forest T of the current window.
//     Each tree edge carries a mark = "lies on some cycle". A non-tree edge
//     (u,v) closes a cycle with the T-path; the window stays a cactus iff that
//     path contains no marked edge, and then the path edges become marked.
//     Marks are path-assigned (lazily), and rollback reverts them.
#include <bits/stdc++.h>
using namespace std;

static int N, M;
static vector<int> EU, EV;

// ---------- link-cut tree ----------
static vector<array<int, 2>> ch;
static vector<int> fa;
static vector<char> rv, mk, isE;
static vector<signed char> tg;
static vector<int> sm, ec;

static inline bool isroot(int x) {
    int f = fa[x];
    return f == 0 || (ch[f][0] != x && ch[f][1] != x);
}
static inline void pushup(int x) {
    int l = ch[x][0], r = ch[x][1];
    sm[x] = sm[l] + sm[r] + mk[x];
    ec[x] = ec[l] + ec[r] + isE[x];
}
static inline void applyRev(int x) {
    if (!x) return;
    swap(ch[x][0], ch[x][1]);
    rv[x] ^= 1;
}
static inline void applyAssign(int x, signed char a) {
    if (!x) return;
    mk[x] = isE[x] ? (char)a : 0;
    sm[x] = (int)a * ec[x];
    tg[x] = a;
}
static inline void pushdown(int x) {
    if (rv[x]) {
        applyRev(ch[x][0]);
        applyRev(ch[x][1]);
        rv[x] = 0;
    }
    if (tg[x] != -1) {
        applyAssign(ch[x][0], tg[x]);
        applyAssign(ch[x][1], tg[x]);
        tg[x] = -1;
    }
}
static inline void rotate_(int x) {
    int y = fa[x], z = fa[y];
    int k = (ch[y][1] == x);
    if (!isroot(y)) ch[z][ch[z][1] == y] = x;
    fa[x] = z;
    ch[y][k] = ch[x][k ^ 1];
    if (ch[x][k ^ 1]) fa[ch[x][k ^ 1]] = y;
    ch[x][k ^ 1] = y;
    fa[y] = x;
    pushup(y);
    pushup(x);
}
static vector<int> stk;
static void splay(int x) {
    stk.clear();
    int y = x;
    stk.push_back(y);
    while (!isroot(y)) {
        y = fa[y];
        stk.push_back(y);
    }
    while (!stk.empty()) {
        pushdown(stk.back());
        stk.pop_back();
    }
    while (!isroot(x)) {
        int y2 = fa[x], z = fa[y2];
        if (!isroot(y2)) {
            rotate_(((ch[y2][1] == x) ^ (ch[z][1] == y2)) ? x : y2);
        }
        rotate_(x);
    }
}
static void access(int x) {
    for (int y = 0; x; y = x, x = fa[x]) {
        splay(x);
        ch[x][1] = y;
        pushup(x);
    }
}
static void makeroot(int x) {
    access(x);
    splay(x);
    applyRev(x);
}
// x and y must be adjacent in the represented forest.
static void cutEdge(int x, int y) {
    makeroot(x);
    access(y);
    splay(y);
    ch[y][0] = 0;
    fa[x] = 0;
    pushup(y);
}

// ---------- DSU with rollback ----------
static vector<int> par, dsz;

static inline int findr(int x) {
    while (par[x] != x) x = par[x];
    return x;
}

// ---------- operation stack ----------
struct Op {
    int type;  // 0 = tree edge, 1 = non-tree (marked path)
    int x, u, v;
    int child, root;  // for tree-edge DSU undo
};
static vector<Op> ops;

static bool addEdge(int x) {
    int u = EU[x], v = EV[x];
    if (u == v) return true;  // a self-loop never interacts with other edges
    int ru = findr(u), rvv = findr(v);
    int e = N + x;
    if (ru != rvv) {
        if (dsz[ru] < dsz[rvv]) swap(ru, rvv);
        // attach rvv under ru
        par[rvv] = ru;
        dsz[ru] += dsz[rvv];
        makeroot(u);
        fa[u] = e;
        makeroot(e);
        fa[e] = v;
        ops.push_back({0, x, u, v, rvv, ru});
        return true;
    }
    makeroot(u);
    access(v);
    splay(v);
    if (sm[v] > 0) return false;
    applyAssign(v, 1);
    ops.push_back({1, x, u, v, 0, 0});
    return true;
}

static void rollback(size_t sz0) {
    while (ops.size() > sz0) {
        Op o = ops.back();
        ops.pop_back();
        if (o.type == 0) {
            int e = N + o.x;
            cutEdge(e, o.v);
            cutEdge(o.u, e);
            par[o.child] = o.child;
            dsz[o.root] -= dsz[o.child];
        } else {
            makeroot(o.u);
            access(o.v);
            splay(o.v);
            applyAssign(o.v, 0);
        }
    }
}

static long long ans = 0;

// Precondition: the structure holds edges [r+1 .. A] (empty if A <= r),
// and R(L) is in [A, B] for every L in [l, r].
static void solve(int l, int r, int A, int B) {
    if (l > r) return;
    int mid = (l + r) / 2;
    size_t sz0 = ops.size();

    // Window for L = mid: edges [mid .. Ae] where Ae = max(A, mid-1).
    int Ae = max(A, mid - 1);
    for (int x = mid; x <= min(r, Ae); x++) addEdge(x);
    int X = Ae;
    for (int R = Ae + 1; R <= B; R++) {
        if (addEdge(R)) X = R;
        else break;
    }
    rollback(sz0);
    ans += (long long)(X - mid + 1);

    // Left half: L in [l, mid-1], R in [A, X]; needs edges [mid .. A].
    for (int x = mid; x <= min(r, A); x++) addEdge(x);
    solve(l, mid - 1, A, X);
    rollback(sz0);

    // Right half: L in [mid+1, r], R in [X, B]; needs edges [r+1 .. X].
    for (int x = max(A, r) + 1; x <= X; x++) addEdge(x);
    solve(mid + 1, r, X, B);
    rollback(sz0);
}

static int readInt() {
    int c = getchar_unlocked();
    while (c != '-' && (c < '0' || c > '9')) {
        if (c == EOF) return 0;
        c = getchar_unlocked();
    }
    int s = 1;
    if (c == '-') {
        s = -1;
        c = getchar_unlocked();
    }
    int x = 0;
    while (c >= '0' && c <= '9') {
        x = x * 10 + (c - '0');
        c = getchar_unlocked();
    }
    return x * s;
}

int main() {
    N = readInt();
    M = readInt();
    EU.assign(M + 1, 0);
    EV.assign(M + 1, 0);
    for (int i = 1; i <= M; i++) {
        EU[i] = readInt();
        EV[i] = readInt();
    }
    if (M == 0) {
        printf("0\n");
        return 0;
    }
    int K = N + M + 1;
    ch.assign(K, {0, 0});
    fa.assign(K, 0);
    rv.assign(K, 0);
    mk.assign(K, 0);
    isE.assign(K, 0);
    tg.assign(K, -1);
    sm.assign(K, 0);
    ec.assign(K, 0);
    for (int i = 1; i <= M; i++) isE[N + i] = 1, ec[N + i] = 1;
    par.resize(N + 1);
    dsz.assign(N + 1, 1);
    for (int i = 0; i <= N; i++) par[i] = i;

    solve(1, M, 0, M);
    printf("%lld\n", ans);
    return 0;
}
