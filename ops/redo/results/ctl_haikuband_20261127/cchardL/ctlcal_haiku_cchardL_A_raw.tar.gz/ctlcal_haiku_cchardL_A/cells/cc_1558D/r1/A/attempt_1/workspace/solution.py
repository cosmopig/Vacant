import sys
import random


def main():
    data = sys.stdin.buffer.read().split()
    MOD = 998244353
    t = int(data[0])
    # First pass: find the largest n to size factorial tables.
    idx = 1
    max_n = 2
    for _ in range(t):
        n = int(data[idx]); m = int(data[idx + 1])
        if n > max_n:
            max_n = n
        idx += 2 + 2 * m
    LIM = 2 * max_n + 2
    fact = [1] * (LIM + 1)
    for i in range(1, LIM + 1):
        fact[i] = fact[i - 1] * i % MOD
    inv = [1] * (LIM + 1)
    inv[LIM] = pow(fact[LIM], MOD - 2, MOD)
    for i in range(LIM, 0, -1):
        inv[i - 1] = inv[i] * i % MOD

    def comb(a, b):
        if b < 0 or b > a or a < 0:
            return 0
        return fact[a] * inv[b] % MOD * inv[a - b] % MOD

    # Implicit treap whose nodes are chunks of consecutive indices [first..last],
    # stored in increasing order inside the chunk.
    L = [0]          # left child
    R = [0]          # right child
    PR = [0]         # priority
    SZ = [0]         # total number of elements in subtree
    LN = [0]         # chunk length
    FI = [0]         # first index
    LA = [0]         # last index

    def new_node(first, last):
        L.append(0); R.append(0); PR.append(random.random())
        SZ.append(last - first + 1); LN.append(last - first + 1)
        FI.append(first); LA.append(last)
        return len(L) - 1

    def upd(v):
        SZ[v] = SZ[L[v]] + LN[v] + SZ[R[v]]

    def merge(a, b):
        if a == 0:
            return b
        if b == 0:
            return a
        if PR[a] > PR[b]:
            R[a] = merge(R[a], b)
            upd(a)
            return a
        L[b] = merge(a, L[b])
        upd(b)
        return b

    def split(v, k):
        # returns (A, B): A holds the first k elements of the subtree rooted at v
        if v == 0:
            return 0, 0
        ls = SZ[L[v]]
        if k <= ls:
            a, b = split(L[v], k)
            L[v] = b
            upd(v)
            return a, v
        if k >= ls + LN[v]:
            a, b = split(R[v], k - ls - LN[v])
            R[v] = a
            upd(v)
            return v, b
        # split inside this chunk at offset o (1 <= o < LN[v])
        o = k - ls
        lt = L[v]
        rt = R[v]
        first = FI[v]
        last = LA[v]
        LA[v] = first + o - 1
        LN[v] = o
        L[v] = 0
        R[v] = 0
        upd(v)
        r = new_node(first + o, last)
        return merge(lt, v), merge(r, rt)

    out = []
    idx = 1
    for _ in range(t):
        n = int(data[idx]); m = int(data[idx + 1])
        idx += 2
        root = 0
        pos = 1
        for _k in range(m):
            x = int(data[idx]); y = int(data[idx + 1])
            idx += 2
            if pos <= x - 1:
                root = merge(root, new_node(pos, x - 1))
            p = y - 1
            total = SZ[root]
            if p < 0:
                p = 0
            if p > total:
                p = total
            a, b = split(root, p)
            root = merge(merge(a, new_node(x, x)), b)
            pos = x + 1
        if pos <= n:
            root = merge(root, new_node(pos, n))

        # Walk the chunk sequence in order and count descents at chunk boundaries.
        seq = []
        stack = []
        cur = root
        while stack or cur:
            while cur:
                stack.append(cur)
                cur = L[cur]
            cur = stack.pop()
            seq.append(cur)
            cur = R[cur]
        d = 0
        for j in range(1, len(seq)):
            if LA[seq[j - 1]] > FI[seq[j]]:
                d += 1
        out.append(comb(2 * n - 1 - d, n))

        # Reset node storage between tests to keep memory bounded.
        del L[1:]; del R[1:]; del PR[1:]; del SZ[1:]
        del LN[1:]; del FI[1:]; del LA[1:]

    sys.stdout.write("\n".join(map(str, out)) + "\n")


if __name__ == "__main__":
    main()
