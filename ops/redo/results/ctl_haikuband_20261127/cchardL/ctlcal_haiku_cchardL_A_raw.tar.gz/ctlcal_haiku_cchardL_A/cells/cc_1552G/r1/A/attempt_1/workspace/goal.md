# A Serious Referee

Time limit per test: 1 seconds. Memory limit: 488 MB.

Write a program in Python 3 or C++17 that reads from standard input and writes to standard output.

Andrea has come up with what he believes to be a novel sorting algorithm for arrays of length n. The algorithm works as follows.

Initially there is an array of n integers a_1,  a_2,  ...,  a_n. Then, k steps are executed.

For each 1≤ i≤ k, during the i-th step the subsequence of the array a with indexes j_{i,1}< j_{i,2}< ...< j_{i, q_i} is sorted, without changing the values with the remaining indexes. So, the subsequence a_{j_{i,1}},  a_{j_{i,2}},  ...,  a_{j_{i,q_i}} is sorted and all other elements of a are left untouched.

Andrea, being eager to share his discovery with the academic community, sent a short paper describing his algorithm to the journal "Annals of Sorting Algorithms" and you are the referee of the paper (that is, the person who must judge the correctness of the paper). You must decide whether Andrea's algorithm is correct, that is, if it sorts any array a of n integers.

Input

The first line contains two integers n and k (1≤ n≤ 40, 0≤ k≤ 10) — the length of the arrays handled by Andrea's algorithm and the number of steps of Andrea's algorithm.

Then k lines follow, each describing the subsequence considered in a step of Andrea's algorithm.

The i-th of these lines contains the integer q_i (1≤ q_i≤ n) followed by q_i integers j_{i,1},\,j_{i,2}, ...,  j_{i,q_i} (1≤ j_{i,1}<j_{i,2}<⋅⋅⋅<j_{i,q_i}≤ n) — the length of the subsequence considered in the i-th step and the indexes of the subsequence.

Output

If Andrea's algorithm is correct print ACCEPTED, otherwise print REJECTED.

Examples

Input


4 3
3 1 2 3
3 2 3 4
2 1 2


Output


ACCEPTED


Input


4 3
3 1 2 3
3 2 3 4
3 1 3 4


Output


REJECTED


Input


3 4
1 1
1 2
1 3
2 1 3


Output


REJECTED


Input


5 2
3 2 3 4
5 1 2 3 4 5


Output


ACCEPTED

Note

Explanation of the first sample: The algorithm consists of 3 steps. The first one sorts the subsequence [a_1, a_2, a_3], the second one sorts the subsequence [a_2, a_3, a_4], the third one sorts the subsequence [a_1,a_2]. For example, if initially a=[6, 5, 6, 3], the algorithm transforms the array as follows (the subsequence that gets sorted is highlighted in red) $$$ [{\color{red}6},{\color{red}5},{\color{red}6},3] → [5, {\color{red}6}, {\color{red}6}, {\color{red}3}] → [{\color{red}5}, {\color{red}3}, 6, 6] → [3, 5, 6, 6]  . One can prove that, for any initial array a, at the end of the algorithm the array a$$$ will be sorted.

Explanation of the second sample: The algorithm consists of 3 steps. The first one sorts the subsequence [a_1, a_2, a_3], the second one sorts the subsequence [a_2, a_3, a_4], the third one sorts the subsequence [a_1,a_3,a_4]. For example, if initially a=[6, 5, 6, 3], the algorithm transforms the array as follows (the subsequence that gets sorted is highlighted in red) $$$ [{\color{red}6},{\color{red}5},{\color{red}6},3] → [5, {\color{red}6}, {\color{red}6}, {\color{red}3}] → [{\color{red}5}, 3, {\color{red}6}, {\color{red}6}] → [5, 3, 6, 6]  . Notice that a=[6,5,6,3]$$$ is an example of an array that is not sorted by the algorithm.

Explanation of the third sample: The algorithm consists of 4 steps. The first 3 steps do nothing because they sort subsequences of length 1, whereas the fourth step sorts the subsequence [a_1,a_3]. For example, if initially a=[5,6,4], the algorithm transforms the array as follows (the subsequence that gets sorted is highlighted in red) $$$ [{\color{red}5},6,4] → [5,{\color{red}6},4] → [5,{\color{red}6},4] → [{\color{red}5},6,{\color{red}4}]→ [4,6,5]  . Notice that a=[5,6,4]$$$ is an example of an array that is not sorted by the algorithm.

Explanation of the fourth sample: The algorithm consists of 2 steps. The first step sorts the subsequences [a_2,a_3,a_4], the second step sorts the whole array [a_1,a_2,a_3,a_4,a_5]. For example, if initially a=[9,8,1,1,1], the algorithm transforms the array as follows (the subsequence that gets sorted is highlighted in red) $$$ [9,{\color{red}8},{\color{red}1},{\color{red}1},1] → [{\color{red}9},{\color{red}1},{\color{red}1},{\color{red}8},{\color{red}1}] → [1,1,1,8,9]  . Since in the last step the whole array is sorted, it is clear that, for any initial array a, at the end of the algorithm the array a$$$ will be sorted.
