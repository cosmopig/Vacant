#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

// Value of a chosen set B (|B| = m) is (m-1)*S - 2*C, where S = sum of chosen a,
// and C = sum over unordered pairs {p<q} of B of min(a[p..q]).
//
// Recursively split on the global minimum g of a segment [l,r] (Cartesian tree):
//   - g not chosen: pairs crossing g cost a_g each -> a_g * kL * kR
//   - g chosen:     pairs involving g or crossing g cost a_g each
//                   -> a_g * (kL + kR + kL*kR), plus (m-1)*a_g from S.
// dp[k] = best partial value of choosing k elements inside the segment.

static const ll NEG = LLONG_MIN / 4;
int n, m;
vector<ll> a;

vector<ll> solve(int l, int r) {
    if (l > r) return vector<ll>(1, 0);
    int g = l;
    for (int i = l + 1; i <= r; i++)
        if (a[i] < a[g]) g = i;
    vector<ll> L = solve(l, g - 1);
    vector<ll> R = solve(g + 1, r);
    int sL = (int)L.size() - 1, sR = (int)R.size() - 1;
    int cap = min(m, sL + sR + 1);
    vector<ll> res(cap + 1, NEG);
    ll ag = a[g];
    for (int kL = 0; kL <= sL; kL++) {
        if (L[kL] <= NEG) continue;
        for (int kR = 0; kR <= sR; kR++) {
            if (R[kR] <= NEG) continue;
            ll base = L[kL] + R[kR];
            ll cross = (ll)kL * kR;
            int k = kL + kR;
            if (k <= cap) {
                ll v = base - 2 * ag * cross;
                if (v > res[k]) res[k] = v;
            }
            if (k + 1 <= cap) {
                ll v = base + (ll)(m - 1) * ag - 2 * ag * (k + cross);
                if (v > res[k + 1]) res[k + 1] = v;
            }
        }
    }
    return res;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    if (!(cin >> n >> m)) return 0;
    a.resize(n);
    for (int i = 0; i < n; i++) cin >> a[i];
    if (m <= 0 || m > n) {
        cout << 0 << "\n";
        return 0;
    }
    vector<ll> res = solve(0, n - 1);
    ll ans = (m < (int)res.size()) ? res[m] : 0;
    if (ans <= NEG) ans = 0;
    cout << ans << "\n";
    return 0;
}
