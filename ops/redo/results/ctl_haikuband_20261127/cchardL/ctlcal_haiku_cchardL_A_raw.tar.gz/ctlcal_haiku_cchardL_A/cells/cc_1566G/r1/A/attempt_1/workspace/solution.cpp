#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;

typedef long long ll;
typedef tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update> OST;

int n, m, q;
int M;                       // universe size (all edges that ever exist)
vector<int> eu, ev, ew;      // per universe id
vector<int> pos_of, id_at;   // weight-sorted positions
vector<int> bit;             // Fenwick over positions (1-indexed)
int active_cnt = 0;
vector<OST> A;               // per vertex: positions of active incident edges
vector<ll> cur3;             // current sum of 3 lightest incident weights, -1 if none
set<pair<ll, int>> gs;       // (sum3, vertex) for vertices with degree >= 3
map<pair<int, int>, int> cur_id;  // pair -> active universe id

void bit_add(int i, int d) {
    for (i++; i <= M; i += i & -i) bit[i] += d;
}
int bit_sum(int i) {  // count of active positions in [0..i]
    int s = 0;
    for (i++; i > 0; i -= i & -i) s += bit[i];
    return s;
}
int bit_kth(int k) {  // position (0-indexed) of k-th active (k>=1)
    int idx = 0;
    int lg = 1;
    while ((lg << 1) <= M) lg <<= 1;
    for (int step = lg; step > 0; step >>= 1) {
        if (idx + step <= M && bit[idx + step] < k) {
            idx += step;
            k -= bit[idx];
        }
    }
    return idx;  // idx+1 is 1-indexed => position idx
}

void refresh(int v) {
    if (cur3[v] >= 0) gs.erase({cur3[v], v});
    cur3[v] = -1;
    if (A[v].size() >= 3) {
        ll s = 0;
        int k = 0;
        for (auto it = A[v].begin(); k < 3; ++it, ++k) s += ew[id_at[*it]];
        cur3[v] = s;
        gs.insert({s, v});
    }
}

void activate(int id) {
    int p = pos_of[id];
    bit_add(p, 1);
    active_cnt++;
    A[eu[id]].insert(p);
    A[ev[id]].insert(p);
    refresh(eu[id]);
    refresh(ev[id]);
}

void deactivate(int id) {
    int p = pos_of[id];
    bit_add(p, -1);
    active_cnt--;
    A[eu[id]].erase(p);
    A[ev[id]].erase(p);
    refresh(eu[id]);
    refresh(ev[id]);
}

ll compute_answer() {
    const ll INF = LLONG_MAX / 4;
    ll best = INF;
    // (B): three edges at one vertex
    if (!gs.empty()) best = min(best, gs.begin()->first);

    // (A): two disjoint edges; one of them is among the 5 lightest active edges.
    int t = min(5, active_cnt);
    vector<int> R;
    for (int k = 1; k <= t; k++) R.push_back(bit_kth(k));
    for (int p : R) {
        int g = id_at[p];
        int u = eu[g], v = ev[g];
        auto F = [&](int x) -> int {  // number of active edges avoiding u and v with position <= x
            int tot = bit_sum(x);
            int bad = (int)A[u].order_of_key(x + 1) + (int)A[v].order_of_key(x + 1) - (p <= x ? 1 : 0);
            return tot - bad;
        };
        if (F(M - 1) < 1) continue;
        int lo = 0, hi = M - 1;
        while (lo < hi) {
            int mid = (lo + hi) / 2;
            if (F(mid) >= 1) hi = mid;
            else lo = mid + 1;
        }
        int partner = id_at[lo];
        best = min(best, (ll)ew[g] + ew[partner]);
    }
    return best;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cin >> n >> m;
    vector<int> init_u(m), init_v(m), init_w(m);
    for (int i = 0; i < m; i++) {
        cin >> init_u[i] >> init_v[i] >> init_w[i];
    }
    cin >> q;
    vector<int> qt(q), qu(q), qv(q), qw(q);
    for (int i = 0; i < q; i++) {
        cin >> qt[i] >> qu[i] >> qv[i];
        if (qt[i] == 1) cin >> qw[i];
    }

    // Build universe: initial edges, then every added edge occurrence.
    vector<int> q_add_id(q, -1);
    for (int i = 0; i < m; i++) {
        eu.push_back(init_u[i]);
        ev.push_back(init_v[i]);
        ew.push_back(init_w[i]);
    }
    for (int i = 0; i < q; i++) {
        if (qt[i] == 1) {
            q_add_id[i] = (int)eu.size();
            eu.push_back(qu[i]);
            ev.push_back(qv[i]);
            ew.push_back(qw[i]);
        }
    }
    M = (int)eu.size();
    vector<int> order(M);
    iota(order.begin(), order.end(), 0);
    sort(order.begin(), order.end(), [&](int a, int b) {
        if (ew[a] != ew[b]) return ew[a] < ew[b];
        return a < b;
    });
    pos_of.assign(M, 0);
    id_at.assign(M, 0);
    for (int p = 0; p < M; p++) {
        pos_of[order[p]] = p;
        id_at[p] = order[p];
    }
    bit.assign(M + 1, 0);
    A.assign(n + 1, OST());
    cur3.assign(n + 1, -1);

    for (int i = 0; i < m; i++) {
        int a = min(init_u[i], init_v[i]), b = max(init_u[i], init_v[i]);
        cur_id[{a, b}] = i;
        activate(i);
    }

    string out;
    out.reserve((size_t)(q + 1) * 12);
    out += to_string(compute_answer());
    out += '\n';
    for (int i = 0; i < q; i++) {
        int a = min(qu[i], qv[i]), b = max(qu[i], qv[i]);
        if (qt[i] == 0) {
            auto it = cur_id.find({a, b});
            int id = it->second;
            cur_id.erase(it);
            deactivate(id);
        } else {
            int id = q_add_id[i];
            cur_id[{a, b}] = id;
            activate(id);
        }
        out += to_string(compute_answer());
        out += '\n';
    }
    cout << out;
    return 0;
}
