import sys

MOD = 10 ** 9 + 7
K = 6  # number of power sums compared (k = 1..K)


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    q = int(data[1])
    a = [int(x) % MOD for x in data[2:2 + n]]
    pos = 2 + n
    qs_l = [0] * q
    qs_r = [0] * q
    qs_d = [0] * q
    for i in range(q):
        qs_l[i] = int(data[pos]) - 1
        qs_r[i] = int(data[pos + 1]) - 1
        qs_d[i] = int(data[pos + 2]) % MOD
        pos += 3

    # Sj[i][m] = sum_{j=0}^{m-1} j^i (mod MOD), with 0^0 = 1
    Sj = [[0] * (n + 2) for _ in range(K + 1)]
    Sj[0] = [m for m in range(n + 2)]
    for i in range(1, K + 1):
        row = Sj[i]
        acc = 0
        for j in range(n + 1):
            row[j] = acc
            acc = (acc + pow(j, i, MOD)) % MOD
        row[n + 1] = acc
    # binomial coefficients up to K
    C = [[0] * (K + 1) for _ in range(K + 1)]
    for i in range(K + 1):
        C[i][0] = 1
        for j in range(1, i + 1):
            C[i][j] = C[i - 1][j - 1] + (C[i - 1][j] if j <= i - 1 else 0)

    # Fenwick trees: index 0 = count, 1..K = power sums of distinct values
    bit = [[0] * (n + 1) for _ in range(K + 1)]
    total = [0] * (K + 1)

    def add(k, idx, w):
        t = bit[k]
        while idx <= n:
            t[idx] = (t[idx] + w) % MOD
            idx += idx & (-idx)

    def prefix(k, idx):
        t = bit[k]
        s = 0
        while idx > 0:
            s += t[idx]
            idx -= idx & (-idx)
        return s % MOD

    # Group queries by right endpoint
    by_r = [[] for _ in range(n)]
    for i in range(q):
        by_r[qs_r[i]].append(i)

    last = {}  # value -> position (0-based) of its last occurrence so far
    ans = [""] * q

    for r in range(n):
        v = a[r]
        # weights of value v
        w = [1] * (K + 1)
        cur = 1
        for k in range(1, K + 1):
            cur = cur * v % MOD
            w[k] = cur
        # remove previous occurrence of v (only the latest occurrence counts)
        pr = last.get(v)
        if pr is not None:
            p1 = pr + 1  # 1-based index
            for k in range(K + 1):
                add(k, p1, -w[k])
                total[k] = (total[k] - w[k]) % MOD
        last[v] = r
        p1 = r + 1
        for k in range(K + 1):
            add(k, p1, w[k])
            total[k] = (total[k] + w[k]) % MOD

        for qi in by_r[r]:
            L = qs_l[qi]  # 0-based left endpoint
            D = qs_d[qi]
            # distinct values in positions [L, r]: total minus prefix up to L (1-based L)
            m = (total[0] - prefix(0, L)) % MOD
            if D == 0:
                ans[qi] = "Yes" if m == 1 else "No"
                continue
            if m == 1:
                ans[qi] = "Yes"
                continue
            S = [0] * (K + 1)
            for k in range(1, K + 1):
                S[k] = (total[k] - prefix(k, L)) % MOD
            u = pow(D, MOD - 2, MOD)
            P = [0] * (K + 1)
            uk = 1
            for k in range(1, K + 1):
                uk = uk * u % MOD
                P[k] = uk * S[k] % MOD
            # Candidate progression t = c, c+1, ..., c+m-1 in the scaled space
            c = (P[1] - m * (m - 1) // 2) % MOD * pow(m, MOD - 2, MOD) % MOD
            ok = True
            cp = 1
            cpow = [1] * (K + 1)
            for k in range(1, K + 1):
                cp = cp * c % MOD
                cpow[k] = cp
            for k in range(2, K + 1):
                e = 0
                for i in range(k + 1):
                    # C(k,i) * c^(k-i) * sum_{j<m} j^i
                    base = cpow[k - i] if k - i > 0 else 1
                    e = (e + C[k][i] * base % MOD * Sj[i][m]) % MOD
                if e != P[k]:
                    ok = False
                    break
            ans[qi] = "Yes" if ok else "No"

    sys.stdout.write("\n".join(ans) + ("\n" if ans else ""))


main()
