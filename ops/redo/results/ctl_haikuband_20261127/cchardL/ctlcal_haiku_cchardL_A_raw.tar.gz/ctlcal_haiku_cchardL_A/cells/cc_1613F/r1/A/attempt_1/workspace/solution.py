import sys

MOD = 998244353
SLOT = 10  # bytes per coefficient slot (80 bits): products of up to 250000 terms < 2^78


def pack(a):
    return int.from_bytes(b"".join(x.to_bytes(SLOT, "little") for x in a), "little")


def unpack(v, length):
    bs = v.to_bytes(length * SLOT, "little")
    return [int.from_bytes(bs[i * SLOT:(i + 1) * SLOT], "little") % MOD for i in range(length)]


def mul(a, b):
    if min(len(a), len(b)) <= 16:
        res = [0] * (len(a) + len(b) - 1)
        for i, x in enumerate(a):
            if x == 0:
                continue
            for j, y in enumerate(b):
                res[i + j] += x * y
        return [r % MOD for r in res]
    L = len(a) + len(b) - 1
    prod = pack(a) * pack(b)
    return unpack(prod, L)


def product(polys):
    # divide and conquer product
    while len(polys) > 1:
        nxt = []
        for i in range(0, len(polys) - 1, 2):
            nxt.append(mul(polys[i], polys[i + 1]))
        if len(polys) % 2 == 1:
            nxt.append(polys[-1])
        polys = nxt
    return polys[0] if polys else [1]


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    deg = [0] * (n + 1)
    for x in data[1:2 * n - 1]:
        deg[int(x)] += 1

    # k_v = number of children of v = deg(v) minus parent edge (root has none)
    cnt = [0] * (n + 1)
    for v in range(1, n + 1):
        k = deg[v] - (1 if v != 1 else 0)
        if k > 0:
            cnt[k] += 1

    # factorials
    fact = [1] * (n + 1)
    for i in range(1, n + 1):
        fact[i] = fact[i - 1] * i % MOD
    inv_fact = [1] * (n + 1)
    inv_fact[n] = pow(fact[n], MOD - 2, MOD)
    for i in range(n, 0, -1):
        inv_fact[i - 1] = inv_fact[i] * i % MOD

    # group identical factors (1 + k x) into (1 + k x)^c, expanded by binomial theorem
    polys = []
    for k in range(1, n + 1):
        c = cnt[k]
        if c == 0:
            continue
        p = [0] * (c + 1)
        pw = 1
        fc = fact[c]
        for j in range(c + 1):
            # C(c, j) * k^j
            p[j] = fc * inv_fact[j] % MOD * inv_fact[c - j] % MOD * pw % MOD
            pw = pw * k % MOD
        polys.append(p)

    f = product(polys)

    ans = 0
    for k in range(0, min(len(f), n)):
        term = f[k] * fact[n - k] % MOD
        if k & 1:
            ans -= term
        else:
            ans += term
    print(ans % MOD)


if __name__ == "__main__":
    main()
