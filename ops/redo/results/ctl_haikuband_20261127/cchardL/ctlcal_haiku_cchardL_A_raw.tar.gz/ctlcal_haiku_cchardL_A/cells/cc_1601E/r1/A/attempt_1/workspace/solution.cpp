// Phys Ed Online.
//
// For a student (l, r), activations happen at t = l, l+k, l+2k, ... (while <= r).
// The ticket for an activation at t is bought at the cheapest day in [l, t], so
// the cost is  sum over chain nodes t of  min(a[l..t]).
//
// Let s* = leftmost argmin of a[l..r]. Records of prefix minima from l form the
// path l -> nse(l) -> nse(nse(l)) -> ... (nse = next strictly smaller index).
// With G(x) = number of chain nodes in [l, x-1] = ceil((x-l)/k):
//   answer = sum over path nodes s before s* of a_s * (G(nse s) - G(s))
//          + a_{s*} * (G(r+1) - G(s*)).
// G(x) = Q_x - floor(l/k) - [R_x < c], with Q_x = (x+k-1)/k, R_x = (x+k-1)%k,
// c = l % k. The floor terms cancel, so the path sums split into a root-path
// sum PW (independent of l) and a residue-threshold sum handled by a Fenwick
// tree that holds exactly the monotone stack (the ancestors of the current index).
#include <bits/stdc++.h>
using namespace std;

static char buf[1 << 25];
int bufLen = 0, bufPos = 0;
inline int gc() {
    if (bufPos == bufLen) {
        bufLen = (int)fread(buf, 1, sizeof(buf), stdin);
        bufPos = 0;
        if (bufLen <= 0) return -1;
    }
    return buf[bufPos++];
}
inline long long readInt() {
    int c = gc();
    while (c != '-' && (c < '0' || c > '9')) c = gc();
    bool neg = false;
    if (c == '-') { neg = true; c = gc(); }
    long long x = 0;
    while (c >= '0' && c <= '9') { x = x * 10 + (c - '0'); c = gc(); }
    return neg ? -x : x;
}

int main() {
    int n = (int)readInt();
    int q = (int)readInt();
    long long k = readInt();

    vector<long long> a(n + 2, 0);
    for (int i = 1; i <= n; i++) a[i] = readInt();

    vector<int> L(q), R(q);
    for (int j = 0; j < q; j++) {
        L[j] = (int)readInt();
        R[j] = (int)readInt();
    }

    // Sparse table for leftmost argmin.
    int LOG = 1;
    while ((1 << LOG) <= n) LOG++;
    vector<vector<int>> sp(LOG, vector<int>(n + 2, 0));
    for (int i = 1; i <= n; i++) sp[0][i] = i;
    for (int j = 1; j < LOG; j++) {
        for (int i = 1; i + (1 << j) - 1 <= n; i++) {
            int x = sp[j - 1][i], y = sp[j - 1][i + (1 << (j - 1))];
            sp[j][i] = (a[y] < a[x]) ? y : x;  // ties keep the left index
        }
    }
    auto argmin = [&](int l, int r) {
        int len = r - l + 1;
        int j = 31 - __builtin_clz(len);
        int x = sp[j][l], y = sp[j][r - (1 << j) + 1];
        return (a[y] < a[x]) ? y : x;
    };

    vector<int> sStar(q);
    vector<long long> ans(q, 0);
    vector<long long> tailVal(q, 0);
    // Bucket queries by l and by s*.
    vector<vector<int>> byL(n + 2), byS(n + 2);
    for (int j = 0; j < q; j++) {
        sStar[j] = argmin(L[j], R[j]);
        byL[L[j]].push_back(j);
        byS[sStar[j]].push_back(j);
        long long l = L[j], s = sStar[j], r = R[j];
        long long ceilRL = (r + 1 - l + k - 1) / k;
        long long ceilSL = (s - l + k - 1) / k;
        tailVal[j] = a[s] * (ceilRL - ceilSL);
    }

    // Residue Fenwick (keys 0..k-1, stored at index key+1).
    int K = (int)k;
    vector<long long> fen(K + 1, 0);
    auto fenAdd = [&](int key, long long v) {
        for (int i = key + 1; i <= K; i += i & -i) fen[i] += v;
    };
    // Sum of values with key < c.
    auto fenPrefix = [&](int c) {
        long long s = 0;
        for (int i = c; i > 0; i -= i & -i) s += fen[i];
        return s;
    };

    auto Qf = [&](long long x) { return (x + k - 1) / k; };
    auto Rf = [&](long long x) { return (x + k - 1) % k; };

    vector<int> nse(n + 2, n + 1);
    vector<long long> PW(n + 2, 0);
    // Stack of indices; Fenwick contains each stack element's pairs.
    vector<int> st;
    st.reserve(n);

    auto addPairs = [&](int y, long long sign) {
        // (key R_y, +a_y) and (key R_{nse y}, -a_y)
        fenAdd((int)Rf(y), sign * a[y]);
        fenAdd((int)Rf(nse[y]), -sign * a[y]);
    };

    // Process positions from right to left.
    PW[n + 1] = 0;
    for (int i = n; i >= 1; i--) {
        while (!st.empty() && a[st.back()] >= a[i]) {
            int y = st.back();
            st.pop_back();
            addPairs(y, -1);  // remove y's pairs (uses its stored nse)
        }
        nse[i] = st.empty() ? n + 1 : st.back();
        st.push_back(i);
        addPairs(i, +1);

        PW[i] = a[i] * (Qf(nse[i]) - Qf(i)) + PW[nse[i]];

        // Fenwick now holds ancestors of i (including i).
        // Contribution at time l: +PW[l] + F_c(l); at time s*: -(PW[s*] + F_c(s*)).
        for (int j : byL[i]) {
            int c = (int)(L[j] % K);
            ans[j] += PW[i] + fenPrefix(c);
        }
        for (int j : byS[i]) {
            int c = (int)(L[j] % K);
            ans[j] -= PW[i] + fenPrefix(c);
        }
    }

    string out;
    out.reserve((size_t)q * 16);
    for (int j = 0; j < q; j++) {
        long long res = ans[j] + tailVal[j];
        out += to_string(res);
        out += '\n';
    }
    fwrite(out.data(), 1, out.size(), stdout);
    return 0;
}
