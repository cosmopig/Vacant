import sys


def main():
    data = sys.stdin.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    k = int(data[pos]); pos += 1
    steps = []  # for each step: (mask, suffix masks: suf[t] = mask of last t positions of the set)
    for _ in range(k):
        q = int(data[pos]); pos += 1
        idx = sorted(set(int(x) - 1 for x in data[pos:pos + q]))
        pos += q
        mask = 0
        for j in idx:
            mask |= 1 << j
        # suffix masks over the positions of the subsequence, in increasing index order
        suf = [0] * (len(idx) + 1)
        for t in range(1, len(idx) + 1):
            suf[t] = suf[t - 1] | (1 << idx[len(idx) - t])
        steps.append((mask, suf))

    # 0/1 principle: the algorithm sorts every input iff it sorts every 0/1 input.
    # State: `known` = positions whose initial bit has been fixed by branching, `ones` = their current values
    # (ones is always a subset of known). Positions never touched stay free (any 0/1 value).
    # For a step with subsequence S: let x = #unknown positions in S, K = #ones in S (all known).
    # Only the count c of ones among the unknown positions of S matters for the result, so branch on c
    # in 0..x. After sorting, the last K+c positions of S hold 1, the rest of S hold 0.
    memo = {}

    def check_final(known, ones):
        # Every free position must be able to take either value, so sortedness must hold for all choices.
        seen_one = False
        for p in range(n):
            bit = 1 << p
            if known & bit:
                could1 = bool(ones & bit)
                could0 = not could1
            else:
                could1 = could0 = True
            if could0 and seen_one:
                return False
            if could1:
                seen_one = True
        return True

    def ok(i, known, ones):
        if i == k:
            return check_final(known, ones)
        key = (i, known, ones)
        if key in memo:
            return memo[key]
        mask, suf = steps[i]
        unk = mask & ~known
        x = bin(unk).count("1")
        K = bin(ones & mask).count("1")
        base_ones = ones & ~mask
        new_known = known | mask
        res = True
        for c in range(x + 1):
            total = K + c
            if not ok(i + 1, new_known, base_ones | suf[total]):
                res = False
                break
        memo[key] = res
        return res

    print("ACCEPTED" if ok(0, 0, 0) else "REJECTED")


main()
