#include <bits/stdc++.h>
using namespace std;

// Bottom-up divide and conquer over the binary trie of the values.
// For a trie node at level h (its values are the h low bits, 2^h possible
// low-bit patterns) and every x in [0, 2^h), we keep:
//   mn[x]  = min of (v xor x) over the values v in the node  (INF if empty)
//   mx[x]  = max of (v xor x) over the values v in the node  (-INF if empty)
//   ans[x] = min pairwise |difference| of (v xor x) within the node (INF if < 2 values)
// Node p at level h occupies the block [p*2^h, (p+1)*2^h) of each array; its
// child 2p (bit h-1 = 0) occupies the first half, child 2p+1 the second half.
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, k;
    cin >> n >> k;
    const int N = 1 << k;
    const long long INF = 1000000000000000LL; // 1e15

    vector<long long> mn(N), mx(N), ans(N, INF);
    vector<long long> nmn(N), nmx(N), nans(N);

    for (int i = 0; i < N; i++) {
        mn[i] = INF;
        mx[i] = -INF;
    }
    for (int i = 0; i < n; i++) {
        int a;
        cin >> a;
        mn[a] = 0;
        mx[a] = 0;
    }

    for (int h = 1; h <= k; h++) {
        const int size = 1 << h;
        const int half = size >> 1;
        for (int base = 0; base < N; base += size) {
            const int A = base;        // child with bit h-1 = 0
            const int B = base + half; // child with bit h-1 = 1
            for (int x = 0; x < half; x++) {
                const int a = A + x, b = B + x;
                // x has bit h-1 = 0: A stays low, B becomes high.
                {
                    long long mnA = mn[a], mxA = mx[a], mnB = mn[b], mxB = mx[b];
                    nmn[base + x] = min(mnA, mnB + half);
                    nmx[base + x] = max(mxA, mxB + half);
                    long long r = min(ans[a], ans[b]);
                    r = min(r, mnB + half - mxA);
                    nans[base + x] = r;
                }
                // x has bit h-1 = 1: B becomes low, A becomes high.
                {
                    long long mnA = mn[a], mxA = mx[a], mnB = mn[b], mxB = mx[b];
                    nmn[base + half + x] = min(mnB, mnA + half);
                    nmx[base + half + x] = max(mxB, mxA + half);
                    long long r = min(ans[a], ans[b]);
                    r = min(r, mnA + half - mxB);
                    nans[base + half + x] = r;
                }
            }
        }
        swap(mn, nmn);
        swap(mx, nmx);
        swap(ans, nans);
    }

    // Output f(0), f(1), ..., f(2^k - 1) separated by spaces.
    string out;
    out.reserve((size_t)N * 8);
    char buf[24];
    for (int x = 0; x < N; x++) {
        int len = snprintf(buf, sizeof(buf), "%lld", ans[x]);
        out.append(buf, len);
        out.push_back(x + 1 < N ? ' ' : '\n');
    }
    cout << out;
    return 0;
}
