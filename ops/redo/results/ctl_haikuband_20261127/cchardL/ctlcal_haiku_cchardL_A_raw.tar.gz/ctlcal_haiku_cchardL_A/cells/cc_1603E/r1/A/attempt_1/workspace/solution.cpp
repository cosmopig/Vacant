#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

// Reduction (derived in the analysis):
// Sort the sequence a_1 <= ... <= a_n. Every subsequence is good iff for every j,
// a_1 + ... + a_j <= a_1 * a_j  (the prefix case is the tightest, since any range
// [i..j] has sum <= prefix sum <= a_1*a_j <= a_i*a_j).
// With m = a_1 and excess e = a - m, the prefix condition for value v becomes
//   k_v <= v, and if k_v == v then E_v == 0,
// where k_v = count of elements <= v and E_v = sum of excesses of elements <= v.
// Also E_total <= m (from v = n+1), so the excess state is bounded by m.
// Count sorted multisets with weight 1/prod(c_v!), then multiply by n!.

ll M;

ll power(ll b, ll e) {
    b %= M;
    if (b < 0) b += M;
    ll r = 1;
    while (e > 0) {
        if (e & 1) r = r * b % M;
        b = b * b % M;
        e >>= 1;
    }
    return r;
}

int n;
vector<ll> invfact;

// Number of weighted multisets with values in [start, n+1], min-value m, which satisfy
// the constraints, containing exactly n elements. Returned mod M (weight without n!).
ll countFrom(int m, int start, bool needMin) {
    // dp[k][E]
    vector<vector<ll>> dp(n + 1, vector<ll>(m + 1, 0));
    dp[0][0] = 1;
    for (int v = start; v <= n + 1; v++) {
        int d = v - m;
        vector<vector<ll>> nd(n + 1, vector<ll>(m + 1, 0));
        int kmax = min(n, v - 1);  // before processing v, k <= v-1 (k <= v is enforced)
        for (int k = 0; k <= kmax; k++) {
            for (int E = 0; E <= m; E++) {
                ll cur = dp[k][E];
                if (!cur) continue;
                // At v == m (the minimum value) we need at least one copy when needMin.
                int cStart = (needMin && v == m) ? 1 : 0;
                for (int c = cStart; k + c <= n; c++) {
                    ll E2 = (ll)E + (ll)c * d;
                    if (E2 > m) break;
                    int k2 = k + c;
                    if (k2 > v) break;
                    if (k2 == v && E2 != 0) continue;
                    ll w = cur * invfact[c] % M;
                    ll &dst = nd[k2][E2];
                    dst += w;
                    if (dst >= M) dst -= M;
                }
            }
        }
        dp.swap(nd);
    }
    ll total = 0;
    for (int E = 0; E <= m; E++) total = (total + dp[n][E]) % M;
    return total;
}

int main() {
    cin >> n >> M;
    if (n == 1) {
        // Any single element is good; values are 1..2.
        cout << 2 % M << "\n";
        return 0;
    }
    vector<ll> fact(n + 1, 1);
    for (int i = 1; i <= n; i++) fact[i] = fact[i - 1] * i % M;
    invfact.assign(n + 1, 1);
    for (int i = 0; i <= n; i++) invfact[i] = power(fact[i], M - 2);

    ll sum = 0;
    for (int m = 1; m <= n + 1; m++) {
        // Sequences whose minimum is exactly m (values in [m, n+1], at least one m).
        sum = (sum + countFrom(m, m, true)) % M;
    }
    ll ans = sum * fact[n] % M;
    cout << ans << "\n";
    return 0;
}
