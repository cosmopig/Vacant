#include <bits/stdc++.h>
using namespace std;

// Min-cost flow (SPFA-based) on a small bipartite graph.
struct MCF {
    struct E { int to; int cap; long long cost; };
    vector<E> es;
    vector<vector<int>> g;
    explicit MCF(int n) : g(n) {}
    void add(int u, int v, int cap, long long cost) {
        g[u].push_back((int)es.size()); es.push_back({v, cap, cost});
        g[v].push_back((int)es.size()); es.push_back({u, 0, -cost});
    }
    // Pushes up to maxFlow units; returns total cost (negative of gain).
    long long run(int s, int t, int maxFlow, long long &flowOut) {
        int n = g.size();
        long long total = 0;
        flowOut = 0;
        const long long INF = LLONG_MAX / 4;
        while (flowOut < maxFlow) {
            vector<long long> dist(n, INF);
            vector<int> prevE(n, -1);
            vector<char> inq(n, 0);
            deque<int> q;
            dist[s] = 0; q.push_back(s); inq[s] = 1;
            while (!q.empty()) {
                int u = q.front(); q.pop_front(); inq[u] = 0;
                for (int id : g[u]) {
                    const E &e = es[id];
                    if (e.cap > 0 && dist[u] + e.cost < dist[e.to]) {
                        dist[e.to] = dist[u] + e.cost;
                        prevE[e.to] = id;
                        if (!inq[e.to]) { inq[e.to] = 1; q.push_back(e.to); }
                    }
                }
            }
            if (dist[t] >= INF) break;
            // Augment one unit along the path.
            int v = t;
            while (v != s) {
                int id = prevE[v];
                es[id].cap -= 1;
                es[id ^ 1].cap += 1;
                v = es[id ^ 1].to;
            }
            total += dist[t];
            flowOut += 1;
        }
        return total;
    }
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, k;
    cin >> n >> k;
    int N = 1 << n;
    vector<int> a(N);
    for (int i = 0; i < N; i++) cin >> a[i];

    // Total number of hypercube edges: n * 2^(n-1).
    long long totalEdges = (long long)n * (N / 2);
    long long K = (long long)(2 * n - 1) * (k - 1) + 1;
    if (K > totalEdges) K = totalEdges;

    // Encode each edge as (weight << 26) | (mask << 5) | bit.
    // weight <= 2e6 (21 bits), mask < 2^20, bit < 32 -> fits in 64 bits.
    vector<unsigned long long> keys;
    keys.reserve((size_t)totalEdges);
    for (int v = 0; v < N; v++) {
        for (int j = 0; j < n; j++) {
            if (v & (1 << j)) continue;
            unsigned long long w = (unsigned long long)(a[v] + a[v | (1 << j)]);
            keys.push_back((w << 26) | ((unsigned long long)v << 5) | (unsigned long long)j);
        }
    }
    if (K < (long long)keys.size()) {
        nth_element(keys.begin(), keys.begin() + (K - 1), keys.end(), greater<unsigned long long>());
        keys.resize((size_t)K);
    }

    struct Edge { int u, v; long long w; };
    vector<Edge> edges;
    edges.reserve(keys.size());
    for (auto key : keys) {
        int j = (int)(key & 31);
        int v = (int)((key >> 5) & ((1ULL << 21) - 1));
        long long w = (long long)(key >> 26);
        int u = v | (1 << j);
        // Left side: even popcount; right side: odd popcount.
        int left = (__builtin_popcount(v) % 2 == 0) ? v : u;
        int right = (left == v) ? u : v;
        edges.push_back({left, right, w});
    }

    // Build flow network: source -> left (cap 1), left -> right (cap 1, cost -w), right -> sink (cap 1).
    int S = 0, T = 1;
    // Reserve ids 0 and 1 for source/sink; vertex ids start at 2.
    vector<pair<int,int>> ev; // (leftId, rightId)
    vector<long long> ew;
    ev.reserve(edges.size());
    ew.reserve(edges.size());
    vector<int> leftIds, rightIds;
    unordered_map<int, int> lid, rid;
    lid.reserve(edges.size() * 2 + 4);
    rid.reserve(edges.size() * 2 + 4);
    int cnt = 2;
    for (auto &e : edges) {
        int li, ri;
        auto itl = lid.find(e.u);
        if (itl == lid.end()) { li = cnt++; lid[e.u] = li; leftIds.push_back(li); } else li = itl->second;
        auto itr = rid.find(e.v);
        if (itr == rid.end()) { ri = cnt++; rid[e.v] = ri; rightIds.push_back(ri); } else ri = itr->second;
        ev.push_back({li, ri});
        ew.push_back(e.w);
    }

    MCF mcf(cnt);
    for (int l : leftIds) mcf.add(S, l, 1, 0);
    for (int r : rightIds) mcf.add(r, T, 1, 0);
    for (size_t i = 0; i < ev.size(); i++) {
        mcf.add(ev[i].first, ev[i].second, 1, -ew[i]);
    }

    long long flow = 0;
    long long cost = mcf.run(S, T, k, flow);
    long long answer = -cost;
    cout << answer << "\n";
    return 0;
}
