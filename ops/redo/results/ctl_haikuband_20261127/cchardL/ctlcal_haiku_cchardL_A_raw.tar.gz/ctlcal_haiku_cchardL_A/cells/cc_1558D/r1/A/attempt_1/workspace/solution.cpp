// Top-Notch Insertions.
//
// Key facts:
//  * Let S be the sorted prefix (by value, ties by index). Insertion of element i
//    at position p = (number of prefix elements <= a_i) is forced by the input:
//    p = y-1 for an insertion at i, p = i-1 (append) otherwise. So the final
//    list of indices is uniquely determined by the input.
//  * A sequence a is counted iff its stable sorted order equals that list, and the
//    number of value sequences with a given order having d descents is
//    C(2n-1-d, n).  So the answer is C(2n-1-d, n), d = #descents of the final list.
//  * The list is kept as O(m) chunks of consecutive indices in an implicit treap.
#include <bits/stdc++.h>
using namespace std;

static const long long MOD = 998244353LL;

static vector<int> Lc, Rc, Pr, Sz, Ln, Fi, La;
static mt19937 rng(12345);

static int newNode(int first, int last) {
    Lc.push_back(0); Rc.push_back(0); Pr.push_back((int)(rng() & 0x7fffffff));
    Sz.push_back(last - first + 1); Ln.push_back(last - first + 1);
    Fi.push_back(first); La.push_back(last);
    return (int)Lc.size() - 1;
}

static void upd(int v) { Sz[v] = Sz[Lc[v]] + Ln[v] + Sz[Rc[v]]; }

static int merge_(int a, int b) {
    if (!a) return b;
    if (!b) return a;
    if (Pr[a] > Pr[b]) {
        Rc[a] = merge_(Rc[a], b);
        upd(a);
        return a;
    }
    Lc[b] = merge_(a, Lc[b]);
    upd(b);
    return b;
}

// Splits subtree v so that the first k elements go to A.
static void split_(int v, int k, int &A, int &B) {
    if (!v) { A = B = 0; return; }
    int ls = Sz[Lc[v]];
    if (k <= ls) {
        int a, b;
        split_(Lc[v], k, a, b);
        Lc[v] = b;
        upd(v);
        A = a; B = v;
        return;
    }
    if (k >= ls + Ln[v]) {
        int a, b;
        split_(Rc[v], k - ls - Ln[v], a, b);
        Rc[v] = a;
        upd(v);
        A = v; B = b;
        return;
    }
    // Split this chunk at offset o (1 <= o < Ln[v]).
    int o = k - ls;
    int lt = Lc[v], rt = Rc[v];
    int first = Fi[v], last = La[v];
    La[v] = first + o - 1;
    Ln[v] = o;
    Lc[v] = 0; Rc[v] = 0;
    upd(v);
    int r = newNode(first + o, last);
    A = merge_(lt, v);
    B = merge_(r, rt);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    vector<int> ns(t), ms(t);
    vector<vector<pair<int, int>>> ops(t);
    int maxN = 2;
    for (int tc = 0; tc < t; ++tc) {
        int n, m;
        cin >> n >> m;
        ns[tc] = n; ms[tc] = m;
        maxN = max(maxN, n);
        ops[tc].resize(m);
        for (int k = 0; k < m; ++k) cin >> ops[tc][k].first >> ops[tc][k].second;
    }

    int LIM = 2 * maxN + 2;
    vector<long long> fact(LIM + 1), inv(LIM + 1);
    fact[0] = 1;
    for (int i = 1; i <= LIM; ++i) fact[i] = fact[i - 1] * i % MOD;
    auto pw = [](long long b, long long e) {
        long long r = 1; b %= MOD;
        while (e) { if (e & 1) r = r * b % MOD; b = b * b % MOD; e >>= 1; }
        return r;
    };
    inv[LIM] = pw(fact[LIM], MOD - 2);
    for (int i = LIM; i > 0; --i) inv[i - 1] = inv[i] * i % MOD;
    auto comb = [&](long long a, long long b) -> long long {
        if (a < 0 || b < 0 || b > a) return 0;
        return fact[a] * inv[b] % MOD * inv[a - b] % MOD;
    };

    // Sentinel node 0.
    Lc.assign(1, 0); Rc.assign(1, 0); Pr.assign(1, 0);
    Sz.assign(1, 0); Ln.assign(1, 0); Fi.assign(1, 0); La.assign(1, 0);

    string out;
    for (int tc = 0; tc < t; ++tc) {
        int n = ns[tc], m = ms[tc];
        Lc.resize(1); Rc.resize(1); Pr.resize(1);
        Sz.resize(1); Ln.resize(1); Fi.resize(1); La.resize(1);

        int root = 0;
        int pos = 1;
        for (int k = 0; k < m; ++k) {
            int x = ops[tc][k].first, y = ops[tc][k].second;
            if (pos <= x - 1) {
                root = merge_(root, newNode(pos, x - 1));
            }
            int total = Sz[root];
            int p = y - 1;
            if (p < 0) p = 0;
            if (p > total) p = total;
            int A, B;
            split_(root, p, A, B);
            root = merge_(merge_(A, newNode(x, x)), B);
            pos = x + 1;
        }
        if (pos <= n) root = merge_(root, newNode(pos, n));

        // In-order walk over chunks (iterative), count descents at chunk boundaries.
        long long d = 0;
        int prevLast = -1;
        bool havePrev = false;
        vector<int> st;
        int cur = root;
        while (!st.empty() || cur) {
            while (cur) { st.push_back(cur); cur = Lc[cur]; }
            cur = st.back(); st.pop_back();
            if (havePrev && prevLast > Fi[cur]) ++d;
            prevLast = La[cur];
            havePrev = true;
            cur = Rc[cur];
        }
        out += to_string(comb(2LL * n - 1 - d, n));
        out += '\n';
    }
    cout << out;
    return 0;
}
