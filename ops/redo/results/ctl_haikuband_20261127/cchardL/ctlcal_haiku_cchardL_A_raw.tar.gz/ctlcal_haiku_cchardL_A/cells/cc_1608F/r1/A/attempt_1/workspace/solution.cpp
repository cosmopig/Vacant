// MEX counting.
//
// Let m_i = MEX of prefix i (m_0 = 0). Constraints: m nondecreasing, m_i in [b_i-k, b_i+k], m_i <= i.
//
// Each value v has a first-occurrence time f_v (n+1 if absent). For a given mex sequence:
//   - a mex value v (left by a jump at step t, p = m_{t-1} = v): f_v = t exactly;
//   - a value v strictly inside a jump (p, q) at step t: f_v <= t;
//   - the final mex value m_n: f_v > n;
//   - all other values are unconstrained.
// Expanding the conditions by inclusion-exclusion turns each value into a choice of
// "forced absent through A_v", and the number of arrays with forced-absent prefixes is
//   prod_i (n+1 - #{v : A_v >= i}).
// So we run a backward DP over steps with state (m_i, c = #{v : A_v >= i}), where the
// jump from p to q at step i is swept value by value (values p..q-1), which keeps it O(n*k) per step
// plus O(n) per (sweep position, c).
//
// Per value in a jump from p to q at step i:
//   v = p:      "A=i-1" (+1)  or  "A=i" (-1)     -> combined effect: c -> c+1 with weight 1
//   p < v < q:  "none" (+1)   or  "A=i" (-1)
// The factor for step i uses the count after all A=i activations.

#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
static const ll MOD = 998244353LL;

int main() {
    int n, k;
    if (scanf("%d %d", &n, &k) != 2) return 0;
    vector<ll> b(n + 1);
    for (int i = 1; i <= n; i++) scanf("%lld", &b[i]);

    // Feasible window for m_i: [L_i, U_i]
    vector<int> L(n + 1), U(n + 1);
    L[0] = 0;
    for (int i = 1; i <= n; i++) {
        ll lo = b[i] - k;
        L[i] = max<ll>(L[i - 1], lo < 0 ? 0 : lo);
    }
    vector<ll> sufmin(n + 2, (ll)4e18);
    for (int i = n; i >= 1; i--) sufmin[i] = min(sufmin[i + 1], b[i] + k);
    U[0] = 0;
    for (int i = 1; i <= n; i++) {
        ll hi = min<ll>(min<ll>(i, n), sufmin[i]);
        U[i] = (int)max<ll>(hi, -1);
    }
    for (int i = 0; i <= n; i++) {
        if (L[i] > U[i]) {
            printf("0\n");
            return 0;
        }
    }

    const int CAP = U[n] + 2;           // max useful count of activated values
    const int W = CAP + 2;              // row width (room for c+1)
    vector<vector<ll>> cur(n + 1, vector<ll>(W, 0)), nxt(n + 1, vector<ll>(W, 0));
    // Y_n: final mex value m_n is activated with A = n, so count = 1.
    for (int q = L[n]; q <= U[n]; q++) cur[q][1] = 1;

    vector<ll> fac(W);
    for (int c = 0; c < W; c++) {
        ll f = (ll)(n + 1) - c;
        f %= MOD;
        if (f < 0) f += MOD;
        fac[c] = f;
    }

    vector<ll> S(W, 0);
    for (int i = n; i >= 1; i--) {
        // Clear the rows we are about to write.
        for (int p = L[i - 1]; p <= U[i - 1]; p++) fill(nxt[p].begin(), nxt[p].end(), 0);

        // Non-jump: m_{i-1} = m_i = p.
        int lo = max(L[i], L[i - 1]), hi = min(U[i], U[i - 1]);
        for (int p = lo; p <= hi; p++) {
            for (int c = 0; c < CAP; c++) nxt[p][c] = cur[p][c] * fac[c] % MOD;
        }

        // Jump sweep: chains start at q in [L_i, U_i] and stop at p in [L_{i-1}, U_{i-1}], p < q.
        fill(S.begin(), S.end(), 0);
        for (int r = U[i] - 1; r >= L[i - 1]; r--) {
            // Inject chains starting at q = r+1.
            if (r + 1 >= L[i] && r + 1 <= U[i]) {
                for (int c = 0; c < CAP; c++) {
                    S[c] += cur[r + 1][c];
                    if (S[c] >= MOD) S[c] -= MOD;
                }
            }
            // Stop at p = r: value r is special; net effect is c -> c+1 with weight 1.
            if (r >= L[i - 1] && r <= U[i - 1]) {
                for (int c = 0; c < CAP; c++) {
                    nxt[r][c + 1] += S[c];
                    if (nxt[r][c + 1] >= MOD) nxt[r][c + 1] -= MOD;
                }
            }
            // Continue through value r as a jumped value: none (+1) or A=i (-1, c -> c+1).
            if (r - 1 >= L[i - 1]) {
                for (int c = CAP; c >= 1; c--) {
                    S[c] = (S[c] - S[c - 1] + MOD) % MOD;
                }
                // S[0] unchanged (no -1 transition lands at 0).
            }
        }
        swap(cur, nxt);
    }

    ll ans = 0;
    for (int c = 0; c < W; c++) ans = (ans + cur[0][c]) % MOD;
    printf("%lld\n", ans);
    return 0;
}
