// Approach:
// * If some A_i occurs in a, then for every value x in A_i, count(x) = count(A_i),
//   and each occurrence of x comes from a fixed offset of A_i. Hence:
//   - an array with a repeated value can never occur, and neither can any of its values;
//   - arrays sharing values form a component; their occurrence sets are translates of one
//     another, so they are placed at fixed relative offsets inside one string M_C;
//   - the component is usable iff the placement is consistent, every position holds one
//     value, and the positions form a contiguous range (so M_C has distinct values);
//   - a valid component contributes a single block M_C of length |M_C| that appears in a
//     as disjoint copies; a value in no array is a free length-1 block; values of unusable
//     components must not appear at all.
// * Hence the answer is the number of token sequences of total length m, computed by
//   dp[i] = f*dp[i-1] + sum_L cnt[L]*dp[i-L], where f = number of free values and
//   cnt[L] = number of usable components of length L.
#include <bits/stdc++.h>
using namespace std;
const long long MOD = 998244353;

static vector<int> par;
static vector<long long> dif;  // pos(x) = pos(par[x]) + dif[x]; dif[root] == 0

int findr(int x) {
    vector<int> path;
    while (par[x] != x) {
        path.push_back(x);
        x = par[x];
    }
    int root = x;
    for (int i = (int)path.size() - 1; i >= 0; --i) {
        int v = path[i];
        int p = par[v];
        if (p != root) {
            dif[v] += dif[p];
            par[v] = root;
        }
    }
    return root;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n, m, k;
    cin >> n >> m >> k;
    par.resize(k + 1);
    dif.assign(k + 1, 0);
    for (int i = 0; i <= k; ++i) par[i] = i;

    vector<char> bad(k + 1, 0);       // indexed by value; mark on the value, propagate later
    vector<int> badMarks;             // values whose component must be marked unusable
    vector<char> used(k + 1, 0);
    vector<int> stamp(k + 1, -1);

    for (int i = 0; i < n; ++i) {
        int c;
        cin >> c;
        vector<int> a(c);
        for (int j = 0; j < c; ++j) cin >> a[j];
        bool dup = false;
        for (int j = 0; j < c; ++j) {
            if (stamp[a[j]] == i) dup = true;
            stamp[a[j]] = i;
            used[a[j]] = 1;
        }
        if (dup) {
            badMarks.push_back(a[0]);
        }
        // pos(a[j]) - pos(a[0]) = j
        int x = a[0];
        for (int j = 1; j < c; ++j) {
            int y = a[j];
            long long delta = j;
            int rx = findr(x);
            long long px = (x == rx) ? 0 : dif[x];
            int ry = findr(y);
            long long py = (y == ry) ? 0 : dif[y];
            if (rx == ry) {
                if (py - px != delta) badMarks.push_back(a[0]);
            } else {
                par[ry] = rx;
                dif[ry] = delta + px - py;
            }
        }
    }

    // mark components with inconsistencies
    // (conflicts recorded by value; after all unions, mark its component)
    vector<char> compBad(k + 1, 0);
    for (int v : badMarks) compBad[findr(v)] = 1;

    // group used values by component root
    vector<vector<long long>> members(k + 1);
    long long usedCount = 0;
    for (int x = 1; x <= k; ++x) {
        if (!used[x]) continue;
        usedCount++;
        int r = findr(x);
        long long p = (x == r) ? 0 : dif[x];
        members[r].push_back(p);
    }
    long long f = (long long)k - usedCount;

    vector<long long> cnt(m + 2, 0);
    for (int r = 1; r <= k; ++r) {
        if (members[r].empty() || compBad[r]) continue;
        vector<long long>& ps = members[r];
        sort(ps.begin(), ps.end());
        bool ok = true;
        for (size_t t = 1; t < ps.size(); ++t)
            if (ps[t] == ps[t - 1]) { ok = false; break; }
        if (ok && ps.back() - ps.front() + 1 != (long long)ps.size()) ok = false;
        if (ok && (long long)ps.size() <= m) cnt[ps.size()]++;
    }

    vector<pair<int, long long>> blocks;
    for (int L = 1; L <= m; ++L)
        if (cnt[L]) blocks.push_back({L, cnt[L]});

    vector<long long> dp(m + 1, 0);
    dp[0] = 1;
    for (int i = 1; i <= m; ++i) {
        unsigned long long acc = (unsigned long long)(f % MOD) * (unsigned long long)dp[i - 1];
        for (auto &b : blocks) {
            if (b.first > i) break;
            acc += (unsigned long long)b.second * (unsigned long long)dp[i - b.first];
        }
        dp[i] = (long long)(acc % MOD);
    }
    cout << dp[m] << "\n";
    return 0;
}
