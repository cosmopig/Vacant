#include <bits/stdc++.h>
using namespace std;

int n, m, k;
bool adj[12][12];
int h;
vector<pair<int, int>> pr;   // matching pairs
vector<vector<pair<int, int>>> matchings;

// Enumerate all perfect matchings of the vertices.
void genMatch(int mask) {
    if (mask == (1 << n) - 1) {
        matchings.push_back(pr);
        return;
    }
    int a = __builtin_ctz(~mask);
    for (int b = a + 1; b < n; b++) {
        if (mask >> b & 1) continue;
        pr.push_back({a, b});
        genMatch(mask | (1 << a) | (1 << b));
        pr.pop_back();
    }
}

// Ladder check: pairs ordered outer->inner, pair i = (a_i, b_i) with
// a_i ~ a_{i+1}, b_i ~ b_{i+1}, and innermost pair must be an edge.
bool valid(const vector<pair<int, int>>& p) {
    int H = p.size();
    int full = (1 << H) - 1;
    // reach[S][j][o]: sets S of pairs placed as outer layers, last placed pair j,
    // orientation o (o=0: a-side is p[j].first; o=1: swapped).
    static bool reach[1 << 6][6][2];
    for (int S = 0; S <= full; S++)
        for (int j = 0; j < H; j++)
            reach[S][j][0] = reach[S][j][1] = false;
    auto fr = [&](int j, int o) { return o == 0 ? p[j].first : p[j].second; };
    auto bk = [&](int j, int o) { return o == 0 ? p[j].second : p[j].first; };
    for (int j = 0; j < H; j++)
        reach[1 << j][j][0] = reach[1 << j][j][1] = true;
    for (int S = 1; S <= full; S++) {
        for (int j = 0; j < H; j++) {
            if (!(S >> j & 1)) continue;
            for (int o = 0; o < 2; o++) {
                if (!reach[S][j][o]) continue;
                for (int l = 0; l < H; l++) {
                    if (S >> l & 1) continue;
                    for (int o2 = 0; o2 < 2; o2++) {
                        if (adj[fr(j, o)][fr(l, o2)] && adj[bk(j, o)][bk(l, o2)])
                            reach[S | (1 << l)][l][o2] = true;
                    }
                }
            }
        }
    }
    for (int j = 0; j < H; j++) {
        if (!adj[p[j].first][p[j].second]) continue;  // innermost pair must be an edge
        if (reach[full][j][0] || reach[full][j][1]) return true;
    }
    return false;
}

int main() {
    scanf("%d %d %d", &n, &m, &k);
    for (int i = 0; i < m; i++) {
        int v, u;
        scanf("%d %d", &v, &u);
        v--; u--;
        adj[v][u] = adj[u][v] = true;
    }
    h = n / 2;
    genMatch(0);

    // Collect every partition (encoded as 4 bits per vertex, restricted growth form)
    // that is coarser than some valid matching.
    vector<unsigned long long> codes;
    for (auto& M : matchings) {
        if (!valid(M)) continue;
        // enumerate set partitions of the h pair-blocks via restricted growth strings
        vector<int> lab(h, 0);
        function<void(int, int)> rec = [&](int i, int mx) {
            if (i == h) {
                int vl[12];
                for (int t = 0; t < h; t++) {
                    vl[M[t].first] = lab[t];
                    vl[M[t].second] = lab[t];
                }
                // canonicalize over vertices by first occurrence
                int map_[12];
                for (int t = 0; t < 12; t++) map_[t] = -1;
                int nxt = 0;
                unsigned long long code = 0;
                for (int v = 0; v < n; v++) {
                    if (map_[vl[v]] < 0) map_[vl[v]] = nxt++;
                    code |= (unsigned long long)map_[vl[v]] << (4 * v);
                }
                codes.push_back(code);
                return;
            }
            for (int c = 0; c <= mx + 1; c++) {
                lab[i] = c;
                rec(i + 1, max(mx, c));
            }
        };
        lab[0] = 0;
        rec(1, 0);
    }
    sort(codes.begin(), codes.end());
    codes.erase(unique(codes.begin(), codes.end()), codes.end());

    long long ans = 0;
    for (auto code : codes) {
        int blocks = 0;
        for (int v = 0; v < n; v++)
            blocks = max(blocks, (int)((code >> (4 * v)) & 15) + 1);
        // injective letter assignment to blocks: k*(k-1)*...*(k-blocks+1)
        long long ways = 1;
        for (int i = 0; i < blocks; i++) ways *= (k - i);
        ans += ways;   // becomes 0 automatically once blocks > k
    }
    printf("%lld\n", ans);
    return 0;
}
