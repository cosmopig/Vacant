// Stairs: count permutations whose stair array equals a (mod 998244353).
//
// Model: maximal stair segments partition the positions into blocks. A block of
// length L has a_i = L on all its positions, so the partition is forced by a
// (greedy left-to-right). A block of length >= 2 is a run of consecutive values in
// monotone order (2 orientations); a block of length 1 is a single value. Adjacent
// blocks must not have boundary values differing by exactly 1.
//
// Inclusion-exclusion over the set S of adjacent block pairs that are forced to
// touch in value (with the bad orientation). Each run of S-pairs contributes 2
// (its direction), each non-singleton block untouched by S contributes 2
// (orientation), and |S| = s contributes (-1)^s (m-s)!. The generating polynomial
// in x (x^s marks |S| = s) is a product of 2x2 polynomial matrices, computed by
// divide and conquer with NTT.
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef vector<ll> poly;
static const ll MOD = 998244353;

ll pw(ll b, ll e) {
    b %= MOD;
    if (b < 0) b += MOD;
    ll r = 1;
    while (e) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

void ntt(vector<ll>& a, bool inv) {
    int n = a.size();
    for (int i = 1, j = 0; i < n; i++) {
        int bit = n >> 1;
        for (; j & bit; bit >>= 1) j ^= bit;
        j ^= bit;
        if (i < j) swap(a[i], a[j]);
    }
    for (int len = 2; len <= n; len <<= 1) {
        ll w = pw(3, (MOD - 1) / len);
        if (inv) w = pw(w, MOD - 2);
        vector<ll> ws(len / 2);
        ws[0] = 1;
        for (int k = 1; k < len / 2; k++) ws[k] = ws[k - 1] * w % MOD;
        for (int i = 0; i < n; i += len) {
            for (int k = 0; k < len / 2; k++) {
                ll u = a[i + k];
                ll v = a[i + k + len / 2] * ws[k] % MOD;
                a[i + k] = (u + v) % MOD;
                a[i + k + len / 2] = (u - v + MOD) % MOD;
            }
        }
    }
    if (inv) {
        ll ni = pw(n, MOD - 2);
        for (auto& x : a) x = x * ni % MOD;
    }
}

poly mul(const poly& a, const poly& b) {
    if (a.empty() || b.empty()) return poly();
    size_t rs = a.size() + b.size() - 1;
    if (min(a.size(), b.size()) <= 32) {
        poly r(rs, 0);
        for (size_t i = 0; i < a.size(); i++)
            for (size_t j = 0; j < b.size(); j++) r[i + j] = (r[i + j] + a[i] * b[j]) % MOD;
        return r;
    }
    int sz = 1;
    while ((size_t)sz < rs) sz <<= 1;
    vector<ll> fa(sz, 0), fb(sz, 0);
    for (size_t i = 0; i < a.size(); i++) fa[i] = a[i];
    for (size_t i = 0; i < b.size(); i++) fb[i] = b[i];
    ntt(fa, false);
    ntt(fb, false);
    for (int i = 0; i < sz; i++) fa[i] = fa[i] * fb[i] % MOD;
    ntt(fa, true);
    fa.resize(rs);
    return fa;
}

poly add(const poly& a, const poly& b) {
    poly r(max(a.size(), b.size()), 0);
    for (size_t i = 0; i < a.size(); i++) r[i] = a[i];
    for (size_t i = 0; i < b.size(); i++) r[i] = (r[i] + b[i]) % MOD;
    return r;
}

struct Mat {
    poly m[2][2];
};

Mat mmul(const Mat& A, const Mat& B) {
    Mat C;
    for (int i = 0; i < 2; i++)
        for (int j = 0; j < 2; j++)
            C.m[i][j] = add(mul(A.m[i][0], B.m[0][j]), mul(A.m[i][1], B.m[1][j]));
    return C;
}

// Transfer matrix for one block. Rows: s_{b-1} (left pair), columns: s_b (right pair).
// Right pair in S contributes x; a run start (left pair not in S) contributes 2.
// A non-singleton block untouched by any pair (left=0, right=0) contributes 2.
Mat base(bool nonsingleton) {
    Mat M;
    M.m[0][0] = poly{nonsingleton ? 2LL : 1LL};
    M.m[0][1] = poly{0, 2};  // 2x
    M.m[1][0] = poly{1};
    M.m[1][1] = poly{0, 1};  // x
    return M;
}

vector<Mat> blocks;

Mat solve(int l, int r) {
    if (r - l == 1) return blocks[l];
    int mid = (l + r) / 2;
    return mmul(solve(l, mid), solve(mid, r));
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    if (!(cin >> n)) return 0;
    vector<ll> a(n);
    for (auto& x : a) cin >> x;

    // Greedy block partition, forced by a.
    vector<int> lens;
    int i = 0;
    while (i < n) {
        ll L = a[i];
        if (L < 1 || (ll)i + L > n) {
            cout << 0 << "\n";
            return 0;
        }
        for (ll j = i; j < i + L; j++) {
            if (a[j] != L) {
                cout << 0 << "\n";
                return 0;
            }
        }
        lens.push_back((int)L);
        i += (int)L;
    }
    int m = lens.size();
    blocks.reserve(m);
    for (int L : lens) blocks.push_back(base(L >= 2));

    Mat M = solve(0, m);
    poly P = M.m[0][0];

    vector<ll> fact(n + 2, 1);
    for (int k = 1; k <= n + 1; k++) fact[k] = fact[k - 1] * k % MOD;

    ll ans = 0;
    for (int s = 0; s < m && s < (int)P.size(); s++) {
        ll term = fact[m - s] * P[s] % MOD;
        if (s & 1) ans = (ans - term + MOD) % MOD;
        else ans = (ans + term) % MOD;
    }
    cout << ans << "\n";
    return 0;
}
