// Cyclic Sum.
//
// Let N = n*m, prefix sums Q_i of b (Q_0 = 0). Each proper arc of b (length 1..N-1)
// is an ordered pair (s, e), s != e, with sum == R_e - R_s + [e < s] * (m*T) (mod k),
// where R_i = Q_i mod k and T = sum(a). The full cycle (one set) has sum m*T.
//
// For unordered positions x < y the two ordered pairs contribute
//   [R_y - R_x == 0]  and  [R_y - R_x == c], with c = m*T mod k.
// So answer = A(0) + A(c) + [c == 0], where A(d) = #{x < y : R_y - R_x == d}.
//
// Positions are x = (q, r) with i = q*n + r, R = q*T + P_r, P_r = a_0+...+a_{r-1}.
//  - same block q:   m * #{r1 < r2 : P_{r2} - P_{r1} == d}
//  - blocks q1<q2 with t = q2-q1: (m-t) * h(d - t*T), where
//    h(v) = #{(r1, r2) : P_{r2} - P_{r1} == v} (cyclic autocorrelation mod k, via NTT).
// For k == 1 every arc counts: answer = N(N-1)+1.

#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

static const ll MOD = 1000000007LL;

ll pw(ll b, ll e, ll m) {
    ll r = 1 % m;
    b %= m;
    if (b < 0) b += m;
    while (e) {
        if (e & 1) r = r * b % m;
        b = b * b % m;
        e >>= 1;
    }
    return r;
}

// In-place NTT modulo prime p (p has primitive root 3), size must be a power of two.
void ntt(vector<ll>& a, bool inv, ll p) {
    int n = a.size();
    for (int i = 1, j = 0; i < n; i++) {
        int bit = n >> 1;
        for (; j & bit; bit >>= 1) j ^= bit;
        j ^= bit;
        if (i < j) swap(a[i], a[j]);
    }
    for (int len = 2; len <= n; len <<= 1) {
        ll w = pw(3, (p - 1) / len, p);
        if (inv) w = pw(w, p - 2, p);
        int half = len / 2;
        vector<ll> ws(half);
        ws[0] = 1;
        for (int i = 1; i < half; i++) ws[i] = ws[i - 1] * w % p;
        for (int i = 0; i < n; i += len) {
            for (int j = 0; j < half; j++) {
                ll u = a[i + j];
                ll v = a[i + j + half] * ws[j] % p;
                ll s = u + v;
                a[i + j] = s >= p ? s - p : s;
                ll d = u - v;
                a[i + j + half] = d < 0 ? d + p : d;
            }
        }
    }
    if (inv) {
        ll ni = pw(n, p - 2, p);
        for (auto& x : a) x = x * ni % p;
    }
}

// Linear convolution of x and y (values already reduced mod p), result length |x|+|y|-1.
vector<ll> convMod(const vector<ll>& x, const vector<ll>& y, ll p) {
    int need = x.size() + y.size() - 1;
    int sz = 1;
    while (sz < need) sz <<= 1;
    vector<ll> a(sz, 0), b(sz, 0);
    copy(x.begin(), x.end(), a.begin());
    copy(y.begin(), y.end(), b.begin());
    ntt(a, false, p);
    ntt(b, false, p);
    for (int i = 0; i < sz; i++) a[i] = a[i] * b[i] % p;
    ntt(a, true, p);
    a.resize(need);
    return a;
}

// Exact cyclic autocorrelation: h[v] = sum_u F[u] * F[(u+v) mod k], for v in [0, k).
// Values are at most n^2 <= 4e10, so two NTT primes are combined with CRT (product ~1.7e17).
vector<ll> cyclicCorr(const vector<ll>& F) {
    int k = F.size();
    vector<ll> Z(2 * k), Zr(2 * k);
    for (int i = 0; i < 2 * k; i++) Z[i] = F[i % k];
    for (int j = 0; j < 2 * k; j++) Zr[j] = Z[2 * k - 1 - j];
    // conv[s] = sum_u F[u] * Zr[s-u] = sum_u F[u] * Z[2k-1-s+u]; with v = 2k-1-s this is h[v].
    const ll P1 = 998244353LL, P2 = 167772161LL;
    vector<ll> c1 = convMod(F, Zr, P1);
    vector<ll> c2 = convMod(F, Zr, P2);
    ll inv_p1_mod_p2 = pw(P1 % P2, P2 - 2, P2);
    vector<ll> h(k);
    for (int v = 0; v < k; v++) {
        int s = 2 * k - 1 - v;
        ll r1 = c1[s], r2 = c2[s];
        ll t = ((r2 - r1) % P2 + P2) % P2 * inv_p1_mod_p2 % P2;
        h[v] = r1 + P1 * t;  // exact value, < P1*P2
    }
    return h;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    ll n, m, k;
    cin >> n >> m >> k;
    vector<ll> a(n);
    for (auto& x : a) cin >> x;

    if (k == 1) {
        ll N = n * m;  // up to 4e10, fits in ll
        ll ans = (N % MOD) * (((N - 1) % MOD + MOD) % MOD) % MOD;
        ans = (ans + 1) % MOD;
        cout << ans << "\n";
        return 0;
    }

    int K = (int)k;
    auto red = [&](ll x) { return ((x % K) + K) % K; };

    ll T = 0;
    for (ll x : a) T = (T + red(x)) % K;

    vector<int> P(n);  // P[r] = (a_0 + ... + a_{r-1}) mod k, r in [0, n)
    P[0] = 0;
    for (int r = 1; r < n; r++) P[r] = (P[r - 1] + red(a[r - 1])) % K;

    vector<ll> F(K, 0);
    for (int r = 0; r < n; r++) F[P[r]]++;
    vector<ll> h = cyclicCorr(F);

    ll c = (m % K) * T % K;

    // A(d) = #{x < y : R_y - R_x == d (mod k)} over all positions of b.
    auto A = [&](int d) -> ll {
        // same block: pairs r1 < r2 with P[r2] - P[r1] == d
        ll W = 0;
        vector<ll> cnt(K, 0);
        for (int r = 0; r < n; r++) {
            W += cnt[red(P[r] - d)];
            cnt[P[r]]++;
        }
        ll res = (m % MOD) * (W % MOD) % MOD;
        // cross blocks: t = q2 - q1 in [1, m-1], multiplicity (m - t)
        ll tT = 0;
        for (ll t = 1; t <= m - 1; t++) {
            tT = (tT + T) % K;
            ll idx = red(d - tT);
            res = (res + ((m - t) % MOD) * (h[idx] % MOD)) % MOD;
        }
        return res;
    };

    ll ans = (A(0) + A((int)c)) % MOD;
    if (c == 0) ans = (ans + 1) % MOD;
    cout << ans << "\n";
    return 0;
}
