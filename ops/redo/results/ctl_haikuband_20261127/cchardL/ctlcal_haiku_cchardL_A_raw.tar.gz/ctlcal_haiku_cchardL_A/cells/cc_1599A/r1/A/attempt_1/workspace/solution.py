import bisect
import sys


def solve(data):
    tok = data.split()
    n = int(tok[0])
    A = list(map(int, tok[1:1 + n]))
    S = tok[1 + n]
    order = sorted(range(n), key=lambda i: A[i])
    vals = [A[i] for i in order]
    # Fenwick tree over sorted positions; 1 = weight still off the table.
    tree = [0] * (n + 1)
    for i in range(1, n + 1):
        tree[i] += 1
        j = i + (i & -i)
        if j <= n:
            tree[j] += tree[i]
    top = 1 << n.bit_length()

    def remove(p):
        p += 1
        while p <= n:
            tree[p] -= 1
            p += p & -p

    def prefix(p):  # number of remaining weights at sorted positions [0, p)
        s = 0
        while p > 0:
            s += tree[p]
            p -= p & -p
        return s

    def kth(k):  # sorted position of the k-th (0-based) remaining weight
        pos = 0
        bit = top
        while bit:
            nxt = pos + bit
            if nxt <= n and tree[nxt] <= k:
                pos = nxt
                k -= tree[nxt]
            bit >>= 1
        return pos

    alive = n
    d = 0
    out = []
    for i in range(n):
        s = S[i]
        if (s == 'L' and d >= 0) or (s == 'R' and d <= 0):
            # Sign already right: every remaining weight is usable; take the median.
            base, cnt = 0, alive
        else:
            # Sign must flip: the weight has to be heavier than |d|; take the lightest such.
            start = bisect.bisect_right(vals, abs(d))
            base = prefix(start)
            cnt = alive - base
            if cnt == 0:
                return "-1"
        p = kth(base + (cnt - 1) // 2)
        w = vals[p]
        remove(p)
        alive -= 1
        nL, nR = d + w, d - w
        okL = (nL > 0) if s == 'L' else (nL < 0)
        okR = (nR > 0) if s == 'L' else (nR < 0)
        if okL and okR:
            side = 'L' if abs(nL) < abs(nR) else 'R'
        else:
            side = 'L' if okL else 'R'
        d = nL if side == 'L' else nR
        out.append("%d %s" % (w, side))
    return "\n".join(out)


def main():
    sys.stdout.write(solve(sys.stdin.read()) + "\n")


if __name__ == "__main__":
    main()
