#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long ull;
typedef long long ll;
const ll MOD = 1000000007LL;

ll pw(ll b, ll e) {
    b %= MOD;
    if (b < 0) b += MOD;
    ll r = 1;
    while (e > 0) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    ll n, k;
    cin >> n >> k;
    vector<ll> a(n);
    for (ll i = 0; i < n; i++) cin >> a[i];

    // Count fixed values and -1s.
    map<ll, ll> cnt;
    ll c = 0;
    for (ll i = 0; i < n; i++) {
        if (a[i] == -1) c++;
        else cnt[a[i]]++;
    }

    // g(x) = sum_{t<x} D(t), where D(0)=0, D(t) = t*((k-1)*D(t-1) - k) / (n-t).
    ll km = k % MOD;
    ll km1 = (k - 1) % MOD;
    vector<ll> D(n + 1, 0), g(n + 1, 0);
    for (ll t = 1; t <= n - 1; t++) {
        ll val = (km1 * D[t - 1] % MOD - km + MOD) % MOD;
        D[t] = (ll)t % MOD * val % MOD * pw(n - t, MOD - 2) % MOD;
    }
    for (ll x = 1; x <= n; x++) g[x] = (g[x - 1] + D[x - 1]) % MOD;

    // Binomial weights w[t] = C(c,t) p^t q^(c-t), p = 1/k, q = (k-1)/k.
    vector<ll> fact(c + 1), ifact(c + 1);
    fact[0] = 1;
    for (ll i = 1; i <= c; i++) fact[i] = fact[i - 1] * i % MOD;
    ifact[c] = pw(fact[c], MOD - 2);
    for (ll i = c; i > 0; i--) ifact[i - 1] = ifact[i] * i % MOD;

    ll invk = pw(km, MOD - 2);
    ll q = km1 * invk % MOD;
    vector<ll> pp(c + 1), pq(c + 1);
    pp[0] = 1;
    pq[0] = 1;
    for (ll i = 1; i <= c; i++) {
        pp[i] = pp[i - 1] * invk % MOD;
        pq[i] = pq[i - 1] * q % MOD;
    }
    vector<ll> w(c + 1);
    for (ll t = 0; t <= c; t++) {
        w[t] = fact[c] * ifact[t] % MOD * ifact[c - t] % MOD * pp[t] % MOD * pq[c - t] % MOD;
    }

    // E[g(x + X)], X ~ Bin(c, 1/k).
    auto expectG = [&](ll x) -> ll {
        ull s = 0;
        for (ll t = 0; t <= c; t++) {
            s += (ull)w[t] * (ull)g[x + t] % MOD;
        }
        return (ll)(s % MOD);
    };

    // Sum over all k values v of E[g(count_v)].
    ll m0 = (ll)cnt.size();
    ll zeroVals = k - m0; // values with no fixed occurrence (fixed count 0)
    ll total = 0;
    for (auto &kv : cnt) {
        total = (total + expectG(kv.second)) % MOD;
    }
    total = (total + (zeroVals % MOD) * expectG(0)) % MOD;

    ll ans = ((total - g[n]) % MOD + MOD) % MOD;
    cout << ans << "\n";
    return 0;
}
