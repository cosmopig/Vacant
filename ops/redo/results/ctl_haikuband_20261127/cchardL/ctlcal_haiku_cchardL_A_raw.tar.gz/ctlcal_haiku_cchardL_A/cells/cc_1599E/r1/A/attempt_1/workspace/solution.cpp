// Two Arrays: range chmin / chmax / add on A1 or A2, range sum of F(A1_i + A2_i) mod 1e9+7.
// Approach: keep A1, A2 explicitly and cache fv[i] = F(A1_i + A2_i) mod p.
// Updates touch only the elements in [l, r] and recompute their cached Fibonacci value
// with fast doubling (O(log value) each). Sum queries add the cached values directly.
#include <bits/stdc++.h>
using namespace std;

static const long long MOD = 1000000007LL;

// F(n) mod MOD via fast doubling. n is non-negative and up to about 1e11.
static long long fib(long long n) {
    long long a = 0, b = 1;  // (F(k), F(k+1)) starting at k = 0
    for (int bit = 62; bit >= 0; --bit) {
        // Doubling: F(2k) = F(k) * (2F(k+1) - F(k)), F(2k+1) = F(k)^2 + F(k+1)^2
        long long t = (2 * b - a) % MOD;
        if (t < 0) t += MOD;
        long long c = a * t % MOD;
        long long d = (a * a + b * b) % MOD;
        if ((n >> bit) & 1LL) {
            a = d;
            b = (c + d) % MOD;
        } else {
            a = c;
            b = d;
        }
    }
    return a;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, q;
    cin >> n >> q;
    vector<long long> A[3];
    A[1].assign(n + 1, 0);
    A[2].assign(n + 1, 0);
    for (int i = 1; i <= n; ++i) cin >> A[1][i];
    for (int i = 1; i <= n; ++i) cin >> A[2][i];

    vector<long long> fv(n + 1, 0);
    for (int i = 1; i <= n; ++i) fv[i] = fib(A[1][i] + A[2][i]);

    string out;
    while (q--) {
        int t;
        cin >> t;
        if (t == 4) {
            int l, r;
            cin >> l >> r;
            long long s = 0;
            for (int i = l; i <= r; ++i) s += fv[i];
            s %= MOD;
            out += to_string(s);
            out += '\n';
            continue;
        }
        int k, l, r;
        long long x;
        cin >> k >> l >> r >> x;
        vector<long long>& arr = A[k];
        for (int i = l; i <= r; ++i) {
            long long old = arr[i];
            if (t == 1) arr[i] = min(arr[i], x);
            else if (t == 2) arr[i] = max(arr[i], x);
            else arr[i] += x;
            if (arr[i] != old) fv[i] = fib(A[1][i] + A[2][i]);
        }
    }
    cout << out;
    return 0;
}
