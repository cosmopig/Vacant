#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long u64;

// 0/1 principle: the algorithm sorts every input iff it sorts every 0/1 input.
// known = positions whose initial bit has been fixed by branching; ones = their current values (ones ⊆ known).
// Untouched positions are free (either bit). In a step with subsequence S, only the number c of ones among
// the still-unknown positions of S matters for the outcome, so branch on c in 0..x (x = #unknown in S).
// After sorting, the last (K + c) positions of S (K = #ones in S) hold 1 and the rest of S hold 0.

int n, k;
u64 full;
vector<u64> smask;
vector<vector<u64>> suf;  // suf[i][t] = mask of the last t positions of step i's subsequence

// Final array is sorted for every assignment of the free bits iff no position that can hold 0
// lies after the first position that can hold 1.
bool finalOk(u64 known, u64 ones) {
    u64 could1 = (ones | (full & ~known)) & full;
    u64 could0 = (~ones) & full;
    if (could1 == 0) return true;
    int low = __builtin_ctzll(could1);
    u64 above = full & ~((1ULL << (low + 1)) - 1);
    return (could0 & above) == 0;
}

bool rec(int i, u64 known, u64 ones) {
    if (i == k) return finalOk(known, ones);
    u64 mask = smask[i];
    int x = __builtin_popcountll(mask & ~known);
    int K = __builtin_popcountll(ones & mask);
    u64 base = ones & ~mask;
    u64 nk = known | mask;
    for (int c = 0; c <= x; c++) {
        if (!rec(i + 1, nk, base | suf[i][K + c])) return false;
    }
    return true;
}

int main() {
    if (!(cin >> n >> k)) return 0;
    full = (n == 64) ? ~0ULL : ((1ULL << n) - 1);
    smask.assign(k, 0);
    suf.assign(k, {});
    for (int i = 0; i < k; i++) {
        int q;
        cin >> q;
        vector<int> idx(q);
        for (int j = 0; j < q; j++) {
            cin >> idx[j];
            idx[j]--;
        }
        sort(idx.begin(), idx.end());
        idx.erase(unique(idx.begin(), idx.end()), idx.end());
        u64 m = 0;
        for (int j : idx) m |= 1ULL << j;
        smask[i] = m;
        int s = idx.size();
        suf[i].assign(s + 1, 0);
        for (int t = 1; t <= s; t++) suf[i][t] = suf[i][t - 1] | (1ULL << idx[s - t]);
    }
    cout << (rec(0, 0, 0) ? "ACCEPTED" : "REJECTED") << "\n";
    return 0;
}
