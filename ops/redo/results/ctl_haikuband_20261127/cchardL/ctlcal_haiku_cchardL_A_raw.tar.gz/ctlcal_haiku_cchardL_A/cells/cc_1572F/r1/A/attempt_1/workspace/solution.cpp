// Stations: sqrt decomposition.
//
// Let t_i be the time of the last rebuild of station i (0 if never rebuilt).
// Station i reaches j iff i <= j <= R_i, where R_i = min(w_i, nxt_i - 1) and
// nxt_i is the first k > i with h_k >= h_i. Initially R_i = i.
//
// Rebuild c (g): for all i < c, R_i = min(R_i, c - 1); then R_c = g.
// Query [l, r]: b_j = j - #{i : R_i < j}, so
//   sum_{j=l..r} b_j = sum j - sum_i clamp(r - max(l - 1, R_i), 0, L), L = r - l + 1.
//
// Blocks keep R values sorted, with a lazy cap (chmin for whole blocks).
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

struct Blk {
    vector<int> sv;   // sorted base values
    vector<int> si;   // index for each sorted entry
    vector<ll> P;     // prefix sums of sv
    int cap;          // lazy cap: effective value = min(base, cap)
    int k;            // number of base values < cap (they are the non-capped prefix)
};

static int n, B, nb;
static vector<Blk> blk;
static vector<pair<int, int>> bufA, bufM, bufB;

static void recomputeP(Blk &b) {
    int N = b.sv.size();
    b.P.assign(N + 1, 0);
    for (int t = 0; t < N; t++) b.P[t + 1] = b.P[t] + b.sv[t];
}

static void rebuildPartial(int bc, int c, int g) {
    Blk &b = blk[bc];
    int lim = c - 1;
    if (b.cap <= n) {  // push lazy cap down
        for (int &v : b.sv) v = min(v, b.cap);
        b.cap = n + 1;
    }
    bufA.clear(); bufM.clear(); bufB.clear();
    int N = b.sv.size();
    for (int t = 0; t < N; t++) {
        int v = b.sv[t], idx = b.si[t];
        if (idx == c) continue;               // will be re-inserted with value g
        if (v <= lim) bufA.push_back({v, idx});
        else if (idx < c) bufM.push_back({lim, idx});
        else bufB.push_back({v, idx});
    }
    b.sv.clear(); b.si.clear();
    for (auto &p : bufA) { b.sv.push_back(p.first); b.si.push_back(p.second); }
    for (auto &p : bufM) { b.sv.push_back(p.first); b.si.push_back(p.second); }
    for (auto &p : bufB) { b.sv.push_back(p.first); b.si.push_back(p.second); }
    // insert (g, c) keeping sorted order by value
    int pos = lower_bound(b.sv.begin(), b.sv.end(), g) - b.sv.begin();
    b.sv.insert(b.sv.begin() + pos, g);
    b.si.insert(b.si.begin() + pos, c);
    b.k = b.sv.size();
    recomputeP(b);
}

static void update(int c, int g) {
    int lim = c - 1;
    int bc = (c - 1) / B;
    for (int b = 0; b < bc; b++) {
        Blk &blkb = blk[b];
        if (blkb.cap > lim) {
            blkb.cap = lim;
            blkb.k = lower_bound(blkb.sv.begin(), blkb.sv.end(), lim) - blkb.sv.begin();
        }
    }
    rebuildPartial(bc, c, g);
}

static ll query(int l, int r) {
    ll L = r - l + 1;
    ll total = 0;
    for (int bi = 0; bi < nb; bi++) {
        const Blk &b = blk[bi];
        int N = b.sv.size();
        int k = b.k;
        // base values below cap: exact values
        int p1 = upper_bound(b.sv.begin(), b.sv.begin() + k, l - 1) - b.sv.begin();
        int p2 = upper_bound(b.sv.begin(), b.sv.begin() + k, r) - b.sv.begin();
        total += (ll)p1 * L + (ll)(p2 - p1) * r - (b.P[p2] - b.P[p1]);
        if (N > k) {
            ll h = (ll)r - b.cap;
            if (h < 0) h = 0;
            if (h > L) h = L;
            total += (ll)(N - k) * h;
        }
    }
    return (ll)(l + r) * L / 2 - total;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int q;
    cin >> n >> q;
    B = 1024;
    nb = (n + B - 1) / B;
    blk.resize(nb);
    for (int bi = 0; bi < nb; bi++) {
        int s = bi * B + 1, e = min(n, (bi + 1) * B);
        Blk &b = blk[bi];
        for (int i = s; i <= e; i++) {
            b.sv.push_back(i);
            b.si.push_back(i);
        }
        b.cap = n + 1;
        b.k = b.sv.size();
        recomputeP(b);
    }
    string out;
    out.reserve(1 << 20);
    while (q--) {
        int p;
        cin >> p;
        if (p == 1) {
            int c, g;
            cin >> c >> g;
            update(c, g);
        } else {
            int l, r;
            cin >> l >> r;
            out += to_string(query(l, r));
            out += '\n';
        }
    }
    cout << out;
    return 0;
}
