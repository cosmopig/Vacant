// Artistic Partition.
//
// Derivation (summary):
//   c(l,r) = (r-l+1) + G(l,r),  G(l,r) = sum_{D=l}^{r/2} Phi(floor(r/D)),
//   Phi(m) = sum_{b=2}^{m} phi(b).
//   f(n,k) = n + min over partitions of [1..n] into k segments of sum G(l_s, r_s).
//   Segments with r < 2l have G = 0, and the segments [2^i, 2^{i+1}-1] cover [1..1e5]
//   with 17 segments, so for k >= 17 the answer is n.
//   dp_j[r] = min_l dp_{j-1}[l-1] + G(l,r).
//   G(l,r) for fixed l as r grows changes only by adding phi(r/x) to all l <= x,
//   for each proper divisor x of r. So each DP layer is a segment tree over l with
//   prefix adds and prefix-min queries.

#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

static const ll INF = (ll)1e18;

static int SZ;                 // number of leaves (power of two)
static vector<ll> mn, ad;      // min over subtree (excluding ancestors' adds), lazy add

static void build(const vector<ll>& base) {
    // base indexed by position 0..SZ-1
    for (int i = 0; i < SZ; i++) { mn[SZ + i] = base[i]; ad[SZ + i] = 0; }
    for (int i = SZ - 1; i >= 1; i--) {
        mn[i] = min(mn[2 * i], mn[2 * i + 1]);
        ad[i] = 0;
    }
}

// add v to positions [0, qr] (inclusive)
static void addPrefix(int node, int nl, int nr, int qr, ll v) {
    if (nl > qr) return;
    if (nr <= qr) {
        mn[node] += v;
        ad[node] += v;
        return;
    }
    int mid = (nl + nr) / 2;
    addPrefix(2 * node, nl, mid, qr, v);
    addPrefix(2 * node + 1, mid + 1, nr, qr, v);
    mn[node] = min(mn[2 * node], mn[2 * node + 1]) + ad[node];
}

// min over positions [0, qr]
static ll queryPrefix(int node, int nl, int nr, int qr) {
    if (nl > qr) return INF;
    if (nr <= qr) return mn[node];
    int mid = (nl + nr) / 2;
    ll a = queryPrefix(2 * node, nl, mid, qr);
    ll b = queryPrefix(2 * node + 1, mid + 1, nr, qr);
    return min(a, b) + ad[node];
}

int main() {
    // ---- read all input ----
    int t;
    if (scanf("%d", &t) != 1) return 0;
    vector<int> qn(t), qk(t);
    int N = 1, maxk = 1;
    for (int i = 0; i < t; i++) {
        scanf("%d %d", &qn[i], &qk[i]);
        N = max(N, qn[i]);
        maxk = max(maxk, qk[i]);
    }

    const int KCAP = 16;  // for k >= 17 the answer is n (see above)
    int K = min(maxk, KCAP);

    // ---- phi and divisor lists (proper divisors x of r, with weight phi(r/x)) ----
    vector<int> phi(N + 1);
    for (int i = 0; i <= N; i++) phi[i] = i;
    for (int p = 2; p <= N; p++)
        if (phi[p] == p)
            for (int m = p; m <= N; m += p) phi[m] -= phi[m] / p;

    // CSR storage: for each r, entries (x, phi[r/x]) for x | r, x < r
    vector<int> cnt(N + 2, 0);
    for (int x = 1; x <= N; x++)
        for (int m = 2 * x; m <= N; m += x) cnt[m]++;
    vector<int> start(N + 2, 0);
    for (int r = 1; r <= N; r++) start[r + 1] = start[r] + cnt[r];
    vector<int> dx(start[N + 1]), dw(start[N + 1]);
    {
        vector<int> fill(start.begin(), start.end());
        for (int x = 1; x <= N; x++)
            for (int m = 2 * x; m <= N; m += x) {
                dx[fill[m]] = x;
                dw[fill[m]] = phi[m / x];
                fill[m]++;
            }
    }

    // ---- DP layers ----
    // dpPrev[r] = dp_{j-1}[r], dpCur[r] = dp_j[r]
    vector<vector<ll>> dp(K + 1, vector<ll>(N + 1, INF));
    dp[0][0] = 0;

    SZ = 1;
    while (SZ < N) SZ <<= 1;
    mn.assign(2 * SZ, INF);
    ad.assign(2 * SZ, 0);
    vector<ll> base(SZ, INF);

    for (int j = 1; j <= K; j++) {
        // base position l-1 holds dp_{j-1}[l-1]; position index p = l-1
        for (int p = 0; p < SZ; p++) {
            int l = p + 1;
            base[p] = (l <= N) ? dp[j - 1][l - 1] : INF;
        }
        build(base);
        for (int r = 1; r <= N; r++) {
            // G(., r) = G(., r-1) + sum over proper divisors x of r: phi(r/x) on l <= x
            for (int e = start[r]; e < start[r + 1]; e++) {
                int x = dx[e];
                // positions l in [1..x] -> indices [0..x-1]
                addPrefix(1, 0, SZ - 1, x - 1, (ll)dw[e]);
            }
            // dp_j[r] = min over l in [1..r] of dp_{j-1}[l-1] + G(l,r)
            // indices [0..r-1]
            ll v = queryPrefix(1, 0, SZ - 1, r - 1);
            dp[j][r] = (v >= INF / 2) ? INF : v;
        }
    }

    // ---- answer queries ----
    string out;
    out.reserve((size_t)t * 12);
    char buf[32];
    for (int i = 0; i < t; i++) {
        int n = qn[i], k = qk[i];
        ll ans;
        if (k > KCAP) {
            ans = n;  // k >= 17: free partition exists
        } else {
            ans = (ll)n + dp[k][n];
        }
        int len = sprintf(buf, "%lld\n", ans);
        out.append(buf, len);
    }
    fputs(out.c_str(), stdout);
    return 0;
}
