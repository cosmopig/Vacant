#include <bits/stdc++.h>
using namespace std;

// Segment [l,r] is simple iff for every prime p and every j in [l,r]:
//   E_p(j) >= E_p(l-1), where E_p(t) is the prefix sum of signed exponents
//   of p (+v_p(a_k) for '*', -v_p(a_k) for '/') over positions 1..t.
// For each l let R(l) = first j >= l where some prime's constraint fails
// (n+1 if never). Answer = sum over l of (R(l) - l).
// Per prime, E_p is piecewise constant between event positions; each
// constant piece gives a range of l values that all share one kill time
// (the next event whose level drops below the piece's level). We collect
// these (range, kill) pairs and assign R(l) = min kill covering l by
// processing kills in increasing order with a DSU "next unassigned" skip.

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;
    vector<int> a(n + 1);
    for (int i = 1; i <= n; i++) cin >> a[i];
    string b;
    cin >> b;  // b[i-1] is the symbol for position i

    const int MAXV = 1000000;
    vector<int> spf(MAXV + 1, 0);
    for (int i = 2; i <= MAXV; i++) {
        if (spf[i] == 0) {
            for (long long j = i; j <= MAXV; j += i)
                if (spf[j] == 0) spf[j] = i;
        }
    }

    // Count events per prime (two passes, CSR layout, time-ordered per prime).
    vector<int> cnt(MAXV + 2, 0);
    for (int k = 1; k <= n; k++) {
        int x = a[k];
        while (x > 1) {
            int p = spf[x];
            cnt[p]++;
            while (x % p == 0) x /= p;
        }
    }
    vector<int> start(MAXV + 2, 0);
    for (int p = 1; p <= MAXV; p++) start[p + 1] = start[p] + cnt[p];
    int total = start[MAXV + 1];
    vector<int> evT(total), evD(total);
    vector<int> fillPos(start.begin(), start.end());
    for (int k = 1; k <= n; k++) {
        int x = a[k];
        int sign = (b[k - 1] == '*') ? 1 : -1;
        while (x > 1) {
            int p = spf[x];
            int e = 0;
            while (x % p == 0) {
                x /= p;
                e++;
            }
            int idx = fillPos[p]++;
            evT[idx] = k;
            evD[idx] = sign * e;
        }
    }

    // Ranges: (kill time, lo, hi) meaning every l in [lo,hi] fails at 'kill'.
    struct Range {
        int kill, lo, hi;
    };
    vector<Range> ranges;
    ranges.reserve(total + 16);

    vector<int> T, L, stk;
    for (int p = 2; p <= MAXV; p++) {
        int m = cnt[p];
        if (m == 0) continue;
        int base = start[p];
        // Pieces k = 0..m: piece k has level L[k] for s = l-1 in [T[k], T[k+1]-1].
        T.assign(m + 2, 0);
        L.assign(m + 1, 0);
        T[0] = 0;
        L[0] = 0;
        for (int i = 1; i <= m; i++) {
            T[i] = evT[base + i - 1];
            L[i] = L[i - 1] + evD[base + i - 1];
        }
        T[m + 1] = n;
        // Next strictly-smaller level to the right for each piece.
        stk.clear();
        for (int k = m; k >= 0; k--) {
            while (!stk.empty() && L[stk.back()] >= L[k]) stk.pop_back();
            if (!stk.empty()) {
                int j = stk.back();
                // Piece k covers l in [T[k]+1, T[k+1]]; kill at event time T[j].
                ranges.push_back({T[j], T[k] + 1, T[k + 1]});
            }
            stk.push_back(k);
        }
    }

    sort(ranges.begin(), ranges.end(),
         [](const Range& x, const Range& y) { return x.kill < y.kill; });

    // DSU over positions 1..n+1: find(x) = smallest unassigned position >= x.
    vector<int> nxt(n + 3);
    for (int i = 0; i <= n + 2; i++) nxt[i] = i;
    auto find = [&](int x) {
        int r = x;
        while (nxt[r] != r) r = nxt[r];
        while (nxt[x] != r) {
            int t = nxt[x];
            nxt[x] = r;
            x = t;
        }
        return r;
    };

    vector<int> R(n + 2, n + 1);
    for (const Range& rg : ranges) {
        int x = find(rg.lo);
        while (x <= rg.hi) {
            R[x] = rg.kill;
            nxt[x] = x + 1;
            x = find(x + 1);
        }
    }

    long long ans = 0;
    for (int l = 1; l <= n; l++) ans += R[l] - l;
    cout << ans << "\n";
    return 0;
}
