// Count sequences a_1..a_n in [0,2^k) with no nonempty subsequence XORing to x (mod 998244353).
//
// x = 0: the a_i must be linearly independent over GF(2): prod_{i<n} (2^k - 2^i), 0 if n > k.
// x != 0: x must not lie in the span V of the a_i. If dim V = d, the number of subspaces of
//   dimension d avoiding x is 2^d * [k-1 choose d]_2, and the number of n-tuples spanning a fixed
//   d-dim space is prod_{i<d} (2^n - 2^i). So
//   answer = sum_{d=0}^{min(n,k-1)} 2^d * [k-1 choose d]_2 * prod_{i<d} (2^n - 2^i).
// The Gaussian binomial is updated incrementally: [m,d] = [m,d-1] * (2^{m-d+1}-1) / (2^d-1).

#include <bits/stdc++.h>
using namespace std;

static const uint64_t MOD = 998244353ULL;

static uint64_t modpow(uint64_t b, uint64_t e) {
    uint64_t r = 1;
    b %= MOD;
    while (e) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    vector<array<long long, 3>> tests(t);
    long long maxK = 0;
    for (auto &tc : tests) {
        cin >> tc[0] >> tc[1] >> tc[2];
        maxK = max(maxK, tc[1]);
    }

    // pw[i] = 2^i mod p, inv[d] = (2^d - 1)^{-1} mod p, for 0 <= i <= maxK, 1 <= d <= maxK.
    const size_t N = (size_t)maxK + 1;
    vector<uint32_t> pw(N), inv(N, 0);
    pw[0] = 1;
    for (size_t i = 1; i < N; i++) pw[i] = (uint32_t)(pw[i - 1] * 2 % MOD);

    if (maxK >= 1) {
        // Batch inversion of den[d] = 2^d - 1 using prefix products stored in inv.
        vector<uint32_t> pre(N, 1);
        for (size_t d = 1; d < N; d++) {
            uint64_t den = (pw[d] + MOD - 1) % MOD;
            pre[d] = (uint32_t)(pre[d - 1] * den % MOD);
        }
        uint64_t cur = modpow(pre[N - 1], MOD - 2);
        for (size_t d = N - 1; d >= 1; d--) {
            uint64_t den = (pw[d] + MOD - 1) % MOD;
            inv[d] = (uint32_t)(cur * pre[d - 1] % MOD);
            cur = cur * den % MOD;
        }
    }

    string out;
    out.reserve((size_t)t * 12);
    for (auto &tc : tests) {
        long long n = tc[0], k = tc[1], x = tc[2];
        uint64_t ans = 0;
        if (x == 0) {
            if (n > k) {
                ans = 0;
            } else {
                ans = 1;
                for (long long i = 0; i < n; i++) {
                    uint64_t term = (pw[k] + MOD - pw[i]) % MOD;
                    ans = ans * term % MOD;
                }
            }
        } else {
            // here k >= 1 because x < 2^min(20,k) and x != 0
            long long m = k - 1;
            long long D = min(n, m);
            uint64_t p2n = modpow(2, (uint64_t)n);
            uint64_t G = 1;  // [m, d]_2
            uint64_t P = 1;  // prod_{i<d} (2^n - 2^i)
            ans = 1;         // d = 0 term
            for (long long d = 1; d <= D; d++) {
                uint64_t num = (pw[k - d] + MOD - 1) % MOD;
                G = G * num % MOD * inv[d] % MOD;
                P = P * ((p2n + MOD - pw[d - 1]) % MOD) % MOD;
                uint64_t term = (uint64_t)pw[d] * G % MOD * P % MOD;
                ans += term;
                if (ans >= MOD) ans -= MOD;
            }
        }
        out += to_string(ans);
        out += '\n';
    }
    cout << out;
    return 0;
}
