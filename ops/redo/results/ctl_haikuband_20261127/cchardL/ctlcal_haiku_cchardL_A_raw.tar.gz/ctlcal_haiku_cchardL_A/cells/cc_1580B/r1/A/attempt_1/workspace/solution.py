import sys


def main():
    n, m, k, p = map(int, sys.stdin.read().split())

    # x is good iff the number of distinct maxima of subsegments containing x
    # equals the depth of x in the max-Cartesian tree (root depth 1), since the
    # maxima are exactly the ancestors of x. So we count permutations in which
    # exactly k nodes lie at depth m.
    #
    # P[s][d] = polynomial in y: sum_j (#perms of length s whose Cartesian tree
    # hangs at absolute depth d, with exactly j nodes at depth m) y^j.
    # Packed as a big integer with B-bit slots (Kronecker substitution).
    B = 112
    L = n + 2
    NBYTES = (B // 8) * L
    SLOT = B // 8

    def pack_reduced(coeffs):
        return int.from_bytes(b"".join((c % p).to_bytes(SLOT, "little") for c in coeffs), "little")

    def unpack_reduced(x):
        b = x.to_bytes(NBYTES, "little")
        return [int.from_bytes(b[SLOT * i:SLOT * (i + 1)], "little") % p for i in range(L)]

    fact = [1] * (n + 1)
    for i in range(1, n + 1):
        fact[i] = fact[i - 1] * i % p

    # binomials mod p
    C = [[0] * (n + 1) for _ in range(n + 1)]
    for i in range(n + 1):
        C[i][0] = 1 % p
        for j in range(1, i + 1):
            C[i][j] = (C[i - 1][j - 1] + C[i - 1][j]) % p

    # Depth d > m: no depth-m nodes inside, polynomial is constant s!.
    below = [pack_reduced([fact[s]] + [0] * (L - 1)) for s in range(n + 1)]
    nxt = below
    for d in range(m, 0, -1):
        cur = [0] * (n + 1)
        cur[0] = pack_reduced([1] + [0] * (L - 1))
        for s in range(1, n + 1):
            acc = 0
            for a in range(s):
                b = s - 1 - a
                if a > b:
                    break
                w = C[s - 1][a] if a == b else 2 * C[s - 1][a]
                if w % p == 0:
                    continue
                acc += w * (nxt[a] * nxt[b])
            if d == m:
                acc <<= B  # root itself is at depth m: multiply by y
            cur[s] = pack_reduced(unpack_reduced(acc)) if acc else 0
        nxt = cur

    coeffs = unpack_reduced(nxt[n])
    ans = coeffs[k] % p if k < len(coeffs) else 0
    print(ans)


if __name__ == "__main__":
    main()
