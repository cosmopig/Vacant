import sys


def main():
    data = sys.stdin.buffer.read().split()
    MOD = 10**9 + 7
    n = int(data[0])
    a = [0] * (n + 1)
    b = [0] * (n + 1)
    T = 2 * n
    owner = [0] * (T + 2)  # owner[time] = task whose b-time is `time`
    idx = 1
    for k in range(1, n + 1):
        a[k] = int(data[idx])
        b[k] = int(data[idx + 1])
        idx += 2
        owner[b[k]] = k
    t = int(data[idx])
    idx += 1
    inS = [False] * (n + 1)
    for i in range(t):
        inS[int(data[idx + i])] = True

    # nxt_b[p] = smallest b-time >= p (or T+1 if none)
    nxt_b = [T + 1] * (T + 3)
    for p in range(T, 0, -1):
        nxt_b[p] = p if owner[p] else nxt_b[p + 1]

    comp = [False] * (n + 1)
    stack = []          # completed tasks, sorted by a ascending
    cntS = 0
    count = 0
    p = 0
    while True:
        tm = nxt_b[p + 1] if p + 1 <= T else T + 1
        if tm > T:
            break
        k = owner[tm]
        if not comp[k]:
            count += 1
            ak = a[k]
            while stack and a[stack[-1]] > ak:
                j = stack.pop()
                comp[j] = False
                if inS[j]:
                    cntS -= 1
            comp[k] = True
            stack.append(k)
            if inS[k]:
                cntS += 1
            if cntS == t:
                break
            p = ak
        else:
            p = tm
    print(count % MOD)


main()
