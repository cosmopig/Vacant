// Sum of f(u,v) over unordered tours (u <= v) whose path uses at most K colour switches.
// Approach: centroid decomposition. For a centroid c, every vertex x in its component gives a
// "half" (S_x = sum of a over path x..c excluding c, s_x = switches on path c..x, col_x = colour of the
// edge at c). A pair of halves (x,y) through c is valid iff s_x + s_y + [col_x != col_y] <= K.
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
static const ll MOD = 1000000007LL;

struct Item {
    ll S;   // sum of a over the half path (mod MOD), excluding the centroid
    int s;  // colour switches inside the half path
    int col; // colour of the first edge (adjacent to centroid)
};

static int n, K;
static vector<ll> A;
static vector<vector<pair<int, int>>> adj;  // (neighbour, colour)
static vector<char> removed_;
static vector<int> sz_, par_;
static vector<Item> itm;
static vector<int> pr;

// Sum over ordered pairs (x, y) of items (including x == y) that are valid, of S_x + S_y + ac.
static ll calc(const vector<Item>& items, ll ac) {
    if (items.empty()) return 0;
    int maxS = 0;
    for (const auto& it : items) maxS = max(maxS, it.s);
    vector<ll> cnt[2], sm[2];
    for (int q = 0; q < 2; q++) {
        cnt[q].assign(maxS + 1, 0);
        sm[q].assign(maxS + 1, 0);
    }
    for (const auto& it : items) {
        cnt[it.col][it.s] += 1;
        sm[it.col][it.s] = (sm[it.col][it.s] + it.S) % MOD;
    }
    for (int q = 0; q < 2; q++)
        for (int i = 1; i <= maxS; i++) {
            cnt[q][i] += cnt[q][i - 1];
            sm[q][i] = (sm[q][i] + sm[q][i - 1]) % MOD;
        }
    ll total = 0;
    for (const auto& x : items) {
        for (int q = 0; q < 2; q++) {
            int d = (x.col == q) ? 0 : 1;
            ll T = (ll)K - x.s - d;  // need s_y <= T
            if (T < 0) continue;
            int idx = (int)min<ll>(T, (ll)maxS);
            ll C = cnt[q][idx] % MOD;
            ll SS = sm[q][idx];
            total = (total + x.S * C % MOD + SS + ac * C % MOD) % MOD;
        }
    }
    return total;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cin >> n >> K;
    A.assign(n, 0);
    ll ans = 0;
    for (int i = 0; i < n; i++) {
        ll v;
        cin >> v;
        A[i] = ((v % MOD) + MOD) % MOD;
        ans = (ans + A[i]) % MOD;  // single-attraction tours (0 switches, always valid)
    }
    adj.assign(n, {});
    for (int i = 0; i < n - 1; i++) {
        int u, v, t;
        cin >> u >> v >> t;
        u--; v--;
        adj[u].push_back({v, t});
        adj[v].push_back({u, t});
    }

    removed_.assign(n, 0);
    sz_.assign(n, 0);
    par_.assign(n, -1);
    itm.assign(n, Item{0, 0, 0});
    pr.assign(n, -1);
    const ll inv2 = (MOD + 1) / 2;

    vector<int> stk;
    stk.push_back(0);
    vector<int> order;
    while (!stk.empty()) {
        int r = stk.back();
        stk.pop_back();

        // BFS the component of r.
        order.clear();
        order.push_back(r);
        par_[r] = -1;
        for (size_t i = 0; i < order.size(); i++) {
            int u = order[i];
            for (auto [v, t] : adj[u]) {
                (void)t;
                if (!removed_[v] && v != par_[u]) {
                    par_[v] = u;
                    order.push_back(v);
                }
            }
        }
        int tot = (int)order.size();
        for (int u : order) sz_[u] = 1;
        for (int i = tot - 1; i >= 1; i--) sz_[par_[order[i]]] += sz_[order[i]];

        // Find centroid.
        int c = r;
        while (true) {
            bool moved = false;
            for (auto [v, t] : adj[c]) {
                (void)t;
                if (!removed_[v] && v != par_[c] && sz_[v] > tot / 2) {
                    c = v;
                    moved = true;
                    break;
                }
            }
            if (!moved) break;
        }

        // Collect halves per child subtree of c.
        vector<vector<Item>> groups;
        for (auto [w, tw] : adj[c]) {
            if (removed_[w]) continue;
            vector<Item> grp;
            vector<int> q;
            q.push_back(w);
            pr[w] = c;
            itm[w] = Item{A[w], 0, tw};
            for (size_t i = 0; i < q.size(); i++) {
                int u = q[i];
                grp.push_back(itm[u]);
                for (auto [v, tc] : adj[u]) {
                    if (removed_[v] || v == pr[u]) continue;
                    pr[v] = u;
                    Item cur = itm[u];
                    Item nx;
                    nx.S = (cur.S + A[v]) % MOD;
                    nx.s = cur.s + (tc != cur.col ? 1 : 0);
                    nx.col = cur.col;
                    itm[v] = nx;
                    q.push_back(v);
                }
            }
            groups.push_back(move(grp));
        }

        vector<Item> all;
        for (auto& g : groups) all.insert(all.end(), g.begin(), g.end());

        ll ac = A[c];
        ll gAll = calc(all, ac);
        ll gGroups = 0;
        for (auto& g : groups) gGroups = (gGroups + calc(g, ac)) % MOD;
        // Ordered cross pairs between different groups (both orders), halved.
        ll cross = ((gAll - gGroups) % MOD + MOD) % MOD * inv2 % MOD;
        // Pairs (x, c): valid iff s_x <= K; value S_x + a_c.
        ll extra = 0;
        for (const auto& x : all)
            if (x.s <= K) extra = (extra + x.S + ac) % MOD;
        ans = (ans + cross + extra) % MOD;

        removed_[c] = 1;
        for (auto [w, tw] : adj[c]) {
            (void)tw;
            if (!removed_[w]) stk.push_back(w);
        }
    }

    ans = ((ans % MOD) + MOD) % MOD;
    cout << ans << "\n";
    return 0;
}
