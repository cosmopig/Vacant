# Subsequences Galore

Time limit per test: 10 seconds. Memory limit: 977 MB.

Write a program in Python 3 or C++17 that reads from standard input and writes to standard output.

For a sequence of strings [t_1, t_2, ..., t_m], let's define the function f([t_1, t_2, ..., t_m]) as the number of different strings (including the empty string) that are subsequences of at least one string t_i. f([]) = 0 (i. e. the number of such strings for an empty sequence is 0).

You are given a sequence of strings [s_1, s_2, ..., s_n]. Every string in this sequence consists of lowercase Latin letters and is sorted (i. e., each string begins with several (maybe zero) characters a, then several (maybe zero) characters b, ..., ends with several (maybe zero) characters z).

For each of 2^n subsequences of [s_1, s_2, ..., s_n], calculate the value of the function f modulo 998244353.

Input

The first line contains one integer n (1 ≤ n ≤ 23) — the number of strings.

Then n lines follow. The i-th line contains the string s_i (1 ≤ |s_i| ≤ 2 ⋅ 10^4), consisting of lowercase Latin letters. Each string s_i is sorted.

Output

Since printing up to 2^{23} integers would be really slow, you should do the following:

For each of the 2^n subsequences (which we denote as [s_{i_1}, s_{i_2}, ..., s_{i_k}]), calculate f([s_{i_1}, s_{i_2}, ..., s_{i_k}]), take it modulo 998244353, then multiply it by k ⋅ (i_1 + i_2 + ... + i_k). Print the XOR of all 2^n integers you get.

The indices i_1, i_2, ..., i_k in the description of each subsequences are 1-indexed (i. e. are from 1 to n).

Examples

Input


3
a
b
c


Output


92


Input


2
aa
a


Output


21


Input


2
a
a


Output


10


Input


2
abcd
aabb


Output


124


Input


3
ddd
aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
aaaaaaaabbbbbbbbbbbcccccccccccciiiiiiiiiiiiiiiiiiiiiiooooooooooqqqqqqqqqqqqqqqqqqvvvvvzzzzzzzzzzzz


Output


15706243380
