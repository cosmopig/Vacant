#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int n, m;
vector<ll> A, B;
vector<vector<int>> adj;

// Can the hero, starting with power p, beat every monster?
bool check(ll p) {
    vector<char> inS(n + 1, 0);
    vector<int> par(n + 1, -1);
    vector<char> reached(n + 1, 0);
    vector<ll> pw(n + 1, 0);
    inS[1] = 1;
    ll cur = p + B[1];
    int cnt = 1;

    auto addChain = [&](int x) {
        // Add all not-yet-owned vertices on the tree path from x back to S.
        while (!inS[x]) {
            inS[x] = 1;
            cur += B[x];
            ++cnt;
            x = par[x];
        }
    };

    while (cnt < n) {
        fill(reached.begin(), reached.end(), 0);
        fill(par.begin(), par.end(), -1);
        vector<int> q;
        q.reserve(n);
        int found = -1;      // a vertex whose chain should be added
        int found2 = -1;    // optional second chain
        bool ok = false;

        // Seed BFS from every vertex in S.
        for (int u = 1; u <= n && !ok; ++u) {
            if (!inS[u]) continue;
            for (int v : adj[u]) {
                if (inS[v]) continue;
                if (reached[v]) {
                    if (par[v] != u) {  // second entry into v from S: augment
                        found = v;
                        ok = true;
                        break;
                    }
                    continue;
                }
                if (cur > A[v]) {
                    reached[v] = 1;
                    par[v] = u;
                    pw[v] = cur + B[v];
                    q.push_back(v);
                }
            }
        }

        size_t head = 0;
        while (!ok && head < q.size()) {
            int x = q[head++];
            for (int y : adj[x]) {
                if (y == par[x]) continue;
                if (par[y] == x) continue;  // same tunnel as the tree edge
                if (inS[y]) {
                    found = x;
                    ok = true;
                    break;
                }
                if (reached[y]) {
                    found = x;
                    found2 = y;
                    ok = true;
                    break;
                }
                if (pw[x] > A[y]) {
                    reached[y] = 1;
                    par[y] = x;
                    pw[y] = pw[x] + B[y];
                    q.push_back(y);
                }
            }
        }

        if (!ok) return false;
        addChain(found);
        if (found2 != -1) addChain(found2);
    }
    return true;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin >> t;
    while (t--) {
        cin >> n >> m;
        A.assign(n + 1, 0);
        B.assign(n + 1, 0);
        for (int i = 2; i <= n; ++i) cin >> A[i];
        for (int i = 2; i <= n; ++i) cin >> B[i];
        adj.assign(n + 1, {});
        for (int i = 0; i < m; ++i) {
            int u, v;
            cin >> u >> v;
            adj[u].push_back(v);
            adj[v].push_back(u);
        }
        ll lo = 1, hi = 0;
        for (int i = 2; i <= n; ++i) hi = max(hi, A[i]);
        hi += 1;  // this power always suffices
        while (lo < hi) {
            ll mid = lo + (hi - lo) / 2;
            if (check(mid)) hi = mid;
            else lo = mid + 1;
        }
        cout << lo << "\n";
    }
    return 0;
}
