#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin >> t;
    while (t--) {
        int n;
        cin >> n;
        vector<int> raw(n);
        for (auto &x : raw) cin >> x;
        // compress consecutive duplicates
        vector<int> a;
        for (int x : raw)
            if (a.empty() || a.back() != x) a.push_back(x);
        int m = a.size();
        // positions of each color (after compression)
        // nxt[i] = list of j > i with a[j] == a[i]
        map<int, vector<int>> pos;
        for (int i = 0; i < m; i++) pos[a[i]].push_back(i);
        vector<vector<int>> nxt(m);
        for (auto &[c, v] : pos)
            for (size_t k = 0; k < v.size(); k++)
                for (size_t q = k + 1; q < v.size(); q++)
                    nxt[v[k]].push_back(v[q]);
        // dp[l][r] = max savings on segment [l, r]
        // dp[l][r] = max(dp[l+1][r], max_{j in nxt[l], j<=r} dp[l+1][j-1] + 1 + dp[j][r])
        vector<vector<int>> dp(m + 1, vector<int>(m + 1, 0));
        for (int l = m - 1; l >= 0; l--) {
            for (int r = l + 1; r < m; r++) {
                int best = dp[l + 1][r];
                for (int j : nxt[l]) {
                    if (j > r) break;  // nxt[l] is increasing
                    int inner = (j - 1 >= l + 1) ? dp[l + 1][j - 1] : 0;
                    int cand = inner + 1 + dp[j][r];
                    if (cand > best) best = cand;
                }
                dp[l][r] = best;
            }
        }
        int savings = m >= 2 ? dp[0][m - 1] : 0;
        cout << (m - 1) - savings << "\n";
    }
    return 0;
}
