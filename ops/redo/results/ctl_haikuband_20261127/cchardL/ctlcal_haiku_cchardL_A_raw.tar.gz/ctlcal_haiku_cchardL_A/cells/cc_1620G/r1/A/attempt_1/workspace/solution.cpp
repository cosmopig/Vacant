#include <bits/stdc++.h>
using namespace std;

static const uint32_t MOD = 998244353u;

int n;
int cnt[23][26];
vector<uint32_t> g;        // g[T] = prod_x (1 + min_{i in T} cnt[i][x]) mod MOD
// Stack of current per-letter minima, one row of 26 per recursion depth.
int mins_stack[24][26];

void rec(int i, int mask) {
    if (i == n) {
        if (mask == 0) return;
        const int* m = mins_stack[i];
        uint64_t prod = 1;
        for (int x = 0; x < 26; x++) {
            prod = prod * (uint64_t)(1 + m[x]) % MOD;
        }
        g[mask] = (uint32_t)prod;
        return;
    }
    // Exclude string i: same minima.
    memcpy(mins_stack[i + 1], mins_stack[i], sizeof(int) * 26);
    rec(i + 1, mask);
    // Include string i: take componentwise min with cnt[i].
    if (mask == 0) {
        for (int x = 0; x < 26; x++) mins_stack[i + 1][x] = cnt[i][x];
    } else {
        for (int x = 0; x < 26; x++)
            mins_stack[i + 1][x] = min(mins_stack[i][x], cnt[i][x]);
    }
    rec(i + 1, mask | (1 << i));
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cin >> n;
    for (int i = 0; i < n; i++) {
        string s;
        cin >> s;
        memset(cnt[i], 0, sizeof(cnt[i]));
        for (char c : s) cnt[i][c - 'a']++;
    }

    const uint32_t full = 1u << n;
    g.assign(full, 0);
    for (int x = 0; x < 26; x++) mins_stack[0][x] = INT_MAX / 2;
    rec(0, 0);

    // h[T] = (-1)^{|T|+1} g[T] for nonempty T; h[0] = 0.
    // f(S) = sum_{T subset of S} h[T]  (zeta transform over subsets).
    vector<uint32_t>& h = g;
    h[0] = 0;
    for (uint32_t T = 1; T < full; T++) {
        if (__builtin_popcount(T) & 1) {
            // sign +: keep
        } else {
            h[T] = (h[T] == 0) ? 0 : MOD - h[T];
        }
    }
    for (int b = 0; b < n; b++) {
        uint32_t bit = 1u << b;
        for (uint32_t S = 0; S < full; S++) {
            if (S & bit) {
                uint32_t v = h[S] + h[S ^ bit];
                if (v >= MOD) v -= MOD;
                h[S] = v;
            }
        }
    }

    // Sum of 1-indexed positions for each mask.
    vector<uint16_t> sumidx(full, 0);
    for (uint32_t S = 1; S < full; S++) {
        int b = __builtin_ctz(S);
        sumidx[S] = (uint16_t)(sumidx[S & (S - 1)] + b + 1);
    }

    uint64_t ans = 0;
    for (uint32_t S = 1; S < full; S++) {
        uint64_t f = h[S];
        uint64_t k = __builtin_popcount(S);
        uint64_t val = f * k * (uint64_t)sumidx[S];
        ans ^= val;
    }
    cout << ans << "\n";
    return 0;
}
