#include <bits/stdc++.h>
using namespace std;

const long long MOD = 1000000007LL;

long long power(long long b, long long e) {
    long long r = 1;
    b %= MOD;
    while (e > 0) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    long long n;
    int q;
    cin >> n >> q;

    // S(t) = sum_{k=0}^{n} (1+t)^{3k} = ((1+t)^{3n+3} - 1) / ((1+t)^3 - 1)
    // Denominator = t * (t^2 + 3t + 3), so with A(t) = (numerator)/t:
    //   A(t) = S(t) * (t^2 + 3t + 3)
    // Coefficients: a_j = C(3n+3, j+1). Then s_j = (a_j - 3 s_{j-1} - s_{j-2}) / 3.
    // Answer for x >= 1 is s_x (the k=0 term only contributes to x = 0).
    long long M = 3 * n + 3;
    vector<long long> fact(M + 1), inv(M + 1);
    fact[0] = 1;
    for (long long i = 1; i <= M; ++i) fact[i] = fact[i - 1] * i % MOD;
    inv[M] = power(fact[M], MOD - 2);
    for (long long i = M; i > 0; --i) inv[i - 1] = inv[i] * i % MOD;

    auto C = [&](long long a, long long b) -> long long {
        if (b < 0 || b > a) return 0;
        return fact[a] * inv[b] % MOD * inv[a - b] % MOD;
    };

    long long L = 3 * n;  // degree of S(t)
    vector<long long> s(L + 1, 0);
    long long inv3 = power(3, MOD - 2);
    long long prev1 = 0, prev2 = 0;  // s_{j-1}, s_{j-2}
    for (long long j = 0; j <= L; ++j) {
        long long aj = C(M, j + 1);
        long long cur = (aj - 3 * prev1 % MOD - prev2) % MOD;
        cur = (cur + 2 * MOD) % MOD;  // normalize (handles negatives)
        cur = cur * inv3 % MOD;
        s[j] = cur;
        prev2 = prev1;
        prev1 = cur;
    }

    string out;
    out.reserve(static_cast<size_t>(q) * 11);
    for (int i = 0; i < q; ++i) {
        long long x;
        cin >> x;
        long long ans = (x >= 0 && x <= L) ? s[x] : 0;
        out += to_string(ans);
        out += '\n';
    }
    cout << out;
    return 0;
}
