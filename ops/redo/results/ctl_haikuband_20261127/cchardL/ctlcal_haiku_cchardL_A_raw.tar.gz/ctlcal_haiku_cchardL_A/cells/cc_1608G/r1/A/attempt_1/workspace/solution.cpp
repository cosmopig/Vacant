// Alphabetic Tree: count occurrences of tree-path strings in a range of strings.
// Approach: suffix array over the concatenation of all strings (separated),
// polynomial hashing (mod 2^61-1) to compare a tree-path pattern with suffixes,
// HLD to split each path into O(log n) contiguous array segments, and an
// offline BIT sweep to count suffix-array positions whose string index is in [l, r].
#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long u64;

static const u64 MOD = (1ULL << 61) - 1;
static inline u64 mulm(u64 a, u64 b) {
    __uint128_t c = (__uint128_t)a * b;
    u64 lo = (u64)(c & MOD), hi = (u64)(c >> 61);
    u64 r = lo + hi;
    if (r >= MOD) r -= MOD;
    return r;
}
static inline u64 addm(u64 a, u64 b) { u64 r = a + b; if (r >= MOD) r -= MOD; return r; }
static inline u64 subm(u64 a, u64 b) { return a >= b ? a - b : a + MOD - b; }

static vector<u64> pw;
static int n;                 // tree nodes
static vector<int> A, Arev;   // A[pos] = letter of parent edge of node at pos; Arev reversed
static vector<u64> HA, HR;    // prefix hashes of A and Arev
static vector<int> tv;        // text values (1..26 letters, 27 separator)
static vector<u64> HT;
static int N;                 // text length

static inline u64 getH(const vector<u64>& G, int s, int len) {
    return subm(G[s + len], mulm(G[s], pw[len]));
}

struct Seg { int arr; int st; int len; };  // arr 0: A, arr 1: Arev

struct QD {
    vector<Seg> segs;
    vector<int> cum;     // cum[i] = start offset of segment i, cum[s] = k
    vector<u64> PH;      // PH[i] = hash of pattern prefix of length cum[i]
    int k;
};

static inline u64 segHash(const Seg& s, int t) {
    return s.arr == 0 ? getH(HA, s.st, t) : getH(HR, s.st, t);
}

static u64 prefixHash(const QD& d, int x) {
    if (x == 0) return 0;
    int j = lower_bound(d.cum.begin(), d.cum.end(), x) - d.cum.begin();
    int i = j - 1;
    int t = x - d.cum[i];
    return addm(mulm(d.PH[i], pw[t]), segHash(d.segs[i], t));
}

static inline int charAt(const QD& d, int x) {
    int j = upper_bound(d.cum.begin(), d.cum.end(), x) - d.cum.begin() - 1;
    const Seg& s = d.segs[j];
    int off = x - d.cum[j];
    return s.arr == 0 ? A[s.st + off] : Arev[s.st + off];
}

// compare pattern (truncated to k) with suffix at p: -1 less, 0 pattern is prefix of suffix, +1 greater
static int cmp3(const QD& d, int p) {
    int hi = min(d.k, N - p);
    int L = 0, R = hi;
    while (L < R) {
        int mid = (L + R + 1) >> 1;
        if (prefixHash(d, mid) == getH(HT, p, mid)) L = mid;
        else R = mid - 1;
    }
    int x = L;
    if (x == d.k) return 0;
    if (p + x == N) return -1;
    return tv[p + x] < charAt(d, x) ? -1 : 1;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int m, q;
    cin >> n >> m >> q;
    vector<vector<pair<int, int>>> adj(n);
    for (int i = 0; i < n - 1; i++) {
        int u, v;
        char c;
        cin >> u >> v >> c;
        --u; --v;
        int w = c - 'a' + 1;
        adj[u].push_back({v, w});
        adj[v].push_back({u, w});
    }

    // Root at 0, BFS order
    vector<int> par(n, -1), dep(n, 0), pch(n, 0), order;
    order.reserve(n);
    vector<char> vis(n, 0);
    order.push_back(0);
    vis[0] = 1;
    for (size_t h = 0; h < order.size(); h++) {
        int v = order[h];
        for (auto [to, w] : adj[v]) {
            if (!vis[to]) {
                vis[to] = 1;
                par[to] = v;
                dep[to] = dep[v] + 1;
                pch[to] = w;
                order.push_back(to);
            }
        }
    }
    vector<int> sz(n, 1), heavy(n, -1);
    for (int i = n - 1; i >= 1; i--) {
        int v = order[i];
        sz[par[v]] += sz[v];
    }
    for (int i = n - 1; i >= 1; i--) {
        int v = order[i];
        int p = par[v];
        if (heavy[p] == -1 || sz[heavy[p]] < sz[v]) heavy[p] = v;
    }
    vector<int> head(n), pos(n);
    int cur = 0;
    for (int v : order) {
        if (v == 0 || heavy[par[v]] != v) {
            for (int x = v; x != -1; x = heavy[x]) {
                head[x] = v;
                pos[x] = cur++;
            }
        }
    }
    A.assign(n, 0);
    for (int v = 0; v < n; v++) A[pos[v]] = pch[v];
    Arev.assign(n, 0);
    for (int i = 0; i < n; i++) Arev[i] = A[n - 1 - i];

    // Random base
    mt19937_64 rng(chrono::steady_clock::now().time_since_epoch().count());
    u64 B = rng() % (MOD - 1000) + 500;
    pw.assign(max(n, 200005) + 5, 1);
    for (size_t i = 1; i < pw.size(); i++) pw[i] = mulm(pw[i - 1], B);

    HA.assign(n + 1, 0);
    HR.assign(n + 1, 0);
    for (int i = 0; i < n; i++) {
        HA[i + 1] = addm(mulm(HA[i], B), (u64)A[i]);
        HR[i + 1] = addm(mulm(HR[i], B), (u64)Arev[i]);
    }

    // Read strings and build text
    vector<int> idT;
    tv.clear();
    for (int i = 1; i <= m; i++) {
        string s;
        cin >> s;
        for (char c : s) {
            tv.push_back(c - 'a' + 1);
            idT.push_back(i);
        }
        tv.push_back(27);
        idT.push_back(0);
    }
    N = (int)tv.size();
    HT.assign(N + 1, 0);
    for (int i = 0; i < N; i++) HT[i + 1] = addm(mulm(HT[i], B), (u64)tv[i]);

    // Suffix array by prefix doubling
    vector<int> sa(N), rk(N), tmp(N);
    for (int i = 0; i < N; i++) sa[i] = i;
    sort(sa.begin(), sa.end(), [&](int a, int b) { return tv[a] < tv[b]; });
    for (int i = 0; i < N; i++) rk[i] = tv[i];
    for (int k = 1;; k <<= 1) {
        auto key2 = [&](int i) { return i + k < N ? rk[i + k] : -1; };
        sort(sa.begin(), sa.end(), [&](int a, int b) {
            if (rk[a] != rk[b]) return rk[a] < rk[b];
            return key2(a) < key2(b);
        });
        tmp[sa[0]] = 0;
        for (int i = 1; i < N; i++) {
            tmp[sa[i]] = tmp[sa[i - 1]] +
                ((rk[sa[i]] != rk[sa[i - 1]] || key2(sa[i]) != key2(sa[i - 1])) ? 1 : 0);
        }
        rk = tmp;
        if (rk[sa[N - 1]] == N - 1) break;
        if (k > N) break;
    }

    // Queries: build path segments
    vector<QD> qs(q);
    vector<int> QL(q), QR(q);
    for (int qi = 0; qi < q; qi++) {
        int u, v, l, r;
        cin >> u >> v >> l >> r;
        --u; --v;
        QL[qi] = l;
        QR[qi] = r;
        // LCA
        int a = u, b = v;
        while (head[a] != head[b]) {
            if (dep[head[a]] < dep[head[b]]) swap(a, b);
            a = par[head[a]];
        }
        int w = (dep[a] < dep[b]) ? a : b;

        QD& d = qs[qi];
        vector<Seg> upv, dnc;
        int x = u;
        while (head[x] != head[w]) {
            upv.push_back({1, n - 1 - pos[x], pos[x] - pos[head[x]] + 1});
            x = par[head[x]];
        }
        if (x != w) upv.push_back({1, n - 1 - pos[x], pos[x] - pos[w]});
        int y = v;
        while (head[y] != head[w]) {
            dnc.push_back({0, pos[head[y]], pos[y] - pos[head[y]] + 1});
            y = par[head[y]];
        }
        if (y != w) d.segs.push_back({0, pos[w] + 1, pos[y] - pos[w]});
        for (int i = (int)dnc.size() - 1; i >= 0; i--) d.segs.push_back(dnc[i]);
        // prepend upward segments
        d.segs.insert(d.segs.begin(), upv.begin(), upv.end());

        int s = d.segs.size();
        d.cum.assign(s + 1, 0);
        d.PH.assign(s + 1, 0);
        for (int i = 0; i < s; i++) {
            d.cum[i + 1] = d.cum[i] + d.segs[i].len;
            d.PH[i + 1] = addm(mulm(d.PH[i], pw[d.segs[i].len]), segHash(d.segs[i], d.segs[i].len));
        }
        d.k = d.cum[s];
    }

    // Binary search suffix-array range for each pattern
    vector<int> LO(q), HI(q);
    for (int qi = 0; qi < q; qi++) {
        const QD& d = qs[qi];
        int L = 0, R = N;
        while (L < R) {
            int mid = (L + R) >> 1;
            if (cmp3(d, sa[mid]) < 0) L = mid + 1;
            else R = mid;
        }
        LO[qi] = L;
        R = N;
        int L2 = L;
        while (L2 < R) {
            int mid = (L2 + R) >> 1;
            if (cmp3(d, sa[mid]) <= 0) L2 = mid + 1;
            else R = mid;
        }
        HI[qi] = L2;
    }

    // Offline counting: events at SA index j, prefix sums over SA[0..j)
    vector<vector<pair<int, int>>> ev(N + 1);  // (query, sign)
    for (int qi = 0; qi < q; qi++) {
        if (LO[qi] < HI[qi]) {
            ev[LO[qi]].push_back({qi, -1});
            ev[HI[qi]].push_back({qi, +1});
        }
    }
    vector<long long> bit(m + 1, 0);
    auto bitAdd = [&](int i) { for (; i <= m; i += i & -i) bit[i]++; };
    auto bitSum = [&](int i) { long long s = 0; for (; i > 0; i -= i & -i) s += bit[i]; return s; };
    vector<long long> ans(q, 0);
    for (int j = 0; j <= N; j++) {
        for (auto [qi, sg] : ev[j]) {
            long long val = bitSum(QR[qi]) - bitSum(QL[qi] - 1);
            ans[qi] += sg * val;
        }
        if (j < N && idT[sa[j]] > 0) bitAdd(idT[sa[j]]);
    }

    string out;
    out.reserve(q * 8);
    for (int qi = 0; qi < q; qi++) {
        out += to_string(ans[qi]);
        out += '\n';
    }
    cout << out;
    return 0;
}
