// Good Graph: dynamic cactus maintenance.
//
// A graph is good iff every block is a single edge or a cycle with XOR 1.
// Adding (u,v,x):
//   - u,v in different components           -> YES (new bridge).
//   - u,v connected only through cycle edges -> NO  (would create a theta).
//   - u,v connected by a path of bridges P   -> YES iff XOR(P) ^ x == 1.
//     On YES, all edges of P stop being bridges (they join a cycle).
// Bridges are kept in a link-cut forest (edge nodes carry weights, vertex
// nodes carry 0), and a DSU tracks full connectivity.
#include <bits/stdc++.h>
using namespace std;

static vector<array<int, 2>> ch;
static vector<int> fa, val, sm;
static vector<char> tg;
static vector<int> stk;

static bool isroot(int x) {
    int f = fa[x];
    return f == 0 || (ch[f][0] != x && ch[f][1] != x);
}
static void app(int x) {
    if (!x) return;
    swap(ch[x][0], ch[x][1]);
    tg[x] ^= 1;
}
static void pd(int x) {
    if (tg[x]) {
        app(ch[x][0]);
        app(ch[x][1]);
        tg[x] = 0;
    }
}
static void pu(int x) {
    sm[x] = sm[ch[x][0]] ^ sm[ch[x][1]] ^ val[x];
}
static void rot(int x) {
    int y = fa[x], z = fa[y];
    int k = (ch[y][1] == x);
    if (!isroot(y)) ch[z][ch[z][1] == y] = x;
    fa[x] = z;
    ch[y][k] = ch[x][k ^ 1];
    if (ch[x][k ^ 1]) fa[ch[x][k ^ 1]] = y;
    ch[x][k ^ 1] = y;
    fa[y] = x;
    pu(y);
    pu(x);
}
static void splay(int x) {
    stk.clear();
    int y = x;
    stk.push_back(y);
    while (!isroot(y)) {
        y = fa[y];
        stk.push_back(y);
    }
    for (int i = (int)stk.size() - 1; i >= 0; --i) pd(stk[i]);
    while (!isroot(x)) {
        int y2 = fa[x], z = fa[y2];
        if (!isroot(y2)) {
            rot(((ch[y2][0] == x) ^ (ch[z][0] == y2)) ? x : y2);
        }
        rot(x);
    }
}
static void access(int x) {
    for (int y = 0; x; y = x, x = fa[x]) {
        splay(x);
        ch[x][1] = y;
        pu(x);
    }
}
static void makeroot(int x) {
    access(x);
    splay(x);
    app(x);
}
static int findroot(int x) {
    access(x);
    splay(x);
    while (true) {
        pd(x);
        if (!ch[x][0]) break;
        x = ch[x][0];
    }
    splay(x);
    return x;
}
static void link(int x, int y) {  // x, y in different trees
    makeroot(x);
    fa[x] = y;
}
static void cut(int x, int y) {  // x, y adjacent in the forest
    makeroot(x);
    access(y);
    splay(y);
    ch[y][0] = 0;
    fa[x] = 0;
    pu(y);
}

static vector<int> dsu;
static int findd(int x) {
    while (dsu[x] != x) {
        dsu[x] = dsu[dsu[x]];
        x = dsu[x];
    }
    return x;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n, q;
    cin >> n >> q;
    int N = n + q + 2;
    ch.assign(N, {0, 0});
    fa.assign(N, 0);
    val.assign(N, 0);
    sm.assign(N, 0);
    tg.assign(N, 0);
    dsu.resize(n + 1);
    for (int i = 0; i <= n; ++i) dsu[i] = i;
    vector<int> EU(q + 2, 0), EV(q + 2, 0);
    int cnt = 0;
    string out;
    out.reserve((size_t)q * 4);
    vector<int> collected;
    for (int qi = 0; qi < q; ++qi) {
        int u, v, x;
        cin >> u >> v >> x;
        int a = findd(u), b = findd(v);
        if (a != b) {
            dsu[a] = b;
            ++cnt;
            int id = n + cnt;
            EU[cnt] = u;
            EV[cnt] = v;
            val[id] = x;
            sm[id] = x;
            link(u, id);
            link(id, v);
            out += "YES\n";
            continue;
        }
        makeroot(u);
        if (findroot(v) != u) {
            out += "NO\n";
            continue;
        }
        makeroot(u);
        access(v);
        splay(v);
        int p = sm[v];
        if ((p ^ x) != 1) {
            out += "NO\n";
            continue;
        }
        // Collect all bridge edges on the path u..v; they join a new cycle.
        collected.clear();
        stk.clear();
        stk.push_back(v);
        while (!stk.empty()) {
            int y = stk.back();
            stk.pop_back();
            if (!y) continue;
            pd(y);
            if (y > n) collected.push_back(y - n);
            stk.push_back(ch[y][0]);
            stk.push_back(ch[y][1]);
        }
        for (int k : collected) {
            int id = n + k;
            cut(EU[k], id);
            cut(id, EV[k]);
        }
        out += "YES\n";
    }
    fwrite(out.data(), 1, out.size(), stdout);
    return 0;
}
