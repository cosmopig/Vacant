import sys

# Let f(x) be the 1-based lexicographic rank of x among 1..n, and g(x) = f(x) - x.
# The required sum is sum_x (g(x) mod M), M = 998244353.
# Since sum_x g(x) = 0 (f is a permutation of 1..n), this equals -M * sum_x floor(g(x)/M).
# Within one digit-length group d, g is nondecreasing in x, so floor(g/M) can be
# summed by counting thresholds t*M with a binary search per threshold.


def main():
    n = int(sys.stdin.read().split()[0])
    M = 998244353
    P = 10**9 + 7
    D = len(str(n))
    pw = [10**k for k in range(D + 2)]
    K = n // M + 2  # shift so that h = g + K*M >= 0 for all x

    # cs[d] = sum_{L=d+1}^{D-1} 10^{L-d}
    cs = [0] * (D + 1)
    for d in range(1, D + 1):
        cs[d] = sum(pw[L - d] for L in range(d + 1, D))

    def g(x, d):
        res = 0
        if d < D:
            # Lengths L in (d, D): all L-digit numbers with prefix < x.
            res += (x - pw[d - 1]) * cs[d]
            # Length D: D-digit numbers y <= n with prefix < x.
            res += max(0, min(n + 1, x * pw[D - d]) - pw[D - 1])
        # Shorter numbers y (length L < d) that are lexicographically greater than x.
        for L in range(1, d):
            res -= pw[L] - 1 - x // pw[d - L]
        return res

    total_floor = 0  # sum_x floor(g(x)/M)
    for d in range(1, D + 1):
        lo = pw[d - 1]
        hi = min(n, pw[d] - 1)
        if lo > hi:
            continue
        size = hi - lo + 1
        base = K * M

        def h(x):
            return g(x, d) + base

        h_lo = h(lo)
        h_hi = h(hi)
        t0 = h_lo // M  # thresholds t <= t0 are met by every x in the group
        tmax = h_hi // M  # thresholds t > tmax are never met
        cnt = t0 * size
        for t in range(t0 + 1, tmax + 1):
            target = t * M
            a, b = lo, hi  # find smallest x with h(x) >= target (h nondecreasing)
            while a < b:
                mid = (a + b) // 2
                if h(mid) >= target:
                    b = mid
                else:
                    a = mid + 1
            cnt += hi - a + 1
        total_floor += cnt - K * size

    print((-M * total_floor) % P)


main()
