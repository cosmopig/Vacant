# Contract

Write your solution to `solution.py` (Python 3) or `solution.cpp` (C++17) in the root of this workspace, as you prefer.
`solution.py` exists as an empty stub. The program reads the input from standard input and prints the answer to
standard output, as the problem statement in `goal.md` describes.

- If `solution.cpp` exists it is compiled with `g++ -O2 -std=gnu++17` and run; otherwise `solution.py` is run with Python 3.
- Only the standard library of the language; do not install packages.
- The tests for this task are in `solution_test.py` (with their data in `cases.json`). The tests are correct;
  don't change them or the data. Each test runs the program on one input and compares the output with the
  expected output after whitespace normalisation. A test fails if the program takes longer than 18 seconds
  on one input. Run them with:

      python3 -m pytest -q solution_test.py

  or, without pytest:

      python3 -m unittest solution_test.py
