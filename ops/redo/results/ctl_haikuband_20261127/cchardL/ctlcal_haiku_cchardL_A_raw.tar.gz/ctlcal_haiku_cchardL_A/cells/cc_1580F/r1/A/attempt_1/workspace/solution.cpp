// Count cyclic sequences a_1..a_n, a_i >= 0, with a_i + a_{i+1} < m (indices cyclic).
//
// Let M be the m x m matrix M[a][b] = [a + b < m]. The answer is trace(M^n).
// Let P_m(z) = det(I - zM). Then sum_{n>=1} trace(M^n) z^n = -z P_m'(z) / P_m(z),
// so the answer is [z^n] of (-z P_m'(z) * inv(P_m(z))).
//
// P_m satisfies P_m = (2 - z^2) P_{m-2} - P_{m-4} for m >= 4, with
//   P_0 = 1, P_1 = 1 - z, P_2 = 1 - z - z^2, P_3 = 1 - 2z - z^2 + z^3.
// Writing c = 2 - z^2, the sequence S_j = P_{2j+r} (r = m mod 2) satisfies
// S_j = c S_{j-1} - S_{j-2}, so S_J = F_J S_1 - F_{J-1} S_0 where F is the
// Chebyshev-type sequence F_0 = 0, F_1 = 1, F_{j+1} = c F_j - F_{j-1}.
// F_J is computed by binary doubling in O(log m) polynomial products, all
// truncated mod z^{n+1}. Polynomial products use NTT modulo 998244353.
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

static const ll MOD = 998244353;

ll pw(ll b, ll e) {
    b %= MOD;
    if (b < 0) b += MOD;
    ll r = 1;
    while (e) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

void ntt(vector<ll>& a, bool invert) {
    int n = a.size();
    for (int i = 1, j = 0; i < n; i++) {
        int bit = n >> 1;
        for (; j & bit; bit >>= 1) j ^= bit;
        j ^= bit;
        if (i < j) swap(a[i], a[j]);
    }
    vector<ll> wp;
    for (int len = 2; len <= n; len <<= 1) {
        ll w = pw(3, (MOD - 1) / len);
        if (invert) w = pw(w, MOD - 2);
        int half = len >> 1;
        wp.assign(half, 1);
        for (int i = 1; i < half; i++) wp[i] = wp[i - 1] * w % MOD;
        for (int i = 0; i < n; i += len) {
            for (int j = 0; j < half; j++) {
                ll u = a[i + j];
                ll v = a[i + j + half] * wp[j] % MOD;
                ll s = u + v;
                a[i + j] = s >= MOD ? s - MOD : s;
                ll d = u - v;
                a[i + j + half] = d < 0 ? d + MOD : d;
            }
        }
    }
    if (invert) {
        ll ni = pw(n, MOD - 2);
        for (auto& x : a) x = x * ni % MOD;
    }
}

int L;  // every polynomial is stored with exactly L = n+1 coefficients

vector<ll> trunc(const vector<ll>& a) {
    vector<ll> r(L, 0);
    for (int i = 0; i < L && i < (int)a.size(); i++) r[i] = a[i];
    return r;
}

// product truncated to L coefficients
vector<ll> mul(const vector<ll>& a, const vector<ll>& b) {
    int la = min<int>(L, a.size()), lb = min<int>(L, b.size());
    int full = la + lb - 1;
    int sz = 1;
    while (sz < full) sz <<= 1;
    vector<ll> fa(sz, 0), fb(sz, 0);
    for (int i = 0; i < la; i++) fa[i] = a[i];
    for (int i = 0; i < lb; i++) fb[i] = b[i];
    ntt(fa, false);
    ntt(fb, false);
    for (int i = 0; i < sz; i++) fa[i] = fa[i] * fb[i] % MOD;
    ntt(fa, true);
    vector<ll> r(L, 0);
    for (int i = 0; i < L && i < full; i++) r[i] = fa[i];
    return r;
}

vector<ll> addp(const vector<ll>& a, const vector<ll>& b) {
    vector<ll> r(L);
    for (int i = 0; i < L; i++) {
        ll s = a[i] + b[i];
        r[i] = s >= MOD ? s - MOD : s;
    }
    return r;
}

vector<ll> subp(const vector<ll>& a, const vector<ll>& b) {
    vector<ll> r(L);
    for (int i = 0; i < L; i++) {
        ll d = a[i] - b[i];
        r[i] = d < 0 ? d + MOD : d;
    }
    return r;
}

vector<ll> scalep(const vector<ll>& a, ll s) {
    vector<ll> r(L);
    s %= MOD;
    if (s < 0) s += MOD;
    for (int i = 0; i < L; i++) r[i] = a[i] * s % MOD;
    return r;
}

// multiply by c = 2 - z^2 (cheap)
vector<ll> mulc(const vector<ll>& a) {
    vector<ll> r(L);
    for (int i = 0; i < L; i++) {
        ll v = 2 * a[i];
        if (i >= 2) v -= a[i - 2];
        v %= MOD;
        if (v < 0) v += MOD;
        r[i] = v;
    }
    return r;
}

// power-series inverse mod z^L, requires f[0] != 0
vector<ll> inverse(const vector<ll>& f) {
    vector<ll> g(L, 0);
    g[0] = pw(f[0], MOD - 2);
    int cur = 1;
    while (cur < L) {
        int nxt = min(L, cur * 2);
        // g = g * (2 - f g) mod z^nxt
        vector<ll> fg = mul(trunc(vector<ll>(f.begin(), f.begin() + min<int>(nxt, L))), g);
        vector<ll> t(L, 0);
        for (int i = 0; i < L; i++) t[i] = (MOD - fg[i]) % MOD;
        t[0] = (t[0] + 2) % MOD;
        g = mul(g, t);
        for (int i = nxt; i < L; i++) g[i] = 0;
        cur = nxt;
    }
    return g;
}

int main() {
    ll n, m;
    cin >> n >> m;
    L = (int)n + 1;

    // P_m for m <= 3 directly
    vector<ll> P;
    if (m <= 3) {
        static const ll base[4][4] = {
            {1, 0, 0, 0},
            {1, -1, 0, 0},
            {1, -1, -1, 0},
            {1, -2, -1, 1},
        };
        P.assign(L, 0);
        for (int i = 0; i < 4 && i < L; i++) P[i] = (base[m][i] % MOD + MOD) % MOD;
    } else {
        int r = m % 2;
        ll J = (m - r) / 2;
        // S_0 = P_r, S_1 = P_{2+r}
        vector<ll> S0(L, 0), S1(L, 0);
        if (r == 0) {
            S0[0] = 1;
            S1[0] = 1;
            if (L > 1) S1[1] = MOD - 1;
            if (L > 2) S1[2] = MOD - 1;
        } else {
            S0[0] = 1;
            if (L > 1) S0[1] = MOD - 1;
            S1[0] = 1;
            if (L > 1) S1[1] = MOD - 2;
            if (L > 2) S1[2] = MOD - 1;
            if (L > 3) S1[3] = 1;
        }
        // (F_k, F_{k+1}) starting at k = 0
        vector<ll> A(L, 0), B(L, 0);
        B[0] = 1;  // F_1 = 1 (if L == 1, still fine since n >= 2)
        int hb = 0;
        while ((J >> (hb + 1)) > 0) hb++;
        for (int bit = hb; bit >= 0; bit--) {
            // double: (F_k, F_{k+1}) -> (F_{2k}, F_{2k+1})
            vector<ll> cA = mulc(A);
            vector<ll> D = subp(scalep(B, 2), cA);  // 2F_{k+1} - cF_k = F_{k+1} - F_{k-1}
            vector<ll> FE = mul(A, D);
            vector<ll> A2 = mul(A, A);
            vector<ll> B2 = mul(B, B);
            vector<ll> FO = subp(B2, A2);
            A = FE;
            B = FO;
            if ((J >> bit) & 1) {
                // increment: (F_{2k}, F_{2k+1}) -> (F_{2k+1}, F_{2k+2})
                vector<ll> nxt = subp(mulc(B), A);
                A = B;
                B = nxt;
            }
        }
        // now A = F_J, B = F_{J+1}; F_{J-1} = c F_J - F_{J+1}
        vector<ll> FJm1 = subp(mulc(A), B);
        P = subp(mul(A, S1), mul(FJm1, S0));
    }

    // numerator: -z P'(z), coefficient i is -i * P[i]
    vector<ll> num(L, 0);
    for (int i = 1; i < L; i++) {
        ll v = (MOD - (ll)i % MOD) % MOD * P[i] % MOD;
        num[i] = v;
    }
    vector<ll> invP = inverse(P);
    ll ans = 0;
    for (int i = 0; i <= n; i++) {
        ans = (ans + num[i] * invP[n - i]) % MOD;
    }
    cout << ans << "\n";
    return 0;
}
