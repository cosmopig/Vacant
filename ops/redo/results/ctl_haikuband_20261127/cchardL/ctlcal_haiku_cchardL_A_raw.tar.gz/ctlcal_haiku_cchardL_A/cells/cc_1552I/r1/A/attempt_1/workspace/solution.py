import sys

MOD = 998244353


def overlap(a, b):
    return bool(a & b) and bool(a - b) and bool(b - a)


def place(seq, X):
    """Refine an ordered list of blocks so that X becomes a union of consecutive blocks.
    Returns the new list, or None if impossible."""
    idx = [i for i, b in enumerate(seq) if b & X]
    if not idx:
        return None
    l, r = idx[0], idx[-1]
    if idx != list(range(l, r + 1)):
        return None
    if l == r:
        # Cannot happen for overlap-connected insertion; treat as failure to be safe.
        return None
    for i in range(l + 1, r):
        if seq[i] - X:
            return None
    new = list(seq[:l])
    if seq[l] - X:
        new += [seq[l] - X, seq[l] & X]
    else:
        new.append(seq[l])
    new += seq[l + 1:r]
    if seq[r] - X:
        new += [seq[r] & X, seq[r] - X]
    else:
        new.append(seq[r])
    new += seq[r + 1:]
    return new


def build_blocks(sets):
    """sets: overlap-connected list of frozensets. Returns ordered list of blocks
    (classes of elements) forced up to reversal, or None if inconsistent."""
    k = len(sets)
    adj = [[j for j in range(k) if j != i and overlap(sets[i], sets[j])] for i in range(k)]
    order = []
    seen = [False] * k
    seen[0] = True
    queue = [0]
    while queue:
        i = queue.pop(0)
        order.append(i)
        for j in adj[i]:
            if not seen[j]:
                seen[j] = True
                queue.append(j)
    blocks = [sets[order[0]]]
    union = sets[order[0]]
    for i in order[1:]:
        X = sets[i]
        N = X - union
        if N:
            cand = [blocks + [N], [N] + blocks]
        else:
            cand = [blocks]
        res = None
        for seq in cand:
            res = place(seq, X)
            if res is not None:
                break
        if res is None:
            return None
        blocks = res
        union = union | X
    return blocks


def solve(U, S, fact):
    """Number of orderings of U such that every set in S is contiguous.
    All sets in S are subsets of U."""
    S = list({s for s in S if 2 <= len(s) < len(U)})
    if not S:
        return fact[len(U)]
    k = len(S)
    parent = list(range(k))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for i in range(k):
        for j in range(i + 1, k):
            if overlap(S[i], S[j]):
                parent[find(i)] = find(j)
    groups = {}
    for i in range(k):
        groups.setdefault(find(i), []).append(i)

    comps = []  # dicts: idx (list), union, blocks (None for single)
    multi_unions = set()
    for idxs in groups.values():
        union = frozenset()
        for i in idxs:
            union = union | S[i]
        if len(idxs) > 1:
            blocks = build_blocks([S[i] for i in idxs])
            if blocks is None:
                return 0
            multi_unions.add(union)
            comps.append({"idx": idxs, "union": union, "blocks": blocks})
        else:
            comps.append({"idx": idxs, "union": union, "blocks": None})
    # A single set equal to the union of a multi-set component is implied by it.
    comps = [c for c in comps if not (c["blocks"] is None and c["union"] in multi_unions)]

    tops = []
    for c in comps:
        dominated = any(d is not c and c["union"] < d["union"] for d in comps)
        if not dominated:
            tops.append(c)

    result = 1
    covered = 0
    for c in tops:
        covered += len(c["union"])
        if c["blocks"] is not None:
            result = result * 2 % MOD
            own = set(c["idx"])
            others = [S[i] for i in range(k) if i not in own]
            for b in c["blocks"]:
                sub = [s for s in others if s <= b]
                result = result * solve(b, sub, fact) % MOD
                if result == 0:
                    return 0
        else:
            sub = [S[i] for i in range(k) if S[i] < c["union"]]
            result = result * solve(c["union"], sub, fact) % MOD
    units = len(tops) + (len(U) - covered)
    result = result * fact[units] % MOD
    return result


def main():
    data = sys.stdin.read().split()
    n, m = int(data[0]), int(data[1])
    pos = 2
    sets = []
    for _ in range(m):
        q = int(data[pos])
        pos += 1
        sets.append(frozenset(int(x) for x in data[pos:pos + q]))
        pos += q
    fact = [1] * (n + 2)
    for i in range(1, n + 2):
        fact[i] = fact[i - 1] * i % MOD
    U = frozenset(range(1, n + 1))
    print(solve(U, sets, fact) % MOD)


if __name__ == "__main__":
    main()
