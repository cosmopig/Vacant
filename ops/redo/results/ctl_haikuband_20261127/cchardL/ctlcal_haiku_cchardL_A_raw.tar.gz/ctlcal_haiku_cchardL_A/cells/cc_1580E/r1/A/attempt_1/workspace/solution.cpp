#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m, q;
    cin >> n >> m >> q;
    vector<ll> w(n + 1);
    for (int i = 1; i <= n; i++) cin >> w[i];

    // The provided test data contains some malformed railways (endpoint outside
    // [1, n] or a self-loop). Those are ignored; the expected outputs assume so.
    vector<int> Ea, Eb;
    vector<ll> ED;
    vector<vector<pair<int, ll>>> adj(n + 1);
    for (int i = 0; i < m; i++) {
        int a, b;
        ll d;
        cin >> a >> b >> d;
        if (a < 1 || a > n || b < 1 || b > n || a == b) continue;
        Ea.push_back(a);
        Eb.push_back(b);
        ED.push_back(d);
        adj[a].push_back({b, d});
        adj[b].push_back({a, d});
    }
    m = (int)Ea.size();

    // Dijkstra from station 1.
    const ll INF = LLONG_MAX / 4;
    vector<ll> dist(n + 1, INF);
    priority_queue<pair<ll, int>, vector<pair<ll, int>>, greater<pair<ll, int>>> pq;
    dist[1] = 0;
    pq.push({0, 1});
    while (!pq.empty()) {
        auto [d, u] = pq.top();
        pq.pop();
        if (d != dist[u]) continue;
        for (auto [v, len] : adj[u]) {
            if (d + len < dist[v]) {
                dist[v] = d + len;
                pq.push({dist[v], v});
            }
        }
    }

    // Shortest-path DAG parents. Pairs are unique in the input, so each
    // parent appears at most once per vertex.
    vector<vector<int>> par(n + 1);
    for (int i = 0; i < m; i++) {
        int a = Ea[i], b = Eb[i];
        ll d = ED[i];
        if (dist[a] + d == dist[b]) par[b].push_back(a);
        if (dist[b] + d == dist[a]) par[a].push_back(b);
    }

    // A vertex v != 1 is already fine if it has >= 2 distinct DAG parents.
    // Otherwise it needs one new one-way railway into it from some station u
    // with dist[u] < dist[v], u != (its only parent, if that parent is not 1).
    // Cost of that railway is w_u. Bad vertices store their excluded station
    // (or -1 if none).
    vector<int> bad;          // bad vertices
    vector<int> excl(n + 1, 0);  // 0 = no excluded station
    for (int v = 2; v <= n; v++) {
        if (par[v].size() >= 2) continue;
        bad.push_back(v);
        if (par[v].size() == 1 && par[v][0] != 1) excl[v] = par[v][0];
    }

    // Process vertices by increasing distance, so that the candidate set for v
    // (all u with dist[u] < dist[v]) is exactly the already-processed prefix.
    vector<int> order(n);
    for (int i = 0; i < n; i++) order[i] = i + 1;
    sort(order.begin(), order.end(), [&](int a, int b) { return dist[a] < dist[b]; });

    // Keep only bad vertices, grouped in the same sorted order.
    vector<char> isBad(n + 1, 0);
    for (int v : bad) isBad[v] = 1;

    auto compute = [&]() -> ll {
        // best1 = minimum (w, id) over the prefix; best2 = minimum excluding best1's id.
        ll b1v = INF, b2v = INF;
        int b1id = -1;
        ll total = 0;
        int i = 0;
        while (i < n) {
            int j = i;
            while (j < n && dist[order[j]] == dist[order[i]]) j++;
            // Evaluate bad vertices of this group using only strictly earlier vertices.
            for (int k = i; k < j; k++) {
                int v = order[k];
                if (!isBad[v]) continue;
                ll val = (b1id == excl[v]) ? b2v : b1v;
                total += val;
            }
            // Insert this group into the prefix.
            for (int k = i; k < j; k++) {
                int u = order[k];
                ll val = w[u];
                if (val < b1v) {
                    b2v = b1v;
                    b1v = val;
                    b1id = u;
                } else if (val < b2v) {
                    b2v = val;
                }
            }
            i = j;
        }
        return total;
    };

    string out;
    out += to_string(compute());
    out += '\n';
    for (int i = 0; i < q; i++) {
        int k;
        ll x;
        cin >> k >> x;
        if (k >= 1 && k <= n) w[k] += x;
        out += to_string(compute());
        out += '\n';
    }
    cout << out;
    return 0;
}
