def rebase(input_base, digits, output_base):
    if input_base < 2:
        raise ValueError("input base must be >= 2")
    if output_base < 2:
        raise ValueError("output base must be >= 2")

    # Convert the input digits to a single integer value.
    value = 0
    for d in digits:
        if not (0 <= d < input_base):
            raise ValueError("all digits must satisfy 0 <= d < input base")
        value = value * input_base + d

    # Convert the integer value into digits of the output base.
    if value == 0:
        return [0]

    result = []
    while value > 0:
        value, remainder = divmod(value, output_base)
        result.append(remainder)
    result.reverse()
    return result
