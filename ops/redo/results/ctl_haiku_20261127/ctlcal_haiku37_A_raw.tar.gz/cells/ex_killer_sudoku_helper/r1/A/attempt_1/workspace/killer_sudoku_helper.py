from itertools import combinations as _combinations

DIGITS = range(1, 10)


def combinations(target, size, exclude):
    """Return all sorted digit combinations for a Killer Sudoku cage.

    A valid combination:
      - has exactly `size` distinct digits from 1 to 9,
      - sums to `target`,
      - contains none of the digits in `exclude`.

    Results are lists of digits in ascending order, and the list of
    combinations is sorted lexicographically.
    """
    excluded = set(exclude)
    allowed = [d for d in DIGITS if d not in excluded]
    return [
        list(combo)
        for combo in _combinations(allowed, size)
        if sum(combo) == target
    ]
