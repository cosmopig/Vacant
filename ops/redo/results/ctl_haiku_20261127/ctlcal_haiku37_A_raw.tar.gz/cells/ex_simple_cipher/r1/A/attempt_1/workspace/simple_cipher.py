import secrets
import string


class Cipher:
    def __init__(self, key=None):
        if key is None:
            # 100 random lowercase letters. `secrets` is used rather than `random`
            # because the key should be unpredictable.
            key = "".join(secrets.choice(string.ascii_lowercase) for _ in range(100))
        if not key or any(c not in string.ascii_lowercase for c in key):
            raise ValueError("key must be a non-empty string of lowercase letters")
        self.key = key

    def _shift(self, text, direction):
        shifted = []
        for i, char in enumerate(text):
            if char not in string.ascii_lowercase:
                shifted.append(char)
                continue
            shift = ord(self.key[i % len(self.key)]) - ord("a")
            offset = (ord(char) - ord("a") + direction * shift) % 26
            shifted.append(chr(ord("a") + offset))
        return "".join(shifted)

    def encode(self, text):
        return self._shift(text, 1)

    def decode(self, text):
        return self._shift(text, -1)
