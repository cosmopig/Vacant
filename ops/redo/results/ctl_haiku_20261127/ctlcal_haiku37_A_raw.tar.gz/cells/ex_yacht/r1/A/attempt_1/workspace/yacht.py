# Score categories.
# Change the values as you see fit.
YACHT = 0
ONES = 1
TWOS = 2
THREES = 3
FOURS = 4
FIVES = 5
SIXES = 6
FULL_HOUSE = 7
FOUR_OF_A_KIND = 8
LITTLE_STRAIGHT = 9
BIG_STRAIGHT = 10
CHOICE = 11


def score(dice, category):
    counts = [0] * 7  # counts[face] for faces 1..6
    for die in dice:
        counts[die] += 1
    total = sum(dice)
    faces = sorted(dice)

    if category in (ONES, TWOS, THREES, FOURS, FIVES, SIXES):
        face = category  # category values 1..6 match the face value
        return face * counts[face]
    if category == FULL_HOUSE:
        # Exactly one face appearing three times and another appearing twice.
        return total if sorted(c for c in counts if c) == [2, 3] else 0
    if category == FOUR_OF_A_KIND:
        for face in range(1, 7):
            if counts[face] >= 4:
                return 4 * face
        return 0
    if category == LITTLE_STRAIGHT:
        return 30 if faces == [1, 2, 3, 4, 5] else 0
    if category == BIG_STRAIGHT:
        return 30 if faces == [2, 3, 4, 5, 6] else 0
    if category == CHOICE:
        return total
    if category == YACHT:
        return 50 if counts.count(5) == 1 else 0
    return 0
