"""Atbash cipher: a substitution cipher that reverses the alphabet."""

import string

_ALPHABET = string.ascii_lowercase
_TABLE = str.maketrans(_ALPHABET, _ALPHABET[::-1])
_GROUP_SIZE = 5


def _transform(text):
    """Lowercase, drop anything that is not a letter or digit, and apply the Atbash map."""
    kept = "".join(ch for ch in text.lower() if ch.isascii() and ch.isalnum())
    return kept.translate(_TABLE)


def encode(plain_text):
    """Encode plain text, grouping the output into blocks of five characters."""
    cipher = _transform(plain_text)
    return " ".join(
        cipher[i:i + _GROUP_SIZE] for i in range(0, len(cipher), _GROUP_SIZE)
    )


def decode(ciphered_text):
    """Decode ciphered text, ignoring spaces and returning ungrouped plain text."""
    return _transform(ciphered_text)
