class BufferFullException(BufferError):
    """Exception raised when CircularBuffer is full.

    message: explanation of the error.

    """
    def __init__(self, message):
        super().__init__(message)
        self.message = message


class BufferEmptyException(BufferError):
    """Exception raised when CircularBuffer is empty.

    message: explanation of the error.

    """
    def __init__(self, message):
        super().__init__(message)
        self.message = message


class CircularBuffer:
    def __init__(self, capacity):
        if capacity <= 0:
            raise ValueError("Capacity must be a positive integer")
        self._capacity = capacity
        self._data = [None] * capacity
        self._read_index = 0
        self._count = 0

    def read(self):
        if self._count == 0:
            raise BufferEmptyException("Circular buffer is empty")
        item = self._data[self._read_index]
        self._data[self._read_index] = None
        self._read_index = (self._read_index + 1) % self._capacity
        self._count -= 1
        return item

    def write(self, data):
        if self._count == self._capacity:
            raise BufferFullException("Circular buffer is full")
        write_index = (self._read_index + self._count) % self._capacity
        self._data[write_index] = data
        self._count += 1

    def overwrite(self, data):
        if self._count == self._capacity:
            # Full: replace the oldest item and advance the read position.
            self._data[self._read_index] = data
            self._read_index = (self._read_index + 1) % self._capacity
        else:
            self.write(data)

    def clear(self):
        self._data = [None] * self._capacity
        self._read_index = 0
        self._count = 0
