ORDINALS = [
    "first", "second", "third", "fourth", "fifth", "sixth",
    "seventh", "eighth", "ninth", "tenth", "eleventh", "twelfth",
]

# Gifts in the order they were introduced; verse n sings GIFTS[n-1] down to GIFTS[0].
GIFTS = [
    "a Partridge in a Pear Tree",
    "two Turtle Doves",
    "three French Hens",
    "four Calling Birds",
    "five Gold Rings",
    "six Geese-a-Laying",
    "seven Swans-a-Swimming",
    "eight Maids-a-Milking",
    "nine Ladies Dancing",
    "ten Lords-a-Leaping",
    "eleven Pipers Piping",
    "twelve Drummers Drumming",
]


def verse(day):
    """Return the lyrics of a single verse for the given day (1-12)."""
    gifts = GIFTS[day - 1::-1]  # newest gift first, cumulative back to day 1
    if day == 1:
        gift_text = gifts[0]
    else:
        gift_text = ", ".join(gifts[:-1]) + ", and " + gifts[-1]
    return (
        f"On the {ORDINALS[day - 1]} day of Christmas my true love gave to me: "
        f"{gift_text}."
    )


def recite(start_verse, end_verse):
    """Return the verses from start_verse through end_verse as a list of strings."""
    return [verse(day) for day in range(start_verse, end_verse + 1)]
