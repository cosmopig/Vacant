DIGIT_PATTERNS = {
    (" _ ", "| |", "|_|"): "0",
    ("   ", "  |", "  |"): "1",
    (" _ ", " _|", "|_ "): "2",
    (" _ ", " _|", " _|"): "3",
    ("   ", "|_|", "  |"): "4",
    (" _ ", "|_ ", " _|"): "5",
    (" _ ", "|_ ", "|_|"): "6",
    (" _ ", "  |", "  |"): "7",
    (" _ ", "|_|", "|_|"): "8",
    (" _ ", "|_|", " _|"): "9",
}

CELL_WIDTH = 3
CELL_HEIGHT = 4


def _convert_row(lines):
    """Convert one row of cells (four lines of text) into a string of digits."""
    cell_count = len(lines[0]) // CELL_WIDTH
    digits = []
    for col in range(cell_count):
        start = col * CELL_WIDTH
        cell = tuple(line[start:start + CELL_WIDTH] for line in lines[:CELL_HEIGHT - 1])
        digits.append(DIGIT_PATTERNS.get(cell, "?"))
    return "".join(digits)


def convert(input_grid):
    """Convert a multi-line OCR grid of digits into a string of digits.

    Rows of cells are separated by commas in the output. Unrecognised cells
    are shown as "?". Raises ValueError if the grid dimensions are invalid.
    """
    if len(input_grid) % CELL_HEIGHT != 0:
        raise ValueError("Number of input lines is not a multiple of four")

    for line in input_grid:
        if len(line) % CELL_WIDTH != 0:
            raise ValueError("Number of input columns is not a multiple of three")

    rows = []
    for start in range(0, len(input_grid), CELL_HEIGHT):
        group = input_grid[start:start + CELL_HEIGHT]
        rows.append(_convert_row(group))
    return ",".join(rows)
