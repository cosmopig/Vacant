import calendar
import re
from datetime import datetime, timedelta

WORKDAYS = (0, 1, 2, 3, 4)  # Monday through Friday


def _first_workday(year, month):
    day = datetime(year, month, 1)
    while day.weekday() not in WORKDAYS:
        day += timedelta(days=1)
    return day


def _last_workday(year, month):
    last = calendar.monthrange(year, month)[1]
    day = datetime(year, month, last)
    while day.weekday() not in WORKDAYS:
        day -= timedelta(days=1)
    return day


def _quarter(month):
    return (month - 1) // 3 + 1


def delivery_date(start, description):
    meeting = datetime.fromisoformat(start)

    if description == "NOW":
        return (meeting + timedelta(hours=2)).isoformat()

    if description == "ASAP":
        if meeting.hour < 13:
            due = meeting.replace(hour=17, minute=0, second=0)
        else:
            due = (meeting + timedelta(days=1)).replace(hour=13, minute=0, second=0)
        return due.isoformat()

    if description == "EOW":
        weekday = meeting.weekday()
        if weekday <= 2:  # Monday, Tuesday, Wednesday
            due = meeting + timedelta(days=4 - weekday)
            due = due.replace(hour=17, minute=0, second=0)
        else:  # Thursday, Friday
            due = meeting + timedelta(days=6 - weekday)
            due = due.replace(hour=20, minute=0, second=0)
        return due.isoformat()

    month_match = re.fullmatch(r"(\d+)M", description)
    if month_match:
        n = int(month_match.group(1))
        year = meeting.year if meeting.month < n else meeting.year + 1
        due = _first_workday(year, n).replace(hour=8, minute=0, second=0)
        return due.isoformat()

    quarter_match = re.fullmatch(r"Q(\d)", description)
    if quarter_match:
        n = int(quarter_match.group(1))
        year = meeting.year if _quarter(meeting.month) <= n else meeting.year + 1
        end_month = 3 * n
        due = _last_workday(year, end_month).replace(hour=8, minute=0, second=0)
        return due.isoformat()

    raise ValueError(f"unknown delivery date description: {description!r}")
