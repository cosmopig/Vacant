from collections import deque

# Penalty owed by the opponent for each payment card.
PENALTY = {"J": 1, "Q": 2, "K": 3, "A": 4}


def _normalize(card):
    """Number cards are all equivalent for loop detection."""
    return card if card in PENALTY else "N"


def simulate_game(player_a, player_b):
    decks = [deque(player_a), deque(player_b)]
    total = len(player_a) + len(player_b)

    if total == 0 or not decks[0] or not decks[1]:
        # Degenerate setup: one player already holds every card.
        return {"status": "finished", "cards": 0, "tricks": 0}

    pile = []
    cards_played = 0
    tricks = 0
    starter = 0  # player who plays the first card of the current round
    seen = set()

    while True:
        # Round start: the pile is empty here, so the decks plus the starter
        # fully determine the future of the game.
        key = (
            tuple(_normalize(c) for c in decks[0]),
            tuple(_normalize(c) for c in decks[1]),
            starter,
        )
        if key in seen:
            return {"status": "loop", "cards": cards_played, "tricks": tricks}
        seen.add(key)

        # Play one round until someone collects the pile.
        turn = starter
        owed = 0    # cards the current payer still owes
        last = None # player who placed the most recent payment card

        while True:
            if not decks[turn]:
                # Player cannot play (fresh turn or during a penalty):
                # the other player collects the pile.
                collector = 1 - turn
                break

            card = decks[turn].popleft()
            pile.append(card)
            cards_played += 1

            if card in PENALTY:
                # Payment card: the opponent must pay (this interrupts any
                # penalty currently being paid).
                owed = PENALTY[card]
                last = turn
                turn = 1 - turn
            elif owed > 0:
                # Number card paid toward a penalty.
                owed -= 1
                if owed == 0:
                    collector = last
                    break
                # Otherwise the same player keeps paying.
            else:
                # Plain number card: play passes to the other player.
                turn = 1 - turn

        decks[collector].extend(pile)
        pile.clear()
        tricks += 1
        starter = collector

        if len(decks[collector]) == total:
            return {"status": "finished", "cards": cards_played, "tricks": tricks}
