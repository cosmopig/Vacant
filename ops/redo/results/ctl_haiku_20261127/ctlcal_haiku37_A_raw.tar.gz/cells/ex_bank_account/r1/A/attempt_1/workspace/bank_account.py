import threading


class BankAccount:
    def __init__(self):
        self._open = False
        self._balance = 0
        # A lock guards state changes so concurrent callers cannot interleave
        # a read of the balance with the write of the new balance.
        self._lock = threading.Lock()

    def _check_open(self):
        if not self._open:
            raise ValueError('account not open')

    def get_balance(self):
        with self._lock:
            self._check_open()
            return self._balance

    def open(self):
        with self._lock:
            if self._open:
                raise ValueError('account already open')
            self._open = True
            self._balance = 0

    def deposit(self, amount):
        with self._lock:
            self._check_open()
            if amount <= 0:
                raise ValueError('amount must be greater than 0')
            self._balance += amount

    def withdraw(self, amount):
        with self._lock:
            self._check_open()
            if amount <= 0:
                raise ValueError('amount must be greater than 0')
            if amount > self._balance:
                raise ValueError('amount must be less than balance')
            self._balance -= amount

    def close(self):
        with self._lock:
            self._check_open()
            self._open = False
            self._balance = 0
