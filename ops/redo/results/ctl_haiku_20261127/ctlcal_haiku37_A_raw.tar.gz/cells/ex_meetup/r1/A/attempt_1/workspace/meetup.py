import calendar
from datetime import date


# subclassing the built-in ValueError to create MeetupDayException
class MeetupDayException(ValueError):
    """Exception raised when the Meetup weekday and count do not result in a valid date.

    message: explanation of the error.

    """
    def __init__(self, message="That day does not exist."):
        super().__init__(message)
        self.message = message


_ORDINALS = {"first": 0, "second": 1, "third": 2, "fourth": 3, "fifth": 4}


def meetup(year, month, week, day_of_week):
    """Return the date of the meetup in the given year and month.

    week: one of "first", "second", "third", "fourth", "fifth", "last", "teenth".
    day_of_week: full English weekday name, e.g. "Monday".
    """
    weekday_names = list(calendar.day_name)
    if day_of_week not in weekday_names:
        raise MeetupDayException(f"Unknown weekday: {day_of_week!r}.")
    weekday = weekday_names.index(day_of_week)

    days_in_month = calendar.monthrange(year, month)[1]
    matches = [
        date(year, month, d)
        for d in range(1, days_in_month + 1)
        if date(year, month, d).weekday() == weekday
    ]

    if week == "teenth":
        for candidate in matches:
            if 13 <= candidate.day <= 19:
                return candidate
        raise MeetupDayException("That day does not exist.")

    if week == "last":
        return matches[-1]

    if week in _ORDINALS:
        index = _ORDINALS[week]
        if index < len(matches):
            return matches[index]
        raise MeetupDayException("That day does not exist.")

    raise MeetupDayException(f"Unknown week descriptor: {week!r}.")
