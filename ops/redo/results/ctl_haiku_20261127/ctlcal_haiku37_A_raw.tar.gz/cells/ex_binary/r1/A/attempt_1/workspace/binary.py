def parse_binary(binary_string):
    """Convert a binary string such as '101010' to its decimal value.

    The conversion is done manually by accumulating powers of two, without
    using int(..., 2) or any other built-in base conversion.

    Raises ValueError if the input is empty or contains anything other
    than '0' and '1'.
    """
    if not isinstance(binary_string, str) or binary_string == "":
        raise ValueError("Invalid binary literal: " + repr(binary_string))

    value = 0
    for digit in binary_string:
        if digit == "0":
            bit = 0
        elif digit == "1":
            bit = 1
        else:
            raise ValueError("Invalid binary literal: " + binary_string)
        # Horner's method: shift the accumulated value left one place
        # (multiply by 2) and add the new bit.
        value = value * 2 + bit
    return value
