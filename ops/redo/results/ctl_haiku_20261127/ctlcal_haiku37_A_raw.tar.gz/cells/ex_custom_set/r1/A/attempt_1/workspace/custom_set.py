class CustomSet:
    def __init__(self, elements=None):
        # Backed by a dict so membership checks and duplicate handling are O(1).
        # A fresh dict per instance avoids sharing state between sets.
        self._items = {}
        if elements is not None:
            for element in elements:
                self.add(element)

    def isempty(self):
        return not self._items

    def __contains__(self, element):
        return element in self._items

    def issubset(self, other):
        return all(element in other for element in self._items)

    def isdisjoint(self, other):
        return not any(element in other for element in self._items)

    def __eq__(self, other):
        if not isinstance(other, CustomSet):
            return NotImplemented
        return len(self._items) == len(other._items) and self.issubset(other)

    def __repr__(self):
        return f"CustomSet({list(self._items)!r})"

    def add(self, element):
        self._items[element] = None

    def intersection(self, other):
        return CustomSet(e for e in self._items if e in other)

    def __sub__(self, other):
        return CustomSet(e for e in self._items if e not in other)

    def __add__(self, other):
        return CustomSet([*self._items, *other._items])
