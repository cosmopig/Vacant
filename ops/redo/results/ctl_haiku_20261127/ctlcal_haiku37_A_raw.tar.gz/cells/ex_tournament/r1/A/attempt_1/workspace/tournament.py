HEADER = "Team                           | MP |  W |  D |  L |  P"


def _row(name, mp, w, d, l, p):
    return f"{name:<31}| {mp:>2} | {w:>2} | {d:>2} | {l:>2} | {p:>2}"


def tally(rows):
    stats = {}

    def entry(team):
        if team not in stats:
            stats[team] = {"W": 0, "D": 0, "L": 0}
        return stats[team]

    for line in rows:
        line = line.strip()
        if not line:
            continue
        parts = line.split(";")
        if len(parts) != 3:
            raise ValueError(f"invalid input line: {line!r}")
        first, second, outcome = (p.strip() for p in parts)

        if outcome == "win":
            entry(first)["W"] += 1
            entry(second)["L"] += 1
        elif outcome == "loss":
            entry(first)["L"] += 1
            entry(second)["W"] += 1
        elif outcome == "draw":
            entry(first)["D"] += 1
            entry(second)["D"] += 1
        else:
            raise ValueError(f"invalid outcome: {outcome!r}")

    table = []
    for team, s in stats.items():
        mp = s["W"] + s["D"] + s["L"]
        points = 3 * s["W"] + s["D"]
        table.append((team, mp, s["W"], s["D"], s["L"], points))

    # Sort by points descending, then team name ascending.
    table.sort(key=lambda r: (-r[5], r[0]))

    return [HEADER] + [_row(*r) for r in table]
