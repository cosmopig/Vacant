def find_fewest_coins(coins, target):
    """Return the fewest coins (sorted ascending) that sum to target.

    Raises ValueError if target is negative or cannot be made from the given coins.
    """
    if target < 0:
        raise ValueError("target can't be negative")

    # best[amount] = minimum number of coins to make amount (None if impossible)
    # last[amount] = coin value used last to reach amount
    best = [0] + [None] * target
    last = [None] * (target + 1)

    for amount in range(1, target + 1):
        for coin in coins:
            if coin <= 0 or coin > amount:
                continue
            prev = best[amount - coin]
            if prev is None:
                continue
            if best[amount] is None or prev + 1 < best[amount]:
                best[amount] = prev + 1
                last[amount] = coin

    if best[target] is None:
        raise ValueError("can't make target with given coins")

    result = []
    amount = target
    while amount > 0:
        coin = last[amount]
        result.append(coin)
        amount -= coin

    return sorted(result)
