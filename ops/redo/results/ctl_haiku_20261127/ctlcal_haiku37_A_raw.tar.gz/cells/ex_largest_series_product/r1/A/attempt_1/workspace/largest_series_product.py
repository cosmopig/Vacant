def largest_product(series, size):
    if size < 0:
        raise ValueError("span must not be negative")
    if size > len(series):
        raise ValueError("span must not exceed string length")
    if not all(char in "0123456789" for char in series):
        raise ValueError("digits input must only contain digits")

    digits = [int(char) for char in series]
    largest = 0
    for start in range(len(digits) - size + 1):
        product = 1
        for digit in digits[start:start + size]:
            product *= digit
        largest = max(largest, product)
    return largest
