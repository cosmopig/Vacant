import math


class ComplexNumber:
    def __init__(self, real, imaginary):
        self.real = real
        self.imaginary = imaginary

    @staticmethod
    def _coerce(other):
        """Convert a real number to a ComplexNumber; return None for unsupported types."""
        if isinstance(other, ComplexNumber):
            return other
        if isinstance(other, (int, float)) and not isinstance(other, bool):
            return ComplexNumber(other, 0)
        return None

    def __repr__(self):
        return f"ComplexNumber({self.real!r}, {self.imaginary!r})"

    def __eq__(self, other):
        other = self._coerce(other)
        if other is None:
            return NotImplemented
        return self.real == other.real and self.imaginary == other.imaginary

    def __ne__(self, other):
        result = self.__eq__(other)
        if result is NotImplemented:
            return result
        return not result

    __hash__ = None  # mutable-style value type; keep unhashable like other __eq__ classes

    def __add__(self, other):
        other = self._coerce(other)
        if other is None:
            return NotImplemented
        return ComplexNumber(self.real + other.real, self.imaginary + other.imaginary)

    def __radd__(self, other):
        return self.__add__(other)

    def __sub__(self, other):
        other = self._coerce(other)
        if other is None:
            return NotImplemented
        return ComplexNumber(self.real - other.real, self.imaginary - other.imaginary)

    def __rsub__(self, other):
        other = self._coerce(other)
        if other is None:
            return NotImplemented
        return other.__sub__(self)

    def __mul__(self, other):
        other = self._coerce(other)
        if other is None:
            return NotImplemented
        a, b = self.real, self.imaginary
        c, d = other.real, other.imaginary
        return ComplexNumber(a * c - b * d, b * c + a * d)

    def __rmul__(self, other):
        return self.__mul__(other)

    def __truediv__(self, other):
        other = self._coerce(other)
        if other is None:
            return NotImplemented
        a, b = self.real, self.imaginary
        c, d = other.real, other.imaginary
        denom = c * c + d * d
        if denom == 0:
            raise ZeroDivisionError("complex division by zero")
        return ComplexNumber((a * c + b * d) / denom, (b * c - a * d) / denom)

    def __rtruediv__(self, other):
        other = self._coerce(other)
        if other is None:
            return NotImplemented
        return other.__truediv__(self)

    def __abs__(self):
        return math.hypot(self.real, self.imaginary)

    def conjugate(self):
        return ComplexNumber(self.real, -self.imaginary)

    def exp(self):
        magnitude = math.exp(self.real)
        return ComplexNumber(
            magnitude * math.cos(self.imaginary),
            magnitude * math.sin(self.imaginary),
        )
