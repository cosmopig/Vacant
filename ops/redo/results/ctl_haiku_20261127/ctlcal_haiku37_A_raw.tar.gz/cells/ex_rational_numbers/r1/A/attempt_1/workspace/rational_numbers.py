from math import gcd


class Rational:
    def __init__(self, numer, denom):
        if denom == 0:
            raise ZeroDivisionError("denominator must not be zero")
        # Reduce to lowest terms with a positive denominator (standard form).
        g = gcd(numer, denom)
        if g == 0:
            g = 1
        numer, denom = numer // g, denom // g
        if denom < 0:
            numer, denom = -numer, -denom
        self.numer = numer
        self.denom = denom

    @staticmethod
    def _coerce(other):
        if isinstance(other, Rational):
            return other
        if isinstance(other, int):
            return Rational(other, 1)
        return None

    def __eq__(self, other):
        other = self._coerce(other)
        if other is None:
            return NotImplemented
        return self.numer == other.numer and self.denom == other.denom

    def __hash__(self):
        return hash((self.numer, self.denom))

    def __repr__(self):
        return f'{self.numer}/{self.denom}'

    def __add__(self, other):
        other = self._coerce(other)
        if other is None:
            return NotImplemented
        return Rational(self.numer * other.denom + other.numer * self.denom,
                        self.denom * other.denom)

    def __sub__(self, other):
        other = self._coerce(other)
        if other is None:
            return NotImplemented
        return Rational(self.numer * other.denom - other.numer * self.denom,
                        self.denom * other.denom)

    def __mul__(self, other):
        other = self._coerce(other)
        if other is None:
            return NotImplemented
        return Rational(self.numer * other.numer, self.denom * other.denom)

    def __truediv__(self, other):
        other = self._coerce(other)
        if other is None:
            return NotImplemented
        if other.numer == 0:
            raise ZeroDivisionError("division by zero rational")
        return Rational(self.numer * other.denom, self.denom * other.numer)

    def __abs__(self):
        return Rational(abs(self.numer), self.denom)

    def __pow__(self, power):
        if isinstance(power, Rational):
            if power.denom == 1:
                power = power.numer
            else:
                # Rational exponent of a rational base: a real number.
                return (self.numer / self.denom) ** (power.numer / power.denom)
        if isinstance(power, int):
            if power >= 0:
                return Rational(self.numer ** power, self.denom ** power)
            m = -power
            if self.numer == 0:
                raise ZeroDivisionError("zero cannot be raised to a negative power")
            return Rational(self.denom ** m, self.numer ** m)
        if isinstance(power, float):
            # (a^x) / (b^x), a real number.
            return (self.numer ** power) / (self.denom ** power)
        return NotImplemented

    def __rpow__(self, base):
        # real ** Rational = root(base^a, b), i.e. base ** (a/b).
        if isinstance(base, (int, float)):
            return base ** (self.numer / self.denom)
        return NotImplemented
