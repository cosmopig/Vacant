def rows(row_count):
    """Return the first ``row_count`` rows of Pascal's triangle, computed recursively."""
    if row_count < 0:
        raise ValueError("number of rows is negative")
    if row_count == 0:
        return []
    if row_count == 1:  # base case
        return [[1]]

    previous = rows(row_count - 1)  # recursive case
    last = previous[-1]
    new_row = [1] + [last[i] + last[i + 1] for i in range(len(last) - 1)] + [1]
    return previous + [new_row]
