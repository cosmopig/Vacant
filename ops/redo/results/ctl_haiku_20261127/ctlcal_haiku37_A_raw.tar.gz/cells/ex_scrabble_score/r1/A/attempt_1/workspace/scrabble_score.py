LETTER_VALUES = {}
for _letters, _value in (
    ("AEIOULNRST", 1),
    ("DG", 2),
    ("BCMP", 3),
    ("FHVWY", 4),
    ("K", 5),
    ("JX", 8),
    ("QZ", 10),
):
    for _letter in _letters:
        LETTER_VALUES[_letter] = _value


def score(word):
    return sum(LETTER_VALUES.get(letter, 0) for letter in word.upper())
