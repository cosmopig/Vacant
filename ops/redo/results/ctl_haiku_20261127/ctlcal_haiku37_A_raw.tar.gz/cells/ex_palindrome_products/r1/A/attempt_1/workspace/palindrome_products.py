def _is_palindrome(number):
    text = str(number)
    return text == text[::-1]


def _validate(min_factor, max_factor):
    if min_factor > max_factor:
        raise ValueError("min must be <= max")


def largest(*, min_factor=0, max_factor):
    """Given a range of numbers, find the largest palindromes which
       are products of two numbers within that range.

    :param min_factor: int with a default value of 0
    :param max_factor: int
    :return: tuple of (palindrome, iterable).
             Iterable should contain both factors of the palindrome in an arbitrary order.
    """
    _validate(min_factor, max_factor)

    best = None
    factors = []
    for a in range(max_factor, min_factor - 1, -1):
        # Largest possible product with this a is a * max_factor; stop once below best.
        if best is not None and a * max_factor < best:
            break
        for b in range(max_factor, a - 1, -1):
            product = a * b
            if best is not None and product < best:
                break
            if _is_palindrome(product):
                if best is None or product > best:
                    best = product
                    factors = [(a, b)]
                elif product == best:
                    factors.append((a, b))
                break  # smaller b only gives smaller products for this a

    if best is None:
        return None, []
    return best, factors


def smallest(*, min_factor=0, max_factor):
    """Given a range of numbers, find the smallest palindromes which
    are products of two numbers within that range.

    :param min_factor: int with a default value of 0
    :param max_factor: int
    :return: tuple of (palindrome, iterable).
    Iterable should contain both factors of the palindrome in an arbitrary order.
    """
    _validate(min_factor, max_factor)

    best = None
    factors = []
    for a in range(min_factor, max_factor + 1):
        # Smallest possible product with this a is a * a; stop once above best.
        if best is not None and a * a > best:
            break
        for b in range(a, max_factor + 1):
            product = a * b
            if best is not None and product > best:
                break
            if _is_palindrome(product):
                if best is None or product < best:
                    best = product
                    factors = [(a, b)]
                elif product == best:
                    factors.append((a, b))
                break  # larger b only gives larger products for this a

    if best is None:
        return None, []
    return best, factors
