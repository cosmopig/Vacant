class Node:
    def __init__(self, value, succeeding=None, previous=None):
        self.value = value
        self.succeeding = succeeding
        self.previous = previous


class LinkedList:
    def __init__(self):
        self.head = None
        self.tail = None
        self.length = 0

    def __len__(self):
        return self.length

    def __iter__(self):
        node = self.head
        while node is not None:
            yield node.value
            node = node.succeeding

    def push(self, value):
        """Add a value to the end of the list."""
        node = Node(value, previous=self.tail)
        if self.tail is None:
            self.head = node
        else:
            self.tail.succeeding = node
        self.tail = node
        self.length += 1

    def pop(self):
        """Remove and return the value at the end of the list."""
        if self.length == 0:
            raise IndexError("List is empty")
        node = self.tail
        self._unlink(node)
        return node.value

    def unshift(self, value):
        """Add a value to the beginning of the list."""
        node = Node(value, succeeding=self.head)
        if self.head is None:
            self.tail = node
        else:
            self.head.previous = node
        self.head = node
        self.length += 1

    def shift(self):
        """Remove and return the value at the beginning of the list."""
        if self.length == 0:
            raise IndexError("List is empty")
        node = self.head
        self._unlink(node)
        return node.value

    def delete(self, value):
        """Remove the first node holding value; raise ValueError if absent."""
        node = self.head
        while node is not None:
            if node.value == value:
                self._unlink(node)
                return
            node = node.succeeding
        raise ValueError("Value not found")

    def _unlink(self, node):
        """Detach node from the list, updating head, tail and length."""
        if node.previous is None:
            self.head = node.succeeding
        else:
            node.previous.succeeding = node.succeeding
        if node.succeeding is None:
            self.tail = node.previous
        else:
            node.succeeding.previous = node.previous
        node.previous = None
        node.succeeding = None
        self.length -= 1
