class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def __eq__(self, other):
        if not isinstance(other, Point):
            return NotImplemented
        return self.x == other.x and self.y == other.y

    def __hash__(self):
        return hash((self.x, self.y))

    def __repr__(self):
        return f"Point({self.x}, {self.y})"


DIRECTIONS = [
    (-1, -1), (0, -1), (1, -1),
    (-1, 0),           (1, 0),
    (-1, 1),  (0, 1),  (1, 1),
]


class WordSearch:
    def __init__(self, puzzle):
        self.grid = list(puzzle)
        self.height = len(self.grid)
        self.width = len(self.grid[0]) if self.height else 0

    def search(self, word):
        """Return (start, end) Points of the word, or None if it is not found.

        Words may run in any of the eight directions. Coordinates are
        (x, y) = (column, row).
        """
        if not word:
            return None
        first = word[0]
        for y in range(self.height):
            for x in range(len(self.grid[y])):
                if self.grid[y][x] != first:
                    continue
                for dx, dy in DIRECTIONS:
                    if self._matches(word, x, y, dx, dy):
                        end_x = x + dx * (len(word) - 1)
                        end_y = y + dy * (len(word) - 1)
                        return (Point(x, y), Point(end_x, end_y))
        return None

    def _matches(self, word, x, y, dx, dy):
        for i, ch in enumerate(word):
            cx = x + dx * i
            cy = y + dy * i
            if not (0 <= cy < self.height and 0 <= cx < len(self.grid[cy])):
                return False
            if self.grid[cy][cx] != ch:
                return False
        return True
