ONES = [
    "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine",
    "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen",
    "seventeen", "eighteen", "nineteen",
]
TENS = [
    "", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety",
]
SCALES = [
    (1_000_000_000, "billion"),
    (1_000_000, "million"),
    (1_000, "thousand"),
]


def _below_thousand(n):
    """Spell out 1 <= n <= 999 (no leading 'zero' for n == 0)."""
    words = []
    hundreds, rest = divmod(n, 100)
    if hundreds:
        words.append(f"{ONES[hundreds]} hundred")
    if rest:
        if rest < 20:
            words.append(ONES[rest])
        else:
            tens, ones = divmod(rest, 10)
            words.append(f"{TENS[tens]}-{ONES[ones]}" if ones else TENS[tens])
    return " ".join(words)


def say(number):
    if not isinstance(number, int) or isinstance(number, bool):
        raise ValueError("input must be an integer")
    if number < 0 or number > 999_999_999_999:
        raise ValueError("input out of range")
    if number == 0:
        return "zero"

    parts = []
    remainder = number
    for value, name in SCALES:
        chunk, remainder = divmod(remainder, value)
        if chunk:
            parts.append(f"{_below_thousand(chunk)} {name}")
    if remainder:
        parts.append(_below_thousand(remainder))
    return " ".join(parts)
