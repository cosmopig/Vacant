DEFAULT_STUDENTS = [
    "Alice", "Bob", "Charlie", "David", "Eve", "Fred",
    "Ginny", "Harriet", "Ileana", "Joseph", "Kincaid", "Larry",
]

PLANTS = {
    "G": "Grass",
    "C": "Clover",
    "R": "Radishes",
    "V": "Violets",
}


class Garden:
    def __init__(self, diagram, students=None):
        # The tests call Garden(diagram) with the default roster, so students
        # defaults to None and falls back to the twelve-child roster.
        if students is None:
            students = DEFAULT_STUDENTS
        self.rows = diagram.split("\n")
        self.students = sorted(students)

    def plants(self, student):
        # Each child gets two columns in each row; children are assigned
        # cups alphabetically, so the index is the position in sorted order.
        start = self.students.index(student) * 2
        result = []
        for row in self.rows:
            for code in row[start:start + 2]:
                result.append(PLANTS[code])
        return result
