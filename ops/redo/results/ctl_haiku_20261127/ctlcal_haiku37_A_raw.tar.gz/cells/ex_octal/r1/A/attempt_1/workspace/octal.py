def parse_octal(digits):
    """Convert an octal digit string to its decimal value without built-in base conversion.

    Raises ValueError if the string is empty or contains anything other than 0-7.
    """
    if not digits:
        raise ValueError("empty string is not a valid octal number")

    value = 0
    for ch in digits:
        if ch < "0" or ch > "7":
            raise ValueError(f"invalid octal digit {ch!r} in {digits!r}")
        value = value * 8 + (ord(ch) - ord("0"))
    return value
