import sys
from collections import deque


def check(p, n, adj, a, b):
    """Return True if the hero starting with power p can beat all monsters.

    Maintain a set S of beaten caves (containing cave 1) and the current power cur.
    Repeatedly search for an 'augmenting ear': a walk leaving S through new caves,
    which either returns to S or meets a cave already on another such walk.
    Every ear found is absorbed into S. Greedy absorption is safe because power only grows.
    """
    inS = [False] * (n + 1)
    inS[1] = True
    cur = p
    cnt = 1
    while cnt < n:
        par = [0] * (n + 1)
        vis = [False] * (n + 1)
        pw = [0] * (n + 1)
        dq = deque()
        for u in range(1, n + 1):
            if inS[u]:
                dq.append(u)
        found = None  # (x, y) pair: x is the vertex being expanded, y the target
        while dq and found is None:
            x = dq.popleft()
            px = cur if inS[x] else pw[x]
            px_par = par[x]
            for y in adj[x]:
                if y == px_par:
                    continue
                if inS[y]:
                    if inS[x]:
                        continue
                    found = (x, y)
                    break
                if px <= a[y]:
                    continue
                if vis[y]:
                    if par[y] == x:
                        continue
                    found = (x, y)
                    break
                vis[y] = True
                par[y] = x
                pw[y] = px + b[y]
                dq.append(y)
        if found is None:
            return False
        x, y = found
        # Absorb every outside cave on the walk ending at x, and on the walk ending at y.
        for start in (x, y):
            v = start
            while v and not inS[v]:
                inS[v] = True
                cur += b[v]
                cnt += 1
                v = par[v]
    return True


def solve(data):
    it = iter(data)
    t = int(next(it))
    out = []
    for _ in range(t):
        n = int(next(it))
        m = int(next(it))
        a = [0, 0] + [int(next(it)) for _ in range(n - 1)]
        b = [0, 0] + [int(next(it)) for _ in range(n - 1)]
        adj = [[] for _ in range(n + 1)]
        for _ in range(m):
            u = int(next(it))
            v = int(next(it))
            adj[u].append(v)
            adj[v].append(u)
        lo, hi = 1, max(a) + 1  # hi always works: every monster is beatable
        while lo < hi:
            mid = (lo + hi) // 2
            if check(mid, n, adj, a, b):
                hi = mid
            else:
                lo = mid + 1
        out.append(str(lo))
    return "\n".join(out)


def main():
    sys.stdout.write(solve(sys.stdin.read().split()) + "\n")


if __name__ == "__main__":
    main()
