// Count sequences a_1..a_n in [0, 2^k) such that no non-empty subsequence XORs to x.
//
// Let V = span(a). The condition is x not in V (for x = 0: the a_i are linearly
// independent, i.e. no non-empty subset XORs to 0).
//
// x = 0: answer = prod_{j=0}^{n-1} (2^k - 2^j) if n <= k, else 0.
//
// x != 0: answer = sum_{i=0}^{min(n,k)} A_i * S_i where
//   S_i = #n-tuples spanning a fixed i-dim space = prod_{j=0}^{i-1} (2^n - 2^j)
//   A_i = #i-dim subspaces of F_2^k not containing x
//       = G(k,i) - G(k-1,i-1) = G(k,i) * (2^k - 2^i) / (2^k - 1)
//   G(k,i) = Gaussian binomial [k choose i]_2, with
//   G(k,i) = G(k,i-1) * (2^{k-i+1} - 1) / (2^i - 1).
#include <bits/stdc++.h>
using namespace std;

typedef unsigned long long ull;
typedef long long ll;
static const ull MOD = 998244353ULL;

static ull pw(ull b, ull e) {
    ull r = 1;
    b %= MOD;
    while (e) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

int main() {
    int t;
    if (scanf("%d", &t) != 1) return 0;
    vector<ll> N(t), K(t), X(t);
    ll maxK = 1;
    for (int i = 0; i < t; i++) {
        scanf("%lld %lld %lld", &N[i], &K[i], &X[i]);
        maxK = max(maxK, K[i]);
    }

    // pow2[i] = 2^i mod p for i in [0, maxK]
    vector<uint32_t> pow2(maxK + 2);
    pow2[0] = 1;
    for (ll i = 1; i <= maxK + 1; i++) pow2[i] = (uint32_t)(pow2[i - 1] * 2ULL % MOD);

    // invm[i] = inverse of (2^i - 1) mod p, for i in [1, maxK], via batch inversion.
    vector<uint32_t> invm(maxK + 2, 0);
    vector<uint32_t> pre(maxK + 1);
    pre[0] = 1;
    for (ll i = 1; i <= maxK; i++) {
        ull m = (pow2[i] + MOD - 1) % MOD;
        pre[i] = (uint32_t)(pre[i - 1] * m % MOD);
    }
    ull invAll = pw(pre[maxK], MOD - 2);
    for (ll i = maxK; i >= 1; i--) {
        invm[i] = (uint32_t)(invAll * pre[i - 1] % MOD);
        invAll = invAll * ((pow2[i] + MOD - 1) % MOD) % MOD;
    }

    string out;
    out.reserve((size_t)t * 12);
    for (int tc = 0; tc < t; tc++) {
        ll n = N[tc], k = K[tc], x = X[tc];
        ull ans = 0;
        if (x == 0) {
            if (n > k) {
                ans = 0;
            } else {
                ans = 1;
                for (ll j = 0; j < n; j++) {
                    ull f = (pow2[k] + MOD - pow2[j]) % MOD;
                    ans = ans * f % MOD;
                }
            }
        } else {
            // k >= 1 here since x < 2^min(20,k) and x > 0.
            ull twoN = pw(2, (ull)n);
            ull invK = invm[k];
            ull pk = pow2[k];
            ll lim = min(n, k);
            ull G = 1, S = 1;
            for (ll i = 0; i <= lim; i++) {
                if (i > 0) {
                    ull num = (pow2[k - i + 1] + MOD - 1) % MOD;
                    G = G * num % MOD * invm[i] % MOD;
                    S = S * ((twoN + MOD - pow2[i - 1]) % MOD) % MOD;
                }
                ull f = (pk + MOD - pow2[i]) % MOD;
                ull A = G * f % MOD * invK % MOD;
                ans = (ans + A * S) % MOD;
            }
        }
        out += to_string(ans);
        out += '\n';
    }
    fputs(out.c_str(), stdout);
    return 0;
}
