import sys


def solve(n, m, k, a):
    MOD = 10 ** 9 + 7
    N = n * m

    # Q[r] = (a_1 + ... + a_r) mod k for r in [0, n); Q[0] = 0.
    Q = [0] * n
    cur = 0
    for r in range(n):
        Q[r] = cur
        cur = (cur + a[r]) % k
    T = cur  # (sum of one copy of a) mod k

    if T % k == 0:
        # Prefix sums are N-periodic mod k in this case, so each start i
        # pairs with every other position in its residue class.
        hist = [0] * k
        for q in Q:
            hist[q] += 1
        total = 0
        for v in range(k):
            c = hist[v] * m
            total += c * (c - 1)
        total += 1  # full circle: m*T = 0 mod k
    elif m % k == 0:
        # Residues are uniformly distributed over the N positions.
        total = N * (N // k - 1) + 1
    else:
        # T invertible, shift by N changes residues by m*T != 0.
        inv = pow(T, k - 2, k)
        u = [(q * inv) % k for q in Q]
        H = [0] * k
        for x in u:
            H[x] += 1

        # Term1: pairs (r1, r2) weighted by #{d in [1, m-1] : d = u1 - u2 mod k}.
        q_, s = divmod(m - 1, k)
        term1 = q_ * n * n
        A = H + H
        PS = [0] * (2 * k + 1)
        for x in range(2 * k):
            PS[x + 1] = PS[x] + A[x]
        for u1 in range(k):
            if H[u1]:
                # sum of H over residues u1-s .. u1-1 (mod k)
                term1 += H[u1] * (PS[u1 + k] - PS[u1 + k - s])

        # Term2: r1 < r2 with u1 == u2  (d = 0 boundary).
        # Term3: r2 < r1 with u1 - u2 == m mod k  (d = m boundary).
        seen = [0] * k
        term2 = 0
        term3 = 0
        for r in range(n):
            ur = u[r]
            term2 += seen[ur]
            term3 += seen[(ur - m) % k]
            seen[ur] += 1

        total = m * (term1 + term2 + term3)

    return total % MOD


def main():
    data = sys.stdin.buffer.read().split()
    n, m, k = int(data[0]), int(data[1]), int(data[2])
    a = [int(x) for x in data[3:3 + n]]
    print(solve(n, m, k, a))


if __name__ == "__main__":
    main()
