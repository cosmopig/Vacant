import sys
import heapq
from bisect import insort, bisect_left


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); m = int(data[pos + 1]); pos += 2

    # L: all edges sorted by weight, as (w, u, v) with u < v.
    # adj[x]: sorted list of (w, other) for edges incident to x.
    L = []
    adj = [[] for _ in range(n + 1)]
    ver = [0] * (n + 1)
    heap = []  # (sum of three smallest incident weights, vertex, version)

    def refresh(x):
        ver[x] += 1
        a = adj[x]
        if len(a) >= 3:
            heapq.heappush(heap, (a[0][0] + a[1][0] + a[2][0], x, ver[x]))

    def add_edge(u, v, w):
        if u > v:
            u, v = v, u
        insort(L, (w, u, v))
        insort(adj[u], (w, v))
        insort(adj[v], (w, u))
        refresh(u)
        refresh(v)

    def del_edge(u, v, w):
        if u > v:
            u, v = v, u
        i = bisect_left(L, (w, u, v))
        del L[i]
        a = adj[u]
        del a[bisect_left(a, (w, v))]
        b = adj[v]
        del b[bisect_left(b, (w, u))]
        refresh(u)
        refresh(v)

    for _ in range(m):
        v = int(data[pos]); u = int(data[pos + 1]); w = int(data[pos + 2]); pos += 3
        add_edge(v, u, w)

    def best_star():
        # Min over vertices x (deg >= 3) of the sum of the 3 smallest incident edges.
        while heap and heap[0][2] != ver[heap[0][1]]:
            heapq.heappop(heap)
        return heap[0][0] if heap else float('inf')

    def best_disjoint(best):
        # Min over pairs of vertex-disjoint edges, pruned by the current best.
        size = len(L)
        for i in range(size):
            w1, u, v = L[i]
            if i + 1 < size and w1 + L[i + 1][0] >= best:
                break
            for j in range(i + 1, size):
                w2, a, b = L[j]
                if w1 + w2 >= best:
                    break
                if a != u and a != v and b != u and b != v:
                    best = w1 + w2
                    break
        return best

    def answer():
        return best_disjoint(best_star())

    out = [str(answer())]
    q = int(data[pos]); pos += 1
    for _ in range(q):
        t = data[pos]
        if t == b'0':
            v = int(data[pos + 1]); u = int(data[pos + 2]); pos += 3
            a, b = (v, u) if v < u else (u, v)
            # find its weight
            w = None
            for ww, other in adj[a]:
                if other == b:
                    w = ww
                    break
            del_edge(a, b, w)
        else:
            v = int(data[pos + 1]); u = int(data[pos + 2]); w = int(data[pos + 3]); pos += 4
            add_edge(v, u, w)
        out.append(str(answer()))

    sys.stdout.write("\n".join(out) + "\n")


main()
