#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

struct Edge {
    int to, rev, cap;
    ll cost;
};
vector<vector<Edge>> g;

void addEdge(int u, int v, int cap, ll cost) {
    g[u].push_back({v, (int)g[v].size(), cap, cost});
    g[v].push_back({u, (int)g[u].size() - 1, 0, -cost});
}

int main() {
    int n, k;
    if (scanf("%d %d", &n, &k) != 2) return 0;
    int N = 1 << n;
    vector<ll> a(N);
    for (int i = 0; i < N; i++) scanf("%lld", &a[i]);

    // Keep only the top M edges by weight a_u + a_v (hypercube edges).
    ll totalEdges = (ll)n * (N / 2);
    ll M = (ll)(2 * n - 1) * (k - 1) + 1;
    if (M > totalEdges) M = totalEdges;

    // min-heap of (weight, u, v), keeps the M heaviest edges seen so far
    typedef tuple<ll, int, int> T;
    priority_queue<T, vector<T>, greater<T>> pq;
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < n; j++) {
            if (i >> j & 1) continue;
            int v = i | (1 << j);
            ll w = a[i] + a[v];
            if ((ll)pq.size() < M) {
                pq.emplace(w, i, v);
            } else if (w > get<0>(pq.top())) {
                pq.pop();
                pq.emplace(w, i, v);
            }
        }
    }

    vector<T> edges;
    edges.reserve(pq.size());
    while (!pq.empty()) {
        edges.push_back(pq.top());
        pq.pop();
    }

    // Map vertices to compact ids. Left = even popcount, right = odd popcount.
    vector<int> id(N, -1);
    int cnt = 2;  // 0 = source, 1 = sink
    vector<int> leftIds, rightIds;
    auto getId = [&](int x, bool isLeft) {
        if (id[x] == -1) {
            id[x] = cnt++;
            (isLeft ? leftIds : rightIds).push_back(id[x]);
        }
        return id[x];
    };

    struct BE { int l, r; ll w; };
    vector<BE> bedges;
    bedges.reserve(edges.size());
    for (auto &e : edges) {
        ll w; int x, y;
        tie(w, x, y) = e;
        int L = (__builtin_popcount(x) % 2 == 0) ? x : y;
        int R = (L == x) ? y : x;
        int li = getId(L, true);
        int ri = getId(R, false);
        bedges.push_back({li, ri, w});
    }

    g.assign(cnt, {});
    for (int l : leftIds) addEdge(0, l, 1, 0);
    for (int r : rightIds) addEdge(r, 1, 1, 0);
    for (auto &b : bedges) addEdge(b.l, b.r, 1, -b.w);

    // Initial potentials via DAG shortest paths (s -> L -> R -> t).
    const ll INF = LLONG_MAX / 4;
    vector<ll> h(cnt, INF);
    h[0] = 0;
    for (int l : leftIds) h[l] = 0;
    for (auto &b : bedges) h[b.r] = min(h[b.r], -b.w);
    h[1] = INF;
    for (int r : rightIds) h[1] = min(h[1], h[r]);

    ll ans = 0;
    vector<ll> dist(cnt);
    vector<int> pv(cnt), pe(cnt);
    for (int it = 0; it < k; it++) {
        fill(dist.begin(), dist.end(), INF);
        dist[0] = 0;
        priority_queue<pair<ll, int>, vector<pair<ll, int>>, greater<pair<ll, int>>> q;
        q.push({0, 0});
        while (!q.empty()) {
            auto [d, u] = q.top();
            q.pop();
            if (d > dist[u]) continue;
            for (int ei = 0; ei < (int)g[u].size(); ei++) {
                Edge &e = g[u][ei];
                if (e.cap <= 0) continue;
                ll nd = d + e.cost + h[u] - h[e.to];
                if (nd < dist[e.to]) {
                    dist[e.to] = nd;
                    pv[e.to] = u;
                    pe[e.to] = ei;
                    q.push({nd, e.to});
                }
            }
        }
        if (dist[1] >= INF) break;
        for (int v = 0; v < cnt; v++)
            if (dist[v] < INF) h[v] += dist[v];
        ll cost = h[1] - h[0];  // actual shortest path cost (negated gain)
        ll gain = -cost;
        if (gain <= 0) break;  // gains are non-increasing, so stop here
        ans += gain;
        // augment one unit along the path
        for (int v = 1; v != 0; v = pv[v]) {
            Edge &e = g[pv[v]][pe[v]];
            e.cap -= 1;
            g[v][e.rev].cap += 1;
        }
    }

    printf("%lld\n", ans);
    return 0;
}
