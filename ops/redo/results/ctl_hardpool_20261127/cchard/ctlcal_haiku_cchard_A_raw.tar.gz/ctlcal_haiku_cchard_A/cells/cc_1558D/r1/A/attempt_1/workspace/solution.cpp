// Insertion Sorting counting.
//
// Model: the final sorted list F (elements are indices 1..n) has a fixed order
// determined by the insertions. Insertion i moves element x_i in front of its
// right neighbour R_i (the element at position y_i of the list before the move).
// Values must satisfy F weakly increasing along the list and v(x_i) < v(R_i).
// Counting via inclusion-exclusion over the "violated" constraints, the laminar
// structure of the intervals cancels every non-leaf constraint, leaving only
// constraints that are adjacent in F. If L is their number:
//     answer = sum_{j=0..L} (-1)^j C(L, j) C(2n-1-j, n-1).
// x_i is a leaf iff the element immediately after x_i in F has index < x_i.
//
// The list is kept as an implicit treap whose nodes are runs of consecutive
// untouched indices or single moved elements, so each test costs O(m log m).

#include <bits/stdc++.h>
using namespace std;

const long long MOD = 998244353LL;
const int MAXNODE = 700010;

int lc[MAXNODE], rc[MAXNODE], lenv[MAXNODE], szv[MAXNODE];
int lov[MAXNODE];
unsigned pr[MAXNODE];
int cntNode;
mt19937 rng(20240601);

long long pw(long long b, long long e) {
    long long r = 1;
    b %= MOD;
    while (e > 0) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

void upd(int t) {
    szv[t] = szv[lc[t]] + lenv[t] + szv[rc[t]];
}

int newNode(int lo, int len) {
    int t = ++cntNode;
    lc[t] = rc[t] = 0;
    lov[t] = lo;
    lenv[t] = len;
    pr[t] = rng();
    upd(t);
    return t;
}

int merge(int a, int b) {
    if (!a) return b;
    if (!b) return a;
    if (pr[a] > pr[b]) {
        rc[a] = merge(rc[a], b);
        upd(a);
        return a;
    } else {
        lc[b] = merge(a, lc[b]);
        upd(b);
        return b;
    }
}

// Splits t into the first k elements (a) and the rest (b).
pair<int, int> split(int t, int k) {
    if (!t) return {0, 0};
    int ls = szv[lc[t]];
    if (k <= ls) {
        auto pr2 = split(lc[t], k);
        lc[t] = pr2.second;
        upd(t);
        return {pr2.first, t};
    }
    k -= ls;
    if (k >= lenv[t]) {
        auto pr2 = split(rc[t], k - lenv[t]);
        rc[t] = pr2.first;
        upd(t);
        return {t, pr2.second};
    }
    if (k == 0) {
        int a = lc[t];
        lc[t] = 0;
        upd(t);
        return {a, t};
    }
    // Split a run node strictly inside it.
    int r = newNode(lov[t] + k, lenv[t] - k);
    rc[r] = rc[t];
    lenv[t] = k;
    rc[t] = 0;
    upd(r);
    upd(t);
    return {t, r};
}

int leftmost(int t) {
    while (lc[t]) t = lc[t];
    return t;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    const int FMAX = 400010;
    vector<long long> fact(FMAX + 1), inv(FMAX + 1);
    fact[0] = 1;
    for (int i = 1; i <= FMAX; i++) fact[i] = fact[i - 1] * i % MOD;
    inv[FMAX] = pw(fact[FMAX], MOD - 2);
    for (int i = FMAX; i > 0; i--) inv[i - 1] = inv[i] * i % MOD;
    auto C = [&](long long a, long long b) -> long long {
        if (b < 0 || a < 0 || b > a) return 0;
        return fact[a] * inv[b] % MOD * inv[a - b] % MOD;
    };

    int T;
    cin >> T;
    string out;
    while (T--) {
        int n, m;
        cin >> n >> m;
        vector<int> X(m), Y(m);
        for (int i = 0; i < m; i++) cin >> X[i] >> Y[i];

        cntNode = 0;
        szv[0] = 0;
        int root = 0;
        int prev = 0;
        vector<int> R(m), nodeOf(m);
        for (int i = 0; i < m; i++) {
            int x = X[i], y = Y[i];
            // Append untouched indices prev+1 .. x-1.
            if (x - 1 > prev) {
                root = merge(root, newNode(prev + 1, x - 1 - prev));
                prev = x - 1;
            }
            auto ab = split(root, y - 1);
            R[i] = lov[leftmost(ab.second)];
            int s = newNode(x, 1);
            nodeOf[i] = s;
            root = merge(ab.first, merge(s, ab.second));
            prev = x;
        }
        if (prev < n) root = merge(root, newNode(prev + 1, n - prev));

        // In-order traversal of the final list.
        vector<int> seq;
        seq.reserve(cntNode);
        {
            vector<int> st;
            int cur = root;
            while (cur || !st.empty()) {
                while (cur) {
                    st.push_back(cur);
                    cur = lc[cur];
                }
                cur = st.back();
                st.pop_back();
                seq.push_back(cur);
                cur = rc[cur];
            }
        }
        vector<int> posOf(cntNode + 1, -1);
        for (int p = 0; p < (int)seq.size(); p++) posOf[seq[p]] = p;

        long long L = 0;
        for (int i = 0; i < m; i++) {
            int p = posOf[nodeOf[i]];
            if (p + 1 < (int)seq.size() && lov[seq[p + 1]] < X[i]) L++;
        }

        long long ans = 0;
        for (long long j = 0; j <= L; j++) {
            long long term = C(L, j) * C(2LL * n - 1 - j, n - 1) % MOD;
            if (j & 1) ans = (ans - term + MOD) % MOD;
            else ans = (ans + term) % MOD;
        }
        out += to_string(ans);
        out += '\n';
    }
    cout << out;
    return 0;
}
