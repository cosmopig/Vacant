import sys


def main():
    n = int(sys.stdin.read().split()[0])
    M = 998244353
    P = 10 ** 9 + 7
    L = len(str(n))
    pw = [10 ** k for k in range(L + 2)]

    def rank(x, d):
        # number of y in [1, n] with str(y) <=lex str(x); x has d digits
        total = 0
        for k in range(1, L + 1):
            if k <= d:
                total += x // pw[d - k] - pw[k - 1] + 1
            else:
                nk = min(n, pw[k] - 1)
                hi = min(nk, x * pw[k - d] - 1)
                total += hi - pw[k - 1] + 1
        return total

    # i - a_i = rank(x) - x, where x = a_i. Over all x, the sum of (rank(x) - x) is 0,
    # so the answer is -M * S mod P with S = sum of floor(v(x) / M), v(x) = rank(x) - x.
    # Within a digit-length block v is non-decreasing (rank is increasing there).
    S = 0
    for d in range(1, L + 1):
        lo = pw[d - 1]
        hi = min(n, pw[d] - 1)

        def v(x):
            return rank(x, d) - x

        vlo = v(lo)
        vhi = v(hi)
        qmin = vlo // M
        qmax = vhi // M
        S += (hi - lo + 1) * qmin
        for q in range(qmin + 1, qmax + 1):
            c = q * M
            a, b = lo, hi
            while a < b:
                mid = (a + b) // 2
                if v(mid) >= c:
                    b = mid
                else:
                    a = mid + 1
            S += hi - a + 1

    print((-M * S) % P)


main()
