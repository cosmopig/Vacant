#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll MOD = 1000000007LL;

ll pw(ll b, ll e) {
    ll r = 1;
    b %= MOD;
    if (b < 0) b += MOD;
    while (e > 0) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

int main() {
    int n;
    ll k;
    if (scanf("%d %lld", &n, &k) != 2) return 0;
    vector<ll> a(n);
    for (int i = 0; i < n; i++) scanf("%lld", &a[i]);

    // Group fixed values: map count -> number of distinct values having that count.
    vector<ll> vals;
    for (ll x : a)
        if (x != -1) vals.push_back(x);
    sort(vals.begin(), vals.end());
    map<ll, ll> cntOfCount;
    ll present = 0;
    for (size_t i = 0; i < vals.size();) {
        size_t j = i;
        while (j < vals.size() && vals[j] == vals[i]) j++;
        cntOfCount[(ll)(j - i)]++;
        present++;
        i = j;
    }
    ll c = (ll)n - (ll)vals.size();              // number of -1 entries
    ll km = ((k - present) % MOD + MOD) % MOD;   // values absent from a (count 0 fixed)

    // Modular inverses 1..n
    vector<ll> inv(n + 2, 1);
    for (int i = 2; i <= n; i++)
        inv[i] = (MOD - (MOD / i) * inv[MOD % i] % MOD) % MOD;

    // h(c) for c = 0..n, from d(c) = ((k-1) c d(c-1) - k c) / (n - c), h(c) = h(c-1) + d(c-1)
    ll km1 = (k - 1) % MOD, kk = k % MOD;
    vector<ll> d(n + 1, 0), h(n + 1, 0);
    d[0] = 0;
    for (int x = 1; x <= n - 1; x++) {
        ll t1 = km1 * x % MOD * d[x - 1] % MOD;
        ll t2 = kk * x % MOD;
        ll num = ((t1 - t2) % MOD + MOD) % MOD;
        d[x] = num * inv[n - x] % MOD;
    }
    h[0] = 0;
    for (int x = 1; x <= n; x++) h[x] = (h[x - 1] + d[x - 1]) % MOD;

    // Binomial pmf for Bin(c, 1/k)
    vector<ll> fact(n + 1, 1), ifact(n + 1, 1);
    for (int i = 1; i <= n; i++) fact[i] = fact[i - 1] * i % MOD;
    ifact[n] = pw(fact[n], MOD - 2);
    for (int i = n; i >= 1; i--) ifact[i - 1] = ifact[i] * i % MOD;

    ll invk = pw(k, MOD - 2);
    ll p = invk;
    ll q = km1 * invk % MOD;
    vector<ll> pp(c + 1, 1), qp(c + 1, 1);
    for (ll i = 1; i <= c; i++) {
        pp[i] = pp[i - 1] * p % MOD;
        qp[i] = qp[i - 1] * q % MOD;
    }
    vector<ll> pmf(c + 1);
    for (ll j = 0; j <= c; j++) {
        ll comb = fact[c] * ifact[j] % MOD * ifact[c - j] % MOD;
        pmf[j] = comb * pp[j] % MOD * qp[c - j] % MOD;
    }

    // S(e) = E[h(e + X)], X ~ Bin(c, 1/k)
    auto S = [&](ll e) -> ll {
        ll s = 0;
        for (ll j = 0; j <= c; j++) s = (s + pmf[j] * h[e + j]) % MOD;
        return s;
    };

    ll ans = 0;
    for (auto &kv : cntOfCount) {
        ans = (ans + (kv.second % MOD) * S(kv.first)) % MOD;
    }
    if (km != 0) ans = (ans + km * S(0)) % MOD;
    ans = ((ans - h[n]) % MOD + MOD) % MOD;
    printf("%lld\n", ans);
    return 0;
}
