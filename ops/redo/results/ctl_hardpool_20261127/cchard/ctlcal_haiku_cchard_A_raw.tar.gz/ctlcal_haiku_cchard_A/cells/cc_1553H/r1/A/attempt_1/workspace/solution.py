import sys


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    k = int(data[1])
    N = 1 << k
    INF = 1 << 40  # sentinel for "no element in this block"

    # Level 0: block size 1. f = min diff inside block (INF if < 2 elements),
    # mn/mx = min/max of the (xored) value inside block, INF/-INF if empty.
    f = [INF] * N
    mn = [INF] * N
    mx = [-INF] * N
    for t in data[2:2 + n]:
        v = int(t)
        mn[v] = 0
        mx[v] = 0

    # Level b -> b+1: each block of size S = 2^b is combined with its buddy
    # (the block that differs in bit b). Result block of size 2S:
    #   x < S  (bit b of x is 0): buddy with bit b set lands in the upper half.
    #   x >= S (bit b of x is 1): the two halves swap roles.
    S = 1
    while S < N:
        h = S
        nf = []
        nmn = []
        nmx = []
        for base in range(0, N, 2 * S):
            fL = f[base:base + S]
            mnL = mn[base:base + S]
            mxL = mx[base:base + S]
            fR = f[base + S:base + 2 * S]
            mnR = mn[base + S:base + 2 * S]
            mxR = mx[base + S:base + 2 * S]

            hmnL = [h + c for c in mnL]
            hmxL = [h + c for c in mxL]
            hmnR = [h + c for c in mnR]
            hmxR = [h + c for c in mxR]

            fc = [a if a < b else b for a, b in zip(fL, fR)]

            # x < S
            c0 = [x - y for x, y in zip(hmnR, mxL)]
            t = [a if a < b else b for a, b in zip(fc, c0)]
            nf.extend(t)
            # min/max for x < S
            t = [a if a < b else b for a, b in zip(mnL, hmnR)]
            nmn.extend(t)
            t = [a if a > b else b for a, b in zip(mxL, hmxR)]
            nmx.extend(t)

            # x >= S
            c1 = [x - y for x, y in zip(hmnL, mxR)]
            t = [a if a < b else b for a, b in zip(fc, c1)]
            nf.extend(t)
            t = [a if a < b else b for a, b in zip(mnR, hmnL)]
            nmn.extend(t)
            t = [a if a > b else b for a, b in zip(mxR, hmxL)]
            nmx.extend(t)

        f = nf
        mn = nmn
        mx = nmx
        S *= 2

    sys.stdout.write(" ".join(map(str, f)) + "\n")


main()
