#include <bits/stdc++.h>
using namespace std;

static const uint32_t MOD = 998244353u;

int n;
vector<array<int, 26>> cnt;   // per-string letter counts
vector<uint32_t> h;           // signed inclusion-exclusion terms, then zeta-transformed to f(S)

// Enumerate all subsets T of {0..n-1}. cur[c] = min over chosen strings of their count of letter c.
void dfs(int i, uint32_t mask, int k, const int* cur) {
    if (i == n) {
        if (mask == 0) return;
        uint64_t g = 1;
        for (int c = 0; c < 26; c++) g = g * (uint64_t)(cur[c] + 1) % MOD;
        h[mask] = (k & 1) ? (uint32_t)g : (uint32_t)((MOD - g) % MOD);
        return;
    }
    dfs(i + 1, mask, k, cur);
    int nxt[26];
    for (int c = 0; c < 26; c++) nxt[c] = min(cur[c], cnt[i][c]);
    dfs(i + 1, mask | (1u << i), k + 1, nxt);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cin >> n;
    cnt.assign(n, array<int, 26>{});
    for (int i = 0; i < n; i++) {
        string s;
        cin >> s;
        for (char ch : s) cnt[i][ch - 'a']++;
    }

    size_t full = (size_t)1 << n;
    h.assign(full, 0);

    int init[26];
    for (int c = 0; c < 26; c++) init[c] = INT_MAX / 2;
    dfs(0, 0, 0, init);

    // Subset-sum (zeta) transform: h[S] becomes f(S) = sum over nonempty T subset of S of signed g(T).
    for (int b = 0; b < n; b++) {
        uint32_t bit = 1u << b;
        for (size_t m = 0; m < full; m++) {
            if (m & bit) {
                uint32_t v = h[m] + h[m ^ bit];
                if (v >= MOD) v -= MOD;
                h[m] = v;
            }
        }
    }

    // sumidx[S] = sum of (i+1) over i in S, computed via lowest-bit DP.
    vector<uint16_t> sumidx(full, 0);
    for (size_t m = 1; m < full; m++) {
        int low = __builtin_ctzll(m);
        sumidx[m] = sumidx[m & (m - 1)] + (uint16_t)(low + 1);
    }

    long long ans = 0;
    for (size_t m = 1; m < full; m++) {
        long long f = h[m];
        long long k = __builtin_popcountll(m);
        long long val = f * k * (long long)sumidx[m];
        ans ^= val;
    }
    cout << ans << "\n";
    return 0;
}
