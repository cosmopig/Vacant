import sys
from collections import deque

MOD = 998244353
sys.setrecursionlimit(10000)


def overlap(a, b):
    return bool(a & b) and not (a <= b) and not (b <= a)


def add_set(blocks, W, s):
    """Extend an ordered block sequence (covering W) with set s, which overlaps
    some set already added. Returns the new block list, or None if infeasible."""
    N = s - W
    idxs = [i for i, b in enumerate(blocks) if b & s]
    if not idxs:
        return None
    l, r = idxs[0], idxs[-1]
    if idxs != list(range(l, r + 1)):
        return None
    for i in range(l + 1, r):
        if not blocks[i] <= s:
            return None
    k = len(blocks)

    def parts_right(b):  # s-part placed on the right
        return [p for p in (b - s, b & s) if p]

    def parts_left(b):  # s-part placed on the left
        return [p for p in (b & s, b - s) if p]

    if N:
        # Try attaching N on the right: s-part must be a suffix.
        if r == k - 1 and (l == r or blocks[r] <= s):
            return blocks[:l] + parts_right(blocks[l]) + blocks[l + 1:] + [N]
        # Try attaching N on the left: s-part must be a prefix.
        if l == 0 and (l == r or blocks[l] <= s):
            return [N] + blocks[:r] + parts_left(blocks[r]) + blocks[r + 1:]
        return None
    else:
        if l == r:
            return None  # cannot happen for an overlapping set
        return (blocks[:l] + parts_right(blocks[l]) + blocks[l + 1:r]
                + parts_left(blocks[r]) + blocks[r + 1:])


def count(U, F, fact):
    u = len(U)
    F = {s for s in F if 2 <= len(s) < u}
    if not F:
        return fact[u]
    F = list(F)
    k = len(F)
    adj = [[j for j in range(k) if j != i and overlap(F[i], F[j])] for i in range(k)]
    seen = [False] * k
    comps = []
    for i in range(k):
        if seen[i]:
            continue
        order = []
        dq = deque([i])
        seen[i] = True
        while dq:
            x = dq.popleft()
            order.append(x)
            for y in adj[x]:
                if not seen[y]:
                    seen[y] = True
                    dq.append(y)
        comps.append(order)

    unions = []
    for comp in comps:
        M = set()
        for x in comp:
            M |= F[x]
        unions.append(frozenset(M))

    # Case A: an overlap component covers all of U -> Q-node.
    for comp, M in zip(comps, unions):
        if M == U:
            blocks = [F[comp[0]]]
            W = F[comp[0]]
            for x in comp[1:]:
                blocks = add_set(blocks, W, F[x])
                if blocks is None:
                    return 0
                W = W | F[x]
            res = 2
            for b in blocks:
                sub = [s for s in F if s <= b]
                res = res * count(b, sub, fact) % MOD
                if res == 0:
                    return 0
            return res

    # Case B: P-node over maximal component unions plus free elements.
    distinct = set(unions)
    maximal = [M for M in distinct if not any(M < O for O in distinct)]
    covered = set()
    res = 1
    for M in maximal:
        covered |= M
        sub = [s for s in F if s <= M]
        res = res * count(M, sub, fact) % MOD
        if res == 0:
            return 0
    singles = u - len(covered)
    return res * fact[len(maximal) + singles] % MOD


def main():
    data = sys.stdin.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    m = int(data[pos]); pos += 1
    F = []
    for _ in range(m):
        q = int(data[pos]); pos += 1
        s = frozenset(int(x) for x in data[pos:pos + q])
        pos += q
        F.append(s)
    fact = [1] * (n + 2)
    for i in range(1, n + 2):
        fact[i] = fact[i - 1] * i % MOD
    U = frozenset(range(1, n + 1))
    print(count(U, F, fact) % MOD)


if __name__ == "__main__":
    main()
