#include <bits/stdc++.h>
using namespace std;

// A string is good iff the partition of vertices into "same letter" classes
// admits a palindromic Hamiltonian path. Goodness depends only on that
// partition, so answer = sum over good partitions of k*(k-1)*...*(k-b+1),
// where b is the number of classes. Every class must have even size.

static int n, K;
static int adj[12];
static int sameMask[12];   // vertices in the same block as v
static int nblocks;

static int stampCur = 0;

// Current ladder: layers are added from the innermost edge outwards.
// State (mask, a, b): a and b are the outermost endpoints so far.
// seen[mask] is a 144-bit set of visited (a,b) pairs (bit a*12+b), stored as
// 3 words and lazily reset via a stamp, so no per-partition clearing is needed.
static unsigned long long seen[1 << 12][3];
static int seenStamp[1 << 12];

// Returns true if the ladder can be completed from state (mask, a, b).
static bool extend(int mask, int a, int b) {
    if (mask == (1 << n) - 1) return true;
    if (seenStamp[mask] != stampCur) {
        seenStamp[mask] = stampCur;
        seen[mask][0] = seen[mask][1] = seen[mask][2] = 0;
    }
    int idx = a * 12 + b;
    unsigned long long bit = 1ULL << (idx & 63);
    if (seen[mask][idx >> 6] & bit) return false;
    seen[mask][idx >> 6] |= bit;
    int ca = adj[a] & ~mask;
    while (ca) {
        int a2 = __builtin_ctz(ca);
        ca &= ca - 1;
        int cb = adj[b] & ~mask & sameMask[a2] & ~(1 << a2);
        while (cb) {
            int b2 = __builtin_ctz(cb);
            cb &= cb - 1;
            if (extend(mask | (1 << a2) | (1 << b2), a2, b2)) return true;
        }
    }
    return false;
}

static bool ladderExists() {
    stampCur++;
    for (int a = 0; a < n; a++) {
        int c = adj[a] & sameMask[a];
        while (c) {
            int b = __builtin_ctz(c);
            c &= c - 1;
            if (extend((1 << a) | (1 << b), a, b)) return true;
        }
    }
    return false;
}

static long long total = 0;

static void evaluate() {
    if (!ladderExists()) return;
    long long ways = 1;
    for (int i = 0; i < nblocks; i++) {
        if (K - i <= 0) { ways = 0; break; }
        ways *= (K - i);
    }
    total += ways;
}

static void rec(int remaining, int idx) {
    if (remaining == 0) {
        evaluate();
        return;
    }
    int v = __builtin_ctz(remaining);
    int rest = remaining & ~(1 << v);
    // Enumerate subsets s of rest such that |s| is odd (block = s + v is even).
    for (int s = rest; ; s = (s - 1) & rest) {
        if (__builtin_popcount(s) % 2 == 1) {
            int block = s | (1 << v);
            for (int u = 0; u < n; u++)
                if (block >> u & 1) sameMask[u] = block;
            nblocks = idx + 1;
            rec(remaining & ~block, idx + 1);
        }
        if (s == 0) break;
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long nn, mm, kk;
    if (!(cin >> nn >> mm >> kk)) return 0;
    n = (int)nn;
    K = (int)kk;
    for (int i = 0; i < n; i++) adj[i] = 0;
    for (long long i = 0; i < mm; i++) {
        long long v, u;
        if (!(cin >> v >> u)) break;
        if (v < 1 || v > n || u < 1 || u > n || v == u) continue;
        adj[v - 1] |= 1 << (u - 1);
        adj[u - 1] |= 1 << (v - 1);
    }

    rec((1 << n) - 1, 0);
    cout << total << "\n";
    return 0;
}
