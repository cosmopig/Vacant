import sys
from bisect import bisect_right

MOD = 10**9 + 7


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    a = [0] * n
    b = [0] * n
    idx = 1
    for k in range(n):
        a[k] = int(data[idx])
        b[k] = int(data[idx + 1])
        idx += 2
    t = int(data[idx])
    idx += 1
    S = [int(x) - 1 for x in data[idx:idx + t]]

    M = 2 * n + 2
    # Tasks in order of realisation time b.
    order = sorted(range(n), key=lambda k: b[k])

    # g[d] = number of time-travel pushes in the sub-process started by d:
    #   g[d] = 1 + sum of g[e] over e nested inside d (a_e > a_d, b_e < b_d).
    bit = [0] * (M + 1)  # indexed by r = M - a, so "a > A" is a prefix query

    def add(i, v):
        while i <= M:
            bit[i] = (bit[i] + v) % MOD
            i += i & -i

    def pref(i):
        s = 0
        while i > 0:
            s += bit[i]
            i -= i & -i
        return s % MOD

    g = [0] * n
    for d in order:
        q = pref(M - a[d] - 1)
        g[d] = (1 + q) % MOD
        add(M - a[d], g[d])

    # Chain of required tasks: m1 = max-b in S, m2 = max-b in S with a > a[m1], ...
    # Each step contributes (sum of g[e] over e with a_e > A, b_e < b_m) + 1,
    # where A is the a-value of the previous chain element (0 at the start).
    S_sorted = sorted(S, key=lambda k: a[k])
    sa = [a[k] for k in S_sorted]
    L = len(S_sorted)
    suf = [0] * (L + 1)  # suf[i] = index in S_sorted of max-b among positions >= i
    best = -1
    for i in range(L - 1, -1, -1):
        if best == -1 or b[S_sorted[i]] > b[S_sorted[best]]:
            best = i
        suf[i] = best

    queries = []  # (A, B)
    A = 0
    base = 0
    while True:
        i = bisect_right(sa, A)
        if i >= L:
            break
        m = S_sorted[suf[i]]
        queries.append((A, b[m]))
        base += 1
        A = a[m]

    # Offline: Q = sum of g[e] over e with a_e > A and b_e < B.
    queries.sort(key=lambda q: q[1])
    bit2 = [0] * (M + 1)
    total = base % MOD
    ptr = 0
    for A, B in queries:
        while ptr < n and b[order[ptr]] < B:
            e = order[ptr]
            i = M - a[e]
            v = g[e]
            while i <= M:
                bit2[i] = (bit2[i] + v) % MOD
                i += i & -i
            ptr += 1
        s = 0
        i = M - A - 1
        while i > 0:
            s += bit2[i]
            i -= i & -i
        total = (total + s) % MOD

    print(total % MOD)


main()
