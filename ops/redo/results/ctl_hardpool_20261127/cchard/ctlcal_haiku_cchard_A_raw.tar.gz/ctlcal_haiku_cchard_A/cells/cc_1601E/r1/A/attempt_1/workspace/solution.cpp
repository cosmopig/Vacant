#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

// Stack entry for one residue class. Entries are stored bottom (largest t) to top (smallest t).
// cntBelow / sumBelow: number of elements and total value strictly below this entry (bottom side).
struct Entry {
    ll val;
    ll cnt;
    ll cntBelow;
    ll sumBelow;
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, q, k;
    cin >> n >> q >> k;
    vector<ll> a(n + 2, 0);
    for (int i = 1; i <= n; i++) cin >> a[i];

    // Sparse table for range minimum.
    int LOG = 1;
    while ((1 << LOG) <= n) LOG++;
    vector<vector<ll>> sp(LOG, vector<ll>(n + 2, 0));
    for (int i = 1; i <= n; i++) sp[0][i] = a[i];
    for (int j = 1; j < LOG; j++)
        for (int i = 1; i + (1 << j) - 1 <= n; i++)
            sp[j][i] = min(sp[j - 1][i], sp[j - 1][i + (1 << (j - 1))]);
    vector<int> lg(n + 2, 0);
    for (int i = 2; i <= n + 1; i++) lg[i] = lg[i / 2] + 1;
    auto rmq = [&](int l, int r) -> ll {
        int j = lg[r - l + 1];
        return min(sp[j][l], sp[j][r - (1 << j) + 1]);
    };

    // Queries grouped by l.
    vector<vector<pair<int, int>>> byL(n + 2);  // (r, query index)
    for (int i = 0; i < q; i++) {
        int l, r;
        cin >> l >> r;
        byL[l].push_back({r, i});
    }

    vector<ll> ans(q, 0);
    vector<vector<Entry>> stacks(k);

    for (int l = n; l >= 1; l--) {
        vector<Entry>& st = stacks[l % k];
        if (l + k <= n) {
            ll m = rmq(l, l + k - 1);
            ll popped = 0;
            while (!st.empty() && st.back().val > m) {
                popped += st.back().cnt;
                st.pop_back();
            }
            if (popped > 0) {
                ll cb = 0, sb = 0;
                if (!st.empty()) {
                    cb = st.back().cntBelow + st.back().cnt;
                    sb = st.back().sumBelow + st.back().val * st.back().cnt;
                }
                st.push_back({m, popped, cb, sb});
            }
        }
        // Push the ticket bought at day l for the block starting at l.
        {
            ll cb = 0, sb = 0;
            if (!st.empty()) {
                cb = st.back().cntBelow + st.back().cnt;
                sb = st.back().sumBelow + st.back().val * st.back().cnt;
            }
            st.push_back({a[l], 1, cb, sb});
        }

        // Answer queries with this l. The stack now holds P(l, t) for every t = l, l+k, ... <= n.
        if (!byL[l].empty()) {
            ll N = st.back().cntBelow + st.back().cnt;
            ll totalSum = st.back().sumBelow + st.back().val * st.back().cnt;
            for (auto& [r, idx] : byL[l]) {
                ll K = (r - l) / k + 1;  // number of blocks with start <= r
                ll P = N - K;           // bottom-based positions < P are not counted
                // Largest stack index e with cntBelow <= P.
                int lo = 0, hi = (int)st.size() - 1;
                while (lo < hi) {
                    int mid = (lo + hi + 1) / 2;
                    if (st[mid].cntBelow <= P) lo = mid;
                    else hi = mid - 1;
                }
                const Entry& e = st[lo];
                ll below = e.sumBelow + e.val * (P - e.cntBelow);
                ans[idx] = totalSum - below;
            }
        }
    }

    string out;
    out.reserve(q * 12);
    for (int i = 0; i < q; i++) {
        out += to_string(ans[i]);
        out += '\n';
    }
    cout << out;
    return 0;
}
