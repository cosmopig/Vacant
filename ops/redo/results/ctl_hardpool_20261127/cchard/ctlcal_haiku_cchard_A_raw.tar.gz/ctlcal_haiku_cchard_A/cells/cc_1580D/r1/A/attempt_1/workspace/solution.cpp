#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

// Value = (m-1) * sum(a_chosen) - 2 * sum_{i<j} min(a[b_i..b_j]).
// We minimise cost = 2 * sum_{i<j} min - (m-1) * sum(a_chosen) over subsets of size m.
// Build the Cartesian tree (min at root). For a node k with interval [l,r] and minimum a_k,
// every pair of chosen indices whose span lies in [l,r] and crosses or touches k has min a_k.
// dp[v][c] = min cost using c chosen indices inside the subtree of v (capped at m).

static int n, m;
static vector<ll> a;
static vector<int> lc, rc;
static const ll INF = LLONG_MAX / 4;

vector<ll> dfs(int v) {
    if (v < 0) return vector<ll>(1, 0);
    vector<ll> L = dfs(lc[v]);
    vector<ll> R = dfs(rc[v]);
    int sL = (int)L.size() - 1, sR = (int)R.size() - 1;
    int sz = min(sL + sR + 1, m);
    vector<ll> res(sz + 1, INF);
    ll av = a[v];
    for (int cl = 0; cl <= sL; cl++) {
        if (L[cl] >= INF) continue;
        for (int cr = 0; cr <= sR; cr++) {
            if (R[cr] >= INF) continue;
            ll base = L[cl] + R[cr];
            ll cross = (ll)cl * cr;
            for (int ek = 0; ek <= 1; ek++) {
                int c = cl + cr + ek;
                if (c > m) continue;
                ll val = base + 2 * av * (cross + (ll)ek * (cl + cr)) - (ll)(m - 1) * av * ek;
                if (val < res[c]) res[c] = val;
            }
        }
    }
    return res;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    if (!(cin >> n >> m)) return 0;
    a.assign(n, 0);
    for (int i = 0; i < n; i++) cin >> a[i];
    if (m <= 0) {
        cout << 0 << "\n";
        return 0;
    }
    // Cartesian tree via monotonic stack (min-heap).
    lc.assign(n, -1);
    rc.assign(n, -1);
    vector<int> st;
    for (int i = 0; i < n; i++) {
        int last = -1;
        while (!st.empty() && a[st.back()] > a[i]) {
            last = st.back();
            st.pop_back();
        }
        lc[i] = last;
        if (!st.empty()) rc[st.back()] = i;
        st.push_back(i);
    }
    int root = st.front();
    vector<ll> res = dfs(root);
    ll best = -res[m];
    cout << best << "\n";
    return 0;
}
