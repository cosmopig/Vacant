import sys
from itertools import combinations


def boxes_ok(groups):
    # groups: three lists of (x, y) points, one per color (all chosen)
    boxes = []
    for g in groups:
        xs = [p[0] for p in g]
        ys = [p[1] for p in g]
        boxes.append((min(xs), max(xs), min(ys), max(ys)))
    # bounding boxes must have zero-area pairwise intersection
    for i in range(3):
        for j in range(i + 1, 3):
            ax1, ax2, ay1, ay2 = boxes[i]
            bx1, bx2, by1, by2 = boxes[j]
            w = min(ax2, bx2) - max(ax1, bx1)
            h = min(ay2, by2) - max(ay1, by1)
            if w > 0 and h > 0:
                return False
    # no chosen cell of another color may lie in a box (closed boxes)
    for i in range(3):
        x1, x2, y1, y2 = boxes[i]
        for j in range(3):
            if j == i:
                continue
            for (px, py) in groups[j]:
                if x1 <= px <= x2 and y1 <= py <= y2:
                    return False
    return True


def main():
    data = sys.stdin.read().split()
    n = int(data[0])
    cols = ([], [], [])
    idx = 1
    for _ in range(n):
        x = int(data[idx])
        y = int(data[idx + 1])
        c = int(data[idx + 2])
        idx += 3
        cols[c - 1].append((x, y))
    m_total = n // 3
    # Feasibility is monotone in m (dropping one cell per color keeps validity),
    # but we simply scan downward and stop at the first feasible m.
    for m in range(m_total, 0, -1):
        for A in combinations(cols[0], m):
            for B in combinations(cols[1], m):
                for C in combinations(cols[2], m):
                    if boxes_ok([A, B, C]):
                        print(3 * m)
                        return
    print(0)


if __name__ == "__main__":
    main()
