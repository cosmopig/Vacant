#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

static const int MAXN = 100000;
static ll Phi[MAXN + 2];

// E(l,r) = sum_{g=l}^{r} Phi(floor(r/g)); extra cost of block [l,r] beyond its length.
static inline ll E(int l, int r) {
    if (r < 2 * l) return 0;
    ll res = 0;
    int g = l;
    while (g <= r) {
        int q = r / g;
        if (q <= 1) break;
        int g2 = r / q;
        if (g2 > r) g2 = r;
        res += Phi[q] * (ll)(g2 - g + 1);
        g = g2 + 1;
    }
    return res;
}

static const ll INF = LLONG_MAX / 4;

// dp_j(x) = min_{l in [j,x]} dp_{j-1}(l-1) + E(l,x)
static void solveLayer(int j, int N, const vector<ll>& prev, vector<ll>& cur) {
    cur.assign(N + 1, INF);
    // iterative stack of (lo, hi, optl, optr)
    struct Frame { int lo, hi, ol, orr; };
    vector<Frame> st;
    st.push_back({j, N, j, N});
    while (!st.empty()) {
        Frame f = st.back();
        st.pop_back();
        if (f.lo > f.hi) continue;
        int mid = (f.lo + f.hi) / 2;
        ll best = INF;
        int bestL = -1;
        int from = max(f.ol, j);
        int to = min(f.orr, mid);
        for (int l = from; l <= to; l++) {
            ll pv = prev[l - 1];
            if (pv >= INF) continue;
            ll v = pv + E(l, mid);
            if (v < best) { best = v; bestL = l; }
        }
        cur[mid] = best;
        if (bestL < 0) bestL = max(f.ol, j);
        st.push_back({f.lo, mid - 1, f.ol, bestL});
        st.push_back({mid + 1, f.hi, bestL, f.orr});
    }
}

int main() {
    // phi sieve
    vector<int> phi(MAXN + 1);
    for (int i = 0; i <= MAXN; i++) phi[i] = i;
    for (int i = 2; i <= MAXN; i++)
        if (phi[i] == i)
            for (int j = i; j <= MAXN; j += i) phi[j] -= phi[j] / i;
    Phi[0] = 0;
    Phi[1] = 0;
    for (int m = 2; m <= MAXN; m++) Phi[m] = Phi[m - 1] + phi[m];

    int t;
    if (scanf("%d", &t) != 1) return 0;
    vector<int> qn(t), qk(t);
    int N = 1;
    for (int i = 0; i < t; i++) {
        scanf("%d %d", &qn[i], &qk[i]);
        N = max(N, qn[i]);
    }

    // Layers: layer[j][x] = dp_j(x), computed only up to needed depth.
    int maxK = 0;
    for (int i = 0; i < t; i++) {
        int n = qn[i], k = qk[i];
        int z = 0;
        while ((1LL << z) <= n) z++;  // floor(log2 n)+1 zero-cost blocks suffice
        if (k < z) maxK = max(maxK, k);
    }
    vector<vector<ll>> layer(maxK + 1);
    if (maxK >= 1) {
        layer[1].assign(N + 1, INF);
        for (int x = 1; x <= N; x++) layer[1][x] = E(1, x);
        for (int j = 2; j <= maxK; j++) solveLayer(j, N, layer[j - 1], layer[j]);
    }

    string out;
    for (int i = 0; i < t; i++) {
        int n = qn[i], k = qk[i];
        int z = 0;
        while ((1LL << z) <= n) z++;
        ll ans;
        if (k >= z) ans = n;
        else ans = (ll)n + layer[k][n];
        out += to_string(ans);
        out += '\n';
    }
    fputs(out.c_str(), stdout);
    return 0;
}
