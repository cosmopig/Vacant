import sys
from collections import deque


def main():
    data = sys.stdin.read().split()
    if len(data) < 2:
        return
    n, m = int(data[0]), int(data[1])
    rows = data[2:2 + n]
    # Pad / truncate rows defensively; any character other than '.' is a marked cell.
    rows = [(r + "." * m)[:m] for r in rows] + ["." * m] * (n - len(rows))
    marked = [[rows[i][j] != "." for j in range(m)] for i in range(n)]

    # Unmarked neighbours of each marked cell, in order up, right, down, left.
    dirs = ((-1, 0), (0, 1), (1, 0), (0, -1))
    adj = {}
    for i in range(n):
        for j in range(m):
            if not marked[i][j]:
                continue
            nb = []
            for di, dj in dirs:
                a, b = i + di, j + dj
                if 0 <= a < n and 0 <= b < m and not marked[a][b]:
                    nb.append((a, b))
            # A marked cell needs an even number of unmarked neighbours, otherwise
            # no sum of 1s and 4s can be a multiple of 5.
            if len(nb) % 2:
                sys.stdout.write("NO\n")
                return
            # Pair consecutive neighbours; each pair must hold one 1 and one 4.
            for k in range(0, len(nb), 2):
                p, q = nb[k], nb[k + 1]
                adj.setdefault(p, []).append(q)
                adj.setdefault(q, []).append(p)

    # 2-colour the pairing graph: colour 0 -> value 1, colour 1 -> value 4.
    val = [[1] * m for _ in range(n)]
    color = {}
    for start in adj:
        if start in color:
            continue
        color[start] = 0
        dq = deque([start])
        while dq:
            u = dq.popleft()
            for v in adj[u]:
                if v not in color:
                    color[v] = 1 - color[u]
                    dq.append(v)
                elif color[v] == color[u]:
                    sys.stdout.write("NO\n")
                    return
    for (a, b), c in color.items():
        val[a][b] = 1 if c == 0 else 4

    # Marked cells hold the sum of their unmarked neighbours.
    for i in range(n):
        for j in range(m):
            if marked[i][j]:
                s = 0
                for di, dj in dirs:
                    a, b = i + di, j + dj
                    if 0 <= a < n and 0 <= b < m and not marked[a][b]:
                        s += val[a][b]
                val[i][j] = s

    out = ["YES"]
    for i in range(n):
        out.append(" ".join(str(val[i][j]) for j in range(m)))
    sys.stdout.write("\n".join(out) + "\n")


main()
