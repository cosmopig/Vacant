import sys


def main():
    data = sys.stdin.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    k = int(data[pos]); pos += 1
    steps = []
    for _ in range(k):
        q = int(data[pos]); pos += 1
        mask = 0
        for _j in range(q):
            idx = int(data[pos]) - 1
            pos += 1
            mask |= 1 << idx
        steps.append(mask)

    full = (1 << n) - 1

    # 0/1 principle: it suffices to check every 0/1 input.
    # Positions not yet touched by a step keep their original (free) bit.
    # A step on subsequence S with F free positions and fo fixed ones: the F
    # free bits are consumed by this step and contribute any m in [0, F] ones
    # (independently of other choices), so the count c = fo + m is branched on.
    # The sorted subsequence then has ones on the last c positions of S.
    # touched[i] = mask of positions touched before step i.
    touched = [0] * (k + 1)
    for i, S in enumerate(steps):
        touched[i + 1] = touched[i] | S

    # Precompute, for each step, suffix masks of the subsequence.
    suffixes = []
    for S in steps:
        positions = [p for p in range(n) if (S >> p) & 1]
        q = len(positions)
        suf = [0] * (q + 1)
        for c in range(1, q + 1):
            suf[c] = suf[c - 1] | (1 << positions[q - c])
        suffixes.append(suf)

    # future[s] = mask of positions touched by steps s..k-1
    future = [0] * (k + 1)
    for i in range(k - 1, -1, -1):
        future[i] = future[i + 1] | steps[i]

    never = full & ~touched[k]  # positions no step touches: free bits forever

    def violated(v, sel):
        # Positions in sel have final values fixed by v, or are free (never touched).
        # Violation iff some i<j in sel with i can be 1 and j can be 0.
        can1 = (v | never) & sel
        can0 = (~v | never) & sel
        if can1 == 0:
            return False
        i = (can1 & -can1).bit_length() - 1
        return (can0 >> (i + 1)) != 0

    visited = set()

    def popcount(x):
        return x.bit_count()

    # Branch order for m in [0, F]: extremes first (finds counterexamples sooner).
    orders = []
    for F in range(n + 1):
        order = []
        lo, hi = 0, F
        while lo <= hi:
            order.append(lo)
            if hi != lo:
                order.append(hi)
            lo += 1
            hi -= 1
        orders.append(order)

    def dfs(step, v):
        # Returns True if some 0/1 input ends unsorted from this state.
        # Positions not touched by any remaining step are frozen: their values
        # never change again. A violation among frozen positions is permanent.
        frozen = full & ~future[step]
        if violated(v, frozen):
            return True
        if step == k:
            return False
        # Future evolution depends only on v restricted to future[step] and on
        # the frozen part only through f = min index that can be 1 and
        # g = max index that can be 0 (cross violations).
        can1f = (v | never) & frozen
        can0f = (~v | never) & frozen
        f = (can1f & -can1f).bit_length() - 1 if can1f else n
        g = can0f.bit_length() - 1 if can0f else -1
        key = (step, v & future[step], f, g)
        if key in visited:
            return False
        visited.add(key)
        S = steps[step]
        F = popcount(S & ~touched[step] & full)
        base = v & ~S & full
        suf = suffixes[step]
        fo = popcount(v & S)
        for m in orders[F]:
            if dfs(step + 1, base | suf[fo + m]):
                return True
        return False

    if dfs(0, 0):
        print("REJECTED")
    else:
        print("ACCEPTED")


main()
