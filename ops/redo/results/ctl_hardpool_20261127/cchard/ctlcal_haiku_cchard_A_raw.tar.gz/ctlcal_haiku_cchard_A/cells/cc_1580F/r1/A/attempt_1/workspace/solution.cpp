// Count cyclic sequences a_1..a_n, a_i >= 0, with a_i + a_{i+1} < m (cyclically).
// This equals tr(A^n) where A is the m x m matrix A[x][y] = [x + y <= m-1].
//
// Let D_m(z) = det(I - z A_m) and E_m = u^T adj(I - z A_m) u (u = all-ones).
// Peeling two vertices off the threshold structure gives
//   D_{m+2} = (1 - z - z^2) D_m - z^2 E_m
//   E_{m+2} = (2 + z) D_m + (1 + z) E_m
// with D_0 = 1, E_0 = 0 (even m) and D_1 = 1 - z, E_1 = 1 (odd m).
// Then sum_{k>=1} tr(A^k) z^k = -z D'(z) / D(z), so the answer is [z^n] of that.
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

const ll MOD = 998244353;

ll pw(ll b, ll e) {
    b %= MOD;
    if (b < 0) b += MOD;
    ll r = 1;
    while (e) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

// In-place iterative NTT (size must be a power of two).
void ntt(vector<ll>& a, bool invert) {
    int n = a.size();
    for (int i = 1, j = 0; i < n; i++) {
        int bit = n >> 1;
        for (; j & bit; bit >>= 1) j ^= bit;
        j ^= bit;
        if (i < j) swap(a[i], a[j]);
    }
    for (int len = 2; len <= n; len <<= 1) {
        ll w = pw(3, (MOD - 1) / len);
        if (invert) w = pw(w, MOD - 2);
        int half = len >> 1;
        vector<ll> roots(half);
        roots[0] = 1;
        for (int j = 1; j < half; j++) roots[j] = roots[j - 1] * w % MOD;
        for (int i = 0; i < n; i += len) {
            for (int j = 0; j < half; j++) {
                ll u = a[i + j];
                ll v = a[i + j + half] * roots[j] % MOD;
                a[i + j] = (u + v) % MOD;
                a[i + j + half] = (u - v + MOD) % MOD;
            }
        }
    }
    if (invert) {
        ll ni = pw(n, MOD - 2);
        for (auto& x : a) x = x * ni % MOD;
    }
}

// Product of two polynomials, truncated to degree < L.
vector<ll> mul(const vector<ll>& a, const vector<ll>& b, int L) {
    if (a.empty() || b.empty()) return {};
    int need = a.size() + b.size() - 1;
    int sz = 1;
    while (sz < need) sz <<= 1;
    vector<ll> fa(sz, 0), fb(sz, 0);
    copy(a.begin(), a.end(), fa.begin());
    copy(b.begin(), b.end(), fb.begin());
    ntt(fa, false);
    ntt(fb, false);
    for (int i = 0; i < sz; i++) fa[i] = fa[i] * fb[i] % MOD;
    ntt(fa, true);
    fa.resize(min(need, L));
    return fa;
}

// Power series inverse mod x^L (f[0] must be nonzero).
vector<ll> inverse(const vector<ll>& f, int L) {
    vector<ll> g = {pw(f[0], MOD - 2)};
    int len = 1;
    while (len < L) {
        len <<= 1;
        vector<ll> ft(f.begin(), f.begin() + min((int)f.size(), len));
        vector<ll> t = mul(ft, g, len);
        for (auto& x : t) x = (MOD - x) % MOD;
        if (t.empty()) t.push_back(0);
        t[0] = (t[0] + 2) % MOD;
        g = mul(g, t, len);
    }
    g.resize(L, 0);
    return g;
}

// 2x2 matrix of polynomials, row-major: m[0]=(0,0), m[1]=(0,1), m[2]=(1,0), m[3]=(1,1).
typedef array<vector<ll>, 4> Mat;

// Matrix product C = A * B mod x^L. Each input is transformed once (8 forward NTTs),
// and each output entry needs one inverse NTT (4 inverse NTTs).
Mat matmul(const Mat& A, const Mat& B, int L) {
    int need = 0;
    for (int i = 0; i < 4; i++) {
        need = max(need, (int)A[i].size() + (int)B[i].size() - 1);
    }
    int sz = 1;
    while (sz < need) sz <<= 1;
    array<vector<ll>, 4> FA, FB;
    for (int i = 0; i < 4; i++) {
        FA[i].assign(sz, 0);
        FB[i].assign(sz, 0);
        copy(A[i].begin(), A[i].end(), FA[i].begin());
        copy(B[i].begin(), B[i].end(), FB[i].begin());
        ntt(FA[i], false);
        ntt(FB[i], false);
    }
    Mat C;
    int outLen = min(need, L);
    // C[i][j] = A[i][0]*B[0][j] + A[i][1]*B[1][j]
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
            vector<ll> acc(sz);
            for (int k = 0; k < sz; k++) {
                acc[k] = (FA[2 * i][k] * FB[j][k] + FA[2 * i + 1][k] * FB[2 + j][k]) % MOD;
            }
            ntt(acc, true);
            acc.resize(outLen);
            C[2 * i + j] = acc;
        }
    }
    return C;
}

// v' = M * v (M, v polynomial entries), truncated to L.
pair<vector<ll>, vector<ll>> applyMat(const Mat& M, const vector<ll>& v0, const vector<ll>& v1, int L) {
    auto addp = [&](vector<ll> a, const vector<ll>& b) {
        if (a.size() < b.size()) a.resize(b.size(), 0);
        for (size_t i = 0; i < b.size(); i++) a[i] = (a[i] + b[i]) % MOD;
        if ((int)a.size() > L) a.resize(L);
        return a;
    };
    vector<ll> r0 = addp(mul(M[0], v0, L), mul(M[1], v1, L));
    vector<ll> r1 = addp(mul(M[2], v0, L), mul(M[3], v1, L));
    return {r0, r1};
}

int main() {
    ll n, m;
    cin >> n >> m;
    int L = max<ll>(n + 1, 3);  // keep coefficients up to z^n (at least degree 2 for the step matrix)

    // Start state and number of 2-step transitions.
    vector<ll> D, E;
    ll steps;
    if (m % 2 == 0) {
        D = {1};
        E = {0};
        steps = m / 2;
    } else {
        D = {1, MOD - 1};  // 1 - z
        E = {1};
        steps = (m - 1) / 2;
    }

    // One 2-step transition: D' = c*D - z^2*E,  E' = (2+z)*D + (1+z)*E,  c = 1 - z - z^2.
    Mat T;
    T[0] = {1, MOD - 1, MOD - 1};  // c
    T[1] = {0, 0, MOD - 1};        // -z^2
    T[2] = {2, 1};                 // 2 + z
    T[3] = {1, 1};                 // 1 + z

    // Apply T^steps to (D, E) by binary exponentiation (powers of T commute).
    while (steps > 0) {
        if (steps & 1) {
            auto r = applyMat(T, D, E, L);
            D = r.first;
            E = r.second;
        }
        steps >>= 1;
        if (steps > 0) T = matmul(T, T, L);
    }

    D.resize(L, 0);
    // A(z) = -z * D'(z): coefficient of z^k is -k * d_k.
    vector<ll> A(L, 0);
    for (int k = 1; k < L; k++) {
        A[k] = (MOD - (ll)k % MOD * D[k] % MOD) % MOD;
    }
    vector<ll> invD = inverse(D, L);
    // Answer = [z^n] A(z) / D(z).
    ll ans = 0;
    for (int i = 1; i <= n; i++) {
        ans = (ans + A[i] * invD[n - i]) % MOD;
    }
    cout << ans << "\n";
    return 0;
}
