#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
static const ll MOD = 1000000007LL;

// Returns (F(n), F(n+1)) mod MOD using fast doubling.
static pair<ll, ll> fibPair(ll n) {
    if (n == 0) return {0, 1};
    auto [a, b] = fibPair(n >> 1);
    ll c = a * ((2 * b - a + MOD) % MOD) % MOD;  // F(2k)
    ll d = (a * a + b * b) % MOD;                // F(2k+1)
    if (n & 1) return {d, (c + d) % MOD};
    return {c, d};
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, q;
    cin >> n >> q;
    vector<ll> a[2];
    a[0].resize(n);
    a[1].resize(n);
    for (int i = 0; i < n; i++) cin >> a[0][i];
    for (int i = 0; i < n; i++) cin >> a[1][i];

    string out;
    while (q--) {
        int t;
        cin >> t;
        if (t == 4) {
            int l, r;
            cin >> l >> r;
            ll sum = 0;
            for (int i = l - 1; i < r; i++) {
                sum += fibPair(a[0][i] + a[1][i]).first;
                if (sum >= MOD) sum -= MOD;
            }
            out += to_string(sum);
            out += '\n';
        } else {
            int k, l, r;
            ll x;
            cin >> k >> l >> r >> x;
            vector<ll>& arr = a[k - 1];
            for (int i = l - 1; i < r; i++) {
                if (t == 1) arr[i] = min(arr[i], x);
                else if (t == 2) arr[i] = max(arr[i], x);
                else arr[i] += x;
            }
        }
    }
    cout << out;
    return 0;
}
