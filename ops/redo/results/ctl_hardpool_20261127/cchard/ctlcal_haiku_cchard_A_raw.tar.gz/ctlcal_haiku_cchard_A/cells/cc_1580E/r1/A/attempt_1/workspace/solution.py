import sys
import heapq


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0

    def nxt():
        nonlocal pos
        v = int(data[pos])
        pos += 1
        return v

    n = nxt()
    m = nxt()
    q = nxt()
    w = [0] * (n + 1)
    for i in range(1, n + 1):
        w[i] = nxt()
    adj = [[] for _ in range(n + 1)]
    edges = []
    for _ in range(m):
        u = nxt()
        v = nxt()
        d = nxt()
        adj[u].append((v, d))
        adj[v].append((u, d))
        edges.append((u, v, d))

    # Shortest distances from station 1.
    INF = float("inf")
    dist = [INF] * (n + 1)
    dist[1] = 0
    heap = [(0, 1)]
    while heap:
        du, u = heapq.heappop(heap)
        if du != dist[u]:
            continue
        for v, d in adj[u]:
            nd = du + d
            if nd < dist[v]:
                dist[v] = nd
                heapq.heappush(heap, (nd, v))

    # Shortest-path DAG parents. nonroot[v] = set of non-1 parents, root[v] = 1 is a parent.
    nonroot = [[] for _ in range(n + 1)]
    root = [False] * (n + 1)
    for u, v, d in edges:
        if dist[u] + d == dist[v]:
            if u == 1:
                root[v] = True
            else:
                nonroot[v].append(u)
        if dist[v] + d == dist[u]:
            if v == 1:
                root[u] = True
            else:
                nonroot[u].append(v)

    # Classify every vertex v != 1.
    #   cost 0           : already has two disjoint shortest paths
    #   type A (kind=0) : only parent is 1; need one more edge from any u with dist[u] < dist[v]
    #   type B (kind=1) : one non-root parent p, no edge from 1; need an edge from u != p, dist[u] < dist[v]
    order = sorted(range(1, n + 1), key=lambda x: dist[x])  # 1 comes first (dist 0)
    # Sorted position info: for each v, L = number of vertices with dist < dist[v].
    L_of = [0] * (n + 1)
    i = 0
    while i < n:
        j = i
        while j < n and dist[order[j]] == dist[order[i]]:
            j += 1
        for k in range(i, j):
            L_of[order[k]] = i
        i = j

    items = []  # (L, kind, p)
    for v in range(2, n + 1):
        cnt = len(set(nonroot[v]))
        if cnt >= 2:
            continue
        if cnt == 1:
            if root[v]:
                continue
            items.append((L_of[v], 1, nonroot[v][0]))
        else:
            items.append((L_of[v], 0, 0))

    def total(wt):
        # m1/a1/m2 over prefixes of the sorted order: minimum, its vertex, minimum excluding that vertex.
        pm1 = [0] * (n + 1)
        pa1 = [0] * (n + 1)
        pm2 = [0] * (n + 1)
        m1 = INF
        a1 = 0
        m2 = INF
        for idx in range(n):
            x = order[idx]
            val = wt[x]
            if val < m1:
                m2 = m1
                m1 = val
                a1 = x
            elif val < m2:
                m2 = val
            pm1[idx + 1] = m1
            pa1[idx + 1] = a1
            pm2[idx + 1] = m2
        s = 0
        for L, kind, p in items:
            if kind == 0 or pa1[L] != p:
                s += pm1[L]
            else:
                s += pm2[L]
        return s

    out = [total(w)]
    for _ in range(q):
        k = nxt()
        x = nxt()
        w[k] += x
        out.append(total(w))
    sys.stdout.write("\n".join(map(str, out)) + "\n")


main()
