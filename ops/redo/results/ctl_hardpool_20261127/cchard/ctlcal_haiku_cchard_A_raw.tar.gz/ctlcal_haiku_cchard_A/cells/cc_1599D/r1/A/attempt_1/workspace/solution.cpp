// Bubble Popping.
//
// Model: the popped bubbles form "convex layers" (onion peeling). Layer 0 is the
// convex hull of all bubbles, layer 1 the hull of the rest, and so on. Each layer
// is emptied completely, in counter-clockwise order, before the next layer starts.
// The start of layer 0 is the bubble with minimal cross(d, p) (the first hit).
// The start of layer l+1 is the tangent vertex of layer l+1 that the stick hits
// first when it rotates about the last bubble of layer l, starting from the edge
// direction it arrived on. Those starts depend only on the layers, so they form a
// forest over (layer, start) nodes, and binary lifting answers each query.
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

struct P {
    ll x, y;
};
static inline P sub(P a, P b) { return {a.x - b.x, a.y - b.y}; }
static inline ll cross(P a, P b) { return a.x * b.y - a.y * b.x; }

// Polar-angle order on [0, 2*pi): true iff angle(a) < angle(b).
static inline int halfOf(P a) { return (a.y < 0 || (a.y == 0 && a.x < 0)) ? 1 : 0; }
static inline bool angLess(P a, P b) {
    int ha = halfOf(a), hb = halfOf(b);
    if (ha != hb) return ha < hb;
    return cross(a, b) > 0;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N;
    cin >> N;
    vector<P> pt(N);
    for (int i = 0; i < N; i++) cin >> pt[i].x >> pt[i].y;

    // Onion peeling.
    vector<int> order(N);
    iota(order.begin(), order.end(), 0);
    sort(order.begin(), order.end(), [&](int a, int b) {
        if (pt[a].x != pt[b].x) return pt[a].x < pt[b].x;
        return pt[a].y < pt[b].y;
    });
    vector<vector<int>> H;  // each layer's hull, counter-clockwise
    vector<int> rem = order;
    vector<char> inHull(N, 0);
    while (!rem.empty()) {
        int n = rem.size();
        vector<int> h;
        if (n <= 2) {
            h = rem;
        } else {
            vector<int> buf(2 * n);
            int k = 0;
            for (int i = 0; i < n; i++) {
                while (k >= 2 && cross(sub(pt[buf[k - 1]], pt[buf[k - 2]]), sub(pt[rem[i]], pt[buf[k - 2]])) <= 0) k--;
                buf[k++] = rem[i];
            }
            for (int i = n - 2, t = k + 1; i >= 0; i--) {
                while (k >= t && cross(sub(pt[buf[k - 1]], pt[buf[k - 2]]), sub(pt[rem[i]], pt[buf[k - 2]])) <= 0) k--;
                buf[k++] = rem[i];
            }
            buf.resize(k - 1);
            h = buf;
        }
        for (int v : h) inHull[v] = 1;
        vector<int> nxt;
        nxt.reserve(n);
        for (int v : rem)
            if (!inHull[v]) nxt.push_back(v);
        H.push_back(h);
        rem.swap(nxt);
    }

    int L = H.size();
    vector<int> offset(L + 1, 0);
    for (int l = 0; l < L; l++) offset[l + 1] = offset[l] + (int)H[l].size();
    vector<ll> C(L);  // inclusive prefix counts of layer sizes
    for (int l = 0; l < L; l++) C[l] = offset[l + 1];

    const int LOG = 18;
    vector<vector<int>> up(LOG, vector<int>(N));
    for (int l = 0; l < L; l++) {
        int m = H[l].size();
        for (int s = 0; s < m; s++) {
            int node = offset[l] + s;
            up[0][node] = node;  // default: last layer maps to itself
        }
        if (l + 1 >= L || m == 1) continue;
        const vector<int>& Q = H[l + 1];
        int mn = Q.size();
        int t = 0;
        for (int s = 0; s < m; s++) {
            // Position s is the start of the layer; the last popped bubble is s-1.
            P p = pt[H[l][(s - 1 + m) % m]];
            // Walk to the tangent vertex: the one with the smallest angle about p.
            while (true) {
                bool moved = false;
                int nx = (t + 1) % mn;
                if (cross(sub(pt[Q[nx]], p), sub(pt[Q[t]], p)) > 0) {
                    t = nx;
                    moved = true;
                } else {
                    int pv = (t - 1 + mn) % mn;
                    if (cross(sub(pt[Q[pv]], p), sub(pt[Q[t]], p)) > 0) {
                        t = pv;
                        moved = true;
                    }
                }
                if (!moved) break;
            }
            up[0][offset[l] + s] = offset[l + 1] + t;
        }
    }
    for (int k = 1; k < LOG; k++)
        for (int v = 0; v < N; v++) up[k][v] = up[k - 1][up[k - 1][v]];

    // Layer 0 edge angles, sorted from the smallest angle.
    const vector<int>& H0 = H[0];
    int m0 = H0.size();
    vector<P> E0(m0);  // E0[j] = edge starting at vertex (r + j) % m0
    int r = 0;
    {
        vector<P> e(m0);
        for (int i = 0; i < m0; i++) e[i] = sub(pt[H0[(i + 1) % m0]], pt[H0[i]]);
        for (int i = 1; i < m0; i++)
            if (angLess(e[i], e[r])) r = i;
        for (int j = 0; j < m0; j++) E0[j] = e[(r + j) % m0];
    }

    // Start of layer 0 for direction d: vertex with minimal cross(d, p).
    auto startFor = [&](P d) -> int {
        if (m0 == 1) return 0;
        if (m0 == 2) {
            ll a = cross(d, pt[H0[0]]), b = cross(d, pt[H0[1]]);
            return a <= b ? 0 : 1;
        }
        // First edge (cyclically) with angle >= angle(d) starts the minimal vertex.
        int lo = 0, hi = m0;
        while (lo < hi) {
            int mid = (lo + hi) / 2;
            if (!angLess(E0[mid], d))
                hi = mid;
            else
                lo = mid + 1;
        }
        int j = (lo == m0) ? 0 : lo;
        return (r + j) % m0;
    };

    int Q;
    cin >> Q;
    string out;
    out.reserve(Q * 8);
    for (int qi = 0; qi < Q; qi++) {
        ll dx, dy, K;
        cin >> dx >> dy >> K;
        P d{dx, dy};
        int s1 = startFor(d);
        int node = offset[0] + s1;
        // Layer containing the K-th pop: smallest l with C[l] >= K.
        int l = lower_bound(C.begin(), C.end(), K) - C.begin();
        for (int k = 0; k < LOG; k++)
            if ((l >> k) & 1) node = up[k][node];
        int s = node - offset[l];
        int m = H[l].size();
        ll before = (l == 0) ? 0 : C[l - 1];
        ll t = K - before;  // 1-based position within layer l
        int idx = (int)((s + t - 1) % m);
        int ans = H[l][idx] + 1;
        out += to_string(ans);
        out += '\n';
    }
    fputs(out.c_str(), stdout);
    return 0;
}
