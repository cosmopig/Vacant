import sys
from bisect import bisect_left, bisect_right


def main():
    data = sys.stdin.read().split()
    n = int(data[0])
    A = [int(x) for x in data[1:1 + n]]
    S = data[1 + n]

    vals = sorted(A)

    # Union-find "skip" structures over sorted positions.
    # nxt[p] -> smallest alive position >= p (n means none).
    # pv[k]  -> shifted index k (k = position + 1) resolves to largest alive
    #           position <= k - 1 (0 means none).
    nxt = list(range(n + 1))
    pv = list(range(n + 1))

    def find_next(p):
        while nxt[p] != p:
            nxt[p] = nxt[nxt[p]]
            p = nxt[p]
        return p

    def find_prev(k):
        while pv[k] != k:
            pv[k] = pv[pv[k]]
            k = pv[k]
        return k

    def remove(p):
        nxt[p] = p + 1
        pv[p + 1] = p

    out = []
    D = 0
    for i in range(n):
        s = 1 if S[i] == 'L' else -1
        if i == 0:
            # First move: the median of the remaining weights.
            p = (n - 1) // 2
            w = vals[p]
            side = s
            remove(p)
        else:
            a = s * D
            if a > 0:
                # Correct side already heavier. If the next requirement flips
                # the side, take the largest weight below the margin and put it
                # on the other side (shrinks the margin toward the flip).
                # Otherwise add the smallest weight on the correct side.
                flips_next = i + 1 < n and S[i + 1] != S[i]
                q = bisect_left(vals, a) - 1
                r = find_prev(q + 1) - 1 if (q >= 0 and flips_next) else -1
                if r >= 0:
                    w = vals[r]
                    side = -s
                    remove(r)
                else:
                    p = find_next(0)
                    if p >= n:
                        print(-1)
                        return
                    w = vals[p]
                    side = s
                    remove(p)
            else:
                # Wrong side is heavier: need a weight strictly above the margin.
                q = bisect_right(vals, -a)
                p = find_next(q)
                if p >= n:
                    print(-1)
                    return
                w = vals[p]
                side = s
                remove(p)
        D += side * w
        out.append("%d %s" % (w, 'L' if side == 1 else 'R'))

    sys.stdout.write("\n".join(out) + "\n")


main()
