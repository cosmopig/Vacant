import sys


def is_cactus_forest(n, edges):
    """Return True if every connected component of the graph (n nodes, given edges) is a cactus.

    A connected graph is a cactus iff, in a DFS tree, every tree edge is covered by at most one
    back edge (the fundamental cycles are pairwise edge-disjoint).
    """
    adj = [[] for _ in range(n)]
    for idx, (u, v) in enumerate(edges):
        adj[u].append((v, idx))
        adj[v].append((u, idx))

    depth = [-1] * n
    parent = [-1] * n
    parent_edge = [-1] * n
    used = [False] * n  # used[x]: tree edge (x, parent[x]) already lies on a cycle
    it = [0] * n

    for root in range(n):
        if depth[root] != -1:
            continue
        depth[root] = 0
        stack = [root]
        while stack:
            u = stack[-1]
            if it[u] < len(adj[u]):
                w, eid = adj[u][it[u]]
                it[u] += 1
                if eid == parent_edge[u]:
                    continue
                if depth[w] == -1:
                    depth[w] = depth[u] + 1
                    parent[w] = u
                    parent_edge[w] = eid
                    stack.append(w)
                elif depth[w] < depth[u]:
                    # back edge from u up to ancestor w: walk the tree path and mark it
                    x = u
                    while x != w:
                        if used[x]:
                            return False
                        used[x] = True
                        x = parent[x]
            else:
                stack.pop()
    return True


def main():
    data = sys.stdin.buffer.read().split()
    if len(data) < 2:
        print(0)
        return
    n = int(data[0])
    m = int(data[1])
    vals = list(map(int, data[2:2 + 2 * m]))
    m = len(vals) // 2
    if m == 0:
        print(0)
        return
    # Labels are used as-is (some inputs contain label 0); size the node set to cover all labels.
    us = vals[0::2]
    vs = vals[1::2]
    n = max(n, max(max(us), max(vs)) + 1)

    def window_ok(l, r):  # edges l..r-1 (0-based, half-open)
        return is_cactus_forest(n, [(us[i], vs[i]) for i in range(l, r)])

    total = 0
    r = 0
    for l in range(m):
        if r < l:
            r = l
        while r < m and window_ok(l, r + 1):
            r += 1
        total += r - l  # windows [l, l..r-1] are deserts
    print(total)


main()
