// Stations: sqrt decomposition over cities.
//
// Model: e_i = last city covered by station i (it covers [i, e_i]).
//  - Initially e_i = i.
//  - Rebuilding c with range g: every i < c gets e_i = min(e_i, c-1) (stations to
//    the left that reached c are now blocked by c), and e_c = g.
//  - Query: b_j = #{i : i <= j <= e_i}. Let S(X) = sum_{j<=X} b_j. Then
//    S(X) = sum_{i<=X} min(e_i, X) - X(X-1)/2, and the answer is S(r) - S(l-1).
//
// Each block keeps its (value, index) pairs sorted by value, a lazy cap K
// (applied as min to all values), and prefix sums of the values. Full blocks
// are answered by binary search; the partial block is scanned.
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

static const int INF = INT_MAX;

int n, q, B, nb;
vector<vector<pair<int,int>>> P;   // (value, idx) sorted by value
vector<vector<int>> vals;          // sorted values
vector<vector<ll>> pre;            // prefix sums of vals
vector<int> K;                     // lazy cap per block

static inline void rebuildArrays(int b) {
    auto &p = P[b];
    auto &v = vals[b];
    auto &pr = pre[b];
    int sz = (int)p.size();
    v.resize(sz);
    pr.assign(sz + 1, 0);
    for (int i = 0; i < sz; i++) {
        v[i] = p[i].first;
        pr[i + 1] = pr[i] + v[i];
    }
}

// sum over block of min(value, Y), values taken as stored (cap already folded into Y)
static inline ll blockMinSum(int b, int Y) {
    const auto &v = vals[b];
    int sz = (int)v.size();
    int k = (int)(upper_bound(v.begin(), v.end(), Y) - v.begin());
    return pre[b][k] + (ll)Y * (sz - k);
}

// S(X) = sum_{j<=X} b_j
static ll S(int X) {
    if (X <= 0) return 0;
    int bX = (X - 1) / B;
    ll tot = 0;
    for (int b = 0; b < bX; b++) {
        int Y = min(K[b], X);
        tot += blockMinSum(b, Y);
    }
    for (const auto &pr : P[bX]) {
        if (pr.second <= X) {
            tot += min(min(pr.first, K[bX]), X);
        }
    }
    tot -= (ll)X * (X - 1) / 2;
    return tot;
}

static vector<pair<int,int>> bufA, bufB, merged;

static void rebuild(int c, int g) {
    // Blocks entirely before c's block: chmin with c-1.
    int bc = (c - 1) / B;
    for (int b = 0; b < bc; b++) K[b] = min(K[b], c - 1);

    // Block containing c: fold the lazy cap, then apply the point update.
    auto &p = P[bc];
    for (auto &pr : p) {
        if (K[bc] < pr.first) pr.first = K[bc];
    }
    K[bc] = INF;

    bufA.clear();
    bufB.clear();
    for (auto &pr : p) {
        if (pr.second < c) {
            pr.first = min(pr.first, c - 1);
            bufA.push_back(pr);
        } else if (pr.second > c) {
            bufB.push_back(pr);
        }
        // pr.second == c is dropped and reinserted below
    }
    pair<int,int> np(g, c);
    auto pos = lower_bound(bufB.begin(), bufB.end(), np);
    bufB.insert(pos, np);

    merged.clear();
    merged.reserve(p.size());
    merge(bufA.begin(), bufA.end(), bufB.begin(), bufB.end(), back_inserter(merged));
    p.swap(merged);
    rebuildArrays(bc);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cin >> n >> q;
#ifndef BSZ
#define BSZ 512
#endif
    B = BSZ;
    nb = (n + B - 1) / B;
    P.assign(nb, {});
    vals.assign(nb, {});
    pre.assign(nb, {});
    K.assign(nb, INF);
    for (int i = 1; i <= n; i++) {
        P[(i - 1) / B].push_back({i, i});
    }
    for (int b = 0; b < nb; b++) rebuildArrays(b);

    string out;
    out.reserve(1 << 20);
    for (int t = 0; t < q; t++) {
        int type, a, b2;
        cin >> type >> a >> b2;
        if (type == 1) {
            rebuild(a, b2);
        } else {
            ll ans = S(b2) - S(a - 1);
            out += to_string(ans);
            out += '\n';
        }
    }
    cout << out;
    return 0;
}
