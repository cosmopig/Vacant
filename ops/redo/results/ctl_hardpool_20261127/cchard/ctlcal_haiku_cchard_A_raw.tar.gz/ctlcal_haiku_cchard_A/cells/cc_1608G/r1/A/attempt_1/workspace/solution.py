import sys
from collections import deque


def build_suffix_array(s):
    n = len(s)
    rank = [ord(c) for c in s]
    mult = max(n, 256) + 2  # ranks are < mult, so the combined key is collision-free
    sa = list(range(n))
    k = 1
    while True:
        key = [rank[i] * mult + (rank[i + k] + 1 if i + k < n else 0) for i in range(n)]
        sa.sort(key=key.__getitem__)
        new_rank = [0] * n
        r = 0
        for idx in range(1, n):
            if key[sa[idx]] != key[sa[idx - 1]]:
                r += 1
            new_rank[sa[idx]] = r
        if n:
            new_rank[sa[0]] = 0
        rank = new_rank
        if r == n - 1:
            break
        k <<= 1
        if k >= n:
            break
    return sa


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); m = int(data[pos + 1]); q = int(data[pos + 2])
    pos += 3

    adj = [[] for _ in range(n + 1)]
    for _ in range(n - 1):
        u = int(data[pos]); v = int(data[pos + 1]); c = data[pos + 2].decode()
        pos += 3
        adj[u].append((v, c))
        adj[v].append((u, c))

    # Root the tree at 1 and record parent, depth, and the character on the parent edge.
    par = [0] * (n + 1)
    depth = [0] * (n + 1)
    pc = [''] * (n + 1)
    seen = [False] * (n + 1)
    seen[1] = True
    dq = deque([1])
    while dq:
        x = dq.popleft()
        for y, c in adj[x]:
            if not seen[y]:
                seen[y] = True
                par[y] = x
                depth[y] = depth[x] + 1
                pc[y] = c
                dq.append(y)

    strings = [data[pos + i].decode() for i in range(m)]
    pos += m

    # Concatenate with '#' separators (never part of a pattern, so matches cannot cross strings).
    text = '#'.join(strings)
    N = len(text)
    sid = [0] * N  # 1-based string index for each text position, 0 for separators
    p = 0
    for i, s in enumerate(strings, 1):
        for _ in range(len(s)):
            sid[p] = i
            p += 1
        p += 1  # separator

    sa = build_suffix_array(text)

    ans = [0] * q
    # events[x] holds (query index, sign, l, r); value is added to ans when BIT holds suffixes sa[0..x-1].
    events = [[] for _ in range(N + 1)]
    for qi in range(q):
        u = int(data[pos]); v = int(data[pos + 1]); l = int(data[pos + 2]); r = int(data[pos + 3])
        pos += 4
        a, b = u, v
        left = []
        right = []
        while depth[a] > depth[b]:
            left.append(pc[a]); a = par[a]
        while depth[b] > depth[a]:
            right.append(pc[b]); b = par[b]
        while a != b:
            left.append(pc[a]); a = par[a]
            right.append(pc[b]); b = par[b]
        right.reverse()
        P = ''.join(left) + ''.join(right)
        L = len(P)

        # Range [lo, hi) of suffixes in sa whose first L characters equal P.
        lo, hi = 0, N
        while lo < hi:
            mid = (lo + hi) // 2
            if text[sa[mid]:sa[mid] + L] < P:
                lo = mid + 1
            else:
                hi = mid
        start = lo
        hi, lo = N, start
        while lo < hi:
            mid = (lo + hi) // 2
            if text[sa[mid]:sa[mid] + L] <= P:
                lo = mid + 1
            else:
                hi = mid
        end = lo
        if start < end:
            events[end].append((qi, 1, l, r))
            events[start].append((qi, -1, l, r))

    # Fenwick tree over string indices 1..m.
    tree = [0] * (m + 1)

    def add(i):
        while i <= m:
            tree[i] += 1
            i += i & -i

    def prefix(i):
        s = 0
        while i > 0:
            s += tree[i]
            i -= i & -i
        return s

    for x in range(N + 1):
        for qi, sign, l, r in events[x]:
            ans[qi] += sign * (prefix(r) - prefix(l - 1))
        if x < N:
            if sid[sa[x]]:
                add(sid[sa[x]])

    sys.stdout.write('\n'.join(map(str, ans)) + ('\n' if ans else ''))


main()
