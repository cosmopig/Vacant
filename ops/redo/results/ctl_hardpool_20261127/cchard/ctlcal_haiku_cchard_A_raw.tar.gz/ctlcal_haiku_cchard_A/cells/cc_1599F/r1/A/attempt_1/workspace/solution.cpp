// Mars: for each query [L,R] with step D, answer Yes iff the distinct
// city values in [L,R] (taken mod P) form a single connected component when
// two cities are linked iff their difference is +-D (mod P).
//
// Reasoning: for D != 0 (P prime) multiply everything by u = D^{-1}; links
// become +-1 steps, so the distinct set must be one contiguous arc
// {c, c+1, ..., c+m-1} of Z_P. We test this with power sums of the distinct
// values (sums 1..3 maintained with Fenwick trees over "last occurrence"
// positions, processing queries offline sorted by R). The arc is determined
// by c from the first moment and checked against the 2nd and 3rd moments.
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll P = 1000000007LL;

ll pw(ll b, ll e) {
    b %= P;
    if (b < 0) b += P;
    ll r = 1;
    while (e) {
        if (e & 1) r = r * b % P;
        b = b * b % P;
        e >>= 1;
    }
    return r;
}

struct BIT {
    int n;
    vector<ll> t;
    BIT(int n) : n(n), t(n + 1, 0) {}
    void add(int i, ll v) {  // v in [0,P)
        for (; i <= n; i += i & -i) t[i] = (t[i] + v) % P;
    }
    ll sum(int i) const {
        ll s = 0;
        for (; i > 0; i -= i & -i) s += t[i];
        return s % P;
    }
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N, Q;
    cin >> N >> Q;
    vector<ll> a(N + 1);
    for (int i = 1; i <= N; i++) {
        ll x;
        cin >> x;
        a[i] = ((x % P) + P) % P;
    }
    vector<int> qL(Q), qR(Q);
    vector<ll> qD(Q);
    vector<vector<int>> byR(N + 1);
    for (int q = 0; q < Q; q++) {
        cin >> qL[q] >> qR[q] >> qD[q];
        if (qL[q] > qR[q]) swap(qL[q], qR[q]);
        byR[qR[q]].push_back(q);
    }

    vector<char> ans(Q, 0);  // 1 = Yes
    BIT c0(N), c1(N), c2(N), c3(N);
    unordered_map<ll, int> last;
    last.reserve(2 * N + 1);

    auto upd = [&](int pos, ll v, ll sign) {  // sign = +1 or -1
        ll s = sign > 0 ? 1 : P - 1;
        ll v1 = v % P;
        ll v2 = v1 * v1 % P;
        ll v3 = v2 * v1 % P;
        c0.add(pos, s);
        c1.add(pos, sign > 0 ? v1 : (P - v1) % P);
        c2.add(pos, sign > 0 ? v2 : (P - v2) % P);
        c3.add(pos, sign > 0 ? v3 : (P - v3) % P);
    };

    for (int i = 1; i <= N; i++) {
        ll v = a[i];
        auto it = last.find(v);
        if (it != last.end()) upd(it->second, v, -1);
        upd(i, v, +1);
        last[v] = i;

        for (int q : byR[i]) {
            int L = qL[q];
            ll D = qD[q] % P;
            ll m = (c0.sum(i) - c0.sum(L - 1) + P) % P;  // distinct count
            if (m == 1) {
                ans[q] = 1;
                continue;
            }
            if (D == 0) {
                ans[q] = 0;  // m >= 2 and road length 0 links nothing
                continue;
            }
            ll u = pw(D, P - 2);
            ll A1 = (c1.sum(i) - c1.sum(L - 1) + P) % P;
            ll A2 = (c2.sum(i) - c2.sum(L - 1) + P) % P;
            ll A3 = (c3.sum(i) - c3.sum(L - 1) + P) % P;
            ll u2 = u * u % P, u3 = u2 * u % P;
            ll T1 = u * A1 % P, T2 = u2 * A2 % P, T3 = u3 * A3 % P;

            // Exact integer power sums of j = 0..m-1 (m <= 2e5, no overflow).
            ll mi = m;
            ll S1i = mi * (mi - 1) / 2;
            ll S2i = (mi - 1) * mi * (2 * mi - 1) / 6;
            ll S1 = S1i % P, S2 = S2i % P;
            ll S3 = S1 * S1 % P;

            ll c = ((T1 - S1) % P + P) % P * pw(m, P - 2) % P;
            ll c2v = c * c % P, c3v = c2v * c % P;
            ll E2 = (m * c2v % P + 2 * c % P * S1 % P + S2) % P;
            ll E3 = (m * c3v % P + 3 * c2v % P * S1 % P + 3 * c % P * S2 % P + S3) % P;
            ans[q] = (E2 == T2 && E3 == T3) ? 1 : 0;
        }
    }

    string out;
    out.reserve(Q * 4);
    for (int q = 0; q < Q; q++) out += ans[q] ? "Yes\n" : "No\n";
    cout << out;
    return 0;
}
