#include <bits/stdc++.h>
using namespace std;

const long long MOD = 1000000007LL;

long long power(long long b, long long e) {
    long long r = 1;
    b %= MOD;
    while (e > 0) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    long long n;
    int q;
    cin >> n >> q;

    // Let m = 3n. The answer for x is A_x = sum_{t=1}^{n} C(3t, x), i.e. the
    // coefficient of z^x in S(z) = sum_{t=1}^{n} (1+z)^{3t}.
    // With w = (1+z)^3:  S(z) = w(w^n - 1)/(w - 1),  w - 1 = z(z^2 + 3z + 3).
    // So S(z) = g(z) / (z^2 + 3z + 3) where
    //   g(z) = ((1+z)^{m+3} - (1+z)^3) / z,   g_k = C(m+3, k+1) - C(3, k+1).
    // Power-series division gives h_k = (g_k - 3 h_{k-1} - h_{k-2}) / 3.
    long long m = 3 * n;
    long long N = m + 3;

    vector<long long> fact(N + 1), inv(N + 1);
    fact[0] = 1;
    for (long long i = 1; i <= N; i++) fact[i] = fact[i - 1] * i % MOD;
    inv[N] = power(fact[N], MOD - 2);
    for (long long i = N; i > 0; i--) inv[i - 1] = inv[i] * i % MOD;

    auto C = [&](long long a, long long b) -> long long {
        if (b < 0 || b > a) return 0;
        return fact[a] * inv[b] % MOD * inv[a - b] % MOD;
    };

    long long inv3 = power(3, MOD - 2);
    vector<long long> h(m + 1);
    long long h1 = 0, h2 = 0;  // h_{k-1}, h_{k-2}
    for (long long k = 0; k <= m; k++) {
        long long g = (C(N, k + 1) - C(3, k + 1) + MOD) % MOD;
        long long val = (g - 3 * h1 % MOD - h2 + 2 * MOD) % MOD;
        val = val * inv3 % MOD;
        h[k] = val;
        h2 = h1;
        h1 = val;
    }

    string out;
    out.reserve((size_t)q * 11);
    for (int i = 0; i < q; i++) {
        long long x;
        cin >> x;
        out += to_string(h[x]);
        out += '\n';
    }
    cout << out;
    return 0;
}
