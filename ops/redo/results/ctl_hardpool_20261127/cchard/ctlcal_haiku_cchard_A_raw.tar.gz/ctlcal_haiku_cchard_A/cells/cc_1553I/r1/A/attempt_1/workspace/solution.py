import sys

MOD = 998244353


def main():
    data = sys.stdin.read().split()
    n = int(data[0])
    a = [int(v) for v in data[1:1 + n]]

    # The stair array partitions positions into blocks: a block of length L
    # starts at the current position and every entry in it equals L.
    # The partition is forced, so it is found greedily from the left.
    types = []  # True = singleton block (L == 1), False = block with L >= 2
    i = 0
    while i < n:
        L = a[i]
        if i + L > n or any(a[j] != L for j in range(i, i + L)):
            print(0)
            return
        types.append(L == 1)
        i += L
    m = len(types)

    # Inclusion-exclusion over "bad" boundaries between consecutive blocks.
    # Grouping the m blocks into g contiguous chains gives g! * prod(w(chain))
    # arrangements, where w = 1 for a lone singleton block and 2 otherwise
    # (two directions). Answer = (-1)^m * sum_g (-1)^g g! C_g, where C_g is the
    # coefficient of x^g in F_m(x). F satisfies
    #   F_i = shift(c_i * F_{i-1} + 2 * P_{i-2}),
    # with c_i = 1 for a singleton block, 2 otherwise, P_k = F_0 + ... + F_k.
    F_prev = [1]          # F_0
    Ppp = []              # P_{-1}
    Pp = [1]              # P_0
    for i in range(1, m + 1):
        c = 1 if types[i - 1] else 2
        size = len(F_prev) + 1
        new = [0] * (size + 1)
        for k in range(len(F_prev)):
            new[k + 1] = (new[k + 1] + c * F_prev[k]) % MOD
        for k in range(len(Ppp)):
            new[k + 1] = (new[k + 1] + 2 * Ppp[k]) % MOD
        while len(new) > 1 and new[-1] == 0:
            new.pop()
        # P_i = P_{i-1} + F_i
        L = max(len(Pp), len(new))
        P_new = [0] * L
        for k in range(len(Pp)):
            P_new[k] = Pp[k]
        for k in range(len(new)):
            P_new[k] = (P_new[k] + new[k]) % MOD
        Ppp, Pp = Pp, P_new
        F_prev = new

    C = F_prev
    ans = 0
    fact = 1
    for g in range(len(C)):
        if g > 0:
            fact = fact * g % MOD
        term = fact * C[g] % MOD
        if g % 2 == 1:
            ans -= term
        else:
            ans += term
    if m % 2 == 1:
        ans = -ans
    print(ans % MOD)


if __name__ == "__main__":
    main()
