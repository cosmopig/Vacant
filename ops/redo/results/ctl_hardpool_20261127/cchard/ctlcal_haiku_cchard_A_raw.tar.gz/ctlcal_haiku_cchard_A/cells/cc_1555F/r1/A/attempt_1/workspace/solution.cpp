// Good Graph: each simple cycle must have XOR 1.
//
// Characterisation used:
//  - Two cycles sharing a path (theta graph) are impossible, so every
//    biconnected block is a bridge or a cycle of XOR 1 (a cactus).
//  - Adding u-v inside one connected component is allowed iff the unique
//    forest path between u and v contains no cycle edge and its XOR x'
//    satisfies x' ^ x == 1. Adding u-v between components is always allowed.
//  - Accepted cycle-closing edges are not kept in the forest; their forest
//    path edges are marked "cyclic" forever.
// A link-cut tree over the forest (edges as nodes) gives path XOR and
// "any cyclic edge on path" queries, plus path marking. A DSU answers
// connectivity (the forest is never cut).

#include <bits/stdc++.h>
using namespace std;

static const int MAXN = 300000 + 500000 + 5;

int ch[MAXN][2], fa[MAXN];
int rv[MAXN], mk[MAXN];
int isE[MAXN], cyc[MAXN], cntE[MAXN], cntC[MAXN];
int val[MAXN], xs[MAXN];

bool isRoot(int x) {
    int f = fa[x];
    return f == 0 || (ch[f][0] != x && ch[f][1] != x);
}

void applyRev(int x) {
    if (!x) return;
    swap(ch[x][0], ch[x][1]);
    rv[x] ^= 1;
}

void applyMark(int x) {
    if (!x) return;
    mk[x] = 1;
    cyc[x] = isE[x];
    cntC[x] = cntE[x];
}

void push(int x) {
    if (rv[x]) {
        applyRev(ch[x][0]);
        applyRev(ch[x][1]);
        rv[x] = 0;
    }
    if (mk[x]) {
        applyMark(ch[x][0]);
        applyMark(ch[x][1]);
        mk[x] = 0;
    }
}

void pull(int x) {
    int l = ch[x][0], r = ch[x][1];
    cntE[x] = isE[x] + cntE[l] + cntE[r];
    cntC[x] = cyc[x] + cntC[l] + cntC[r];
    xs[x] = val[x] ^ xs[l] ^ xs[r];
}

void rotate(int x) {
    int y = fa[x], z = fa[y];
    int k = (ch[y][1] == x);
    if (!isRoot(y)) ch[z][ch[z][1] == y] = x;
    fa[x] = z;
    ch[y][k] = ch[x][k ^ 1];
    if (ch[x][k ^ 1]) fa[ch[x][k ^ 1]] = y;
    ch[x][k ^ 1] = y;
    fa[y] = x;
    pull(y);
    pull(x);
}

int stk[MAXN];

void splay(int x) {
    int top = 0, y = x;
    stk[top++] = y;
    while (!isRoot(y)) {
        y = fa[y];
        stk[top++] = y;
    }
    while (top) push(stk[--top]);
    while (!isRoot(x)) {
        int y2 = fa[x], z = fa[y2];
        if (!isRoot(y2)) {
            if ((ch[y2][1] == x) == (ch[z][1] == y2)) rotate(y2);
            else rotate(x);
        }
        rotate(x);
    }
}

void access(int x) {
    int last = 0;
    for (int y = x; y; y = fa[y]) {
        splay(y);
        ch[y][1] = last;
        pull(y);
        last = y;
    }
    splay(x);
}

void makeRoot(int x) {
    access(x);
    applyRev(x);
}

// Precondition: x and y in different trees.
void linkNodes(int x, int y) {
    makeRoot(x);
    fa[x] = y;
}

int dsuP[300005];
int findS(int x) {
    while (dsuP[x] != x) {
        dsuP[x] = dsuP[dsuP[x]];
        x = dsuP[x];
    }
    return x;
}

int main() {
    int n, q;
    if (scanf("%d %d", &n, &q) != 2) return 0;
    for (int i = 1; i <= n; i++) dsuP[i] = i;
    int nextId = n + 1;
    string out;
    out.reserve((size_t)q * 4);

    for (int i = 0; i < q; i++) {
        int u, v, x;
        scanf("%d %d %d", &u, &v, &x);
        int ru = findS(u), rv_ = findS(v);
        if (ru != rv_) {
            dsuP[ru] = rv_;
            int e = nextId++;
            isE[e] = 1;
            val[e] = x;
            pull(e);
            linkNodes(u, e);
            linkNodes(e, v);
            out += "YES\n";
        } else {
            makeRoot(u);
            access(v);
            // v is the splay root of the u..v path.
            int px = xs[v];
            if (cntC[v] > 0 || (px ^ x) != 1) {
                out += "NO\n";
            } else {
                applyMark(v);
                out += "YES\n";
            }
        }
    }
    fwrite(out.data(), 1, out.size(), stdout);
    return 0;
}
