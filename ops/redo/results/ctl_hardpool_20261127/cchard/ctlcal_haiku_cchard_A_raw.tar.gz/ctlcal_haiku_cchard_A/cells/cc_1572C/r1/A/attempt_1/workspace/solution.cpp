// Codeforces 1572C "Paint".
// Compress runs of equal colours into b[0..m-1]. Each operation can reduce the
// number of runs by at most one, and the answer is (m-1) minus the maximum
// number of "free" merges, computed by an interval DP:
//   dp[l][r] = max(dp[l+1][r],
//                  max over j in (l, r] with b[j]==b[l] of
//                      dp[l+1][j-1] + 1 + dp[j][r])
// Each colour has at most 20 pixels, so every l has at most 19 such j.
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while (t--) {
        int n;
        cin >> n;
        vector<int> a(n);
        for (auto &x : a) cin >> x;

        vector<int> b;
        for (int x : a) {
            if (b.empty() || b.back() != x) b.push_back(x);
        }
        int m = (int)b.size();
        if (m <= 1) {
            cout << 0 << '\n';
            continue;
        }

        // dp stored row-major: dp[l*m + r]; only r >= l is meaningful.
        vector<int> dp((size_t)m * m, 0);
        auto D = [&](int l, int r) -> int & { return dp[(size_t)l * m + r]; };

        for (int l = m - 2; l >= 0; --l) {
            // Base: skip pixel l.
            for (int r = l + 1; r < m; ++r) D(l, r) = D(l + 1, r);
            // Merge pixel l with a later pixel j of the same colour.
            for (int j = l + 2; j < m; ++j) {
                if (b[j] != b[l]) continue;
                int c = D(l + 1, j - 1) + 1;
                for (int r = j; r < m; ++r) {
                    int v = c + D(j, r);
                    if (v > D(l, r)) D(l, r) = v;
                }
            }
        }

        cout << (m - 1) - D(0, m - 1) << '\n';
    }
    return 0;
}
