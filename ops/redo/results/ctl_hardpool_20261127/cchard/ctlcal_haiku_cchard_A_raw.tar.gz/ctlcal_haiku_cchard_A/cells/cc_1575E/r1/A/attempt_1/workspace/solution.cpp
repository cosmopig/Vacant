#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
static const ll MOD = 1000000007LL;
static const ll INV2 = (MOD + 1) / 2;

int n, K;
vector<ll> a;
vector<vector<pair<int, int>>> adj;

// items: (x, col, D). col 0/1 = colour of first rail from the centre, 2 = centre itself.
// Returns sum over ordered pairs (p,q) (p==q allowed) with x_p + x_q + delta <= K
// of (D_p + D_q - ac), modulo MOD. D values are already reduced mod MOD.
ll through(const vector<array<ll, 3>>& items, ll ac) {
    if (items.empty()) return 0;
    ll L = 0;
    for (auto& it : items) L = max(L, it[0]);
    L += 2;
    vector<ll> c[3], s[3];
    for (int col = 0; col < 3; col++) {
        c[col].assign(L, 0);
        s[col].assign(L, 0);
    }
    for (auto& it : items) {
        int x = (int)it[0], col = (int)it[1];
        c[col][x] += 1;
        s[col][x] = (s[col][x] + it[2]) % MOD;
    }
    for (int col = 0; col < 3; col++)
        for (ll i = 1; i < L; i++) {
            c[col][i] += c[col][i - 1];
            s[col][i] = (s[col][i] + s[col][i - 1]) % MOD;
        }
    ll total = 0;
    for (auto& it : items) {
        ll x = it[0];
        int col = (int)it[1];
        ll d = it[2];
        ll T = (ll)K - x;
        if (T < 0) continue;
        if (T > L - 1) T = L - 1;
        ll cnt = 0, sd = 0;
        if (col == 2) {
            for (int q = 0; q < 3; q++) {
                cnt += c[q][T];
                sd += s[q][T];
            }
        } else {
            int other = 1 - col;
            // same colour or centre partner: no ticket needed
            cnt += c[col][T] + c[2][T];
            sd += s[col][T] + s[2][T];
            // opposite colour partner: one ticket needed
            if (T >= 1) {
                cnt += c[other][T - 1];
                sd += s[other][T - 1];
            }
        }
        sd %= MOD;
        ll dd = ((d - ac) % MOD + MOD) % MOD;
        total = (total + (cnt % MOD) * dd % MOD + sd) % MOD;
    }
    return total;
}

int main() {
    if (scanf("%d %d", &n, &K) != 2) return 0;
    a.assign(n, 0);
    for (int i = 0; i < n; i++) {
        ll x = 0;
        scanf("%lld", &x);
        a[i] = ((x % MOD) + MOD) % MOD;
    }
    adj.assign(n, {});
    for (int i = 0; i < n - 1; i++) {
        int u, v, t;
        scanf("%d %d %d", &u, &v, &t);
        u--;
        v--;
        adj[u].push_back({v, t});
        adj[v].push_back({u, t});
    }

    vector<char> removed(n, 0);
    vector<int> par(n, -1), sz(n, 0), ec(n, 0), xs(n, 0), hc(n, 0);
    vector<ll> dsum(n, 0);
    ll ans = 0;
    vector<int> stk;
    stk.push_back(0);
    vector<int> order;
    while (!stk.empty()) {
        int r = stk.back();
        stk.pop_back();
        par[r] = -1;
        order.clear();
        order.push_back(r);
        for (size_t i = 0; i < order.size(); i++) {
            int u = order[i];
            int pu = par[u];
            for (auto& e : adj[u]) {
                int v = e.first;
                if (v != pu && !removed[v]) {
                    par[v] = u;
                    order.push_back(v);
                }
            }
        }
        int tot = (int)order.size();
        if (tot == 1) {
            removed[r] = 1;
            continue;
        }
        for (int u : order) sz[u] = 1;
        for (int j = tot - 1; j > 0; j--) {
            int u = order[j];
            sz[par[u]] += sz[u];
        }
        // find centroid
        int c = r;
        while (true) {
            bool moved = false;
            int pc = par[c];
            for (auto& e : adj[c]) {
                int v = e.first;
                if (v != pc && !removed[v] && 2LL * sz[v] > tot) {
                    c = v;
                    moved = true;
                    break;
                }
            }
            if (!moved) break;
        }

        ll ac = a[c];
        vector<array<ll, 3>> allI;
        allI.push_back({0, 2, ac});
        vector<vector<array<ll, 3>>> groups;
        par[c] = -1;
        for (auto& e : adj[c]) {
            int v = e.first, t = e.second;
            if (removed[v]) continue;
            par[v] = c;
            ec[v] = t;
            xs[v] = 0;
            hc[v] = t;
            dsum[v] = (ac + a[v]) % MOD;
            vector<int> q;
            q.push_back(v);
            for (size_t j = 0; j < q.size(); j++) {
                int w = q[j];
                int pw = par[w];
                int ew = ec[w];
                for (auto& f : adj[w]) {
                    int y = f.first, s2 = f.second;
                    if (y != pw && !removed[y]) {
                        par[y] = w;
                        ec[y] = s2;
                        xs[y] = xs[w] + (s2 != ew ? 1 : 0);
                        hc[y] = hc[w];
                        dsum[y] = (dsum[w] + a[y]) % MOD;
                        q.push_back(y);
                    }
                }
            }
            vector<array<ll, 3>> g;
            g.reserve(q.size());
            for (int w : q) g.push_back({(ll)xs[w], (ll)hc[w], dsum[w]});
            allI.insert(allI.end(), g.begin(), g.end());
            groups.push_back(move(g));
        }

        ll contrib = through(allI, ac);
        for (auto& g : groups) contrib = (contrib - through(g, ac) + MOD) % MOD;
        contrib = (contrib - ac + MOD) % MOD;
        ans = (ans + contrib * INV2) % MOD;

        removed[c] = 1;
        for (auto& e : adj[c]) {
            if (!removed[e.first]) stk.push_back(e.first);
        }
    }

    ll singles = 0;
    for (ll x : a) singles = (singles + x) % MOD;
    printf("%lld\n", (singles + ans) % MOD);
    return 0;
}
