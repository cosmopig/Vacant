#include <bits/stdc++.h>
using namespace std;

static const long long MOD = 998244353LL;

static vector<int> parent_;

int findr(int x) {
    while (parent_[x] != x) {
        parent_[x] = parent_[parent_[x]];
        x = parent_[x];
    }
    return x;
}

void unite(int a, int b) {
    a = findr(a);
    b = findr(b);
    if (a != b) parent_[a] = b;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    long long n, m, k;
    cin >> n >> m >> k;

    vector<char> inComp(k + 1, 0);
    vector<pair<int, int>> edges;
    edges.reserve(300000);

    for (long long i = 0; i < n; i++) {
        int c;
        cin >> c;
        vector<int> a(c);
        for (int j = 0; j < c; j++) cin >> a[j];
        if (c >= 2) {
            for (int j = 0; j < c; j++) inComp[a[j]] = 1;
            for (int j = 0; j + 1 < c; j++) edges.emplace_back(a[j], a[j + 1]);
        }
    }

    sort(edges.begin(), edges.end());
    edges.erase(unique(edges.begin(), edges.end()), edges.end());

    parent_.resize(k + 1);
    for (int v = 0; v <= k; v++) parent_[v] = v;

    vector<int> outdeg(k + 1, 0), indeg(k + 1, 0);
    for (auto &e : edges) {
        outdeg[e.first]++;
        indeg[e.second]++;
        unite(e.first, e.second);
    }

    long long inCompCount = 0;
    vector<int> vcount(k + 1, 0), ecount(k + 1, 0);
    vector<char> bad(k + 1, 0);

    for (int v = 1; v <= k; v++) {
        if (!inComp[v]) continue;
        inCompCount++;
        int r = findr(v);
        vcount[r]++;
        if (outdeg[v] > 1 || indeg[v] > 1) bad[r] = 1;
    }
    for (auto &e : edges) {
        ecount[findr(e.first)]++;
    }

    // cnt[L] = number of valid path components with L values
    vector<long long> cnt(k + 2, 0);
    for (int v = 1; v <= k; v++) {
        if (!inComp[v]) continue;
        if (findr(v) != v) continue;
        if (!bad[v] && ecount[v] == vcount[v] - 1) {
            cnt[vcount[v]]++;
        }
    }

    vector<pair<int, long long>> blocks;
    for (int L = 1; L <= k; L++) {
        if (cnt[L] > 0) blocks.emplace_back(L, cnt[L] % MOD);
    }

    long long f = (k - inCompCount) % MOD;

    vector<long long> dp(m + 1, 0);
    dp[0] = 1;
    for (long long i = 1; i <= m; i++) {
        long long acc = f * dp[i - 1] % MOD;
        for (auto &b : blocks) {
            if (b.first > i) break;
            acc = (acc + b.second * dp[i - b.first]) % MOD;
        }
        dp[i] = acc;
    }

    cout << dp[m] % MOD << "\n";
    return 0;
}
