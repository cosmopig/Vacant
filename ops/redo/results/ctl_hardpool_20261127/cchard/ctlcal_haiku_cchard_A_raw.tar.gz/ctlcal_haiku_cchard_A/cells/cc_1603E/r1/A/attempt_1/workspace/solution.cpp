#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long ull;

// A sorted sequence c_1<=...<=c_n (values in [1, n+1]) is perfect iff for every j,
// c_1 * c_j >= c_1 + ... + c_j.  Write x0 = c_1 and E_j = sum_{i<=j} (c_i - x0).
// Then the condition is E_j <= x0 * (c_j - j).  Since E is nondecreasing and the
// final E is <= x0, every intermediate E is <= x0 as well (state pruning).
// The arrangement count of a multiset is prod_v C(remaining, m_v), so the DP
// adds whole value-blocks with binomial weights.
int main() {
    long long n_ll, M_ll;
    cin >> n_ll >> M_ll;
    int n = (int)n_ll;
    ull M = (ull)M_ll;

    vector<vector<ull>> C(n + 2, vector<ull>(n + 2, 0));
    for (int i = 0; i <= n + 1; i++) {
        C[i][0] = 1 % M;
        for (int j = 1; j <= i; j++) C[i][j] = (C[i - 1][j - 1] + (j <= i - 1 ? C[i - 1][j] : 0)) % M;
    }

    ull ans = 0;
    for (int x0 = 1; x0 <= n + 1; x0++) {
        // m0 <= x0 copies of x0, and at least n - x0 other elements each with excess >= 1
        // and total excess <= x0, so n <= 2*x0 is necessary.
        if (n > 2 * x0) continue;
        int W = x0;  // excess cap
        // f[k*(W+1)+E]: weighted count of prefixes with k elements and excess E.
        // Updated in place: targets have k2 > k, so iterate k downwards.
        vector<ull> f((size_t)(n + 1) * (W + 1), 0);
        auto at = [&](int k, int E) -> ull& { return f[(size_t)k * (W + 1) + E]; };
        for (int m0 = 1; m0 <= min(n, x0); m0++) at(m0, 0) = C[n][m0];
        for (int v = x0 + 1; v <= n + 1; v++) {
            int d = v - x0;
            for (int k = min(n - 1, v - 1); k >= 0; k--) {
                for (int E = 0; E <= W; E++) {
                    ull val = at(k, E);
                    if (!val) continue;
                    int maxm = min(n - k, (W - E) / d);
                    for (int m = 1; m <= maxm; m++) {
                        int k2 = k + m, E2 = E + m * d;
                        if (k2 > v) break;  // count can't exceed the largest value used
                        if ((long long)E2 > (long long)x0 * (v - k2)) continue;
                        ull& t = at(k2, E2);
                        t = (t + val * C[n - k][m]) % M;
                    }
                }
            }
        }
        for (int E = 0; E <= W; E++) ans = (ans + at(n, E)) % M;
    }
    cout << ans % M << endl;
    return 0;
}
