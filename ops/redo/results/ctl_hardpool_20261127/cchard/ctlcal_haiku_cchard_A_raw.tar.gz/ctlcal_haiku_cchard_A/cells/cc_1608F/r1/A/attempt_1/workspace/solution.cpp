// MEX counting.
//
// State after prefix i: (m, D) where m = MEX of the prefix and D = number of
// distinct values in the prefix. Values above m that have appeared are kept
// unlabelled ("tokens"); they get concrete values only when the MEX jumps past
// them, which is counted with falling factorials.
//
// Transitions for position i (from time i-1):
//   repeat  : a_i is one of the D appeared values            -> (m, D),   weight D
//   token   : a_i is a new value above m, labelled later      -> (m, D+1), weight 1
//   jump    : a_i = m, MEX becomes m' > m; the m'-m-1 values
//             m+1..m'-1 are chosen among the U = D-m tokens    -> (m', D+1),
//             weight P(D-m, m'-m-1) = (D-m)! / (D+1-m')!
// Final answer: sum over (M, D) of P(n-M, D-M) = (n-M)! / (n-D)!.
// Only m in [max(0,b_i-k), min(n,b_i+k)] is allowed at time i.
#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long ull;
static const ull MOD = 998244353ULL;

ull pw(ull b, ull e) {
    ull r = 1;
    b %= MOD;
    while (e) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

int main() {
    int n, k;
    if (scanf("%d %d", &n, &k) != 2) return 0;
    vector<long long> b(n + 1);
    for (int i = 1; i <= n; i++) scanf("%lld", &b[i]);

    vector<int> L(n + 1), R(n + 1);
    for (int i = 1; i <= n; i++) {
        long long lo = max(0LL, b[i] - k);
        long long hi = min((long long)n, b[i] + k);
        if (lo > hi) {
            printf("0\n");
            return 0;
        }
        L[i] = (int)lo;
        R[i] = (int)hi;
    }

    vector<ull> fact(n + 3), inv(n + 3);
    fact[0] = 1;
    for (int i = 1; i < n + 3; i++) fact[i] = fact[i - 1] * i % MOD;
    inv[n + 2] = pw(fact[n + 2], MOD - 2);
    for (int i = n + 2; i > 0; i--) inv[i - 1] = inv[i] * i % MOD;

    const int W = n + 2;
    vector<ull> X((size_t)W * W, 0), Y((size_t)W * W, 0);
    auto at = [&](vector<ull>& v, int m, int d) -> ull& { return v[(size_t)m * W + d]; };

    at(X, 0, 0) = 1;
    int A = 0, B = 0;  // window of MEX values at time i-1
    vector<ull> pre;

    for (int i = 1; i <= n; i++) {
        int a2 = L[i], b2 = R[i];
        // Y is all zero here.
        for (int D = 0; D <= i - 1; D++) {
            // repeat / token: MEX unchanged, must stay inside the new window.
            int lo = max(A, a2), hi = min(B, b2);
            for (int m = lo; m <= hi; m++) {
                if (m > D) break;
                ull v = at(X, m, D);
                if (!v) continue;
                at(Y, m, D) = (at(Y, m, D) + v * (ull)D) % MOD;
                at(Y, m, D + 1) = (at(Y, m, D + 1) + v) % MOD;
            }
            // jump: MEX goes from m to m2 > m.
            pre.assign(B - A + 2, 0);
            for (int m = A; m <= B; m++) {
                ull t = 0;
                if (m <= D) t = at(X, m, D) * fact[D - m] % MOD;
                pre[m - A + 1] = (pre[m - A] + t) % MOD;
            }
            for (int m2 = a2; m2 <= b2; m2++) {
                if (m2 > D + 1) break;
                int idx = m2 - A;
                if (idx < 0) idx = 0;
                if (idx > B - A + 1) idx = B - A + 1;
                if (idx == 0) continue;
                ull c = pre[idx] * inv[D + 1 - m2] % MOD;
                at(Y, m2, D + 1) = (at(Y, m2, D + 1) + c) % MOD;
            }
        }
        // Clear old buffer so it can be reused as the next Y.
        for (int m = A; m <= B; m++)
            for (int D = 0; D <= i - 1; D++) at(X, m, D) = 0;
        swap(X, Y);
        A = a2;
        B = b2;
    }

    ull ans = 0;
    for (int m = A; m <= B; m++)
        for (int D = m; D <= n; D++) {
            ull v = at(X, m, D);
            if (!v) continue;
            ans = (ans + v * fact[n - m] % MOD * inv[n - D]) % MOD;
        }
    printf("%llu\n", ans);
    return 0;
}
