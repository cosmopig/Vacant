// Count permutations of length n with exactly k "good" elements, where x is good
// iff the number of distinct subsegment maxima containing x equals m.
//
// Key fact: for position i, the distinct maxima over subsegments containing i are
// the values of the proper ancestors of i in the max-Cartesian tree, plus c_i itself.
// So x is good iff its depth (root = depth 0) equals m-1.
//
// g[t][len][k] = number of permutations of length len having exactly k elements at
// depth t. Splitting at the maximum (root) with left size L and right size len-1-L:
//   g[t][len][k] = sum_L C(len-1, L) * sum_{k1+k2=k} g[t-1][L][k1] * g[t-1][R][k2]
// Base: g[0][len][1] = len!, g[0][0][0] = 1.
// Answer: g[m-1][n][k] mod p.
#include <bits/stdc++.h>
using namespace std;

int main() {
    long long n, m, k, p;
    cin >> n >> m >> k >> p;

    // Binomials mod p (p need not be prime).
    vector<vector<long long>> C(n + 1, vector<long long>(n + 1, 0));
    for (int i = 0; i <= n; i++) {
        C[i][0] = 1 % p;
        for (int j = 1; j <= i; j++) {
            C[i][j] = (C[i - 1][j - 1] + (j <= i - 1 ? C[i - 1][j] : 0)) % p;
        }
    }

    // Depth 0.
    vector<vector<long long>> prev(n + 1, vector<long long>(n + 1, 0));
    prev[0][0] = 1 % p;
    {
        long long f = 1 % p;
        for (int len = 1; len <= n; len++) {
            f = f * len % p;
            prev[len][1] = f;
        }
    }

    for (int t = 1; t <= m - 1; t++) {
        vector<vector<long long>> cur(n + 1, vector<long long>(n + 1, 0));
        cur[0][0] = 1 % p;  // empty subtree: zero nodes at every depth
        for (int len = 1; len <= n; len++) {
            for (int L = 0; L <= len - 1; L++) {
                int R = len - 1 - L;
                long long c = C[len - 1][L];
                if (c == 0) continue;
                for (int k1 = 0; k1 <= L; k1++) {
                    long long a = prev[L][k1];
                    if (a == 0) continue;
                    long long ca = a * c % p;
                    for (int k2 = 0; k2 <= R && k1 + k2 <= n; k2++) {
                        long long b = prev[R][k2];
                        if (b == 0) continue;
                        cur[len][k1 + k2] = (cur[len][k1 + k2] + ca * b) % p;
                    }
                }
            }
        }
        prev.swap(cur);
    }

    long long ans = 0;
    if (k >= 0 && k <= n) ans = prev[n][k] % p;
    cout << ans << "\n";
    return 0;
}
