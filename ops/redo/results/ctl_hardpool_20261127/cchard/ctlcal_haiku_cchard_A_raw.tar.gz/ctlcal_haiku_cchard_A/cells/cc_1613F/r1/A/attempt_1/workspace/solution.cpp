#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

const ll MOD = 998244353;

ll pw(ll b, ll e) {
    ll r = 1;
    b %= MOD;
    if (b < 0) b += MOD;
    while (e) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

void ntt(vector<ll>& a, bool inv) {
    int n = a.size();
    for (int i = 1, j = 0; i < n; i++) {
        int bit = n >> 1;
        for (; j & bit; bit >>= 1) j ^= bit;
        j ^= bit;
        if (i < j) swap(a[i], a[j]);
    }
    for (int len = 2; len <= n; len <<= 1) {
        ll w = pw(3, (MOD - 1) / len);
        if (inv) w = pw(w, MOD - 2);
        int half = len / 2;
        vector<ll> ws(half);
        ws[0] = 1;
        for (int i = 1; i < half; i++) ws[i] = ws[i - 1] * w % MOD;
        for (int i = 0; i < n; i += len) {
            for (int j = 0; j < half; j++) {
                ll u = a[i + j];
                ll v = a[i + j + half] * ws[j] % MOD;
                ll s = u + v;
                a[i + j] = s >= MOD ? s - MOD : s;
                ll d = u - v;
                a[i + j + half] = d < 0 ? d + MOD : d;
            }
        }
    }
    if (inv) {
        ll ni = pw(n, MOD - 2);
        for (auto& x : a) x = x * ni % MOD;
    }
}

vector<ll> multiply(vector<ll> a, vector<ll> b) {
    if (a.empty() || b.empty()) return {};
    int need = a.size() + b.size() - 1;
    if (min(a.size(), b.size()) <= 32) {
        vector<ll> r(need, 0);
        for (size_t i = 0; i < a.size(); i++)
            for (size_t j = 0; j < b.size(); j++)
                r[i + j] = (r[i + j] + a[i] * b[j]) % MOD;
        return r;
    }
    int sz = 1;
    while (sz < need) sz <<= 1;
    a.resize(sz);
    b.resize(sz);
    ntt(a, false);
    ntt(b, false);
    for (int i = 0; i < sz; i++) a[i] = a[i] * b[i] % MOD;
    ntt(a, true);
    a.resize(need);
    return a;
}

vector<ll> ds;  // non-zero child counts; factor (1 + d x) for each

vector<ll> prodRange(int l, int r) {
    if (r - l == 1) return {1, ds[l] % MOD};
    int m = (l + r) / 2;
    return multiply(prodRange(l, m), prodRange(m, r));
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;
    vector<int> deg(n + 1, 0);
    for (int i = 0; i < n - 1; i++) {
        int x, y;
        cin >> x >> y;
        deg[x]++;
        deg[y]++;
    }
    // Every non-root vertex has exactly one parent edge, so its child count
    // is deg - 1; the root has no parent edge, so its child count is deg.
    for (int p = 1; p <= n; p++) {
        int d = deg[p] - (p != 1 ? 1 : 0);
        if (d > 0) ds.push_back(d);
    }

    vector<ll> poly;
    if (ds.empty()) {
        poly = {1};
    } else {
        poly = prodRange(0, ds.size());
    }

    vector<ll> fact(n + 1, 1);
    for (int i = 1; i <= n; i++) fact[i] = fact[i - 1] * i % MOD;

    ll ans = 0;
    for (size_t k = 0; k < poly.size() && (int)k <= n; k++) {
        ll term = poly[k] * fact[n - k] % MOD;
        if (k & 1)
            ans = (ans - term + MOD) % MOD;
        else
            ans = (ans + term) % MOD;
    }
    cout << ans << "\n";
    return 0;
}
