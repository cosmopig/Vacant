import sys

MOD = 10**9 + 7
INV2 = (MOD + 1) // 2


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    k = int(data[1])
    a = [int(data[2 + i]) % MOD for i in range(n)]
    adj = [[] for _ in range(n)]
    idx = 2 + n
    for _ in range(n - 1):
        u = int(data[idx]) - 1
        v = int(data[idx + 1]) - 1
        t = int(data[idx + 2])
        idx += 3
        adj[u].append((v, t))
        adj[v].append((u, t))

    def through(items, ac):
        # items: list of (x, col, D); col 0/1 = colour of first rail from centre, 2 = centre itself.
        # Returns sum over ordered pairs (p, q) in items (incl. p == q) with
        # x_p + x_q + delta <= k of (D_p + D_q - ac).
        if not items:
            return 0
        L = max(it[0] for it in items) + 2
        c0 = [0] * L
        s0 = [0] * L
        c1 = [0] * L
        s1 = [0] * L
        c2 = [0] * L
        s2 = [0] * L
        for x, col, d in items:
            if col == 0:
                c0[x] += 1
                s0[x] += d
            elif col == 1:
                c1[x] += 1
                s1[x] += d
            else:
                c2[x] += 1
                s2[x] += d
        for i in range(1, L):
            c0[i] += c0[i - 1]
            s0[i] += s0[i - 1]
            c1[i] += c1[i - 1]
            s1[i] += s1[i - 1]
            c2[i] += c2[i - 1]
            s2[i] += s2[i - 1]
        total = 0
        for x, col, d in items:
            T = k - x
            if T < 0:
                continue
            if T > L - 1:
                T = L - 1
            if col == 2:
                cnt = c0[T] + c1[T] + c2[T]
                sd = s0[T] + s1[T] + s2[T]
            elif col == 0:
                cnt = c0[T] + c2[T]
                sd = s0[T] + s2[T]
                if T >= 1:
                    cnt += c1[T - 1]
                    sd += s1[T - 1]
            else:
                cnt = c1[T] + c2[T]
                sd = s1[T] + s2[T]
                if T >= 1:
                    cnt += c0[T - 1]
                    sd += s0[T - 1]
            total += cnt * (d - ac) + sd
        return total

    removed = [False] * n
    par = [-1] * n
    sz = [0] * n
    ec = [0] * n
    xs = [0] * n
    hc = [0] * n
    dsum = [0] * n
    ans = 0
    stack = [0]
    while stack:
        r = stack.pop()
        par[r] = -1
        order = [r]
        i = 0
        while i < len(order):
            u = order[i]
            i += 1
            pu = par[u]
            for v, _ in adj[u]:
                if v != pu and not removed[v]:
                    par[v] = u
                    order.append(v)
        tot = len(order)
        if tot == 1:
            removed[r] = True
            continue
        for u in order:
            sz[u] = 1
        for j in range(tot - 1, 0, -1):
            u = order[j]
            sz[par[u]] += sz[u]
        # find centroid
        c = r
        while True:
            moved = False
            pc = par[c]
            for v, _ in adj[c]:
                if v != pc and not removed[v] and sz[v] * 2 > tot:
                    c = v
                    moved = True
                    break
            if not moved:
                break

        ac = a[c]
        all_items = [(0, 2, ac)]
        group_items = []
        par[c] = -1
        for v, t in adj[c]:
            if removed[v]:
                continue
            par[v] = c
            ec[v] = t
            xs[v] = 0
            hc[v] = t
            dsum[v] = ac + a[v]
            q = [v]
            j = 0
            while j < len(q):
                w = q[j]
                j += 1
                pw = par[w]
                ew = ec[w]
                xw = xs[w]
                hw = hc[w]
                dw = dsum[w]
                for y, s in adj[w]:
                    if y != pw and not removed[y]:
                        par[y] = w
                        ec[y] = s
                        xs[y] = xw + (1 if s != ew else 0)
                        hc[y] = hw
                        dsum[y] = dw + a[y]
                        q.append(y)
            items = [(xs[w], hc[w], dsum[w]) for w in q]
            group_items.append(items)
            all_items.extend(items)

        contrib = through(all_items, ac)
        for g in group_items:
            contrib -= through(g, ac)
        contrib -= ac
        ans = (ans + contrib % MOD * INV2) % MOD

        removed[c] = True
        for v, _ in adj[c]:
            if not removed[v]:
                stack.append(v)

    singles = sum(a) % MOD
    print((singles + ans) % MOD)


main()
