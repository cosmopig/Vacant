#include <bits/stdc++.h>
using namespace std;

// A segment [l,r] is simple iff for every prefix k in [l,r] the value
// x_k = prod_{i=l..k} a_i^{s_i} (s_i = +1 for '*', -1 for '/') is an integer,
// i.e. for every prime p: S_k(p) >= S_{l-1}(p), where S_k(p) = sum_{i<=k} s_i*v_p(a_i).
//
// For a start j = l-1 let bad(j) = first k > j with S_k(p) < S_j(p) for some p.
// Then valid r are j+1 .. bad(j)-1, so the answer is sum_j (bad(j) - j - 1).
//
// For a fixed prime p, S(p) is piecewise constant over blocks of indices. For a block b
// with value v, every j in the block has first-smaller index = start of the first later
// block with value < v (next-smaller-element over blocks). We apply these as range-chmin
// updates over j, then point-query each j.

static int segN;
static vector<int> tagv;

static void rangeChmin(int l, int r, int v) {  // inclusive [l, r]
    l += segN;
    r += segN + 1;
    while (l < r) {
        if (l & 1) { if (v < tagv[l]) tagv[l] = v; l++; }
        if (r & 1) { --r; if (v < tagv[r]) tagv[r] = v; }
        l >>= 1;
        r >>= 1;
    }
}

static int pointQuery(int j) {
    int idx = j + segN;
    int res = tagv[idx];
    while (idx > 1) {
        idx >>= 1;
        res = min(res, tagv[idx]);
    }
    return res;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;
    vector<int> a(n + 1);
    for (int i = 1; i <= n; i++) cin >> a[i];
    string b;
    cin >> b;

    const int MAXV = 1000000;
    vector<int> spf(MAXV + 1, 0);
    for (int i = 2; i <= MAXV; i++) {
        if (spf[i] == 0) {
            for (long long j = i; j <= MAXV; j += i) {
                if (spf[j] == 0) spf[j] = i;
            }
        }
    }

    // Count events per prime (number of positions k where p | a_k).
    vector<int> cnt(MAXV + 1, 0);
    for (int k = 1; k <= n; k++) {
        int x = a[k];
        while (x > 1) {
            int p = spf[x];
            cnt[p]++;
            while (x % p == 0) x /= p;
        }
    }
    vector<long long> off(MAXV + 2, 0);
    for (int p = 2; p <= MAXV; p++) off[p + 1] = off[p] + cnt[p];
    long long total = off[MAXV + 1];

    vector<int> evK(total), evD(total);
    vector<long long> pos(off.begin(), off.end());
    for (int k = 1; k <= n; k++) {
        int d = (b[k - 1] == '*') ? 1 : -1;
        int x = a[k];
        while (x > 1) {
            int p = spf[x];
            int e = 0;
            while (x % p == 0) { x /= p; e++; }
            long long q = pos[p]++;
            evK[q] = k;
            evD[q] = d * e;
        }
    }

    segN = 1;
    while (segN < n + 1) segN <<= 1;
    tagv.assign(2 * segN, n + 1);

    vector<int> bs, be, bv, st;
    for (int p = 2; p <= MAXV; p++) {
        int m = cnt[p];
        if (m == 0) continue;
        long long o = off[p];
        int B = m + 1;
        bs.assign(B, 0);
        be.assign(B, 0);
        bv.assign(B, 0);
        int v = 0;
        for (int i = 0; i < B; i++) {
            bs[i] = (i == 0) ? 0 : evK[o + i - 1];
            be[i] = (i < m) ? evK[o + i] - 1 : n;
            if (i > 0) v += evD[o + i - 1];
            bv[i] = v;
        }
        st.clear();
        for (int i = B - 1; i >= 0; i--) {
            while (!st.empty() && bv[st.back()] >= bv[i]) st.pop_back();
            if (!st.empty()) {
                int nx = bs[st.back()];
                rangeChmin(bs[i], be[i], nx);
            }
            st.push_back(i);
        }
    }

    long long ans = 0;
    for (int j = 0; j <= n - 1; j++) {
        int bad = pointQuery(j);
        ans += (long long)bad - j - 1;
    }
    cout << ans << "\n";
    return 0;
}
