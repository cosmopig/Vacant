// Mars: city values are residues mod P = 1e9+7 (prime).
// A road of length D (D != 0) links x and x+D (and x-D). The chosen cities
// (distinct values in [L,R]) can be connected iff they form an arithmetic
// progression x0, x0+D, ..., x0+(k-1)D (mod P).
// Check: solve x0 from the first power sum, then verify power sums 2..4
// against the progression (exact for k <= 3, hash-like check beyond).
// Distinct values in [L,R] are summed offline: index i counts for query
// [L,R] iff i in [L,R] and prev[i] < L (prev = previous equal value, 0 if none).
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
static const ll MOD = 1000000007LL;

ll pw(ll b, ll e) {
    b %= MOD; if (b < 0) b += MOD;
    ll r = 1;
    while (e) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

int N, Q;
// BIT over 5 channels: count, sum a, sum a^2, sum a^3, sum a^4 (mod MOD)
vector<array<ll, 5>> bit;

void upd(int i, const array<ll, 5>& v) {
    for (; i <= N; i += i & -i)
        for (int c = 0; c < 5; c++) bit[i][c] = (bit[i][c] + v[c]) % MOD;
}

array<ll, 5> qry(int i) {
    array<ll, 5> r{0, 0, 0, 0, 0};
    for (; i > 0; i -= i & -i)
        for (int c = 0; c < 5; c++) r[c] = (r[c] + bit[i][c]) % MOD;
    return r;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cin >> N >> Q;
    vector<ll> a(N + 1);
    for (int i = 1; i <= N; i++) {
        ll x;
        cin >> x;
        a[i] = ((x % MOD) + MOD) % MOD;
    }

    // prev occurrence (0 if none)
    vector<int> prv(N + 1, 0);
    {
        unordered_map<ll, int> last;
        last.reserve(N * 2 + 1);
        for (int i = 1; i <= N; i++) {
            auto it = last.find(a[i]);
            prv[i] = (it == last.end()) ? 0 : it->second;
            last[a[i]] = i;
        }
    }
    vector<vector<int>> bucket(N + 1);
    for (int i = 1; i <= N; i++) bucket[prv[i]].push_back(i);

    vector<int> QL(Q), QR(Q);
    vector<ll> QD(Q);
    for (int q = 0; q < Q; q++) {
        cin >> QL[q] >> QR[q] >> QD[q];
        if (QL[q] > QR[q]) swap(QL[q], QR[q]);
    }
    vector<int> ord(Q);
    for (int q = 0; q < Q; q++) ord[q] = q;
    sort(ord.begin(), ord.end(), [&](int x, int y) { return QL[x] < QL[y]; });

    bit.assign(N + 1, array<ll, 5>{0, 0, 0, 0, 0});
    vector<int> ans(Q, 0);
    const ll inv6 = pw(6, MOD - 2);
    const ll inv30 = pw(30, MOD - 2);

    int qp = 0;
    for (int L = 1; L <= N; L++) {
        // activate indices whose previous occurrence is L-1 (prev < L now)
        for (int i : bucket[L - 1]) {
            ll x = a[i];
            ll x2 = x * x % MOD, x3 = x2 * x % MOD, x4 = x3 * x % MOD;
            upd(i, array<ll, 5>{1, x, x2, x3, x4});
        }
        while (qp < Q && QL[ord[qp]] == L) {
            int q = ord[qp++];
            int R = QR[q];
            ll D = QD[q] % MOD;
            array<ll, 5> hi = qry(R), lo = qry(L - 1);
            ll k = (hi[0] - lo[0] + MOD) % MOD;
            if (D == 0) {
                ans[q] = (k <= 1) ? 1 : 0;
                continue;
            }
            if (k <= 1) {
                ans[q] = 1;
                continue;
            }
            ll p1 = (hi[1] - lo[1] + MOD) % MOD;
            ll p2 = (hi[2] - lo[2] + MOD) % MOD;
            ll p3 = (hi[3] - lo[3] + MOD) % MOD;
            ll p4 = (hi[4] - lo[4] + MOD) % MOD;

            ll kk = k % MOD;
            // S1 = sum_{i<k} i, S2 = sum i^2, S3 = sum i^3, S4 = sum i^4
            ll S1 = (k * (k - 1) / 2) % MOD;
            ll S2 = ((k - 1) % MOD) * kk % MOD * ((2 * k - 1) % MOD) % MOD * inv6 % MOD;
            ll S3 = S1 * S1 % MOD;
            ll t = (3 * k % MOD * k % MOD - 3 * k % MOD - 1 + 2 * MOD) % MOD;
            ll S4 = ((k - 1) % MOD) * kk % MOD * ((2 * k - 1) % MOD) % MOD * t % MOD * inv30 % MOD;

            ll invk = pw(kk, MOD - 2);
            ll x0 = ((p1 - D * S1 % MOD) % MOD + MOD) % MOD * invk % MOD;

            ll D2 = D * D % MOD, D3 = D2 * D % MOD, D4 = D3 * D % MOD;
            ll x02 = x0 * x0 % MOD, x03 = x02 * x0 % MOD, x04 = x03 * x0 % MOD;

            ll e2 = (kk * x02 % MOD + 2 * x0 % MOD * D % MOD * S1 % MOD + D2 * S2 % MOD) % MOD;
            ll e3 = (kk * x03 % MOD + 3 * x02 % MOD * D % MOD * S1 % MOD
                     + 3 * x0 % MOD * D2 % MOD * S2 % MOD + D3 * S3 % MOD) % MOD;
            ll e4 = (kk * x04 % MOD + 4 * x03 % MOD * D % MOD * S1 % MOD
                     + 6 * x02 % MOD * D2 % MOD * S2 % MOD
                     + 4 * x0 % MOD * D3 % MOD * S3 % MOD + D4 * S4 % MOD) % MOD;

            ans[q] = (p2 == e2 && p3 == e3 && p4 == e4) ? 1 : 0;
        }
    }

    string out;
    out.reserve(Q * 4);
    for (int q = 0; q < Q; q++) {
        out += ans[q] ? "Yes\n" : "No\n";
    }
    cout << out;
    return 0;
}
