import sys

MOD = 10 ** 9 + 7


def fib_pair(n):
    """Return (F(n) mod MOD, F(n+1) mod MOD) using fast doubling."""
    a, b = 0, 1  # F(0), F(1)
    for bit in bin(n)[2:]:
        # Doubling step: F(2k) = F(k) * (2F(k+1) - F(k)), F(2k+1) = F(k)^2 + F(k+1)^2
        c = a * ((2 * b - a) % MOD) % MOD
        d = (a * a + b * b) % MOD
        if bit == "1":
            a, b = d, (c + d) % MOD
        else:
            a, b = c, d
    return a


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    q = int(data[pos]); pos += 1
    a1 = [int(x) for x in data[pos:pos + n]]; pos += n
    a2 = [int(x) for x in data[pos:pos + n]]; pos += n
    arrays = (None, a1, a2)
    memo = {}
    out = []

    for _ in range(q):
        if pos >= len(data):
            break
        t = int(data[pos]); pos += 1
        if t == 4:
            l = int(data[pos]) - 1
            r = int(data[pos + 1]) - 1
            pos += 2
            total = 0
            for i in range(l, r + 1):
                s = a1[i] + a2[i]
                f = memo.get(s)
                if f is None:
                    f = fib_pair(s)
                    memo[s] = f
                total += f
            out.append(total % MOD)
        else:
            k = int(data[pos])
            l = int(data[pos + 1]) - 1
            r = int(data[pos + 2]) - 1
            x = int(data[pos + 3])
            pos += 4
            arr = arrays[k]
            if t == 1:
                for i in range(l, r + 1):
                    if arr[i] > x:
                        arr[i] = x
            elif t == 2:
                for i in range(l, r + 1):
                    if arr[i] < x:
                        arr[i] = x
            elif t == 3:
                for i in range(l, r + 1):
                    arr[i] += x

    sys.stdout.write("\n".join(map(str, out)) + ("\n" if out else ""))


if __name__ == "__main__":
    main()
