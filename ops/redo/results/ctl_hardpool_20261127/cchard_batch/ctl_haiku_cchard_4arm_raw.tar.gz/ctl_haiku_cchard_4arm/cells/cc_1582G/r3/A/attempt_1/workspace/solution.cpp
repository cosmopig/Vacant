#include <bits/stdc++.h>
using namespace std;

// A segment [l,r] is simple iff for every prime p and every i in [l,r],
// S_p(i) >= S_p(l-1), where S_p is the prefix sum of signed exponents of p
// ('*' contributes +e, '/' contributes -e).
// For start j = l-1 let B_j be the first index i > j where some S_p(i) < S_p(j)
// (n+1 if none). The number of simple segments starting at j+1 is B_j - 1 - j.
// Per prime, S_p is piecewise constant; a next-smaller-element pass over the
// blocks gives range-chmin updates on j, which a tag segment tree resolves.

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;
    vector<int> a(n + 1);
    for (int i = 1; i <= n; i++) cin >> a[i];
    string b;
    cin >> b;

    const int MAXV = 1000000;
    vector<int> spf(MAXV + 1, 0);
    for (int i = 2; i <= MAXV; i++) {
        if (spf[i] == 0) {
            for (long long j = i; j <= MAXV; j += i)
                if (spf[j] == 0) spf[j] = i;
        }
    }

    // Count events per prime (number of distinct primes of each a_i).
    vector<int> cnt(MAXV + 2, 0);
    for (int i = 1; i <= n; i++) {
        int x = a[i];
        while (x > 1) {
            int p = spf[x];
            cnt[p]++;
            while (x % p == 0) x /= p;
        }
    }
    vector<int> off(MAXV + 2, 0);
    for (int p = 0; p <= MAXV; p++) off[p + 1] = off[p] + cnt[p];
    int total = off[MAXV + 1];
    vector<int> evPos(total), evDelta(total);
    vector<int> fill(off.begin(), off.end() - 1);
    for (int i = 1; i <= n; i++) {
        int x = a[i];
        while (x > 1) {
            int p = spf[x];
            int e = 0;
            while (x % p == 0) {
                x /= p;
                e++;
            }
            int k = fill[p]++;
            evPos[k] = i;
            evDelta[k] = (b[i - 1] == '*') ? e : -e;
        }
    }

    // Tag segment tree over j in [0, n]: range chmin, then push down at the end.
    int N = 1;
    while (N < n + 1) N <<= 1;
    const int INF = n + 1;
    vector<int> tag(2 * N, INF);
    auto chmin_range = [&](int l, int r, int val) {  // inclusive [l, r]
        if (l > r) return;
        l += N;
        r += N + 1;
        while (l < r) {
            if (l & 1) {
                tag[l] = min(tag[l], val);
                l++;
            }
            if (r & 1) {
                --r;
                tag[r] = min(tag[r], val);
            }
            l >>= 1;
            r >>= 1;
        }
    };

    vector<long long> v;     // block values v_0..v_k
    vector<int> stk;         // indices into v
    vector<int> ns;          // next smaller index per block
    for (int p = 2; p <= MAXV; p++) {
        int k = cnt[p];
        if (k == 0) continue;
        int base = off[p];
        // Block t (0..k): value v[t], covers j in [q_t, q_{t+1}-1],
        // with q_0 = 0 and q_{k+1} = n+1 (blocks cover j in [0, n]).
        v.assign(k + 1, 0);
        for (int t = 1; t <= k; t++) v[t] = v[t - 1] + evDelta[base + t - 1];
        ns.assign(k + 1, -1);
        stk.clear();
        for (int t = k; t >= 0; t--) {
            while (!stk.empty() && v[stk.back()] >= v[t]) stk.pop_back();
            ns[t] = stk.empty() ? -1 : stk.back();
            stk.push_back(t);
        }
        for (int t = 0; t <= k; t++) {
            if (ns[t] < 0) continue;
            int s = ns[t];
            int bound = evPos[base + s - 1];  // q_s (1-indexed event s)
            int lo = (t == 0) ? 0 : evPos[base + t - 1];
            int hi = (t == k) ? n : evPos[base + t] - 1;
            chmin_range(lo, hi, bound);
        }
    }

    // Push tags down to leaves.
    for (int x = 1; x < N; x++) {
        tag[2 * x] = min(tag[2 * x], tag[x]);
        tag[2 * x + 1] = min(tag[2 * x + 1], tag[x]);
    }

    long long ans = 0;
    for (int j = 0; j < n; j++) {
        long long B = tag[N + j];
        ans += B - 1 - j;
    }
    cout << ans << "\n";
    return 0;
}
