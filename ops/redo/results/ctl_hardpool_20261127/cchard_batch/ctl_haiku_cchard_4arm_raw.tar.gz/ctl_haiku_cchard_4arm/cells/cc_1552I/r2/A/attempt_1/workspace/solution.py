import sys

MOD = 998244353


def main():
    data = sys.stdin.read().split()
    n, m = int(data[0]), int(data[1])
    pos = 2
    raw = set()
    for _ in range(m):
        q = int(data[pos])
        pos += 1
        s = frozenset(int(x) for x in data[pos:pos + q])
        pos += q
        raw.add(s)

    U = frozenset(range(1, n + 1))
    fact = [1] * (n + 2)
    for i in range(1, n + 2):
        fact[i] = fact[i - 1] * i % MOD

    # Trivial constraints (size <= 1, or the whole set) impose nothing.
    S = [s for s in raw if 2 <= len(s) < n]
    k = len(S)

    def overlap(a, b):
        return bool(a & b) and not (a <= b) and not (b <= a)

    # Overlap components via union-find.
    parent = list(range(k))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for i in range(k):
        for j in range(i + 1, k):
            if overlap(S[i], S[j]):
                parent[find(i)] = find(j)

    comps = {}
    for i in range(k):
        comps.setdefault(find(i), []).append(S[i])

    Qdict = {}      # union frozenset -> list of ordered block frozensets
    Pset = set()    # single-set components (plain P-constraints)

    for comp in comps.values():
        if len(comp) == 1:
            Pset.add(comp[0])
            continue
        blocks = build(comp)
        if blocks is None:
            print(0)
            return
        union = frozenset().union(*comp)
        Qdict[union] = blocks

    # A single set equal to a Q-union is already enforced by that Q-node.
    Pset = {s for s in Pset if s not in Qdict}
    allc = list(Pset) + list(Qdict.keys())

    def P(G):
        inside = [c for c in allc if c < G]
        M = [c for c in inside if not any(c < d for d in inside)]
        covered = sum(len(c) for c in M)
        res = fact[len(M) + len(G) - covered]
        for c in M:
            res = res * NODE(c) % MOD
        return res

    def NODE(c):
        if c in Qdict:
            r = 2
            for b in Qdict[c]:
                r = r * blockcount(b) % MOD
            return r
        return P(c)

    def blockcount(b):
        # A block that is itself a Q-union carries that Q-node's structure.
        if b in Qdict:
            return NODE(b)
        return P(b)

    if U in Qdict:
        ans = NODE(U)
    else:
        ans = P(U)
    print(ans % MOD)


def build(comp):
    """Order the classes of an overlap-connected family of >=2 sets.
    Returns the forced block sequence (up to reversal), or None if impossible."""
    # BFS-like order: each next set overlaps some already processed set.
    order = [comp[0]]
    rest = list(comp[1:])
    while rest:
        found = None
        for idx, x in enumerate(rest):
            if any(
                (x & y) and not (x <= y) and not (y <= x) for y in order
            ):
                found = idx
                break
        if found is None:
            return None  # cannot happen for an overlap component
        order.append(rest.pop(found))

    A, B = order[0], order[1]
    blocks = [A - B, A & B, B - A]
    union = A | B

    for X in order[2:]:
        kb = len(blocks)
        inter = [i for i, b in enumerate(blocks) if b & X]
        if not inter:
            return None
        l, r = min(inter), max(inter)
        N = X - union

        def full(i):
            return blocks[i] <= X

        if not N:
            if l == r:
                return None
            for i in range(l + 1, r):
                if not full(i):
                    return None
            new = blocks[:l] + [blocks[l] - X, blocks[l] & X] + blocks[l + 1:r] \
                + [blocks[r] & X, blocks[r] - X] + blocks[r + 1:]
        else:
            opt_app = (r == kb - 1) and all(full(i) for i in range(l + 1, kb))
            opt_pre = (l == 0) and all(full(i) for i in range(0, r))
            if opt_app:
                new = blocks[:l] + [blocks[l] - X, blocks[l] & X] + blocks[l + 1:] + [N]
            elif opt_pre:
                new = [N] + blocks[:r] + [blocks[r] & X, blocks[r] - X] + blocks[r + 1:]
            else:
                return None
            union = union | N
        blocks = [b for b in new if b]

    return blocks


main()
