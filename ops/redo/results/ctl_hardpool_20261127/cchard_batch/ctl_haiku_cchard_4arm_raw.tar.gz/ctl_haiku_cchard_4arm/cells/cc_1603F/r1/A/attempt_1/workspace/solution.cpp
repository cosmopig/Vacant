// Count sequences a_1..a_n in [0, 2^k) such that no non-empty subsequence XORs to x (mod 998244353).
//
// x = 0: the elements must be linearly independent over GF(2), so the answer is
//        prod_{i=0}^{n-1} (2^k - 2^i), which is 0 when n > k.
//
// x != 0: let A(k) be the answer for dimension k. Viewing each a_i as (b_i, c_i) with b_i in GF(2)^{k-1}
//         and c_i in GF(2), one gets A(k) = sum over b-tuples of 2^{rank(b)}. Counting the pairs
//         (b, y) with y in the column span of b gives the recurrence (m = k-1, R = 2^{n+1}):
//             A(1) = 1,   A(m+1) = R^m - (2^m - 1) * A(m).
//         This costs O(k) per test, and the sum of k is at most 5*10^7.

#include <cstdio>

static const long long MOD = 998244353LL;

static long long power(long long b, long long e) {
    b %= MOD;
    if (b < 0) b += MOD;
    long long r = 1;
    while (e > 0) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

int main() {
    int t;
    if (scanf("%d", &t) != 1) return 0;
    while (t--) {
        long long n, k, x;
        scanf("%lld %lld %lld", &n, &k, &x);
        long long ans;
        if (x == 0) {
            if (n > k) {
                ans = 0;
            } else {
                long long pk = power(2, k);
                long long p2i = 1;  // 2^i mod MOD
                ans = 1;
                for (long long i = 0; i < n; i++) {
                    long long term = (pk - p2i + MOD) % MOD;
                    ans = ans * term % MOD;
                    p2i = p2i * 2 % MOD;
                }
            }
        } else {
            // k >= 1 here, since x < 2^min(20,k) and x != 0.
            long long R = power(2, n + 1);
            long long A = 1;   // A(1)
            long long Rp = 1;  // R^m
            long long pw = 1;  // 2^m
            for (long long m = 1; m <= k - 1; m++) {
                Rp = Rp * R % MOD;
                pw = pw * 2 % MOD;
                long long coef = (pw - 1 + MOD) % MOD;
                A = (Rp - coef * A % MOD + MOD) % MOD;
            }
            ans = A;
        }
        printf("%lld\n", ans);
    }
    return 0;
}
