#include <bits/stdc++.h>
using namespace std;

static char buf[1 << 25];
int bufLen = 0, bufPos = 0;

inline int readChar() {
    if (bufPos == bufLen) {
        bufLen = (int)fread(buf, 1, sizeof(buf), stdin);
        bufPos = 0;
        if (bufLen <= 0) return -1;
    }
    return buf[bufPos++];
}

inline long long readInt() {
    int c = readChar();
    while (c != '-' && (c < '0' || c > '9')) c = readChar();
    bool neg = false;
    if (c == '-') { neg = true; c = readChar(); }
    long long x = 0;
    while (c >= '0' && c <= '9') {
        x = x * 10 + (c - '0');
        c = readChar();
    }
    return neg ? -x : x;
}

int n, q, K;
vector<long long> a;      // 1-indexed
vector<int> nse;          // next strictly smaller index, 0 if none
vector<long long> R;      // root-path sum of constant parts
vector<long long> bit;    // BIT over residues 0..K-1 (stored at index key+1)
long long bitTotal = 0;

void bitAdd(int key, long long w) {
    bitTotal += w;
    for (int i = key + 1; i <= K; i += i & (-i)) bit[i] += w;
}

// sum of weights with key < rho
long long bitPrefixLess(int rho) {
    long long s = 0;
    for (int i = rho; i > 0; i -= i & (-i)) s += bit[i];  // keys 0..rho-1 -> indices 1..rho
    return s;
}

// sum of weights with key >= rho
long long sumGE(int rho) {
    return bitTotal - bitPrefixLess(rho);
}

// f(x, rho) = #{y in [0..x] : y % K == rho}
inline long long fcount(long long x, int rho) {
    return x / K + ((x % K) >= rho ? 1 : 0);
}

int main() {
    n = (int)readInt();
    q = (int)readInt();
    K = (int)readInt();

    a.assign(n + 2, 0);
    for (int i = 1; i <= n; i++) a[i] = readInt();

    // next strictly smaller element
    nse.assign(n + 2, 0);
    {
        vector<int> st;
        st.reserve(n);
        for (int i = n; i >= 1; i--) {
            while (!st.empty() && a[st.back()] >= a[i]) st.pop_back();
            nse[i] = st.empty() ? 0 : st.back();
            st.push_back(i);
        }
    }

    // e[p] = last day of p's segment in the prefix-min chain
    vector<long long> e(n + 2, 0);
    for (int p = 1; p <= n; p++) e[p] = nse[p] ? (long long)(nse[p] - 1) : (long long)n;

    // R[p] = sum over ancestors (inclusive) of a * (e/K - (p-1)/K)
    R.assign(n + 2, 0);
    for (int p = n; p >= 1; p--) {
        long long c = a[p] * (e[p] / K - (long long)(p - 1) / K);
        R[p] = c + (nse[p] ? R[nse[p]] : 0);
    }

    // sparse table for leftmost argmin
    int LOG = 1;
    while ((1 << LOG) <= n) LOG++;
    vector<vector<int>> sp(LOG, vector<int>(n + 2, 0));
    for (int i = 1; i <= n; i++) sp[0][i] = i;
    for (int j = 1; j < LOG; j++) {
        for (int i = 1; i + (1 << j) - 1 <= n; i++) {
            int x = sp[j - 1][i], y = sp[j - 1][i + (1 << (j - 1))];
            sp[j][i] = (a[y] < a[x]) ? y : x;  // ties keep left index
        }
    }
    auto argmin = [&](int l, int r) {
        int len = r - l + 1;
        int j = 31 - __builtin_clz(len);
        int x = sp[j][l], y = sp[j][r - (1 << j) + 1];
        return (a[y] < a[x]) ? y : x;
    };

    vector<int> qL(q), qR(q), qRho(q), qPj(q);
    vector<long long> part(q, 0);
    vector<vector<pair<int, int>>> at(n + 2);  // node -> (query id, sign)
    for (int i = 0; i < q; i++) {
        int l = (int)readInt();
        int r = (int)readInt();
        qL[i] = l;
        qR[i] = r;
        qRho[i] = l % K;
        qPj[i] = argmin(l, r);
        at[l].push_back({i, +1});
        at[qPj[i]].push_back({i, -1});
    }

    // children lists of the next-smaller forest
    vector<vector<int>> children(n + 2);
    vector<int> roots;
    for (int p = 1; p <= n; p++) {
        if (nse[p]) children[nse[p]].push_back(p);
        else roots.push_back(p);
    }

    bit.assign(K + 1, 0);
    // iterative DFS: (node, exiting flag)
    vector<pair<int, bool>> stk;
    stk.reserve(2 * n + 2);
    for (int root : roots) {
        stk.push_back({root, false});
        while (!stk.empty()) {
            auto [v, exiting] = stk.back();
            stk.pop_back();
            if (exiting) {
                bitAdd((int)(e[v] % K), -a[v]);
                bitAdd((int)((v - 1) % K), +a[v]);
                continue;
            }
            bitAdd((int)(e[v] % K), +a[v]);
            bitAdd((int)((v - 1) % K), -a[v]);
            for (auto [qi, sign] : at[v]) {
                part[qi] += sign * sumGE(qRho[qi]);
            }
            stk.push_back({v, true});
            for (int c : children[v]) stk.push_back({c, false});
        }
    }

    string out;
    out.reserve((size_t)q * 16);
    for (int i = 0; i < q; i++) {
        int l = qL[i], r = qR[i], rho = qRho[i], pj = qPj[i];
        long long ans = (R[l] - R[pj]) + part[i] +
                        a[pj] * (fcount(r, rho) - fcount(pj - 1, rho));
        out += to_string(ans);
        out += '\n';
    }
    fwrite(out.data(), 1, out.size(), stdout);
    return 0;
}
