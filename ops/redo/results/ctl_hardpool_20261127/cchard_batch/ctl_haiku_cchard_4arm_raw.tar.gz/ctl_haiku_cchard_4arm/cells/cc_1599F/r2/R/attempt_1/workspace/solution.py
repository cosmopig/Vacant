import sys

P = 10**9 + 7


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    q = int(data[1])
    a = [int(x) % P for x in data[2:2 + n]]
    pos = 2 + n
    out = []
    for _ in range(q):
        l = int(data[pos]) - 1
        r = int(data[pos + 1])
        d = int(data[pos + 2]) % P
        pos += 3
        s = set(a[l:r])
        k = len(s)
        if k <= 1:
            out.append("Yes")
            continue
        if d == 0:
            # Roads of length 0 can only join a city to itself.
            out.append("No")
            continue
        # Roads of length d form a single cycle over Z_P (P is prime), so the
        # chosen cities are connected iff they form one contiguous arc of that
        # cycle, i.e. exactly k-1 cities x have x+d also chosen.
        adj = 0
        for x in s:
            if (x + d) % P in s:
                adj += 1
        out.append("Yes" if adj == k - 1 else "No")
    sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
