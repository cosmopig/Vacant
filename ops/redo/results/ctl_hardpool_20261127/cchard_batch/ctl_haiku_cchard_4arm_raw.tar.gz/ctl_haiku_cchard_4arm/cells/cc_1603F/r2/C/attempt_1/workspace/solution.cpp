#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long ull;
static const ull MOD = 998244353ULL;

static ull pw(ull b, ull e) {
    b %= MOD;
    ull r = 1;
    while (e) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    vector<long long> N(t), K(t), X(t);
    long long maxK = 0;
    for (int i = 0; i < t; i++) {
        cin >> N[i] >> K[i] >> X[i];
        maxK = max(maxK, K[i]);
    }

    // p2[m] = 2^m mod p, F[m] = prod_{l=1}^m (2^l - 1), invF[m] = 1/F[m]
    // Gaussian binomial [k choose i]_2 = F[k] / (F[i] F[k-i]).
    vector<uint32_t> p2(maxK + 1), F(maxK + 1), invF(maxK + 1);
    p2[0] = 1;
    F[0] = 1;
    for (long long m = 1; m <= maxK; m++) {
        p2[m] = (uint32_t)((ull)p2[m - 1] * 2 % MOD);
        F[m] = (uint32_t)((ull)F[m - 1] * ((p2[m] + MOD - 1) % MOD) % MOD);
    }
    invF[maxK] = (uint32_t)pw(F[maxK], MOD - 2);
    for (long long m = maxK; m >= 1; m--) {
        invF[m - 1] = (uint32_t)((ull)invF[m] * ((p2[m] + MOD - 1) % MOD) % MOD);
    }

    string out;
    for (int tc = 0; tc < t; tc++) {
        long long n = N[tc], k = K[tc], x = X[tc];
        ull ans = 0;
        if (x == 0) {
            // Need n linearly independent vectors in F_2^k.
            if (n > k) {
                ans = 0;
            } else {
                ans = 1;
                ull p2k = p2[k];
                for (long long j = 0; j < n; j++) {
                    ull term = (p2k + MOD - p2[j]) % MOD;
                    ans = ans * term % MOD;
                }
            }
        } else {
            // Sum over dimension i of subspaces V not containing x,
            // times number of n-tuples spanning exactly V.
            long long m = min(n, k);
            ull pn = pw(2, (ull)n);
            ull P = 1;  // prod_{j<i} (2^n - 2^j)
            ull Fk = F[k];
            ull Fk1 = (k >= 1) ? F[k - 1] : 0;
            for (long long i = 0; i <= m; i++) {
                ull c = Fk * invF[i] % MOD * invF[k - i] % MOD;
                if (i >= 1) {
                    ull sub = Fk1 * invF[i - 1] % MOD * invF[k - i] % MOD;
                    c = (c + MOD - sub) % MOD;
                }
                ans = (ans + c * P) % MOD;
                P = P * ((pn + MOD - p2[i]) % MOD) % MOD;
            }
        }
        out += to_string(ans);
        out += '\n';
    }
    cout << out;
    return 0;
}
