// Count strings over the first k letters admitting a palindromic Hamiltonian path.
// A string is good iff its vertices split into letter classes; the path's mirror pairs
// (p_i, p_{n+1-i}) must share a letter, so every class has even size. We enumerate the
// partitions of the vertex set into even-sized blocks (each block = one letter class, at most k
// blocks), test each partition for a palindromic Hamiltonian path, and add the number of
// injective letter assignments k*(k-1)*...*(k-b+1).
#include <bits/stdc++.h>
using namespace std;

static int n, m, k;
static int adjm[12];
static int sb[12];                 // block mask containing each vertex
static int blocks[12], nb;         // current partition
static uint16_t reach[4096][12];   // reach[mask][l] = bitmask of r values
static unsigned stamp[4096];
static unsigned curStamp = 0;
static long long total = 0;

static int work[1 << 20];
static bool inWork[4096];

// Worklist fixpoint over masks: reach[mask][l] only grows, so re-processing a mask when it
// gains bits is safe. Returns as soon as a state with the full mask is reached.
static bool good() {
    ++curStamp;
    int full = (1 << n) - 1;
    int top = 0;
    auto touch = [&](int mask, int l, int r) -> bool {
        if (stamp[mask] != curStamp) {
            stamp[mask] = curStamp;
            memset(reach[mask], 0, sizeof(reach[mask]));
            inWork[mask] = false;
        }
        uint16_t bit = (uint16_t)(1 << r);
        if (reach[mask][l] & bit) return false;
        reach[mask][l] |= bit;
        if (mask != full && !inWork[mask]) { inWork[mask] = true; work[top++] = mask; }
        return mask == full;
    };
    for (int x = 0; x < n; x++)
        for (int y = 0; y < n; y++) {
            if (x == y || !((adjm[x] >> y) & 1) || !((sb[x] >> y) & 1)) continue;
            if (touch((1 << x) | (1 << y), x, y)) return true;
        }
    while (top > 0) {
        int mask = work[--top];
        inWork[mask] = false;
        for (int l = 0; l < n; l++) {
            int R = reach[mask][l];
            if (!R) continue;
            int cand = adjm[l] & ~mask;
            while (cand) {
                int u = __builtin_ctz(cand); cand &= cand - 1;
                int ws = sb[u] & ~mask & ~(1 << u);
                while (ws) {
                    int w = __builtin_ctz(ws); ws &= ws - 1;
                    if (!(adjm[w] & R)) continue;   // need some r in R adjacent to w
                    if (touch(mask | (1 << u) | (1 << w), u, w)) return true;
                }
            }
        }
    }
    return false;
}

static void rec(int rem) {
    if (rem == 0) {
        if (good()) {
            long long f = 1;
            for (int i = 0; i < nb; i++) f *= (k - i);
            total += f;
        }
        return;
    }
    int v = __builtin_ctz(rem);
    int rest = rem & ~(1 << v);
    // choose sub of rest with odd popcount -> block size even
    for (int sub = rest; ; sub = (sub - 1) & rest) {
        if (__builtin_popcount(sub) % 2 == 1) {
            int blk = sub | (1 << v);
            if (nb + 1 <= k) {
                for (int i = 0; i < n; i++) if ((blk >> i) & 1) sb[i] = blk;
                blocks[nb++] = blk;
                rec(rem & ~blk);
                nb--;
            }
        }
        if (sub == 0) break;
    }
}

int main() {
    if (scanf("%d %d %d", &n, &m, &k) != 3) return 0;
    for (int i = 0; i < m; i++) {
        int a, b;
        if (scanf("%d %d", &a, &b) != 2) break;
        a--; b--;
        if (a < 0 || b < 0 || a >= n || b >= n || a == b) continue;
        adjm[a] |= 1 << b;
        adjm[b] |= 1 << a;
    }
    // A palindromic Hamiltonian path is in particular a Hamiltonian path of the graph.
    // If there is none, the answer is 0 and the partition search can be skipped.
    {
        static uint16_t ham[4096];   // ham[mask] = bitmask of end vertices of Hamiltonian paths on mask
        for (int v = 0; v < n; v++) ham[1 << v] |= (uint16_t)(1 << v);
        for (int mask = 1; mask < (1 << n); mask++) {
            int ends = ham[mask];
            while (ends) {
                int v = __builtin_ctz(ends); ends &= ends - 1;
                int cand = adjm[v] & ~mask;
                while (cand) {
                    int u = __builtin_ctz(cand); cand &= cand - 1;
                    ham[mask | (1 << u)] |= (uint16_t)(1 << u);
                }
            }
        }
        if (!ham[(1 << n) - 1]) { printf("0\n"); return 0; }
    }
    rec((1 << n) - 1);
    printf("%lld\n", total);
    return 0;
}
