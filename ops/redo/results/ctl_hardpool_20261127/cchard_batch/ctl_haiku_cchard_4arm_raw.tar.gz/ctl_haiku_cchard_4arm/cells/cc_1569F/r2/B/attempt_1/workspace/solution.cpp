// Palindromic Hamiltonian path: count good letter strings.
//
// A palindromic Hamiltonian path p_1..p_n is a "ladder": h = n/2 columns
// (a_i, b_i) with a_i = p_i, b_i = p_{n+1-i}, where a_i~a_{i+1}, b_i~b_{i+1},
// a_h~b_h, and each column must carry the same letter.
//
// Step 1: enumerate perfect matchings M of the vertex set (columns) and keep
//         those admitting a ladder ordering (DP over subsets of columns).
// Step 2: a string is determined by its letter-class partition pi of the
//         vertices. The string is good iff some M in F has every pair of M
//         inside one block of pi. Enumerate all set partitions with at most k
//         blocks, all blocks of even size, and test against F with 128-bit masks.
// Step 3: each good partition with b blocks contributes k(k-1)...(k-b+1).
#include <bits/stdc++.h>
using namespace std;
typedef unsigned __int128 u128;

static int n, m, k;
static int adjm[12];
static u128 pbit[12][12];
static vector<u128> F;
static long long fallf[13];
static long long ans = 0;
static int a[12];

static bool ladderOK(const vector<pair<int, int>>& cols) {
    int h = (int)cols.size();
    int full = (1 << h) - 1;
    // R[S][x] = bitmask of y such that state (a-end = x, b-end = y) is reachable
    // after placing the columns in S.
    static uint16_t R[64][12];
    for (int s = 0; s <= full; s++)
        for (int x = 0; x < 12; x++) R[s][x] = 0;
    for (int c = 0; c < h; c++) {
        int p = cols[c].first, q = cols[c].second;
        R[1 << c][p] |= (uint16_t)(1 << q);
        R[1 << c][q] |= (uint16_t)(1 << p);
    }
    for (int s = 1; s <= full; s++) {
        for (int c = 0; c < h; c++) {
            if (s >> c & 1) continue;
            int ns = s | (1 << c);
            for (int o = 0; o < 2; o++) {
                int u = o ? cols[c].second : cols[c].first;
                int v = o ? cols[c].first : cols[c].second;
                bool ok = false;
                for (int x = 0; x < n && !ok; x++) {
                    if ((adjm[u] >> x & 1) && (R[s][x] & adjm[v])) ok = true;
                }
                if (ok) R[ns][u] |= (uint16_t)(1 << v);
            }
        }
    }
    for (int x = 0; x < n; x++)
        if (R[full][x] & adjm[x]) return true;
    return false;
}

static vector<pair<int, int>> cols;

static void genM(int used, u128 cur) {
    if (used == (1 << n) - 1) {
        if (ladderOK(cols)) F.push_back(cur);
        return;
    }
    int v = 0;
    while (used >> v & 1) v++;
    for (int u = v + 1; u < n; u++) {
        if (used >> u & 1) continue;
        cols.push_back({v, u});
        genM(used | (1 << v) | (1 << u), cur | pbit[v][u]);
        cols.pop_back();
    }
}

static void rec(int i, int nb, u128 P) {
    if (i == n) {
        int cnt[12] = {0};
        for (int j = 0; j < n; j++) cnt[a[j]]++;
        for (int b = 0; b < nb; b++)
            if (cnt[b] & 1) return;
        for (const u128& M : F) {
            if ((M & ~P) == 0) {
                ans += fallf[nb];
                return;
            }
        }
        return;
    }
    int top = min(nb, k - 1);
    for (int b = 0; b <= top; b++) {
        a[i] = b;
        u128 Q = P;
        for (int j = 0; j < i; j++)
            if (a[j] == b) Q |= pbit[j][i];
        rec(i + 1, b == nb ? nb + 1 : nb, Q);
    }
}

int main() {
    if (scanf("%d %d %d", &n, &m, &k) != 3) return 0;
    for (int i = 0; i < m; i++) {
        int v, u;
        scanf("%d %d", &v, &u);
        v--; u--;
        adjm[v] |= 1 << u;
        adjm[u] |= 1 << v;
    }
    int id = 0;
    for (int i = 0; i < n; i++)
        for (int j = i + 1; j < n; j++) {
            pbit[i][j] = pbit[j][i] = ((u128)1) << id;
            id++;
        }
    fallf[0] = 1;
    for (int b = 1; b <= 12; b++)
        fallf[b] = (b <= k) ? fallf[b - 1] * (k - b + 1) : 0;

    genM(0, 0);
    if (F.empty()) {
        printf("0\n");
        return 0;
    }
    a[0] = 0;
    rec(1, 1, 0);
    printf("%lld\n", ans);
    return 0;
}
