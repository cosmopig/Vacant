import sys

MOD = 10 ** 9 + 7


def fib_pair(n):
    """Return (F(n), F(n+1)) mod MOD using fast doubling."""
    a, b = 0, 1  # F(0), F(1)
    for bit in bin(n)[2:]:
        # Doubling step: (F(k), F(k+1)) -> (F(2k), F(2k+1))
        c = a * ((2 * b - a) % MOD) % MOD
        d = (a * a + b * b) % MOD
        if bit == "1":
            a, b = d, (c + d) % MOD
        else:
            a, b = c, d
    return a


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); q = int(data[pos + 1]); pos += 2
    arr = [None, [int(x) for x in data[pos:pos + n]], None]
    pos += n
    arr[2] = [int(x) for x in data[pos:pos + n]]
    pos += n
    a1 = arr[1]
    a2 = arr[2]
    out = []
    for _ in range(q):
        t = int(data[pos])
        if t == 4:
            l = int(data[pos + 1]) - 1
            r = int(data[pos + 2])
            pos += 3
            total = 0
            for i in range(l, r):
                total += fib_pair(a1[i] + a2[i])
            out.append(total % MOD)
        else:
            k = int(data[pos + 1])
            l = int(data[pos + 2]) - 1
            r = int(data[pos + 3])
            x = int(data[pos + 4])
            pos += 5
            a = a1 if k == 1 else a2
            if t == 1:
                for i in range(l, r):
                    if a[i] > x:
                        a[i] = x
            elif t == 2:
                for i in range(l, r):
                    if a[i] < x:
                        a[i] = x
            else:
                for i in range(l, r):
                    a[i] += x
    sys.stdout.write("\n".join(map(str, out)) + ("\n" if out else ""))


main()
