#include <bits/stdc++.h>
using namespace std;

// For a start index L, the path of [L, r] is integer iff, for every prime p,
// the prefix exponent sum never drops below its value at L. Let bad(L) be the
// first r where this fails; the answer is sum over L of (bad(L) - L).
// For each prime, the exponent sums change only at positions holding a
// multiple of p, so "next smaller" over those events gives a range of L's
// with a candidate bad position. Candidates are combined with a range-chmin
// segment tree (point query at the end).

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;
    vector<int> a(n);
    for (auto &x : a) cin >> x;
    string b;
    cin >> b;

    const int MAXV = 1000000;
    vector<int> spf(MAXV + 1, 0);
    for (int i = 2; i <= MAXV; i++) {
        if (spf[i] == 0) {
            for (long long j = i; j <= MAXV; j += i)
                if (spf[j] == 0) spf[j] = i;
        }
    }

    // events[p]: (position, signed exponent change) for prime p.
    vector<vector<pair<int, int>>> events(MAXV + 1);
    for (int j = 0; j < n; j++) {
        int x = a[j];
        int s = (b[j] == '*') ? 1 : -1;
        while (x > 1) {
            int p = spf[x];
            int c = 0;
            while (x % p == 0) {
                x /= p;
                c++;
            }
            events[p].push_back({j, s * c});
        }
    }

    // Range-chmin / point-query segment tree over indices 0..n-1.
    // Initial value n means "no failure before the end".
    const int N = n;
    vector<int> t(2 * N, n);
    auto update = [&](int l, int r, int v) {  // inclusive [l, r]
        for (l += N, r += N + 1; l < r; l >>= 1, r >>= 1) {
            if (l & 1) {
                t[l] = min(t[l], v);
                l++;
            }
            if (r & 1) {
                --r;
                t[r] = min(t[r], v);
            }
        }
    };

    for (int p = 2; p <= MAXV; p++) {
        auto &ev = events[p];
        if (ev.empty()) continue;
        int m = (int)ev.size();
        // V[0] = 0 before any event; V[k] = exponent sum after the k-th event.
        vector<long long> V(m + 1, 0);
        for (int k = 1; k <= m; k++) V[k] = V[k - 1] + ev[k - 1].second;

        // Next strictly smaller value to the right, over indices 0..m.
        vector<int> st;
        st.reserve(m + 1);
        for (int k = m; k >= 0; k--) {
            while (!st.empty() && V[st.back()] >= V[k]) st.pop_back();
            if (!st.empty()) {
                int s = st.back();
                int failPos = ev[s - 1].first;  // position of event s
                int lo = (k == 0) ? 0 : ev[k - 1].first + 1;
                int hi = (k == m) ? n - 1 : ev[k].first;
                if (hi > n - 1) hi = n - 1;
                if (lo <= hi) update(lo, hi, failPos);
            }
            st.push_back(k);
        }
        vector<pair<int, int>>().swap(ev);  // free memory
    }

    // Point query: min over ancestors of leaf.
    long long ans = 0;
    for (int L = 0; L < n; L++) {
        int best = n;
        for (int i = L + N; i >= 1; i >>= 1) best = min(best, t[i]);
        ans += best - L;
    }
    cout << ans << "\n";
    return 0;
}
