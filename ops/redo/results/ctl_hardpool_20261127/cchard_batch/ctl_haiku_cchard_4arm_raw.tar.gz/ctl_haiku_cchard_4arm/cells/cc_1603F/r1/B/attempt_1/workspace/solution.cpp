// Count n-tuples over GF(2)^k whose span avoids a fixed nonzero x (or, for x = 0,
// tuples that are linearly independent).
//
// x = 0:  answer = prod_{i=0}^{n-1} (2^k - 2^i)   (0 if n > k)
// x != 0: answer = sum_{j=0}^{k-1} [k-1 choose j]_2 * 2^{j(n+1)} * prod_{t=1}^{k-1-j} (1 - 2^t)
// The second formula does not depend on x (GL(k,2) acts transitively on nonzero vectors).
#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long ull;
typedef unsigned int u32;
static const ull MOD = 998244353ULL;

static ull power(ull b, ull e) {
    b %= MOD;
    ull r = 1;
    while (e) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    vector<long long> N(t), K(t), X(t);
    long long maxK = 1;
    for (int i = 0; i < t; i++) {
        cin >> N[i] >> K[i] >> X[i];
        maxK = max(maxK, K[i]);
    }

    // F[m] = prod_{s=1}^{m} (2^s - 1)           (q-factorial)
    // iF[m] = 1 / F[m]
    // G[L] = prod_{s=1}^{L} (1 - 2^s)
    // Only needed when some test has x != 0 (for F, iF, G); precompute up to maxK-1.
    bool needTables = false;
    for (int i = 0; i < t; i++)
        if (X[i] != 0) needTables = true;

    vector<u32> F, iF, G;
    if (needTables) {
        size_t M = (size_t)maxK; // indices 0..maxK-1 are used, allocate maxK+1 to be safe
        F.assign(M + 1, 0);
        iF.assign(M + 1, 0);
        G.assign(M + 1, 0);
        vector<u32> D(M + 1, 0); // D[s] = 2^s - 1
        ull p2 = 1;
        F[0] = 1;
        G[0] = 1;
        D[0] = 0;
        for (size_t s = 1; s <= M; s++) {
            p2 = p2 * 2 % MOD;
            D[s] = (u32)((p2 + MOD - 1) % MOD);
            F[s] = (u32)((ull)F[s - 1] * D[s] % MOD);
            G[s] = (u32)((ull)G[s - 1] * ((1 + MOD - p2) % MOD) % MOD);
        }
        iF[M] = (u32)power(F[M], MOD - 2);
        for (size_t s = M; s >= 1; s--) {
            iF[s - 1] = (u32)((ull)iF[s] * D[s] % MOD);
        }
    }

    string out;
    out.reserve((size_t)t * 12);
    for (int i = 0; i < t; i++) {
        long long n = N[i], k = K[i], x = X[i];
        ull ans = 0;
        if (x == 0) {
            if (n > k) {
                ans = 0;
            } else {
                ull pk = power(2, (ull)k);
                ull cur = 1; // 2^i
                ans = 1;
                for (long long j = 0; j < n; j++) {
                    ans = ans * ((pk + MOD - cur) % MOD) % MOD;
                    cur = cur * 2 % MOD;
                }
            }
        } else {
            // k >= 1 here, since x < 2^min(20,k) and x != 0.
            long long Nk = k - 1;
            ull base = power(2, (ull)(n + 1)); // 2^{n+1}
            ull cur = 1;                       // base^j
            ull FN = F[Nk];
            for (long long j = 0; j <= Nk; j++) {
                ull binom = FN * iF[j] % MOD * iF[Nk - j] % MOD;
                ull term = binom * cur % MOD * G[Nk - j] % MOD;
                ans += term;
                if (ans >= MOD) ans -= MOD;
                cur = cur * base % MOD;
            }
        }
        out += to_string(ans);
        out += '\n';
    }
    cout << out;
    return 0;
}
