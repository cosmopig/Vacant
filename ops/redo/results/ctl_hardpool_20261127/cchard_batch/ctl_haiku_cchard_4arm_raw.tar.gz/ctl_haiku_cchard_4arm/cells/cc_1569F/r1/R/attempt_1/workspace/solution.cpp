// Palindromic Hamiltonian Path: count good strings.
//
// Idea:
//  * A palindromic Hamiltonian path is a_1..a_h, b_h..b_1 (h = n/2) with
//    a_i~a_{i+1}, b_i~b_{i+1}, a_h~b_h, and letter(a_i) = letter(b_i).
//    So a string is good iff its letter partition P (set partition of the
//    vertices into equal-letter classes) contains a "realizable" perfect
//    matching M (every pair of M lies inside one block of P).
//  * Enumerate all perfect matchings M of the n vertices (<= 10395), keep the
//    realizable ones R (checked by a subset DP over pairs).
//  * Enumerate set partitions P by restricted growth strings, maintaining the
//    bitset of matchings in R still compatible with P. Each pair (u,v), u<v, is
//    checked when v is placed. Prune when no matching remains. At leaves, add
//    falling_factorial(k, #blocks) since a partition with b blocks corresponds
//    to k(k-1)...(k-b+1) strings.
#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long u64;

int n, m, K;
bool adj[12][12];
int W;                       // number of 64-bit words for the matching bitset
vector<vector<int>> R;       // realizable matchings: partner arrays
vector<vector<vector<u64>>> tab;  // tab[v][S] = bitset of compatible matchings (S subset of [0,v))
u64 ff[14];
long long ans = 0;
vector<u64> cur[14];
int blockMask[14];

// Check whether matching (given as list of pairs) admits a palindromic Hamiltonian path.
bool realizable(const vector<pair<int,int>>& pr) {
    int h = pr.size();
    // A[p][o], B[p][o]: a-end and b-end vertices when pair p is placed with orientation o.
    int A[6][2], Bv[6][2];
    for (int p = 0; p < h; p++) {
        A[p][0] = pr[p].first;  Bv[p][0] = pr[p].second;
        A[p][1] = pr[p].second; Bv[p][1] = pr[p].first;
    }
    int full = (1 << h) - 1;
    // reach[mask][p][o]: chain covering pairs in mask ending with pair p (orientation o)
    static bool reach[1 << 6][6][2];
    for (int mask = 0; mask <= full; mask++)
        for (int p = 0; p < h; p++)
            reach[mask][p][0] = reach[mask][p][1] = false;
    for (int p = 0; p < h; p++)
        for (int o = 0; o < 2; o++)
            reach[1 << p][p][o] = true;
    for (int mask = 1; mask <= full; mask++) {
        for (int p = 0; p < h; p++) {
            if (!(mask >> p & 1)) continue;
            for (int o = 0; o < 2; o++) {
                if (!reach[mask][p][o]) continue;
                int a = A[p][o], b = Bv[p][o];
                for (int q = 0; q < h; q++) {
                    if (mask >> q & 1) continue;
                    for (int o2 = 0; o2 < 2; o2++) {
                        if (adj[a][A[q][o2]] && adj[b][Bv[q][o2]])
                            reach[mask | (1 << q)][q][o2] = true;
                    }
                }
            }
        }
    }
    for (int p = 0; p < h; p++)
        for (int o = 0; o < 2; o++)
            if (reach[full][p][o] && adj[A[p][o]][Bv[p][o]]) return true;
    return false;
}

void enumMatchings(int used, vector<int>& partner, vector<pair<int,int>>& pr) {
    int v = -1;
    for (int i = 0; i < n; i++) if (!(used >> i & 1)) { v = i; break; }
    if (v < 0) {
        if (realizable(pr)) {
            R.push_back(partner);
        }
        return;
    }
    for (int u = v + 1; u < n; u++) {
        if (used >> u & 1) continue;
        partner[v] = u; partner[u] = v;
        pr.push_back({v, u});
        enumMatchings(used | (1 << v) | (1 << u), partner, pr);
        pr.pop_back();
    }
}

void dfs(int v, int nb) {
    if (v == n) {
        ans += (long long)ff[nb];
        return;
    }
    // Join an existing block.
    for (int b = 0; b < nb; b++) {
        int S = blockMask[b];
        const vector<u64>& T = tab[v][S];
        bool nz = false;
        for (int w = 0; w < W; w++) {
            cur[v + 1][w] = cur[v][w] & T[w];
            if (cur[v + 1][w]) nz = true;
        }
        if (!nz) continue;
        blockMask[b] |= 1 << v;
        dfs(v + 1, nb);
        blockMask[b] ^= 1 << v;
    }
    // Start a new block.
    {
        const vector<u64>& T = tab[v][0];
        bool nz = false;
        for (int w = 0; w < W; w++) {
            cur[v + 1][w] = cur[v][w] & T[w];
            if (cur[v + 1][w]) nz = true;
        }
        if (nz) {
            blockMask[nb] = 1 << v;
            dfs(v + 1, nb + 1);
            blockMask[nb] = 0;
        }
    }
}

int main() {
    scanf("%d %d %d", &n, &m, &K);
    for (int i = 0; i < m; i++) {
        int a, b;
        scanf("%d %d", &a, &b);
        a--; b--;
        if (a == b || a < 0 || b < 0 || a >= n || b >= n) continue;
        adj[a][b] = adj[b][a] = true;
    }
    // falling factorials
    for (int b = 0; b <= 13; b++) {
        if (b > K) { ff[b] = 0; continue; }
        u64 r = 1;
        for (int i = 0; i < b; i++) r *= (u64)(K - i);
        ff[b] = r;
    }

    vector<int> partner(n, -1);
    vector<pair<int,int>> pr;
    enumMatchings(0, partner, pr);

    int X = R.size();
    W = max(1, (X + 63) / 64);
    if (X == 0) {
        printf("0\n");
        return 0;
    }

    // Build per-vertex bitsets: Wv[v] = matchings with partner > v,
    // Q[v][u] = matchings with partner(v) = u (u < v).
    tab.assign(n, {});
    for (int v = 0; v < n; v++) {
        vector<vector<u64>> Q(v, vector<u64>(W, 0));
        vector<u64> Wv(W, 0);
        for (int i = 0; i < X; i++) {
            int u = R[i][v];
            if (u > v) Wv[i >> 6] |= 1ULL << (i & 63);
            else Q[u][i >> 6] |= 1ULL << (i & 63);
        }
        int sz = 1 << v;
        tab[v].assign(sz, vector<u64>(W, 0));
        tab[v][0] = Wv;
        for (int S = 1; S < sz; S++) {
            int low = S & -S;
            int u = __builtin_ctz(S);
            for (int w = 0; w < W; w++)
                tab[v][S][w] = tab[v][S ^ low][w] | Q[u][w];
        }
    }

    for (int l = 0; l <= n; l++) cur[l].assign(W, 0);
    for (int i = 0; i < X; i++) cur[0][i >> 6] |= 1ULL << (i & 63);
    for (int b = 0; b < 14; b++) blockMask[b] = 0;

    dfs(0, 0);
    printf("%lld\n", ans);
    return 0;
}
