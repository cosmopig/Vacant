// Phys Ed Online.
// For a student visiting [l, r], the greedy is optimal: a ticket must be activated at l (cost a_l),
// and whenever the current ticket expires at day c+1 <= r, activate a new one exactly at day c+1.
// Activating at day t costs min(a[l..t]) (buy at the cheapest day in [l, t]); activating later is
// never worse in cost, so the activation days are l, l+k, l+2k, ... (all <= r).
// Answer = sum over those days t of min(a[l..t]), computed with a sparse table for O(1) range minima.
#include <bits/stdc++.h>
using namespace std;

static char buf[1 << 25];

int main() {
    size_t len = fread(buf, 1, sizeof(buf) - 1, stdin);
    buf[len] = 0;
    char* p = buf;
    auto readInt = [&]() -> long long {
        while (*p && (*p < '0' || *p > '9') && *p != '-') ++p;
        bool neg = false;
        if (*p == '-') { neg = true; ++p; }
        long long x = 0;
        while (*p >= '0' && *p <= '9') { x = x * 10 + (*p - '0'); ++p; }
        return neg ? -x : x;
    };

    int n = (int)readInt();
    int q = (int)readInt();
    int k = (int)readInt();

    vector<long long> a(n + 1);
    for (int i = 1; i <= n; ++i) a[i] = readInt();

    // Sparse table over 1..n for range minimum.
    int LOG = 1;
    while ((1 << LOG) <= n) ++LOG;
    vector<vector<long long>> sp(LOG, vector<long long>(n + 1));
    sp[0] = a;
    for (int j = 1; j < LOG; ++j)
        for (int i = 1; i + (1 << j) - 1 <= n; ++i)
            sp[j][i] = min(sp[j - 1][i], sp[j - 1][i + (1 << (j - 1))]);
    vector<int> lg(n + 2, 0);
    for (int i = 2; i <= n + 1; ++i) lg[i] = lg[i / 2] + 1;

    auto rmq = [&](int l, int r) -> long long {
        int j = lg[r - l + 1];
        return min(sp[j][l], sp[j][r - (1 << j) + 1]);
    };

    string out;
    out.reserve((size_t)q * 16);
    char tmp[32];
    for (int i = 0; i < q; ++i) {
        int l = (int)readInt();
        int r = (int)readInt();
        long long cost = 0;
        for (int t = l; t <= r; t += k) cost += rmq(l, t);
        int m = snprintf(tmp, sizeof(tmp), "%lld\n", cost);
        out.append(tmp, m);
    }
    fwrite(out.data(), 1, out.size(), stdout);
    return 0;
}
