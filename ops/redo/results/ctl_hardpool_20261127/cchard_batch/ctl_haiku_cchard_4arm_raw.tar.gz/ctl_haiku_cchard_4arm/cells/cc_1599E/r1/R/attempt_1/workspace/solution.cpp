// Two Arrays: range min/max/add updates on A1 and A2, range sum of F(A1_i + A2_i) mod 1e9+7.
// Approach: direct per-element updates; F(s) cached per element and recomputed lazily (dirty flag)
// via fast doubling only when a type-4 query reads it. Worst case O(N*Q) element operations.
#include <bits/stdc++.h>
using namespace std;

static const long long MOD = 1000000007LL;

// Returns F(n) mod MOD using fast doubling. n may be up to ~1e11.
static long long fibmod(long long n) {
    long long a = 0, b = 1;  // (F(k), F(k+1)) with k = 0
    for (int bit = 62; bit >= 0; --bit) {
        // doubling: k -> 2k
        long long t = ((2 * b - a) % MOD + MOD) % MOD;
        long long c = a * t % MOD;                 // F(2k)
        long long d = (a * a % MOD + b * b % MOD) % MOD;  // F(2k+1)
        if ((n >> bit) & 1LL) {
            a = d;
            b = (c + d) % MOD;                     // k -> 2k+1
        } else {
            a = c;
            b = d;
        }
    }
    return a;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, q;
    if (!(cin >> n >> q)) return 0;
    vector<long long> A1(n + 1), A2(n + 1);
    for (int i = 1; i <= n; ++i) cin >> A1[i];
    for (int i = 1; i <= n; ++i) cin >> A2[i];

    vector<long long> fv(n + 1, 0);
    vector<char> dirty(n + 1, 1);

    string out;
    out.reserve(static_cast<size_t>(q) * 12);

    for (int qi = 0; qi < q; ++qi) {
        int type;
        cin >> type;
        if (type == 4) {
            int l, r;
            cin >> l >> r;
            long long sum = 0;
            for (int i = l; i <= r; ++i) {
                if (dirty[i]) {
                    fv[i] = fibmod(A1[i] + A2[i]);
                    dirty[i] = 0;
                }
                sum += fv[i];
            }
            sum %= MOD;
            out += to_string(sum);
            out += '\n';
        } else {
            int k, l, r;
            long long x;
            cin >> k >> l >> r >> x;
            vector<long long>& A = (k == 1) ? A1 : A2;
            for (int i = l; i <= r; ++i) {
                if (type == 1) {
                    A[i] = min(A[i], x);
                } else if (type == 2) {
                    A[i] = max(A[i], x);
                } else {
                    A[i] += x;
                }
                dirty[i] = 1;
            }
        }
    }
    cout << out;
    return 0;
}
