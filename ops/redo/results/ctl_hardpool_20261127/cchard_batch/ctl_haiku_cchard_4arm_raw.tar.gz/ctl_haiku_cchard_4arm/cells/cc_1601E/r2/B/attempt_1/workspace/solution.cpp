// Phys Ed Online.
// Cost of student [l, r] = sum over t = l, l+k, l+2k, ..., <= r of min(a[l..t]).
// (Each ticket activation point t_i = l + i*k; buy at the cheapest day in [l, t_i].)
//
// Two regimes:
//  * k large (> S): each query has at most n/k+1 terms; sum them with a sparse table.
//  * k small (<= S): for each residue class c = l mod k, sweep l from n down to 1
//    maintaining the monotone stack of pieces of M(l, .). Each stack entry stores the
//    cumulative sum of value * (#class-c positions in its span), so a query is a
//    binary search plus O(1) arithmetic.
#include <bits/stdc++.h>
using namespace std;

static const int S = 400;

static char buf[1 << 25];
int bufpos = 0, buflen = 0;
inline int gc() {
    if (bufpos == buflen) {
        buflen = (int)fread(buf, 1, sizeof(buf), stdin);
        bufpos = 0;
        if (buflen <= 0) return -1;
    }
    return buf[bufpos++];
}
inline long long readInt() {
    int c = gc();
    while (c != '-' && (c < '0' || c > '9')) c = gc();
    bool neg = false;
    if (c == '-') { neg = true; c = gc(); }
    long long x = 0;
    while (c >= '0' && c <= '9') { x = x * 10 + (c - '0'); c = gc(); }
    return neg ? -x : x;
}

int n, q, k;
vector<long long> a;  // 1-indexed

int main() {
    n = (int)readInt();
    q = (int)readInt();
    k = (int)readInt();
    a.assign(n + 2, 0);
    for (int i = 1; i <= n; i++) a[i] = readInt();
    vector<int> ql(q), qr(q);
    for (int i = 0; i < q; i++) {
        ql[i] = (int)readInt();
        qr[i] = (int)readInt();
    }
    vector<long long> ans(q, 0);

    if (k > S) {
        // Sparse table for range minimum.
        int LOG = 1;
        while ((1 << LOG) <= n) LOG++;
        vector<vector<long long>> sp(LOG, vector<long long>(n + 2));
        for (int i = 1; i <= n; i++) sp[0][i] = a[i];
        for (int j = 1; j < LOG; j++)
            for (int i = 1; i + (1 << j) - 1 <= n; i++)
                sp[j][i] = min(sp[j - 1][i], sp[j - 1][i + (1 << (j - 1))]);
        vector<int> lg(n + 2, 0);
        for (int i = 2; i <= n + 1; i++) lg[i] = lg[i / 2] + 1;
        auto rmq = [&](int lo, int hi) {  // inclusive, lo <= hi
            int j = lg[hi - lo + 1];
            return min(sp[j][lo], sp[j][hi - (1 << j) + 1]);
        };
        for (int i = 0; i < q; i++) {
            int l = ql[i], r = qr[i];
            long long cur = a[l];
            long long total = cur;
            int prev = l;
            for (int t = l + k; t <= r; t += k) {
                cur = min(cur, rmq(prev + 1, t));
                total += cur;
                prev = t;
            }
            ans[i] = total;
        }
    } else {
        // Group queries by l.
        vector<vector<int>> byL(n + 2);
        for (int i = 0; i < q; i++) byL[ql[i]].push_back(i);
        // Which residue classes have queries?
        vector<char> need(k, 0);
        for (int i = 0; i < q; i++) need[ql[i] % k] = 1;

        vector<int> sx(n + 2), sy(n + 2);
        vector<long long> sv(n + 2), scum(n + 2);
        for (int c = 0; c < k; c++) {
            if (!need[c]) continue;
            // cntUpTo(y): #t in [0, y] with t % k == c.
            auto cntUpTo = [&](long long y) -> long long {
                if (y < c) return 0;
                return (y - c) / k + 1;
            };
            int top = -1;  // stack index of top (leftmost piece)
            for (int l = n; l >= 1; l--) {
                int y = l;
                while (top >= 0 && sv[top] >= a[l]) {
                    y = sy[top];
                    top--;
                }
                long long below = (top >= 0) ? scum[top] : 0;
                long long cnt = cntUpTo(y) - cntUpTo(l - 1);
                ++top;
                sx[top] = l;
                sy[top] = y;
                sv[top] = a[l];
                scum[top] = below + a[l] * cnt;

                if (l % k != c) continue;
                for (int qi : byL[l]) {
                    int r = qr[qi];
                    // Smallest index j in [0, top] with sx[j] <= r (sx decreasing in index).
                    int lo = 0, hi = top;
                    while (lo < hi) {
                        int mid = (lo + hi) / 2;
                        if (sx[mid] <= r) hi = mid;
                        else lo = mid + 1;
                    }
                    int j = lo;
                    long long res = scum[top] - scum[j];
                    long long partial = cntUpTo(r) - cntUpTo(sx[j] - 1);
                    res += sv[j] * partial;
                    ans[qi] = res;
                }
            }
        }
    }

    // Output.
    string out;
    out.reserve((size_t)q * 12);
    for (int i = 0; i < q; i++) {
        out += to_string(ans[i]);
        out += '\n';
    }
    fwrite(out.data(), 1, out.size(), stdout);
    return 0;
}
