#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll MOD = 1000000007LL;

ll power(ll b, ll e) {
    ll r = 1;
    b %= MOD;
    if (b < 0) b += MOD;
    while (e > 0) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, q;
    if (!(cin >> n >> q)) return 0;

    vector<ll> a(n + 1);
    for (int i = 1; i <= n; i++) {
        ll v;
        cin >> v;
        v %= MOD;
        if (v < 0) v += MOD;
        a[i] = v;
    }

    string out;
    out.reserve(q * 4);

    vector<ll> t;
    t.reserve(n);

    for (int qi = 0; qi < q; qi++) {
        ll L, R, D;
        cin >> L >> R >> D;
        if (L > R) swap(L, R);

        // Distinct city positions in [L, R].
        t.clear();
        for (ll i = L; i <= R; i++) t.push_back(a[i]);
        sort(t.begin(), t.end());
        t.erase(unique(t.begin(), t.end()), t.end());
        ll k = (ll)t.size();

        bool ok;
        if (k <= 1) {
            ok = true;
        } else if (D % MOD == 0) {
            // Road length 0 (mod p): only identical cities can be linked.
            ok = false;
        } else {
            // Map cities to positions on the cycle with step D:
            // city x is at position x * D^{-1} mod p; roads join neighbours.
            ll invD = power(D, MOD - 2);
            for (ll i = 0; i < k; i++) t[i] = t[i] * invD % MOD;
            sort(t.begin(), t.end());
            // Count adjacent pairs (x, x+1 mod p) present in the set.
            ll adj = 0;
            for (ll i = 0; i + 1 < k; i++)
                if (t[i + 1] - t[i] == 1) adj++;
            if (t[k - 1] - t[0] == MOD - 1) adj++;  // wrap-around pair
            // A set of k < p points on the cycle is a single arc iff it has k-1 adjacent pairs.
            ok = (adj == k - 1);
        }
        out += ok ? "Yes\n" : "No\n";
    }

    cout << out;
    return 0;
}
