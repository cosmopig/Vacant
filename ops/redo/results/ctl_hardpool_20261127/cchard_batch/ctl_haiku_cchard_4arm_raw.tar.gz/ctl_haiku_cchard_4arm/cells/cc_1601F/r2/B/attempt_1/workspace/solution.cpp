#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef __int128 i128;

static const ll MOD_SUM = 998244353LL;   // M
static const ll MOD_OUT = 1000000007LL;  // output modulus

static ll n;
static int D;                 // number of decimal digits of n
static ll p10[20];

static int digitsOf(ll x) {
    int d = 0;
    while (x > 0) { d++; x /= 10; }
    return d;
}

// pos(x) = number of y in [1, n] whose decimal string is lexicographically <= str(x).
// x must lie in [1, n].
static ll posOf(ll x) {
    int L = digitsOf(x);
    i128 total = 0;
    for (int l = 1; l <= D; l++) {
        i128 lo = p10[l - 1];
        i128 hi;
        if (l <= L) {
            // y of length l is lex <= x iff y <= prefix of x of length l
            i128 pre = (i128)(x / p10[L - l]);
            hi = min((i128)n, pre);
        } else {
            // y of length l is lex <= x iff y < x * 10^(l-L)
            i128 bound = (i128)x * (i128)p10[l - L] - 1;
            hi = min((i128)n, bound);
        }
        if (hi >= lo) total += hi - lo + 1;
    }
    return (ll)total;
}

// g(x) = pos(x) - x. Nondecreasing for x inside one digit-length block.
static ll gOf(ll x) { return posOf(x) - x; }

// Within block [a, b], return the smallest x with g(x) >= T, or b+1 if none.
static ll firstGE(ll a, ll b, ll T) {
    ll lo = a, hi = b + 1;
    while (lo < hi) {
        ll mid = lo + (hi - lo) / 2;
        if (gOf(mid) >= T) hi = mid;
        else lo = mid + 1;
    }
    return lo;
}

int main() {
    if (!(cin >> n)) return 0;

    p10[0] = 1;
    for (int i = 1; i < 20; i++) p10[i] = p10[i - 1] * 10;
    D = digitsOf(n);

    // S = sum_x floor(g(x) / M), with
    // floor(g/M) = sum_{j>=1} [g >= jM] - sum_{j>=0} [g < -jM].
    // Since g(x) is in (-n, n), only j with jM < n matter.
    i128 S = 0;
    for (int L = 1; L <= D; L++) {
        ll a = p10[L - 1];
        ll b = min(n, p10[L] - 1);
        if (a > b) continue;
        ll cnt = b - a + 1;

        for (ll j = 1; j * MOD_SUM < n; j++) {
            ll T = j * MOD_SUM;
            ll f = firstGE(a, b, T);
            S += (i128)((b + 1) - f);          // #{g >= T}
        }
        for (ll j = 0; j * MOD_SUM < n; j++) {
            ll T = -j * MOD_SUM;
            ll f = firstGE(a, b, T);
            S -= (i128)(f - a);                // #{g < T}
        }
        (void)cnt;
    }

    ll Smod = (ll)(S % MOD_OUT);
    if (Smod < 0) Smod += MOD_OUT;
    // answer = (-M * S) mod (1e9+7)
    ll ans = (MOD_SUM % MOD_OUT) * Smod % MOD_OUT;
    ans = (MOD_OUT - ans) % MOD_OUT;
    cout << ans << "\n";
    return 0;
}
