#include <bits/stdc++.h>
using namespace std;

// A segment [l,r] is simple iff for every prime p and every prefix j in [l,r],
// E_p(j) >= E_p(l-1), where E_p(k) is the signed exponent sum of p over a_1..a_k
// ('*' contributes +v_p(a_i), '/' contributes -v_p(a_i)).
// For each start k = l-1 we need f(k) = first j > k where some E_p(j) < E_p(k);
// the number of simple segments starting at l is f(k) - l.
int main() {
    int n;
    if (scanf("%d", &n) != 1) return 0;
    vector<int> a(n + 1);
    for (int i = 1; i <= n; i++) scanf("%d", &a[i]);
    vector<char> b(n + 5);
    scanf("%s", b.data());

    const int MX = 1000001;
    vector<int> spf(MX, 0);
    for (int i = 2; i < MX; i++) {
        if (spf[i] == 0) {
            for (long long j = i; j < MX; j += i)
                if (spf[j] == 0) spf[j] = i;
        }
    }

    // events per prime: (index i, signed exponent delta)
    vector<vector<pair<int, int>>> ev(MX);
    for (int i = 1; i <= n; i++) {
        int x = a[i];
        int s = (b[i - 1] == '*') ? 1 : -1;
        while (x > 1) {
            int p = spf[x];
            int e = 0;
            while (x % p == 0) {
                x /= p;
                e++;
            }
            ev[p].push_back({i, s * e});
        }
    }

    // intervals [lo,hi] of starts k with candidate failure index f
    vector<array<int, 3>> iv;
    vector<int> idx, val, nl, st;
    for (int p = 2; p < MX; p++) {
        if (ev[p].empty()) continue;
        int m = (int)ev[p].size();
        idx.assign(m + 1, 0);
        val.assign(m + 1, 0);
        for (int t = 1; t <= m; t++) {
            idx[t] = ev[p][t - 1].first;
            val[t] = val[t - 1] + ev[p][t - 1].second;
        }
        // next strictly smaller state to the right
        nl.assign(m + 1, -1);
        st.clear();
        for (int t = m; t >= 0; t--) {
            while (!st.empty() && val[st.back()] >= val[t]) st.pop_back();
            nl[t] = st.empty() ? -1 : st.back();
            st.push_back(t);
        }
        for (int t = 0; t <= m; t++) {
            if (nl[t] < 0) continue;
            int lo = idx[t];
            int hi = (t + 1 <= m) ? idx[t + 1] - 1 : n - 1;
            if (hi > n - 1) hi = n - 1;
            if (lo > hi) continue;
            iv.push_back({lo, hi, idx[nl[t]]});
        }
        vector<pair<int, int>>().swap(ev[p]);
    }

    // range-min assignment: process intervals by increasing f, paint unpainted starts
    sort(iv.begin(), iv.end(), [](const array<int, 3>& x, const array<int, 3>& y) {
        return x[2] < y[2];
    });
    vector<int> fval(n + 1, n + 1), nxt(n + 2);
    for (int i = 0; i <= n + 1; i++) nxt[i] = i;
    function<int(int)> find = [&](int x) {
        while (nxt[x] != x) {
            nxt[x] = nxt[nxt[x]];
            x = nxt[x];
        }
        return x;
    };
    for (auto& q : iv) {
        int lo = q[0], hi = q[1], f = q[2];
        int x = find(lo);
        while (x <= hi) {
            fval[x] = f;
            nxt[x] = x + 1;
            x = find(x + 1);
        }
    }

    long long ans = 0;
    for (int k = 0; k <= n - 1; k++) ans += (long long)(fval[k] - (k + 1));
    printf("%lld\n", ans);
    return 0;
}
