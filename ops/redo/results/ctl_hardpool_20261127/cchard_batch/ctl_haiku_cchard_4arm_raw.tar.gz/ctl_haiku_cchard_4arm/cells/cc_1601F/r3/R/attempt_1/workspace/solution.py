import sys
from math import gcd

MOD_OUT = 10 ** 9 + 7
M = 998244353
Q = 9 * M  # floor(D/M) == floor((9D) / Q), and 9D is an integer


def floor_sum(n, m, a, b):
    """sum_{i=0}^{n-1} floor((a*i + b) / m) for a, b >= 0, m >= 1."""
    ans = 0
    while True:
        if a >= m:
            ans += (n - 1) * n // 2 * (a // m)
            a %= m
        if b >= m:
            ans += n * (b // m)
            b %= m
        y_max = a * n + b
        if y_max < m:
            break
        n, b = divmod(y_max, m)
        m, a = a, m
    return ans


def floor_sum_range(lo, hi, A, B):
    """sum_{x=lo}^{hi} floor((A*x + B) / Q), A >= 0."""
    N = hi - lo + 1
    b0 = A * lo + B
    q0, r0 = divmod(b0, Q)
    return N * q0 + floor_sum(N, Q, A % Q, r0) + (A // Q) * ((N - 1) * N // 2)


def digsum(x):
    return sum(map(int, str(x)))


def corr(lo, hi, A, B):
    """#{x in [lo,hi] : (A*x+B) mod Q < s(x)}, s = decimal digit sum."""
    A0 = A % Q
    g = gcd(A0, Q)
    m = Q // g
    total = 0
    for r in range(0, 120):
        c = r - B
        if c % g:
            continue
        if m == 1:
            x0 = 0
        else:
            x0 = (c // g) * pow((A0 // g) % m, -1, m) % m
        x = lo + ((x0 - lo) % m)
        while x <= hi:
            if digsum(x) > r:
                total += 1
            x += m
    return total


def block_sum(lo, hi, alpha, beta):
    """sum_{x=lo}^{hi} floor(D(x)/M) where 9*D(x) = (A*x + B) - s(x)."""
    A = 9 * alpha + 1
    B = 9 * beta
    return floor_sum_range(lo, hi, A, B) - corr(lo, hi, A, B)


def solve(n):
    D = len(str(n))
    F = 0
    for L in range(1, D + 1):
        p = 10 ** (L - 1)
        csum = (p - 1) // 9 - (L - 1)
        if L == D:
            F += block_sum(p, n, 0, -csum + 1 - p)
        else:
            e = 10 ** (D - L)
            T = (n + 1) // e
            R = sum(10 ** j for j in range(1, D - L + 1))
            Rp = R - e
            hi_nc = min(T, 10 ** L - 1)
            if p <= hi_nc:
                F += block_sum(p, hi_nc, R, -csum + 1 - p - R * p)
            lo_c = max(T + 1, p)
            hi_c = 10 ** L - 1
            if lo_c <= hi_c:
                F += block_sum(lo_c, hi_c, Rp,
                               -csum - (1 + Rp) * p + n - 10 ** (D - 1) + 2)
    return (-M * F) % MOD_OUT


def main():
    n = int(sys.stdin.read().split()[0])
    print(solve(n))


if __name__ == "__main__":
    main()
