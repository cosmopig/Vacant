#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

// Model: a student visiting [l, r] activates tickets at grid points t_i = l + i*k
// (i = 0 .. m-1, m = ceil((r-l+1)/k)). The activation at t_i costs
// min(a[l..t_i]); exact k-spacing is optimal because the prefix minimum is
// non-increasing and any valid schedule has at least m activations.
//
// V(p) = min a[p-k+1..p] is the cheapest day in the window that is covered
// by the activation at p. The answer is the sum over i of
// min(a_l, V(l+k), ..., V(l+ik)).
//
// Positions are relabelled chain-major (residue class mod k, then position),
// so every stride-k chain is contiguous. A next-smaller tree on each chain plus
// binary lifting gives the prefix-minimum sums in O(log n) per query.

int main() {
    int n, q, k;
    if (scanf("%d %d %d", &n, &q, &k) != 3) return 0;
    vector<ll> a(n);
    for (auto &x : a) scanf("%lld", &x);

    vector<ll> V(n, 0);
    {
        deque<int> dq;
        for (int p = 0; p < n; p++) {
            while (!dq.empty() && a[dq.back()] >= a[p]) dq.pop_back();
            dq.push_back(p);
            while (dq.front() < p - k + 1) dq.pop_front();
            if (p >= k - 1) V[p] = a[dq.front()];
        }
    }

    vector<int> gi(n), pos(n), chainEnd(n);
    int cnt = 0;
    for (int c = 0; c < k && c < n; c++) {
        int start = cnt;
        for (int p = c; p < n; p += k) {
            gi[p] = cnt;
            pos[cnt] = p;
            cnt++;
        }
        for (int g = start; g < cnt; g++) chainEnd[g] = cnt - 1;
    }

    const int LOG = 19;  // 2^19 > 3e5
    vector<ll> Vg(n);
    for (int g = 0; g < n; g++) Vg[g] = V[pos[g]];

    vector<vector<int>> jmp(LOG, vector<int>(n + 1, n));
    vector<vector<ll>> acc(LOG, vector<ll>(n + 1, 0));

    // Next strictly smaller element within the same chain (or chain end + 1).
    {
        vector<int> st;
        int g = 0;
        while (g < n) {
            int end = chainEnd[g];
            st.clear();
            for (int h = end; h >= g; h--) {
                while (!st.empty() && Vg[st.back()] >= Vg[h]) st.pop_back();
                jmp[0][h] = st.empty() ? end + 1 : st.back();
                st.push_back(h);
            }
            g = end + 1;
        }
        for (int x = 0; x < n; x++) acc[0][x] = Vg[x] * (ll)(jmp[0][x] - x);
        jmp[0][n] = n;
        acc[0][n] = 0;
    }
    for (int h = 1; h < LOG; h++) {
        for (int x = 0; x <= n; x++) {
            int mid = jmp[h - 1][x];
            jmp[h][x] = jmp[h - 1][mid];
            acc[h][x] = acc[h - 1][x] + acc[h - 1][mid];
        }
    }

    string out;
    out.reserve((size_t)q * 16);
    for (int qi = 0; qi < q; qi++) {
        int l, r;
        scanf("%d %d", &l, &r);
        l--;
        r--;
        ll al = a[l];
        ll m = ((ll)r - l + k) / k;  // ceil((r-l+1)/k)
        ll ans;
        if (m == 1) {
            ans = al;
        } else {
            int Glim = gi[l + (int)((m - 1) * k)];
            int g1 = gi[l + k];
            int f = -1;
            if (Vg[g1] < al) {
                f = g1;
            } else {
                int g = g1;
                for (int h = LOG - 1; h >= 0; h--) {
                    int nx = jmp[h][g];
                    if (nx <= Glim && Vg[nx] >= al) g = nx;
                }
                int nx = jmp[0][g];
                if (nx <= Glim) f = nx;
            }
            if (f < 0) {
                ans = al * m;
            } else {
                ll jf = (pos[f] - l) / k;
                ll tot = 0;
                int g = f;
                for (int h = LOG - 1; h >= 0; h--) {
                    if (jmp[h][g] <= Glim) {
                        tot += acc[h][g];
                        g = jmp[h][g];
                    }
                }
                tot += Vg[g] * (ll)(Glim - g + 1);
                ans = al * jf + tot;
            }
        }
        out += to_string(ans);
        out += '\n';
    }
    fputs(out.c_str(), stdout);
    return 0;
}
