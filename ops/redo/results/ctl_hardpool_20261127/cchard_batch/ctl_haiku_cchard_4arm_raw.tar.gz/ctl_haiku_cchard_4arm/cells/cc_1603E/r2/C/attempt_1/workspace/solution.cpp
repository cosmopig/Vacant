#include <bits/stdc++.h>
using namespace std;

// Characterisation used:
// A sequence is perfect iff, with x = min value present, for every w in [x, n+1]:
//     sum_{v<=w} v * k_v  <=  x * w,
// where k_v is the number of occurrences of v. Equivalently, with
// D(w) = sum_{x<=v<=w} (v - x) k_v and t(w) = #elements <= w:
//     D(w) <= x * (w - t(w)).
// The answer is sum over x and count vectors of n! / prod k_v!, computed as
// a product of binomials C(cumulative count, k_v).

int main() {
    long long n, M;
    cin >> n >> M;

    vector<vector<long long>> C(n + 2, vector<long long>(n + 2, 0));
    for (int i = 0; i <= n + 1; i++) {
        C[i][0] = 1 % M;
        for (int j = 1; j <= i; j++) {
            C[i][j] = (C[i - 1][j - 1] + (j <= i - 1 ? C[i - 1][j] : 0)) % M;
        }
    }

    long long ans = 0;
    for (long long x = 1; x <= n + 1; x++) {
        // A valid sequence needs k_x <= x and (n - k_x) <= x (each other element
        // has excess >= 1 and total excess <= x), so n <= 2x.
        if (2 * x < n) continue;
        const long long W = x + 1;  // row width for D in [0, x]
        // dp[t * W + D]: t elements placed so far (values in [x, v]), excess sum D.
        vector<long long> dp((n + 1) * W, 0), ndp((n + 1) * W, 0);
        dp[0] = 1;
        for (long long v = x; v <= n + 1; v++) {
            fill(ndp.begin(), ndp.end(), 0LL);
            long long tmax = min(n, v);
            for (long long t = 0; t <= tmax; t++) {
                for (long long D = 0; D <= x; D++) {
                    long long cur = dp[t * W + D];
                    if (!cur) continue;
                    // Any valid state has nt <= v (since 0 <= nD <= x*(v-nt)).
                    for (long long k = (v == x ? 1 : 0); t + k <= tmax; k++) {
                        long long ex = (v - x) * k;
                        if (D + ex > x) break;
                        long long nt = t + k, nD = D + ex;
                        if (nD > x * (v - nt)) continue;  // constraint at w = v
                        long long &slot = ndp[nt * W + nD];
                        slot = (slot + cur * C[nt][k]) % M;
                    }
                }
            }
            swap(dp, ndp);
        }
        for (long long D = 0; D <= x; D++) {
            ans = (ans + dp[n * W + D]) % M;
        }
    }
    cout << ans % M << "\n";
    return 0;
}
