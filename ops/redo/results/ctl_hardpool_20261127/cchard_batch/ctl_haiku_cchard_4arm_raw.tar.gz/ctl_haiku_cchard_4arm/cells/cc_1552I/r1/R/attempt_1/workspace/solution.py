import sys

MOD = 998244353


def main():
    data = sys.stdin.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    m = int(data[pos]); pos += 1
    sets = []
    for _ in range(m):
        q = int(data[pos]); pos += 1
        s = frozenset(int(x) for x in data[pos:pos + q])
        pos += q
        sets.append(s)

    fact = [1] * (n + 2)
    for i in range(1, n + 2):
        fact[i] = fact[i - 1] * i % MOD

    def overlap(a, b):
        return bool(a & b) and not (a <= b) and not (b <= a)

    def build_order(order):
        """order: sets of one overlap-connected component in BFS order.
        Returns the list of atoms in a consistent linear order, or None."""
        seq = [order[0]]
        covered = set(order[0])
        for T in order[1:]:
            N = frozenset(T - covered)
            idx = [i for i, B in enumerate(seq) if B & T]
            if not idx:
                return None
            l, r = idx[0], idx[-1]
            if len(idx) != r - l + 1:
                return None
            L = len(seq)
            if N:
                if r == L - 1 and all(seq[i] <= T for i in range(l + 1, r + 1)):
                    if seq[l] <= T:
                        split = [seq[l]]
                    else:
                        split = [seq[l] - T, seq[l] & T]
                    seq = seq[:l] + split + seq[l + 1:] + [N]
                elif l == 0 and all(seq[i] <= T for i in range(0, r)):
                    if seq[r] <= T:
                        split = [seq[r]]
                    else:
                        split = [seq[r] & T, seq[r] - T]
                    seq = [N] + seq[:r] + split + seq[r + 1:]
                else:
                    return None
            else:
                if r == l:
                    return None
                if not all(seq[i] <= T for i in range(l + 1, r)):
                    return None
                splitL = [seq[l]] if seq[l] <= T else [seq[l] - T, seq[l] & T]
                splitR = [seq[r]] if seq[r] <= T else [seq[r] & T, seq[r] - T]
                seq = seq[:l] + splitL + seq[l + 1:r] + splitR + seq[r + 1:]
            covered |= T
        # verify every set is a contiguous run of blocks
        for T in order:
            idx = [i for i, B in enumerate(seq) if B & T]
            if len(idx) != idx[-1] - idx[0] + 1:
                return None
            for i in idx:
                if not seq[i] <= T:
                    return None
        return seq

    def count(U, F):
        # F: sets, all subsets of U; drop trivial ones
        F = list({S for S in F if 2 <= len(S) < len(U)})
        if not F:
            return fact[len(U)]
        k = len(F)
        adj = [[] for _ in range(k)]
        for a in range(k):
            for b in range(a + 1, k):
                if overlap(F[a], F[b]):
                    adj[a].append(b)
                    adj[b].append(a)
        seen = [False] * k
        comps = []  # list of BFS orders
        for s in range(k):
            if seen[s]:
                continue
            seen[s] = True
            order = [s]
            qi = 0
            while qi < len(order):
                x = order[qi]; qi += 1
                for y in adj[x]:
                    if not seen[y]:
                        seen[y] = True
                        order.append(y)
            comps.append(order)

        unions = []
        for order in comps:
            u = set()
            for i in order:
                u |= F[i]
            unions.append(frozenset(u))

        # Case B: a component covering all of U -> Q-node
        for ci, order in enumerate(comps):
            if unions[ci] == U:
                if len(order) == 1:
                    # single set equal to U would have been removed
                    return 0
                C_sets = [F[i] for i in order]
                seq = build_order(C_sets)
                if seq is None:
                    return 0
                rest = [F[i] for j, o in enumerate(comps) if j != ci for i in o]
                total = 2
                for atom in seq:
                    sub = [T for T in rest if T <= atom]
                    total = total * count(atom, sub) % MOD
                    if total == 0:
                        return 0
                # every remaining set must lie in one atom
                for T in rest:
                    if not any(T <= atom for atom in seq):
                        return 0
                return total

        # Case A: P-node over maximal blocks and uncovered elements
        distinct = set(unions)
        maximal = []
        for W in distinct:
            if not any(W < V for V in distinct):
                maximal.append(W)
        covered = set()
        for W in maximal:
            covered |= W
        children = len(maximal) + len(U - covered)
        total = fact[children]
        for W in maximal:
            sub = [T for T in F if T <= W]
            total = total * count(W, sub) % MOD
            if total == 0:
                return 0
        return total

    U = frozenset(range(1, n + 1))
    print(count(U, sets) % MOD)


main()
