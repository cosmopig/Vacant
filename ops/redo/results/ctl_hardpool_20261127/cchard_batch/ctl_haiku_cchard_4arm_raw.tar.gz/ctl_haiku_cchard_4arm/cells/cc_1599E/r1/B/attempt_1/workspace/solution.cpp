#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef unsigned long long ull;

static const ll MOD = 1000000007LL;

// Returns (F(n) mod MOD, F(n+1) mod MOD) using fast doubling.
static pair<ll, ll> fibPair(ull n) {
    if (n == 0) return {0, 1};
    pair<ll, ll> p = fibPair(n >> 1);
    ll a = p.first, b = p.second;             // a = F(k), b = F(k+1), k = n/2
    ll c = a * ((2 * b % MOD + MOD - a) % MOD) % MOD;  // F(2k)
    ll d = (a * a % MOD + b * b % MOD) % MOD;          // F(2k+1)
    if (n & 1) return {d, (c + d) % MOD};
    return {c, d};
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, q;
    if (!(cin >> n >> q)) return 0;

    vector<ll> A1(n + 1), A2(n + 1);
    for (int i = 1; i <= n; i++) cin >> A1[i];
    for (int i = 1; i <= n; i++) cin >> A2[i];

    string out;
    for (int qi = 0; qi < q; qi++) {
        int t;
        cin >> t;
        if (t == 4) {
            int l, r;
            cin >> l >> r;
            ll sum = 0;
            for (int i = max(l, 1); i <= min(r, n); i++) {
                ll s = A1[i] + A2[i];
                sum += fibPair((ull)s).first;
                if (sum >= MOD) sum -= MOD;
            }
            out += to_string(sum);
            out += '\n';
        } else {
            int k, l, r;
            ll x;
            cin >> k >> l >> r >> x;
            vector<ll>& A = (k == 1) ? A1 : A2;
            for (int i = max(l, 1); i <= min(r, n); i++) {
                if (t == 1) A[i] = min(A[i], x);
                else if (t == 2) A[i] = max(A[i], x);
                else A[i] += x;
            }
        }
    }
    cout << out;
    return 0;
}
