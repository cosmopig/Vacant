import sys

MOD = 998244353


def overlap(a, b):
    c = a & b
    return c != 0 and c != a and c != b


def popcount(x):
    return bin(x).count("1")


def build_component(order):
    """order: masks of one overlap-connected component, each (after the first) overlapping
    an earlier one. Returns the ordered list of atoms (blocks) if the sets can be made
    contiguous, else None."""
    first = order[0]
    blocks = [first]
    U = first
    for S in order[1:]:
        k = len(blocks)
        new = S & ~U
        touched = [i for i, b in enumerate(blocks) if b & S]
        if not touched:
            return None
        l, r = touched[0], touched[-1]
        if touched != list(range(l, r + 1)):
            return None
        if new:
            B = None
            if r == k - 1 and all(blocks[i] & S == blocks[i] for i in range(l + 1, r + 1)):
                # append new elements on the right
                B = blocks[l]
                out = blocks[:l]
                if B & ~S:
                    out.append(B & ~S)
                out.append(B & S)
                out += blocks[l + 1:]
                out.append(new)
            elif l == 0 and all(blocks[i] & S == blocks[i] for i in range(l, r)):
                # prepend new elements on the left
                B = blocks[r]
                out = [new] + blocks[:r] + [B & S]
                if B & ~S:
                    out.append(B & ~S)
                out += blocks[r + 1:]
            else:
                return None
            U |= new
        else:
            if l == r:
                return None
            out = blocks[:l]
            B = blocks[l]
            if B & ~S:
                out.append(B & ~S)
            out.append(B & S)
            out += blocks[l + 1:r]
            B = blocks[r]
            out.append(B & S)
            if B & ~S:
                out.append(B & ~S)
            out += blocks[r + 1:]
        blocks = out
    # final verification: every set must be a run of whole blocks
    for S in order:
        t = [i for i, b in enumerate(blocks) if b & S]
        if not t or t != list(range(t[0], t[-1] + 1)):
            return None
        if any(blocks[i] & S != blocks[i] for i in t):
            return None
    return blocks


def main():
    data = sys.stdin.read().split()
    p = 0
    n = int(data[p])
    m = int(data[p + 1])
    p += 2
    full = (1 << n) - 1
    raw = set()
    for _ in range(m):
        q = int(data[p])
        p += 1
        mask = 0
        for j in range(q):
            mask |= 1 << (int(data[p + j]) - 1)
        p += q
        raw.add(mask)
    # sets of size <= 1 or equal to everything impose no constraint
    sets = [s for s in raw if 2 <= popcount(s) < n]
    k = len(sets)

    adj = [[] for _ in range(k)]
    for i in range(k):
        for j in range(i + 1, k):
            if overlap(sets[i], sets[j]):
                adj[i].append(j)
                adj[j].append(i)

    seen = [False] * k
    nodes = {}  # union mask -> atoms list (multi-set component) or None (single set / plain)
    singles = []
    for s in range(k):
        if seen[s]:
            continue
        seen[s] = True
        order = [s]
        idx = 0
        while idx < len(order):
            u = order[idx]
            idx += 1
            for v in adj[u]:
                if not seen[v]:
                    seen[v] = True
                    order.append(v)
        if len(order) == 1:
            singles.append(sets[s])
        else:
            atoms = build_component([sets[t] for t in order])
            if atoms is None:
                print(0)
                return
            U = 0
            for a in atoms:
                U |= a
            nodes[U] = atoms
    for sm in singles:
        if sm not in nodes:
            nodes[sm] = None
    if full not in nodes:
        nodes[full] = None

    fact = [1] * (n + 2)
    for i in range(1, n + 2):
        fact[i] = fact[i - 1] * i % MOD

    node_list = list(nodes.keys())
    ans = 1
    for X in node_list:
        inside = [Y for Y in node_list if Y != X and (Y & ~X) == 0]
        maxi = [Y for Y in inside if not any(Y != Z and (Y & ~Z) == 0 for Z in inside)]
        covered = 0
        for Y in maxi:
            covered |= Y
        unc = X & ~covered
        atoms = nodes[X]
        if atoms is None:
            ans = ans * fact[len(maxi) + popcount(unc)] % MOD
        else:
            ans = ans * 2 % MOD
            for A in atoms:
                cnt = sum(1 for Y in maxi if Y & A) + popcount(unc & A)
                ans = ans * fact[cnt] % MOD
    print(ans % MOD)


if __name__ == "__main__":
    main()
