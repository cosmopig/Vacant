#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long u64;

int n, m, k;
bool adj[12][12];
int partner_[12];
vector<array<int, 12>> matchings;   // all perfect matchings
vector<array<int, 12>> validM;      // matchings admitting a palindromic chain
int W;                              // words per bitset over validM

// Does the perfect matching admit an ordering of its pairs p_1..p_m (outermost
// first) with orientations so that a_j~a_{j+1}, b_j~b_{j+1}, a_m~b_m ?
bool chainOK(const array<int, 12> &pt) {
    vector<pair<int, int>> P;
    for (int v = 0; v < n; v++)
        if (pt[v] > v) P.push_back({v, pt[v]});
    int mm = P.size();
    int full = (1 << mm) - 1;
    // reach[mask][i][o]: chain over pairs in mask, innermost-so-far is pair i with
    // orientation o (a = P[i].first if o==0 else P[i].second, b = the other).
    vector<array<array<char, 2>, 6>> reach(1 << mm);
    for (auto &r : reach)
        for (auto &x : r) x[0] = x[1] = 0;
    for (int i = 0; i < mm; i++) {
        int x = P[i].first, y = P[i].second;
        if (adj[x][y]) {
            reach[1 << i][i][0] = 1;
            reach[1 << i][i][1] = 1;
        }
    }
    for (int mask = 1; mask <= full; mask++) {
        for (int i = 0; i < mm; i++)
            for (int o = 0; o < 2; o++) {
                if (!reach[mask][i][o]) continue;
                int a = o == 0 ? P[i].first : P[i].second;
                int b = o == 0 ? P[i].second : P[i].first;
                for (int j = 0; j < mm; j++) {
                    if (mask >> j & 1) continue;
                    for (int oj = 0; oj < 2; oj++) {
                        int c = oj == 0 ? P[j].first : P[j].second;
                        int d = oj == 0 ? P[j].second : P[j].first;
                        if (adj[a][c] && adj[b][d]) reach[mask | 1 << j][j][oj] = 1;
                    }
                }
            }
    }
    for (int i = 0; i < mm; i++)
        for (int o = 0; o < 2; o++)
            if (reach[full][i][o]) return true;
    return false;
}

void genMatch(array<int, 12> &pt, int used) {
    int v = -1;
    for (int i = 0; i < n; i++)
        if (!(used >> i & 1)) { v = i; break; }
    if (v < 0) {
        matchings.push_back(pt);
        return;
    }
    for (int u = v + 1; u < n; u++) {
        if (used >> u & 1) continue;
        pt[v] = u;
        pt[u] = v;
        genMatch(pt, used | 1 << v | 1 << u);
    }
}

vector<vector<vector<u64>>> tab;  // tab[v][S]: matchings allowed when v's block-mates-before-v are S
vector<vector<u64>> buf;          // alive bitset per depth
long long f[13];                  // falling factorials k*(k-1)*...
long long ans = 0;
int memb[12];

void dfs(int v, int nb) {
    if (v == n) {
        ans += f[nb];
        return;
    }
    // choose an existing block or a new one
    for (int b = 0; b <= nb; b++) {
        int nnb = (b == nb) ? nb + 1 : nb;
        if (nnb > k) break;
        int S = (b == nb) ? 0 : memb[b];
        const vector<u64> &t = tab[v][S];
        vector<u64> &cur = buf[v];
        vector<u64> &nxt = buf[v + 1];
        u64 any = 0;
        for (int w = 0; w < W; w++) {
            nxt[w] = cur[w] & t[w];
            any |= nxt[w];
        }
        if (!any) continue;
        int saved = memb[b];
        if (b == nb) memb[b] = 0;
        memb[b] |= 1 << v;
        dfs(v + 1, nnb);
        memb[b] = saved;
    }
}

int main() {
    scanf("%d %d %d", &n, &m, &k);
    for (int i = 0; i < m; i++) {
        int a, b;
        scanf("%d %d", &a, &b);
        a--; b--;
        adj[a][b] = adj[b][a] = true;
    }
    array<int, 12> pt{};
    pt.fill(-1);
    genMatch(pt, 0);
    for (auto &x : matchings)
        if (chainOK(x)) validM.push_back(x);
    int V = validM.size();
    if (V == 0) {
        printf("0\n");
        return 0;
    }
    W = (V + 63) / 64;

    // Later[v]: matchings where partner(v) > v.  Cov[u][v]: partner(v) == u (u < v).
    vector<vector<u64>> Later(n, vector<u64>(W, 0));
    vector<vector<vector<u64>>> Cov(n, vector<vector<u64>>(n, vector<u64>(W, 0)));
    for (int id = 0; id < V; id++) {
        for (int v = 0; v < n; v++) {
            int u = validM[id][v];
            if (u > v) Later[v][id >> 6] |= 1ULL << (id & 63);
            else Cov[u][v][id >> 6] |= 1ULL << (id & 63);
        }
    }
    tab.assign(n, {});
    for (int v = 0; v < n; v++) {
        tab[v].assign(1 << v, vector<u64>(W, 0));
        tab[v][0] = Later[v];
        for (int S = 1; S < (1 << v); S++) {
            int low = __builtin_ctz(S);
            for (int w = 0; w < W; w++)
                tab[v][S][w] = tab[v][S & (S - 1)][w] | Cov[low][v][w];
        }
    }
    // All matchings alive initially.
    buf.assign(n + 1, vector<u64>(W, 0));
    for (int id = 0; id < V; id++) buf[0][id >> 6] |= 1ULL << (id & 63);

    f[0] = 1;
    for (int i = 1; i <= 12; i++) f[i] = (i <= k) ? f[i - 1] * (k - i + 1) : 0;

    dfs(0, 0);
    printf("%lld\n", ans);
    return 0;
}
