// Count length-n sequences over GF(2)^k (values < 2^k) such that no non-empty
// subsequence XORs to x.
//
// x = 0: the elements must be linearly independent, giving
//        prod_{i<n} (2^k - 2^i) if n <= k, else 0.
// x != 0: let V be the span of the sequence. x must not lie in V. For an
//        i-dimensional V, the number of length-n sequences spanning exactly V is
//        prod_{j<i} (2^n - 2^j) (rank-i i x n matrices). The number of i-dim
//        subspaces not containing x is [k,i]_2 - [k-1,i-1]_2 (Gaussian binomials),
//        which does not depend on which non-zero x is used. So
//        answer = sum_{i=0}^{min(n,k)} ([k,i]_2 - [k-1,i-1]_2) * prod_{j<i}(2^n - 2^j).
#include <bits/stdc++.h>
using namespace std;

typedef unsigned long long ull;
static const ull MOD = 998244353ULL;

static ull pw(ull b, ull e) {
    b %= MOD;
    ull r = 1;
    while (e) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    vector<long long> N(t), K(t), X(t);
    long long maxK = 0;
    for (int q = 0; q < t; q++) {
        cin >> N[q] >> K[q] >> X[q];
        maxK = max(maxK, K[q]);
    }

    // pow2[i] = 2^i mod p for i in [0, maxK]
    vector<unsigned> pow2(maxK + 1);
    pow2[0] = 1;
    for (long long i = 1; i <= maxK; i++) pow2[i] = (unsigned)(pow2[i - 1] * 2ULL % MOD);

    // inv[i] = (2^i - 1)^{-1} mod p for i in [1, maxK], via batch inversion.
    vector<unsigned> inv(maxK + 1, 0);
    {
        vector<ull> pre(maxK + 1, 1);  // pre[i] = prod_{j=1..i} (2^j - 1)
        for (long long i = 1; i <= maxK; i++) {
            ull d = (pow2[i] + MOD - 1) % MOD;
            pre[i] = pre[i - 1] * d % MOD;
        }
        ull acc = pw(pre[maxK], MOD - 2);  // inverse of pre[maxK]
        for (long long i = maxK; i >= 1; i--) {
            ull d = (pow2[i] + MOD - 1) % MOD;
            inv[i] = (unsigned)(acc * pre[i - 1] % MOD);  // (2^i-1)^{-1}
            acc = acc * d % MOD;
        }
    }

    string out;
    for (int q = 0; q < t; q++) {
        long long n = N[q], k = K[q], x = X[q];
        ull ans = 0;
        if (x == 0) {
            if (n > k) {
                ans = 0;
            } else {
                ull pk = pow2[k];
                ans = 1;
                for (long long i = 0; i < n; i++) {
                    ull f = (pk + MOD - pow2[i]) % MOD;
                    ans = ans * f % MOD;
                }
            }
        } else {
            long long m = min(n, k);
            ull p2n = pw(2, (ull)n);
            ull G = 1;      // [k, i]_2
            ull Hprev = 0;  // [k-1, i-1]_2
            ull Hcur = 1;   // [k-1, i]_2
            ull gp = 1;     // prod_{j<i} (2^n - 2^j)
            for (long long i = 0; i <= m; i++) {
                ull cnt = (G + MOD - Hprev) % MOD;  // i-dim subspaces not containing x
                ans = (ans + cnt * gp) % MOD;
                if (i < m) {
                    // [k,i+1] = [k,i] * (2^{k-i} - 1) / (2^{i+1} - 1)
                    ull f1 = (pow2[k - i] + MOD - 1) % MOD;
                    G = G * f1 % MOD * inv[i + 1] % MOD;
                    // [k-1,i+1] = [k-1,i] * (2^{k-1-i} - 1) / (2^{i+1} - 1)
                    ull f2 = (pow2[k - 1 - i] + MOD - 1) % MOD;
                    Hprev = Hcur;
                    Hcur = Hcur * f2 % MOD * inv[i + 1] % MOD;
                    // extend gp by factor (2^n - 2^i)
                    ull f3 = (p2n + MOD - pow2[i]) % MOD;
                    gp = gp * f3 % MOD;
                }
            }
        }
        out += to_string(ans);
        out += '\n';
    }
    cout << out;
    return 0;
}
