// Kuzya and Homework.
//
// For a start l, the path [l..r] is all-integer iff for every prime p the
// running exponent E_p(i) - E_p(l-1) >= 0 for all i in [l, r], where E_p is the
// prefix sum of signed prime exponents (+v for '*', -v for '/').
//
// For each prime p, E_p only changes at occurrences of p. Split the timeline
// into runs of constant E_p; for a run starting at occurrence t_k with value
// v_k, the first failure is at the next occurrence t_q (q > k) with v_q < v_k.
// f(s) = min over primes of these failure indices, where s = l-1.
// Answer = sum over s in [0, n-1] of (f(s) - s - 1), with f(s) = n+1 if none.
// Range-chmin updates are done with a sparse-table style structure in O(1)
// each, followed by one push-down pass.

#include <bits/stdc++.h>
using namespace std;

static char buf[1 << 25];

int main() {
    size_t len = fread(buf, 1, sizeof(buf) - 1, stdin);
    buf[len] = 0;
    char *ptr = buf;

    auto skip = [&]() {
        while (*ptr && (*ptr == ' ' || *ptr == '\n' || *ptr == '\r' || *ptr == '\t')) ++ptr;
    };
    auto readInt = [&]() -> long long {
        skip();
        long long x = 0;
        while (*ptr >= '0' && *ptr <= '9') {
            x = x * 10 + (*ptr - '0');
            ++ptr;
        }
        return x;
    };

    int n = (int)readInt();
    vector<int> a(n + 1);
    for (int i = 1; i <= n; ++i) a[i] = (int)readInt();

    skip();
    vector<int> sgn(n + 1);
    for (int i = 1; i <= n; ++i) {
        // Each symbol is '*' or '/'; skip anything else defensively.
        while (*ptr && *ptr != '*' && *ptr != '/') ++ptr;
        sgn[i] = (*ptr == '/') ? -1 : 1;
        if (*ptr) ++ptr;
    }

    const int MAXV = 1000000;
    vector<int> spf(MAXV + 1, 0);
    for (int i = 2; i <= MAXV; ++i) {
        if (spf[i] == 0) {
            for (long long j = i; j <= MAXV; j += i) {
                if (spf[j] == 0) spf[j] = i;
            }
        }
    }

    // For each prime, list of (position, signed exponent) in position order.
    // Positions are appended in increasing order, so each list stays sorted.
    vector<vector<pair<int, int>>> occ(MAXV + 1);
    for (int i = 1; i <= n; ++i) {
        int x = a[i];
        while (x > 1) {
            int p = spf[x];
            int e = 0;
            while (x % p == 0) {
                x /= p;
                ++e;
            }
            occ[p].push_back({i, sgn[i] * e});
        }
    }

    // Sparse-table style range chmin over s in [0, n-1].
    const int INF = n + 1;
    int LOG = 1;
    while ((1 << LOG) <= n) ++LOG;
    vector<vector<int>> tab(LOG, vector<int>(n, INF));
    vector<int> lg(n + 2, 0);
    for (int i = 2; i <= n + 1; ++i) lg[i] = lg[i / 2] + 1;

    auto chmin_range = [&](int L, int R, int val) {
        // inclusive [L, R], 0 <= L <= R <= n-1
        if (L > R) return;
        int k = lg[R - L + 1];
        if (tab[k][L] > val) tab[k][L] = val;
        int st = R - (1 << k) + 1;
        if (tab[k][st] > val) tab[k][st] = val;
    };

    vector<int> tpos, vval, nsm;
    vector<int> stk;
    for (int p = 2; p <= MAXV; ++p) {
        if (occ[p].empty()) continue;
        // Build occurrence sequence: index 0 is virtual (time 0, value 0).
        int m = (int)occ[p].size();
        tpos.assign(m + 1, 0);
        vval.assign(m + 1, 0);
        for (int k = 1; k <= m; ++k) {
            tpos[k] = occ[p][k - 1].first;
            vval[k] = vval[k - 1] + occ[p][k - 1].second;
        }
        // Next strictly smaller value index for each k in [0, m].
        nsm.assign(m + 1, -1);
        stk.clear();
        for (int q = 0; q <= m; ++q) {
            while (!stk.empty() && vval[stk.back()] > vval[q]) {
                nsm[stk.back()] = q;
                stk.pop_back();
            }
            stk.push_back(q);
        }
        // Runs: run k covers s in [tpos[k], tpos[k+1]-1], clipped to [0, n-1].
        for (int k = 0; k <= m; ++k) {
            int L = tpos[k];
            int R = (k < m) ? tpos[k + 1] - 1 : n - 1;
            if (R > n - 1) R = n - 1;
            if (L > R) continue;
            int fail = (nsm[k] >= 0) ? tpos[nsm[k]] : INF;
            if (fail < INF) chmin_range(L, R, fail);
        }
    }

    // Push-down: propagate level-j entries to level j-1.
    for (int j = LOG - 1; j >= 1; --j) {
        int half = 1 << (j - 1);
        for (int i = 0; i + (1 << j) <= n; ++i) {
            int v = tab[j][i];
            if (v < tab[j - 1][i]) tab[j - 1][i] = v;
            if (v < tab[j - 1][i + half]) tab[j - 1][i + half] = v;
        }
    }

    long long ans = 0;
    for (int s = 0; s <= n - 1; ++s) {
        long long f = tab[0][s];
        ans += f - s - 1;
    }
    printf("%lld\n", ans);
    return 0;
}
