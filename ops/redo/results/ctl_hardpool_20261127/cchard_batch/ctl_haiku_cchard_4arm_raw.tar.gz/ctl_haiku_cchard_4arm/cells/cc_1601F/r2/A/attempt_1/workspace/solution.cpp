// Two Sorts.
//
// Let p(x) be the 1-based position of x in the lexicographic order of 1..n, and
// D(x) = p(x) - x. Since a_{p(x)} = x, the answer is
//   sum_i ((i - a_i) mod M) = sum_x (D(x) mod M) = -M * S  (mod 1e9+7),
// where S = sum_x floor(D(x) / M) and M = 998244353.
//
// Within numbers of one digit length k, p is strictly increasing, so D(x+1) - D(x)
// = (p(x+1) - p(x)) - 1 >= 0: D is non-decreasing inside each length block. Hence
// for a threshold v, #{x in block : D(x) >= v} is found by binary search, and
//   floor(D/M) = sum_{t>=1} [D >= tM] - sum_{t>=0} [D < -tM].

#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

static const ll MOD_A = 998244353LL;
static const ll MOD_B = 1000000007LL;

static ll n;
static int N;               // number of digits of n
static ll pw[20];

static int digits_of(ll x) {
    int k = 0;
    while (x > 0) { x /= 10; k++; }
    return k;
}

// Lexicographic position of x (1-based) among 1..n.
static ll pos_of(ll x) {
    int k = digits_of(x);
    ll res = 0;
    // Shorter numbers L < k: those whose value is <= the length-L prefix of x.
    for (int L = 1; L < k; L++) {
        res += x / pw[k - L] - pw[L - 1] + 1;
    }
    // Same length: numbers <= x.
    res += x - pw[k - 1] + 1;
    // Longer numbers L > k: those whose length-k prefix is < x.
    for (int L = k + 1; L <= N; L++) {
        ll upper = (L < N) ? pw[L] : n + 1;
        ll t = min(upper, x * pw[L - k]);
        ll c = t - pw[L - 1];
        if (c > 0) res += c;
    }
    return res;
}

static ll D_of(ll x) { return pos_of(x) - x; }

int main() {
    cin >> n;
    pw[0] = 1;
    for (int i = 1; i < 20; i++) pw[i] = pw[i - 1] * 10;
    N = digits_of(n);

    ll S = 0;  // exact: |S| is at most about n * (n / M) ~ 1e16, fits in ll
    for (int k = 1; k <= N; k++) {
        ll lo = pw[k - 1];
        if (lo > n) break;
        ll hi = min(n, pw[k] - 1);
        ll size = hi - lo + 1;

        // First x in [lo, hi] with D(x) >= v; returns hi+1 if none.
        auto lower_bound_D = [&](ll v) -> ll {
            ll a = lo, b = hi + 1;
            while (a < b) {
                ll m = a + (b - a) / 2;
                if (D_of(m) >= v) b = m; else a = m + 1;
            }
            return a;
        };
        // #{x in block : D(x) >= v}
        auto cnt_ge = [&](ll v) -> ll { return hi + 1 - lower_bound_D(v); };

        ll Dlo = D_of(lo), Dhi = D_of(hi);

        // Positive part: sum over t >= 1 of #{D >= tM}.
        for (ll t = 1; t * MOD_A <= Dhi; t++) {
            S += cnt_ge(t * MOD_A);
        }
        // Negative part: - sum over t >= 0 of #{D < -tM}.
        for (ll t = 0; Dlo < -t * MOD_A; t++) {
            S -= size - cnt_ge(-t * MOD_A);
        }
    }

    ll s = S % (ll)MOD_B;
    if (s < 0) s += MOD_B;
    ll ans = ((MOD_B - s) % MOD_B) * (MOD_A % MOD_B) % MOD_B;
    cout << ans << "\n";
    return 0;
}
