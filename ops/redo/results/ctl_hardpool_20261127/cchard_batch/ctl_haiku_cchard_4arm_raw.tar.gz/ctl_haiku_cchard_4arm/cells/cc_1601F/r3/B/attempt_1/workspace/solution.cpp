// Two Sorts: sum over x = 1..n of ((pos(x) - x) mod 998244353), mod 1e9+7,
// where pos(x) is the 1-based position of x among 1..n in lexicographic order.
//
// Derivation sketch:
//  * pos(x) - x = h(x) + u*x + const within a regime, where h(x) = sum_{j>=1} floor(x/10^j)
//    = (x - s(x))/9 (s = digit sum). So 9*f(x) = alpha*x + beta - s(x) inside a regime.
//  * Regimes: for length-L numbers, x <= floor((n+1)/10^(K-L)) (K = len(n)) is one regime,
//    the rest another; L = K is a single regime.
//  * Each regime is cut into aligned blocks P*10^t + r, r in [0,10^t). Inside a block,
//    f = c0 + sum_k r_k * w_k with integer w_k = (alpha*10^k - 1)/9.
//  * Sum over r of ((c0 + sum r_k w_k) mod M) is computed by splitting the t digits into two
//    halves, sorting the two lists of partial sums mod M, and counting carries with two pointers.

#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef __int128 i128;

static const ll MP = 998244353LL;
static const ll MOD = 1000000007LL;

static i128 P10[30];
static ll N;
static int K;

static int digitsOf(i128 x) {
    int c = 0;
    while (x > 0) { c++; x /= 10; }
    return c;
}

static ll dsum(i128 x) {
    ll s = 0;
    while (x > 0) { s += (ll)(x % 10); x /= 10; }
    return s;
}

// Exact f(x) = pos(x) - x, computed directly from the lexicographic counting formula.
static i128 posMinusX(i128 x) {
    int L = digitsOf(x);
    i128 pos = 0;
    for (int d = 1; d <= L - 1; d++) pos += x / P10[L - d] - P10[d - 1] + 1;
    pos += x - P10[L - 1] + 1;
    if (L < K) {
        for (int d = L + 1; d <= K - 1; d++) pos += x * P10[d - L] - P10[d - 1];
        i128 a = (i128)N - P10[K - 1] + 1;
        i128 b = x * P10[K - L] - P10[K - 1];
        pos += (a < b ? a : b);
    }
    return pos - x;
}

static map<i128, vector<pair<int, ll>>> groups;  // alpha -> list of (t, c0 mod MP)

static void addInterval(i128 alpha, i128 lo, i128 hi) {
    if (lo > hi) return;
    i128 f0 = posMinusX(lo);
    i128 beta = 9 * f0 + dsum(lo) - alpha * lo;
    i128 x = lo;
    while (x <= hi) {
        int t = 0;
        while (t + 1 <= 13 && x % P10[t + 1] == 0 && x + P10[t + 1] - 1 <= hi) t++;
        i128 num = alpha * x + beta - dsum(x);
        i128 c0 = num / 9;  // exact: num is divisible by 9 inside a regime
        ll c = (ll)(((c0 % MP) + MP) % MP);
        groups[alpha].push_back({t, c});
        x += P10[t];
    }
}

static ll posmod(i128 v) {
    i128 r = v % MP;
    if (r < 0) r += MP;
    return (ll)r;
}

// Number of pairs (a in A, b in B) with a + b >= T. A and B sorted ascending.
static ll countAtLeast(const vector<ll>& A, const vector<ll>& B, ll T) {
    ll nB = (ll)B.size();
    ll j = nB;
    ll cnt = 0;
    for (ll a : A) {
        ll thr = T - a;
        while (j > 0 && B[j - 1] >= thr) j--;
        cnt += nB - j;
    }
    return cnt;
}

// Sum over a in A, b in B of ((c + a + b) mod MP), with c, a, b in [0, MP).
static i128 blockSum(ll c, const vector<ll>& A, const vector<ll>& B, i128 sumA, i128 sumB) {
    i128 nA = (i128)A.size(), nB = (i128)B.size();
    i128 res = nA * nB * (i128)c + nB * sumA + nA * sumB;
    ll carries = countAtLeast(A, B, MP - c) + countAtLeast(A, B, 2 * MP - c);
    res -= (i128)MP * (i128)carries;
    return res;
}

static vector<ll> genList(const ll* w, int from, int to) {
    vector<ll> v(1, 0);
    for (int k = from; k < to; k++) {
        vector<ll> nv;
        nv.reserve(v.size() * 10);
        for (int d = 0; d <= 9; d++) {
            ll add = (ll)d * w[k];
            for (ll val : v) nv.push_back((val + add) % MP);
        }
        v.swap(nv);
    }
    return v;
}

int main() {
    if (!(cin >> N)) return 0;
    P10[0] = 1;
    for (int i = 1; i < 30; i++) P10[i] = P10[i - 1] * 10;
    K = digitsOf(N);

    for (int L = 1; L <= K; L++) {
        i128 lo = P10[L - 1];
        i128 hi = min((i128)N, P10[L] - 1);
        if (L < K) {
            int m = K - L;
            i128 X = ((i128)N + 1) / P10[m];
            addInterval(P10[m + 1] - 9, lo, min(X, hi));
            addInterval(P10[m] - 9, max(lo, X + 1), hi);
        } else {
            addInterval(1, lo, hi);
        }
    }

    i128 total = 0;
    for (auto& g : groups) {
        i128 alpha = g.first;
        ll w[14];
        for (int k = 0; k < 14; k++) {
            i128 v = (alpha * P10[k] - 1) / 9;  // exact
            w[k] = posmod(v);
        }
        map<int, vector<ll>> byT;
        for (auto& bc : g.second) byT[bc.first].push_back(bc.second);
        for (auto& tb : byT) {
            int t = tb.first;
            int t1 = t / 2;
            vector<ll> A = genList(w, 0, t1);
            vector<ll> B = genList(w, t1, t);
            sort(A.begin(), A.end());
            sort(B.begin(), B.end());
            i128 sumA = 0, sumB = 0;
            for (ll a : A) sumA += a;
            for (ll b : B) sumB += b;
            for (ll c : tb.second) total += blockSum(c, A, B, sumA, sumB);
        }
    }

    ll ans = (ll)(total % MOD);
    if (ans < 0) ans += MOD;
    cout << ans << "\n";
    return 0;
}
