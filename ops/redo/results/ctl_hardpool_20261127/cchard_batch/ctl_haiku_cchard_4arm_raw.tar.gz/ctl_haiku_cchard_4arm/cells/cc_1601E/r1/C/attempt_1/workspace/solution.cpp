// Phys Ed Online.
//
// For a student visiting [l, r], an optimal plan activates tickets at days
// g_s = l + (s-1)k (s = 1, 2, ...) while g_s <= r, and each activation at day t
// costs pm_l(t) = min(a[l..t]) (buy the ticket at the cheapest day in [l, t]).
// So answer = sum over t in {l, l+k, ...}, t <= r, of min(a[l..t]).
//
// Sweep l from n down to 1 maintaining a monotonic stack of "prefix-minimum
// records" starting at l (stack entry d has nse(st[d]) = st[d-1]). Each stack
// entry q covers days [q, nse(q)-1] with value a[q]. Count of days t = l (mod k)
// in [x, y] is G(y) - G(x-1) with G(x) = x/k + [x%k >= l%k].
// Entries strictly above the partial entry q* (the record containing r) are full
// segments; their residue-dependent indicator terms are summed with a persistent
// segment tree over residues versioned by stack depth, and the residue-free part
// with prefix sums along the stack.

#include <bits/stdc++.h>
using namespace std;

static vector<int> PL, PR;
static vector<long long> PS;
static int K;

static int newNode(int l, int r, long long s) {
    PL.push_back(l);
    PR.push_back(r);
    PS.push_back(s);
    return (int)PL.size() - 1;
}

// Returns a new version of `node` with `val` added at `pos` in [lo, hi].
static int upd(int node, int lo, int hi, int pos, long long val) {
    int nn = newNode(PL[node], PR[node], PS[node] + val);
    if (lo == hi) return nn;
    int mid = (lo + hi) / 2;
    if (pos <= mid) {
        int c = upd(PL[node], lo, mid, pos, val);
        PL[nn] = c;
    } else {
        int c = upd(PR[node], mid + 1, hi, pos, val);
        PR[nn] = c;
    }
    return nn;
}

// Sum of values at indices in [ql, qr] of the tree rooted at `node` over [lo, hi].
static long long qry(int node, int lo, int hi, int ql, int qr) {
    if (node == 0 || qr < lo || hi < ql) return 0;
    if (ql <= lo && hi <= qr) return PS[node];
    int mid = (lo + hi) / 2;
    return qry(PL[node], lo, mid, ql, qr) + qry(PR[node], mid + 1, hi, ql, qr);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, q, k;
    cin >> n >> q >> k;
    K = k;
    vector<long long> a(n + 2);
    for (int i = 1; i <= n; i++) cin >> a[i];

    vector<int> ql(q), qr(q);
    vector<vector<int>> byL(n + 2);
    for (int i = 0; i < q; i++) {
        cin >> ql[i] >> qr[i];
        byL[ql[i]].push_back(i);
    }

    PL.reserve(size_t(n) * 2 * 22 + 8);
    PR.reserve(size_t(n) * 2 * 22 + 8);
    PS.reserve(size_t(n) * 2 * 22 + 8);
    newNode(0, 0, 0);  // null node (index 0), sum 0, children 0

    vector<long long> ans(q, 0);
    vector<int> st(n + 1);     // stack of positions, st[0] = bottom
    vector<long long> P(n + 1); // residue-free prefix sums along the stack
    vector<int> root(n + 1);    // persistent tree root per stack depth
    int sz = 0;

    auto G = [&](long long x, long long rho) -> long long {
        // number of t in [0, x] with t % k == rho, x >= 0
        return x / k + ((x % k) >= rho ? 1 : 0);
    };

    for (int l = n; l >= 1; l--) {
        while (sz > 0 && a[st[sz - 1]] >= a[l]) sz--;
        st[sz] = l;
        long long A = a[l];
        if (sz == 0) {
            P[sz] = 0;
            root[sz] = 0;
        } else {
            int e = st[sz - 1] - 1;  // segment of l is [l, e]
            long long lin = (long long)(e / k) - (long long)((l - 1) / k);
            P[sz] = P[sz - 1] + A * lin;
            int rt = root[sz - 1];
            rt = upd(rt, 0, k - 1, e % k, A);
            rt = upd(rt, 0, k - 1, (l - 1) % k, -A);
            root[sz] = rt;
        }
        sz++;

        long long rho = l % k;
        for (int id : byL[l]) {
            int r = qr[id];
            // first stack index d with st[d] <= r (positions decrease with depth)
            int lo = 0, hi = sz - 1;
            while (lo < hi) {
                int mid = (lo + hi) / 2;
                if (st[mid] <= r) hi = mid;
                else lo = mid + 1;
            }
            int idx = lo;           // partial entry q*
            int qs = st[idx];
            long long res = a[qs] * (G(r, rho) - G(qs - 1, rho));
            // full entries: depths idx+1 .. sz-1
            long long full = P[sz - 1] - P[idx];
            long long tTop = qry(root[sz - 1], 0, k - 1, (int)rho, k - 1);
            long long tIdx = qry(root[idx], 0, k - 1, (int)rho, k - 1);
            full += tTop - tIdx;
            res += full;
            ans[id] = res;
        }
    }

    string out;
    out.reserve(size_t(q) * 16);
    for (int i = 0; i < q; i++) {
        out += to_string(ans[i]);
        out += '\n';
    }
    cout << out;
    return 0;
}
