// Palindromic Hamiltonian Path: count letter strings (k letters) for which some
// Hamiltonian path has palindromic letters.
//
// Reformulation:
//  * A palindromic Hamiltonian path v_1..v_n exists iff there is an ordered sequence of
//    h = n/2 pairs (a_i, b_i) (a_i = v_i, b_i = v_{n+1-i}) that partitions V, with
//    a_i~a_{i+1}, b_i~b_{i+1} for consecutive pairs, and a_h~b_h.
//    Each pair must receive the same letter. Call a perfect matching of V "admissible" if
//    its pairs admit such an ordering/orientation.
//  * A letter string is good iff some admissible matching has every pair monochromatic.
//  * Group strings by their partition of V into letter classes; a partition with b blocks
//    corresponds to falling(k, b) strings. We DFS over restricted-growth partitions while
//    keeping the list of admissible matchings still consistent with the partial partition.
//    A partition is good iff that list is nonempty at the leaf.
#include <bits/stdc++.h>
using namespace std;

int n, m, k;
bool adj[12][12];
vector<array<int, 12>> partners;   // partner of each vertex, one entry per admissible matching
long long fallingK[13];
long long answer = 0;
int col[12];

// Does a ladder ordering exist for matching given by pairs (x_i, y_i)?
bool admissible(const vector<pair<int, int>>& pr) {
    int h = (int)pr.size();
    // reach[mask][j][o]: pairs in mask used, last pair j with orientation o
    static bool reach[1 << 6][6][2];
    int full = (1 << h) - 1;
    for (int mask = 0; mask <= full; ++mask)
        for (int j = 0; j < 6; ++j) reach[mask][j][0] = reach[mask][j][1] = false;
    for (int i = 0; i < h; ++i)
        for (int o = 0; o < 2; ++o) reach[1 << i][i][o] = true;
    for (int mask = 1; mask <= full; ++mask) {
        for (int j = 0; j < h; ++j) {
            if (!(mask >> j & 1)) continue;
            for (int o = 0; o < 2; ++o) {
                if (!reach[mask][j][o]) continue;
                int a = o ? pr[j].second : pr[j].first;
                int b = o ? pr[j].first : pr[j].second;
                for (int q = 0; q < h; ++q) {
                    if (mask >> q & 1) continue;
                    for (int o2 = 0; o2 < 2; ++o2) {
                        int c = o2 ? pr[q].second : pr[q].first;
                        int d = o2 ? pr[q].first : pr[q].second;
                        if (adj[a][c] && adj[b][d]) reach[mask | (1 << q)][q][o2] = true;
                    }
                }
            }
        }
    }
    for (int j = 0; j < h; ++j)
        for (int o = 0; o < 2; ++o) {
            if (!reach[full][j][o]) continue;
            int a = o ? pr[j].second : pr[j].first;
            int b = o ? pr[j].first : pr[j].second;
            if (adj[a][b]) return true;
        }
    return false;
}

void enumerate_matchings(int used, vector<pair<int, int>>& cur) {
    int v = 0;
    while (v < n && (used >> v & 1)) ++v;
    if (v == n) {
        if (admissible(cur)) {
            array<int, 12> p{};
            for (auto& e : cur) {
                p[e.first] = e.second;
                p[e.second] = e.first;
            }
            partners.push_back(p);
        }
        return;
    }
    for (int u = v + 1; u < n; ++u) {
        if (used >> u & 1) continue;
        cur.push_back({v, u});
        enumerate_matchings(used | (1 << v) | (1 << u), cur);
        cur.pop_back();
    }
}

// alive: indices into partners, matchings consistent with col[0..v-1].
void dfs(int v, int nb, const vector<int>& alive) {
    if (alive.empty()) return;
    if (v == n) {
        answer += fallingK[nb];
        return;
    }
    int maxc = min(nb + 1, k);  // choose existing block 0..nb-1, or new block nb (if nb < k)
    for (int c = 0; c < maxc; ++c) {
        vector<int> next;
        next.reserve(alive.size());
        for (int idx : alive) {
            int p = partners[idx][v];
            if (p > v || (p < v && col[p] == c)) next.push_back(idx);
        }
        if (next.empty()) continue;
        col[v] = c;
        dfs(v + 1, c == nb ? nb + 1 : nb, next);
    }
}

int main() {
    if (!(cin >> n >> m >> k)) return 0;
    for (int i = 0; i < m; ++i) {
        int u, v;
        cin >> u >> v;
        if (u < 1 || v < 1 || u > n || v > n || u == v) continue;  // ignore invalid/self-loop
        adj[u - 1][v - 1] = adj[v - 1][u - 1] = true;
    }
    fallingK[0] = 1;
    for (int b = 1; b <= 12; ++b)
        fallingK[b] = (b <= k) ? fallingK[b - 1] * (k - b + 1) : 0;

    vector<pair<int, int>> cur;
    enumerate_matchings(0, cur);

    vector<int> alive(partners.size());
    for (size_t i = 0; i < alive.size(); ++i) alive[i] = (int)i;
    dfs(0, 0, alive);
    cout << answer << "\n";
    return 0;
}
