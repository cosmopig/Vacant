// Kuzya and Homework.
//
// Segment [l;r] is simple iff for every prime p and every j in [l;r]:
//   E_p(j) >= E_p(l-1),
// where E_p(t) is the prefix sum over i<=t of (+v_p(a_i) for '*', -v_p(a_i) for '/').
//
// Sweep r from 1..n. Let t = l-1 range over alive indices in [0, r-1].
// An index t is removed (permanently, since the condition is monotone in r)
// the first time some '/' at position r with prime p gives E_p(r) < E_p(t).
// Per prime we keep the current constant segment of E_p (start, value) and a
// max-heap of closed segments keyed by value. When a '/' drops E_p to x, every
// segment with value > x is killed entirely (all its alive indices removed).
// Removal uses a DSU "next alive index". The answer adds, for each r, the
// number of alive t in [0, r-1], i.e. r - removed.

#include <bits/stdc++.h>
using namespace std;

const int MAXA = 1000000;
static int spf[MAXA + 1];

static vector<int> nxt_alive;
static long long removed_cnt = 0;

static int findAlive(int t) {
    int r = t;
    while (nxt_alive[r] != r) r = nxt_alive[r];
    while (nxt_alive[t] != r) {
        int nt = nxt_alive[t];
        nxt_alive[t] = r;
        t = nt;
    }
    return r;
}

static void removeRange(int a, int b) {
    int t = findAlive(a);
    while (t <= b) {
        nxt_alive[t] = t + 1;
        removed_cnt++;
        t = findAlive(t + 1);
    }
}

int main() {
    for (int i = 2; i <= MAXA; i++) {
        if (spf[i] == 0) {
            for (int j = i; j <= MAXA; j += i) {
                if (spf[j] == 0) spf[j] = i;
            }
        }
    }

    int n;
    if (scanf("%d", &n) != 1) return 0;
    vector<int> a(n + 1);
    for (int i = 1; i <= n; i++) scanf("%d", &a[i]);

    static char buf[1000010];
    scanf("%s", buf);
    // buf[i-1] is b_i
    nxt_alive.resize(n + 2);
    for (int i = 0; i <= n + 1; i++) nxt_alive[i] = i;

    vector<int> cur(MAXA + 1, 0), st(MAXA + 1, 0);
    // Each entry: {value, start, end}; max-heap on value.
    vector<vector<array<int, 3>>> heaps(MAXA + 1);

    long long ans = 0;
    for (int r = 1; r <= n; r++) {
        char op = buf[r - 1];
        int x = a[r];
        while (x > 1) {
            int p = spf[x];
            int v = 0;
            while (x % p == 0) {
                x /= p;
                v++;
            }
            if (op == '*') {
                if (st[p] <= r - 1) {
                    heaps[p].push_back({cur[p], st[p], r - 1});
                    push_heap(heaps[p].begin(), heaps[p].end());
                }
                st[p] = r;
                cur[p] += v;
            } else {
                int nv = cur[p] - v;
                // Open segment has value cur[p] > nv: all its alive indices die.
                if (st[p] <= r - 1) removeRange(st[p], r - 1);
                // Closed segments with value > nv die.
                auto &h = heaps[p];
                while (!h.empty() && h.front()[0] > nv) {
                    pop_heap(h.begin(), h.end());
                    array<int, 3> seg = h.back();
                    h.pop_back();
                    removeRange(seg[1], seg[2]);
                }
                cur[p] = nv;
                st[p] = r;
            }
        }
        ans += (long long)r - removed_cnt;
    }

    printf("%lld\n", ans);
    return 0;
}
