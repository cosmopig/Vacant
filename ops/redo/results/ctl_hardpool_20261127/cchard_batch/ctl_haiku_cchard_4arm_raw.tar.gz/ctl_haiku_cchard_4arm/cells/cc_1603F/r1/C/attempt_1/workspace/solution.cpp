// Count sequences of n vectors in F_2^k whose span does not contain x (x != 0),
// or which are linearly independent (x == 0).
//
// For x != 0: answer = sum_r  [k choose r]_2 * (2^k - 2^r) / (2^k - 1) * prod_{i<r} (2^n - 2^i)
//   - [k choose r]_2 * (2^k-2^r)/(2^k-1) = number of r-dim subspaces not containing x
//   - prod_{i<r}(2^n-2^i) = number of n-tuples spanning a fixed r-dim space
#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long ull;
typedef unsigned int ui;
static const ull MOD = 998244353ULL;

ull mpow(ull b, ull e) {
    b %= MOD;
    ull r = 1;
    while (e) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

int main() {
    int t;
    if (scanf("%d", &t) != 1) return 0;
    vector<long long> N(t), K(t), X(t);
    long long maxK = 0;
    for (int i = 0; i < t; i++) {
        scanf("%lld %lld %lld", &N[i], &K[i], &X[i]);
        maxK = max(maxK, K[i]);
    }

    // pw2[j] = 2^j mod p, j in [0, maxK]
    vector<ui> pw2(maxK + 1);
    pw2[0] = 1;
    for (long long j = 1; j <= maxK; j++) pw2[j] = (ui)((ull)pw2[j - 1] * 2 % MOD);

    // invD[j] = inverse of (2^j - 1) mod p, j in [1, maxK], via batch inversion.
    // pre[j] = prod_{i=1..j} (2^i - 1)
    vector<ui> invD(maxK + 1, 0);
    if (maxK >= 1) {
        vector<ui> pre(maxK + 1);
        pre[0] = 1;
        for (long long j = 1; j <= maxK; j++)
            pre[j] = (ui)((ull)pre[j - 1] * ((pw2[j] + MOD - 1) % MOD) % MOD);
        ull cur = mpow(pre[maxK], MOD - 2);  // = 1 / pre[j] for j = maxK
        for (long long j = maxK; j >= 1; j--) {
            // 1/(2^j-1) = (1/pre[j]) * pre[j-1]
            invD[j] = (ui)(cur * pre[j - 1] % MOD);
            // 1/pre[j-1] = (1/pre[j]) * (2^j - 1)
            cur = cur * ((pw2[j] + MOD - 1) % MOD) % MOD;
        }
    }

    string out;
    out.reserve((size_t)t * 12);
    for (int tc = 0; tc < t; tc++) {
        long long n = N[tc], k = K[tc], x = X[tc];
        ull ans = 0;
        if (x == 0) {
            // Must be linearly independent: prod_{i<n} (2^k - 2^i), zero if n > k.
            if (n > k) {
                ans = 0;
            } else {
                ans = 1;
                for (long long i = 0; i < n; i++)
                    ans = ans * ((pw2[k] + MOD - pw2[i]) % MOD) % MOD;
            }
        } else {
            long long R = min(n, k);
            ull pn = mpow(2, (ull)n);
            ull denomInv = mpow((pw2[k] + MOD - 1) % MOD, MOD - 2);  // 1/(2^k-1)
            ull G = 1;  // [k choose r]_2
            ull P = 1;  // prod_{i<r} (2^n - 2^i)
            ull S = 0;
            for (long long r = 0; r <= R; r++) {
                if (r > 0) {
                    G = G * ((pw2[k - r + 1] + MOD - 1) % MOD) % MOD * invD[r] % MOD;
                    P = P * ((pn + MOD - pw2[r - 1]) % MOD) % MOD;
                }
                ull c = (pw2[k] + MOD - pw2[r]) % MOD;
                S = (S + G * c % MOD * P) % MOD;
            }
            ans = S * denomInv % MOD;
        }
        out += to_string(ans);
        out += '\n';
    }
    fputs(out.c_str(), stdout);
    return 0;
}
