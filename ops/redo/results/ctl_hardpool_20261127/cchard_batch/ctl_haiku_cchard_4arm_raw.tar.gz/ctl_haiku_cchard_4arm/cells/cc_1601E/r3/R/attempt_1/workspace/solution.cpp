// Phys Ed Online (CF 1132C).
//
// Model: a ticket bought on day p can be activated on any day t >= p (validity k days
// from activation). A student on [l, r] must activate tickets at a chain of days
// l = s_0 < s_1 < ... with gaps <= k and last start >= r-k+1; the cost of a start t is
// min a[l..t]. Pushing every start as late as possible (s_i = l + i*k) is optimal, so
//   answer = sum_{i=0..m} min a[l .. l+i*k],   m = ceil((r-l+1)/k) - 1.
// With B(c) = min a[c+1 .. c+k], this becomes
//   a_l*(j*+1) + sum_{t=j*}^{m-1} min(B(c*), ..., B(l+t*k))
// where c* is the first chain node with B(c*) < a_l. The running-min sums are answered
// with a next-smaller tree over chain steps (step k) and binary lifting.
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

static const int LOG = 19;

int main() {
    int n, q, k;
    if (scanf("%d %d %d", &n, &q, &k) != 3) return 0;
    const ll INF = LLONG_MAX / 4;
    vector<ll> a(n + 2, 0);
    for (int i = 1; i <= n; i++) scanf("%lld", &a[i]);

    // E[e] = min a[e-k+1 .. e]
    vector<ll> E(n + 2, INF);
    {
        deque<int> dq;
        for (int e = 1; e <= n; e++) {
            while (!dq.empty() && a[dq.back()] >= a[e]) dq.pop_back();
            dq.push_back(e);
            while (dq.front() <= e - k) dq.pop_front();
            if (e >= k) E[e] = a[dq.front()];
        }
    }

    const int root = n + 1;
    vector<ll> B(n + 2, INF);
    for (int c = 1; c + k <= n; c++) B[c] = E[c + k];
    B[root] = -INF;

    // Next-smaller tree along chains of step k: P[c] = first c' = c + j*k (j>=1) with B[c'] < B[c].
    vector<int> P(n + 2, root);
    {
        vector<vector<int>> st(k);
        for (int c = n; c >= 1; c--) {
            auto &s = st[c % k];
            while (!s.empty() && B[s.back()] >= B[c]) s.pop_back();
            P[c] = s.empty() ? root : s.back();
            s.push_back(c);
        }
    }
    P[root] = root;

    // Binary lifting.
    vector<vector<int>> up(LOG, vector<int>(n + 2, root));
    for (int c = 1; c <= root; c++) up[0][c] = P[c];
    for (int j = 1; j < LOG; j++)
        for (int c = 1; c <= root; c++) up[j][c] = up[j - 1][up[j - 1][c]];

    // Dsum[c] = sum over chain from c up to (excluding) root of B[node] * (#chain nodes until parent).
    vector<ll> Dsum(n + 2, 0);
    for (int c = n; c >= 1; c--) {
        if (B[c] >= INF || P[c] == root) {
            Dsum[c] = 0;
        } else {
            Dsum[c] = B[c] * (ll)((P[c] - c) / k) + Dsum[P[c]];
        }
    }

    string out;
    out.reserve((size_t)q * 16);
    for (int qi = 0; qi < q; qi++) {
        int l, r;
        scanf("%d %d", &l, &r);
        int len = r - l + 1;
        int m = (len + k - 1) / k - 1;
        ll ans;
        if (m == 0) {
            ans = a[l];
        } else {
            int X = l + (m - 1) * k;  // last chain node whose block is needed
            int cs;
            if (B[l] < a[l]) {
                cs = l;
            } else {
                int cur = l;
                for (int j = LOG - 1; j >= 0; j--) {
                    int nx = up[j][cur];
                    if (nx != root && B[nx] >= a[l]) cur = nx;
                }
                cs = up[0][cur];
            }
            if (cs == root || cs > X) {
                ans = a[l] * (ll)(m + 1);
            } else {
                ll jstar = (cs - l) / k;
                int R = cs;
                for (int j = LOG - 1; j >= 0; j--) {
                    int nx = up[j][R];
                    if (nx <= X) R = nx;
                }
                ll sum = Dsum[cs] - Dsum[R] + B[R] * (ll)((X - R) / k + 1);
                ans = a[l] * (jstar + 1) + sum;
            }
        }
        out += to_string(ans);
        out += '\n';
    }
    fputs(out.c_str(), stdout);
    return 0;
}
