// Counting sequences a_1..a_n in [0, 2^k) such that no nonempty subsequence XORs to x.
//
// Let V = span(a_1..a_n) over F_2. Condition <=> x not in V.
// - x = 0: the condition says the a_i are linearly independent. Answer = prod_{i<n} (2^k - 2^i)
//   (0 if n > k).
// - x != 0: sum over dimension d of
//       (#d-dim subspaces V of F_2^k with x not in V) * (#n-tuples spanning exactly V)
//   #tuples spanning a fixed d-dim V = prod_{i<d} (2^n - 2^i)
//   #d-dim subspaces  = G(k,d)  (Gaussian binomial)
//   #d-dim subspaces containing x = G(k-1,d-1)
//   so the count is G(k,d) - G(k-1,d-1).
// G(m,e) = G(m,e-1) * (2^{m-e+1} - 1) / (2^e - 1), so we need inv(2^j - 1) for j <= max k,
// precomputed once with batch inversion.

#include <bits/stdc++.h>
using namespace std;

static const unsigned long long MOD = 998244353ULL;

static unsigned long long pw(unsigned long long b, unsigned long long e) {
    unsigned long long r = 1;
    b %= MOD;
    while (e) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

int main() {
    int t;
    if (scanf("%d", &t) != 1) return 0;
    vector<array<long long, 3>> q(t);
    long long maxK = 0;
    for (auto &c : q) {
        scanf("%lld %lld %lld", &c[0], &c[1], &c[2]);
        maxK = max(maxK, c[1]);
    }

    // pre[j] = prod_{i=1..j} (2^i - 1), pre[0] = 1
    // invE[j] = inv(2^j - 1) for 1 <= j <= maxK
    const unsigned long long inv2 = (MOD + 1) / 2;
    vector<uint32_t> pre(maxK + 1), invE(maxK + 1, 0);
    pre[0] = 1;
    {
        unsigned long long p2 = 1, run = 1;
        for (long long j = 1; j <= maxK; j++) {
            p2 = p2 * 2 % MOD;
            run = run * ((p2 + MOD - 1) % MOD) % MOD;
            pre[j] = (uint32_t)run;
        }
        // Backward: inv(2^j - 1) = inv(pre[j]) * pre[j-1]
        unsigned long long invPre = pw(pre[maxK], MOD - 2);
        unsigned long long p2b = pw(2, maxK);  // 2^j, going down
        for (long long j = maxK; j >= 1; j--) {
            invE[j] = (uint32_t)(invPre * pre[j - 1] % MOD);
            invPre = invPre * ((p2b + MOD - 1) % MOD) % MOD;
            p2b = p2b * inv2 % MOD;
        }
    }

    string out;
    out.reserve(t * 11);
    for (auto &c : q) {
        long long n = c[0], k = c[1], x = c[2];
        unsigned long long ans = 0;

        if (x == 0) {
            if (n > k) {
                ans = 0;
            } else {
                unsigned long long pk = pw(2, k), cur = 1;  // cur = 2^i
                ans = 1;
                for (long long i = 0; i < n; i++) {
                    ans = ans * ((pk + MOD - cur) % MOD) % MOD;
                    cur = cur * 2 % MOD;
                }
            }
        } else {
            // k >= 1 here since x < 2^min(20,k)
            unsigned long long twon = pw(2, n);
            unsigned long long G = 1;  // G(k,d)
            unsigned long long H = 0;  // G(k-1,d-1)
            unsigned long long S = 1;  // prod_{i<d} (2^n - 2^i)
            unsigned long long pk = pw(2, k);  // 2^{k-d+1} at step d
            unsigned long long p2d1 = 1;       // 2^{d-1} at step d
            ans = 1;                           // d = 0 term: 1 * 1
            long long L = min(n, k);
            for (long long d = 1; d <= L; d++) {
                unsigned long long f = (pk + MOD - 1) % MOD;  // 2^{k-d+1} - 1
                unsigned long long Gn = G * f % MOD * invE[d] % MOD;
                unsigned long long Hn = (d == 1) ? 1 : H * f % MOD * invE[d - 1] % MOD;
                G = Gn;
                H = Hn;
                S = S * ((twon + MOD - p2d1) % MOD) % MOD;
                unsigned long long T = (G + MOD - H) % MOD;
                ans = (ans + T * S) % MOD;
                pk = pk * inv2 % MOD;
                p2d1 = p2d1 * 2 % MOD;
            }
        }
        out += to_string(ans);
        out += '\n';
    }
    fputs(out.c_str(), stdout);
    return 0;
}
