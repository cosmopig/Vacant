#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long u64;
static const u64 MOD = 998244353ULL;

static u64 pw(u64 b, u64 e) {
    u64 r = 1;
    b %= MOD;
    while (e) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

int main() {
    int t;
    if (scanf("%d", &t) != 1) return 0;

    const int MAXK = 10000000;
    vector<uint32_t> p2(MAXK + 2);
    p2[0] = 1;
    for (int i = 1; i < MAXK + 2; i++) p2[i] = (uint32_t)((u64)p2[i - 1] * 2 % MOD);

    // F(j) = 2^j - 1 mod p
    auto F = [&](long long j) -> u64 { return ((u64)p2[j] + MOD - 1) % MOD; };

    string out;
    while (t--) {
        long long n, k, x;
        scanf("%lld %lld %lld", &n, &k, &x);

        if (x == 0) {
            // Need n vectors in F_2^k that are linearly independent.
            if (n > k) {
                out += "0\n";
                continue;
            }
            u64 K = p2[k];
            u64 ans = 1;
            for (long long i = 0; i < n; i++) {
                ans = ans * ((K + MOD - p2[i]) % MOD) % MOD;
            }
            out += to_string(ans) + "\n";
            continue;
        }

        // x != 0 (so k >= 1). Answer = sum_r c_r * P_r, where
        //   c_r = G(k,r) - G(k-1,r-1),  G = Gaussian binomial base 2,
        //   P_r = prod_{i<r} (2^n - 2^i).
        long long m = min(n, k);

        // D_j = prod_{t=1}^{j} F(t); need inverses for j = 0..m.
        vector<uint32_t> invD(m + 1);
        u64 D = 1;
        for (long long j = 1; j <= m; j++) D = D * F(j) % MOD;
        invD[m] = (uint32_t)pw(D, MOD - 2);
        for (long long r = m; r >= 1; r--) {
            invD[r - 1] = (uint32_t)((u64)invD[r] * F(r) % MOD);
        }

        u64 N = pw(2, (u64)n);  // 2^n mod p
        u64 A = 1;              // A_r = prod_{t=1}^{r} F(k-t+1)  -> G(k,r) = A_r / D_r
        u64 B = 1;              // B_r = prod_{t=1}^{r-1} F(k-t)  -> G(k-1,r-1) = B_r / D_{r-1}
        u64 P = 1;              // P_r
        u64 pow2r = 1;          // 2^r
        u64 ans = 0;

        for (long long r = 0; r <= m; r++) {
            if (r >= 1) {
                A = A * F(k - r + 1) % MOD;
            }
            if (r >= 2) {
                B = B * F(k - r + 1) % MOD;
            }
            u64 G1 = A * invD[r] % MOD;
            u64 G2 = (r >= 1) ? (B * invD[r - 1] % MOD) : 0;
            u64 c = (G1 + MOD - G2) % MOD;
            ans = (ans + c * P) % MOD;

            // P_{r+1} = P_r * (N - 2^r)
            P = P * ((N + MOD - pow2r) % MOD) % MOD;
            pow2r = pow2r * 2 % MOD;
        }
        out += to_string(ans) + "\n";
    }
    fputs(out.c_str(), stdout);
    return 0;
}
