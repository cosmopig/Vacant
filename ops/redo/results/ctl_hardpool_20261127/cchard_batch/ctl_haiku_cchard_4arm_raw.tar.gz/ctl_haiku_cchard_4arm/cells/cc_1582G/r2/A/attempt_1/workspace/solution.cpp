// Kuzya and Homework.
// For a fixed start l, [l,r] is simple iff every prefix product Q(l,i), i in [l,r], is an integer.
// So for each l we need R_l = first i >= l where Q(l,i) is not an integer; answer = sum (R_l - l).
// Q(l,i) is integer iff for every prime p, E_p(i) >= E_p(l-1), where E_p is the prefix sum of
// s_j * v_p(a_j) (s=+1 for '*', -1 for '/'). For prime p, E_p only changes at events (positions
// where p | a_j), so the first failure for baseline k=l-1 is the next event whose value drops
// below the baseline: a "next smaller element" over the event sequence.
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    vector<int> a(n + 1);
    for (int i = 1; i <= n; i++) cin >> a[i];
    string b;
    cin >> b;

    const int MX = 1000001;
    vector<int> spf(MX, 0);
    for (int i = 2; i < MX; i++) {
        if (spf[i] == 0) {
            for (long long j = i; j < MX; j += i)
                if (spf[j] == 0) spf[j] = i;
        }
    }

    // events[p] = list of (position, delta exponent of p)
    vector<vector<pair<int, int>>> ev(MX);
    for (int i = 1; i <= n; i++) {
        int x = a[i];
        int s = (b[i - 1] == '*') ? 1 : -1;
        while (x > 1) {
            int p = spf[x];
            int c = 0;
            while (x % p == 0) {
                x /= p;
                c++;
            }
            ev[p].push_back({i, s * c});
        }
    }

    // Range updates on k in [lo,hi] (k = l-1, so l = k+1): R[k+1] = min(R[k+1], T).
    vector<int> uT, uLo, uHi;
    for (int p = 2; p < MX; p++) {
        int m = (int)ev[p].size();
        if (m == 0) continue;
        // e[0] = 0 (virtual), e[1..m] = event positions; V[j] = exponent after event j.
        vector<int> e(m + 1), V(m + 1);
        e[0] = 0;
        V[0] = 0;
        for (int j = 1; j <= m; j++) {
            e[j] = ev[p][j - 1].first;
            V[j] = V[j - 1] + ev[p][j - 1].second;
        }
        // nxt[j] = first t > j with V[t] < V[j], or -1.
        vector<int> nxt(m + 1, -1);
        vector<int> st;
        for (int j = m; j >= 0; j--) {
            while (!st.empty() && V[st.back()] >= V[j]) st.pop_back();
            nxt[j] = st.empty() ? -1 : st.back();
            st.push_back(j);
        }
        for (int j = 0; j <= m; j++) {
            int lo = (j == 0) ? 0 : e[j];
            int hi = (j == m) ? n - 1 : min(e[j + 1] - 1, n - 1);
            if (lo > hi) continue;
            int T = (nxt[j] == -1) ? n + 1 : e[nxt[j]];
            uT.push_back(T);
            uLo.push_back(lo);
            uHi.push_back(hi);
        }
    }

    // Counting sort updates by T, then paint unassigned cells in increasing T (min wins).
    int U = (int)uT.size();
    vector<int> cnt(n + 3, 0);
    for (int u = 0; u < U; u++) cnt[uT[u] + 1]++;
    for (int t = 1; t < n + 3; t++) cnt[t] += cnt[t - 1];
    vector<int> order(U);
    {
        vector<int> pos(cnt.begin(), cnt.end());
        for (int u = 0; u < U; u++) order[pos[uT[u]]++] = u;
    }

    vector<int> R(n + 2, n + 1);
    // DSU: nf[k] = smallest unpainted index >= k (k in [0, n]).
    vector<int> nf(n + 2);
    for (int k = 0; k <= n + 1; k++) nf[k] = k;
    auto find = [&](int x) {
        int r = x;
        while (nf[r] != r) r = nf[r];
        while (nf[x] != r) {
            int nx = nf[x];
            nf[x] = r;
            x = nx;
        }
        return r;
    };
    for (int idx = 0; idx < U; idx++) {
        int u = order[idx];
        int T = uT[u];
        int k = find(uLo[u]);
        while (k <= uHi[u]) {
            R[k + 1] = T;
            nf[k] = k + 1;
            k = find(k + 1);
        }
    }

    long long ans = 0;
    for (int l = 1; l <= n; l++) ans += (long long)(R[l] - l);
    cout << ans << "\n";
    return 0;
}
