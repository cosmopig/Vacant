import sys

M = 10**9 + 7
MASK = (1 << 64) - 1
# Binomial coefficients C(j, i) for j <= 4
BIN = {2: [1, 2, 1], 3: [1, 3, 3, 1], 4: [1, 4, 6, 4, 1]}


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    q = int(data[1])
    a = [0] * (n + 1)
    for i in range(n):
        a[i + 1] = int(data[2 + i]) % M
    pos = 2 + n

    Ls = [0] * q
    Rs = [0] * q
    Ds = [0] * q
    byR = [[] for _ in range(n + 1)]
    for t in range(q):
        l = int(data[pos]); r = int(data[pos + 1]); d = int(data[pos + 2])
        pos += 3
        if l > r:
            l, r = r, l
        Ls[t] = l
        Rs[t] = r
        Ds[t] = d % M
        byR[r].append(t)

    # S[i][s] = sum_{k=0}^{s-1} k^i mod M, for i = 0..4
    S = [[0] * (n + 1) for _ in range(5)]
    for s in range(1, n + 1):
        k = s - 1
        p = 1
        for i in range(5):
            S[i][s] = (S[i][s - 1] + p) % M
            p = p * k % M

    # Packed BIT: field 0 = count, fields 1..4 = sums of v^1..v^4 (mod M).
    # Each field stays below 2^64 and never goes negative, so packed
    # addition/subtraction is exact.
    tree = [0] * (n + 1)

    def packed(v):
        v2 = v * v % M
        v3 = v2 * v % M
        v4 = v3 * v % M
        return 1 | (v << 64) | (v2 << 128) | (v3 << 192) | (v4 << 256)

    last = {}
    res = [None] * q

    for R in range(1, n + 1):
        v = a[R]
        fv = packed(v)
        if v in last:
            pv = last[v]
            neg = -fv
            i = pv
            while i <= n:
                tree[i] += neg
                i += i & -i
        last[v] = R
        i = R
        while i <= n:
            tree[i] += fv
            i += i & -i

        for t in byR[R]:
            L = Ls[t]
            # prefix(R) - prefix(L-1)
            x = 0
            i = R
            while i > 0:
                x += tree[i]
                i -= i & -i
            i = L - 1
            while i > 0:
                x -= tree[i]
                i -= i & -i
            s = x & MASK
            P1 = (x >> 64) & MASK
            P2 = (x >> 128) & MASK
            P3 = (x >> 192) & MASK
            P4 = (x >> 256) & MASK

            d = Ds[t]
            if s <= 1:
                res[t] = "Yes"
                continue
            if d == 0:
                res[t] = "No"
                continue

            c = pow(d, M - 2, M)
            c2 = c * c % M
            c3 = c2 * c % M
            c4 = c3 * c % M
            T = [0, c * P1 % M, c2 * P2 % M, c3 * P3 % M, c4 * P4 % M]

            inv_s = pow(s, M - 2, M)
            q0 = (T[1] - s * (s - 1) // 2) % M * inv_s % M
            qp = [1, q0, q0 * q0 % M, 0, 0]
            qp[3] = qp[2] * q0 % M
            qp[4] = qp[3] * q0 % M

            ok = True
            for j in range(2, 5):
                rhs = 0
                coeffs = BIN[j]
                for i in range(j + 1):
                    rhs += coeffs[i] * qp[j - i] % M * S[i][s]
                if rhs % M != T[j]:
                    ok = False
                    break
            res[t] = "Yes" if ok else "No"

    sys.stdout.write("\n".join(res) + "\n")


main()
