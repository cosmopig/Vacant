// Two Sorts.
//
// Let pos(x) = rank of x in the lexicographic order of 1..n (1-based), so a_{pos(x)} = x.
// Let F(x) = pos(x) - x. Then
//   sum_i ((i - a_i) mod M) = sum_x ((-F(x)) mod M) = -M * S,
// where S = sum_x floor(F(x) / M). The answer is (-M * S) mod (1e9+7).
//
// pos(x) is computed in O(digits) per x. Within each digit-length block of x
// (split once more at n / 10^(D-d)), F is nondecreasing, so
//   sum floor(F/M) = sum_{j} #{x : F(x) >= jM}
// and each threshold is located by binary search. There are only about
// |F|/M ~ 1000 thresholds per block, so the whole computation is fast.
#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef __int128 L128;

static const ll MOD = 1000000007LL;
#ifndef MM
#define MM 998244353LL
#endif

static ll n;
static int D;
static L128 P10[31];

// Number of y in [1, n] with y lexicographically <= x.
static L128 posOf(ll x) {
    int d = 0;
    for (ll t = x; t > 0; t /= 10) ++d;
    L128 total = 0;
    for (int L = 1; L <= D; ++L) {
        L128 lowL = P10[L - 1];
        L128 ymaxP1 = min((L128)n + 1, P10[L]);  // (largest L-digit y allowed) + 1
        L128 up;                                 // exclusive upper bound on counted y
        if (L <= d) {
            // y lex<= x  <=>  y <= prefix_L(x)
            L128 t = (L128)x / P10[d - L];
            up = min(t + 1, ymaxP1);
        } else {
            // y lex<= x  <=>  prefix_d(y) < x  <=>  y < x * 10^(L-d)
            up = min(ymaxP1, (L128)x * P10[L - d]);
        }
        if (up > lowL) total += up - lowL;
    }
    return total;
}

static inline L128 F(ll x) { return posOf(x) - (L128)x; }

static inline L128 floordiv(L128 a, L128 m) {
    L128 q = a / m;
    if ((a % m != 0) && (a < 0)) --q;
    return q;
}

// sum_{x=lo}^{hi} floor(F(x)/MM), where F is nondecreasing on [lo, hi].
static L128 sumFloor(ll lo, ll hi) {
    L128 fl = floordiv(F(lo), MM);
    L128 fh = floordiv(F(hi), MM);
    L128 res = fl * (L128)(hi - lo + 1);
    for (L128 j = fl + 1; j <= fh; ++j) {
        L128 target = j * (L128)MM;
        ll a = lo, b = hi;  // smallest x in [lo, hi] with F(x) >= target
        while (a < b) {
            ll mid = a + (b - a) / 2;
            if (F(mid) >= target) b = mid;
            else a = mid + 1;
        }
        res += (L128)(hi - a + 1);
    }
    return res;
}

static string toStr(L128 v) {
    if (v == 0) return "0";
    bool neg = v < 0;
    if (neg) v = -v;
    string s;
    while (v > 0) {
        s += char('0' + (int)(v % 10));
        v /= 10;
    }
    if (neg) s += '-';
    reverse(s.begin(), s.end());
    return s;
}

int main() {
    if (!(cin >> n)) return 0;

    P10[0] = 1;
    for (int i = 1; i <= 30; ++i) P10[i] = P10[i - 1] * 10;

    D = 0;
    for (ll t = n; t > 0; t /= 10) ++D;

    L128 S = 0;
    for (int d = 1; d <= D; ++d) {
        ll blo = (ll)P10[d - 1];
        ll bhi = min(n, (ll)P10[d] - 1);
        if (blo > bhi) continue;
        if (d < D) {
            // Within the block, x*10^(D-d) <= n holds for x <= x0; beyond x0 the
            // top-level term is clipped at n+1. Use separate segments.
            ll x0 = n / (ll)P10[D - d];
            ll a1 = blo, b1 = min(bhi, x0);
            if (a1 <= b1) S += sumFloor(a1, b1);
            ll a2 = max(blo, x0 + 1), b2 = bhi;
            if (a2 <= b2) S += sumFloor(a2, b2);
        } else {
            S += sumFloor(blo, bhi);
        }
    }

    L128 Sm = S % MOD;
    if (Sm < 0) Sm += MOD;
    ll t = (MOD - (ll)(MM % MOD)) % MOD;  // -M mod (1e9+7)
    ll ans = (ll)(((L128)t * Sm) % MOD);
    cout << ans << "\n";
    return 0;
}
