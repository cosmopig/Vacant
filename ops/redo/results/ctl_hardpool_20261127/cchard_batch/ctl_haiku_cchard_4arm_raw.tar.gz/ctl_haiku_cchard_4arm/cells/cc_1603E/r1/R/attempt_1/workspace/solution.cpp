#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long ull;
typedef long long ll;

// A multiset sorted as b_1<=...<=b_n is perfect iff for every j: b_1 * b_j >= b_1+...+b_j.
// (Necessity: the prefix subset. Sufficiency: b_i*b_j >= b_1*b_j >= P_j >= P_j - P_{i-1}.)
// Fix x = b_1, write b = x + d with d >= 0, F = sum of d over the prefix.
// Condition for block of value x+d ending at count j2 with excess F2:
//   j2*x + F2 <= x*(x+d)  <=>  F2 <= x*(x+d-j2).
// Final excess is <= x, so F is capped at x.
// Count = n! * sum over multisets of prod 1/c_v!.
int main() {
    int n;
    ll M;
    cin >> n >> M;
    vector<ll> fact(n + 1), inv(n + 1);
    fact[0] = 1;
    for (int i = 1; i <= n; i++) fact[i] = fact[i - 1] * i % M;
    auto pw = [&](ll b, ll e) {
        ll r = 1 % M;
        b %= M;
        while (e) {
            if (e & 1) r = r * b % M;
            b = b * b % M;
            e >>= 1;
        }
        return r;
    };
    for (int i = 0; i <= n; i++) inv[i] = pw(fact[i], M - 2);

    ll ans = 0;
    for (int x = 1; x <= n + 1; x++) {
        // dp[j][F]: j elements placed, excess sum F
        vector<vector<ull>> dp(n + 1, vector<ull>(x + 1, 0));
        // offset 0 (value x): must have at least one copy, the first element.
        for (int c = 1; c <= n && c <= x; c++) {
            dp[c][0] = (ull)inv[c];
        }
        for (int d = 1; d <= n + 1 - x; d++) {
            // Pull form: the check F2 <= x*(x+d-j2) depends only on the target,
            // so each target sums its valid sources c>=1 and reduces once.
            // In place: sources have smaller j, so descending j reads old values.
            // Targets need F2 <= x*(x+d-j2), which forces j2 <= x+d.
            int jmax = min(n, x + d);
            for (int j2 = jmax; j2 >= 1; j2--) {
                ll lim = (ll)x * (x + d - j2);
                for (int F2 = 0; F2 <= x && F2 <= lim; F2++) {
                    unsigned __int128 acc = 0;
                    for (int c = 1; c <= j2 && (ll)c * d <= F2; c++) {
                        ull src = dp[j2 - c][F2 - c * d];
                        if (src) acc += (unsigned __int128)src * (ull)inv[c];
                    }
                    if (acc) dp[j2][F2] = (dp[j2][F2] + (ull)(acc % (unsigned __int128)M)) % (ull)M;
                }
            }
        }
        ull s = 0;
        for (int F = 0; F <= x; F++) s = (s + dp[n][F]) % (ull)M;
        ans = (ans + (ll)s * fact[n]) % M;
    }
    cout << ans % M << "\n";
    return 0;
}
