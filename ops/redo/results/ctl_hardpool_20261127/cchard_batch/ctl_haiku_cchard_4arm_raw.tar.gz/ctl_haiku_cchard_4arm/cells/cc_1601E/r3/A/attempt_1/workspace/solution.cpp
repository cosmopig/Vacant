#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

// Answer for [l, r]:
//   Let J = (r - l) / k and chain points x_j = l + j*k (j = 0..J).
//   Cost = sum_{j=0..J} min(a[l..x_j]).
//   With Bk[x] = min(a[x-k+1..x]) (fixed block ending at x), the j>=1 term is
//   min(a[l], Bk[x_1], ..., Bk[x_j]).  Blocks for one residue class are shared
//   by all l in that class, so we use a next-smaller-element tree per class
//   (binary lifting) with suffix sums G.

int main() {
    int n, q, k;
    if (scanf("%d %d %d", &n, &q, &k) != 3) return 0;
    vector<ll> a(n + 2, 0);
    for (int i = 1; i <= n; i++) scanf("%lld", &a[i]);

    const int SENT = n + 1;
    const int LOG = 20;

    // Bk[x] = min over window [x-k+1, x], valid for x >= k.
    vector<ll> Bk(n + 2, 0);
    {
        deque<int> dq;
        for (int x = 1; x <= n; x++) {
            while (!dq.empty() && a[dq.back()] >= a[x]) dq.pop_back();
            dq.push_back(x);
            while (dq.front() <= x - k) dq.pop_front();
            if (x >= k) Bk[x] = a[dq.front()];
        }
    }

    vector<vector<int>> up(LOG, vector<int>(n + 2, SENT));
    vector<ll> G(n + 2, 0);  // G[x] = sum over chain from x of Bk * (#class elements covered)
    Bk[SENT] = 0;
    {
        vector<vector<int>> st(k);
        for (int x = n; x >= k + 1; x--) {
            int c = x % k;
            auto &S = st[c];
            while (!S.empty() && Bk[S.back()] >= Bk[x]) S.pop_back();
            int nx = S.empty() ? SENT : S.back();
            ll cnt = (nx == SENT) ? (ll)((n - x) / k + 1) : (ll)((nx - x) / k);
            G[x] = Bk[x] * cnt + G[nx];
            up[0][x] = nx;
            S.push_back(x);
        }
    }
    for (int j = 1; j < LOG; j++)
        for (int x = 0; x <= n + 1; x++) up[j][x] = up[j - 1][up[j - 1][x]];

    string out;
    out.reserve((size_t)q * 16);
    for (int qi = 0; qi < q; qi++) {
        int l, r;
        scanf("%d %d", &l, &r);
        ll c = a[l];
        int J = (r - l) / k;
        ll ans = c;
        if (J > 0) {
            int bound = l + J * k;
            int u = l + k;
            int f;
            if (Bk[u] < c) {
                f = u;
            } else {
                for (int j = LOG - 1; j >= 0; j--) {
                    int v = up[j][u];
                    if (Bk[v] >= c) u = v;  // sentinel has Bk 0 < c
                }
                f = up[0][u];
            }
            if (f == SENT || f > bound) {
                ans += c * (ll)J;
            } else {
                int fi = (f - l) / k;
                ans += c * (ll)(fi - 1);
                int p = f;
                for (int j = LOG - 1; j >= 0; j--) {
                    int v = up[j][p];
                    if (v <= bound) p = v;
                }
                ans += (G[f] - G[p]) + Bk[p] * (ll)((bound - p) / k + 1);
            }
        }
        out += to_string(ans);
        out += '\n';
    }
    fputs(out.c_str(), stdout);
    return 0;
}
