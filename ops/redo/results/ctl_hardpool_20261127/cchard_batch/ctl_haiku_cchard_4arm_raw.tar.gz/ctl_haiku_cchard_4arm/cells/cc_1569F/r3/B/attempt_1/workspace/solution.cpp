#include <bits/stdc++.h>
using namespace std;

int n, m, k;
bool adj[12][12];
vector<vector<pair<int,int>>> matchings;  // all perfect matchings of [n]
vector<pair<int,int>> cur;

void genMatchings(int used) {
    if (used == (1 << n) - 1) {
        matchings.push_back(cur);
        return;
    }
    int v = 0;
    while (used >> v & 1) v++;
    for (int u = v + 1; u < n; u++) {
        if (used >> u & 1) continue;
        cur.push_back({v, u});
        genMatchings(used | (1 << v) | (1 << u));
        cur.pop_back();
    }
}

// Is there an ordering and orientation of the pairs forming a palindromic path?
// Pair P_i = (a_i, b_i); need a_i~a_{i+1}, b_i~b_{i+1}, and a_h~b_h.
bool chainable(const vector<pair<int,int>>& M) {
    int h = M.size();
    // state: (mask of used pairs, last pair index, orientation o)
    // orientation o: 0 => a = M[idx].first, b = second; 1 => swapped
    int full = (1 << h) - 1;
    vector<vector<array<char, 2>>> reach(1 << h, vector<array<char, 2>>(h, {0, 0}));
    for (int i = 0; i < h; i++) {
        reach[1 << i][i][0] = 1;
        reach[1 << i][i][1] = 1;
    }
    for (int mask = 1; mask <= full; mask++) {
        for (int i = 0; i < h; i++) {
            if (!(mask >> i & 1)) continue;
            for (int o = 0; o < 2; o++) {
                if (!reach[mask][i][o]) continue;
                int a = o ? M[i].second : M[i].first;
                int b = o ? M[i].first : M[i].second;
                for (int j = 0; j < h; j++) {
                    if (mask >> j & 1) continue;
                    for (int p = 0; p < 2; p++) {
                        int a2 = p ? M[j].second : M[j].first;
                        int b2 = p ? M[j].first : M[j].second;
                        if (adj[a][a2] && adj[b][b2]) reach[mask | (1 << j)][j][p] = 1;
                    }
                }
            }
        }
    }
    for (int i = 0; i < h; i++) {
        for (int o = 0; o < 2; o++) {
            if (!reach[full][i][o]) continue;
            int a = o ? M[i].second : M[i].first;
            int b = o ? M[i].first : M[i].second;
            if (adj[a][b]) return true;
        }
    }
    return false;
}

// Enumerate all set partitions of the h pairs (restricted growth strings),
// map to vertex-level partitions, and record their canonical encodings.
void addCoarsenings(const vector<pair<int,int>>& M, vector<unsigned long long>& out) {
    int h = M.size();
    vector<int> g(h, 0);
    // recursive generation of RGS over h pairs
    function<void(int, int)> rec = [&](int idx, int maxLabel) {
        if (idx == h) {
            int vlab[12];
            for (int i = 0; i < h; i++) {
                vlab[M[i].first] = g[i];
                vlab[M[i].second] = g[i];
            }
            // canonical RGS over vertices
            int mp[12];
            for (int i = 0; i < 12; i++) mp[i] = -1;
            int nxt = 0;
            unsigned long long code = 0;
            for (int v = 0; v < n; v++) {
                if (mp[vlab[v]] < 0) mp[vlab[v]] = nxt++;
                code |= (unsigned long long)mp[vlab[v]] << (4 * v);
            }
            out.push_back(code);
            return;
        }
        for (int l = 0; l <= maxLabel + 1; l++) {
            g[idx] = l;
            rec(idx + 1, max(maxLabel, l));
        }
    };
    rec(0, -1);
}

int main() {
    if (!(cin >> n >> m >> k)) return 0;
    for (int i = 0; i < m; i++) {
        int v, u;
        cin >> v >> u;
        // Ignore self-loops and endpoints outside [1, n] (not valid per statement).
        if (v == u || v < 1 || u < 1 || v > n || u > n) continue;
        adj[v - 1][u - 1] = adj[u - 1][v - 1] = true;
    }
    genMatchings(0);

    vector<unsigned long long> codes;
    for (auto& M : matchings) {
        if (chainable(M)) addCoarsenings(M, codes);
    }
    sort(codes.begin(), codes.end());
    codes.erase(unique(codes.begin(), codes.end()), codes.end());

    long long ans = 0;
    for (unsigned long long c : codes) {
        int b = 0;
        for (int v = 0; v < n; v++) b = max(b, (int)((c >> (4 * v)) & 15) + 1);
        // number of strings whose level partition is exactly this: falling factorial k^(b)
        long long ways = 1;
        for (int i = 0; i < b; i++) {
            long long f = k - i;
            if (f <= 0) { ways = 0; break; }
            ways *= f;
        }
        ans += ways;
    }
    cout << ans << "\n";
    return 0;
}
