#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long ull;

// Reduction (sorted b_1 <= ... <= b_n, x = b_1):
//  - Every subset is good iff for all j: b_1 + ... + b_j <= x * b_j
//    (the subsets {i..j} with i > 1 have sum <= prefix sum up to j <= x*b_j <= b_i*b_j).
//  - Write b = x + d with d >= 0. Let D = total deviation of the chosen elements,
//    k = count of elements with value <= v. The constraint at value v becomes
//    k <= v, and if k == v then all deviations of those elements are 0; and D_total <= x.
// DP over values v = x..n+1 with state (k, D), weight prod 1/c_v!, times n! at the end.

int main() {
    long long n, M;
    cin >> n >> M;
    vector<ull> fact(n + 1), inv(n + 1);
    auto pw = [&](ull b, ull e) {
        ull r = 1 % M;
        b %= M;
        while (e) {
            if (e & 1) r = r * b % M;
            b = b * b % M;
            e >>= 1;
        }
        return r;
    };
    fact[0] = 1;
    for (int i = 1; i <= n; i++) fact[i] = fact[i - 1] * i % M;
    for (int i = 0; i <= n; i++) inv[i] = pw(fact[i], M - 2);

    ull ans = 0;
    for (long long x = 1; x <= n + 1; x++) {
        int W = (int)x;  // D ranges over [0, x]
        vector<vector<ull>> dp(n + 1, vector<ull>(W + 1, 0)), ndp;
        // value v = x, deviation 0, must have at least one element (min is exactly x)
        for (long long c = 1; c <= min(x, n); c++) dp[c][0] = inv[c];
        for (long long v = x + 1; v <= n + 1; v++) {
            long long d = v - x;
            ndp.assign(n + 1, vector<ull>(W + 1, 0));
            for (int k = 0; k <= n; k++) {
                for (int D = 0; D <= W; D++) {
                    ull cur = dp[k][D];
                    if (!cur) continue;
                    // c = 0
                    ndp[k][D] = (ndp[k][D] + cur) % M;
                    for (long long c = 1; k + c <= min<long long>(n, v); c++) {
                        long long D2 = D + c * d;
                        if (D2 > W) break;
                        long long k2 = k + c;
                        if (k2 == v && D2 != 0) continue;
                        ndp[k2][D2] = (ndp[k2][D2] + cur * inv[c]) % M;
                    }
                }
            }
            dp.swap(ndp);
        }
        for (int D = 0; D <= W; D++) ans = (ans + dp[n][D]) % M;
    }
    ans = ans * fact[n] % M;
    cout << ans << "\n";
    return 0;
}
