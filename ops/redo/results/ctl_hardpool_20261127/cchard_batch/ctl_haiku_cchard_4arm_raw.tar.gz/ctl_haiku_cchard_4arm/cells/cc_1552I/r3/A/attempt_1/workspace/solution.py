import sys
from collections import deque

MOD = 998244353


def popcount(x):
    return bin(x).count('1')


def overlap(a, b):
    # Two sets overlap: they intersect, and neither contains the other.
    return (a & b) != 0 and (a & ~b) != 0 and (b & ~a) != 0


def split_left(b, S):
    # Part of block b outside S comes first, then the part inside S.
    return [x for x in (b & ~S, b & S) if x]


def split_right(b, S):
    # Part of block b inside S comes first, then the part outside S.
    return [x for x in (b & S, b & ~S) if x]


def build_seq(members):
    """Arrange the classes of an overlap-connected family spanning its union.

    Returns the ordered list of blocks (bitmasks) or None if infeasible.
    The order is unique up to reversal, so the caller multiplies by 2.
    """
    k = len(members)
    visited = [False] * k
    visited[0] = True
    order = [members[0]]
    q = deque([0])
    while q:
        i = q.popleft()
        for j in range(k):
            if not visited[j] and overlap(members[i], members[j]):
                visited[j] = True
                order.append(members[j])
                q.append(j)

    seq = [order[0]]
    W = order[0]
    for S in order[1:]:
        N = S & ~W
        idx = [i for i, b in enumerate(seq) if b & S]
        if not idx:
            return None
        l, r = idx[0], idx[-1]
        if idx != list(range(l, r + 1)):
            return None
        for i in range(l + 1, r):
            if seq[i] & ~S:
                return None
        L = len(seq)
        if N:
            can_right = (r == L - 1) and (l == r or not (seq[r] & ~S))
            can_left = (l == 0) and (l == r or not (seq[l] & ~S))
            if can_right:
                new = seq[:l] + split_left(seq[l], S) + seq[l + 1:] + [N]
            elif can_left:
                new = [N] + seq[:r] + split_right(seq[r], S) + seq[r + 1:]
            else:
                return None
        else:
            if l == r:
                return None
            new = (seq[:l] + split_left(seq[l], S) + seq[l + 1:r]
                   + split_right(seq[r], S) + seq[r + 1:])
        seq = new
        W |= S
    return seq


def count(U, sets_in, fact):
    """Number of orderings of the elements of bitmask U where every set is contiguous."""
    nU = popcount(U)
    S = list({s for s in sets_in if s != U and popcount(s) >= 2})
    if not S:
        return fact[nU]

    k = len(S)
    comp_id = [-1] * k
    comps = []
    for i in range(k):
        if comp_id[i] != -1:
            continue
        cid = len(comps)
        comp_id[i] = cid
        stack = [i]
        members = []
        while stack:
            x = stack.pop()
            members.append(S[x])
            for j in range(k):
                if comp_id[j] == -1 and overlap(S[x], S[j]):
                    comp_id[j] = cid
                    stack.append(j)
        union = 0
        for mm in members:
            union |= mm
        comps.append((members, union))

    # Q-node: an overlap component spans all of U.
    for members, union in comps:
        if union == U:
            seq = build_seq(members)
            if seq is None:
                return 0
            res = 2
            for b in seq:
                sub = [s for s in S if s & ~b == 0]
                res = res * count(b, sub, fact) % MOD
                if res == 0:
                    return 0
            return res

    # P-node: maximal component unions are disjoint blocks, plus free singletons.
    unions = {u for _, u in comps}
    maximal = [u for u in unions if not any(v != u and (u & ~v) == 0 for v in unions)]
    covered = 0
    for u in maximal:
        covered |= u
    free = nU - popcount(covered)
    kk = len(maximal) + free
    res = fact[kk]
    for u in maximal:
        sub = [s for s in S if s & ~u == 0]
        res = res * count(u, sub, fact) % MOD
    return res


def main():
    sys.setrecursionlimit(10000)
    data = sys.stdin.read().split()
    it = iter(data)
    n = int(next(it))
    m = int(next(it))
    sets = []
    for _ in range(m):
        q = int(next(it))
        mask = 0
        for _ in range(q):
            s = int(next(it))
            mask |= 1 << (s - 1)
        sets.append(mask)

    fact = [1] * (n + 1)
    for i in range(1, n + 1):
        fact[i] = fact[i - 1] * i % MOD

    U = (1 << n) - 1
    print(count(U, sets, fact) % MOD)


if __name__ == "__main__":
    main()
