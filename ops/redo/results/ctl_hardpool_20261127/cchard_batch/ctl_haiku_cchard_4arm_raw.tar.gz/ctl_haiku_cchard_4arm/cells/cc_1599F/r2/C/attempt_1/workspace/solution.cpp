// Mars: for each query (L, R, D), decide whether the distinct city values in
// positions [L, R] can be linked by roads of length D on a circle of size P = 1e9+7.
//
// Model: a road joins x and x+D (mod P). The chosen cities must form a connected
// subgraph of this graph.
//  - k = 1 (all values equal in range)          -> Yes.
//  - D = 0 (no real roads), k >= 2              -> No.
//  - D != 0: P is prime, so multiplying by D^{-1} maps the graph onto the cycle
//    Z_P. The set is connected iff it is a cyclic run of consecutive residues,
//    i.e. the set is an arithmetic progression {s, s+D, ..., s+(k-1)D} mod P.
//
// Checking the AP: with m = S1/k and s = m - D(k-1)/2 (mod P), the set must match
// the AP. Two checks:
//   (a) sum of x^2 over the set equals the AP's sum of squares (mod P);
//   (b) a hash H = sum of r^x over the set, computed in F_Q where Q-1 is a
//       multiple of P and r has order P, so r^x depends only on x mod P. For the
//       AP, sum_j r^(s+jD) = r^s (1 - r^(kD)) / (1 - r^D).
// Distinct-value sums over [L, R] are computed offline with a Fenwick tree
// (each value counted only at its last occurrence up to the sweep position R).
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

static const ll P = 1000000007LL;
static const ll QH = 44000000309LL;  // prime, QH - 1 = 2 * P * 22

static ll pw(ll b, ll e, ll m) {
    __int128 r = 1, x = ((b % m) + m) % m;
    while (e > 0) {
        if (e & 1) r = r * x % m;
        x = x * x % m;
        e >>= 1;
    }
    return (ll)r;
}

static ll inv_mod(ll a, ll m) { return pw(a, m - 2, m); }

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, q;
    cin >> n >> q;
    vector<ll> A(n + 1);
    for (int i = 1; i <= n; i++) cin >> A[i];

    // Random element r of order P in F_QH.
    mt19937_64 rng(chrono::steady_clock::now().time_since_epoch().count());
    ll r = 1;
    while (r == 1) {
        ll a = 2 + (ll)(rng() % (unsigned long long)(QH - 3));
        r = pw(a, (QH - 1) / P, QH);
    }

    vector<ll> hv(n + 1), v2(n + 1);
    for (int i = 1; i <= n; i++) {
        hv[i] = pw(r, A[i] % P, QH);
        v2[i] = A[i] % P * (A[i] % P) % P;
    }

    // Fenwick trees: count, sum x (mod P), sum x^2 (mod P), sum r^x (mod QH).
    vector<ll> bc(n + 1, 0), b1(n + 1, 0), b2(n + 1, 0), bh(n + 1, 0);
    auto upd = [&](int i, ll dc, ll d1, ll d2, ll dh) {
        for (; i <= n; i += i & -i) {
            bc[i] += dc;
            b1[i] = (b1[i] + d1) % P;
            b2[i] = (b2[i] + d2) % P;
            bh[i] = (bh[i] + dh) % QH;
        }
    };
    struct Agg { ll c, s1, s2, h; };
    auto pre = [&](int i) {
        Agg g{0, 0, 0, 0};
        for (; i > 0; i -= i & -i) {
            g.c += bc[i];
            g.s1 = (g.s1 + b1[i]) % P;
            g.s2 = (g.s2 + b2[i]) % P;
            g.h = (g.h + bh[i]) % QH;
        }
        return g;
    };

    vector<array<ll, 3>> qs(q);  // L, R, D
    vector<vector<int>> byR(n + 1);
    for (int i = 0; i < q; i++) {
        ll L, R, D;
        cin >> L >> R >> D;
        qs[i] = {L, R, D};
        byR[R].push_back(i);
    }

    vector<char> ans(q, 0);

    // Map values to compact ids for last-occurrence tracking.
    vector<ll> sortedVals(A.begin() + 1, A.end());
    sort(sortedVals.begin(), sortedVals.end());
    sortedVals.erase(unique(sortedVals.begin(), sortedVals.end()), sortedVals.end());
    vector<int> id(n + 1);
    for (int i = 1; i <= n; i++)
        id[i] = (int)(lower_bound(sortedVals.begin(), sortedVals.end(), A[i]) - sortedVals.begin());
    vector<int> lastPos(sortedVals.size(), 0);

    for (int R = 1; R <= n; R++) {
        int pv = lastPos[id[R]];
        if (pv != 0) {
            upd(pv, -1, (P - A[pv] % P) % P, (P - v2[pv]) % P, (QH - hv[pv]) % QH);
        }
        upd(R, 1, A[R] % P, v2[R], hv[R]);
        lastPos[id[R]] = R;

        for (int qi : byR[R]) {
            ll L = qs[qi][0];
            ll D = qs[qi][2];
            Agg hi = pre(R), lo = pre(L - 1);
            ll k = hi.c - lo.c;
            ll S1 = ((hi.s1 - lo.s1) % P + P) % P;
            ll S2 = ((hi.s2 - lo.s2) % P + P) % P;
            ll H = ((hi.h - lo.h) % QH + QH) % QH;

            bool ok;
            if (k == 1) {
                ok = true;
            } else if (D % P == 0) {
                ok = false;
            } else {
                ll Dm = D % P;
                ll kk = k % P;
                ll invk = inv_mod(kk, P);
                ll inv2 = inv_mod(2, P);
                ll m = S1 * invk % P;
                ll half = (k - 1) % P * inv2 % P;
                ll s = ((m - Dm * half) % P + P) % P;

                // (a) sum of squares check.
                ll T1 = (k * (k - 1) / 2) % P;
                ll T2 = ((k - 1) * k % P) * ((2 * k - 1) % P) % P * inv_mod(6, P) % P;
                ll expS2 = (kk * s % P * s % P
                            + 2 * s % P * Dm % P * T1 % P
                            + Dm * Dm % P * T2 % P) % P;
                bool sq = (expS2 == S2);

                // (b) hash check.
                ll rD = pw(r, Dm, QH);
                ll rkD = pw(rD, k, QH);
                ll num = (1 - rkD + QH) % QH;
                ll den = (1 - rD + QH) % QH;
                ll expH = (ll)((__int128)pw(r, s, QH) * num % QH * pw(den, QH - 2, QH) % QH);
                ok = sq && (expH == H);
            }
            ans[qi] = ok ? 1 : 0;
        }
    }

    string out;
    out.reserve((size_t)q * 4);
    for (int i = 0; i < q; i++) {
        out += ans[i] ? "Yes\n" : "No\n";
    }
    cout << out;
    return 0;
}
