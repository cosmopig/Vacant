#include <bits/stdc++.h>
using namespace std;

typedef unsigned __int128 u128;

int n, m, k;
bool adj[12][12];
int pid[12][12];              // index of unordered pair {a,b} in 0..65
vector<u128> validMatch;      // for each valid perfect matching: bitmask of its pairs

// Check whether the perfect matching (given as list of h pairs) admits a palindromic
// Hamiltonian path: an ordering of the pairs with orientations such that consecutive
// pairs are joined by edges on both sides and the last pair's endpoints are adjacent.
bool palindromicOrderExists(const vector<pair<int,int>>& q) {
    int h = (int)q.size();
    // dp[S][i][o]: pairs in S used, last pair i with orientation o (0: (a,b), 1: (b,a))
    static bool dp[1 << 6][6][2];
    for (int S = 0; S < (1 << h); ++S)
        for (int i = 0; i < h; ++i)
            dp[S][i][0] = dp[S][i][1] = false;
    for (int i = 0; i < h; ++i) {
        dp[1 << i][i][0] = dp[1 << i][i][1] = true;
    }
    for (int S = 1; S < (1 << h); ++S) {
        for (int i = 0; i < h; ++i) {
            if (!(S >> i & 1)) continue;
            for (int o = 0; o < 2; ++o) {
                if (!dp[S][i][o]) continue;
                int x = o == 0 ? q[i].first : q[i].second;
                int y = o == 0 ? q[i].second : q[i].first;
                if (S == (1 << h) - 1) {
                    if (adj[x][y]) return true;
                    continue;
                }
                for (int j = 0; j < h; ++j) {
                    if (S >> j & 1) continue;
                    for (int p = 0; p < 2; ++p) {
                        int xx = p == 0 ? q[j].first : q[j].second;
                        int yy = p == 0 ? q[j].second : q[j].first;
                        if (adj[x][xx] && adj[y][yy]) dp[S | (1 << j)][j][p] = true;
                    }
                }
            }
        }
    }
    return false;
}

// Enumerate all perfect matchings of the vertices and keep those with a palindromic order.
void enumMatch(int used, vector<pair<int,int>>& cur) {
    int v = -1;
    for (int i = 0; i < n; ++i)
        if (!(used >> i & 1)) { v = i; break; }
    if (v < 0) {
        if (palindromicOrderExists(cur)) {
            u128 mk = 0;
            for (auto& pr : cur) mk |= (u128)1 << pid[pr.first][pr.second];
            validMatch.push_back(mk);
        }
        return;
    }
    for (int u = v + 1; u < n; ++u) {
        if (used >> u & 1) continue;
        cur.push_back({v, u});
        enumMatch(used | (1 << v) | (1 << u), cur);
        cur.pop_back();
    }
}

long long answer = 0;
long long perm[13];  // perm[t] = k*(k-1)*...*(k-t+1)

// Enumerate set partitions of the vertices into even-sized blocks.
void enumPart(int used, vector<int>& blockOf, int blocks) {
    int v = -1;
    for (int i = 0; i < n; ++i)
        if (!(used >> i & 1)) { v = i; break; }
    if (v < 0) {
        // Build mask of same-block pairs.
        u128 same = 0;
        for (int a = 0; a < n; ++a)
            for (int b = a + 1; b < n; ++b)
                if (blockOf[a] == blockOf[b]) same |= (u128)1 << pid[a][b];
        bool good = false;
        for (u128 mk : validMatch) {
            if ((mk & ~same) == 0) { good = true; break; }
        }
        if (good && blocks <= k) answer += perm[blocks];
        return;
    }
    // Block containing v: choose a subset of the remaining vertices (excluding v) of odd size.
    int rest = ((1 << n) - 1) & ~used & ~(1 << v);
    for (int sub = rest; ; sub = (sub - 1) & rest) {
        int sz = __builtin_popcount(sub) + 1;
        if (sz % 2 == 0) {
            int nb = blocks;
            for (int i = 0; i < n; ++i)
                if (sub >> i & 1) blockOf[i] = nb;
            blockOf[v] = nb;
            enumPart(used | sub | (1 << v), blockOf, blocks + 1);
        }
        if (sub == 0) break;
    }
}

int main() {
    if (!(cin >> n >> m >> k)) return 0;
    int idx = 0;
    for (int a = 0; a < 12; ++a)
        for (int b = a + 1; b < 12; ++b) {
            pid[a][b] = pid[b][a] = idx++;
        }
    for (int i = 0; i < m; ++i) {
        int v, u;
        cin >> v >> u;
        --v; --u;
        if (v < 0 || u < 0 || v >= n || u >= n || v == u) continue;
        adj[v][u] = adj[u][v] = true;
    }
    perm[0] = 1;
    for (int t = 1; t <= 12; ++t)
        perm[t] = (k - t + 1 > 0) ? perm[t - 1] * (k - t + 1) : 0;

    vector<pair<int,int>> cur;
    enumMatch(0, cur);

    vector<int> blockOf(n, 0);
    enumPart(0, blockOf, 0);
    cout << answer << "\n";
    return 0;
}
