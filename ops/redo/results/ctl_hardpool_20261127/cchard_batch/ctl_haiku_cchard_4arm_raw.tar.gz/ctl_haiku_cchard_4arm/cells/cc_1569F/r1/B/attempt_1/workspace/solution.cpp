#include <bits/stdc++.h>
using namespace std;

int n, m, k;
int adj[12];
long long ans = 0;

// Perfect matchings that admit a palindromic Hamiltonian path structure.
// partner[t][v] = bitmask of v's partner in matching t.
vector<array<int, 12>> good;

static bool admissible(const vector<pair<int, int>> &pr) {
    int p = pr.size();
    // dp[S][j][o]: pairs in S placed, last pair j, o selects which vertex is the "outer-left" x.
    static bool dp[1 << 6][6][2];
    memset(dp, 0, sizeof(dp));
    for (int j = 0; j < p; j++)
        for (int o = 0; o < 2; o++) dp[1 << j][j][o] = true;
    for (int S = 1; S < (1 << p); S++)
        for (int j = 0; j < p; j++)
            for (int o = 0; o < 2; o++) {
                if (!dp[S][j][o]) continue;
                int x = o ? pr[j].second : pr[j].first;
                int y = o ? pr[j].first : pr[j].second;
                for (int l = 0; l < p; l++) {
                    if (S >> l & 1) continue;
                    for (int q = 0; q < 2; q++) {
                        int nx = q ? pr[l].second : pr[l].first;
                        int ny = q ? pr[l].first : pr[l].second;
                        if ((adj[x] >> nx & 1) && (adj[y] >> ny & 1))
                            dp[S | (1 << l)][l][q] = true;
                    }
                }
            }
    int full = (1 << p) - 1;
    for (int j = 0; j < p; j++)
        for (int o = 0; o < 2; o++) {
            if (!dp[full][j][o]) continue;
            int x = o ? pr[j].second : pr[j].first;
            int y = o ? pr[j].first : pr[j].second;
            if (adj[x] >> y & 1) return true;
        }
    return false;
}

static void genMatchings(int mask, vector<pair<int, int>> &cur) {
    if (mask == 0) {
        if (admissible(cur)) {
            array<int, 12> pm{};
            for (auto &e : cur) {
                pm[e.first] = 1 << e.second;
                pm[e.second] = 1 << e.first;
            }
            good.push_back(pm);
        }
        return;
    }
    int v = __builtin_ctz(mask);
    int rest = mask & ~(1 << v);
    for (int u = v + 1; u < n; u++) {
        if (!(rest >> u & 1)) continue;
        cur.push_back({v, u});
        genMatchings(rest & ~(1 << u), cur);
        cur.pop_back();
    }
}

static long long fall(int b) {
    long long r = 1;
    for (int i = 0; i < b; i++) {
        if (k - i <= 0) return 0;
        r *= (k - i);
    }
    return r;
}

// R: vertices not yet assigned to a block. alive: matchings whose edges all lie
// inside the blocks chosen so far or inside R.
static void rec(int R, const vector<int> &alive, int blocks) {
    if (R == 0) {
        if (!alive.empty()) ans += fall(blocks);
        return;
    }
    int v = __builtin_ctz(R);
    int rest = R & ~(1 << v);
    // enumerate subsets S of rest with |S| odd so that block B = S + {v} has even size
    for (int S = rest;; S = (S - 1) & rest) {
        if (__builtin_popcount(S) & 1) {
            int B = S | (1 << v);
            vector<int> na;
            na.reserve(alive.size());
            for (int t : alive) {
                bool ok = true;
                for (int u = 0; u < n && ok; u++)
                    if (B >> u & 1) {
                        if ((good[t][u] & ~B) != 0) ok = false;
                    }
                if (ok) na.push_back(t);
            }
            if (!na.empty()) rec(R & ~B, na, blocks + 1);
        }
        if (S == 0) break;
    }
}

int main() {
    scanf("%d %d %d", &n, &m, &k);
    for (int i = 0; i < m; i++) {
        int a, b;
        scanf("%d %d", &a, &b);
        a--; b--;
        adj[a] |= 1 << b;
        adj[b] |= 1 << a;
    }
    vector<pair<int, int>> cur;
    genMatchings((1 << n) - 1, cur);
    vector<int> alive(good.size());
    for (size_t i = 0; i < good.size(); i++) alive[i] = i;
    if (!good.empty()) rec((1 << n) - 1, alive, 0);
    printf("%lld\n", ans);
    return 0;
}
