// Mars: for each query [L,R] with road length D, decide whether the distinct
// city positions in the range (residues mod P = 1e9+7) are connected by edges
// x <-> x +- D (mod P).
//
// Idea: with u = D^{-1} mod P, map each residue v to k = u*v mod P. The edges
// become k <-> k+1 on a cycle of length P, so the distinct set is connected iff
// its k-values form one contiguous arc {c, ..., c+m-1} (mod P), m = #distinct.
// Offline (sweep by R, last-occurrence trick) we get the power sums of the
// distinct values for degrees 1..4; the arc condition is checked against them
// (c is forced by degree 1; degrees 2..4 are then verified).
#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long ull;
typedef long long ll;
static const ll P = 1000000007LL;

static ll pw(ll b, ll e) {
    b %= P; if (b < 0) b += P;
    ll r = 1;
    while (e > 0) {
        if (e & 1) r = r * b % P;
        b = b * b % P;
        e >>= 1;
    }
    return r;
}

int n, q;
// BIT storing: [0]=count, [1..4]=sum of v^1..v^4 (mod P)
struct Node { ll f[5]; };
vector<Node> bit;

void upd(int i, const ll* d) {
    for (; i <= n; i += i & -i)
        for (int t = 0; t < 5; ++t) {
            ll x = bit[i].f[t] + d[t];
            if (x >= P) x -= P;
            if (x < 0) x += P;
            bit[i].f[t] = x;
        }
}

void qry(int i, ll* out) {
    for (int t = 0; t < 5; ++t) out[t] = 0;
    for (; i > 0; i -= i & -i)
        for (int t = 0; t < 5; ++t) {
            out[t] += bit[i].f[t];
            if (out[t] >= P) out[t] -= P;
        }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    if (!(cin >> n >> q)) return 0;
    vector<ll> v(n + 1);
    for (int i = 1; i <= n; ++i) {
        ll x; cin >> x;
        x %= P; if (x < 0) x += P;
        v[i] = x;
    }
    vector<int> L(q), R(q);
    vector<ll> D(q);
    for (int i = 0; i < q; ++i) {
        cin >> L[i] >> R[i] >> D[i];
        D[i] %= P; if (D[i] < 0) D[i] += P;
    }

    // prev occurrence of each value
    vector<int> prv(n + 1, 0);
    {
        vector<pair<ll, int>> pr;
        pr.reserve(n);
        for (int i = 1; i <= n; ++i) pr.push_back({v[i], i});
        sort(pr.begin(), pr.end());
        for (int j = 1; j < (int)pr.size(); ++j)
            if (pr[j].first == pr[j - 1].first) prv[pr[j].second] = pr[j - 1].second;
    }

    // F[i][m] = sum_{t=0}^{m-1} t^i  (mod P), i = 0..4, m = 0..n+1
    vector<array<ll, 5>> F(n + 2);
    {
        array<ll, 5> acc{};
        F[0] = acc;  // m = 0: empty sum
        for (int m = 1; m <= n + 1; ++m) {
            ll t = (m - 1) % P;  // add term t = m-1 first, then store prefix sum over t < m
            ll p = 1;            // t^0 = 1 (also for t = 0)
            for (int e = 0; e < 5; ++e) {
                acc[e] = (acc[e] + p) % P;
                p = p * t % P;
            }
            F[m] = acc;
        }
    }
    // inverses 1..n
    vector<ll> inv(n + 2, 1);
    for (int i = 2; i <= n + 1; ++i) inv[i] = (P - (P / i) * inv[P % i] % P) % P;

    // binomials up to 4
    const ll C[5][5] = {{1, 0, 0, 0, 0}, {1, 1, 0, 0, 0}, {1, 2, 1, 0, 0}, {1, 3, 3, 1, 0}, {1, 4, 6, 4, 1}};

    bit.assign(n + 1, Node{{0, 0, 0, 0, 0}});

    vector<vector<int>> byR(n + 1);
    for (int i = 0; i < q; ++i) byR[R[i]].push_back(i);

    vector<char> ans(q, 0);
    for (int i = 1; i <= n; ++i) {
        // remove previous occurrence of the same value
        if (prv[i] > 0) {
            ll d[5];
            ll x = v[prv[i]], p = 1;
            d[0] = P - 1;  // -1
            for (int e = 1; e <= 4; ++e) { p = p * x % P; d[e] = (P - p) % P; }
            upd(prv[i], d);
        }
        {
            ll d[5];
            ll x = v[i], p = 1;
            d[0] = 1;
            for (int e = 1; e <= 4; ++e) { p = p * x % P; d[e] = p; }
            upd(i, d);
        }
        for (int qi : byR[i]) {
            ll hi[5], lo[5], s[5];
            qry(R[qi], hi);
            qry(L[qi] - 1, lo);
            for (int t = 0; t < 5; ++t) {
                s[t] = (hi[t] - lo[t]) % P;
                if (s[t] < 0) s[t] += P;
            }
            ll m = s[0];
            if (m <= 1) { ans[qi] = 1; continue; }
            if (D[qi] == 0) { ans[qi] = 0; continue; }
            ll u = pw(D[qi], P - 2);
            // degree-1 moment fixes the arc start c
            ll mm = (int)m;
            ll tri = (mm % P) * ((mm - 1) % P) % P * pw(2, P - 2) % P;  // m(m-1)/2
            ll c = ((u * s[1] % P) - tri + P) % P * inv[(int)m] % P;
            bool ok = true;
            ll uj = u;
            for (int j = 2; j <= 4 && ok; ++j) {
                uj = uj * u % P;  // u^j
                ll lhs = uj * s[j] % P;
                // T_j = sum_{t<m} (c+t)^j = sum_e C(j,e) c^{j-e} F[e][m]
                ll T = 0;
                for (int e = 0; e <= j; ++e) {
                    T = (T + C[j][e] * pw(c, j - e) % P * F[(int)m][e]) % P;
                }
                if (lhs != T) ok = false;
            }
            ans[qi] = ok ? 1 : 0;
        }
    }

    string out;
    out.reserve((size_t)q * 4);
    for (int i = 0; i < q; ++i) out += ans[i] ? "Yes\n" : "No\n";
    cout << out;
    return 0;
}
