#include <bits/stdc++.h>
using namespace std;

static const uint64_t MOD = 998244353ULL;

static uint64_t pw_mod(uint64_t b, uint64_t e) {
    uint64_t r = 1;
    b %= MOD;
    while (e) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    vector<long long> N(t), K(t), X(t);
    long long maxK = 1;
    for (int i = 0; i < t; i++) {
        cin >> N[i] >> K[i] >> X[i];
        maxK = max(maxK, K[i]);
    }

    // pow2[i] = 2^i mod MOD for i in [0, maxK]
    vector<uint32_t> pow2(maxK + 1);
    pow2[0] = 1;
    for (long long i = 1; i <= maxK; i++) pow2[i] = (uint32_t)((uint64_t)pow2[i - 1] * 2 % MOD);

    // invd[i] = inverse of (2^i - 1) mod MOD for i in [1, maxK]
    // computed by batch inversion
    vector<uint32_t> invd(maxK + 1, 0);
    if (maxK >= 1) {
        vector<uint32_t> pref(maxK + 1, 1);  // pref[i] = prod_{j=1..i} (2^j - 1)
        for (long long i = 1; i <= maxK; i++) {
            uint64_t d = (pow2[i] + MOD - 1) % MOD;
            pref[i] = (uint32_t)((uint64_t)pref[i - 1] * d % MOD);
        }
        uint64_t inv = pw_mod(pref[maxK], MOD - 2);
        for (long long i = maxK; i >= 1; i--) {
            uint64_t d = (pow2[i] + MOD - 1) % MOD;
            invd[i] = (uint32_t)(inv * pref[i - 1] % MOD);
            inv = inv * d % MOD;
        }
    }

    string out;
    out.reserve((size_t)t * 11);
    for (int tc = 0; tc < t; tc++) {
        long long n = N[tc], k = K[tc], x = X[tc];
        uint64_t ans = 0;
        if (x == 0) {
            // Need a_1..a_n linearly independent over GF(2).
            if (n > k) {
                ans = 0;
            } else {
                ans = 1;
                uint64_t p2k = pow2[k];
                for (long long i = 0; i < n; i++) {
                    uint64_t term = (p2k + MOD - pow2[i]) % MOD;
                    ans = ans * term % MOD;
                }
            }
        } else {
            // x != 0: answer = sum_{r=0}^{min(n,k-1)} 2^r [k-1 choose r]_2 prod_{i<r}(2^n - 2^i)
            uint64_t pn = pw_mod(2, (uint64_t)n);  // 2^n mod MOD
            long long R = min(n, k - 1);
            uint64_t G = 1;  // gaussian binomial [k-1 choose r]_2
            uint64_t P = 1;  // prod_{i<r} (2^n - 2^i)
            ans = 1;         // r = 0 term
            for (long long r = 1; r <= R; r++) {
                // G(r) = G(r-1) * (2^{k-r} - 1) / (2^r - 1)
                uint64_t num = (pow2[k - r] + MOD - 1) % MOD;
                G = G * num % MOD * invd[r] % MOD;
                // P(r) = P(r-1) * (2^n - 2^{r-1})
                uint64_t factor = (pn + MOD - pow2[r - 1]) % MOD;
                P = P * factor % MOD;
                uint64_t term = (uint64_t)pow2[r] * G % MOD * P % MOD;
                ans = (ans + term) % MOD;
            }
        }
        out += to_string(ans);
        out += '\n';
    }
    cout << out;
    return 0;
}
