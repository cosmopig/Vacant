#include <bits/stdc++.h>
using namespace std;

// A segment [l,r] is simple iff for every prime p and every i in [l,r],
// S_p(i) >= S_p(l-1), where S_p(k) is the prefix sum of signed exponents of p
// ('*' contributes +e, '/' contributes -e).
// For each k = l-1, f(k) = first i > k where some prime's S_p drops below S_p(k)
// (n+1 if none). Then the number of simple segments starting at l is f(l-1) - l.

struct Range {
    int val, lo, hi;
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;
    vector<int> a(n + 1);
    for (int i = 1; i <= n; i++) cin >> a[i];
    string b;
    cin >> b;

    const int MAXA = 1000000;
    vector<int> spf(MAXA + 1, 0);
    for (int i = 2; i <= MAXA; i++) {
        if (spf[i] == 0) {
            for (long long j = i; j <= MAXA; j += i) {
                if (spf[j] == 0) spf[j] = i;
            }
        }
    }

    // events[p] = list of (position, signed exponent) for prime p, positions increasing.
    vector<vector<pair<int, int>>> events(MAXA + 1);
    for (int i = 1; i <= n; i++) {
        int x = a[i];
        int sgn = (b[i - 1] == '*') ? 1 : -1;
        while (x > 1) {
            int p = spf[x];
            int e = 0;
            while (x % p == 0) {
                x /= p;
                e++;
            }
            events[p].push_back({i, sgn * e});
        }
    }

    vector<Range> ranges;
    for (int p = 2; p <= MAXA; p++) {
        const auto &ev = events[p];
        if (ev.empty()) continue;
        int m = (int)ev.size();
        // pos[t] for t=1..m is the position of the t-th event; pos[0]=0 sentinel; pos[m+1]=n+1.
        vector<int> pos(m + 2);
        pos[0] = 0;
        for (int t = 1; t <= m; t++) pos[t] = ev[t - 1].first;
        pos[m + 1] = n + 1;
        // C[t] = prefix sum after t events; S_p(k) = C[t] for k in [pos[t], pos[t+1]-1].
        vector<long long> C(m + 1);
        C[0] = 0;
        for (int t = 1; t <= m; t++) C[t] = C[t - 1] + ev[t - 1].second;

        // nse[t] = first u > t with C[u] < C[t] (next strictly smaller), or -1.
        vector<int> nse(m + 1, -1);
        vector<int> st;
        for (int t = m; t >= 0; t--) {
            while (!st.empty() && C[st.back()] >= C[t]) st.pop_back();
            nse[t] = st.empty() ? -1 : st.back();
            st.push_back(t);
        }

        for (int t = 0; t <= m; t++) {
            int val = (nse[t] == -1) ? n + 1 : pos[nse[t]];
            int lo = pos[t];
            int hi = pos[t + 1] - 1;
            if (lo > hi) continue;
            ranges.push_back({val, lo, hi});
        }
    }

    sort(ranges.begin(), ranges.end(), [](const Range &x, const Range &y) { return x.val < y.val; });

    // f[k] = min over ranges covering k of val; assign in increasing val order with DSU "next unassigned".
    vector<int> f(n + 1, n + 1);
    vector<int> nxt(n + 2);
    for (int k = 0; k <= n + 1; k++) nxt[k] = k;
    auto findNext = [&](int x) {
        int r = x;
        while (nxt[r] != r) r = nxt[r];
        while (nxt[x] != r) {
            int y = nxt[x];
            nxt[x] = r;
            x = y;
        }
        return r;
    };
    for (const Range &r : ranges) {
        int k = findNext(r.lo);
        while (k <= r.hi) {
            f[k] = r.val;
            nxt[k] = k + 1;
            k = findNext(k + 1);
        }
    }

    long long ans = 0;
    for (int l = 1; l <= n; l++) {
        ans += (long long)(f[l - 1] - l);
    }
    cout << ans << "\n";
    return 0;
}
