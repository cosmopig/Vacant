import sys

MOD = 998244353


def main():
    data = sys.stdin.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    m = int(data[pos]); pos += 1
    sets = []
    for _ in range(m):
        q = int(data[pos]); pos += 1
        s = frozenset(int(x) for x in data[pos:pos + q])
        pos += q
        sets.append(s)
    fact = [1] * (n + 2)
    for i in range(1, n + 2):
        fact[i] = fact[i - 1] * i % MOD
    universe = frozenset(range(1, n + 1))
    print(count(universe, sets, fact) % MOD)


def overlaps(a, b):
    return bool(a & b) and not (a <= b) and not (b <= a)


def arrange(comp):
    """Order the sets of an overlap-connected component into a sequence of
    blocks (classes). Returns the block list, or None if impossible."""
    k = len(comp)
    adj = [[j for j in range(k) if j != i and overlaps(comp[i], comp[j])] for i in range(k)]
    order = [0]
    seen = [False] * k
    seen[0] = True
    q = 0
    while q < len(order):
        u = order[q]; q += 1
        for v in adj[u]:
            if not seen[v]:
                seen[v] = True
                order.append(v)
    first = comp[order[0]]
    seq = [first]
    covered = set(first)
    for idx in order[1:]:
        T = comp[idx]
        new = T - covered
        hit = [i for i, B in enumerate(seq) if B & T]
        if not hit:
            return None
        l, r = hit[0], hit[-1]

        def full(i):
            return seq[i] <= T

        def partial(i):
            return (seq[i] & T) and not (seq[i] <= T)

        if new:
            last = len(seq) - 1
            canR = (r == last) and all(full(i) for i in range(l + 1, r + 1))
            canL = (l == 0) and all(full(i) for i in range(l, r))
            if canR:
                mid = [seq[l] - T, seq[l] & T] if partial(l) else [seq[l]]
                mid = [b for b in mid if b]
                seq = seq[:l] + mid + seq[l + 1:] + [frozenset(new)]
            elif canL:
                mid = [seq[r] & T, seq[r] - T] if partial(r) else [seq[r]]
                mid = [b for b in mid if b]
                seq = [frozenset(new)] + seq[:r] + mid + seq[r + 1:]
            else:
                return None
        else:
            if l == r:
                return None
            if not all(full(i) for i in range(l + 1, r)):
                return None
            left = [seq[l] - T, seq[l] & T] if partial(l) else [seq[l]]
            right = [seq[r] & T, seq[r] - T] if partial(r) else [seq[r]]
            left = [b for b in left if b]
            right = [b for b in right if b]
            seq = seq[:l] + left + seq[l + 1:r] + right + seq[r + 1:]
        covered |= T
    return seq


def count(U, S, fact):
    """Number of orderings of U in which every set of S is contiguous.
    All sets in S are subsets of U."""
    sets = list({s for s in S if 2 <= len(s) < len(U)})
    if not sets:
        return fact[len(U)]
    k = len(sets)
    parent = list(range(k))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for i in range(k):
        for j in range(i + 1, k):
            if overlaps(sets[i], sets[j]):
                parent[find(i)] = find(j)
    comps = {}
    for i in range(k):
        comps.setdefault(find(i), []).append(sets[i])
    comps = list(comps.values())
    unions = [frozenset().union(*c) for c in comps]

    for c, un in zip(comps, unions):
        if un == U:
            blocks = arrange(c)
            if blocks is None:
                return 0
            res = 2
            for B in blocks:
                sub = [s for s in sets if s <= B]
                res = res * count(B, sub, fact) % MOD
                if res == 0:
                    return 0
            return res

    maxima = set()
    for un in unions:
        if not any(un < other for other in unions):
            maxima.add(un)
    maxima = list(maxima)
    covered = frozenset().union(*maxima)
    kk = len(maxima) + (len(U) - len(covered))
    res = fact[kk]
    for M in maxima:
        sub = [s for s in sets if s <= M]
        res = res * count(M, sub, fact) % MOD
        if res == 0:
            return 0
    return res


if __name__ == "__main__":
    main()
