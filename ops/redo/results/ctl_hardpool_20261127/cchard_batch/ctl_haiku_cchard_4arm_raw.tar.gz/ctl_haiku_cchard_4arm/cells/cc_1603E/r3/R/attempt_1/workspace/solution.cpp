// Count perfect sequences modulo prime M.
//
// Reduction (verified by brute force for n <= 6): a sequence is perfect iff,
// with m = its minimum, for every value y (m <= y <= n+1):
//     m * y >= sum of all elements <= y.
// Writing t = number of elements <= y and e = sum over elements of (a - m),
// the sum of elements <= y equals t*m + e, so the condition is e <= m*(y - t).
//
// For each minimum m we run a DP over values v = m..n+1 with state (t, e):
// t = elements placed so far (all <= v), e = accumulated excess. Placing c
// copies of v gets weight 1/c! (exponential generating function), so the answer
// is n! * (sum of final DP weights over all m).
//
// Pruning (all valid, since e never decreases and the final e must be <= m):
//   * after value v: e <= m*(v - t)                       (the constraint at v)
//   * after value v <= n: the n - t unplaced elements have values >= v+1, each
//     adding >= v+1-m excess, so e + (n - t)*(v+1-m) <= m.
//   * the minimum m needs c_m <= m and k = n - c_m <= m, so 2m >= n.
#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long u64;
typedef long long ll;

static u64 MOD;
static u64 BR;  // floor(2^64 / MOD), for Barrett reduction

// x mod MOD for any 64-bit x (no hardware division).
static inline u64 barrett(u64 x) {
    u64 q = (u64)(((unsigned __int128)x * BR) >> 64);
    u64 r = x - q * MOD;
    while (r >= MOD) r -= MOD;
    return r;
}

static u64 pw(u64 b, u64 e) {
    u64 r = 1 % MOD;
    b %= MOD;
    while (e) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

int main() {
    int n;
    ll M;
    if (!(cin >> n >> M)) return 0;
    MOD = (u64)M;
    BR = (u64)(((unsigned __int128)1 << 64) / MOD);

    vector<u64> invfact(n + 1), fact(n + 1);
    fact[0] = 1;
    for (int i = 1; i <= n; i++) fact[i] = fact[i - 1] * i % MOD;
    for (int i = 0; i <= n; i++) invfact[i] = pw(fact[i], MOD - 2);

    // Lazy accumulation: products are < MOD^2; keep sums below 2^64 by
    // subtracting K = 8*MOD^2 (a multiple of MOD) whenever we exceed it.
    const u64 K = 8ULL * MOD * MOD;
    const int W = n + 2;  // row width (e in 0..n+1)

    vector<u64> f((n + 1) * W), g((n + 1) * W);
    vector<int> eprev(n + 1), ecur(n + 1);
    u64 total = 0;

    // Largest live excess for a state with t placed after processing value v.
    // Returns -1 if no state is live.
    auto liveMax = [&](int m, int v, int t) -> int {
        if (t > v) return -1;
        ll lim = (ll)m * ((ll)v - t);
        if (lim > m) lim = m;
        if (v <= n) {
            ll rest = (ll)m - (ll)(n - t) * (ll)(v + 1 - m);
            if (rest < lim) lim = rest;
        }
        return lim < 0 ? -1 : (int)lim;
    };

    for (int m = 1; m <= n + 1; m++) {
        if (2 * m < n) continue;  // impossible, see header
        // Initial state: nothing placed, excess 0. Row 0 is live up to e = 0.
        fill(f.begin(), f.end(), 0);
        f[0] = 1;
        for (int t = 0; t <= n; t++) eprev[t] = (t == 0) ? 0 : -1;

        for (int v = m; v <= n + 1; v++) {
            const int d = v - m;
            const int tnew = min(n, v);
            for (int t = 0; t <= tnew; t++) ecur[t] = liveMax(m, v, t);
            for (int t = tnew + 1; t <= n; t++) ecur[t] = -1;

            // Zero the live part of g.
            for (int t = 0; t <= tnew; t++)
                for (int e = 0; e <= ecur[t]; e++) g[t * W + e] = 0;

            const int cmin = (v == m) ? 1 : 0;  // the minimum value must appear
            for (int t = 0; t <= tnew; t++) {
                const int hiSrc = eprev[t];  // live cells of f in row t
                if (hiSrc < 0) continue;
                const u64 *src = &f[t * W];
                for (int c = cmin; t + c <= tnew; c++) {
                    const int shift = c * d;
                    const int tc = t + c;
                    if (ecur[tc] < 0) continue;
                    const int hi = min(hiSrc, ecur[tc] - shift);  // src e with dst live
                    if (hi < 0) continue;  // no live destination for this c
                    const u64 ic = invfact[c];
                    u64 *dst = &g[tc * W + shift];
                    for (int e = 0; e <= hi; e++) {
                        u64 x = dst[e] + src[e] * ic;
                        dst[e] = (x >= K) ? x - K : x;
                    }
                }
            }

            // Reduce live cells of g; they become the new f.
            for (int t = 0; t <= tnew; t++) {
                u64 *row = &g[t * W];
                for (int e = 0; e <= ecur[t]; e++)
                    if (row[e]) row[e] = barrett(row[e]);
            }
            swap(f, g);
            for (int t = 0; t <= n; t++) eprev[t] = ecur[t];
        }
        // After processing value n+1, count the length-n multisets (t = n).
        for (int e = 0; e <= eprev[n]; e++) total = (total + f[n * W + e]) % MOD;
    }

    total = total * fact[n] % MOD;
    cout << total << endl;
    return 0;
}
