#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long u64;
typedef unsigned int u32;
static const u64 MOD = 998244353ULL;

static u64 pw(u64 b, u64 e) {
    u64 r = 1;
    b %= MOD;
    while (e) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

int main() {
    int t;
    if (scanf("%d", &t) != 1) return 0;
    vector<array<long long, 3>> qs(t);
    long long maxk = 1;
    for (auto &q : qs) {
        scanf("%lld %lld %lld", &q[0], &q[1], &q[2]);
        maxk = max(maxk, q[1]);
    }

    // inv[s] = (2^s - 1)^{-1} mod p for 1 <= s <= maxk (batch inversion).
    int M = (int)maxk;
    vector<u32> d(M + 1), pre(M + 1), inv(M + 1, 0);
    {
        u64 p2 = 1;  // 2^s
        for (int s = 0; s <= M; s++) {
            d[s] = (u32)((p2 + MOD - 1) % MOD);
            p2 = p2 * 2 % MOD;
        }
        u64 acc = 1;
        pre[0] = 1;
        for (int s = 1; s <= M; s++) {
            acc = acc * d[s] % MOD;
            pre[s] = (u32)acc;
        }
        u64 ip = pw(acc, MOD - 2);
        for (int s = M; s >= 1; s--) {
            inv[s] = (u32)(ip * pre[s - 1] % MOD);
            ip = ip * d[s] % MOD;
        }
    }
    const u64 inv2 = (MOD + 1) / 2;

    string out;
    out.reserve((size_t)t * 12);
    for (auto &q : qs) {
        long long n = q[0], k = q[1], x = q[2];
        u64 ans = 0;
        if (x == 0) {
            // Need n linearly independent vectors: prod_{i<n} (2^k - 2^i), zero if n > k.
            if (n <= k) {
                u64 K = pw(2, k);
                u64 cur = 1;
                ans = 1;
                for (long long i = 0; i < n; i++) {
                    ans = ans * ((K + MOD - cur) % MOD) % MOD;
                    cur = cur * 2 % MOD;
                }
            }
        } else {
            // x != 0 forces k >= 1.
            // ans = sum_{r=0}^{min(n,k)} ( G(k,r) - G(k-1,r-1) ) * prod_{i<r} (2^n - 2^i)
            // G(m,s) = Gaussian binomial [m choose s]_2.
            long long R = min(n, k);
            u64 q2n = pw(2, n);
            u64 A = 1;     // G(k, r)
            u64 B = 1;     // G(k-1, r-1), starts as G(k-1,0)=1 for r=1
            u64 F = 1;     // prod_{i<r} (2^n - 2^i)
            u64 c = 1;     // 2^{r-1}
            u64 e = pw(2, k - 1);  // 2^{k-r}, for r=1
            ans = 1;       // term r=0: G(k,0)*1 = 1 (G(k-1,-1)=0)
            for (long long r = 1; r <= R; r++) {
                u64 ir = inv[r];
                A = A * ((2 * e + MOD - 1) % MOD) % MOD * ir % MOD;  // G(k,r)
                F = F * ((q2n + MOD - c) % MOD) % MOD;               // f(r)
                u64 diff = (A + MOD - B) % MOD;
                ans = (ans + diff * F) % MOD;
                // B becomes G(k-1, r)
                B = B * ((e + MOD - 1) % MOD) % MOD * ir % MOD;
                e = e * inv2 % MOD;
                c = c * 2 % MOD;
            }
        }
        out += to_string(ans);
        out += '\n';
    }
    fputs(out.c_str(), stdout);
    return 0;
}
