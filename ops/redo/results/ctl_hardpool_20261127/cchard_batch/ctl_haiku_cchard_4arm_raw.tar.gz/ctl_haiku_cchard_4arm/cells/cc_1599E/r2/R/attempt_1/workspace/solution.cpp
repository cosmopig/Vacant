#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

static const ll MOD = 1000000007LL;

// Returns (F(n), F(n+1)) mod MOD using fast doubling.
static pair<ll, ll> fib(ll n) {
    if (n == 0) return {0, 1};
    pair<ll, ll> p = fib(n >> 1);
    ll a = p.first, b = p.second;
    ll t = (2 * b - a) % MOD;
    if (t < 0) t += MOD;
    ll c = a * t % MOD;             // F(2k)
    ll d = (a * a + b * b) % MOD;   // F(2k+1)
    if (n & 1) return {d, (c + d) % MOD};
    return {c, d};
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, q;
    cin >> n >> q;
    vector<ll> A[2];
    A[0].assign(n + 1, 0);
    A[1].assign(n + 1, 0);
    for (int i = 1; i <= n; i++) cin >> A[0][i];
    for (int i = 1; i <= n; i++) cin >> A[1][i];

    string out;
    for (int qi = 0; qi < q; qi++) {
        int t;
        cin >> t;
        if (t == 4) {
            int l, r;
            cin >> l >> r;
            ll sum = 0;
            for (int i = l; i <= r; i++) {
                sum += fib(A[0][i] + A[1][i]).first;
                if (sum >= MOD) sum -= MOD;
            }
            out += to_string(sum);
            out += '\n';
        } else {
            int k, l, r;
            ll x;
            cin >> k >> l >> r >> x;
            vector<ll>& arr = A[k - 1];
            if (t == 1) {
                for (int i = l; i <= r; i++) arr[i] = min(arr[i], x);
            } else if (t == 2) {
                for (int i = l; i <= r; i++) arr[i] = max(arr[i], x);
            } else {
                for (int i = l; i <= r; i++) arr[i] += x;
            }
        }
    }
    cout << out;
    return 0;
}
