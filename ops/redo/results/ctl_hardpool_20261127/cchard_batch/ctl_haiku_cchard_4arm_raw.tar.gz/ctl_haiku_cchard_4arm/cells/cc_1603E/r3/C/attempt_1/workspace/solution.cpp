#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

// A sequence is perfect iff, with m = min(a), for every y >= m:
//     sum_{a_i <= y} a_i <= m * y.
// (Any subsequence with min x, max y has sum <= sum of all elements in [m, y] <= m*y <= x*y,
//  and the condition at present values y is necessary by taking all elements in [m, y].)
// Writing d = a - m, D = sum of d over elements <= y, k = count of elements <= y,
// the condition becomes D <= m * (y - k).
// For each exact minimum m we run a DP over values v = m..n+1 with state (k, D),
// D <= m (since the total excess is bounded by m at y = n+1), weighting by 1/c!.
// The answer is n! times the sum of the EGF weights.
int main() {
    ll n, M;
    cin >> n >> M;

    vector<ll> fact(n + 1), inv(n + 1);
    auto pw = [&](ll b, ll e) {
        ll r = 1 % M;
        b %= M;
        while (e > 0) {
            if (e & 1) r = r * b % M;
            b = b * b % M;
            e >>= 1;
        }
        return r;
    };
    fact[0] = 1 % M;
    for (ll i = 1; i <= n; i++) fact[i] = fact[i - 1] * i % M;
    for (ll i = 0; i <= n; i++) inv[i] = pw(fact[i], M - 2);

    // fast a*b mod M for a,b < M < 2^30: quotient estimated in double, off by at most 1
    const double invM = 1.0 / (double)M;
    auto mulm = [&](ll a, ll b) -> ll {
        ll p = a * b;
        ll q = (ll)((double)a * (double)b * invM);
        ll r = p - q * M;
        if (r < 0) r += M;
        else if (r >= M) r -= M;
        return r;
    };

    ll ans = 0;
    for (ll m = 1; m <= n + 1; m++) {
        vector<vector<ll>> dp(n + 1, vector<ll>(m + 1, 0)), nd;
        dp[0][0] = 1;
        for (ll v = m; v <= n + 1; v++) {
            ll d = v - m;
            nd.assign(n + 1, vector<ll>(m + 1, 0));
            // before processing v, count k <= v-1 (enforced by the constraint at v-1)
            for (ll k = 0; k <= min(n, v - 1); k++) {
                for (ll D = 0; D <= m; D++) {
                    ll cur = dp[k][D];
                    if (cur == 0) continue;
                    ll cmax = (d == 0) ? (n - k) : min(n - k, (m - D) / d);
                    for (ll c = (v == m ? 1 : 0); c <= cmax; c++) {
                        ll k2 = k + c, D2 = D + c * d;
                        if (D2 > m) break;
                        if (D2 > m * (v - k2)) break;  // monotone in c: larger c only fails more
                        nd[k2][D2] += mulm(cur, inv[c]);
                        if (nd[k2][D2] >= M) nd[k2][D2] -= M;
                    }
                }
            }
            dp.swap(nd);
        }
        for (ll D = 0; D <= m; D++) {
            ans = (ans + dp[n][D] * fact[n]) % M;
        }
    }
    cout << ans % M << "\n";
    return 0;
}
