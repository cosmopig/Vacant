import sys

MOD = 998244353
FACT = [1] * 205
for _i in range(1, 205):
    FACT[_i] = FACT[_i - 1] * _i % MOD


def overlap(a, b):
    return bool(a & b) and not (a <= b) and not (b <= a)


def solve_chain(comp_sets):
    """comp_sets: sets of one overlap component in BFS order (each overlaps an earlier one).
    Returns the ordered list of blocks (membership classes), or None if impossible."""
    blocks = [set(comp_sets[0])]
    W = set(comp_sets[0])
    for S in comp_sets[1:]:
        new = S - W
        idx = [i for i, B in enumerate(blocks) if B & S]
        if not idx:
            return None
        l, r = idx[0], idx[-1]
        if idx != list(range(l, r + 1)):
            return None
        for i in range(l + 1, r):
            if not blocks[i] <= S:
                return None
        k = len(blocks)
        if new:
            can_right = (r == k - 1) and (l == r or blocks[r] <= S)
            can_left = (l == 0) and (l == r or blocks[l] <= S)
            if can_right:
                nb = blocks[:l]
                for part in (blocks[l] - S, blocks[l] & S):
                    if part:
                        nb.append(part)
                nb.extend(blocks[l + 1:])
                nb.append(set(new))
            elif can_left:
                nb = [set(new)]
                nb.extend(blocks[:r])
                for part in (blocks[r] & S, blocks[r] - S):
                    if part:
                        nb.append(part)
                nb.extend(blocks[r + 1:])
            else:
                return None
            blocks = nb
            W |= S
        else:
            if l == r:
                return None  # cannot happen for BFS order over overlap graph
            nb = blocks[:l]
            for part in (blocks[l] - S, blocks[l] & S):
                if part:
                    nb.append(part)
            nb.extend(blocks[l + 1:r])
            for part in (blocks[r] & S, blocks[r] - S):
                if part:
                    nb.append(part)
            nb.extend(blocks[r + 1:])
            blocks = nb
    return blocks


def count(U, F):
    """Number of orderings of set U in which every set of F (subsets of U) is contiguous."""
    n = len(U)
    F = list({frozenset(S) for S in F if 2 <= len(S) < n})
    if not F:
        return FACT[n]
    k = len(F)
    seen = [False] * k
    comps = []  # (bfs-ordered list of set indices, union)
    for s in range(k):
        if seen[s]:
            continue
        seen[s] = True
        order = [s]
        q = [s]
        while q:
            x = q.pop(0)
            for y in range(k):
                if not seen[y] and overlap(F[x], F[y]):
                    seen[y] = True
                    order.append(y)
                    q.append(y)
        union = set()
        for x in order:
            union |= F[x]
        comps.append((order, frozenset(union)))

    # Case B: a multi-set overlap component covering all of U -> Q-node
    for order, union in comps:
        if len(order) >= 2 and union == U:
            blocks = solve_chain([F[x] for x in order])
            if blocks is None:
                return 0
            res = 2
            for B in blocks:
                sub = [S for S in F if S <= B]
                res = res * count(frozenset(B), sub) % MOD
                if res == 0:
                    return 0
            return res

    # Case A: maximal component unions are disjoint proper blocks -> P-node
    unions = list({u for _, u in comps})
    maximal = [u for u in unions if not any(u < v for v in unions)]
    covered = 0
    for T in maximal:
        covered += len(T)
    items = len(maximal) + (n - covered)
    res = FACT[items]
    for T in maximal:
        sub = [S for S in F if S <= T]
        res = res * count(T, sub) % MOD
        if res == 0:
            return 0
    return res


def main():
    data = sys.stdin.read().split()
    p = 0
    n = int(data[p]); p += 1
    m = int(data[p]); p += 1
    F = []
    for _ in range(m):
        q = int(data[p]); p += 1
        S = frozenset(int(x) for x in data[p:p + q])
        p += q
        F.append(S)
    print(count(frozenset(range(1, n + 1)), F) % MOD)


if __name__ == "__main__":
    main()
