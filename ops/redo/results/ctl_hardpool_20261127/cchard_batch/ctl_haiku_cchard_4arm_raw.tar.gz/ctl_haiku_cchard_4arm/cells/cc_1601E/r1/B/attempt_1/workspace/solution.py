import sys
from bisect import bisect_left
from collections import deque


def main():
    data = sys.stdin.buffer.read().split()
    n, q, k = int(data[0]), int(data[1]), int(data[2])
    a = [0] * (n + 1)
    for i in range(n):
        a[i + 1] = int(data[3 + i])
    ptr = 3 + n
    ql = [0] * q
    qr = [0] * q
    for i in range(q):
        ql[i] = int(data[ptr])
        qr[i] = int(data[ptr + 1])
        ptr += 2

    ans = [0] * q
    # W[b] = min(a[b-k+1 .. b]) for b >= k  (block of the chain step ending at b)
    W = [0] * (n + 1)
    dq = deque()
    for b in range(1, n + 1):
        v = a[b]
        while dq and a[dq[-1]] >= v:
            dq.pop()
        dq.append(b)
        if dq[0] <= b - k:
            dq.popleft()
        if b >= k:
            W[b] = a[dq[0]]

    # Queries needing chain steps: b0 = l + k <= r. Others cost just a[l].
    # Group by residue class c = b0 mod k, sorted by b0 descending.
    buckets = {}
    for i in range(q):
        l = ql[i]
        r = qr[i]
        b0 = l + k
        if b0 > r:
            ans[i] = a[l]
        else:
            c = b0 % k
            buckets.setdefault(c, []).append((b0, i))

    for c, lst in buckets.items():
        lst.sort(reverse=True)
        qi = 0
        m = len(lst)
        # Monotonic stack over positions b = c+k, c+2k, ... (all >= k), processed descending.
        # Wl: W values strictly increasing bottom->top.
        # NPl: negated positions, strictly increasing bottom->top.
        # Gl: G[b] = sum over chain points x >= b (within n) of min-prefix PM(x) from b.
        Wl = []
        NPl = []
        Gl = []
        top = n - ((n - c) % k)
        start = c + k
        b = top
        while b >= start:
            w = W[b]
            while Wl and Wl[-1] >= w:
                Wl.pop()
                NPl.pop()
                Gl.pop()
            if Wl:
                nxt = -NPl[-1]
                cnt = (nxt - b) // k
                g = w * cnt + Gl[-1]
            else:
                cnt = (n - b) // k + 1
                g = w * cnt
            Wl.append(w)
            NPl.append(-b)
            Gl.append(g)

            while qi < m and lst[qi][0] == b:
                i = lst[qi][1]
                qi += 1
                R = qr[i]
                l = b - k
                e = a[l]
                idx = bisect_left(Wl, e) - 1
                if idx >= 0 and -NPl[idx] <= R:
                    py = -NPl[idx]
                    cnt_e = (py - b) // k
                    j0 = bisect_left(NPl, -R)
                    pz = -NPl[j0]
                    rest = (Gl[idx] - Gl[j0]) + Wl[j0] * ((R - pz) // k + 1)
                else:
                    cnt_e = (R - b) // k + 1
                    rest = 0
                ans[i] = a[l] + e * cnt_e + rest
            b -= k

    sys.stdout.write("\n".join(map(str, ans)) + "\n")


main()
