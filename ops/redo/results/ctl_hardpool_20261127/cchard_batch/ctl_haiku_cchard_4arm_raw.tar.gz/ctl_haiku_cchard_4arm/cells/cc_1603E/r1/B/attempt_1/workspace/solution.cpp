#include <bits/stdc++.h>
using namespace std;

// Characterisation (derived):
// A sequence is perfect iff, with a = min, b = max, and sum over elements of
// (v - a) = E:
//   * constant sequences: every value v in {n, n+1} (one sequence each);
//   * otherwise b = n+1 is present, E <= a, the number of a's is n - m with
//     1 <= n - m <= a (m = number of elements > a), and for every present value
//     hi in (a, n+1) at least n+1-hi elements are > hi.
// Counting uses multinomial coefficients, summed by a DP over values in
// decreasing order with state (r = #elements above, F = excess sum so far).

int main() {
    long long n, M;
    cin >> n >> M;

    auto pw = [&](long long b, long long e) {
        long long r = 1 % M;
        b %= M;
        while (e > 0) {
            if (e & 1) r = r * b % M;
            b = b * b % M;
            e >>= 1;
        }
        return r;
    };

    int N = (int)n;
    vector<long long> fact(N + 2), inv(N + 2);
    fact[0] = 1;
    for (int i = 1; i <= N + 1; i++) fact[i] = fact[i - 1] * i % M;
    for (int i = 0; i <= N + 1; i++) inv[i] = pw(fact[i], M - 2);

    long long ans = 0;
    // constant sequences
    ans = (ans + 2) % M;  // values n and n+1 (n >= 1 so both are valid)

    for (int a = 1; a <= N; a++) {
        int A = a;  // states: r in [0, A], F in [0, A]
        vector<vector<long long>> dp(A + 1, vector<long long>(A + 1, 0)), ndp;
        dp[0][0] = 1;
        for (int v = N + 1; v >= a + 1; v--) {
            int d = v - a;
            ndp.assign(A + 1, vector<long long>(A + 1, 0));
            for (int r = 0; r <= A; r++) {
                for (int F = 0; F <= A; F++) {
                    long long cur = dp[r][F];
                    if (!cur) continue;
                    for (int c = 0; F + c * d <= A && r + c <= A; c++) {
                        if (v == N + 1 && c == 0) continue;  // n+1 must be present
                        if (v < N + 1 && c > 0 && r < N + 1 - v) break;  // hi=v constraint
                        int nr = r + c, nF = F + c * d;
                        ndp[nr][nF] = (ndp[nr][nF] + cur * inv[c]) % M;
                    }
                }
            }
            swap(dp, ndp);
        }
        // m = number of elements > a; a appears n - m times
        for (int m = 1; m <= min(N - 1, A); m++) {  // m <= E <= a
            int ca = N - m;
            if (ca > a) continue;
            for (int F = 0; F <= A; F++) {
                long long cur = dp[m][F];
                if (!cur) continue;
                long long w = cur * fact[N] % M * inv[ca] % M;
                ans = (ans + w) % M;
            }
        }
    }
    cout << ans % M << "\n";
    return 0;
}
