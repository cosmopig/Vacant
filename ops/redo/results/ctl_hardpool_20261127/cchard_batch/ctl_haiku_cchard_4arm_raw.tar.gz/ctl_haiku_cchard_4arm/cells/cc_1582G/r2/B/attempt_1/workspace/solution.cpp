#include <bits/stdc++.h>
using namespace std;

// Count segments [l,r] whose every prefix product is an integer.
//
// For a fixed l, the valid r form a prefix [l, R(l)-1], so the answer is
// sum over l of (R(l) - l). Write E_p(i) for the exponent of prime p in the
// product of a_1..a_i (with '*' adding v_p(a_j) and '/' subtracting it).
// The prefix product from l is an integer at i iff E_p(i) >= E_p(l-1) for all p.
// So R(l) = min over p of nxt_p(l-1), where nxt_p(k) is the first i>k with
// E_p(i) < E_p(k).
//
// We sweep l from n down to 1 and keep D_p = nxt_p(l-1) for every prime in a
// segment tree (min). D_p only changes when p divides a_l. Using
// G(i) = E(i) - E(n) (computed from the right), each prime keeps a monotone
// "record" stack of suffix prefix-minima to answer the next-smaller query.

const int MAXV = 1000001;
const int SZ = 1 << 20;
int spf[MAXV];
int tree_[2 * SZ];

int main() {
    int n;
    if (scanf("%d", &n) != 1) return 0;
    vector<int> a(n + 1);
    for (int i = 1; i <= n; i++) scanf("%d", &a[i]);
    vector<char> b(n + 2);
    {
        string s;
        s.resize(n + 1);
        scanf("%s", &s[0]);
        for (int i = 1; i <= n; i++) b[i] = s[i - 1];
    }

    for (int i = 2; i < MAXV; i++) spf[i] = 0;
    for (int i = 2; i < MAXV; i++) {
        if (spf[i] == 0) {
            for (long long j = i; j < MAXV; j += i)
                if (spf[j] == 0) spf[j] = i;
        }
    }

    for (int i = 0; i < 2 * SZ; i++) tree_[i] = n + 1;

    vector<int> g(MAXV, 0);                       // current G(l) per prime
    vector<vector<pair<int, int>>> st(MAXV);      // (G, position) records

    long long ans = 0;
    for (int l = n; l >= 1; l--) {
        int x = a[l];
        int c = (b[l] == '*') ? 1 : -1;
        while (x > 1) {
            int p = spf[x];
            int e = 0;
            while (x % p == 0) { x /= p; e++; }
            int delta = c * e;  // change of E_p caused by a_l

            int D;
            vector<pair<int, int>> &S = st[p];
            if (c == -1) {
                D = l;  // E(l) < E(l-1): immediate break
            } else {
                int v = g[p] - delta;  // need G(i) < G(l-1) = G(l) - delta
                // S: G strictly increasing with index; find first idx with G >= v
                int lo = 0, hi = (int)S.size();
                while (lo < hi) {
                    int mid = (lo + hi) / 2;
                    if (S[mid].first >= v) hi = mid;
                    else lo = mid + 1;
                }
                D = (lo > 0) ? S[lo - 1].second : n + 1;
            }

            // update segment tree at leaf p
            int pos = p + SZ;
            tree_[pos] = D;
            for (pos >>= 1; pos >= 1; pos >>= 1)
                tree_[pos] = min(tree_[2 * pos], tree_[2 * pos + 1]);

            // push l into record stack
            int Gl = g[p];
            while (!S.empty() && S.back().first >= Gl) S.pop_back();
            S.push_back({Gl, l});

            g[p] -= delta;  // G(l-1) = G(l) - delta
        }
        int R = tree_[1];
        ans += (long long)(R - l);
    }
    printf("%lld\n", ans);
    return 0;
}
