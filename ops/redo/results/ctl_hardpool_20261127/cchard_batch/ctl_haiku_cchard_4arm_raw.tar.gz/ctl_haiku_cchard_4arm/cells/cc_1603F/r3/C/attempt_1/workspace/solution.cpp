#include <bits/stdc++.h>
using namespace std;

typedef unsigned long long ull;
static const ull MOD = 998244353ULL;

static ull pw(ull b, ull e) {
    b %= MOD;
    ull r = 1;
    while (e) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    vector<long long> N(t), K(t), X(t);
    long long maxK = 0;
    for (int i = 0; i < t; i++) {
        cin >> N[i] >> K[i] >> X[i];
        maxK = max(maxK, K[i]);
    }

    // F[i] = prod_{j=1}^{i} (2^j - 1), invF[i] = 1 / F[i]  (q-factorials for Gaussian binomials)
    // Only needed when some test has x != 0.
    bool needF = false;
    for (int i = 0; i < t; i++) if (X[i] != 0) { needF = true; break; }
    vector<uint32_t> F, invF;
    if (needF && maxK >= 1) {
        F.assign(maxK + 1, 0);
        invF.assign(maxK + 1, 0);
        F[0] = 1;
        ull p2 = 1;  // 2^i mod MOD
        for (long long i = 1; i <= maxK; i++) {
            p2 = p2 * 2 % MOD;
            ull v = (p2 + MOD - 1) % MOD;  // 2^i - 1
            F[i] = (uint32_t)((ull)F[i - 1] * v % MOD);
        }
        invF[maxK] = (uint32_t)pw(F[maxK], MOD - 2);
        const ull inv2 = (MOD + 1) / 2;
        p2 = pw(2, maxK);
        for (long long i = maxK; i >= 1; i--) {
            ull v = (p2 + MOD - 1) % MOD;  // 2^i - 1
            invF[i - 1] = (uint32_t)((ull)invF[i] * v % MOD);
            // move p2 from 2^i to 2^(i-1)
            p2 = p2 * inv2 % MOD;
        }
    }

    string out;
    out.reserve((size_t)t * 11);

    for (int tc = 0; tc < t; tc++) {
        long long n = N[tc], k = K[tc], x = X[tc];
        ull ans = 0;

        if (x == 0) {
            // All n vectors must be linearly independent over F_2.
            if (n > k) {
                ans = 0;
            } else {
                ull pk = pw(2, k);
                ull p2 = 1;  // 2^i
                ans = 1;
                for (long long i = 0; i < n; i++) {
                    ull term = (pk + MOD - p2) % MOD;
                    ans = ans * term % MOD;
                    p2 = p2 * 2 % MOD;
                }
            }
        } else {
            // x != 0 here implies k >= 1.
            // Answer = sum_{r=0}^{min(n,k)} (G(k,r) - G(k-1,r-1)) * prod_{i<r} (2^n - 2^i)
            // where G = Gaussian binomial over F_2.
            ull pn = pw(2, n);
            long long R = min(n, k);
            ull P = 1;   // prod_{i<r} (2^n - 2^i)
            ull p2 = 1;  // 2^r
            for (long long r = 0; r <= R; r++) {
                ull g1 = (ull)F[k] * invF[r] % MOD;  // F[k]/F[r]
                ull g2 = 0;
                if (r >= 1) g2 = (ull)F[k - 1] * invF[r - 1] % MOD;  // F[k-1]/F[r-1]
                ull diff = (g1 + MOD - g2) % MOD;
                ull coef = diff * invF[k - r] % MOD;  // divided by F[k-r]
                ans = (ans + coef * P) % MOD;
                // advance P to r+1: multiply by (2^n - 2^r)
                ull factor = (pn + MOD - p2) % MOD;
                P = P * factor % MOD;
                p2 = p2 * 2 % MOD;
            }
        }

        out += to_string(ans);
        out += '\n';
    }

    cout << out;
    return 0;
}
