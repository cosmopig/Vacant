// Mars: query answers via offline distinct-value range sums.
//
// Model: cities i and j are adjacent iff (A_i - A_j) == +-D (mod M), M = 1e9+7.
// For D != 0 (mod M), the distinct values in [L,R] must form an arithmetic
// progression with step D (mod M); duplicates attach to a shared neighbour, so
// only the distinct set matters when there are at least two distinct values.
// For D == 0 only equal values are adjacent, so the range must hold one value.
// With one distinct value and D != 0, the range must hold a single city.
//
// AP test: with k distinct values, the first step a is recovered from the power
// sums S1 = sum x (a = (S1 - D*K1)/k). S2 and S3 must then match the AP's sums.
// Distinct-value sums over [L,R] are computed offline: sweep R, keep one
// Fenwick entry per value (its last occurrence), query prefix differences.

#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

static const ll M = 1000000007LL;

ll pw(ll b, ll e) {
    b %= M;
    if (b < 0) b += M;
    ll r = 1;
    while (e) {
        if (e & 1) r = r * b % M;
        b = b * b % M;
        e >>= 1;
    }
    return r;
}

struct Fenwick {
    int n;
    vector<array<ll, 4>> t;  // count, sum x, sum x^2, sum x^3 (mod M)
    void init(int n_) {
        n = n_;
        t.assign(n + 1, array<ll, 4>{0, 0, 0, 0});
    }
    void add(int i, const array<ll, 4>& v) {
        for (; i <= n; i += i & -i)
            for (int c = 0; c < 4; c++) t[i][c] = (t[i][c] + v[c]) % M;
    }
    array<ll, 4> prefix(int i) const {
        array<ll, 4> s{0, 0, 0, 0};
        for (; i > 0; i -= i & -i)
            for (int c = 0; c < 4; c++) s[c] += t[i][c];
        for (int c = 0; c < 4; c++) s[c] %= M;
        return s;
    }
};

int main() {
    int N, Q;
    if (scanf("%d %d", &N, &Q) != 2) return 0;
    vector<ll> A(N + 1);
    for (int i = 1; i <= N; i++) {
        scanf("%lld", &A[i]);
        A[i] %= M;
        if (A[i] < 0) A[i] += M;
    }
    vector<int> QL(Q), QR(Q);
    vector<ll> QD(Q);
    vector<vector<int>> byR(N + 1);
    for (int q = 0; q < Q; q++) {
        ll l, r, d;
        scanf("%lld %lld %lld", &l, &r, &d);
        if (l > r) swap(l, r);
        QL[q] = (int)l;
        QR[q] = (int)r;
        QD[q] = d % M;
        byR[(int)r].push_back(q);
    }

    Fenwick fw;
    fw.init(N);
    unordered_map<ll, int> last;
    last.reserve(N * 2 + 1);
    vector<char> ans(Q, 0);

    for (int r = 1; r <= N; r++) {
        ll v = A[r];
        ll v2 = v * v % M, v3 = v2 * v % M;
        auto it = last.find(v);
        if (it != last.end()) {
            int p = it->second;
            array<ll, 4> neg = {M - 1, (M - v) % M, (M - v2) % M, (M - v3) % M};
            fw.add(p, neg);
        }
        fw.add(r, array<ll, 4>{1, v, v2, v3});
        last[v] = r;

        for (int q : byR[r]) {
            int L = QL[q];
            auto hi = fw.prefix(r);
            auto lo = fw.prefix(L - 1);
            ll k = ((hi[0] - lo[0]) % M + M) % M;
            ll S1 = ((hi[1] - lo[1]) % M + M) % M;
            ll S2 = ((hi[2] - lo[2]) % M + M) % M;
            ll S3 = ((hi[3] - lo[3]) % M + M) % M;
            ll D = QD[q];
            bool ok;
            if (D == 0) {
                ok = (k == 1);
            } else if (k == 1) {
                ok = (QL[q] == QR[q]);
            } else {
                ll kk = k;  // exact distinct count, 1 <= kk <= N
                ll K1 = (kk * (kk - 1) / 2) % M;
                // sum_{j<k} j^2 = (k-1)k(2k-1)/6, exact integer division
                ll K2 = ((kk - 1) * kk * (2 * kk - 1) / 6) % M;
                ll K3 = K1 * K1 % M;
                ll invk = pw(kk, M - 2);
                ll a = ((S1 - D * K1 % M) % M + M) % M * invk % M;
                ll a2 = a * a % M, a3 = a2 * a % M;
                ll D2 = D * D % M, D3 = D2 * D % M;
                ll E2 = (kk % M * a2 % M + 2 * a % M * D % M * K1 % M + D2 * K2 % M) % M;
                ll E3 = (kk % M * a3 % M + 3 * a2 % M * D % M * K1 % M
                         + 3 * a % M * D2 % M * K2 % M + D3 * K3 % M) % M;
                ok = (E2 == S2) && (E3 == S3);
            }
            ans[q] = ok ? 1 : 0;
        }
    }

    string out;
    out.reserve((size_t)Q * 4);
    for (int q = 0; q < Q; q++) {
        out += ans[q] ? "Yes\n" : "No\n";
    }
    fputs(out.c_str(), stdout);
    return 0;
}
