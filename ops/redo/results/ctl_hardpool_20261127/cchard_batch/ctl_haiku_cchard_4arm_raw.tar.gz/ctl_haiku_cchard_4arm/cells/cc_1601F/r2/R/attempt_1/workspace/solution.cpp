// Two Sorts.
// Let pos(x) = 1-based lexicographic position of x in 1..n. The answer is
// sum_x ((pos(x) - x) mod M) mod (1e9+7), with M = 998244353.
//
// For x with m digits (n has K digits):
//   pos(x) - x = (x - s(x))/9 + alpha_lin*x + const   (s = digit sum)
// where the last term depends on whether x*10^(K-m) - 1 <= n (linear in x)
// or not (constant n - 10^(K-1) + 1). So g(x) mod M = (al*x + be*s(x) + ga) mod M
// with residues mod M. We split [lo,hi] into aligned digit blocks
// x = P*10^k + t and sum over t with meet-in-the-middle on the digits of t.
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef __int128 i128;

static const ll MM = 998244353LL;
static const ll PR = 1000000007LL;

static ll pow10v[20];
static unsigned char dsTab[1000000];

static ll md(ll x) {
    x %= MM;
    if (x < 0) x += MM;
    return x;
}

static ll pwmod(ll b, ll e, ll m) {
    ll r = 1 % m;
    b %= m;
    while (e > 0) {
        if (e & 1) r = (i128)r * b % m;
        b = (i128)b * b % m;
        e >>= 1;
    }
    return r;
}

static int dsum(ll x) {
    int s = 0;
    while (x) {
        s += x % 10;
        x /= 10;
    }
    return s;
}

// Sum over t in [0, 10^k) of ((A + al*t + be*s(t)) mod MM). Requires k <= 12.
static i128 blockSum(int k, ll al, ll be, ll A) {
    if (k == 0) return md(A);
    int kl = k / 2, kh = k - kl;
    ll nl = pow10v[kl], nh = pow10v[kh];
    vector<ll> L(nl);
    for (ll tl = 0; tl < nl; tl++) {
        L[tl] = md(A + (al * tl) % MM + be * (ll)dsTab[tl]);
    }
    ll coefH = (al % MM) * (pow10v[kl] % MM) % MM;
    i128 sumL = 0, sumH = 0;
    for (ll l : L) sumL += l;
    sort(L.begin(), L.end());
    i128 cnt = 0;
    for (ll th = 0; th < nh; th++) {
        ll h = md((coefH * th) % MM + be * (ll)dsTab[th]);
        sumH += h;
        // count l in L with l >= MM - h
        ll need = MM - h;
        auto it = lower_bound(L.begin(), L.end(), need);
        cnt += (i128)(L.end() - it);
    }
    // sum over pairs of (h + l) mod MM = nl*sumH + nh*sumL - MM*cnt
    return (i128)nl * sumH + (i128)nh * sumL - (i128)MM * cnt;
}

// Sum over x in [lo, hi] of ((al*x + be*s(x) + ga) mod MM).
static i128 rangeSum(ll lo, ll hi, ll al, ll be, ll ga) {
    i128 total = 0;
    while (lo <= hi) {
        int k = 0;
        while (k + 1 <= 12 && lo % pow10v[k + 1] == 0 && lo + pow10v[k + 1] - 1 <= hi) k++;
        ll P = lo / pow10v[k];
        ll A = (al * (P % MM)) % MM;
        A = A * (pow10v[k] % MM) % MM;
        A = md(A + be * (ll)dsum(P) + ga);
        total += blockSum(k, al, be, A);
        lo += pow10v[k];
    }
    return total;
}

int main() {
    pow10v[0] = 1;
    for (int i = 1; i < 20; i++) pow10v[i] = pow10v[i - 1] * 10;
    for (int i = 0; i < 1000000; i++) dsTab[i] = (unsigned char)dsum(i);

    ll n;
    if (!(cin >> n)) return 0;
    int K = 0;
    while (pow10v[K] <= n) K++;  // K = number of digits of n

    ll inv9 = pwmod(9, MM - 2, MM);
    i128 total = 0;

    for (int m = 1; m <= K; m++) {
        ll lo = pow10v[m - 1];
        if (m < K) {
            ll hiFull = pow10v[m] - 1;
            ll sumMid = 0;   // sum_{L=m+1}^{K-1} 10^{L-m}
            ll sumHigh = 0;  // sum_{L=m+1}^{K-1} 10^{L-1}
            for (int L = m + 1; L <= K - 1; L++) {
                sumMid += pow10v[L - m];
                sumHigh += pow10v[L - 1];
            }
            ll sumLow = 0;   // sum_{L=1}^{m} (10^{L-1} - 1)
            for (int L = 1; L <= m; L++) sumLow += pow10v[L - 1] - 1;
            ll baseGamma = -sumHigh - sumLow;  // exact integer
            ll alphaBase = md(inv9 + sumMid % MM);
            ll X = (n + 1) / pow10v[K - m];
            // Linear cap: x*10^(K-m) <= n+1
            ll alLin = md(alphaBase + pow10v[K - m] % MM);
            ll gaLin = md(baseGamma - pow10v[K - 1]);
            ll hiL = min(hiFull, X);
            if (lo <= hiL) total += rangeSum(lo, hiL, alLin, md(-inv9), gaLin);
            // Constant cap: T = n - 10^(K-1) + 1
            ll gaC = md(baseGamma + (n - pow10v[K - 1] + 1));
            ll loC = max(lo, X + 1);
            if (loC <= hiFull) total += rangeSum(loC, hiFull, alphaBase, md(-inv9), gaC);
        } else {
            // m == K: x in [10^(K-1), n], no cap term
            ll sumLow = 0;
            for (int L = 1; L <= K; L++) sumLow += pow10v[L - 1] - 1;
            ll ga = md(-sumLow);
            total += rangeSum(lo, n, inv9, md(-inv9), ga);
        }
    }

    ll ans = (ll)(total % PR);
    if (ans < 0) ans += PR;
    cout << ans << "\n";
    return 0;
}
