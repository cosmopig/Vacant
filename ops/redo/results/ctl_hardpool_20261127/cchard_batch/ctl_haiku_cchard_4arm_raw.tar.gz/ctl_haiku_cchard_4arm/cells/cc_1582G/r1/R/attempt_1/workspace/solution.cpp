// Kuzya and Homework.
// A segment [l,r] is simple iff, for every i in [l,r], the prefix product
// P(l..i) is an integer, i.e. for every prime p the exponent sum
// E_p(i) - E_p(l-1) >= 0 (E_p = prefix sums of signed exponents).
// For anchor k = l-1 let D(k) = first i > k that breaks some prime
// (or n+1). Then the answer is sum over k of (D(k) - k - 1).
// For each prime, the values V_m of E_p between events form groups of
// anchors; the death of group m is the first later event with a smaller
// value (next-smaller-element). We take the min over primes by a
// segment tree with range chmin.
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;
    vector<int> a(n + 1);
    for (int i = 1; i <= n; i++) cin >> a[i];
    string b;
    cin >> b;

    const int MAXV = 1000000;
    vector<int> spf(MAXV + 1, 0);
    for (int i = 2; i <= MAXV; i++) {
        if (spf[i] == 0) {
            for (long long j = i; j <= MAXV; j += i) {
                if (spf[j] == 0) spf[j] = i;
            }
        }
    }

    // ev[p] = list of (position, signed exponent delta), positions increasing.
    vector<vector<pair<int, int>>> ev(MAXV + 1);
    for (int i = 1; i <= n; i++) {
        int x = a[i];
        int sign = (b[i - 1] == '*') ? 1 : -1;
        while (x > 1) {
            int p = spf[x];
            int e = 0;
            while (x % p == 0) {
                x /= p;
                e++;
            }
            ev[p].push_back({i, sign * e});
        }
    }

    int N = 1;
    while (N < n) N <<= 1;
    const int INF = n + 1;
    vector<int> tr(2 * N, INF);

    // Range chmin on anchors [l, r] (0-based, inclusive).
    auto upd = [&](int l, int r, int v) {
        l += N;
        r += N + 1;
        while (l < r) {
            if (l & 1) {
                tr[l] = min(tr[l], v);
                l++;
            }
            if (r & 1) {
                --r;
                tr[r] = min(tr[r], v);
            }
            l >>= 1;
            r >>= 1;
        }
    };

    vector<int> V, nse, st;
    for (int p = 2; p <= MAXV; p++) {
        const auto &e = ev[p];
        if (e.empty()) continue;
        int K = (int)e.size();
        // t(m) = position of m-th event (1-based m), V[m] = E_p after it.
        V.assign(K + 1, 0);
        for (int m = 1; m <= K; m++) V[m] = V[m - 1] + e[m - 1].second;
        nse.assign(K + 1, -1);
        st.clear();
        for (int s = 0; s <= K; s++) {
            while (!st.empty() && V[s] < V[st.back()]) {
                nse[st.back()] = s;
                st.pop_back();
            }
            st.push_back(s);
        }
        for (int m = 0; m <= K; m++) {
            if (nse[m] < 0) continue;
            int lo = (m == 0) ? 0 : e[m - 1].first;
            int hi = (m < K) ? e[m].first - 1 : n - 1;
            hi = min(hi, n - 1);
            if (lo > hi) continue;
            int death = e[nse[m] - 1].first;  // position of event nse[m]
            upd(lo, hi, death);
        }
    }

    // Push down to leaves.
    for (int i = 1; i < N; i++) {
        tr[2 * i] = min(tr[2 * i], tr[i]);
        tr[2 * i + 1] = min(tr[2 * i + 1], tr[i]);
    }

    long long ans = 0;
    for (int k = 0; k < n; k++) {
        ans += (long long)tr[N + k] - k - 1;
    }
    cout << ans << "\n";
    return 0;
}
