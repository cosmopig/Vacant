// Kuzya and Homework.
//
// For a fixed start l the path stays integral exactly on a prefix [l, R(l)]:
// x changes only at events (positions where a_i has a prime factor), and for each
// prime p the exponent of x after position i is S_p(i) - S_p(l-1), where S_p is the
// prefix sum of +e (for '*') / -e (for '/') over events of p. The first failing
// event for l is the first event k >= s (s = first event >= l) with P_k < P_{s-1},
// with P the prefix sums over events of p. Those failures are found per prime with a
// monotonic stack and binary search, the resulting per-l failure position is a
// range-chmin over the interval (q_{s-1}, q_s], done with a sparse table.
#include <bits/stdc++.h>
using namespace std;

static int readInt() {
    int c = getchar();
    while (c != '-' && (c < '0' || c > '9')) c = getchar();
    int x = 0;
    while (c >= '0' && c <= '9') { x = x * 10 + (c - '0'); c = getchar(); }
    return x;
}

int main() {
    int n = readInt();
    vector<int> a(n + 1);
    for (int i = 1; i <= n; i++) a[i] = readInt();
    vector<char> b(n + 1);
    for (int i = 1; i <= n; i++) {
        int c = getchar();
        while (c != '*' && c != '/') c = getchar();
        b[i] = (char)c;
    }

    const int MX = 1000000;
    vector<int> spf(MX + 1, 0);
    for (int i = 2; i <= MX; i++)
        if (spf[i] == 0)
            for (int j = i; j <= MX; j += i)
                if (spf[j] == 0) spf[j] = i;

    // Count events per prime (distinct prime factors of each a_i).
    vector<int> cnt(MX + 1, 0);
    for (int i = 1; i <= n; i++) {
        int x = a[i];
        while (x > 1) {
            int p = spf[x];
            cnt[p]++;
            while (x % p == 0) x /= p;
        }
    }
    vector<long long> start(MX + 2, 0);
    for (int p = 0; p <= MX; p++) start[p + 1] = start[p] + cnt[p];
    long long E = start[MX + 1];
    vector<int> qpos(E), qdel(E);
    {
        vector<long long> fillp(start.begin(), start.end() - 1);
        for (int i = 1; i <= n; i++) {
            int x = a[i];
            while (x > 1) {
                int p = spf[x];
                int e = 0;
                while (x % p == 0) { x /= p; e++; }
                long long idx = fillp[p]++;
                qpos[idx] = i;
                qdel[idx] = (b[i] == '*') ? e : -e;
            }
        }
    }

    // Sparse table for range chmin: tab[k][i] covers [i, i + 2^k - 1].
    int LOG = 1;
    while ((1 << LOG) <= n) LOG++;
    const int INF = n + 1;
    vector<vector<int>> tab(LOG, vector<int>(n + 2, INF));
    auto update = [&](int l, int r, int v) {
        int len = r - l + 1;
        int k = 31 - __builtin_clz(len);
        if (tab[k][l] > v) tab[k][l] = v;
        int r2 = r - (1 << k) + 1;
        if (tab[k][r2] > v) tab[k][r2] = v;
    };

    vector<int> P;
    vector<int> st;
    for (int p = 2; p <= MX; p++) {
        int m = cnt[p];
        if (m == 0) continue;
        long long base = start[p];
        P.assign(m + 1, 0);
        for (int j = 1; j <= m; j++) P[j] = P[j - 1] + qdel[base + j - 1];
        auto q = [&](int j) -> int { return j == 0 ? 0 : qpos[base + j - 1]; };
        st.clear();
        for (int s = m; s >= 1; s--) {
            while (!st.empty() && P[st.back()] >= P[s]) st.pop_back();
            st.push_back(s);
            int v = P[s - 1];
            // P is strictly increasing along the stack array; find the largest index j with P[st[j]] < v.
            if (P[st[0]] < v) {
                int lo = 0, hi = (int)st.size() - 1;
                while (lo < hi) {
                    int mid = (lo + hi + 1) / 2;
                    if (P[st[mid]] < v) lo = mid; else hi = mid - 1;
                }
                int k = st[lo];
                int L = q(s - 1) + 1, R = q(s);
                if (L <= R) update(L, R, q(k));
            }
        }
    }

    // Push range-chmin values down to single positions.
    for (int k = LOG - 1; k >= 1; k--) {
        int half = 1 << (k - 1);
        for (int i = 1; i + (1 << k) - 1 <= n; i++) {
            int t = tab[k][i];
            if (t < tab[k - 1][i]) tab[k - 1][i] = t;
            if (t < tab[k - 1][i + half]) tab[k - 1][i + half] = t;
        }
    }

    long long ans = 0;
    for (int l = 1; l <= n; l++) ans += (long long)(tab[0][l] - l);
    printf("%lld\n", ans);
    return 0;
}
