import sys

MOD = 998244353


def popcount(x):
    return bin(x).count("1")


def overlap(a, b):
    return (a & b) != 0 and (a & ~b) != 0 and (b & ~a) != 0


def build_order(members):
    """Order the atoms of an overlap-connected family (members in BFS order).
    Returns the list of atom bitmasks in order, or None if impossible."""
    blocks = [members[0]]
    for x in members[1:]:
        covered = 0
        for B in blocks:
            covered |= B
        N = x & ~covered
        k = len(blocks)
        touched = [i for i, B in enumerate(blocks) if B & x]
        if not touched:
            return None
        l, r = touched[0], touched[-1]
        if len(touched) != r - l + 1:
            return None
        full = [(blocks[i] & ~x) == 0 for i in range(k)]
        if N == 0:
            if l == r:
                return None
            for i in range(l + 1, r):
                if not full[i]:
                    return None
            new = blocks[:l]
            Bl = blocks[l]
            new += [p for p in (Bl & ~x, Bl & x) if p]
            new += blocks[l + 1:r]
            Br = blocks[r]
            new += [p for p in (Br & x, Br & ~x) if p]
            new += blocks[r + 1:]
            blocks = new
        else:
            right_ok = (r == k - 1) and all(full[i] for i in range(l + 1, r + 1))
            left_ok = (l == 0) and all(full[i] for i in range(l, r))
            if right_ok:
                Bl = blocks[l]
                new = blocks[:l]
                new += [p for p in (Bl & ~x, Bl & x) if p]
                new += blocks[l + 1:]
                new.append(N)
                blocks = new
            elif left_ok:
                Br = blocks[r]
                new = [N]
                new += blocks[:r]
                new += [p for p in (Br & x, Br & ~x) if p]
                new += blocks[r + 1:]
                blocks = new
            else:
                return None
    # verify every member is a contiguous run of whole blocks
    for s in members:
        idx = [i for i, B in enumerate(blocks) if B & s]
        if not idx or len(idx) != idx[-1] - idx[0] + 1:
            return None
        for i in idx:
            if blocks[i] & ~s:
                return None
    return blocks


def count(U, S, fact):
    size_u = popcount(U)
    sets = set()
    for s in S:
        if s & ~U:
            continue
        p = popcount(s)
        if 2 <= p < size_u:
            sets.add(s)
    if not sets:
        return fact[size_u]
    sets = list(sets)
    k = len(sets)

    # overlap components, each in BFS order
    seen = [False] * k
    comps = []
    for i in range(k):
        if seen[i]:
            continue
        seen[i] = True
        order = [i]
        q = 0
        while q < len(order):
            a = order[q]
            q += 1
            for b in range(k):
                if not seen[b] and overlap(sets[a], sets[b]):
                    seen[b] = True
                    order.append(b)
        members = [sets[j] for j in order]
        union = 0
        for s in members:
            union |= s
        comps.append((union, members))

    comps.sort(key=lambda c: (-popcount(c[0]), -len(c[1])))
    tops = []
    for union, members in comps:
        if any((union & ~T) == 0 for T, _ in tops):
            continue
        tops.append((union, members))

    result = 1
    covered = 0
    for union, members in tops:
        covered |= union
        inside = [s for s in sets if (s & ~union) == 0 and s not in members]
        if len(members) == 1:
            f = count(union, inside, fact)
        else:
            blocks = build_order(members)
            if blocks is None:
                return 0
            f = 2
            for B in blocks:
                sub = [s for s in inside if (s & ~B) == 0]
                f = f * count(B, sub, fact) % MOD
        result = result * f % MOD

    nblocks = len(tops) + popcount(U & ~covered)
    return result * fact[nblocks] % MOD


def solve(data):
    it = iter(data)
    n = int(next(it))
    m = int(next(it))
    sets = []
    for _ in range(m):
        q = int(next(it))
        mask = 0
        for _ in range(q):
            s = int(next(it))
            mask |= 1 << (s - 1)
        sets.append(mask)
    fact = [1] * (n + 2)
    for i in range(1, n + 2):
        fact[i] = fact[i - 1] * i % MOD
    U = (1 << n) - 1
    return count(U, sets, fact)


def main():
    data = sys.stdin.read().split()
    sys.setrecursionlimit(10000)
    print(solve(data))


if __name__ == "__main__":
    main()
