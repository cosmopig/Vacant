import sys

MOD = 10**9 + 7


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    q = int(data[pos]); pos += 1
    a = [int(x) % MOD for x in data[pos:pos + n]]
    pos += n
    out = []
    for _ in range(q):
        l = int(data[pos]) - 1
        r = int(data[pos + 1])
        d = int(data[pos + 2]) % MOD
        pos += 3
        # Distinct cities in the range (duplicates do not matter).
        cities = set(a[l:r])
        k = len(cities)
        if k == 1:
            out.append("Yes")
            continue
        if d == 0:
            out.append("No")
            continue
        # Cities are connected by roads of length d iff the cities form a single
        # chain x, x+d, x+2d, ... on the cycle. Each chain has exactly one start
        # (an element whose predecessor x-d is absent). The cycle cannot be
        # wholly covered since k < MOD, so "exactly one start" <=> connected.
        starts = 0
        for x in cities:
            if (x - d) % MOD not in cities:
                starts += 1
                if starts > 1:
                    break
        out.append("Yes" if starts == 1 else "No")
    sys.stdout.write("\n".join(out) + ("\n" if out else ""))


if __name__ == "__main__":
    main()
