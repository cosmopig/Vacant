import sys

MOD = 998244353
sys.setrecursionlimit(10000)

FACT = [1] * 512
for _i in range(1, 512):
    FACT[_i] = FACT[_i - 1] * _i % MOD


def overlap(a, b):
    return bool(a & b) and not (a <= b) and not (b <= a)


def insert(L, W, T):
    """Insert set T (overlapping some already-placed set) into the ordered
    block list L covering W. Returns the new block list or None if impossible."""
    N = T - W
    touched = [i for i, b in enumerate(L) if b & T]
    if not touched:
        return None
    l, r = touched[0], touched[-1]
    if touched != list(range(l, r + 1)):
        return None
    for i in range(l + 1, r):
        if not L[i] <= T:
            return None
    if N:
        if len(L) == 1:
            left = [L[0] - T] if L[0] - T else []
            return left + [L[0] & T, N]
        left_ok = (l == 0) and all(L[i] <= T for i in range(0, r))
        right_ok = (r == len(L) - 1) and all(L[i] <= T for i in range(l + 1, len(L)))
        if left_ok:
            mid = [L[r] & T] + ([L[r] - T] if L[r] - T else [])
            return [N] + L[:r] + mid + L[r + 1:]
        if right_ok:
            mid = ([L[l] - T] if L[l] - T else []) + [L[l] & T]
            return L[:l] + mid + L[l + 1:] + [N]
        return None
    if l == r:
        return None
    left_part = ([L[l] - T] if L[l] - T else []) + [L[l] & T]
    right_part = [L[r] & T] + ([L[r] - T] if L[r] - T else [])
    return L[:l] + left_part + L[l + 1:r] + right_part + L[r + 1:]


def build_order(S, order):
    """Order the atoms of an overlap-connected component (given in BFS order).
    Returns the atom list, or None if no valid arrangement exists."""
    L = [S[order[0]]]
    W = set(S[order[0]])
    for idx in order[1:]:
        T = S[idx]
        L = insert(L, W, T)
        if L is None:
            return None
        W |= T
    # verify every set of the component is a contiguous run of atoms
    for idx in order:
        T = S[idx]
        touched = [i for i, b in enumerate(L) if b & T]
        if not touched or touched != list(range(touched[0], touched[-1] + 1)):
            return None
        for i in touched:
            if not L[i] <= T:
                return None
    return L


def count(U, sets):
    """Number of orderings of the elements of U in which every set is consecutive.
    All sets in `sets` are subsets of U."""
    n = len(U)
    S = []
    seen = set()
    for s in sets:
        if 2 <= len(s) < n and s not in seen:
            seen.add(s)
            S.append(s)
    if not S:
        return FACT[n]

    k = len(S)
    adj = [[j for j in range(k) if j != i and overlap(S[i], S[j])] for i in range(k)]
    comp = [-1] * k
    comps = []
    for i in range(k):
        if comp[i] == -1:
            cid = len(comps)
            comp[i] = cid
            order = [i]
            q = 0
            while q < len(order):
                x = order[q]
                q += 1
                for y in adj[x]:
                    if comp[y] == -1:
                        comp[y] = cid
                        order.append(y)
            comps.append(order)

    # union of each component; a multi-set component wins over a single set with equal union
    blocks = {}
    for order in comps:
        ucomp = frozenset().union(*[S[i] for i in order])
        multi = len(order) > 1
        if ucomp not in blocks or (multi and not blocks[ucomp][0]):
            blocks[ucomp] = (multi, order)

    keys = list(blocks.keys())
    maximal = [b for b in keys if not any(b < c for c in keys)]
    covered = frozenset().union(*maximal)
    free = n - len(covered)

    res = FACT[len(maximal) + free]
    for B in maximal:
        multi, order = blocks[B]
        sub = [s for s in S if s <= B]
        if not multi:
            res = res * count(B, sub) % MOD
        else:
            atoms = build_order(S, order)
            if atoms is None:
                return 0
            f = 2
            for a in atoms:
                f = f * count(a, [s for s in sub if s <= a]) % MOD
            res = res * f % MOD
    return res


def main():
    data = sys.stdin.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    m = int(data[pos]); pos += 1
    sets = []
    for _ in range(m):
        q = int(data[pos]); pos += 1
        s = frozenset(int(x) for x in data[pos:pos + q])
        pos += q
        sets.append(s)
    U = frozenset(range(1, n + 1))
    print(count(U, sets) % MOD)


main()
