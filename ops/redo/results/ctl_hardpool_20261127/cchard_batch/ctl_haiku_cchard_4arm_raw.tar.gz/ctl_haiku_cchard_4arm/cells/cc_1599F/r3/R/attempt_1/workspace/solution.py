import sys

M = 10**9 + 7
CBITS = 20          # width of the distinct-count field
FBITS = 48          # width of each power-sum field (sums of < 2*10^5 values < 2^30)
SH1, SH2, SH3 = CBITS, CBITS + FBITS, CBITS + 2 * FBITS
FMASK = (1 << FBITS) - 1
CMASK = (1 << CBITS) - 1


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); q = int(data[pos + 1]); pos += 2
    a = [int(x) % M for x in data[pos:pos + n]]
    pos += n
    queries = []
    for qi in range(q):
        l = int(data[pos]); r = int(data[pos + 1]); d = int(data[pos + 2]) % M
        pos += 3
        if l > r:
            l, r = r, l
        queries.append((r, l, d, qi))

    # Packed weight of a value v: count 1, v, v^2 mod M, v^3 mod M in separate fields.
    weight = [0] * n
    for i, v in enumerate(a):
        v2 = v * v % M
        v3 = v2 * v % M
        weight[i] = 1 | (v << SH1) | (v2 << SH2) | (v3 << SH3)

    queries.sort()
    tree = [0] * (n + 1)
    last_of = {}
    ans = ["No"] * q
    qp = 0

    for i in range(1, n + 1):
        w = weight[i - 1]
        v = a[i - 1]
        p = last_of.get(v, 0)
        if p:
            delta = -weight[p - 1]
            j = p
            while j <= n:
                tree[j] += delta
                j += j & -j
        j = i
        while j <= n:
            tree[j] += w
            j += j & -j
        last_of[v] = i

        while qp < q and queries[qp][0] == i:
            r, l, d, qi = queries[qp]
            qp += 1
            if l < 1 or r > n:
                ans[qi] = "No"
                continue
            # S = prefix(r) - prefix(l-1)
            s = 0
            j = r
            while j > 0:
                s += tree[j]
                j -= j & -j
            j = l - 1
            while j > 0:
                s -= tree[j]
                j -= j & -j
            c = s & CMASK
            if c == 0:
                ans[qi] = "No"
                continue
            if c == 1:
                ans[qi] = "Yes"
                continue
            if d == 0:
                ans[qi] = "No"
                continue
            inv = pow(d, M - 2, M)
            a1 = (s >> SH1) & FMASK
            a2 = (s >> SH2) & FMASK
            a3 = (s >> SH3) & FMASK
            s1 = inv * (a1 % M) % M
            s2 = inv * inv % M * (a2 % M) % M
            s3 = inv * inv % M * inv % M * (a3 % M) % M
            # Connected iff the indices k = v/d form an arc {s0, ..., s0+c-1} (mod M).
            t1 = c * (c - 1) // 2
            t2 = (c - 1) * c * (2 * c - 1) // 6
            t3 = t1 * t1
            s0 = (s1 - t1) % M * pow(c, M - 2, M) % M
            ok = True
            # Power sums of the arc, p = 2 and 3.
            e2 = (c * s0 % M * s0 + 2 * s0 * t1 + t2) % M
            if e2 != s2:
                ok = False
            else:
                e3 = (c * s0 % M * s0 % M * s0 + 3 * s0 * s0 % M * t1 + 3 * s0 * t2 + t3) % M
                if e3 != s3:
                    ok = False
            ans[qi] = "Yes" if ok else "No"

    sys.stdout.write("\n".join(ans) + "\n")


main()
