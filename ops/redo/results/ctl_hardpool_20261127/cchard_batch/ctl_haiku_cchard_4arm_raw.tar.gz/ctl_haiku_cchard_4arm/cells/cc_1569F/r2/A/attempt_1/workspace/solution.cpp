// Palindromic Hamiltonian Path counting.
//
// A string is good iff there is a Hamiltonian path v1..vn whose letters form a
// palindrome, i.e. letter(v_i) == letter(v_{n+1-i}). So the pairs
// {v_i, v_{n+1-i}} form a perfect matching M of the vertices, and each pair of M
// must be monochromatic.
//
// Steps:
//  1. Enumerate all perfect matchings M of the n vertices and keep the
//     "achievable" ones: M is achievable iff its pairs can be ordered so that
//     they form a palindromic ladder path (grown from the middle outwards).
//  2. A string's letter classes form a partition pi of the vertices. The string
//     is good iff some achievable M has every pair inside one block of pi.
//  3. Enumerate partitions pi into even-size blocks with b <= k blocks. Each such
//     partition is induced by P(k, b) = k!/(k-b)! strings. Sum P(k, b) over good pi.
#include <bits/stdc++.h>
using namespace std;

typedef unsigned __int128 u128;

static int n, m, k;
static int adjm[12];
static int pid[12][12];          // index of unordered pair {x, y} in 0..65
static u128 pairMaskOf[1 << 12]; // OR of pair bits for all pairs inside a vertex subset
static vector<u128> achievable;  // edge-bitmask of each achievable perfect matching
static long long perm[13];       // perm[b] = k*(k-1)*...*(k-b+1)
static long long ans = 0;
static int numBlocks;
static u128 curE;                // pairs that lie inside one block, for the current partition

// Is the perfect matching given by pairs px[i]--py[i] achievable?
static bool achievableMatching(const int* px, const int* py, int h) {
    // st[S][a] = set of right endpoints b, where the chain built from pair set S
    // has left endpoint a and right endpoint b.
    static uint16_t st[64][12];
    int full = (1 << h) - 1;
    memset(st, 0, sizeof(st));
    for (int i = 0; i < h; i++) {
        int x = px[i], y = py[i];
        if (adjm[x] >> y & 1) {  // innermost pair must be an edge
            st[1 << i][x] |= (uint16_t)(1 << y);
            st[1 << i][y] |= (uint16_t)(1 << x);
        }
    }
    for (int S = 1; S <= full; S++) {
        for (int a = 0; a < n; a++) {
            uint16_t R = st[S][a];
            if (!R) continue;
            int NB = 0;
            for (int r = R; r; r &= r - 1) NB |= adjm[__builtin_ctz(r)];
            for (int j = 0; j < h; j++) {
                if (S >> j & 1) continue;
                int x = px[j], y = py[j];
                int T = S | (1 << j);
                // orientation 1: x becomes the new left end, y the new right end
                if ((adjm[a] >> x & 1) && (NB >> y & 1)) st[T][x] |= (uint16_t)(1 << y);
                // orientation 2: y becomes the new left end, x the new right end
                if ((adjm[a] >> y & 1) && (NB >> x & 1)) st[T][y] |= (uint16_t)(1 << x);
            }
        }
    }
    for (int a = 0; a < n; a++)
        if (st[full][a]) return true;
    return false;
}

static void enumMatchings(int rem, int* px, int* py, int h) {
    if (rem == 0) {
        if (achievableMatching(px, py, h)) {
            u128 mask = 0;
            for (int i = 0; i < h; i++) mask |= (u128)1 << pid[px[i]][py[i]];
            achievable.push_back(mask);
        }
        return;
    }
    int x = __builtin_ctz(rem);
    for (int y = x + 1; y < n; y++) {
        if (!(rem >> y & 1)) continue;
        px[h] = x;
        py[h] = y;
        enumMatchings(rem & ~(1 << x) & ~(1 << y), px, py, h + 1);
    }
}

static bool isGood() {
    for (u128 M : achievable)
        if ((M & ~curE) == 0) return true;
    return false;
}

// Enumerate partitions of the unassigned vertices `rem` into even-size blocks.
static void enumPart(int rem) {
    if (numBlocks > k) return;  // would need more letters than available
    if (rem == 0) {
        if (isGood()) ans += perm[numBlocks];
        return;
    }
    int v = __builtin_ctz(rem);
    int others = rem & ~(1 << v);
    // choose the rest of v's block: a subset T of `others` with |T| odd
    for (int T = others; ; T = (T - 1) & others) {
        if (__builtin_popcount(T) & 1) {
            int block = (1 << v) | T;
            u128 saved = curE;
            curE |= pairMaskOf[block];
            numBlocks++;
            enumPart(rem & ~block);
            numBlocks--;
            curE = saved;
        }
        if (T == 0) break;
    }
}

int main() {
    if (scanf("%d %d %d", &n, &m, &k) != 3) return 0;
    for (int i = 0; i < m; i++) {
        int v, u;
        if (scanf("%d %d", &v, &u) != 2) break;
        v--; u--;
        // Ignore self-loops and vertices outside 1..n (not valid under the statement).
        if (v < 0 || u < 0 || v >= n || u >= n || v == u) continue;
        adjm[v] |= 1 << u;
        adjm[u] |= 1 << v;
    }
    if (n % 2 == 1) { printf("0\n"); return 0; }

    perm[0] = 1;
    for (int b = 1; b <= 12; b++) perm[b] = (b <= k) ? perm[b - 1] * (k - b + 1) : 0;

    int idx = 0;
    for (int x = 0; x < n; x++)
        for (int y = x + 1; y < n; y++) pid[x][y] = pid[y][x] = idx++;

    for (int sub = 0; sub < (1 << n); sub++) {
        u128 mk = 0;
        for (int x = 0; x < n; x++)
            if (sub >> x & 1)
                for (int y = x + 1; y < n; y++)
                    if (sub >> y & 1) mk |= (u128)1 << pid[x][y];
        pairMaskOf[sub] = mk;
    }

    int px[6], py[6];
    enumMatchings((1 << n) - 1, px, py, 0);

    curE = 0;
    numBlocks = 0;
    enumPart((1 << n) - 1);
    printf("%lld\n", ans);
    return 0;
}
