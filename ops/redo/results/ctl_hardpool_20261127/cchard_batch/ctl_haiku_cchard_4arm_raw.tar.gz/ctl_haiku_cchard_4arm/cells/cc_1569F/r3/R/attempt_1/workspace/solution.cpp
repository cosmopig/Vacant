#include <bits/stdc++.h>
using namespace std;

// A string is good iff there is a palindromic Hamiltonian path, i.e. a path
// v_1..v_n whose letters satisfy c(v_i) = c(v_{n+1-i}). Only the pairing
// M = {{v_i, v_{n+1-i}}} matters, and c must be constant on each pair of M.
// So the string's equality partition P must have a realizable pairing M with
// every pair inside one block of P. The number of strings with exactly the
// partition P (b blocks) is k*(k-1)*...*(k-b+1).

int n, m, k;
int adj[12];
int h;
vector<array<int, 12>> mats;  // realizable perfect matchings: partner array
vector<vector<int>> lists;    // per-depth list of alive matching indices
int blk[12];
long long ans = 0;

vector<array<int, 12>> allMatchings;
array<int, 12> curPartner;

void genMatchings(int used) {
    int v = -1;
    for (int i = 0; i < n; i++) if (!(used >> i & 1)) { v = i; break; }
    if (v < 0) { allMatchings.push_back(curPartner); return; }
    for (int u = v + 1; u < n; u++) {
        if (used >> u & 1) continue;
        curPartner[v] = u; curPartner[u] = v;
        genMatchings(used | (1 << v) | (1 << u));
    }
}

// Check whether the matching can be arranged as pairs P_1..P_h, each pair
// oriented (a_i, b_i), with a_i ~ a_{i+1}, b_i ~ b_{i+1}, and a_h ~ b_h.
bool realizable(const array<int, 12>& partner) {
    vector<pair<int, int>> pr;
    for (int v = 0; v < n; v++) if (partner[v] > v) pr.push_back({v, partner[v]});
    int H = pr.size();
    // reach[S][p][o]: subset S of pairs placed as a chain ending with pair p in orientation o
    vector<vector<array<bool, 2>>> reach(1 << H, vector<array<bool, 2>>(H, {false, false}));
    for (int p = 0; p < H; p++) reach[1 << p][p] = {true, true};
    auto ends = [&](int p, int o, int& x, int& y) {
        x = o == 0 ? pr[p].first : pr[p].second;
        y = o == 0 ? pr[p].second : pr[p].first;
    };
    for (int S = 1; S < (1 << H); S++) {
        for (int p = 0; p < H; p++) {
            if (!(S >> p & 1)) continue;
            for (int o = 0; o < 2; o++) {
                if (!reach[S][p][o]) continue;
                int x, y;
                ends(p, o, x, y);
                for (int q = 0; q < H; q++) {
                    if (S >> q & 1) continue;
                    for (int o2 = 0; o2 < 2; o2++) {
                        int x2, y2;
                        ends(q, o2, x2, y2);
                        if ((adj[x] >> x2 & 1) && (adj[y] >> y2 & 1))
                            reach[S | (1 << q)][q][o2] = true;
                    }
                }
            }
        }
    }
    int full = (1 << H) - 1;
    for (int p = 0; p < H; p++) {
        if (!(adj[pr[p].first] >> pr[p].second & 1)) continue;
        if (reach[full][p][0] || reach[full][p][1]) return true;
    }
    return false;
}

long long falling(int b) {
    long long r = 1;
    for (int t = 0; t < b; t++) r *= (long long)(k - t);
    return r;  // becomes 0 once b > k
}

void rec(int i, int nb, int depth) {
    if (i == n) {
        ans += falling(nb);
        return;
    }
    const vector<int>& L = lists[depth];
    vector<int>& C = lists[depth + 1];
    for (int b = 0; b <= nb; b++) {
        C.clear();
        for (int idx : L) {
            const auto& M = mats[idx];
            int j = M[i];
            if (j > i || (j < i && blk[j] == b)) C.push_back(idx);
        }
        if (C.empty()) continue;
        blk[i] = b;
        rec(i + 1, max(nb, b + 1), depth + 1);
    }
}

int main() {
    scanf("%d %d %d", &n, &m, &k);
    for (int i = 0; i < m; i++) {
        int v, u;
        scanf("%d %d", &v, &u);
        v--; u--;
        adj[v] |= 1 << u;
        adj[u] |= 1 << v;
    }
    h = n / 2;
    genMatchings(0);
    for (auto& M : allMatchings) if (realizable(M)) mats.push_back(M);

    lists.assign(n + 2, {});
    lists[0].resize(mats.size());
    for (size_t i = 0; i < mats.size(); i++) lists[0][i] = (int)i;
    if (!mats.empty()) rec(0, 0, 0);
    printf("%lld\n", ans);
    return 0;
}
