#include <bits/stdc++.h>
using namespace std;

static char buf[1 << 25];
int bufLen = 0, bufPos = 0;

inline int readChar() {
    if (bufPos == bufLen) {
        bufLen = (int)fread(buf, 1, sizeof(buf), stdin);
        bufPos = 0;
        if (bufLen <= 0) return -1;
    }
    return buf[bufPos++];
}

inline long long readInt() {
    int c = readChar();
    while (c != '-' && (c < '0' || c > '9')) c = readChar();
    bool neg = false;
    if (c == '-') { neg = true; c = readChar(); }
    long long x = 0;
    while (c >= '0' && c <= '9') { x = x * 10 + (c - '0'); c = readChar(); }
    return neg ? -x : x;
}

int n, q, k;
vector<int> a;
vector<vector<int>> sp;
vector<int> lg;

// index of the minimum in [l, r], first occurrence on ties
inline int better(int i, int j) {
    if (a[i] < a[j]) return i;
    if (a[j] < a[i]) return j;
    return min(i, j);
}

inline int argmin(int l, int r) {
    int j = lg[r - l + 1];
    return better(sp[j][l], sp[j][r - (1 << j) + 1]);
}

int main() {
    n = (int)readInt();
    q = (int)readInt();
    k = (int)readInt();

    a.assign(n + 2, 0);
    for (int i = 1; i <= n; i++) a[i] = (int)readInt();

    vector<int> L(q), R(q);
    for (int i = 0; i < q; i++) {
        L[i] = (int)readInt();
        R[i] = (int)readInt();
    }

    // next strictly smaller element to the right
    vector<int> ns(n + 2, n + 1);
    {
        vector<int> st;
        st.reserve(n);
        for (int x = n; x >= 1; x--) {
            while (!st.empty() && a[st.back()] >= a[x]) st.pop_back();
            ns[x] = st.empty() ? n + 1 : st.back();
            st.push_back(x);
        }
    }

    // sparse table of argmins
    lg.assign(n + 2, 0);
    for (int i = 2; i <= n + 1; i++) lg[i] = lg[i / 2] + 1;
    int LOG = lg[n] + 1;
    sp.assign(LOG, vector<int>(n + 2, 0));
    for (int i = 1; i <= n; i++) sp[0][i] = i;
    for (int j = 1; j < LOG; j++) {
        for (int i = 1; i + (1 << j) - 1 <= n; i++) {
            sp[j][i] = better(sp[j - 1][i], sp[j - 1][i + (1 << (j - 1))]);
        }
    }

    vector<long long> ans(q, 0);
    const int B = 700;

    if (k <= B) {
        // group queries by residue class c = l mod k
        vector<vector<int>> byClass(k);
        for (int i = 0; i < q; i++) byClass[L[i] % k].push_back(i);

        vector<long long> cum(n + 2, 0), H(n + 2, 0);
        for (int c = 0; c < k; c++) {
            if (byClass[c].empty()) continue;
            // cum[y] = #{t in [1..y] : t % k == c}
            {
                int res = 0;
                long long cnt = 0;
                cum[0] = 0;
                for (int y = 1; y <= n; y++) {
                    res = (res + 1 == k) ? 0 : res + 1;
                    if (res == c) cnt++;
                    cum[y] = cnt;
                }
            }
            // H[x] = sum over t >= x, t % k == c, of min a[x..t]
            H[n + 1] = 0;
            for (int x = n; x >= 1; x--) {
                long long cntv = cum[ns[x] - 1] - cum[x - 1];
                H[x] = (long long)a[x] * cntv + H[ns[x]];
            }
            for (int id : byClass[c]) {
                int l = L[id], r = R[id];
                int qp = argmin(l, r);
                ans[id] = H[l] - H[qp] + (long long)a[qp] * (cum[r] - cum[qp - 1]);
            }
        }
    } else {
        // chain length is at most n/k + 1, walk it with RMQ
        for (int i = 0; i < q; i++) {
            long long sum = 0;
            for (int t = L[i]; t <= R[i]; t += k) {
                sum += a[argmin(L[i], t)];
            }
            ans[i] = sum;
        }
    }

    string out;
    out.reserve((size_t)q * 16);
    char tmp[24];
    for (int i = 0; i < q; i++) {
        int len = snprintf(tmp, sizeof(tmp), "%lld\n", ans[i]);
        out.append(tmp, len);
    }
    fwrite(out.data(), 1, out.size(), stdout);
    return 0;
}
