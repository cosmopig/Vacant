// Phys Ed Online.
//
// For a student covering [l, r], the ticket activations happen at the
// uncovered days x = l, l+k, l+2k, ... (<= r). On day x the cheapest
// purchase available is min(a[l..x]), so the answer is
//     sum over x = l + t*k <= r of min(a[l..x]).
//
// Let par[m] = next index j > m with a[j] < a[m] (n+1 if none). For a fixed l,
// min(a[l..x]) is constant on pieces [m, par[m]-1] along the chain
// l -> par[l] -> par[par[l]] -> ... ; M = leftmost argmin of a[l..r] is the
// last chain node <= r. For a piece [s, e] with s >= l,
//     #{x in [s,e] : x = l (mod k)} = (e/k - (s-1)/k) - [ (e%k) < λ ] + [ ((s-1)%k) < λ ],
// with λ = l % k. Summed over the chain nodes strictly below M this splits into
//   * a λ-free part  P1[l] - P1[M]  (root-path prefix sums), and
//   * a λ-dependent part  sum over those nodes of a_m*([key(m)<λ] - [key(par m)<λ]),
//     with key(v) = (v-1) % k. The stack at time l is exactly the chain from l,
//     so this is kept in a Fenwick tree over keys while sweeping l downwards;
//     the value at M is snapshotted when the sweep reaches M.
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

struct Fenwick {
    int n;
    vector<ll> t;
    explicit Fenwick(int n_) : n(n_), t(n_ + 1, 0) {}
    void add(int i, ll v) {  // i in [1, n]
        for (; i <= n; i += i & -i) t[i] += v;
    }
    ll prefix(int i) const {  // sum over [1, i]
        ll s = 0;
        for (; i > 0; i -= i & -i) s += t[i];
        return s;
    }
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, q, k;
    cin >> n >> q >> k;
    vector<ll> a(n + 2, 0);
    for (int i = 1; i <= n; i++) cin >> a[i];

    // Next strictly smaller element to the right.
    vector<int> par(n + 2, n + 1);
    {
        vector<int> st;
        for (int m = n; m >= 1; m--) {
            while (!st.empty() && a[st.back()] >= a[m]) st.pop_back();
            par[m] = st.empty() ? n + 1 : st.back();
            st.push_back(m);
        }
    }

    // Sparse table for leftmost argmin.
    int LOG = 1;
    while ((1 << LOG) <= n) LOG++;
    vector<vector<int>> sp(LOG, vector<int>(n + 2, 0));
    for (int i = 1; i <= n; i++) sp[0][i] = i;
    auto better = [&](int x, int y) {  // leftmost minimum
        if (a[x] != a[y]) return a[x] < a[y] ? x : y;
        return min(x, y);
    };
    for (int j = 1; j < LOG; j++)
        for (int i = 1; i + (1 << j) - 1 <= n; i++)
            sp[j][i] = better(sp[j - 1][i], sp[j - 1][i + (1 << (j - 1))]);
    vector<int> lg(n + 2, 0);
    for (int i = 2; i <= n + 1; i++) lg[i] = lg[i / 2] + 1;
    auto argmin = [&](int l, int r) {
        int j = lg[r - l + 1];
        return better(sp[j][l], sp[j][r - (1 << j) + 1]);
    };

    // P1[m] = a_m * (q(par-1) - q(m-1)) + P1[par], q(y) = y / k.
    vector<ll> P1(n + 2, 0);
    for (int m = n; m >= 1; m--) {
        ll qa = (ll)(par[m] - 1) / k, qb = (ll)(m - 1) / k;
        P1[m] = a[m] * (qa - qb) + P1[par[m]];
    }

    vector<int> ql(q), qr(q), qM(q);
    vector<vector<int>> byL(n + 2), byM(n + 2);
    for (int i = 0; i < q; i++) {
        cin >> ql[i] >> qr[i];
        qM[i] = argmin(ql[i], qr[i]);
        byL[ql[i]].push_back(i);
        byM[qM[i]].push_back(i);
    }

    auto key = [&](int v) { return (v - 1) % k; };  // in [0, k-1]
    // Fenwick index for key c is c+1; prefix(λ) = sum of keys < λ = prefix over indices 1..λ.
    Fenwick fen(k);

    vector<ll> snap(q, 0), ans(q, 0);
    vector<int> st;
    for (int t = n; t >= 1; t--) {
        // Pop elements with a >= a[t]; remove their items.
        while (!st.empty() && a[st.back()] >= a[t]) {
            int m = st.back();
            st.pop_back();
            fen.add(key(m) + 1, -a[m]);
            if (par[m] <= n) fen.add(key(par[m]) + 1, a[m]);
        }
        // Push t; add its items.
        fen.add(key(t) + 1, a[t]);
        if (par[t] <= n) fen.add(key(par[t]) + 1, -a[t]);
        st.push_back(t);

        for (int id : byM[t]) {
            int lam = (ql[id] % k);
            snap[id] = fen.prefix(lam);
        }
        for (int id : byL[t]) {
            int l = ql[id], r = qr[id], M = qM[id];
            int lam = l % k;
            ll pre = fen.prefix(lam);
            // F(y) = number of chain points x = l (mod k) with l <= x <= y.
            auto F = [&](ll y) -> ll { return y >= l ? (y - l) / k + 1 : 0; };
            ll cntM = F(r) - F(M - 1);
            ans[id] = (P1[l] - P1[M]) + (pre - snap[id]) + a[M] * cntM;
        }
    }

    string out;
    out.reserve((size_t)q * 12);
    for (int i = 0; i < q; i++) {
        out += to_string(ans[i]);
        out += '\n';
    }
    cout << out;
    return 0;
}
