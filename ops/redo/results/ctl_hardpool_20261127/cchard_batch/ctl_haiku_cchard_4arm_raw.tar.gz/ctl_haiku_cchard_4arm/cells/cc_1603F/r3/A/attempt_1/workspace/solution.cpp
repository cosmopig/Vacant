#include <bits/stdc++.h>
using namespace std;

typedef unsigned long long ull;
static const ull MOD = 998244353ULL;

static ull pw_mod(ull b, ull e) {
    b %= MOD;
    ull r = 1;
    while (e) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    vector<long long> N(t), K(t), X(t);
    long long maxk = 1;
    for (int i = 0; i < t; i++) {
        cin >> N[i] >> K[i] >> X[i];
        maxk = max(maxk, K[i]);
    }

    // pw[i] = 2^i mod p for i in [0, maxk+1]
    // inv[i] = (2^i - 1)^{-1} mod p for i in [1, maxk]
    int M = (int)maxk;
    vector<uint32_t> pw(M + 2), inv(M + 1, 0);
    pw[0] = 1;
    for (int i = 1; i <= M + 1; i++) pw[i] = (uint32_t)(2ULL * pw[i - 1] % MOD);

    // Batch inversion of D[i] = 2^i - 1 for i in [1, M].
    // pre[i] = prod_{j=1..i} D[j]
    vector<uint32_t> pre(M + 1, 0);
    pre[0] = 1;
    for (int i = 1; i <= M; i++) {
        ull d = (pw[i] + MOD - 1) % MOD;
        pre[i] = (uint32_t)((ull)pre[i - 1] * d % MOD);
    }
    ull invAll = pw_mod(pre[M], MOD - 2);
    for (int i = M; i >= 1; i--) {
        ull d = (pw[i] + MOD - 1) % MOD;
        inv[i] = (uint32_t)(invAll * pre[i - 1] % MOD);
        invAll = invAll * d % MOD;
    }
    vector<uint32_t>().swap(pre);

    string out;
    out.reserve(t * 12);

    for (int tc = 0; tc < t; tc++) {
        long long n = N[tc], k = K[tc], x = X[tc];
        ull ans = 0;

        if (x == 0) {
            // Need all n elements linearly independent: prod_{j<n} (2^k - 2^j), zero if n > k.
            if (n > k) {
                ans = 0;
            } else {
                ull pk = pw[k];
                ull P = 1;
                for (long long j = 0; j < n; j++) {
                    ull f = (pk + MOD - pw[j]) % MOD;
                    P = P * f % MOD;
                }
                ans = P;
            }
        } else {
            // Sum over i = dim V (0 <= i <= min(k, n)) of
            //   ([k,i]_2 - [k-1,i-1]_2) * prod_{j<i} (2^n - 2^j)
            ull N2 = pw_mod(2, (ull)n);
            long long L = min(k, n);
            ull g1 = 1;  // [k, i]_2
            ull g2 = 0;  // [k-1, i-1]_2
            ull P = 1;   // prod_{j<i} (2^n - 2^j)
            for (long long i = 0; i <= L; i++) {
                if (i == 0) {
                    g2 = 0;
                } else {
                    g1 = g1 * ((pw[k - i + 1] + MOD - 1) % MOD) % MOD * inv[i] % MOD;
                    if (i == 1) {
                        g2 = 1;
                    } else {
                        g2 = g2 * ((pw[k - i + 1] + MOD - 1) % MOD) % MOD * inv[i - 1] % MOD;
                    }
                    P = P * ((N2 + MOD - pw[i - 1]) % MOD) % MOD;
                }
                ull c = (g1 + MOD - g2) % MOD;
                ans = (ans + c * P) % MOD;
            }
        }

        out += to_string(ans);
        out += '\n';
    }
    cout << out;
    return 0;
}
