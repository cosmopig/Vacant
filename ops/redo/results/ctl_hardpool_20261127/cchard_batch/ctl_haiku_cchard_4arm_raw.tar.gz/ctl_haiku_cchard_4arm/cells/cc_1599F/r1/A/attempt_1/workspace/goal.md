# Mars

Time limit per test: 2 seconds. Memory limit: 244 MB.

Write a program in Python 3 or C++17 that reads from standard input and writes to standard output.

In the year 2420 humans have finally built a colony on Mars thanks to the work of Elon Tusk. There are 10^9+7 cities arranged in a circle in this colony and none of them are connected yet. Elon Tusk wants to connect some of those cities using only roads of the same size in order to lower the production cost of those roads. Because of that he gave a list on N cites where some cites can appear more than once and Q queries that you need to answer. For the query you need to determine if it is possible to connect all the cities from L_{i} to R_{i} on that list using only roads of length D_{i}. 

Input

The first line contains two integers N and Q (1 ≤ N, Q ≤ 2⋅10^5 ) — the length of the array of cities and the number of queries you need to answer. 

The second lines contains N integers representing the array of cites. Next Q lines contain three integers L, R and D (1 ≤ L_{i}, R_{i} ≤ N, 0 ≤ D_{i} ≤ 10^9+6) — the range of cities that needs to be connected and the length of the road that you can use. 

Output

The output contains Q lines. If it is possible to connect all the cities from the i-th query can be connected with roads of length D_{i} the i-th line should contain the word "Yes", otherwise it should contain the word "No". 

Examples

Input


9 8
17 0 12 6 10 8 2 4 5
2 3 12
2 3 6
2 4 6
4 6 2
2 8 2
1 2 17
1 8 2
9 9 14


Output


Yes
No
Yes
Yes
Yes
Yes
No
Yes


Input


4 1
7 21 14 0
1 4 1000000000


Output


Yes

Note

In the 5^{th} query of the first test case we can connect cities in this order 0-2-4-6-8-10-12 this way distance between any two connected cities is 2. In the second test case we can connect cities in this order 21-14-7-0 this way distance between any two connected cities is 10^9 module 10^9+7.
