// Perfect sequences count.
// Sorted a_1<=...<=a_n is perfect iff for all i<j: sum_{t=i..j} a_t <= a_i*a_j.
// Derived structure (n>=2): either all elements equal n or n+1, or min m in
// [ceil((n+1)/2), n], with c0 copies of m, and the rest excesses e (>=1) summing
// to E <= m, largest excess D = n+1-m, and constraint m*q + E_q <= m*m + m*e_q
// at each upper position q (1-indexed in sorted order).
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int main() {
    ll n, M;
    cin >> n >> M;
    if (n == 1) { cout << 2 % M << "\n"; return 0; }
    vector<vector<ll>> C(n + 1, vector<ll>(n + 1, 0));
    for (int i = 0; i <= n; i++) {
        C[i][0] = 1 % M;
        for (int j = 1; j <= i; j++) C[i][j] = (C[i - 1][j - 1] + (j <= i - 1 ? C[i - 1][j] : 0)) % M;
    }
    ll ans = 2 % M;  // constant sequences all n, and all n+1
    for (ll m = (n + 2) / 2; m <= n; m++) {
        ll D = n + 1 - m;
        ll Emax = m;
        vector<vector<ll>> dp(n + 1, vector<ll>(Emax + 1, 0));
        for (ll c0 = 1; c0 <= min(m, n - 1); c0++) dp[c0][0] = C[n][c0];
        for (ll d = 1; d <= D; d++) {
            vector<vector<ll>> ndp(n + 1, vector<ll>(Emax + 1, 0));
            if (d != D) ndp = dp;  // k = 0 transitions (last value must be D, so k>=1 at d == D)
            for (ll p = 0; p <= n; p++)
                for (ll E = 0; E <= Emax; E++) {
                    ll v = dp[p][E];
                    if (!v) continue;
                    for (ll k = 1; p + k <= n && E + k * d <= Emax; k++) {
                        ll q = p + k, Eq = E + k * d;
                        // constraint for copy j (position p+j, cumulative E+j*d)
                        ll pos = p + k, cum = E + k * d;
                        if (m * pos + cum > m * m + m * d) break;
                        ndp[q][Eq] = (ndp[q][Eq] + v * C[n - p][k]) % M;
                    }
                }
            dp = ndp;
        }
        for (ll E = 0; E <= Emax; E++) ans = (ans + dp[n][E]) % M;
    }
    cout << ans % M << "\n";
    return 0;
}
