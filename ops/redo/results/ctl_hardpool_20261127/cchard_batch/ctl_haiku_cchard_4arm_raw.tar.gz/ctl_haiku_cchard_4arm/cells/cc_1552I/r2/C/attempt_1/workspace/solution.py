import sys

MOD = 998244353


def fact_table(n):
    f = [1] * (n + 1)
    for i in range(1, n + 1):
        f[i] = f[i - 1] * i % MOD
    return f


FACT = fact_table(200)


def overlap(a, b):
    return (not a.isdisjoint(b)) and (not a <= b) and (not b <= a)


def atoms_of_component(sets):
    """sets: list of frozensets forming an overlap-connected component.
    Returns ordered list of blocks (atoms) forced up to reversal, or None if infeasible."""
    # BFS order over overlap graph so each new set overlaps an already-processed set
    k = len(sets)
    seen = [False] * k
    order = [0]
    seen[0] = True
    q = 0
    while q < len(order):
        u = order[q]
        q += 1
        for v in range(k):
            if not seen[v] and overlap(sets[u], sets[v]):
                seen[v] = True
                order.append(v)
    if len(order) != k:
        return None  # should not happen for a component

    first = sets[order[0]]
    blocks = [frozenset(first)]
    P = set(first)
    for idx in order[1:]:
        S = sets[idx]
        N = frozenset(S - P)
        nb = len(blocks)
        status = []
        for b in blocks:
            if b <= S:
                status.append('full')
            elif b.isdisjoint(S):
                status.append('none')
            else:
                status.append('part')
        active = [t for t in range(nb) if status[t] != 'none']
        if not active:
            return None
        i, j = active[0], active[-1]
        for t in range(i, j + 1):
            if status[t] == 'none':
                return None
        if N:
            right_ok = (j == nb - 1) and all(status[t] == 'full' for t in range(i + 1, nb))
            left_ok = (i == 0) and all(status[t] == 'full' for t in range(0, j))
            new = []
            if right_ok:
                for t, b in enumerate(blocks):
                    if t == i and status[t] == 'part':
                        new.append(b - S)
                        new.append(b & S)
                    else:
                        new.append(b)
                new.append(N)
            elif left_ok:
                new.append(N)
                for t, b in enumerate(blocks):
                    if t == j and status[t] == 'part':
                        new.append(b & S)
                        new.append(b - S)
                    else:
                        new.append(b)
            else:
                return None
        else:
            if i == j:
                return None  # cannot happen under overlap
            for t in range(i + 1, j):
                if status[t] != 'full':
                    return None
            new = []
            for t, b in enumerate(blocks):
                if t == i and status[t] == 'part':
                    new.append(b - S)
                    new.append(b & S)
                elif t == j and status[t] == 'part':
                    new.append(b & S)
                    new.append(b - S)
                else:
                    new.append(b)
        blocks = [frozenset(b) for b in new]
        P |= S
    return blocks


def count(U, family):
    """Number of orderings of U in which every set of family is contiguous.
    All sets in family are assumed to be subsets of U."""
    size = len(U)
    F = set()
    for S in family:
        if 2 <= len(S) < size:
            F.add(frozenset(S))
    F = list(F)
    if not F:
        return FACT[size]

    k = len(F)
    # overlap components
    comp = [-1] * k
    comps = []
    for s in range(k):
        if comp[s] != -1:
            continue
        cid = len(comps)
        members = [s]
        comp[s] = cid
        q = 0
        while q < len(members):
            u = members[q]
            q += 1
            for v in range(k):
                if comp[v] == -1 and overlap(F[u], F[v]):
                    comp[v] = cid
                    members.append(v)
        comps.append(members)

    unions = []
    for members in comps:
        un = set()
        for m in members:
            un |= F[m]
        unions.append(frozenset(un))

    # Case B: some overlap component spans the whole universe -> Q-node
    for cid, members in enumerate(comps):
        if unions[cid] == U:
            sets = [F[m] for m in members]
            atoms = atoms_of_component(sets)
            if atoms is None:
                return 0
            res = 2
            for atom in atoms:
                sub = [S for S in F if S <= atom]
                c = count(atom, sub)
                if c == 0:
                    return 0
                res = res * c % MOD
            return res

    # Case A: P-node over maximal unions and uncovered singletons
    uniq = list(set(unions))
    maximal = [M for M in uniq if not any(M < O for O in uniq)]
    covered = set()
    for M in maximal:
        covered |= M
    top = len(maximal) + (size - len(covered))
    res = FACT[top]
    for M in maximal:
        sub = [S for S in F if S <= M]
        c = count(M, sub)
        if c == 0:
            return 0
        res = res * c % MOD
    return res


def main():
    data = sys.stdin.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    m = int(data[pos]); pos += 1
    sets = []
    for _ in range(m):
        q = int(data[pos]); pos += 1
        s = frozenset(int(x) for x in data[pos:pos + q])
        pos += q
        sets.append(s)
    U = frozenset(range(1, n + 1))
    print(count(U, sets) % MOD)


if __name__ == "__main__":
    main()
