import sys

MOD = 10 ** 9 + 7


def fib_pair(n):
    """Return (F(n), F(n+1)) mod MOD using fast doubling."""
    a, b = 0, 1  # F(0), F(1)
    for bit in bin(n)[2:]:
        # Doubling step: F(2k) and F(2k+1) from F(k) and F(k+1)
        c = a * ((2 * b - a) % MOD) % MOD
        d = (a * a + b * b) % MOD
        if bit == "1":
            a, b = d, (c + d) % MOD
        else:
            a, b = c, d
    return a


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    q = int(data[pos]); pos += 1
    a1 = [int(x) for x in data[pos:pos + n]]; pos += n
    a2 = [int(x) for x in data[pos:pos + n]]; pos += n
    arrays = (a1, a2)
    out = []
    for _ in range(q):
        t = int(data[pos]); pos += 1
        if t == 4:
            l = int(data[pos]) - 1
            r = int(data[pos + 1])  # exclusive end (0-based)
            pos += 2
            total = 0
            for i in range(l, r):
                total += fib_pair(a1[i] + a2[i])
            out.append(total % MOD)
        else:
            k = int(data[pos]) - 1
            l = int(data[pos + 1]) - 1
            r = int(data[pos + 2])
            x = int(data[pos + 3])
            pos += 4
            arr = arrays[k]
            if t == 1:
                for i in range(l, r):
                    if arr[i] > x:
                        arr[i] = x
            elif t == 2:
                for i in range(l, r):
                    if arr[i] < x:
                        arr[i] = x
            else:
                for i in range(l, r):
                    arr[i] += x
    sys.stdout.write("\n".join(map(str, out)) + ("\n" if out else ""))


if __name__ == "__main__":
    main()
