import sys

M = 998244353
P = 10 ** 9 + 7


def main():
    n = int(sys.stdin.read().split()[0])
    D = len(str(n))
    pw = [10 ** k for k in range(D + 2)]

    def pos(x):
        # number of y in [1, n] with lex(y) <= lex(x)
        L = len(str(x))
        total = 0
        for l in range(1, D + 1):
            if l <= L:
                p = x // pw[L - l]
                total += p - pw[l - 1] + 1
            else:
                hi = min(n, x * pw[l - L] - 1)
                lo = pw[l - 1]
                if hi >= lo:
                    total += hi - lo + 1
        return total

    def d(x):
        return pos(x) - x

    # S = sum over x in [1, n] of floor(d(x) / M), where d(x) = pos(x) - x.
    # Within a digit-length block, d is non-decreasing in x, so we split
    # the interval recursively wherever floor(d / M) changes.
    S = 0
    for L in range(1, D + 1):
        lo_x = pw[L - 1]
        hi_x = min(pw[L] - 1, n)
        if lo_x > hi_x:
            continue
        stack = []
        dl = d(lo_x)
        dh = d(hi_x)
        stack.append((lo_x, hi_x, dl, dh))
        while stack:
            a, b, da, db = stack.pop()
            fa = da // M
            fb = db // M
            if fa == fb:
                S += fa * (b - a + 1)
                continue
            if b - a <= 1:
                S += fa + fb
                continue
            m = (a + b) // 2
            dm = d(m)
            dm1 = d(m + 1)
            stack.append((a, m, da, dm))
            stack.append((m + 1, b, dm1, db))
    print((-M * S) % P)


main()
