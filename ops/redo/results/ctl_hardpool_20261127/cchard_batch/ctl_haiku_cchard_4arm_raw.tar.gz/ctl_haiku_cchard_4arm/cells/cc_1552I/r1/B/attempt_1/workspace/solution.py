import sys
from collections import deque

MOD = 998244353


def main():
    data = sys.stdin.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    m = int(data[pos]); pos += 1
    sets = []
    for _ in range(m):
        q = int(data[pos]); pos += 1
        s = frozenset(int(x) for x in data[pos:pos + q])
        pos += q
        sets.append(s)

    fact = [1] * (n + 2)
    for i in range(1, n + 2):
        fact[i] = fact[i - 1] * i % MOD

    def overlap(a, b):
        return bool(a & b) and not (a <= b) and not (b <= a)

    def split_right(b, S):
        # block b with the S-part placed on the right side
        return [x for x in (b - S, b & S) if x]

    def split_left(b, S):
        # block b with the S-part placed on the left side
        return [x for x in (b & S, b - S) if x]

    def place(blocks, S):
        # Add set S (overlapping some already-placed set) to an ordered
        # sequence of blocks. Returns the new sequence or None if infeasible.
        W = frozenset().union(*blocks)
        N = S - W
        k = len(blocks)
        idx = [i for i, b in enumerate(blocks) if b & S]
        if not idx:
            return None
        l, r = idx[0], idx[-1]
        if idx != list(range(l, r + 1)):
            return None
        full = [blocks[i] <= S for i in range(k)]
        if N:
            # Option 1: append new elements on the right end.
            if r == k - 1 and all(full[i] for i in range(l + 1, k)):
                return blocks[:l] + split_right(blocks[l], S) + blocks[l + 1:] + [N]
            # Option 2: prepend new elements on the left end.
            if l == 0 and all(full[i] for i in range(0, r)):
                return [N] + blocks[:r] + split_left(blocks[r], S) + blocks[r + 1:]
            return None
        if l == r:
            return None
        if not all(full[i] for i in range(l + 1, r)):
            return None
        return (blocks[:l] + split_right(blocks[l], S) + blocks[l + 1:r]
                + split_left(blocks[r], S) + blocks[r + 1:])

    def count(U, sets):
        sets = list({s for s in sets if 2 <= len(s) < len(U)})
        if not sets:
            return fact[len(U)]
        k = len(sets)
        adj = [[] for _ in range(k)]
        for i in range(k):
            for j in range(i + 1, k):
                if overlap(sets[i], sets[j]):
                    adj[i].append(j)
                    adj[j].append(i)
        seen = [False] * k
        comps = []  # list of BFS orders
        for s in range(k):
            if seen[s]:
                continue
            seen[s] = True
            order = []
            dq = deque([s])
            while dq:
                x = dq.popleft()
                order.append(x)
                for y in adj[x]:
                    if not seen[y]:
                        seen[y] = True
                        dq.append(y)
            comps.append(order)

        unions = []
        for order in comps:
            u = frozenset()
            for x in order:
                u = u | sets[x]
            unions.append(u)

        # Case B: an overlap component covers all of U -> order of atoms is forced up to reversal.
        for ci, order in enumerate(comps):
            if unions[ci] == U:
                blocks = [sets[order[0]]]
                for x in order[1:]:
                    blocks = place(blocks, sets[x])
                    if blocks is None:
                        return 0
                # Verify every set of this component is a contiguous run of blocks.
                for x in order:
                    S = sets[x]
                    touched = [i for i, b in enumerate(blocks) if b & S]
                    if touched != list(range(touched[0], touched[-1] + 1)):
                        return 0
                    for i in touched:
                        if not (blocks[i] <= S or not (blocks[i] & S)):
                            return 0
                res = 2
                for b in blocks:
                    sub = [s for s in sets if s <= b]
                    res = res * count(b, sub) % MOD
                    if res == 0:
                        return 0
                return res

        # Case A: unions of components form a laminar family; the maximal ones are free blocks.
        us = set(unions)
        maximal = [u for u in us if not any(u < v for v in us)]
        covered = frozenset().union(*maximal) if maximal else frozenset()
        children = len(maximal) + len(U - covered)
        res = fact[children]
        for M in maximal:
            sub = [s for s in sets if s <= M]
            res = res * count(M, sub) % MOD
            if res == 0:
                return 0
        return res

    U = frozenset(range(1, n + 1))
    print(count(U, sets) % MOD)


main()
