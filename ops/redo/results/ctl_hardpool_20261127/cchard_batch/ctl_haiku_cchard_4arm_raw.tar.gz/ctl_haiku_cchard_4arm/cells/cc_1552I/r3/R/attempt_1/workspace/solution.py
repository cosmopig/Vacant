import sys

MOD = 998244353


def popcount(x):
    return bin(x).count("1")


def overlap(a, b):
    return (a & b) != 0 and (a & ~b) != 0 and (b & ~a) != 0


def split_left(p, s):
    # part p placed before the S-part: (p \ S, p & S)
    inter = p & s
    if inter == 0 or inter == p:
        return [p]
    return [p & ~s, inter]


def split_right(p, s):
    # part p placed after the S-part: (p & S, p \ S)
    inter = p & s
    if inter == 0 or inter == p:
        return [p]
    return [inter, p & ~s]


def insert_set(parts, s):
    """Insert set s into the ordered partition `parts` (overlapping an already
    inserted set). Returns the new ordered partition, or None if impossible."""
    t = len(parts)
    u = 0
    for p in parts:
        u |= p
    idx = [i for i in range(t) if parts[i] & s]
    if not idx:
        raise RuntimeError("set does not touch current union")
    l, r = idx[0], idx[-1]

    def full(i):
        return (parts[i] & ~s) == 0

    for i in range(l + 1, r):
        if not full(i):
            return None
    new = s & ~u
    if new == 0:
        if l == r:
            raise RuntimeError("set inside a single part: impossible in BFS order")
        return (parts[:l] + split_left(parts[l], s) + parts[l + 1:r]
                + split_right(parts[r], s) + parts[r + 1:])
    right_ok = (r == t - 1) and all(full(i) for i in range(l + 1, t))
    left_ok = (l == 0) and all(full(i) for i in range(0, r))
    if right_ok:
        return parts[:l] + split_left(parts[l], s) + parts[l + 1:] + [new]
    if left_ok:
        return [new] + parts[:r] + split_right(parts[r], s) + parts[r + 1:]
    return None


def bfs_order(sets, members):
    """Order the given set indices so each one overlaps an earlier one."""
    seen = {members[0]}
    order = [members[0]]
    queue = [members[0]]
    while queue:
        a = queue.pop(0)
        for b in members:
            if b not in seen and overlap(sets[a], sets[b]):
                seen.add(b)
                order.append(b)
                queue.append(b)
    return order


def count(x, fam):
    """Number of orderings of the elements of bitmask x such that every mask
    in fam (all subsets of x) is consecutive."""
    px = popcount(x)
    fp = []
    seen = set()
    for d in fam:
        if d & ~x == 0 and 2 <= popcount(d) < px and d not in seen:
            seen.add(d)
            fp.append(d)
    if not fp:
        return FACT[px]

    k = len(fp)
    adj = [[j for j in range(k) if j != i and overlap(fp[i], fp[j])] for i in range(k)]
    comp_id = [-1] * k
    comps = []
    for i in range(k):
        if comp_id[i] != -1:
            continue
        cid = len(comps)
        comp_id[i] = cid
        members = [i]
        q = [i]
        while q:
            a = q.pop()
            for b in adj[a]:
                if comp_id[b] == -1:
                    comp_id[b] = cid
                    members.append(b)
                    q.append(b)
        comps.append(members)

    unions = []
    for members in comps:
        u = 0
        for i in members:
            u |= fp[i]
        unions.append(u)

    # Case B: an overlap component spans the whole of x.
    for cid, members in enumerate(comps):
        if unions[cid] == x:
            return case_b(x, fp, [fp[i] for i in members])

    # Case A: x is a P-node over maximal component unions and free singletons.
    uniq = set(unions)
    maximal = [u for u in uniq if not any(v != u and (u & v) == u for v in uniq)]
    covered = 0
    for u in maximal:
        covered |= u
    r = len(maximal) + popcount(x) - sum(popcount(u) for u in maximal)
    res = FACT[r]
    for b in maximal:
        res = res * count(b, [d for d in fp if d & ~b == 0]) % MOD
        if res == 0:
            return 0
    return res


def case_b(x, fp, comp_sets):
    order = bfs_order(comp_sets, list(range(len(comp_sets))))
    parts = [comp_sets[order[0]]]
    for j in order[1:]:
        parts = insert_set(parts, comp_sets[j])
        if parts is None:
            return 0
    # Verify every set of the component is a consecutive run of whole parts.
    for s in comp_sets:
        idx = [i for i, p in enumerate(parts) if p & s]
        if idx[-1] - idx[0] + 1 != len(idx):
            return 0
        if any((parts[i] & ~s) != 0 for i in idx):
            return 0
    res = 2
    for p in parts:
        res = res * count(p, [d for d in fp if d & ~p == 0]) % MOD
        if res == 0:
            return 0
    return res


FACT = [1] * 201
for _i in range(1, 201):
    FACT[_i] = FACT[_i - 1] * _i % MOD


def main():
    data = sys.stdin.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    m = int(data[pos]); pos += 1
    sets = []
    for _ in range(m):
        q = int(data[pos]); pos += 1
        mask = 0
        for _j in range(q):
            s = int(data[pos]); pos += 1
            mask |= 1 << (s - 1)
        sets.append(mask)
    full = (1 << n) - 1
    print(count(full, sets) % MOD)


if __name__ == "__main__":
    main()
