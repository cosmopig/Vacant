// Kuzya and Homework.
//
// Let P_k(p) be the exponent of prime p in the running product after k steps
// (P_0 = 0). Segment [s+1, r] is simple iff for every '/' step j in (s, r] and
// every prime p | a_j we have P_j(p) >= P_s(p). Equivalently, start s "dies"
// at the first '/' step j where some prime's exponent drops below its value
// at s. Let R(s) be that step (n+1 if it never happens); then the number of
// simple segments starting at s+1 is R(s) - 1 - s.
//
// For each prime p we keep a monotone stack of blocks of start indices s that
// share the same value P_s(p). Invariant: block values are nondecreasing from
// bottom to top and never exceed the current value of P(p). A '/' step that
// lowers P(p) to t kills exactly the blocks with value > t, which are popped
// from the top. Each start index is killed once; DSU "next alive" skips dead
// indices. Total work is O((n + sum of omega(a_i)) * alpha).

#include <bits/stdc++.h>
using namespace std;

const int MAXV = 1000001;
static int spf[MAXV];
static int curE[MAXV];
static int startP[MAXV];

struct Blk {
    int val, lo, hi;  // block of starts s in [lo, hi], all with P_s(p) == val
};

static vector<int> par;

static int findAlive(int x) {
    while (par[x] != x) {
        par[x] = par[par[x]];
        x = par[x];
    }
    return x;
}

int main() {
    int n;
    if (scanf("%d", &n) != 1) return 0;
    vector<int> a(n + 1);
    for (int i = 1; i <= n; i++) scanf("%d", &a[i]);
    vector<char> buf(n + 16);
    scanf("%s", buf.data());
    // buf[j-1] is b_j

    // Smallest prime factor sieve.
    for (int i = 2; i < MAXV; i++) {
        if (spf[i] == 0) {
            for (int j = i; j < MAXV; j += i)
                if (spf[j] == 0) spf[j] = i;
        }
    }

    vector<vector<Blk>> st(MAXV);
    vector<int> R(n + 1, n + 1);
    par.resize(n + 2);
    for (int i = 0; i <= n + 1; i++) par[i] = i;

    for (int j = 1; j <= n; j++) {
        bool star = (buf[j - 1] == '*');
        int x = a[j];
        while (x > 1) {
            int p = spf[x];
            int e = 0;
            while (x % p == 0) {
                x /= p;
                e++;
            }
            // Close the open block (starts [startP[p], j-1], value curE[p]).
            st[p].push_back({curE[p], startP[p], j - 1});
            if (star) {
                curE[p] += e;
                startP[p] = j;
            } else {
                curE[p] -= e;
                startP[p] = j;
                // Kill every block whose value exceeds the new exponent.
                vector<Blk>& stk = st[p];
                while (!stk.empty() && stk.back().val > curE[p]) {
                    Blk bk = stk.back();
                    stk.pop_back();
                    for (int s = findAlive(bk.lo); s <= bk.hi; s = findAlive(s)) {
                        R[s] = j;
                        par[s] = s + 1;
                    }
                }
            }
        }
    }

    long long ans = 0;
    for (int s = 0; s < n; s++) {
        ans += (long long)(R[s] - 1 - s);
    }
    printf("%lld\n", ans);
    return 0;
}
