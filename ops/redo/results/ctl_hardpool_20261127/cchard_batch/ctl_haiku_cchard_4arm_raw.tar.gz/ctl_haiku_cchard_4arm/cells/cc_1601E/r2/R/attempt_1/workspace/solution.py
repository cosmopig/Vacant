import sys
from bisect import bisect_left


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    q = int(data[1])
    k = int(data[2])
    a = [0] * (n + 2)
    for i in range(n):
        a[i + 1] = int(data[3 + i])
    p = 3 + n
    L = [0] * q
    R = [0] * q
    for j in range(q):
        L[j] = int(data[p])
        R[j] = int(data[p + 1])
        p += 2

    # Leftmost position of the minimum of a[l..r] for every query (sweep over r).
    by_r = [[] for _ in range(n + 1)]
    for j in range(q):
        by_r[R[j]].append(j)
    qm = [0] * q
    st = []
    for r in range(1, n + 1):
        ar = a[r]
        while st and a[st[-1]] > ar:
            st.pop()
        st.append(r)
        for j in by_r[r]:
            qm[j] = st[bisect_left(st, L[j])]

    # Events: at time L[j] add prefix(c) to partial[j]; at time qm[j] subtract it.
    ev_start = [[] for _ in range(n + 2)]
    ev_end = [[] for _ in range(n + 2)]
    for j in range(q):
        ev_start[L[j]].append(j)
        ev_end[qm[j]].append(j)

    # Sweep l from n down to 1, maintaining the chain of "next strictly smaller"
    # positions starting at l (a monotone stack) inside a Fenwick tree over residues.
    Gs = [0] * (n + 2)
    par = [n + 1] * (n + 2)
    bit = [0] * (k + 1)
    partial = [0] * q
    chain = []
    for l in range(n, 0, -1):
        al = a[l]
        while chain and a[chain[-1]] >= al:
            y = chain.pop()
            ay = a[y]
            i = (y - 1) % k + 1
            while i <= k:
                bit[i] -= ay
                i += i & -i
            py = par[y]
            if py <= n:
                i = (py - 1) % k + 1
                while i <= k:
                    bit[i] += ay
                    i += i & -i
        pl = chain[-1] if chain else n + 1
        par[l] = pl
        Gs[l] = al * ((pl - 1) // k - (l - 1) // k) + Gs[pl]
        chain.append(l)
        i = (l - 1) % k + 1
        while i <= k:
            bit[i] += al
            i += i & -i
        if pl <= n:
            i = (pl - 1) % k + 1
            while i <= k:
                bit[i] -= al
                i += i & -i

        for j in ev_start[l]:
            c = L[j] % k
            s = 0
            i = c
            while i > 0:
                s += bit[i]
                i -= i & -i
            partial[j] += s
        for j in ev_end[l]:
            c = L[j] % k
            s = 0
            i = c
            while i > 0:
                s += bit[i]
                i -= i & -i
            partial[j] -= s

    out = []
    for j in range(q):
        l = L[j]
        r = R[j]
        m = qm[j]
        c = l % k
        ir = 1 if r % k < c else 0
        im = 1 if (m - 1) % k < c else 0
        ans = Gs[l] - Gs[m] + partial[j] + a[m] * ((r // k - ir) - ((m - 1) // k - im))
        out.append(ans)
    sys.stdout.write("\n".join(map(str, out)) + "\n")


main()
