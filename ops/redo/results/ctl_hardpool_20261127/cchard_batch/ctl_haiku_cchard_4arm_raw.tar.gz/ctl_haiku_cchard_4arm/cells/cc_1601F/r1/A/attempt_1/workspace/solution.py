import sys

M = 998244353
P = 10 ** 9 + 7


def main():
    n = int(sys.stdin.read().split()[0])
    D = len(str(n))
    pw = [10 ** k for k in range(D + 2)]

    def rank(x, L):
        # number of y in [1, n] that are lexicographically <= x, where len(x) == L
        total = 0
        for l in range(1, L):
            # y of length l with y <= prefix_l(x) (numeric == lex for same length)
            total += x // pw[L - l] - pw[l - 1] + 1
        total += x - pw[L - 1] + 1  # length L: y <= x
        for l in range(L + 1, D + 1):
            # y of length l whose length-L prefix is < x
            hi = min(n, x * pw[l - L] - 1)
            if hi >= pw[l - 1]:
                total += hi - pw[l - 1] + 1
        return total

    S = 0
    for L in range(1, D + 1):
        lo = pw[L - 1]
        hi = min(n, pw[L] - 1)
        if lo > hi:
            continue
        N = hi - lo + 1

        def V(x):
            return rank(x, L) - x

        # V is non-decreasing on [lo, hi]: rank strictly increases with x inside a
        # length block, so V(x+1) - V(x) = rank(x+1) - rank(x) - 1 >= 0.
        gl = V(lo) // M
        gh = V(hi) // M
        S += gl * N
        left = lo  # f_k is non-decreasing in k, so the search can start from here
        for k in range(gl + 1, gh + 1):
            target = k * M
            a, b = left, hi  # find smallest x in [a, b] with V(x) >= target
            while a < b:
                mid = (a + b) // 2
                if V(mid) >= target:
                    b = mid
                else:
                    a = mid + 1
            left = a
            S += hi - a + 1

    ans = (-M * S) % P
    print(ans)


main()
