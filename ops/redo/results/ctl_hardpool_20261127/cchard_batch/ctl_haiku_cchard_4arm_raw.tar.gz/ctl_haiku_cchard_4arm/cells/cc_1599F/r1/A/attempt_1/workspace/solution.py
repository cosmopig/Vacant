import sys

MOD = 10**9 + 7


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    q = int(data[1])
    a = [int(x) % MOD for x in data[2:2 + n]]
    out = []
    pos = 2 + n
    for _ in range(q):
        l = int(data[pos]) - 1
        r = int(data[pos + 1])
        d = int(data[pos + 2]) % MOD
        pos += 3
        s = set(a[l:r])
        k = len(s)
        if k == 1:
            out.append("Yes")
            continue
        if d == 0:
            # Equal values only connect to each other; distinct values never do.
            out.append("No")
            continue
        # Roads join x and x+d (mod MOD). Two cities with x == x+d are impossible
        # since d != 0. The distinct values are connected iff the edges form a
        # spanning path, i.e. exactly k-1 edges (k distinct values).
        links = 0
        for x in s:
            if (x + d) % MOD in s:
                links += 1
        out.append("Yes" if links == k - 1 else "No")
    sys.stdout.write("\n".join(out) + ("\n" if out else ""))


main()
