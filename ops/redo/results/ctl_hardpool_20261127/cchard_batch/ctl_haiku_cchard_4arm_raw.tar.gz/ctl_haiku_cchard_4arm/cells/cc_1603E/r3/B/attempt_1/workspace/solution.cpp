// Count perfect sequences modulo prime M.
//
// Derivation: for a multiset with minimum m, the hardest subset with maximum h
// is all elements <= h, so the condition is: for every h >= m,
//     sum_{x<=h} x*c_x <= m*h.
// Write K_h = #elements <= h and E_h = sum_{x<=h} (x-m)*c_x. Then the condition is
//     E_h <= m*(h - K_h)   for all h in [m, n+1].
// Elements larger than m each add excess >= 1, and E_{n+1} <= m, so the number of
// elements above the current value is small. We DP over values x = m..n+1 with
// state (d = #elements > x, e = excess so far), weight 1/c_x!, and multiply by n!.
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

ll MOD;

ll power(ll b, ll e) {
    ll r = 1 % MOD;
    b %= MOD;
    while (e > 0) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

int main() {
    int n;
    cin >> n >> MOD;

    vector<ll> fact(n + 1), invfact(n + 1);
    fact[0] = 1;
    for (int i = 1; i <= n; i++) fact[i] = fact[i - 1] * i % MOD;
    for (int i = 0; i <= n; i++) invfact[i] = power(fact[i], MOD - 2);

    ll ans = 0;
    for (int m = 1; m <= n + 1; m++) {
        // dp[d][e]: d = number of elements with value > x, e = excess so far.
        // Bounds on d (= #elements > x) after processing value x:
        //   d >= n - x                (at most x elements are <= x)
        //   d * (x+1-m) <= m          (each element above x adds excess >= x+1-m)
        vector<vector<ll>> dp(n + 1, vector<ll>(m + 1, 0)), ndp;
        dp[n][0] = 1;  // before value m, all n elements are "above"
        int Dprev = n;
        for (int x = m; x <= n + 1; x++) {
            int Dnew = min(n, m / (x + 1 - m));
            ndp.assign(Dnew + 1, vector<ll>(m + 1, 0));
            int lo = max(0, n - x);
            for (int d = 0; d <= Dprev; d++) {
                for (int e = 0; e <= m; e++) {
                    ll cur = dp[d][e];
                    if (cur == 0) continue;
                    for (int dn = lo; dn <= min(d, Dnew); dn++) {
                        int c = d - dn;  // elements with value exactly x
                        if (x == m && c == 0) continue;  // minimum must be m
                        ll ne = e + (ll)c * (x - m);
                        if (ne > m) continue;
                        if (ne + (ll)dn * (x + 1 - m) > m) continue;  // cannot fit later excess
                        int K = n - dn;  // elements <= x
                        if (ne > (ll)m * (x - K)) continue;
                        ndp[dn][ne] = (ndp[dn][ne] + cur * invfact[c]) % MOD;
                    }
                }
            }
            dp.swap(ndp);
            dp.resize(n + 1, vector<ll>(m + 1, 0));
            Dprev = Dnew;
        }
        ll g = 0;
        for (int e = 0; e <= m; e++) g = (g + dp[0][e]) % MOD;
        ans = (ans + g * fact[n]) % MOD;
    }
    cout << ans % MOD << "\n";
    return 0;
}
