#include <bits/stdc++.h>
using namespace std;

// A sequence is perfect iff, with v = minimum value and P(w) = sum of elements <= w:
//   P(w) <= v*w for every w present, and cnt_u <= u for every value u.
// Non-constant perfect multisets need v >= (n+1)/2, so only those v (plus the constant case) are enumerated.
// DP over values u = v..n+1 with state (k = elements placed, E = sum of (x - v) over placed elements).
// The sequence count is the product of binomials C(k+c, c) as copies of each value are interleaved.
int main() {
    long long n, M;
    cin >> n >> M;
    int N = (int)n + 2;
    vector<vector<long long>> C(N + 1, vector<long long>(N + 1, 0));
    for (int i = 0; i <= N; i++) {
        C[i][0] = 1 % M;
        for (int j = 1; j <= i; j++) C[i][j] = (C[i - 1][j - 1] + C[i - 1][j]) % M;
    }
    long long ans = 0;
    long long vlo = (n + 2) / 2;  // ceil((n+1)/2)
    if (vlo < 1) vlo = 1;
    for (long long v = vlo; v <= n + 1; v++) {
        int V = (int)v;
        vector<vector<long long>> dp(n + 1, vector<long long>(V + 1, 0));
        for (int a = 1; a <= min<long long>(v, n); a++) dp[a][0] = 1 % M;  // cnt_v = a <= v
        for (long long u = v + 1; u <= n + 1; u++) {
            long long d = u - v;
            vector<vector<long long>> ndp(n + 1, vector<long long>(V + 1, 0));
            for (int k = 0; k <= n; k++)
                for (int E = 0; E <= V; E++) {
                    long long cur = dp[k][E];
                    if (!cur) continue;
                    for (int c = 0; c <= min<long long>(u, n - k); c++) {
                        long long E2 = E + c * d;
                        if (E2 > V) break;
                        int k2 = k + c;
                        if (v * k2 + E2 > v * u) break;
                        ndp[k2][E2] = (ndp[k2][E2] + cur * C[k2][c]) % M;
                    }
                }
            dp.swap(ndp);
        }
        for (int E = 0; E <= V; E++) ans = (ans + dp[n][E]) % M;
    }
    cout << ans % M << "\n";
    return 0;
}
