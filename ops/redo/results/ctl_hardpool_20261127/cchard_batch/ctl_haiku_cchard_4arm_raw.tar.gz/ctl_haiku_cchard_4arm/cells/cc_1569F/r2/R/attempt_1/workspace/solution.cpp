// Palindromic Hamiltonian Path counting.
//
// A palindromic Hamiltonian path v_1..v_n (n = 2h) pairs the vertices into
// h "mirror pairs" (v_i, v_{n+1-i}) that must carry equal letters. So a letter
// string is good iff there is a perfect matching M of the vertices that
//   (a) is "valid": its pairs can be ordered/oriented as (a_i,b_i), i=1..h,
//       with a_i~a_{i+1}, b_i~b_{i+1} and a_h~b_h, and
//   (b) every pair of M is monochromatic.
//
// Step 1: enumerate all perfect matchings (<= 11!! = 10395) and keep valid ones.
// Step 2: enumerate set partitions of the vertices (colour classes) by DFS,
//   maintaining the bitset of valid matchings still compatible with the
//   partial partition (every matching pair whose later vertex is assigned must
//   lie inside one block). A partition is good iff the bitset is non-empty at
//   the end; it contributes the number of colourings with exactly that kernel,
//   k*(k-1)*...*(k-b+1) for b blocks.
#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long u64;

int n, m, K;
int adjm[12];                       // adjacency bitmasks
vector<vector<int>> validMatch;     // partner arrays of valid matchings
int W;                              // words per bitset
// Allowed[i][T]: matchings where partner(i) > i or partner(i) in T (T over vertices < i)
vector<vector<u64>> Allowed[12];
long long answer = 0;
vector<vector<u64>> bufs;           // per-depth bitsets

static long long falling(int k, int b) {
    if (b > k) return 0;
    long long r = 1;
    for (int t = 0; t < b; t++) r *= (k - t);
    return r;
}

// Check whether matching (pairs p) admits a palindromic Hamiltonian path structure.
static bool isValid(const vector<pair<int,int>>& p) {
    int h = p.size();
    // reach[mask][idx][o]: pairs in mask placed as nested outer->inner, last placed is idx
    // with orientation o (a = o ? p.second : p.first, b = other end).
    static bool reach[1 << 6][6][2];
    int full = (1 << h) - 1;
    for (int mask = 0; mask <= full; mask++)
        for (int i = 0; i < h; i++)
            for (int o = 0; o < 2; o++) reach[mask][i][o] = false;
    for (int s = 0; s < h; s++)
        for (int o = 0; o < 2; o++) reach[1 << s][s][o] = true;
    for (int mask = 1; mask <= full; mask++) {
        for (int i = 0; i < h; i++) {
            if (!(mask >> i & 1)) continue;
            for (int o = 0; o < 2; o++) {
                if (!reach[mask][i][o]) continue;
                int a = o ? p[i].second : p[i].first;
                int b = o ? p[i].first : p[i].second;
                for (int j = 0; j < h; j++) {
                    if (mask >> j & 1) continue;
                    for (int o2 = 0; o2 < 2; o2++) {
                        int a2 = o2 ? p[j].second : p[j].first;
                        int b2 = o2 ? p[j].first : p[j].second;
                        if ((adjm[a] >> a2 & 1) && (adjm[b] >> b2 & 1))
                            reach[mask | (1 << j)][j][o2] = true;
                    }
                }
            }
        }
    }
    for (int i = 0; i < h; i++)
        for (int o = 0; o < 2; o++) {
            if (!reach[full][i][o]) continue;
            int a = o ? p[i].second : p[i].first;
            int b = o ? p[i].first : p[i].second;
            if (adjm[a] >> b & 1) return true;
        }
    return false;
}

static void genMatchings(int used, vector<int>& partner) {
    int v = -1;
    for (int i = 0; i < n; i++)
        if (!(used >> i & 1)) { v = i; break; }
    if (v < 0) {
        // complete matching
        vector<pair<int,int>> p;
        for (int i = 0; i < n; i++)
            if (partner[i] > i) p.push_back({i, partner[i]});
        if (isValid(p)) validMatch.push_back(partner);
        return;
    }
    for (int u = v + 1; u < n; u++) {
        if (used >> u & 1) continue;
        partner[v] = u; partner[u] = v;
        genMatchings(used | (1 << v) | (1 << u), partner);
    }
}

static void dfs(int i, const u64* S, vector<unsigned>& blocks) {
    if (i == n) {
        bool nonzero = false;
        for (int w = 0; w < W; w++) if (S[w]) { nonzero = true; break; }
        if (nonzero) answer += falling(K, blocks.size());
        return;
    }
    int nb = blocks.size();
    // Option 1: join each existing block
    for (int b = 0; b < nb; b++) {
        unsigned T = blocks[b];
        const vector<u64>& A = Allowed[i][T];
        u64* out = bufs[i].data();
        bool nonzero = false;
        for (int w = 0; w < W; w++) { out[w] = S[w] & A[w]; if (out[w]) nonzero = true; }
        if (!nonzero) continue;
        blocks[b] |= (1u << i);
        dfs(i + 1, out, blocks);
        blocks[b] &= ~(1u << i);
    }
    // Option 2: open a new block {i}
    if (nb + 1 <= K) {
        const vector<u64>& A = Allowed[i][0];
        u64* out = bufs[i].data();
        bool nonzero = false;
        for (int w = 0; w < W; w++) { out[w] = S[w] & A[w]; if (out[w]) nonzero = true; }
        if (nonzero) {
            blocks.push_back(1u << i);
            dfs(i + 1, out, blocks);
            blocks.pop_back();
        }
    }
}

int main() {
    if (!(cin >> n >> m >> K)) return 0;
    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        u--; v--;
        if (u < 0 || v < 0 || u >= n || v >= n || u == v) continue;  // ignore invalid/self edges
        adjm[u] |= 1 << v;
        adjm[v] |= 1 << u;
    }
    vector<int> partner(n, -1);
    genMatchings(0, partner);
    int C = validMatch.size();
    if (C == 0) { printf("0\n"); return 0; }
    W = (C + 63) / 64;

    // Eq[i][j]: matchings with partner(i)==j (j<i);  Gt[i]: partner(i)>i
    vector<vector<vector<u64>>> Eq(n, vector<vector<u64>>(n, vector<u64>(W, 0)));
    vector<vector<u64>> Gt(n, vector<u64>(W, 0));
    for (int c = 0; c < C; c++) {
        for (int i = 0; i < n; i++) {
            int j = validMatch[c][i];
            if (j > i) Gt[i][c >> 6] |= 1ULL << (c & 63);
            else Eq[i][j][c >> 6] |= 1ULL << (c & 63);
        }
    }
    // Allowed[i][T] for T subset of {0..i-1}
    for (int i = 0; i < n; i++) {
        int cnt = 1 << i;
        Allowed[i].assign(cnt, vector<u64>(W, 0));
        // U[T] = OR of Eq[i][j] for j in T
        for (int T = 0; T < cnt; T++) {
            vector<u64> cur = Gt[i];
            for (int j = 0; j < i; j++)
                if (T >> j & 1)
                    for (int w = 0; w < W; w++) cur[w] |= Eq[i][j][w];
            Allowed[i][T] = cur;
        }
    }
    bufs.assign(n + 1, vector<u64>(W, 0));
    vector<u64> S0(W, 0);
    for (int c = 0; c < C; c++) S0[c >> 6] |= 1ULL << (c & 63);
    vector<unsigned> blocks;
    dfs(0, S0.data(), blocks);
    printf("%lld\n", answer);
    return 0;
}
