// Two Arrays: sqrt decomposition with lazy clamp-and-add tags per block.
//
// For each array j and block b the tag represents the map
//     v -> clamp(v + d, lo, hi)
// applied to the stored base value. Composition with the query operations:
//   add x  : d += x, lo += x, hi += x
//   min x  : hi = min(hi, x), lo = min(lo, hi)
//   max x  : lo = min(max(lo, x), hi)
// Each block caches sum of F(A1_i + A2_i) mod p; the cache is marked dirty by
// any update touching the block and recomputed lazily on the next query.
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;

static const ull MOD = 1000000007ULL;
static const ll INF = (ll)1e18;

// Returns F(n) mod p for n >= 0 via fast doubling.
static ull fib(ull n) {
    if (n == 0) return 0;
    ull a = 0, b = 1;  // (F(k), F(k+1)) with k = 0
    int top = 63 - __builtin_clzll(n);
    for (int bit = top; bit >= 0; --bit) {
        ull c = a * ((2 * b % MOD + MOD - a) % MOD) % MOD;  // F(2k)
        ull d = (a * a + b * b) % MOD;                      // F(2k+1)
        a = c;
        b = d;
        if ((n >> bit) & 1ULL) {
            ull t = a;
            a = b;
            b = (t + b) % MOD;
        }
    }
    return a;
}

struct Tag {
    ll d, lo, hi;
};

static int N, Q, B, NB;
static vector<ll> base[2];
static vector<Tag> tg[2];
static vector<ull> bsum;
static vector<char> dirty;

static inline ll actVal(int j, int blk, int i) {
    const Tag &t = tg[j][blk];
    ll v = base[j][i] + t.d;
    if (v < t.lo) v = t.lo;
    if (v > t.hi) v = t.hi;
    return v;
}

static void pushdown(int blk) {
    int lo_i = blk * B, hi_i = min(N, lo_i + B);
    for (int j = 0; j < 2; ++j) {
        for (int i = lo_i; i < hi_i; ++i) base[j][i] = actVal(j, blk, i);
        tg[j][blk] = Tag{0, -INF, INF};
    }
}

static void recompute(int blk) {
    int lo_i = blk * B, hi_i = min(N, lo_i + B);
    ull s = 0;
    for (int i = lo_i; i < hi_i; ++i) {
        ll v = actVal(0, blk, i) + actVal(1, blk, i);
        s += fib((ull)v);
        if (s >= MOD) s -= MOD;
    }
    bsum[blk] = s;
    dirty[blk] = 0;
}

static inline void applyTag(int j, int blk, int type, ll x) {
    Tag &t = tg[j][blk];
    if (type == 1) {  // min
        t.hi = min(t.hi, x);
        t.lo = min(t.lo, t.hi);
    } else if (type == 2) {  // max
        t.lo = max(t.lo, x);
        t.hi = max(t.hi, x);
    } else {  // add
        t.d += x;
        t.lo += x;
        t.hi += x;
    }
}

static inline void applyElem(int j, int i, int type, ll x) {
    if (type == 1) base[j][i] = min(base[j][i], x);
    else if (type == 2) base[j][i] = max(base[j][i], x);
    else base[j][i] += x;
}

// Update 0-based inclusive range [l, r] of array j with op type.
static void update(int j, int type, int l, int r, ll x) {
    int bl = l / B, br = r / B;
    for (int blk = bl; blk <= br; ++blk) {
        int s = blk * B, e = min(N, s + B) - 1;
        int from = max(l, s), to = min(r, e);
        if (from == s && to == e) {
            applyTag(j, blk, type, x);
        } else {
            pushdown(blk);
            for (int i = from; i <= to; ++i) applyElem(j, i, type, x);
        }
        dirty[blk] = 1;
    }
}

// Sum of F(A1_i + A2_i) over 0-based inclusive range [l, r].
static ull query(int l, int r) {
    ull res = 0;
    int bl = l / B, br = r / B;
    for (int blk = bl; blk <= br; ++blk) {
        int s = blk * B, e = min(N, s + B) - 1;
        int from = max(l, s), to = min(r, e);
        if (from == s && to == e) {
            if (dirty[blk]) recompute(blk);
            res += bsum[blk];
        } else {
            for (int i = from; i <= to; ++i) {
                ll v = actVal(0, blk, i) + actVal(1, blk, i);
                res += fib((ull)v);
            }
        }
        res %= MOD;
    }
    return res % MOD;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    if (!(cin >> N >> Q)) return 0;
    for (int j = 0; j < 2; ++j) {
        base[j].assign(N, 0);
        for (int i = 0; i < N; ++i) cin >> base[j][i];
    }
    B = max(1, (int)sqrt((double)N));
    NB = (N + B - 1) / B;
    for (int j = 0; j < 2; ++j) tg[j].assign(NB, Tag{0, -INF, INF});
    bsum.assign(NB, 0);
    dirty.assign(NB, 1);

    string out;
    for (int q = 0; q < Q; ++q) {
        int t;
        cin >> t;
        if (t == 4) {
            ll l, r;
            cin >> l >> r;
            ull ans = 0;
            if (l <= r) ans = query((int)l - 1, (int)r - 1);
            out += to_string(ans);
            out += '\n';
        } else {
            ll k, l, r, x;
            cin >> k >> l >> r >> x;
            if (l <= r) update((int)k - 1, t, (int)l - 1, (int)r - 1, x);
        }
    }
    cout << out;
    return 0;
}
