import sys

MOD_LIM = 998244353
MOD = 10 ** 9 + 7


def floor_sum(n, m, a, b):
    """sum_{i=0}^{n-1} floor((a*i+b)/m) for a, b >= 0, m > 0."""
    ans = 0
    while True:
        if a >= m:
            ans += n * (n - 1) // 2 * (a // m)
            a %= m
        if b >= m:
            ans += n * (b // m)
            b %= m
        y_max = a * n + b
        if y_max < m:
            break
        n, b = y_max // m, y_max % m
        m, a = a, m
    return ans


def digit_sum(x):
    s = 0
    while x:
        s += x % 10
        x //= 10
    return s


def main():
    n = int(sys.stdin.read().split()[0])
    D = len(str(n))
    pw = [10 ** k for k in range(D + 2)]

    def pos(x):
        # number of y in [1, n] with str(y) <= str(x) lexicographically
        m = len(str(x))
        total = 0
        for L in range(1, D + 1):
            if L <= m:
                total += x // pw[m - L] - pw[L - 1] + 1
            else:
                total += min(x * pw[L - m], n + 1, pw[L]) - pw[L - 1]
        return total

    Q = 9 * MOD_LIM
    S = 0  # sum of floor(g(x) / M), g(x) = pos(x) - x

    def piece(a, b, T):
        # For x in [a, b]: 9*g(x) + s(x) == P*x + C with P = 1 + 9*T.
        nonlocal S
        if a > b:
            return
        P = 1 + 9 * T
        C = 9 * (pos(a) - a) + digit_sum(a) - P * a
        # sum floor((P x + C)/Q) over x in [a, b]
        cnt = b - a + 1
        b0 = P * a + C
        off, r = b0 // Q, b0 % Q
        total = floor_sum(cnt, Q, P, r) + off * cnt
        # subtract #{x : (P x + C) mod Q < s(x)}  (since s(x) < Q)
        win = 0
        j_lo = (P * a + C) // Q
        j_hi = (P * b + C) // Q
        for j in range(j_lo, j_hi + 1):
            base = j * Q
            # x with P x + C in [base, base + 119]
            lo_num = base - C
            xs = -((-lo_num) // P)          # ceil
            xe = (base + 119 - C) // P      # floor
            xs = max(xs, a)
            xe = min(xe, b)
            for x in range(xs, xe + 1):
                v = P * x + C - base
                if 0 <= v < digit_sum(x):
                    win += 1
        S += total - win

    for m in range(1, D + 1):
        lo = pw[m - 1]
        hi = min(pw[m] - 1, n)
        if m == D:
            piece(lo, hi, 0)
            continue
        T_mid = sum(pw[L - m] for L in range(m + 1, D))
        Xb = (n + 1) // pw[D - m]
        piece(lo, min(hi, Xb), T_mid + pw[D - m])
        piece(max(lo, Xb + 1), hi, T_mid)

    print((-MOD_LIM * S) % MOD)


if __name__ == "__main__":
    main()
