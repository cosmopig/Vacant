# TODO: write the solution here (read stdin, write stdout)
