#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long ull;
typedef long long ll;
static const ull MOD = 998244353ULL;

static ull pw(ull b, ull e) {
    b %= MOD;
    ull r = 1;
    while (e) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    vector<ll> N(t), K(t), X(t);
    ll M = 1;
    for (int i = 0; i < t; i++) {
        cin >> N[i] >> K[i] >> X[i];
        M = max(M, K[i]);
    }

    // pow2[j] = 2^j mod p for j in [0, M+1]
    vector<uint32_t> pow2(M + 2);
    pow2[0] = 1;
    for (ll j = 1; j <= M + 1; j++) pow2[j] = (uint32_t)(pow2[j - 1] * 2ULL % MOD);

    // inv[j] = (2^j - 1)^{-1} mod p for j in [1, M], via batch inversion
    vector<uint32_t> inv(M + 1, 0);
    {
        vector<ull> pref(M + 1, 1);
        for (ll j = 1; j <= M; j++) {
            ull v = (pow2[j] + MOD - 1) % MOD;
            pref[j] = pref[j - 1] * v % MOD;
        }
        ull all = pw(pref[M], MOD - 2);
        for (ll j = M; j >= 1; j--) {
            ull v = (pow2[j] + MOD - 1) % MOD;
            inv[j] = (uint32_t)(all * pref[j - 1] % MOD);
            all = all * v % MOD;
        }
    }

    vector<ull> g, h;  // g[d] = [k,d]_2 ; h[e] = [k-1,e]_2
    string out;
    for (int i = 0; i < t; i++) {
        ll n = N[i], k = K[i], x = X[i];
        ull ans = 0;
        if (x == 0) {
            // All n elements must be linearly independent.
            if (n > k) {
                ans = 0;
            } else {
                ans = 1;
                for (ll j = 0; j < n; j++) {
                    ull f = (pow2[k] + MOD - pow2[j]) % MOD;
                    ans = ans * f % MOD;
                }
            }
        } else {
            ll D = min(n, k);
            ull pn = pw(2, (ull)n);
            // g[d] = [k,d]_2
            g.assign(D + 1, 0);
            g[0] = 1;
            for (ll d = 1; d <= D; d++) {
                ull num = (pow2[k - d + 1] + MOD - 1) % MOD;
                g[d] = g[d - 1] * num % MOD * inv[d] % MOD;
            }
            // h[e] = [k-1,e]_2 for e in [0, D-1]
            h.assign(D > 0 ? D : 1, 0);
            h[0] = 1;
            for (ll e = 1; e <= D - 1; e++) {
                ull num = (pow2[k - e] + MOD - 1) % MOD;
                h[e] = h[e - 1] * num % MOD * inv[e] % MOD;
            }
            // Sum over dimension d of (#d-dim subspaces avoiding x) * (#n-tuples spanning it)
            ull P = 1;  // prod_{i<d} (2^n - 2^i)
            for (ll d = 0; d <= D; d++) {
                ull cnt = g[d];
                if (d >= 1) cnt = (cnt + MOD - h[d - 1]) % MOD;
                ans = (ans + cnt * P) % MOD;
                P = P * ((pn + MOD - pow2[d]) % MOD) % MOD;
            }
        }
        out += to_string(ans);
        out += '\n';
    }
    cout << out;
    return 0;
}
