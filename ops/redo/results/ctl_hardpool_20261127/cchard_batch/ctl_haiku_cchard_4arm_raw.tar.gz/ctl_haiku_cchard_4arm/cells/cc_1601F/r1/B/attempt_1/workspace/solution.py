import sys

MOD_SUM = 10**9 + 7
MOD_DIFF = 998244353


def solve(n):
    # a_i = x is the x-th number in lexicographic order, i = pos(x).
    # (i - a_i) mod M = -d + M*ceil(d/M) with d = a_i - i, for every sign of d.
    # Summing and using sum(i - a_i) = 0 gives sum = M * S with
    # S = sum over x of ceil(d(x) / M), d(x) = x - pos(x).
    # ceil(d/M) = #{j>=0 : d > jM} for d > 0, and
    # ceil(d/M) = -#{j>=1 : d <= -jM} for d <= 0.
    N = len(str(n))

    def F(y):
        # sum_{k>=1} floor(y / 10^k)
        s = 0
        p = 10
        while p <= y:
            s += y // p
            p *= 10
        return s

    r = n - 10 ** (N - 1) + 1  # only used when m < N

    total = 0
    for m in range(1, N + 1):
        if m == N:
            B = 10 ** (N - 1) - N
            Ymax = n - 10 ** (N - 1)

            def d(y, B=B):
                return B - F(y)
        else:
            B = 10 ** (m - 1) - m
            Ymax = 9 * 10 ** (m - 1) - 1
            A = sum(10 ** j for j in range(1, N - m))
            Q = 10 ** (N - m)

            def d(y, B=B, A=A, Q=Q):
                return B - F(y) - A * y - min(r, Q * y)

        # d is non-increasing in y, so {y : d(y) > t} is a prefix of [0, Ymax].
        def count_above(t):
            if d(0) <= t:
                return 0
            lo, hi = 0, Ymax + 1  # d(lo) > t, d(hi) treated as <= t
            while hi - lo > 1:
                mid = (lo + hi) // 2
                if d(mid) > t:
                    lo = mid
                else:
                    hi = mid
            return lo + 1

        size = Ymax + 1
        # positive side: sum over j >= 0 of #{d > jM}
        j = 0
        while j * MOD_DIFF < B:
            total += count_above(j * MOD_DIFF)
            j += 1
        # negative side: -sum over j >= 1 of #{d <= -jM}
        j = 1
        while True:
            above = count_above(-j * MOD_DIFF)
            if above == size:
                break
            total -= size - above
            j += 1

    return total


def main():
    data = sys.stdin.read().split()
    n = int(data[0])
    S = solve(n)
    print(MOD_DIFF * S % MOD_SUM)


if __name__ == "__main__":
    main()
