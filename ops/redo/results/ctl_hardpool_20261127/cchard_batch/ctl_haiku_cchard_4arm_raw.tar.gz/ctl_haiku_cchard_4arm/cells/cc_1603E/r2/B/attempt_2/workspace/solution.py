import sys


def solve(n, M):
    # Modular factorials (M is prime and > n, so inverses exist).
    fact = [1] * (n + 1)
    for i in range(1, n + 1):
        fact[i] = fact[i - 1] * i % M
    ifact = [1] * (n + 1)
    ifact[n] = pow(fact[n], M - 2, M)
    for i in range(n, 0, -1):
        ifact[i - 1] = ifact[i] * i % M

    # Sequences made only of n copies of v: valid iff n <= v, v in [1, n+1]
    # -> v = n and v = n+1 (these are two distinct sequences for every n >= 1).
    ans = 2

    # Otherwise the minimum m >= 2 and the maximum is n+1 (the maximum must be
    # >= n, and n only works when all elements equal n). Let r = n - m and
    # G_b = number of elements with value > m + b. The perfect condition becomes:
    #   G_0 >= r (count of m is <= m), G_0 <= n-1 (m present),
    #   G_r >= 1 (n+1 present), G nonincreasing, sum_b G_b <= m (total excess),
    #   G_b >= r - b + 1 for b >= 1 (count of values <= m+b is <= m+b-1).
    for m in range(2, n + 1):
        r = n - m
        lo = [0] * (r + 1)
        lo[0] = max(r, 1)
        for b in range(1, r + 1):
            lo[b] = r - b + 1
        suf = [0] * (r + 2)
        for b in range(r, -1, -1):
            suf[b] = suf[b + 1] + lo[b]
        if suf[0] > m:
            continue

        # dp maps (G_b, partial sum of G) -> weighted count, where the weight is
        # the product of 1/(multiplicity)! over the values processed so far.
        dp = {}
        for g0 in range(lo[0], min(n - 1, m) + 1):
            if g0 + suf[1] <= m:
                dp[(g0, g0)] = ifact[n - g0]
        for b in range(1, r + 1):
            nd = {}
            for (gp, s), val in dp.items():
                for g in range(lo[b], gp + 1):
                    s2 = s + g
                    if s2 + suf[b + 1] > m:
                        break
                    key = (g, s2)
                    nd[key] = (nd.get(key, 0) + val * ifact[gp - g]) % M
            dp = nd

        total = 0
        for (g, _s), val in dp.items():
            total = (total + val * ifact[g]) % M
        ans = (ans + fact[n] * total) % M
    return ans % M


def main():
    data = sys.stdin.read().split()
    n, M = int(data[0]), int(data[1])
    print(solve(n, M))


if __name__ == "__main__":
    main()
