#include <bits/stdc++.h>
using namespace std;

// For a start s (segment is positions s+1..r), a prime p's running exponent
// is P_p(j) - P_p(s) where P_p is the prefix sum of signed exponents.
// The segment stays simple while every such difference is >= 0.
// bad(s) = first j > s where some P_p(j) < P_p(s)  (n+1 if none).
// Answer = sum over s of (bad(s) - s - 1).
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;
    vector<int> a(n + 1);
    for (int i = 1; i <= n; i++) cin >> a[i];
    string b;
    cin >> b;

    const int MAXV = 1000001;
    vector<int> spf(MAXV, 0);
    for (int i = 2; i < MAXV; i++) {
        if (spf[i] == 0) {
            for (long long j = i; j < MAXV; j += i)
                if (spf[j] == 0) spf[j] = i;
        }
    }

    // Pass 1: count events per prime.
    vector<int> cnt(MAXV + 1, 0);
    for (int i = 1; i <= n; i++) {
        int x = a[i];
        while (x > 1) {
            int p = spf[x];
            cnt[p]++;
            while (x % p == 0) x /= p;
        }
    }
    // CSR offsets.
    vector<int> start(MAXV + 1, 0);
    for (int p = 0; p < MAXV; p++) start[p + 1] = start[p] + cnt[p];
    int total = start[MAXV];
    vector<int> epos(total), edelta(total);
    vector<int> fillp(start.begin(), start.end() - 1);

    // Pass 2: fill events (positions ascending because i ascends).
    for (int i = 1; i <= n; i++) {
        int x = a[i];
        int sign = (b[i - 1] == '*') ? 1 : -1;
        while (x > 1) {
            int p = spf[x];
            int e = 0;
            while (x % p == 0) {
                x /= p;
                e++;
            }
            int idx = fillp[p]++;
            epos[idx] = i;
            edelta[idx] = sign * e;
        }
    }

    // Range-chmin segment tree (iterative, point query = min over ancestors).
    const int N = n;
    const int INF = n + 1;
    vector<int> tag(2 * N, INF);
    auto update = [&](int l, int r, int c) {  // inclusive, 0-indexed leaves
        int lo = l + N, hi = r + N + 1;
        while (lo < hi) {
            if (lo & 1) {
                tag[lo] = min(tag[lo], c);
                lo++;
            }
            if (hi & 1) {
                --hi;
                tag[hi] = min(tag[hi], c);
            }
            lo >>= 1;
            hi >>= 1;
        }
    };

    vector<int> Q, V, ns, stk;
    for (int p = 2; p < MAXV; p++) {
        int E = cnt[p];
        if (E == 0) continue;
        int base = start[p];
        Q.assign(E + 1, 0);
        V.assign(E + 1, 0);
        for (int k = 1; k <= E; k++) {
            Q[k] = epos[base + k - 1];
            V[k] = V[k - 1] + edelta[base + k - 1];
        }
        // ns[k] = first m > k with V[m] < V[k]
        ns.assign(E + 1, -1);
        stk.clear();
        for (int k = E; k >= 0; k--) {
            while (!stk.empty() && V[stk.back()] >= V[k]) stk.pop_back();
            ns[k] = stk.empty() ? -1 : stk.back();
            stk.push_back(k);
        }
        // Starts s in [Q[k], Q[k+1]-1] have current value V[k].
        for (int k = 0; k < E; k++) {
            if (ns[k] >= 0) {
                update(Q[k], Q[k + 1] - 1, Q[ns[k]]);
            }
        }
    }

    long long ans = 0;
    for (int s = 0; s < n; s++) {
        int v = INF;
        for (int idx = s + N; idx >= 1; idx >>= 1) v = min(v, tag[idx]);
        ans += (long long)(v - s - 1);
    }
    cout << ans << "\n";
    return 0;
}
