#include <bits/stdc++.h>
using namespace std;

static const long long MOD = 1000000007LL;

// Returns {F(k) mod MOD, F(k+1) mod MOD} using fast doubling.
static pair<long long, long long> fibPair(long long k) {
    if (k == 0) return {0, 1};
    auto [a, b] = fibPair(k >> 1);  // a = F(m), b = F(m+1), m = k/2
    long long c = a * ((2 * b - a + MOD) % MOD) % MOD;  // F(2m)
    long long d = (a * a + b * b) % MOD;                  // F(2m+1)
    if (k & 1) return {d, (c + d) % MOD};
    return {c, d};
}

static long long fib(long long k) { return fibPair(k).first; }

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, q;
    cin >> n >> q;
    vector<long long> a1(n + 1), a2(n + 1);
    for (int i = 1; i <= n; ++i) cin >> a1[i];
    for (int i = 1; i <= n; ++i) cin >> a2[i];

    string out;
    while (q--) {
        int t;
        cin >> t;
        if (t == 4) {
            int l, r;
            cin >> l >> r;
            long long ans = 0;
            for (int i = l; i <= r; ++i) {
                ans += fib(a1[i] + a2[i]);
                if (ans >= MOD) ans -= MOD;
            }
            out += to_string(ans);
            out += '\n';
        } else {
            int k, l, r;
            long long x;
            cin >> k >> l >> r >> x;
            vector<long long>& arr = (k == 1) ? a1 : a2;
            for (int i = l; i <= r; ++i) {
                if (t == 1) {
                    arr[i] = min(arr[i], x);
                } else if (t == 2) {
                    arr[i] = max(arr[i], x);
                } else {  // t == 3
                    arr[i] += x;
                }
            }
        }
    }
    cout << out;
    return 0;
}
