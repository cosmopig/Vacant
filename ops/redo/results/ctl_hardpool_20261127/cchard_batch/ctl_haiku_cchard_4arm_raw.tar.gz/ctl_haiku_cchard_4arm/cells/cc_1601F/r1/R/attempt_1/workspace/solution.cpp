#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef __int128 i128;

static const ll M = 998244353LL;
static const ll P = 1000000007LL;

ll n;
int N; // number of digits of n
ll pw[20];

// number of y in [1,n] whose string is lexicographically <= string(x), x in [1,n]
ll rankOf(ll x) {
    int L = 0;
    for (ll t = x; t > 0; t /= 10) L++;
    i128 total = 0;
    for (int l = 1; l <= N; l++) {
        ll lo = pw[l - 1];
        ll cnt;
        if (l <= L) {
            ll p = x / pw[L - l];
            ll up = min(p, n);
            cnt = up - lo + 1;
        } else {
            i128 bound = (i128)x * pw[l - L] - 1;
            i128 up = min(bound, (i128)n);
            cnt = (ll)(up - lo + 1);
        }
        if (cnt > 0) total += cnt;
    }
    return (ll)total;
}

// D(x) = rank(x) - x ; floor division by M
ll floorDivM(ll a) {
    ll q = a / M;
    if ((a % M != 0) && (a < 0)) q--;
    return q;
}

int main() {
    cin >> n;
    pw[0] = 1;
    for (int i = 1; i < 20; i++) pw[i] = pw[i - 1] * 10;
    N = 0;
    for (ll t = n; t > 0; t /= 10) N++;

    i128 S = 0; // sum over x of floor(D(x)/M)
    for (int L = 1; L <= N; L++) {
        ll lo = pw[L - 1];
        ll hi = min(pw[L] - 1, n);
        if (lo > hi) break;
        auto f = [&](ll x) -> ll { return floorDivM(rankOf(x) - x); };
        ll cur = lo;
        while (cur <= hi) {
            ll v = f(cur);
            // find first x in (cur, hi] with f(x) > v (f is nondecreasing)
            ll a = cur + 1, b = hi + 1;
            while (a < b) {
                ll m = a + (b - a) / 2;
                if (f(m) > v) b = m; else a = m + 1;
            }
            ll nxt = a; // first x with f > v, or hi+1
            S += (i128)v * (nxt - cur);
            cur = nxt;
        }
    }

    ll Smod = (ll)(S % P);
    if (Smod < 0) Smod += P;
    ll ans = (P - (M % P) * Smod % P) % P;
    cout << ans << "\n";
    return 0;
}
