#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

const ll MOD_SUB = 998244353LL;   // M from the statement
const ll MOD_OUT = 1000000007LL;  // output modulus

ll N;
int D;            // number of digits of N
ll pw[20];

// Lexicographic rank of x among 1..N (1-based): number of y in [1,N] with str(y) <= str(x).
ll rankOf(ll x) {
    int d = 0;
    for (ll t = x; t > 0; t /= 10) d++;
    ll cnt = 0;
    for (int L = 1; L <= D; L++) {
        if (L < d) {
            // L-digit y lex-<= str(x) iff y <= prefix of x of length L (numerically)
            cnt += x / pw[d - L] - pw[L - 1] + 1;
        } else if (L == d) {
            cnt += x - pw[d - 1] + 1;
        } else {
            // L-digit y whose length-d prefix is < x
            ll up = x * pw[L - d] - 1;
            ll hi = min(N, up);
            ll lo = pw[L - 1];
            if (hi >= lo) cnt += hi - lo + 1;
        }
    }
    return cnt;
}

// g(x) = rank(x) - x. Within a digit-length block g is non-decreasing.
ll g(ll x) { return rankOf(x) - x; }

ll fdiv(ll a, ll b) {
    ll q = a / b;
    if (a % b != 0 && a < 0) q--;
    return q;
}

// Sum over x in [a,b] of floor(g(x)/M), where g is non-decreasing on [a,b].
ll sumFloor(ll a, ll b) {
    ll fa = fdiv(g(a), MOD_SUB);
    ll fb = fdiv(g(b), MOD_SUB);
    if (fa == fb) return (b - a + 1) * fa;
    ll mid = a + (b - a) / 2;
    return sumFloor(a, mid) + sumFloor(mid + 1, b);
}

int main() {
    cin >> N;
    pw[0] = 1;
    for (int i = 1; i < 20; i++) pw[i] = pw[i - 1] * 10;
    D = 0;
    for (ll t = N; t > 0; t /= 10) D++;

    ll S = 0;  // sum of floor((i - a_i) / M); exact in 64-bit
    for (int d = 1; d <= D; d++) {
        ll lo = pw[d - 1];
        if (lo > N) break;
        ll hi = min(N, pw[d] - 1);
        S += sumFloor(lo, hi);
    }

    // Sum of ((i - a_i) mod M) = sum(i - a_i) - M * S = -M * S, since sum(i - a_i) = 0.
    ll t = ((-S) % MOD_OUT + MOD_OUT) % MOD_OUT;
    ll ans = (MOD_SUB % MOD_OUT) * t % MOD_OUT;
    cout << ans << "\n";
    return 0;
}
