// Palindromic Hamiltonian path: count good letter strings.
//
// A palindromic Hamiltonian path a_0..a_{h-1} b_{h-1}..b_0 (h = n/2) gives a
// perfect matching M of the vertices into mirror pairs {a_i, b_i}, where the
// pairs can be ordered so that consecutive a's and consecutive b's are adjacent
// and the innermost pair {a_{h-1}, b_{h-1}} is an edge. A string is good iff
// some such M has every pair monochromatic.
//
// 1. Enumerate all perfect matchings M of n vertices and keep the realizable ones
//    (subset DP over pairs, state = (used pairs, current a-end)).
// 2. Count strings by their letter pattern (restricted growth string, b blocks).
//    A pattern with b blocks corresponds to falling(k, b) strings. DFS over
//    patterns keeps only the matchings still consistent with the pattern; a
//    pattern contributes if some matching survives to the end.
#include <bits/stdc++.h>
using namespace std;

static int n, m, k;
static bool adj[12][12];
static vector<array<int, 12>> mates;  // realizable matchings: mate of each vertex
static long long ans = 0;
static int blk[12];

static bool realizable(const array<int, 12>& mate) {
    // pairs as list of (u,w) with u<w
    vector<pair<int, int>> P;
    for (int v = 0; v < n; v++)
        if (mate[v] > v) P.push_back({v, mate[v]});
    int h = (int)P.size();
    int full = (1 << h) - 1;
    // reach[S][x]: pairs S form a ladder ending with a-end x (b-end = mate[x])
    vector<vector<char>> reach(1 << h, vector<char>(n, 0));
    for (int j = 0; j < h; j++) {
        reach[1 << j][P[j].first] = 1;
        reach[1 << j][P[j].second] = 1;
    }
    for (int S = 1; S <= full; S++) {
        for (int x = 0; x < n; x++) {
            if (!reach[S][x]) continue;
            int y = mate[x];
            for (int j = 0; j < h; j++) {
                if (S >> j & 1) continue;
                int orient[2][2] = {{P[j].first, P[j].second}, {P[j].second, P[j].first}};
                for (auto& o : orient) {
                    int u = o[0], w = o[1];
                    if (adj[x][u] && adj[y][w]) reach[S | (1 << j)][u] = 1;
                }
            }
        }
    }
    for (int x = 0; x < n; x++)
        if (reach[full][x] && adj[x][mate[x]]) return true;
    return false;
}

static void enumerate_matchings(array<int, 12>& mate, int used) {
    int v = -1;
    for (int i = 0; i < n; i++)
        if (!(used >> i & 1)) { v = i; break; }
    if (v < 0) {
        if (realizable(mate)) mates.push_back(mate);
        return;
    }
    for (int w = v + 1; w < n; w++) {
        if (used >> w & 1) continue;
        mate[v] = w;
        mate[w] = v;
        enumerate_matchings(mate, used | (1 << v) | (1 << w));
    }
}

static long long falling(int k_, int b) {
    long long r = 1;
    for (int i = 0; i < b; i++) r *= (k_ - i);
    return r;
}

// i vertices 0..i-1 assigned with b blocks; cand = matchings consistent so far.
static void dfs(int i, int b, const vector<int>& cand) {
    if (i == n) {
        ans += falling(k, b);  // cand nonempty => the pattern is good
        return;
    }
    int v = i;
    int maxc = min(b + 1, k);
    for (int c = 0; c < maxc; c++) {
        vector<int> nxt;
        nxt.reserve(cand.size());
        for (int id : cand) {
            int p = mates[id][v];
            if (p < v && blk[p] != c) continue;
            nxt.push_back(id);
        }
        if (nxt.empty()) continue;
        blk[v] = c;
        dfs(i + 1, max(b, c + 1), nxt);
    }
}

int main() {
    if (!(cin >> n >> m >> k)) return 0;
    for (int i = 0; i < m; i++) {
        int a, b;
        cin >> a >> b;
        a--; b--;
        // Ignore self-loops and anything out of range (not valid input).
        if (a < 0 || b < 0 || a >= n || b >= n || a == b) continue;
        adj[a][b] = adj[b][a] = true;
    }
    array<int, 12> mate{};
    enumerate_matchings(mate, 0);
    if (mates.empty()) {
        cout << 0 << "\n";
        return 0;
    }
    vector<int> all(mates.size());
    for (size_t i = 0; i < all.size(); i++) all[i] = (int)i;
    dfs(0, 0, all);
    cout << ans << "\n";
    return 0;
}
