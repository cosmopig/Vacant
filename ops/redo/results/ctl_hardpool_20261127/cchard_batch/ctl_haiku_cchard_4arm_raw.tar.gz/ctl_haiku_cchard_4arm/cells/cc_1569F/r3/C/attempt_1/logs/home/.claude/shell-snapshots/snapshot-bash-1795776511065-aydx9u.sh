# Snapshot file
# Unset all aliases to avoid conflicts with functions
unalias -a 2>/dev/null || true
shopt -s expand_aliases
# Check for rg availability
if ! hash rg 2>/dev/null && ! typeset -f rg >/dev/null 2>&1; then
  function rg {
  if [[ -x /opt/claude-code/bin/claude ]]; then
  if [[ -n ${ZSH_VERSION:-} ]]; then
    ARGV0=rg /opt/claude-code/bin/claude ${1+"$@"}
  elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "cygwin" ]] || [[ "$OSTYPE" == "win32" ]]; then
    ARGV0=rg /opt/claude-code/bin/claude ${1+"$@"}
  else
    (exec -a rg /opt/claude-code/bin/claude ${1+"$@"})
  fi
  elif [[ -x /opt/ctlwork/runs/ctl_haiku_cchard_4arm/cells/cc_1569F/r3/C/attempt_1/logs/home/.local/bin/claude ]]; then
  if [[ -n ${ZSH_VERSION:-} ]]; then
    ARGV0=rg /opt/ctlwork/runs/ctl_haiku_cchard_4arm/cells/cc_1569F/r3/C/attempt_1/logs/home/.local/bin/claude ${1+"$@"}
  elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "cygwin" ]] || [[ "$OSTYPE" == "win32" ]]; then
    ARGV0=rg /opt/ctlwork/runs/ctl_haiku_cchard_4arm/cells/cc_1569F/r3/C/attempt_1/logs/home/.local/bin/claude ${1+"$@"}
  else
    (exec -a rg /opt/ctlwork/runs/ctl_haiku_cchard_4arm/cells/cc_1569F/r3/C/attempt_1/logs/home/.local/bin/claude ${1+"$@"})
  fi
  else command rg ${1+"$@"}; fi
}
fi
# Shadow find/grep with embedded bfs/ugrep
unalias find 2>/dev/null || true
unalias grep 2>/dev/null || true
function find {
  if [[ -x /opt/claude-code/bin/claude ]]; then
  if [[ -n ${ZSH_VERSION:-} ]]; then
    ARGV0=bfs /opt/claude-code/bin/claude -S dfs -regextype findutils-default ${1+"$@"}
  elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "cygwin" ]] || [[ "$OSTYPE" == "win32" ]]; then
    ARGV0=bfs /opt/claude-code/bin/claude -S dfs -regextype findutils-default ${1+"$@"}
  else
    (exec -a bfs /opt/claude-code/bin/claude -S dfs -regextype findutils-default ${1+"$@"})
  fi
  elif [[ -x /opt/ctlwork/runs/ctl_haiku_cchard_4arm/cells/cc_1569F/r3/C/attempt_1/logs/home/.local/bin/claude ]]; then
  if [[ -n ${ZSH_VERSION:-} ]]; then
    ARGV0=bfs /opt/ctlwork/runs/ctl_haiku_cchard_4arm/cells/cc_1569F/r3/C/attempt_1/logs/home/.local/bin/claude -S dfs -regextype findutils-default ${1+"$@"}
  elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "cygwin" ]] || [[ "$OSTYPE" == "win32" ]]; then
    ARGV0=bfs /opt/ctlwork/runs/ctl_haiku_cchard_4arm/cells/cc_1569F/r3/C/attempt_1/logs/home/.local/bin/claude -S dfs -regextype findutils-default ${1+"$@"}
  else
    (exec -a bfs /opt/ctlwork/runs/ctl_haiku_cchard_4arm/cells/cc_1569F/r3/C/attempt_1/logs/home/.local/bin/claude -S dfs -regextype findutils-default ${1+"$@"})
  fi
  else command find ${1+"$@"}; fi
}
function grep {
  local _cc_a
  for _cc_a in ${1+"$@"}; do
    case "$_cc_a" in -*-filter*|-*-pager*|-*-view*|-*-format-open*|-*-config*|---*|-@*|-*-save-config*|-[Zz]*|-[!-]*[Zz]*|--null|--null-data) command grep ${1+"$@"}; return ;; esac
  done
  if [[ -x /opt/claude-code/bin/claude ]]; then
  if [[ -n ${ZSH_VERSION:-} ]]; then
    ARGV0=ugrep /opt/claude-code/bin/claude -G --ignore-files --hidden -I --encoding=UTF-8 --exclude-dir=.git --exclude-dir=.svn --exclude-dir=.hg --exclude-dir=.bzr --exclude-dir=.jj --exclude-dir=.sl ${1+"$@"}
  elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "cygwin" ]] || [[ "$OSTYPE" == "win32" ]]; then
    ARGV0=ugrep /opt/claude-code/bin/claude -G --ignore-files --hidden -I --encoding=UTF-8 --exclude-dir=.git --exclude-dir=.svn --exclude-dir=.hg --exclude-dir=.bzr --exclude-dir=.jj --exclude-dir=.sl ${1+"$@"}
  else
    (exec -a ugrep /opt/claude-code/bin/claude -G --ignore-files --hidden -I --encoding=UTF-8 --exclude-dir=.git --exclude-dir=.svn --exclude-dir=.hg --exclude-dir=.bzr --exclude-dir=.jj --exclude-dir=.sl ${1+"$@"})
  fi
  elif [[ -x /opt/ctlwork/runs/ctl_haiku_cchard_4arm/cells/cc_1569F/r3/C/attempt_1/logs/home/.local/bin/claude ]]; then
  if [[ -n ${ZSH_VERSION:-} ]]; then
    ARGV0=ugrep /opt/ctlwork/runs/ctl_haiku_cchard_4arm/cells/cc_1569F/r3/C/attempt_1/logs/home/.local/bin/claude -G --ignore-files --hidden -I --encoding=UTF-8 --exclude-dir=.git --exclude-dir=.svn --exclude-dir=.hg --exclude-dir=.bzr --exclude-dir=.jj --exclude-dir=.sl ${1+"$@"}
  elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "cygwin" ]] || [[ "$OSTYPE" == "win32" ]]; then
    ARGV0=ugrep /opt/ctlwork/runs/ctl_haiku_cchard_4arm/cells/cc_1569F/r3/C/attempt_1/logs/home/.local/bin/claude -G --ignore-files --hidden -I --encoding=UTF-8 --exclude-dir=.git --exclude-dir=.svn --exclude-dir=.hg --exclude-dir=.bzr --exclude-dir=.jj --exclude-dir=.sl ${1+"$@"}
  else
    (exec -a ugrep /opt/ctlwork/runs/ctl_haiku_cchard_4arm/cells/cc_1569F/r3/C/attempt_1/logs/home/.local/bin/claude -G --ignore-files --hidden -I --encoding=UTF-8 --exclude-dir=.git --exclude-dir=.svn --exclude-dir=.hg --exclude-dir=.bzr --exclude-dir=.jj --exclude-dir=.sl ${1+"$@"})
  fi
  else command grep ${1+"$@"}; fi
}
# Shadow pkill to refuse patterns matching the CLI process
unalias pkill 2>/dev/null || true
function pkill {
  if [ -n "${CLAUDE_PID:-}" ] && [ -r "/proc/${CLAUDE_PID}/comm" ]; then
    local _cc_skip="" _cc_a
    local -a _cc_probe=()
    for _cc_a in ${1+"$@"}; do
      if [ -n "$_cc_skip" ]; then _cc_skip=""; continue; fi
      case "$_cc_a" in
        --signal) _cc_skip=1 ;;
        --signal=*|-e|--echo) ;;
        -[0-9]*) ;;
        -[PUGOF]?*) _cc_probe+=("$_cc_a") ;;
        -[ABCDEFGHIJKLMNOPQRSTUVWXYZ][ABCDEFGHIJKLMNOPQRSTUVWXYZ0-9]*) ;;
        *) _cc_probe+=("$_cc_a") ;;
      esac
    done
    if command pgrep ${_cc_probe[@]+"${_cc_probe[@]}"} 2>/dev/null | command grep -qx "${CLAUDE_PID}"; then
      printf 'pkill: refusing to run — this pattern matches the Claude CLI process (PID %s). Narrow the pattern, or target your own children with `pkill -P $$ ...`.\n' "${CLAUDE_PID}" >&2
      return 1
    fi
  fi
  command pkill ${1+"$@"}
}
export PATH=/opt/ctl-venv/bin:/usr/local/bin:/usr/bin:/bin:/opt/claude-code/bin
