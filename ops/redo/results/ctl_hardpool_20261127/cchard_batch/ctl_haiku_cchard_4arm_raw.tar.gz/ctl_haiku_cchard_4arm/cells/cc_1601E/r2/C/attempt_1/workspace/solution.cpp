// Phys Ed Online.
//
// For a student covering days [l, r] (0-indexed), the cheapest plan is to
// activate a ticket at t = l, l+k, l+2k, ... (all <= r), and the ticket for an
// activation at t costs min(a[l..t]) (tickets can be bought in bulk, so there is
// no capacity constraint). Answer = sum over such t of min(a[l..t]).
//
// Split by residue c = l mod k. Within class c the activation times are
// t_m = c + m*k, and with i0 = l / k, M = (r - c) / k the answer is
//   x[i0] + sum_{m=i0+1}^{M} min(B[i0..m-1], x[m])
// where x[m] = a[c+mk] and B[i] = min(a[c+ik .. c+ik+k-1]).
// The prefix minima of B from i0 form a "next strictly smaller" tree; the
// contribution of each tree node g over its m-range is a threshold sum
// sum min(B[g], x[m]), computed offline with a BIT. The last node g* (leftmost
// argmin of B on [i0, M-1]) is handled with one extra threshold query.

#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

// Sparse table giving the leftmost argmin of v over ranges.
struct SparseArgmin {
    const vector<ll>* v;
    vector<vector<int>> t;
    void build(const vector<ll>& vals) {
        v = &vals;
        int n = (int)vals.size();
        int levels = 1;
        while ((1 << levels) <= n) levels++;
        t.assign(levels, vector<int>(n));
        for (int i = 0; i < n; i++) t[0][i] = i;
        for (int j = 1; j < levels; j++) {
            for (int i = 0; i + (1 << j) <= n; i++) {
                t[j][i] = better(t[j - 1][i], t[j - 1][i + (1 << (j - 1))]);
            }
        }
    }
    int better(int p, int q) const {
        const vector<ll>& a = *v;
        if (a[q] < a[p] || (a[q] == a[p] && q < p)) return q;
        return p;
    }
    // Leftmost argmin on [l, r], requires l <= r.
    int query(int l, int r) const {
        int len = r - l + 1;
        int j = 31 - __builtin_clz((unsigned)len);
        return better(t[j][l], t[j][r - (1 << j) + 1]);
    }
};

struct Task {
    int lo, hi;
    ll v;
    int slot;
};

// Fills res[slot] = sum over m in [lo, hi] of min(v, x[m]) for every task.
static void solveThresholds(const vector<ll>& x, const vector<Task>& tasks, vector<ll>& res) {
    int L = (int)x.size();
    vector<int> ord(L);
    for (int i = 0; i < L; i++) ord[i] = i;
    sort(ord.begin(), ord.end(), [&](int p, int q) { return x[p] < x[q]; });
    vector<int> tord(tasks.size());
    for (size_t i = 0; i < tasks.size(); i++) tord[i] = (int)i;
    sort(tord.begin(), tord.end(), [&](int p, int q) { return tasks[p].v < tasks[q].v; });

    vector<int> bitCnt(L + 1, 0);
    vector<ll> bitSum(L + 1, 0);
    auto add = [&](int idx, ll val) {
        for (int i = idx + 1; i <= L; i += i & -i) {
            bitCnt[i] += 1;
            bitSum[i] += val;
        }
    };
    // prefix over [0, idx)
    auto prefCnt = [&](int idx) {
        ll s = 0;
        for (int i = idx; i > 0; i -= i & -i) s += bitCnt[i];
        return s;
    };
    auto prefSum = [&](int idx) {
        ll s = 0;
        for (int i = idx; i > 0; i -= i & -i) s += bitSum[i];
        return s;
    };

    int p = 0;
    for (int ti : tord) {
        const Task& tk = tasks[ti];
        while (p < L && x[ord[p]] < tk.v) {
            add(ord[p], x[ord[p]]);
            p++;
        }
        ll cntLess = prefCnt(tk.hi + 1) - prefCnt(tk.lo);
        ll sumLess = prefSum(tk.hi + 1) - prefSum(tk.lo);
        ll len = (ll)(tk.hi - tk.lo + 1);
        res[tk.slot] = sumLess + tk.v * (len - cntLess);
    }
}

int main() {
    int n, q, k;
    if (scanf("%d %d %d", &n, &q, &k) != 3) return 0;
    vector<ll> a(n);
    for (int i = 0; i < n; i++) {
        scanf("%lld", &a[i]);
    }
    vector<int> ql(q), qr(q);
    for (int i = 0; i < q; i++) {
        scanf("%d %d", &ql[i], &qr[i]);
        ql[i]--;
        qr[i]--;
    }

    // Window minima over a, used to build block minima B for each class.
    SparseArgmin globalSp;
    globalSp.build(a);

    vector<vector<int>> byClass(k);
    for (int i = 0; i < q; i++) byClass[ql[i] % k].push_back(i);

    vector<ll> ans(q, 0);
    for (int c = 0; c < k; c++) {
        if (byClass[c].empty()) continue;
        int L = (n - 1 - c) / k + 1;  // number of activation times c + m*k <= n-1
        vector<ll> x(L), B(L);
        for (int m = 0; m < L; m++) {
            int t = c + m * k;
            x[m] = a[t];
            int hi = min(n - 1, t + k - 1);
            B[m] = a[globalSp.query(t, hi)];
        }

        // Next strictly smaller element in B (parent in the record tree).
        vector<int> par(L, -1);
        {
            vector<int> st;
            for (int m = L - 1; m >= 0; m--) {
                while (!st.empty() && B[st.back()] >= B[m]) st.pop_back();
                par[m] = st.empty() ? -1 : st.back();
                st.push_back(m);
            }
        }

        vector<Task> tasks;
        for (int m = 0; m < L; m++) {
            int e = (par[m] == -1) ? L - 1 : par[m];
            if (e >= m + 1) tasks.push_back({m + 1, e, B[m], m});
        }

        SparseArgmin bSp;
        bSp.build(B);
        vector<int> gOf(byClass[c].size(), -1);
        for (size_t j = 0; j < byClass[c].size(); j++) {
            int qi = byClass[c][j];
            int i0 = ql[qi] / k;
            int M = (qr[qi] - c) / k;
            if (M == i0) {
                ans[qi] = x[i0];
                continue;
            }
            int g = bSp.query(i0, M - 1);
            gOf[j] = g;
            tasks.push_back({g + 1, M, B[g], L + (int)j});
        }

        vector<ll> res(L + byClass[c].size(), 0);
        solveThresholds(x, tasks, res);

        // S[m] = W[m] + S[par[m]], where W[m] is the threshold sum over m's range.
        // W[m] is stored in res[m] for tasks with slot m; nodes without a task have W = 0.
        vector<ll> S(L, 0);
        for (int m = L - 1; m >= 0; m--) {
            ll wm = res[m];  // zero if no task was generated for m
            S[m] = wm + (par[m] == -1 ? 0 : S[par[m]]);
        }

        for (size_t j = 0; j < byClass[c].size(); j++) {
            int qi = byClass[c][j];
            if (gOf[j] == -1) continue;  // already answered (M == i0)
            int i0 = ql[qi] / k;
            int g = gOf[j];
            ans[qi] = x[i0] + S[i0] - S[g] + res[L + j];
        }
    }

    string out;
    out.reserve((size_t)q * 12);
    for (int i = 0; i < q; i++) {
        out += to_string(ans[i]);
        out += '\n';
    }
    fputs(out.c_str(), stdout);
    return 0;
}
