#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;

static ull pw(ull b, ull e, ull m) {
    ull r = 1 % m; b %= m;
    while (e) { if (e & 1) r = r * b % m; b = b * b % m; e >>= 1; }
    return r;
}

int main() {
    ll n; ull M;
    if (!(cin >> n >> M)) return 0;
    vector<ull> fact(n + 2), invf(n + 2);
    fact[0] = 1;
    for (ll i = 1; i <= n + 1; i++) fact[i] = fact[i - 1] * i % M;
    for (ll i = 0; i <= n + 1; i++) invf[i] = pw(fact[i], M - 2, M);

    ull total = 2 % M;
    for (ll x = 1; x <= n; x++) {
        ll D = n + 1 - x;
        if (D > x) continue;
        for (ll k = 1; k <= min(n - 1, x); k++) {
            if (n - k > x) continue;
            ll lb = 0;
            for (ll s = 1; s <= min(k, D); s++) lb += D - s + 1;
            if (lb > x) continue;

            const ll W = x + 1, R = k + 1;
            vector<ull> dp(R * W, 0), nd(R * W, 0);
            dp[0] = 1;
            for (ll v = D; v >= 1; v--) {
                fill(nd.begin(), nd.end(), 0);
                for (ll s = 0; s <= x; s++) {
                    for (ll cnt = 0; cnt <= min(k, s); cnt++) {
                        ull val = dp[cnt * W + s];
                        if (!val) continue;
                        for (ll m = 0; cnt + m <= k && s + m * v <= x; m++) {
                            ull &t = nd[(cnt + m) * W + s + m * v];
                            t += val * invf[m] % M;
                            if (t >= M) t -= M;
                        }
                    }
                }
                if (D - v + 1 <= k)
                    for (ll cnt = 0; cnt < D - v + 1 && cnt <= k; cnt++)
                        fill(nd.begin() + cnt * W, nd.begin() + (cnt + 1) * W, 0);
                // prune states where the k-cnt still-unplaced elements (each >= 1) cannot fit
                for (ll cnt = 0; cnt <= k; cnt++)
                    for (ll s = max(0LL, x - (k - cnt) + 1); s <= x; s++) nd[cnt * W + s] = 0;
                dp.swap(nd);
            }
            ull ways = 0;
            for (ll s = 0; s <= x; s++) ways = (ways + dp[k * W + s]) % M;
            ways = ways * fact[k] % M;
            ull comb = fact[n] * invf[k] % M * invf[n - k] % M;
            total = (total + comb * ways) % M;
        }
    }
    cout << total % M << "\n";
}
