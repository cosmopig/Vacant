// Mars: the cities form one cycle of length M = 1e9+7 under step D (D != 0).
// The distinct values in [L,R] are connected under edges u-v = +-D iff they
// form an arithmetic progression with common difference D (mod M).
// Test: with K distinct values, P_j = sum of x^j over them; set c = (P1 - D*S1)/K
// where S1 = sum_{k<K} k, then require P_j = sum_{k<K} (c + k*D)^j for j = 2..6.
// Power sums over distinct values in a range are computed offline (sorted by R)
// with Fenwick trees that keep only the last occurrence of each value.
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll MOD = 1000000007LL;
const int J = 6;

ll pw(ll b, ll e) {
    b %= MOD;
    if (b < 0) b += MOD;
    ll r = 1;
    while (e > 0) {
        if (e & 1) r = r * b % MOD;
        b = b * b % MOD;
        e >>= 1;
    }
    return r;
}

int N, Q;
vector<ll> bitv[J + 1];
vector<ll> bitc;

void addv(vector<ll>& b, int i, ll v) {
    for (; i <= N; i += i & -i) {
        b[i] += v;
        if (b[i] >= MOD) b[i] -= MOD;
        if (b[i] < 0) b[i] += MOD;
    }
}
ll sumv(const vector<ll>& b, int i) {
    ll s = 0;
    for (; i > 0; i -= i & -i) s += b[i];
    return s % MOD;
}
void addc(int i, ll v) {
    for (; i <= N; i += i & -i) bitc[i] += v;
}
ll sumc(int i) {
    ll s = 0;
    for (; i > 0; i -= i & -i) s += bitc[i];
    return s;
}

int main() {
    if (scanf("%d %d", &N, &Q) != 2) return 0;
    vector<ll> a(N + 1);
    for (int i = 1; i <= N; i++) {
        scanf("%lld", &a[i]);
        a[i] %= MOD;
    }
    vector<int> QL(Q), QR(Q);
    vector<ll> QD(Q);
    for (int q = 0; q < Q; q++) {
        ll l, r, d;
        scanf("%lld %lld %lld", &l, &r, &d);
        if (l > r) swap(l, r);
        QL[q] = (int)l;
        QR[q] = (int)r;
        QD[q] = d % MOD;
    }
    vector<vector<int>> byR(N + 1);
    for (int q = 0; q < Q; q++) byR[QR[q]].push_back(q);

    // Coordinate-compress values for last-occurrence tracking.
    vector<ll> vals(a.begin() + 1, a.end());
    sort(vals.begin(), vals.end());
    vals.erase(unique(vals.begin(), vals.end()), vals.end());
    vector<int> id(N + 1);
    for (int i = 1; i <= N; i++) id[i] = lower_bound(vals.begin(), vals.end(), a[i]) - vals.begin();
    vector<int> last(vals.size(), 0);

    // Powers of each element.
    vector<array<ll, J + 1>> pws(N + 1);
    for (int i = 1; i <= N; i++) {
        pws[i][0] = 1;
        for (int j = 1; j <= J; j++) pws[i][j] = pws[i][j - 1] * a[i] % MOD;
    }
    for (int j = 1; j <= J; j++) bitv[j].assign(N + 1, 0);
    bitc.assign(N + 1, 0);

    // St[t][k] = sum_{x<k} x^t  (0^0 = 1), for k = 0..N.
    vector<vector<ll>> St(J + 1, vector<ll>(N + 2, 0));
    for (int t = 0; t <= J; t++) {
        for (int k = 0; k <= N; k++) {
            ll kt = pw(k, t);  // pw(0,0) = 1
            St[t][k + 1] = (St[t][k] + kt) % MOD;
        }
    }
    // Binomial coefficients up to J.
    ll C[J + 1][J + 1];
    memset(C, 0, sizeof(C));
    for (int i = 0; i <= J; i++) {
        C[i][0] = 1;
        for (int j = 1; j <= i; j++) C[i][j] = (C[i - 1][j - 1] + (j <= i - 1 ? C[i - 1][j] : 0)) % MOD;
    }

    vector<char> ans(Q, 0);
    for (int i = 1; i <= N; i++) {
        int v = id[i];
        if (last[v]) {
            int p = last[v];
            for (int j = 1; j <= J; j++) addv(bitv[j], p, (MOD - pws[i][j]) % MOD);
            addc(p, -1);
        }
        for (int j = 1; j <= J; j++) addv(bitv[j], i, pws[i][j]);
        addc(i, 1);
        last[v] = i;

        for (int q : byR[i]) {
            int L = QL[q], R = QR[q];
            ll K = sumc(R) - sumc(L - 1);
            if (K <= 1) {
                ans[q] = 1;
                continue;
            }
            ll D = QD[q];
            if (D == 0) {
                ans[q] = 0;
                continue;
            }
            ll P[J + 1];
            for (int j = 1; j <= J; j++) {
                P[j] = (sumv(bitv[j], R) - sumv(bitv[j], L - 1) + MOD) % MOD;
            }
            ll S1 = St[1][K];
            ll c = ((P[1] - D * S1) % MOD + MOD) % MOD * pw(K, MOD - 2) % MOD;
            // Powers of c and D.
            ll cp[J + 1], dp[J + 1];
            cp[0] = dp[0] = 1;
            for (int e = 1; e <= J; e++) {
                cp[e] = cp[e - 1] * c % MOD;
                dp[e] = dp[e - 1] * D % MOD;
            }
            bool ok = true;
            for (int j = 2; j <= J && ok; j++) {
                ll rhs = 0;
                for (int t = 0; t <= j; t++) {
                    ll term = C[j][t] * cp[j - t] % MOD * dp[t] % MOD * St[t][K] % MOD;
                    rhs = (rhs + term) % MOD;
                }
                if (rhs != P[j]) ok = false;
            }
            ans[q] = ok ? 1 : 0;
        }
    }

    string out;
    out.reserve(Q * 4);
    for (int q = 0; q < Q; q++) {
        out += ans[q] ? "Yes\n" : "No\n";
    }
    fputs(out.c_str(), stdout);
    return 0;
}
