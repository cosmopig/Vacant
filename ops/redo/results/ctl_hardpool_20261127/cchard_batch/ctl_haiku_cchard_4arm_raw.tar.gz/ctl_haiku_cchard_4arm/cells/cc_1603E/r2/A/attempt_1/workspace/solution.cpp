#include <bits/stdc++.h>
using namespace std;

// A multiset with sorted values b_1 <= ... <= b_n is perfect iff for every j:
//     b_1 + ... + b_j <= b_1 * b_j.
// (All interval constraints follow: b_1 <= b_i, and prefix sums dominate interval sums.)
//
// Fix the minimum x = b_1. Sweep values v = x+1..n+1 and keep
//     dp[m][P] = sum over multisets of values < v (including the x-group), with m
//                elements and sum P, of prod_v (1 / c_v!)  (mod M).
// Adding c copies of v requires P + c*v <= x*v (the constraint at the group end,
// which implies it for every earlier copy). The answer is n! * sum_x dp[n][*].
//
// Pruning (exact, not heuristic): a state (m, P) before processing v can only lead to
// a valid final sum if P + (n-m)*v <= x*(n+1), because the remaining n-m elements are
// all >= v and the final sum is at most x*(n+1).

int main() {
    long long n, M;
    cin >> n >> M;
    const unsigned long long MOD = (unsigned long long)M;

    auto power = [&](unsigned long long b, unsigned long long e) {
        unsigned long long r = 1 % MOD;
        b %= MOD;
        while (e) {
            if (e & 1) r = r * b % MOD;
            b = b * b % MOD;
            e >>= 1;
        }
        return r;
    };

    vector<unsigned long long> fact(n + 1), invf(n + 1);
    fact[0] = 1;
    for (long long i = 1; i <= n; i++) fact[i] = fact[i - 1] * i % MOD;
    for (long long i = 0; i <= n; i++) invf[i] = power(fact[i], MOD - 2);

    const long long V = n + 1;
    unsigned long long answer = 0;
    // One reusable buffer (allocated once to avoid repeated page faults).
    vector<unsigned int> dp((n + 1) * (V * V + 1), 0);

    for (long long x = 1; x <= V; x++) {
        const long long S = x * V;             // largest sum we may ever need
        const long long W = S + 1;
        fill(dp.begin(), dp.begin() + (n + 1) * W, 0u);
        auto at = [&](long long m, long long P) -> unsigned int& { return dp[m * W + P]; };

        // Minimum group: c copies of x, with c*x <= x*x, i.e. c <= x.
        for (long long c = 1; c <= min(n, x); c++) {
            at(c, c * x) = (unsigned int)invf[c];
        }

        for (long long v = x + 1; v <= V; v++) {
            const long long lim = x * v;
            // In-place unbounded addition of copies of v. Descending m keeps every
            // source value read before it is overwritten by a smaller-m source.
            for (long long m = n - 1; m >= 1; m--) {
                if (m * x > lim) continue;     // every element is >= x, so P >= m*x
                long long hi = min(lim, m * (v - 1));
                hi = min(hi, S - (n - m) * v); // exact pruning, see above
                for (long long P = m * x; P <= hi; P++) {
                    unsigned long long w = at(m, P);
                    if (!w) continue;
                    for (long long c = 1; m + c <= n; c++) {
                        long long nP = P + c * v;
                        if (nP > lim) break;
                        unsigned long long add = w * invf[c] % MOD;
                        unsigned int& t = at(m + c, nP);
                        t = (unsigned int)((t + add) % MOD);
                    }
                }
            }
        }
        for (long long P = 0; P <= S; P++) {
            answer = (answer + at(n, P)) % MOD;
        }
    }
    answer = answer * fact[n] % MOD;
    cout << answer << "\n";
    return 0;
}
