import sys

M = 10 ** 9 + 7


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    q = int(data[1])
    A = [int(x) % M for x in data[2:2 + n]]
    pos = 2 + n
    queries = []
    for j in range(q):
        L = int(data[pos])
        R = int(data[pos + 1])
        D = int(data[pos + 2]) % M
        pos += 3
        if L > R:
            L, R = R, L
        queries.append((R, L, D, j))
    queries.sort()

    # Fenwick trees over positions holding the *last* occurrence of each
    # distinct residue seen so far: count, sum a, sum a^2, sum a^3 (mod M).
    C = [0] * (n + 1)
    P1 = [0] * (n + 1)
    P2 = [0] * (n + 1)
    P3 = [0] * (n + 1)

    def upd(i, sign, a):
        a2 = a * a % M
        a3 = a2 * a % M
        if sign < 0:
            a, a2, a3 = M - a, M - a2, M - a3
        while i <= n:
            C[i] += sign
            P1[i] = (P1[i] + a) % M
            P2[i] = (P2[i] + a2) % M
            P3[i] = (P3[i] + a3) % M
            i += i & (-i)

    def pref(i):
        c = 0
        s1 = s2 = s3 = 0
        while i > 0:
            c += C[i]
            s1 += P1[i]
            s2 += P2[i]
            s3 += P3[i]
            i -= i & (-i)
        return c, s1 % M, s2 % M, s3 % M

    ans = [None] * q
    last = {}
    cur = 0
    for R, L, D, j in queries:
        while cur < R:
            cur += 1
            a = A[cur - 1]
            if a in last:
                upd(last[a], -1, a)
            last[a] = cur
            upd(cur, 1, a)

        c1, s1, s2, s3 = pref(R)
        c0, t1, t2, t3 = pref(L - 1)
        m = c1 - c0
        P1v = (s1 - t1) % M
        P2v = (s2 - t2) % M
        P3v = (s3 - t3) % M

        if m <= 1:
            ans[j] = "Yes"
            continue
        if D == 0:
            # No road of length 0 joins two different cities.
            ans[j] = "No"
            continue

        # Map residues x -> k = x * D^{-1}; the roads become k -> k+1.
        inv = pow(D, M - 2, M)
        inv2 = inv * inv % M
        inv3 = inv2 * inv % M
        K1 = inv * P1v % M
        K2 = inv2 * P2v % M
        K3 = inv3 * P3v % M

        # Need the k-values to be the arc {s, s+1, ..., s+m-1} (mod M).
        T1 = m * (m - 1) // 2
        T2 = (m - 1) * m * (2 * m - 1) // 6
        T3 = T1 * T1
        s = (K1 - T1) * pow(m, M - 2, M) % M
        ok = (
            (m * s * s + 2 * s * T1 + T2 - K2) % M == 0
            and (m * s * s % M * s + 3 * s * s * T1 + 3 * s * T2 + T3 - K3) % M == 0
        )
        ans[j] = "Yes" if ok else "No"

    sys.stdout.write("\n".join(ans) + "\n")


main()
