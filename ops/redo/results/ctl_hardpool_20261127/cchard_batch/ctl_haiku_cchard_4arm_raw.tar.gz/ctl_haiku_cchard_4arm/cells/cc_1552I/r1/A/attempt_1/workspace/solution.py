import sys

MOD = 998244353


def fact(k):
    r = 1
    for i in range(2, k + 1):
        r = r * i % MOD
    return r


def insert_set(seq, placed, T):
    """Insert set T (overlapping some placed set) into ordered part-list seq.
    Returns new seq or None if impossible."""
    L = len(seq)
    idx = [i for i in range(L) if seq[i] & T]
    if not idx:
        return None
    l, r = idx[0], idx[-1]
    if len(idx) != r - l + 1:
        return None
    for i in range(l + 1, r):
        if not seq[i] <= T:
            return None
    new = T - placed
    left_split = lambda p: [x for x in (p - T, p & T) if x]   # outside first
    right_split = lambda p: [x for x in (p & T, p - T) if x]  # inside first
    if new:
        if l == r:
            if L == 1:
                mode = "append"
            elif r == L - 1:
                mode = "append"
            elif l == 0:
                mode = "prepend"
            else:
                return None
            if mode == "append":
                # l == r == L-1: split the end part so T's piece is at the end
                return seq[:l] + left_split(seq[l]) + [new]
            # l == r == 0: split the first part so T's piece is at the front
            return [new] + right_split(seq[0]) + seq[1:]
        else:
            if r == L - 1 and seq[r] <= T:
                return seq[:l] + left_split(seq[l]) + seq[l + 1:] + [new]
            if l == 0 and seq[l] <= T:
                return [new] + seq[:r] + right_split(seq[r]) + seq[r + 1:]
            return None
    else:
        out = seq[:l]
        if l == r:
            return None  # cannot happen for an overlapping set
        out += left_split(seq[l])
        out += seq[l + 1:r]
        out += right_split(seq[r])
        out += seq[r + 1:]
        return out


def build_component(comp, sets):
    """comp: list of indices into sets forming an overlap-connected component.
    Returns ordered list of parts (sets), or None if no valid arrangement."""
    ids = list(comp)
    overl = lambda a, b: (sets[a] & sets[b]) and not (sets[a] <= sets[b]) and not (sets[b] <= sets[a])
    start = ids[0]
    seq = [set(sets[start])]
    placed = set(sets[start])
    done = {start}
    queue = [start]
    while queue:
        cur = queue.pop(0)
        for t in ids:
            if t in done or not overl(cur, t):
                continue
            seq = insert_set(seq, placed, sets[t])
            if seq is None:
                return None
            placed |= sets[t]
            done.add(t)
            queue.append(t)
    if len(done) != len(ids):
        return None
    # verify every component set is a contiguous run of parts
    for s in ids:
        S = sets[s]
        pos = [i for i, p in enumerate(seq) if p & S]
        if not pos or len(pos) != pos[-1] - pos[0] + 1:
            return None
        for i in pos:
            if not seq[i] <= S:
                return None
    return seq


def count(U, F):
    """U: frozenset of elements; F: list of frozensets subsets of U."""
    n = len(U)
    sets = list({S for S in F if 2 <= len(S) < n})
    if not sets:
        return fact(n)
    k = len(sets)
    # overlap components
    parent = list(range(k))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for a in range(k):
        for b in range(a + 1, k):
            A, B = sets[a], sets[b]
            if (A & B) and not (A <= B) and not (B <= A):
                parent[find(a)] = find(b)
    comps = {}
    for i in range(k):
        comps.setdefault(find(i), []).append(i)
    comp_list = list(comps.values())
    unions = [frozenset().union(*[sets[i] for i in c]) for c in comp_list]

    # Case A: some component covers all of U -> Q-node
    for c, un in zip(comp_list, unions):
        if un == U:
            if len(c) < 2:
                continue
            parts = build_component(c, sets)
            if parts is None:
                return 0
            in_c = set(c)
            for j in range(k):
                if j in in_c:
                    continue
                S = sets[j]
                if not any(S <= p for p in parts):
                    return 0
            res = 2
            for p in parts:
                res = res * count(frozenset(p), [S for S in sets if S <= p]) % MOD
            return res

    # Case B: P-node over maximal unions
    uniq = list(set(unions))
    maxi = [u for u in uniq if not any(u < v for v in uniq)]
    covered = frozenset().union(*maxi) if maxi else frozenset()
    blocks = len(maxi) + (n - len(covered))
    res = fact(blocks)
    for u in maxi:
        res = res * count(u, [S for S in sets if S <= u]) % MOD
    return res


def main():
    data = sys.stdin.read().split()
    p = 0
    n = int(data[p]); m = int(data[p + 1]); p += 2
    F = []
    for _ in range(m):
        q = int(data[p]); p += 1
        F.append(frozenset(int(x) for x in data[p:p + q]))
        p += q
    print(count(frozenset(range(1, n + 1)), F) % MOD)


if __name__ == "__main__":
    main()
