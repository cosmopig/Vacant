import sys


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    a = data[1:1 + n]

    VMAX = 5001          # values are in [0, 5000]
    BITS = 13            # xor results are < 8192
    SIZE = 1 << BITS
    FULL = (1 << SIZE) - 1

    # Masks M[b]: positions p in [0, SIZE) whose bit b is 0.
    masks = []
    for b in range(BITS):
        s = 1 << b
        block = (1 << s) - 1          # s ones
        period = s << 1
        m = 0
        # build pattern: block of s ones followed by s zeros, repeated
        pattern = block  # positions 0..s-1 set (bit b of these is 0)
        length = period
        rep = SIZE // length
        # construct by doubling
        m = pattern
        cur = length
        while cur < SIZE:
            m |= m << cur
            cur <<= 1
        masks.append(m & FULL)

    shifts = [1 << b for b in range(BITS)]

    def translate(S, v):
        """Return {x ^ v : x in S} for bitset S."""
        b = 0
        vv = v
        while vv:
            if vv & 1:
                s = shifts[b]
                m = masks[b]
                S = ((S & m) << s) | ((S >> s) & m)
            vv >>= 1
            b += 1
        return S

    # Fenwick tree over values (index = value + 1), OR-combined.
    tree = [0] * (VMAX + 2)
    size = VMAX + 1

    def query(i):  # OR of indices 1..i
        r = 0
        while i > 0:
            r |= tree[i]
            i &= i - 1
        return r

    def update(i, val):  # OR val into index i
        while i <= size:
            tree[i] |= val
            i += i & (-i)

    Pv = [0] * VMAX           # xor-set of increasing subsequences ending at value v
    last_G = [-1] * VMAX      # last prefix set seen for value v (for skipping)

    for tok in a:
        v = int(tok)
        G = query(v) | 1      # empty subsequence contributes 0; values < v
        if G == last_G[v]:
            continue
        last_G[v] = G
        N = translate(G, v)
        new = N & ~Pv[v]
        if new:
            Pv[v] |= N
            update(v + 1, N)

    result = query(size) | 1
    xs = []
    x = 0
    while result:
        if result & 1:
            xs.append(x)
        result >>= 1
        x += 1

    out = [str(len(xs)), " ".join(map(str, xs))]
    sys.stdout.write("\n".join(out) + "\n")


main()
