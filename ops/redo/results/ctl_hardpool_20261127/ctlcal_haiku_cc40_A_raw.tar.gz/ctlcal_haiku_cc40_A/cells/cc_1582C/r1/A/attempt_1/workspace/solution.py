import sys


def solve_letter(s, n, c):
    """Minimum erasures of letter c to make s a palindrome, or -1 if impossible."""
    l, r = 0, n - 1
    cost = 0
    while l < r:
        if s[l] == s[r]:
            l += 1
            r -= 1
        elif s[l] == c:
            cost += 1
            l += 1
        elif s[r] == c:
            cost += 1
            r -= 1
        else:
            return -1
    return cost


def solve(s, n):
    l, r = 0, n - 1
    while l < r and s[l] == s[r]:
        l += 1
        r -= 1
    if l >= r:
        return 0
    # The erased letter must be one of the two mismatched outer characters.
    best = -1
    for c in {s[l], s[r]}:
        res = solve_letter(s, n, c)
        if res != -1 and (best == -1 or res < best):
            best = res
    return best


def main():
    data = sys.stdin.read().split()
    t = int(data[0])
    idx = 1
    out = []
    for _ in range(t):
        n = int(data[idx])
        s = data[idx + 1]
        idx += 2
        out.append(str(solve(s, len(s))))
    sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
