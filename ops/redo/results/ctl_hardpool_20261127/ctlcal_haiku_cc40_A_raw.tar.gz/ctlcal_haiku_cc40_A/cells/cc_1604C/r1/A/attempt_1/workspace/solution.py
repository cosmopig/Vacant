import sys


def main():
    data = sys.stdin.buffer.read().split()
    t = int(data[0])
    pos = 1
    out = []
    for _ in range(t):
        n = int(data[pos])
        pos += 1
        a = data[pos:pos + n]
        pos += n
        ok = True
        for j in range(1, n + 1):
            x = int(a[j - 1])
            # Element j can be erased at some current position p in [1, j];
            # it is erasable there iff (p + 1) does not divide x.
            # Such a p exists iff some d in [2, j + 1] does not divide x.
            # The smallest non-divisor of x <= 1e9 is small, so this loop is short.
            found = False
            d = 2
            while d <= j + 1:
                if x % d:
                    found = True
                    break
                d += 1
            if not found:
                ok = False
                break
        out.append("YES" if ok else "NO")
    sys.stdout.write("\n".join(out) + "\n")


main()
