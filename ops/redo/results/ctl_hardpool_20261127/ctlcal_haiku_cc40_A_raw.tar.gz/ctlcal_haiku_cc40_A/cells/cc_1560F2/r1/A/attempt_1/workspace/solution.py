import sys


def fill(prefix_digits, k, length):
    """Given the set of digits used so far (already <= k), return the smallest
    tail of `length` digits that keeps the total distinct count <= k."""
    s = set(prefix_digits)
    if len(s) < k:
        return "0" * length
    return str(min(s)) * length


def nearest(n_str, k):
    L = len(n_str)
    if len(set(n_str)) <= k:
        return n_str
    # Try keeping the longest possible prefix of n, then increasing the next digit.
    for i in range(L - 1, -1, -1):
        prefix = n_str[:i]
        pset = set(prefix)
        if len(pset) > k:
            continue
        for d in range(int(n_str[i]) + 1, 10):
            s = pset | {str(d)}
            if len(s) <= k:
                return prefix + str(d) + fill(s, k, L - i - 1)
    # No answer with L digits: go to L+1 digits.
    if k == 1:
        return "1" * (L + 1)
    return "1" + "0" * L


def main():
    data = sys.stdin.read().split()
    t = int(data[0])
    out = []
    idx = 1
    for _ in range(t):
        n_str = data[idx]
        k = int(data[idx + 1])
        idx += 2
        out.append(nearest(str(int(n_str)), k))
    sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
