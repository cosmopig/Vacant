import sys


def ideal(s, n, k):
    # The adversary wins (farm not ideal) iff some distribution with n pens has
    # no segment summing to k. Prefix sums 0=P_0<...<P_n=s form an (n+1)-subset
    # of [0, s] containing 0 and s with no two elements differing by k.
    if k > s:
        return False          # no segment can reach k
    if k == s:
        return True           # the whole farm always sums to s
    # Max size of such a subset of {0..s}: split into residue chains mod k.
    q, rem = divmod(s + 1, k)
    # Each chain of length L admits ceil(L/2) pairwise non-adjacent picks that
    # include both endpoints when needed, so 0 and s cost nothing extra.
    m = rem * ((q + 2) // 2) + (k - rem) * ((q + 1) // 2)
    return m <= n            # adversary needs n + 1 points


def main():
    data = sys.stdin.read().split()
    t = int(data[0])
    out = []
    idx = 1
    for _ in range(t):
        s, n, k = int(data[idx]), int(data[idx + 1]), int(data[idx + 2])
        idx += 3
        out.append("YES" if ideal(s, n, k) else "NO")
    sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
