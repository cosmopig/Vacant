import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    t = int(data[pos])
    pos += 1
    out = []
    for _ in range(t):
        m = int(data[pos])
        n = int(data[pos + 1])
        pos += 2
        best = [None] * n  # best[j]: max joy friend j can get from any shop
        best_second = None  # max over shops of the 2nd-largest joy within that shop
        for _i in range(m):
            row = list(map(int, data[pos:pos + n]))
            pos += n
            # top two values of this row (shop)
            first = second = None
            for j, v in enumerate(row):
                if best[j] is None or v > best[j]:
                    best[j] = v
                if first is None or v > first:
                    second, first = first, v
                elif second is None or v > second:
                    second = v
            if second is not None and (best_second is None or second > best_second):
                best_second = second
        # Feasibility for threshold X: every friend has a shop >= X (X <= min best),
        # and some shop serves >= 2 friends with >= X (X <= best_second), because
        # with at most n-1 shops, at least one shop must cover two friends.
        ans = min(min(best), best_second)
        out.append(str(ans))
    sys.stdout.write("\n".join(out) + "\n")


main()
