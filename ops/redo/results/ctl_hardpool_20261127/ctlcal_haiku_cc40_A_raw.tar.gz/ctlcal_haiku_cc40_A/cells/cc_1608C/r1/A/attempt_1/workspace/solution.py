import sys


def solve(n, a, b):
    # Player u can win iff he can reach the player p with the maximal
    # strength on map 1 (p beats everyone on map 1, so p then wins).
    # Edge u -> v exists if a[u] > a[v] or b[u] > b[v].
    # Reverse BFS from p: a player joins the set if he beats some member
    # on either map, i.e. a[u] > minA or b[u] > minB over the set so far.
    p = max(range(n), key=lambda i: a[i])
    in_set = [False] * n
    in_set[p] = True
    min_a = a[p]
    min_b = b[p]

    order_a = sorted(range(n), key=lambda i: -a[i])
    order_b = sorted(range(n), key=lambda i: -b[i])
    pa = 0
    pb = 0

    progress = True
    while progress:
        progress = False
        while pa < n and a[order_a[pa]] > min_a:
            u = order_a[pa]
            pa += 1
            progress = True
            if not in_set[u]:
                in_set[u] = True
                if a[u] < min_a:
                    min_a = a[u]
                if b[u] < min_b:
                    min_b = b[u]
        while pb < n and b[order_b[pb]] > min_b:
            u = order_b[pb]
            pb += 1
            progress = True
            if not in_set[u]:
                in_set[u] = True
                if a[u] < min_a:
                    min_a = a[u]
                if b[u] < min_b:
                    min_b = b[u]

    return ''.join('1' if x else '0' for x in in_set)


def main():
    data = sys.stdin.buffer.read().split()
    idx = 0
    t = int(data[idx])
    idx += 1
    out = []
    for _ in range(t):
        n = int(data[idx])
        idx += 1
        a = [int(x) for x in data[idx:idx + n]]
        idx += n
        b = [int(x) for x in data[idx:idx + n]]
        idx += n
        out.append(solve(n, a, b))
    sys.stdout.write('\n'.join(out) + '\n')


if __name__ == '__main__':
    main()
