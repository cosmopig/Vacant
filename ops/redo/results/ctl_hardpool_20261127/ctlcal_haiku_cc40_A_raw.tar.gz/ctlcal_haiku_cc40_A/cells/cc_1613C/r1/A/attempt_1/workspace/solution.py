import sys
from bisect import bisect_left


def main():
    data = sys.stdin.read().split()
    pos = 0
    t = int(data[pos]); pos += 1
    out = []
    for _ in range(t):
        n = int(data[pos]); h = int(data[pos + 1]); pos += 2
        a = [int(x) for x in data[pos:pos + n]]
        pos += n
        # Gaps between consecutive attacks; the last attack's poison is capped only by k.
        gaps = sorted(a[i + 1] - a[i] for i in range(n - 1))
        prefix = [0]
        for g in gaps:
            prefix.append(prefix[-1] + g)
        m = len(gaps)

        def damage(k):
            # Each gap contributes min(k, gap); the last attack contributes k.
            idx = bisect_left(gaps, k)  # gaps[:idx] < k, gaps[idx:] >= k
            return prefix[idx] + (m - idx + 1) * k

        lo, hi = 1, h  # damage(h) >= h always, so h is a valid upper bound
        while lo < hi:
            mid = (lo + hi) // 2
            if damage(mid) >= h:
                hi = mid
            else:
                lo = mid + 1
        out.append(str(lo))
    sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
