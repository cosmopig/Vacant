import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    m = int(data[pos]); pos += 1
    rows = data[pos:pos + n]
    pos += n

    # bad[j] = 1 if columns j and j+1 (0-indexed) contain a diagonal pair:
    # cell (i, j) filled and cell (i-1, j+1) filled, for some row i >= 1.
    # Such a pair makes the subgrid containing both columns indeterminable.
    X = ord('X')
    bad = [0] * m
    for i in range(1, n):
        cur = rows[i]
        prev = rows[i - 1]
        for j in range(m - 1):
            if cur[j] == X and prev[j + 1] == X:
                bad[j] = 1

    # prefix[j] = number of bad pairs among indices < j
    prefix = [0] * (m + 1)
    for j in range(m):
        prefix[j + 1] = prefix[j] + bad[j]

    q = int(data[pos]); pos += 1
    out = []
    for _ in range(q):
        x1 = int(data[pos]); x2 = int(data[pos + 1]); pos += 2
        # pairs (j, j+1) with x1-1 <= j and j+1 <= x2-1  => j in [x1-1, x2-2]
        lo = x1 - 1
        hi = x2 - 2  # inclusive
        if hi < lo:
            out.append("YES")
        else:
            cnt = prefix[hi + 1] - prefix[lo]
            out.append("NO" if cnt else "YES")
    sys.stdout.write("\n".join(out) + "\n")


main()
