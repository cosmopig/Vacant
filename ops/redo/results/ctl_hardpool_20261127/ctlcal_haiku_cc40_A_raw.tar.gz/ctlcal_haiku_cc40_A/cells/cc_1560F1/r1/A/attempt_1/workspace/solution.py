import sys


def smallest_at_least(ns, allowed):
    """Smallest integer >= int(ns) whose digits all lie in `allowed` (a sorted list of
    digit characters), with the same length as ns or one digit longer. Returns int or None."""
    L = len(ns)
    allowed_set = set(allowed)
    # Same length: the answer shares the longest possible prefix with ns.
    if all(c in allowed_set for c in ns):
        return int(ns)
    lo = allowed[0]
    # p = length of the longest prefix of ns made only of allowed digits.
    p = 0
    while p < L and ns[p] in allowed_set:
        p += 1
    # Try the longest shared prefix first (i = p is the largest usable index, p < L here).
    for i in range(min(p, L - 1), -1, -1):
        cur = int(ns[i])
        for d in allowed:
            if int(d) > cur:
                return int(ns[:i] + d + lo * (L - i - 1))
    # No same-length answer: use length L+1 with the smallest nonzero leading digit.
    nonzero = [d for d in allowed if d != "0"]
    if not nonzero:
        return None
    return int(nonzero[0] + lo * L)


def solve(n, k):
    ns = str(n)
    best = None
    if k == 1:
        sets = [[str(d)] for d in range(1, 10)]
    else:
        sets = [[str(a), str(b)] for a in range(10) for b in range(a + 1, 10)]
    for s in sets:
        s = sorted(s)
        cand = smallest_at_least(ns, s)
        if cand is not None and (best is None or cand < best):
            best = cand
    return best


def main():
    data = sys.stdin.read().split()
    t = int(data[0])
    out = []
    idx = 1
    for _ in range(t):
        n = int(data[idx])
        k = int(data[idx + 1])
        idx += 2
        out.append(str(solve(n, k)))
    sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
