import sys


def main():
    data = sys.stdin.buffer.read().split()
    q = int(data[0])
    idx = 1

    # DSU over "value nodes". Each node carries a label = the current value
    # of every array element that belongs to its set.
    parent = [0] * (q + 1)
    label = [0] * (q + 1)
    size = [1] * (q + 1)
    cur = {}          # value -> node currently representing that value (absent = none)
    pos_node = []     # node assigned to each array element at insertion time
    n_nodes = 0

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    for _ in range(q):
        t = data[idx]
        if t == b"1":
            x = int(data[idx + 1])
            idx += 2
            node = cur.get(x)
            if node is None:
                node = n_nodes
                n_nodes += 1
                parent[node] = node
                label[node] = x
                cur[x] = node
            pos_node.append(node)
        else:
            x = int(data[idx + 1])
            y = int(data[idx + 2])
            idx += 3
            a = cur.pop(x, None)
            if a is None or x == y:
                if a is not None:
                    cur[x] = a
                continue
            b = cur.get(y)
            if b is None:
                cur[y] = a
                label[find(a)] = y
            else:
                ra = find(a)
                rb = find(b)
                if ra != rb:
                    if size[ra] < size[rb]:
                        ra, rb = rb, ra
                    parent[rb] = ra
                    size[ra] += size[rb]
                label[ra] = y

    out = [str(label[find(nd)]) for nd in pos_node]
    sys.stdout.write(" ".join(out) + "\n")


main()
