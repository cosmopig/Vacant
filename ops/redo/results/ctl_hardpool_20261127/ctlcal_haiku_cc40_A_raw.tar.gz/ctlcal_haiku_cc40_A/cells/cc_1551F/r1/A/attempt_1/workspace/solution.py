import sys
from math import comb
from collections import deque

MOD = 10**9 + 7


def solve(n, k, adj):
    if k == 2:
        # Any pair of distinct vertices is equidistant trivially.
        return comb(n, 2) % MOD

    # For k >= 3, an equidistant set is a set of vertices all at the same
    # distance d from a common centre c, lying in pairwise distinct branches
    # of c. The centre is unique, so each set is counted exactly once.
    ans = 0
    for c in range(1, n + 1):
        # per_depth[d] = list over branches of c of the number of vertices
        # at distance d from c inside that branch.
        per_depth = {}
        for u in adj[c]:
            # BFS over the branch rooted at neighbour u (not going back through c).
            level = {}
            seen = {c, u}
            q = deque([(u, 1)])
            while q:
                x, d = q.popleft()
                level[d] = level.get(d, 0) + 1
                for y in adj[x]:
                    if y not in seen:
                        seen.add(y)
                        q.append((y, d + 1))
            for d, cnt in level.items():
                per_depth.setdefault(d, []).append(cnt)
        # For each depth, choose one vertex from each of k distinct branches:
        # the number of ways is the k-th elementary symmetric polynomial of the counts.
        for counts in per_depth.values():
            if len(counts) < k:
                continue
            e = [1] + [0] * k  # e[j] = ways to pick j branches so far
            for w in counts:
                for j in range(k, 0, -1):
                    e[j] = (e[j] + e[j - 1] * w) % MOD
            ans = (ans + e[k]) % MOD
    return ans % MOD


def main():
    data = sys.stdin.read().split()
    pos = 0
    t = int(data[pos]); pos += 1
    out = []
    for _ in range(t):
        n = int(data[pos]); k = int(data[pos + 1]); pos += 2
        adj = [[] for _ in range(n + 1)]
        for _ in range(n - 1):
            u = int(data[pos]); v = int(data[pos + 1]); pos += 2
            adj[u].append(v)
            adj[v].append(u)
        out.append(str(solve(n, k, adj)))
    sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
