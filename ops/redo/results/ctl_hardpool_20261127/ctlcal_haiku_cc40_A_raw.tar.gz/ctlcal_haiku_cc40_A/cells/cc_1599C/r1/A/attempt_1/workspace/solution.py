import sys
from fractions import Fraction
from math import comb


def success_numerator2(n, k):
    """2 * (probability * C(n,3)) of playing a studied map when Johnny studies k of n maps.

    Model: Johnny is one of the two players and discards an unstudied map whenever one is
    shown; the opponent discards uniformly at random among the three shown maps. Then the
    played map is chosen uniformly from the maps nobody discarded. Let m = n - k:
      - 3 studied shown: success 1
      - 2 studied shown: success 1
      - 1 studied shown: success 1/2
      - 0 studied shown: success 0
    The result is multiplied by 2 to stay in integers.
    """
    m = n - k
    return 2 * comb(k, 3) + 2 * comb(k, 2) * m + k * comb(m, 2)


def main():
    data = sys.stdin.read().split()
    n = int(data[0])
    p = Fraction(data[1])
    total2 = 2 * comb(n, 3)
    # Smallest k with success(k) >= p, where success = num2 / total2.
    k = 0
    while k < n and success_numerator2(n, k) < p * total2:
        k += 1
    print(k)


if __name__ == "__main__":
    main()
