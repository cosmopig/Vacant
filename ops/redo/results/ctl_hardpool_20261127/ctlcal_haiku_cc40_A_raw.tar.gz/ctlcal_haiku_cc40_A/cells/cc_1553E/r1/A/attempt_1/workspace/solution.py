import sys


def main():
    data = sys.stdin.buffer.read().split()
    t = int(data[0])
    pos = 1
    out = []
    for _ in range(t):
        n = int(data[pos])
        m = int(data[pos + 1])
        pos += 2
        # a[i] = p_i - 1 (0-indexed value)
        a = [int(x) - 1 for x in data[pos:pos + n]]
        pos += n

        # Shifting identity right by k gives value v at position (v + k) mod n.
        # Transforming the shifted array into p needs n - cycles(f_k) swaps,
        # where f_k(i) = (a[i] + k) mod n.
        # A permutation with fixed-point count F_fix has (n - F_fix) non-fixed
        # points, and needs at least (n - F_fix) / 2 swaps, so n - F_fix <= 2m.
        # Fixed point for k at i iff k == (i - a[i]) mod n.
        cnt = [0] * n
        for i in range(n):
            cnt[(i - a[i]) % n] += 1

        need = n - 2 * m
        candidates = [k for k in range(n) if cnt[k] >= need]
        # Since need >= n/3, at most 3 candidates exist.
        res = []
        for k in candidates:
            seen = [False] * n
            cycles = 0
            for i in range(n):
                if not seen[i]:
                    cycles += 1
                    j = i
                    while not seen[j]:
                        seen[j] = True
                        j = (a[j] + k) % n
            if n - cycles <= m:
                res.append(k)

        res.sort()
        out.append(str(len(res)))
        if res:
            out.append(" ".join(map(str, res)))
    sys.stdout.write("\n".join(out) + "\n")


main()
