import sys


def main():
    data = sys.stdin.read().split()
    pos = 0
    t = int(data[pos])
    pos += 1
    out = []
    for _ in range(t):
        n = int(data[pos])
        pos += 1
        words = data[pos:pos + n]
        pos += n
        best = 0
        for letter in "abcde":
            # For a chosen set, the letter is dominant iff sum of (2*count_letter - len) > 0.
            vals = [2 * w.count(letter) - len(w) for w in words]
            vals.sort(reverse=True)
            total = 0
            k = 0
            for v in vals:
                total += v
                if total <= 0:
                    break
                k += 1
            if k > best:
                best = k
        out.append(str(best))
    sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
