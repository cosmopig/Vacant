import sys

MOD = 10 ** 9 + 7


def solve(n, k):
    if n % 2 == 1:
        # Win iff XOR == AND. Each bit column: even count below n, or all n ones.
        w = (pow(2, n - 1, MOD) + 1) % MOD
        return pow(w, k, MOD)
    # n even.
    a = (pow(2, n - 1, MOD) - 1) % MOD   # per-column ways: even count, not full
    b = pow(2, n, MOD)                   # per-column ways below the top AND bit
    # AND == 0 and XOR == 0.
    total = pow(a, k, MOD)
    # Highest AND bit i: column i is full, columns above i are even-and-not-full,
    # columns below i are free. Sum over i = Horner evaluation of sum_i b^i a^(k-1-i).
    s = 0
    bp = 1
    for _ in range(k):
        s = (s * a + bp) % MOD
        bp = bp * b % MOD
    return (total + s) % MOD


def main():
    data = sys.stdin.read().split()
    t = int(data[0])
    out = []
    idx = 1
    for _ in range(t):
        n = int(data[idx])
        k = int(data[idx + 1])
        idx += 2
        out.append(str(solve(n, k)))
    sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
