import sys


def main():
    data = sys.stdin.buffer.read().split()
    n, m, q = int(data[0]), int(data[1]), int(data[2])
    a = [int(x) for x in data[3:3 + n]]
    b = [int(x) for x in data[3 + n:3 + n + m]]
    ks = [int(x) for x in data[3 + n + m:3 + n + m + q]]

    # Every price, from both characters, is a "slot" that some item of ours can
    # end up holding.  Given items may return to the pool and be re-acquired, so
    # the union of both lists is the pool of values.  Within a run of values whose
    # consecutive gaps are <= k, any item can reach the top of that run.
    vals = sorted([(x, 1) for x in a] + [(x, 0) for x in b])
    N = len(vals)
    v = [x for x, _ in vals]
    is_src = [f for _, f in vals]
    gaps = [v[i + 1] - v[i] for i in range(N - 1)]

    out = []
    top = [0] * N
    for k in ks:
        # top[i]: index of the largest value reachable from v[i] (end of its run)
        top[N - 1] = N - 1
        for i in range(N - 2, -1, -1):
            top[i] = i if gaps[i] > k else top[i + 1]

        # Process our items in ascending order.  Each takes the largest unused
        # slot not above its reach.  Slots are pushed in ascending order, so a
        # stack always yields the largest unused slot within reach.
        stack = []
        pushed = 0  # slots with index < pushed are on the stack or used
        total = 0
        for i in range(N):
            if not is_src[i]:
                continue
            r = top[i]
            while pushed <= r:
                stack.append(v[pushed])
                pushed += 1
            total += stack.pop()
        out.append(total)

    sys.stdout.write("\n".join(map(str, out)) + ("\n" if out else ""))


main()
