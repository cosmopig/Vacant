import sys


def solve(n, k, a):
    # Levels j = 0..n-2 cover digit positions [a[j], a[j+1]); the top level
    # (denomination 10^a[n-1]) is unbounded. f(s) = sum of level values + top count.
    P = 10 ** a[-1]
    widths = [a[j + 1] - a[j] for j in range(n - 1)]
    M = sum(10 ** w - 1 for w in widths)  # maximum count from the bounded levels

    if M >= k + 1:
        # Top count is 0; smallest L < P whose lower-level count is >= k+1.
        # Filling the cheapest (lowest) levels first minimises L.
        rem = k + 1
        L = 0
        for j in range(n - 1):
            if rem == 0:
                break
            v = min(rem, 10 ** widths[j] - 1)
            L += v * 10 ** a[j]
            rem -= v
        return L

    # Top count t = k+1-M is required; the lower part must be maximal (P-1).
    t = k + 1 - M
    return (t + 1) * P - 1


def main():
    data = sys.stdin.read().split()
    idx = 0
    t = int(data[idx]); idx += 1
    out = []
    for _ in range(t):
        n = int(data[idx]); k = int(data[idx + 1]); idx += 2
        a = [int(x) for x in data[idx:idx + n]]
        idx += n
        out.append(str(solve(n, k, a)))
    sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
