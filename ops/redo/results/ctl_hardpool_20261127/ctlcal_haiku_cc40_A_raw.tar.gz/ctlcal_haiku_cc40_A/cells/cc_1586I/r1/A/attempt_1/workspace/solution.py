import sys


def main():
    data = sys.stdin.read().split()
    if not data:
        print("NONE")
        return
    n = int(data[0])
    rows = data[1:1 + n]

    # Odd n has no mastapeece (single cell or any odd grid fails parity).
    if n % 2 == 1 or len(rows) != n or any(len(r) != n for r in rows):
        print("NONE")
        return
    for r in rows:
        for ch in r:
            if ch not in "SG.":
                print("NONE")
                return

    # Every mastapeece for even n is determined by m = n/2 bits x_0..x_{m-1}:
    #   cell (i, j) has colour bit  base(i,j) XOR x[k(i,j)]
    # where base is the ring pattern (S on even depths) and k(i,j) is a
    # "folded diagonal" index.  All 2^m choices give distinct valid mosaics.
    m = n // 2
    two_n = 2 * n

    # sumk[t] / diffk[t]: pair index for a folded diagonal coordinate t (t mod 2n).
    def fold(t):
        return t if t < n else two_n - 1 - t

    kt = [fold(t) // 2 for t in range(two_n)]  # index by t mod 2n

    def kidx(i, j):
        if (i + j) % 2 == 0:
            return kt[(i + j) % two_n]
        return kt[(j - i) % two_n]

    # base colour (1 = S) of cell (i, j): ring pattern, S on even depths.
    def base_row(i):
        di = min(i, n - 1 - i)
        return [1 if min(di, j, n - 1 - j) % 2 == 0 else 0 for j in range(n)]

    x = [-1] * m
    for i in range(n):
        r = rows[i]
        if r.count(".") == n:
            continue
        b = base_row(i)
        for j in range(n):
            ch = r[j]
            if ch == ".":
                continue
            need = (1 if ch == "S" else 0) ^ b[j]
            k = kidx(i, j)
            if x[k] == -1:
                x[k] = need
            elif x[k] != need:
                print("NONE")
                return

    if any(v == -1 for v in x):
        print("MULTIPLE")
        return

    out = ["UNIQUE"]
    for i in range(n):
        b = base_row(i)
        line = []
        for j in range(n):
            bit = b[j] ^ x[kidx(i, j)]
            line.append("S" if bit else "G")
        out.append("".join(line))
    sys.stdout.write("\n".join(out) + "\n")


main()
