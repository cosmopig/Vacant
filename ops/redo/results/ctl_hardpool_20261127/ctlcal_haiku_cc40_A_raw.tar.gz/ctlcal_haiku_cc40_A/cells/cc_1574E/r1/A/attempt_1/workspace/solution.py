import sys


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    m = int(data[1])
    k = int(data[2])
    MOD = 998244353

    # Beautiful matrices are exactly:
    #   type A: a[i][j] = x_i XOR (j & 1)   (each row alternates, 2^n of them)
    #   type B: a[i][j] = y_j XOR (i & 1)   (each column alternates, 2^m of them)
    # and the overlap (type A and B) is a[i][j] = c XOR (i&1) XOR (j&1), 2 matrices.
    # Answer = A + B - AB, where each term counts matrices consistent with the fixed cells.

    cells = {}          # (x, y) -> value
    rows = {}           # x -> [count implying row bit 0, count implying row bit 1]
    cols = {}           # y -> [count implying col bit 0, count implying col bit 1]
    # S[0] constrained rows, S[1] conflicting rows, S[2] constrained cols, S[3] conflicting cols
    S = [0, 0, 0, 0]
    Z = [0, 0]          # Z[c] = number of fixed cells implying overlap constant c

    def apply(x, y, v, d):
        # row constraint: x_i = v XOR (y & 1)
        r = rows.get(x)
        if r is None:
            r = [0, 0]
            rows[x] = r
        wasC = (r[0] + r[1]) > 0
        wasB = r[0] > 0 and r[1] > 0
        r[v ^ (y & 1)] += d
        isC = (r[0] + r[1]) > 0
        isB = r[0] > 0 and r[1] > 0
        S[0] += int(isC) - int(wasC)
        S[1] += int(isB) - int(wasB)

        # column constraint: y_j = v XOR (x & 1)
        c = cols.get(y)
        if c is None:
            c = [0, 0]
            cols[y] = c
        wasC = (c[0] + c[1]) > 0
        wasB = c[0] > 0 and c[1] > 0
        c[v ^ (x & 1)] += d
        isC = (c[0] + c[1]) > 0
        isB = c[0] > 0 and c[1] > 0
        S[2] += int(isC) - int(wasC)
        S[3] += int(isB) - int(wasB)

        # overlap constant: c = v XOR (x & 1) XOR (y & 1)
        Z[v ^ (x & 1) ^ (y & 1)] += d

    out = []
    idx = 3
    for _ in range(k):
        x = int(data[idx])
        y = int(data[idx + 1])
        t = int(data[idx + 2])
        idx += 3
        key = (x, y)
        old = cells.pop(key, None)
        if old is not None:
            apply(x, y, old, -1)
        if t != -1:
            cells[key] = t
            apply(x, y, t, 1)

        A = 0 if S[1] else pow(2, n - S[0], MOD)
        B = 0 if S[3] else pow(2, m - S[2], MOD)
        if Z[0] and Z[1]:
            AB = 0
        elif not cells:
            AB = 2
        else:
            AB = 1
        out.append((A + B - AB) % MOD)

    sys.stdout.write("\n".join(map(str, out)) + "\n")


main()
