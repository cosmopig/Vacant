# Arena

Time limit per test: 3 seconds. Memory limit: 244 MB.

Write a Python 3 program that reads from standard input and writes to standard output.

There are n heroes fighting in the arena. Initially, the i-th hero has a_i health points.

The fight in the arena takes place in several rounds. At the beginning of each round, each alive hero deals 1 damage to all other heroes. Hits of all heroes occur simultaneously. Heroes whose health is less than 1 at the end of the round are considered killed.

If exactly 1 hero remains alive after a certain round, then he is declared the winner. Otherwise, there is no winner.

Your task is to calculate the number of ways to choose the initial health points for each hero a_i, where 1 ≤ a_i ≤ x, so that there is no winner of the fight. The number of ways can be very large, so print it modulo 998244353. Two ways are considered different if at least one hero has a different amount of health. For example, [1, 2, 1] and [2, 1, 1] are different.

Input

The only line contains two integers n and x (2 ≤ n ≤ 500; 1 ≤ x ≤ 500).

Output

Print one integer — the number of ways to choose the initial health points for each hero a_i, where 1 ≤ a_i ≤ x, so that there is no winner of the fight, taken modulo 998244353. 

Examples

Input


2 5


Output


5


Input


3 3


Output


15


Input


5 4


Output


1024


Input


13 37


Output


976890680
