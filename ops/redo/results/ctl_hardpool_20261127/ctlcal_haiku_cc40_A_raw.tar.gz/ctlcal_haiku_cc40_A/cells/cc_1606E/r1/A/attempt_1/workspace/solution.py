import sys
from operator import mul

MOD = 998244353


def main():
    data = sys.stdin.read().split()
    n, x = int(data[0]), int(data[1])

    # Model: with k heroes alive, every alive hero loses k-1 health per round.
    # Shift health by the total damage so far: a hero with relative health b (1..m)
    # survives a round with k alive iff b > k-1, and then has b-(k-1) left.
    # g(m, k) = number of ways to choose k labelled relative healths in [1..m]
    # such that the fight never ends with exactly one survivor.
    #   g(m, 0) = 1           (everyone dead: no winner)
    #   g(m, 1) = 0           (immediate winner)
    #   g(m, k) = m^k         if m < k  (all die in the first round)
    #   g(m, k) = sum_{c=0}^{k} C(k,c) * (k-1)^c * g(m-k+1, k-c)   if m >= k
    # where c heroes die this round (values in [1..k-1]) and k-c survive.
    # Answer: g(x, n).

    fact = [1] * (n + 1)
    for i in range(1, n + 1):
        fact[i] = fact[i - 1] * i % MOD
    inv_fact = [1] * (n + 1)
    inv_fact[n] = pow(fact[n], MOD - 2, MOD)
    for i in range(n, 0, -1):
        inv_fact[i - 1] = inv_fact[i] * i % MOD

    # coef[k][c] = C(k,c) * (k-1)^c mod MOD
    coef = [None] * (n + 1)
    for k in range(2, n + 1):
        base = k - 1
        lst = []
        pw = 1
        for c in range(k + 1):
            comb = fact[k] * inv_fact[c] % MOD * inv_fact[k - c] % MOD
            lst.append(comb * pw % MOD)
            pw = pw * base % MOD
        coef[k] = lst

    G = [None] * (x + 1)
    for m in range(0, x + 1):
        row = [0] * (n + 1)
        row[0] = 1
        row[1] = 0
        for k in range(2, n + 1):
            if m < k:
                row[k] = pow(m, k, MOD)
            else:
                r = m - k + 1
                # G[r][k - c] for c = 0..k is G[r][k], G[r][k-1], ..., G[r][0]
                row[k] = sum(map(mul, coef[k], G[r][k::-1])) % MOD
        G[m] = row

    print(G[x][n] % MOD)


if __name__ == "__main__":
    main()
