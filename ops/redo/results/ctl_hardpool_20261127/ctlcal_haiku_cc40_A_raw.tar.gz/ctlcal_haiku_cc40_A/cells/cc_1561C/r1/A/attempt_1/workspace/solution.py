import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    t = int(data[pos])
    pos += 1
    out = []
    for _ in range(t):
        n = int(data[pos])
        pos += 1
        caves = []
        for _ in range(n):
            k = int(data[pos])
            pos += 1
            # Starting power P must satisfy P + j > a_j (0-indexed j),
            # i.e. P >= a_j - j + 1 for every monster in the cave.
            need = -10**18
            for j in range(k):
                v = int(data[pos + j]) - j + 1
                if v > need:
                    need = v
            pos += k
            caves.append((need - k, need, k))
        # Exchange argument: process caves in ascending order of need - k.
        caves.sort()
        gained = 0
        best = -10**18
        for _, need, k in caves:
            cand = need - gained
            if cand > best:
                best = cand
            gained += k
        out.append(str(best))
    sys.stdout.write("\n".join(out) + "\n")


main()
