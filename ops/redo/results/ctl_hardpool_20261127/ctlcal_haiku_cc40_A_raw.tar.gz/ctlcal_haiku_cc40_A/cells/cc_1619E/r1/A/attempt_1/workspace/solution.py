import sys
import heapq


def solve(n, a):
    cnt = [0] * (n + 2)
    for x in a:
        cnt[x] += 1

    res = [cnt[0]]  # MEX 0: every copy of 0 must be incremented once
    heap = []       # max-heap (stored negated) of surplus values below current gap
    cost = 0        # cost of filling gaps 0..i-1
    feasible = True

    for i in range(1, n + 1):
        k = i - 1
        if feasible:
            if cnt[k] == 0:
                if heap:
                    v = -heapq.heappop(heap)
                    cost += k - v
                else:
                    feasible = False
            else:
                for _ in range(cnt[k] - 1):
                    heapq.heappush(heap, -k)
        if not feasible:
            res.append(-1)
        else:
            # value i must be absent: each copy of i is bumped by 1 (cost 1 each)
            res.append(cost + cnt[i])
    return res


def main():
    data = sys.stdin.buffer.read().split()
    t = int(data[0])
    pos = 1
    out = []
    for _ in range(t):
        n = int(data[pos])
        pos += 1
        a = list(map(int, data[pos:pos + n]))
        pos += n
        out.append(" ".join(map(str, solve(n, a))))
    sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
