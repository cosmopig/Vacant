import sys
import random


def main():
    sys.setrecursionlimit(10000)
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    q = int(data[1])
    p = [0] * (n + 1)
    for i in range(n):
        p[i + 1] = int(data[2 + i])

    # Implicit treap over nodes 1..n. Each treap is one cycle of the permutation,
    # stored in cycle order: the element after node a is p[a].
    L = [0] * (n + 1)
    R = [0] * (n + 1)
    P = [0] * (n + 1)
    S = [0] * (n + 1)
    rnd = random.getrandbits
    Pr = [0] + [rnd(40) for _ in range(n)]

    def upd(t):
        lt = L[t]
        rt = R[t]
        S[t] = S[lt] + S[rt] + 1
        if lt:
            P[lt] = t
        if rt:
            P[rt] = t

    def split(t, k):
        # returns (first k nodes, rest)
        if not t:
            return 0, 0
        lt = L[t]
        if S[lt] >= k:
            a, b = split(lt, k)
            L[t] = b
            upd(t)
            return a, t
        a, b = split(R[t], k - S[lt] - 1)
        R[t] = a
        upd(t)
        return t, b

    def merge(a, b):
        if not a:
            return b
        if not b:
            return a
        if Pr[a] > Pr[b]:
            R[a] = merge(R[a], b)
            upd(a)
            return a
        L[b] = merge(a, L[b])
        upd(b)
        return b

    def root(x):
        while P[x]:
            x = P[x]
        return x

    def rank(x):
        r = S[L[x]]
        while P[x]:
            par = P[x]
            if R[par] == x:
                r += S[L[par]] + 1
            x = par
        return r

    def kth(t, k):
        while True:
            ls = S[L[t]]
            if k < ls:
                t = L[t]
            elif k == ls:
                return t
            else:
                k -= ls + 1
                t = R[t]

    def clear_root(t):
        if t:
            P[t] = 0
        return t

    # Build cycles.
    seen = [False] * (n + 1)
    cycles = []
    for i in range(1, n + 1):
        if seen[i]:
            continue
        cur = i
        root_t = 0
        while not seen[cur]:
            seen[cur] = True
            S[cur] = 1
            root_t = merge(root_t, cur)
            cur = p[cur]
        cycles.append(clear_root(root_t))
    # Ensure all parent pointers are consistent with the built trees.
    # (merge/upd maintain P for every child; only roots need P = 0.)

    out = []
    pos = 2 + n
    for _ in range(q):
        t = data[pos]
        if t == b"1":
            x = int(data[pos + 1])
            y = int(data[pos + 2])
            pos += 3
            rx = root(x)
            ry = root(y)
            if rx == ry:
                s = rank(x)
                tt = rank(y)
                if s > tt:
                    x, y = y, x
                    s, tt = tt, s
                # cycle: A = [0..s] (ends with x), B = [s+1..tt] (ends with y), C = [tt+1..]
                A, rest = split(rx, s + 1)
                clear_root(A)
                B, C = split(rest, tt - s)
                clear_root(B)
                clear_root(C)
                # cycle1 = B ; cycle2 = C + A
                clear_root(merge(C, A))
                clear_root(B)
            else:
                s = rank(x)
                tt = rank(y)
                XL, rest = split(rx, s)
                Xx, XR = split(rest, 1)
                YL, rest2 = split(ry, tt)
                Yy, YR = split(rest2, 1)
                for node in (XL, Xx, XR, YL, Yy, YR):
                    clear_root(node)
                # new cycle: x, Y_R, Y_L, y, X_R, X_L
                m = merge(Xx, YR)
                m = merge(m, YL)
                m = merge(m, Yy)
                m = merge(m, merge(XR, XL))
                clear_root(m)
        else:
            i = int(data[pos + 1])
            k = int(data[pos + 2])
            pos += 3
            r = root(i)
            idx = rank(i)
            length = S[r]
            ans = kth(r, (idx + k) % length)
            out.append(ans)

    sys.stdout.write("\n".join(map(str, out)) + "\n")


main()
