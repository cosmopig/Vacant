import sys

MOD = 998244353


def main():
    data = sys.stdin.read().split()
    n = int(data[0])
    k = int(data[1])
    s = [1 if ch == '1' else 0 for ch in data[2][:n]]
    m = sum(s)
    if k > m:
        print(1)
        return
    fact = [1] * (n + 1)
    for i in range(1, n + 1):
        fact[i] = fact[i - 1] * i % MOD
    inv = [1] * (n + 1)
    inv[n] = pow(fact[n], MOD - 2, MOD)
    for i in range(n, 0, -1):
        inv[i - 1] = inv[i] * i % MOD

    total = 1  # the unchanged string
    for L in range(n):
        a = 1 - s[L]
        c = s[L]
        for R in range(L + 1, n):
            c += s[R]
            if c > k:
                break
            b = 1 - s[R]
            j = c - a - b
            x = R - L - 1
            if 0 <= j <= x:
                total += fact[x] * inv[j] * inv[x - j]
    print(total % MOD)


main()
