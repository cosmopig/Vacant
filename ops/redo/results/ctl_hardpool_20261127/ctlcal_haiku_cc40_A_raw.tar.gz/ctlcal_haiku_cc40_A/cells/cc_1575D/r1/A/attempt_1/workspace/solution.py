import sys


def count(s):
    n = len(s)
    if n == 1:
        # Only the number 0 is divisible by 25 with one digit; "_" and "X" can both be 0.
        return 1 if s in "0_X" else 0

    total = 0
    # X stands for one digit d shared by all X positions; each d gives distinct numbers.
    ds = range(10) if "X" in s else [None]
    for d in ds:
        # Last two digits must form a multiple of 25.
        for e in ("00", "25", "50", "75"):
            ways = 1
            for i, c in enumerate(s):
                if i >= n - 2:
                    t = int(e[i - (n - 2)])
                    if c == "_":
                        allowed = [t]
                    elif c == "X":
                        allowed = [t] if d == t else []
                    else:
                        allowed = [t] if int(c) == t else []
                else:
                    if c == "_":
                        allowed = list(range(10))
                    elif c == "X":
                        allowed = [d]
                    else:
                        allowed = [int(c)]
                if i == 0:
                    # No leading zero in a number with more than one digit.
                    allowed = [x for x in allowed if x != 0]
                ways *= len(allowed)
                if ways == 0:
                    break
            total += ways
    return total


def main():
    s = sys.stdin.read().split()
    s = s[0] if s else ""
    print(count(s))


if __name__ == "__main__":
    main()
