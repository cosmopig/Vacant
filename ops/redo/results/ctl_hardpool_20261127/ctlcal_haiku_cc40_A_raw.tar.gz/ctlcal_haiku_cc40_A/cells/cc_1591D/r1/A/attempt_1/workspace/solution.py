import sys


def main():
    data = sys.stdin.buffer.read().split()
    t = int(data[0])
    pos = 1
    out = []
    for _ in range(t):
        n = int(data[pos])
        pos += 1
        a = list(map(int, data[pos:pos + n]))
        pos += n

        # Stable sort: order[k] is the index of the element that belongs at position k.
        order = sorted(range(n), key=a.__getitem__)

        # Duplicates allow an odd permutation to be fixed by swapping equal values.
        has_dup = False
        for k in range(1, n):
            if a[order[k]] == a[order[k - 1]]:
                has_dup = True
                break

        # Parity of the permutation p with p[order[k]] = k, via cycle count.
        p = [0] * n
        for k in range(n):
            p[order[k]] = k
        seen = [False] * n
        cycles = 0
        for i in range(n):
            if not seen[i]:
                cycles += 1
                j = i
                while not seen[j]:
                    seen[j] = True
                    j = p[j]
        even = (n - cycles) % 2 == 0

        out.append("YES" if (even or has_dup) else "NO")

    sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
