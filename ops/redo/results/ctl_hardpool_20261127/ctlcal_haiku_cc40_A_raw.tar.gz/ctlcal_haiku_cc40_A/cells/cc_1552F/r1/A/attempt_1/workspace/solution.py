import sys
from bisect import bisect_right

MOD = 998244353


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    xs = [0] * n
    ys = [0] * n
    ss = [0] * n
    idx = 1
    for i in range(n):
        xs[i] = int(data[idx])
        ys[i] = int(data[idx + 1])
        ss[i] = data[idx + 2] == b"1"
        idx += 3

    # dp[i] = time for the ant to go from y_i back to x_i once portal i has
    # been triggered: (x_i - y_i) plus the dp values of every portal j with
    # y_i < x_j < x_i (each such portal is traversed once more on the way).
    # prefix[k] = sum of dp[0..k-1] (mod MOD).
    prefix = [0] * (n + 1)
    answer = (xs[-1] + 1) % MOD
    for i in range(n):
        l = bisect_right(xs, ys[i], 0, i)
        dp = (xs[i] - ys[i] + prefix[i] - prefix[l]) % MOD
        prefix[i + 1] = (prefix[i] + dp) % MOD
        if ss[i]:
            answer = (answer + dp) % MOD

    sys.stdout.write(str(answer % MOD) + "\n")


main()
