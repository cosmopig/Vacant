import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    t = int(data[pos]); pos += 1
    out = []
    for _ in range(t):
        n = int(data[pos]); q = int(data[pos + 1]); pos += 2
        s = data[pos].decode(); pos += 1
        # pre[i] = sum_{j<=i} (-1)^(j-1) * a_j  (1-indexed), a_j = +1 for '+', -1 for '-'
        pre = [0] * (n + 1)
        acc = 0
        for i, ch in enumerate(s):
            v = 1 if ch == '+' else -1
            if i % 2 == 0:
                acc += v
            else:
                acc -= v
            pre[i + 1] = acc
        for _ in range(q):
            l = int(data[pos]); r = int(data[pos + 1]); pos += 2
            length = r - l + 1
            if length % 2 == 1:
                out.append(1)
            elif pre[r] - pre[l - 1] == 0:
                out.append(0)
            else:
                out.append(2)
    sys.stdout.write("\n".join(map(str, out)) + "\n")


main()
