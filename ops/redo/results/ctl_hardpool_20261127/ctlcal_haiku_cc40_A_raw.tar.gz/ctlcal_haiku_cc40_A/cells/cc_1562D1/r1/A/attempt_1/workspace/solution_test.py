"""Tests for solution.py (reads stdin, writes stdout). One test per case; output compared after
whitespace normalisation (whitespace-separated tokens must be equal)."""
import hashlib
import json
import os
import resource
import subprocess
import sys
import unittest

_HERE = os.path.dirname(os.path.abspath(__file__))
_DATA = "cases.json"
_DATA_SHA256 = "aea287e8d2888ed72857658022cc7879c046035dd8f2c8279aa30d67de3c152c"
_LIMIT_S = 6
_N = 30
_state = {"timeouts": 0, "cases": None}


def _cases():
    if _state["cases"] is None:
        raw = open(os.path.join(_HERE, _DATA), "rb").read()
        if hashlib.sha256(raw).hexdigest() != _DATA_SHA256:
            raise AssertionError("data file %s was modified" % _DATA)
        _state["cases"] = json.loads(raw)
    return _state["cases"]


def _limits():
    resource.setrlimit(resource.RLIMIT_AS, (2 << 30, 2 << 30))


def _clip(s, n=240):
    return s if len(s) <= n else s[:n] + "...(%d chars)" % len(s)


def _run_case(tc, i):
    if _state["timeouts"] >= 3:
        tc.fail("skipped: 3 earlier cases timed out in this run")
    case = _cases()[i]
    try:
        p = subprocess.run([sys.executable, "solution.py"], input=case["input"], capture_output=True, text=True,
                           cwd=_HERE, timeout=_LIMIT_S, preexec_fn=_limits)
    except subprocess.TimeoutExpired:
        _state["timeouts"] += 1
        tc.fail("time limit exceeded (%ss) on case %d" % (_LIMIT_S, i))
    if p.returncode != 0:
        tc.fail("runtime error (exit %d) on case %d: %s" % (p.returncode, i, _clip(p.stderr[-400:])))
    if p.stdout.split() != case["output"].split():
        tc.fail("wrong answer on case %d\ninput: %s\nexpected: %s\ngot: %s"
                % (i, _clip(case["input"]), _clip(case["output"]), _clip(p.stdout)))


class SolutionTest(unittest.TestCase):
    pass


def _mk(i):
    def t(self):
        _run_case(self, i)
    return t


for _i in range(_N):
    setattr(SolutionTest, "test_case_%02d" % _i, _mk(_i))

if __name__ == "__main__":
    unittest.main()
