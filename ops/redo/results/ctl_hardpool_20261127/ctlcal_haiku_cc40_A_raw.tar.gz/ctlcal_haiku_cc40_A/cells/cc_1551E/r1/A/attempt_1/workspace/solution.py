import sys


def solve(n, k, a):
    NEG = -1
    # dp[d] = max number of fixed points among processed prefix,
    # having deleted exactly d elements from it (NEG = unreachable).
    dp = [NEG] * (n + 1)
    dp[0] = 0
    for i in range(1, n + 1):
        v = a[i - 1]
        ndp = [NEG] * (n + 1)
        for d in range(i):  # d deletions among first i-1 elements
            cur = dp[d]
            if cur < 0:
                continue
            # Delete element i.
            if cur > ndp[d + 1]:
                ndp[d + 1] = cur
            # Keep element i; its new 1-based index is i - d.
            gain = 1 if v == i - d else 0
            if cur + gain > ndp[d]:
                ndp[d] = cur + gain
        dp = ndp
    for d in range(n + 1):
        if dp[d] >= k:
            return d
    return -1


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    t = int(data[pos]); pos += 1
    out = []
    for _ in range(t):
        n = int(data[pos]); k = int(data[pos + 1]); pos += 2
        a = [int(x) for x in data[pos:pos + n]]
        pos += n
        out.append(str(solve(n, k, a)))
    sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
