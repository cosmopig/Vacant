# Contract

Write your solution to `solution.py` in the root of this workspace. The file exists as an empty stub; replace
its contents with a complete program that reads the input from standard input and prints the answer to
standard output, as the problem statement in `goal.md` describes.

- Put all of your code in `solution.py`. Only use the Python standard library; do not install packages.
- The tests for this task are in `solution_test.py` (with their data in `cases.json`). The tests are correct;
  don't change them or the data. Each test runs `solution.py` on one input and compares the output with the
  expected output after whitespace normalisation. A test fails if the program takes longer than 4 seconds
  on one input. Run them with:

      python3 -m pytest -q solution_test.py

  or, without pytest:

      python3 -m unittest solution_test.py
