import sys


MOD = 998244353


def main():
    data = sys.stdin.read().split()
    n = int(data[0])
    # Each domino is two characters; read them as a stream so any whitespace
    # layout between tokens is accepted.
    chars = ''.join(data[1:])

    # Model each domino (l, r) as a directed edge l -> not(r) on {B, W}.
    # A valid cyclic arrangement is an Eulerian circuit of this multigraph:
    #   #BB == #WW, and if there are no BB/WW edges, the loops must all sit
    #   on one vertex (BW loops at B, WB loops at W cannot be connected).
    # Per domino we track which of the four types are allowed.
    # Categories by (a, b, c) = (BB allowed, WW allowed, #mixed allowed).
    cnt = {}
    prod_c = 1
    prod_bw = 1
    prod_wb = 1
    for i in range(n):
        left = chars[2 * i]
        right = chars[2 * i + 1]
        lo = ('B', 'W') if left == '?' else (left,)
        ro = ('B', 'W') if right == '?' else (right,)
        allowed = {(l, r) for l in lo for r in ro}
        a = 1 if ('B', 'B') in allowed else 0
        b = 1 if ('W', 'W') in allowed else 0
        bw = 1 if ('B', 'W') in allowed else 0
        wb = 1 if ('W', 'B') in allowed else 0
        c = bw + wb
        key = (a, b, c)
        cnt[key] = cnt.get(key, 0) + 1
        prod_c = prod_c * c % MOD
        prod_bw = prod_bw * bw % MOD
        prod_wb = prod_wb * wb % MOD

    Q = cnt.get((1, 1, 2), 0)   # '??'
    A1 = cnt.get((1, 0, 1), 0)  # 'B?' or '?B'
    A0 = cnt.get((1, 0, 0), 0)  # 'BB'
    B1 = cnt.get((0, 1, 1), 0)  # 'W?' or '?W'
    B0 = cnt.get((0, 1, 0), 0)  # 'WW'

    # Balance generating function (BB contributes +1, WW contributes -1):
    # (1+t)^N * t^E, where N = 2Q + A1 + B1 and E = -Q + A0 - B1 - B0.
    N = 2 * Q + A1 + B1
    E = -Q + A0 - B1 - B0
    k = -E  # coefficient of t^0 is C(N, k)

    # Factorials for binomials.
    fact = [1] * (N + 1)
    for i in range(1, N + 1):
        fact[i] = fact[i - 1] * i % MOD
    if 0 <= k <= N:
        balanced = fact[N] * pow(fact[k], MOD - 2, MOD) % MOD * \
            pow(fact[N - k], MOD - 2, MOD) % MOD
    else:
        balanced = 0

    # Remove the disconnected all-mixed assignments that mix BW and WB.
    bad = (prod_c - prod_bw - prod_wb) % MOD
    ans = (balanced - bad) % MOD
    print(ans)


if __name__ == "__main__":
    main()
