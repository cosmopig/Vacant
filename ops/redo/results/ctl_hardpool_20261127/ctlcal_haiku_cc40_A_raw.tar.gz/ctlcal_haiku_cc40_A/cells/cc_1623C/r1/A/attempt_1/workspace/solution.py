import sys


def solve_case(h):
    # h is 0-indexed: h[0] = heap 1, ..., h[n-1] = heap n.
    n = len(h)

    def feasible(m):
        # Every heap i >= 3 must end with at least m stones.
        # d_i = number of units moved from heap i (3*d_i <= stones available).
        # Final heap i = h_i - 3*d_i + d_{i+1} + 2*d_{i+2}.
        # Choosing d_i as large as allowed is optimal, since larger d_{i+1}, d_{i+2}
        # only help the heaps below.
        x = 0  # d_{i+1}
        y = 0  # d_{i+2}
        for i in range(n - 1, 1, -1):
            s = x + 2 * y
            t = h[i] + s - m
            if t < 0:
                return False
            hi_val = h[i]
            c = (hi_val if hi_val < t else t) // 3
            y = x
            x = c
        d3 = x
        d4 = y
        # Heap 1 receives 2*d3; heap 2 receives d3 + 2*d4.
        if h[0] + 2 * d3 < m:
            return False
        if h[1] + d3 + 2 * d4 < m:
            return False
        return True

    lo, hi = 0, h[-1]  # answer is at most the final size of heap n
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if feasible(mid):
            lo = mid
        else:
            hi = mid - 1
    return lo


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    t = int(data[pos])
    pos += 1
    out = []
    for _ in range(t):
        n = int(data[pos])
        pos += 1
        h = [int(v) for v in data[pos:pos + n]]
        pos += n
        out.append(str(solve_case(h)))
    sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
