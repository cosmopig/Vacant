import sys


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    a = [int(x) for x in data[1:1 + n]]
    MOD = 998244353

    # Inclusion-exclusion over adjacent pairs forced to be equal.
    # Answer = sum over partitions of the array into consecutive blocks of
    #   (-1)^(n - #blocks) * prod over blocks of min(a in block).
    # Let dp[i] be the signed sum for prefix of length i, and e_j = (-1)^j dp[j].
    # Then dp[i] = (-1)^(i-1) * sum_{j<i} e_j * min(a[j..i-1]),
    # which is maintained with a monotonic stack of (min value, sum of e_j).
    stack_val = []   # minimum values of segments (actual integers)
    stack_sum = []   # sum of e_j (mod MOD) for j in each segment
    total = 0        # sum_j e_j * min(a[j..i-1]) mod MOD

    e_prev = 1       # e_0 = (-1)^0 * dp[0] = 1
    dp_last = 1
    for i in range(1, n + 1):
        v = a[i - 1]
        s = e_prev
        while stack_val and stack_val[-1] >= v:
            pv = stack_val.pop()
            ps = stack_sum.pop()
            total = (total - ps * pv) % MOD
            s = (s + ps) % MOD
        stack_val.append(v)
        stack_sum.append(s)
        total = (total + s * v) % MOD

        # dp[i] = (-1)^(i-1) * total ; e_i = (-1)^i * dp[i] = -total
        if (i - 1) % 2 == 0:
            dp_last = total
        else:
            dp_last = (-total) % MOD
        e_prev = (-total) % MOD

    print(dp_last % MOD)


if __name__ == "__main__":
    main()
