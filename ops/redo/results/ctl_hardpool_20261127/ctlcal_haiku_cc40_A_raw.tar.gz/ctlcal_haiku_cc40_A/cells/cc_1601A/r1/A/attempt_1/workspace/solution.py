import sys
from math import gcd


def main():
    data = sys.stdin.buffer.read().split()
    t = int(data[0])
    pos = 1
    out = []
    for _ in range(t):
        n = int(data[pos])
        pos += 1
        arr = list(map(int, data[pos:pos + n]))
        pos += n

        # Count, for each bit, how many elements have that bit set.
        g = 0
        for b in range(30):
            c = 0
            for x in arr:
                if (x >> b) & 1:
                    c += 1
            g = gcd(g, c)

        if g == 0:
            # All elements are zero: every k in 1..n works.
            out.append(' '.join(map(str, range(1, n + 1))))
            continue

        # Valid k are exactly the divisors of g (g <= n, so all are <= n).
        divs = []
        d = 1
        while d * d <= g:
            if g % d == 0:
                divs.append(d)
                if d * d != g:
                    divs.append(g // d)
            d += 1
        divs.sort()
        out.append(' '.join(map(str, divs)))

    sys.stdout.write('\n'.join(out) + '\n')


main()
