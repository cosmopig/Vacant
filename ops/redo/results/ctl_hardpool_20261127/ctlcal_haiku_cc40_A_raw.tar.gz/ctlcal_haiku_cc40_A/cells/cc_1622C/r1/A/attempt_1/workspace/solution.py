import sys


def solve(n, k, a):
    total = sum(a)
    need = total - k  # amount the sum must drop by
    if need <= 0:
        return 0
    a.sort(reverse=True)
    lo = a[-1]  # smallest element, used as the copy source
    best = need  # option: only decrement (m = 0 targets)
    prefix = 0  # sum of the top m elements
    for m in range(0, n):
        # m targets (a[0..m-1]) are overwritten by the value x,
        # the smallest element a[n-1] is decremented to x and used as the source.
        if m > 0:
            prefix += a[m - 1]
            cap = a[m - 1]
        else:
            cap = None
        src = lo
        x = (prefix + src - need) // (m + 1)  # largest x that achieves the drop
        if cap is not None and x > cap:
            x = cap
        if x > src:
            x = src
        cost = m + (src - x)
        if cost < best:
            best = cost
    return best


def main():
    data = sys.stdin.buffer.read().split()
    idx = 0
    t = int(data[idx]); idx += 1
    out = []
    for _ in range(t):
        n = int(data[idx]); k = int(data[idx + 1]); idx += 2
        a = [int(x) for x in data[idx:idx + n]]
        idx += n
        out.append(str(solve(n, k, a)))
    sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
