import sys


def count_with_bit(n, b):
    # Count x in [0, n] whose bit b is set.
    if n < 0:
        return 0
    period = 1 << (b + 1)
    half = 1 << b
    full = (n + 1) // period
    rem = (n + 1) % period
    return full * half + max(0, rem - half)


def solve(l, r):
    total = r - l + 1
    best = 0
    for b in range(18):  # 2^18 > 2*10^5
        c = count_with_bit(r, b) - count_with_bit(l - 1, b)
        if c > best:
            best = c
    return total - best


def main():
    data = sys.stdin.read().split()
    t = int(data[0])
    out = []
    idx = 1
    for _ in range(t):
        l = int(data[idx])
        r = int(data[idx + 1])
        idx += 2
        out.append(str(solve(l, r)))
    sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
