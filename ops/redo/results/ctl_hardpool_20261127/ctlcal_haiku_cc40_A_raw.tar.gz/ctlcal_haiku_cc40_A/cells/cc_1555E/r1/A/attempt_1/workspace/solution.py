import sys


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    m = int(data[1])
    L = [0] * n
    R = [0] * n
    W = [0] * n
    idx = 2
    for i in range(n):
        L[i] = int(data[idx])
        R[i] = int(data[idx + 1])
        W[i] = int(data[idx + 2])
        idx += 3

    # Unit edges x (between points x and x+1), 1 <= x <= m-1.
    # Segment [l, r] covers edges l..r-1. Point 1 can reach point m using
    # the chosen segments iff every unit edge is covered by a chosen segment.
    # Stored 0-indexed: segment covers half-open edge range [l-1, r-1).
    E = m - 1
    size = 1
    while size < E:
        size *= 2
    INF = 1 << 60

    # t[node] = min over the node's subtree of covering counts, including
    # all range adds applied at node or below. d[node] = pending add applied
    # to the whole node (already included in t[node]).
    t = [0] * (2 * size)
    for i in range(E, size):
        t[size + i] = INF
    for i in range(size - 1, 0, -1):
        a = t[2 * i]
        b = t[2 * i + 1]
        t[i] = a if a < b else b
    d = [0] * size

    def update(lo, hi, v):
        l = lo + size
        r = hi + size
        l0 = l
        r0 = r - 1
        while l < r:
            if l & 1:
                t[l] += v
                if l < size:
                    d[l] += v
                l += 1
            if r & 1:
                r -= 1
                t[r] += v
                if r < size:
                    d[r] += v
            l >>= 1
            r >>= 1
        i = l0 >> 1
        while i:
            a = t[2 * i]
            b = t[2 * i + 1]
            t[i] = (a if a < b else b) + d[i]
            i >>= 1
        i = r0 >> 1
        while i:
            a = t[2 * i]
            b = t[2 * i + 1]
            t[i] = (a if a < b else b) + d[i]
            i >>= 1

    order = sorted(range(n), key=W.__getitem__)
    ans = None
    hi = 0
    for lo in range(n):
        while hi < n and t[1] <= 0:
            s = order[hi]
            update(L[s] - 1, R[s] - 1, 1)
            hi += 1
        if t[1] <= 0:
            break
        cost = W[order[hi - 1]] - W[order[lo]]
        if ans is None or cost < ans:
            ans = cost
        s = order[lo]
        update(L[s] - 1, R[s] - 1, -1)

    if ans is None:
        ans = 0
    sys.stdout.write(str(ans) + "\n")


main()
