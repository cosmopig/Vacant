import sys


def main():
    data = sys.stdin.read().split()
    t = int(data[0])
    out = []
    idx = 1
    for _ in range(t):
        a = int(data[idx])
        b = int(data[idx + 1])
        idx += 2
        n = a + b
        possible = [False] * (n + 1)
        # Alice serves first: she serves ceil(n/2) games, Borys floor(n/2).
        # Or Borys serves first: the counts are swapped.
        for s_a, s_b in (((n + 1) // 2, n // 2), (n // 2, (n + 1) // 2)):
            # x = number of games Alice wins on Borys's serve (her breaks).
            # Constraints: 0 <= x <= s_b and 0 <= a - x <= s_a.
            lo = max(0, a - s_a)
            hi = min(s_b, a)
            for x in range(lo, hi + 1):
                k = 2 * x + s_a - a
                possible[k] = True
        ks = [k for k in range(n + 1) if possible[k]]
        out.append(str(len(ks)))
        out.append(" ".join(map(str, ks)))
    sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
