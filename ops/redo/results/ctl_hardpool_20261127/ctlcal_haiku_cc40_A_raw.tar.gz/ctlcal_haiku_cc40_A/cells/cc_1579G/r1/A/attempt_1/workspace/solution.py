import sys


def _step(states, x):
    cand = []
    for u, v in states:
        # place the segment to the right of the current end (+x)
        cand.append((u + x, v - x if v >= x else 0))
        # place the segment to the left of the current end (-x)
        cand.append((u - x if u >= x else 0, v + x))
    cand.sort()
    front = []
    best_v = None
    for u, v in cand:
        if best_v is None or v < best_v:
            front.append((u, v))
            best_v = v
    return front


def solve(a):
    # State (u, v): u = current end - left edge of the coverage,
    # v = right edge - current end. The final coverage width is
    # nondecreasing in u and v, and a state's width u + v never decreases
    # along a path, so:
    #   * only Pareto-minimal (u, v) pairs need to be kept;
    #   * any state with width >= a known achievable width can be dropped.
    # A narrow beam search provides such an achievable width (an upper bound).
    beam = [(0, 0)]
    beam_width = 64
    for x in a:
        beam = _step(beam, x)
        if len(beam) > beam_width:
            beam.sort(key=lambda s: s[0] + s[1])
            beam = beam[:beam_width]
    ub = min(u + v for u, v in beam)

    states = [(0, 0)]
    for x in a:
        cand = []
        for u, v in states:
            if u + x + (v - x if v >= x else 0) < ub:
                cand.append((u + x, v - x if v >= x else 0))
            nu = u - x if u >= x else 0
            nw = nu + v + x
            if nw < ub:
                cand.append((nu, v + x))
        cand.sort()
        front = []
        best_v = None
        for u, v in cand:
            if best_v is None or v < best_v:
                front.append((u, v))
                best_v = v
        states = front
        if not states:
            break
    if not states:
        return ub
    return min(ub, min(u + v for u, v in states))


def main():
    data = sys.stdin.buffer.read().split()
    t = int(data[0])
    pos = 1
    out = []
    for _ in range(t):
        n = int(data[pos])
        pos += 1
        a = [int(x) for x in data[pos:pos + n]]
        pos += n
        out.append(str(solve(a)))
    sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
