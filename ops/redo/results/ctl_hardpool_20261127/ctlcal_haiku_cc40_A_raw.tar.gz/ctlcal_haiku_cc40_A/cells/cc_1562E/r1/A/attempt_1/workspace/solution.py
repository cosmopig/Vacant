import sys
from array import array


def solve(n, s):
    # lcp[j] is an array over i: LCP of suffixes s[j:] and s[i:] (i > j).
    # Rows are built from j = n-1 down to 0, since lcp(j, i) depends on lcp(j+1, i+1).
    # Entries with i <= j are never read, so they may hold garbage.
    lcp = [None] * n
    prev = [0] * (n + 1)  # row for j = n (all zeros)
    for j in range(n - 1, -1, -1):
        cj = s[j]
        # cur[i] = prev[i+1] + 1 if s[i] == s[j] else 0
        cur = [p + 1 if x == cj else 0 for p, x in zip(prev[1:], s)]
        cur.append(0)
        lcp[j] = array("H", cur)
        prev = cur

    # Per-letter position lists for the equal-letter transitions.
    positions = {}
    for idx, ch in enumerate(s):
        positions.setdefault(ch, []).append(idx)

    dp = [0] * n
    best = [0] * 26  # best[c] = max dp[j] over processed j with s[j] == letter c
    answer = 0
    for i in range(n):
        c = ord(s[i]) - 97
        base = n - i
        m = 0
        for k in range(c):
            if best[k] > m:
                m = best[k]
        d = base + m
        # Equal starting letter: block j's last string s[j:] must be smaller than
        # the block-i strings taken, so only lengths > l are usable from block i.
        lst = positions[s[i]]
        for j in lst[:lst.index(i)]:
            l = lcp[j][i]
            ii = i + l
            if ii < n and s[j + l] < s[ii]:
                cand = dp[j] + base - l
                if cand > d:
                    d = cand
        dp[i] = d
        if d > best[c]:
            best[c] = d
        if d > answer:
            answer = d
    return answer


def main():
    data = sys.stdin.read().split()
    t = int(data[0])
    pos = 1
    out = []
    for _ in range(t):
        n = int(data[pos])
        s = data[pos + 1]
        pos += 2
        out.append(str(solve(n, s)))
    sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
