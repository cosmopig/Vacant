from typing import List, Dict, Any, Union

def dedupe(records: List[Dict[str, Any]], key: Union[str, List[str]], policy: str = "first") -> List[Dict[str, Any]]:
    if policy not in ("first", "last", "merge"):
        raise ValueError(f"Invalid policy: {policy}")

    keys_to_use = [key] if isinstance(key, str) else key
    
    # To keep track of the first appearance order and unique keys
    seen_keys = {} # maps composite key tuple to index in result list
    result = []

    for record in records:
        # Extract key values
        key_values = []
        for k in keys_to_use:
            if k not in record:
                raise KeyError(k)
            key_values.append(record[k])
        
        composite_key = tuple(key_values)

        if composite_key not in seen_keys:
            # New key found, add to result
            seen_keys[composite_key] = len(result)
            # Copy the record so we don't modify original
            result.append(record.copy())
        else:
            # Duplicate key found, handle based on policy
            idx = seen_keys[composite_key]
            existing_record = result[idx]

            if policy == "first":
                pass # Keep the one already in result
            elif policy == "last":
                result[idx] = record.copy()
            elif policy == "merge":
                # Merge fields: value of last copy that both has the field and whose value is not None
                new_record = existing_record.copy()
                for k, v in record.items():
                    if v is not None:
                        new_record[k] = v
                result[idx] = new_record

    return result
