import re

def slugify(titles: list[str]) -> list[str]:
    def get_base_slug(title: str) -> str:
        # Convert to lowercase
        lower_title = title.lower()
        
        # Keep only letters, digits, and spaces/hyphens
        res = ""
        for char in lower_title:
            if char.isalnum():
                res += char
            elif char == " ":
                res += "-"
            elif char == "-":
                res += "-"
        
        # Collapse multiple hyphens and strip leading/trailing
        res = re.sub(r'-+', '-', res).strip('-')
        
        # If it's still empty (e.g. title was "!!!"), return "a"
        if not res:
            return "a"
        return res

    slugs = []
    seen = set()
    
    for title in titles:
        is_clean_slug = bool(re.match(r"^[a-z0-9]+(?:-[a-z0-9]+)*$", title))
        
        base = get_base_slug(title)
        current_slug = title if is_clean_slug else base
        
        final_slug = current_slug
        counter = 1
        while final_slug in seen:
            suffix = f"-{counter}"
            if is_clean_slug:
                # If the original was a clean slug, we want to keep it as much as possible.
                # But if it's already taken, we append -1, -2 etc.
                final_slug = title + suffix
            else:
                final_slug = base + suffix
            
            # Clean up the new slug (collapse hyphens, strip)
            final_slug = re.sub(r'-+', '-', final_slug).strip('-')
            counter += 1
        
        if not final_slug:
            final_slug = "a"
            
        slugs.append(final_slug)
        seen.add(final_slug)
        
    return slugs

