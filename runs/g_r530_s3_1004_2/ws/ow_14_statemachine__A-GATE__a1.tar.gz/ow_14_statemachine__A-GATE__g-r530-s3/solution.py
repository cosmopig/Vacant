from typing import Dict, List

class Machine:
    def __init__(self, spec: Dict[str, Dict[str, str]], start: str):
        # Validate that all states in the spec exist as keys
        # and that every target state also exists as a key in the spec.
        all_states = set(spec.keys())
        
        if start not in all_states:
            raise ValueError(f"Start state '{start}' is not in spec.")
            
        for state, transitions in spec.items():
            for event, target in transitions.items():
                if target not in all_states:
                    raise ValueError(f"Target state '{target}' for event '{event}' in state '{state}' is not in spec.")

        self._spec = spec
        self._start_state = start
        self._current_state = start
        self._history = [start]

    @property
    def state(self) -> str:
        return self._current_state

    def can(self, event: str) -> bool:
        transitions = self._spec.get(self._current_state, {})
        return event in transitions

    def fire(self, event: str) -> str:
        transitions = self._spec.get(self._current_state, {})
        if event not in transitions:
            raise ValueError(f"Event '{event}' is not valid for state '{self._current_state}'.")
        
        new_state = transitions[event]
        self._current_state = new_state
        self._history.append(new_state)
        return new_state

    def history(self) -> List[str]:
        return list(self._history)

    def reset(self) -> None:
        self._current_state = self._start_state
        self._history = [self._start_state]
