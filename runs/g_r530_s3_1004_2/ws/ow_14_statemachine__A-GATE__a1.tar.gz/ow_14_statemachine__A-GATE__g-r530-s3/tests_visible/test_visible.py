import unittest
from solution import Machine

class TestMachine(unittest.TestCase):
    def test_basic_flow(self):
        spec = {
            "start": {"go": "middle"},
            "middle": {"finish": "end"},
            "end": {}
        }
        m = Machine(spec, "start")
        self.assertEqual(m.state, "start")
        self.assertTrue(m.can("go"))
        self.assertFalse(m.can("finish"))
        
        new_state = m.fire("go")
        self.assertEqual(new_state, "middle")
        self.assertEqual(m.state, "middle")
        self.assertTrue(m.can("finish"))
        
        m.fire("finish")
        self.assertEqual(m.state, "end")
        self.assertEqual(m.history(), ["start", "middle", "end"])

    def test_invalid_transition(self):
        spec = {
            "start": {"go": "middle"},
            "middle": {"finish": "end"},
            "end": {}
        }
        m = Machine(spec, "start")
        with self.assertRaises(ValueError) as cm:
            m.fire("finish")
        self.assertIn("start", str(cm.exception))
        self.assertIn("finish", str(cm.exception))
        self.assertEqual(m.state, "start")

    def test_history_copy(self):
        spec = {
            "start": {"go": "middle"},
            "middle": {"finish": "end"},
            "end": {}
        }
        m = Machine(spec, "start")
        m.fire("go")
        hist = m.history()
        hist.append("fake")
        self.assertEqual(m.history(), ["start", "middle"])

    def test_reset(self):
        spec = {
            "start": {"go": "middle"},
            "middle": {"finish": "end"},
            "end": {}
        }
        m = Machine(spec, "start")
        m.fire("go")
        m.fire("finish")
        m.reset()
        self.assertEqual(m.state, "start")
        self.assertEqual(m.history(), ["start"])

    def test_invalid_initial_state(self):
        spec = {
            "start": {"go": "middle"},
            "middle": {}
        }
        with self.assertRaises(ValueError):
            Machine(spec, "nonexistent")

    def test_invalid_target_state(self):
        spec = {
            "start": {"go": "missing"},
            "missing": {} # Wait, if missing is a key it's valid. 
                           # If it's NOT a key, it should fail.
        }
        # Let's try one where target is truly missing from keys
        spec2 = {
            "start": {"go": "missing"},
            "middle": {}
        }
        with self.assertRaises(ValueError):
            Machine(spec2, "start")

if __name__ == "__main__":
    unittest.main()
