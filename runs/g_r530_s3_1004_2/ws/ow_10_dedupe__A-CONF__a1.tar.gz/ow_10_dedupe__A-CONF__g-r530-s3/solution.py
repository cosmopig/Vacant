from typing import List, Dict, Any, Union

def dedupe(records: List[Dict[str, Any]], key: Union[str, List[str]], policy: str = "first") -> List[Dict[str, Any]]:
    if policy not in ("first", "last", "merge"):
        raise ValueError(f"Invalid policy: {policy}")

    # Normalize key to a list of strings
    keys = [key] if isinstance(key, str) else key
    
    seen_keys = {}  # maps tuple of values -> index in result list
    result = []

    for record in records:
        # Extract the composite key value
        key_values = []
        for k in keys:
            if k not in record:
                raise KeyError(k)
            val = record[k]
            key_values.append(val)
        key_tuple = tuple(key_values)

        if key_tuple not in seen_keys:
            seen_keys[key_tuple] = len(result)
            # We need to store a copy of the record so we don't modify inputs
            result.append(record.copy())
        else:
            idx = seen_keys[key_tuple]
            current_record = result[idx]

            if policy == "first":
                pass  # Keep the first one already in result
            elif policy == "last":
                result[idx] = record.copy()
            elif policy == "merge":
                # Merge fields from current record and new record
                # The rule is: field by field, the value of the last copy that both has the field and whose value is not None.
                for k, v in record.items():
                    if v is not None:
                        current_record[k] = v
    
    return result

