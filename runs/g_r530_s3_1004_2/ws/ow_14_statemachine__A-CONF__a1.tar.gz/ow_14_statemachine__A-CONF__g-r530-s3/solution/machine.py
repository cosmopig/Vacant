from typing import Dict, List

class Machine:
    def __init__(self, spec: Dict[str, Dict[str, str]], start: str):
        # Validate that all states in the spec are known and reachable
        all_states = set(spec.keys())
        if start not in all_states:
            raise ValueError(f"Starting state '{start}' is not in spec.")
        
        for state, transitions in spec.items():
            for event, target in transitions.items():
                if target not in all_states:
                    raise ValueError(f"Event '{event}' in state '{state}' leads to unknown state '{target}'.")

        self._spec = spec
        self._start_state = start
        self._current_state = start
        self._history = [start]

    @property
    def state(self) -> str:
        return self._current_state

    def can(self, event: str) -> bool:
        transitions = self._spec.get(self._current_state, {})
        return event in transitions

    def fire(self, event: str) -> str:
        if not self.can(event):
            raise ValueError(f"Cannot perform '{event}' in state '{self._current_state}'")
        
        next_state = self._spec[self._current_state][event]
        self._current_state = next_state
        self._history.append(next_state)
        return next_state

    def history(self) -> List[str]:
        return list(self._history)

    def reset(self) -> None:
        self._current_state = self._start_state
        self._history = [self._start_state]
