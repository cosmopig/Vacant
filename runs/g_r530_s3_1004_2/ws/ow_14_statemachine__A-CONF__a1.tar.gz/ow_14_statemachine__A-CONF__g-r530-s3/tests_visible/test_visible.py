from solution.machine import Machine

def test_basic():
    spec = {
        "start": {"go": "middle"},
        "middle": {"end": "finish", "back": "start"},
        "finish": {}
    }
    m = Machine(spec, "start")
    assert m.state == "start"
    assert m.can("go") is True
    assert m.can("end") is False
    assert m.fire("go") == "middle"
    assert m.state == "middle"
    assert m.history() == ["start", "middle"]
    m.fire("back")
    assert m.state == "start"
    assert m.history() == ["start", "middle", "start"]

def test_reset():
    spec = {
        "start": {"go": "middle"},
        "middle": {},
    }
    m = Machine(spec, "start")
    m.fire("go")
    m.reset()
    assert m.state == "start"
    assert m.history() == ["start"]

def test_invalid_transitions():
    spec = {
        "start": {"go": "middle"},
        "middle": {},
    }
    m = Machine(spec, "start")
    try:
        m.fire("jump")
    except ValueError as e:
        assert str(e) == "Cannot perform 'jump' in state 'start'"

def test_invalid_init():
    spec1 = {"a": {"b": "c"}} # c is missing
    try:
        Machine(spec1, "a")
    except ValueError:
        pass
    else:
        raise AssertionError("Should have raised ValueError for missing state 'c'")

    spec2 = {"a": {"b": "b"}, "b": {}}
    try:
        Machine(spec2, "c") # c is missing
    except ValueError:
        pass
    else:
        raise AssertionError("Should have raised ValueError for missing start state 'c'")

if __name__ == "__main__":
    test_basic()
    test_reset()
    test_invalid_transitions()
    test_invalid_init()
    print("All tests passed!")
