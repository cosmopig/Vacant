import re

def slugify(titles: list[str]) -> list[str]:
    # Regex for a valid slug as per requirements:
    # lowercase letters, digits and hyphens, never starts or ends with hyphen, 
    # no two hyphens in a row.
    slug_pattern = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")

    def get_base_slug(title: str) -> str:
        # Step 1: Convert to lowercase and replace non-alphanumeric with hyphens
        # But we want to preserve existing hyphens too.
        # Actually, the goal says "lowercase letters, digits and hyphens".
        # So anything else should probably be removed or replaced by a hyphen.
        
        # First, let's replace everything that is not a letter, digit, space, underscore, or hyphen with nothing.
        # Then replace spaces and underscores with hyphens.
        res = ""
        for char in title:
            if char.isalnum():
                res += char.lower()
            elif char == " " or char == "_":
                res += "-"
            elif char == "-":
                res += "-"
            else:
                # Other characters like punctuation are ignored/removed
                pass
        
        # Step 2: Collapse multiple hyphens into one
        res = re.sub(r'-+', '-', res)
        # Step 3: Trim hyphens from start and end
        res = res.strip('-')
        
        # Requirement: "a title written in a script with no Latin letters... still gets a usable slug"
        # Requirement: "so does a title with nothing usable in it at all -- one that is only punctuation"
        if not res:
            return "x"
        return res

    results = []
    used_slugs = set()
    
    for title in titles:
        # Check if the original title is already a clean slug.
        # If it is, we use it as our base.
        if slug_pattern.match(title):
            base = title
        else:
            base = get_base_slug(title)
        
        # Collision resolution
        final_slug = base
        counter = 1
        while final_slug in used_slugs:
            # If the base is "x" (from a non-latin title), we want to avoid "x-1", "x-2" etc.
            # if possible, but it's a safe way to handle collisions.
            # However, if base was already something like "my-post", 
            # then "my-post-1" is a valid slug.
            
            # Special case: if the base itself is just a digit or letter, we still want hyphens.
            # The requirement says no two hyphens in a row and no start/end hyphen.
            # Since base is already clean (or "x"), adding "-1" will be clean.
            final_slug = f"{base}-{counter}"
            
        results.append(final_slug)
        used_slugs.add(final_slug)
        
    return results

