class Machine:
    def __init__(self, spec: dict[str, dict[str, str]], start: str):
        if start not in spec:
            raise ValueError(f"Start state {start} not in spec")
        for state, events in spec.items():
            for event, target in events.items():
                if target not in spec:
                    raise ValueError(f"Target state {target} for event {event} in state {state} not in spec")
        
        self._spec = spec
        self._start_state = start
        self._current_state = start
        self._history = [start]

    @property
    def state(self) -> str:
        return self._current_state

    def can(self, event: str) -> bool:
        return event in self._spec[self._current_state]

    def fire(self, event: str) -> str:
        if not self.can(event):
            raise ValueError(f"Invalid transition from {self._current_state} via {event}")
        self._current_state = self._spec[self._current_state][event]
        self._history.append(self._current_state)
        return self._current_state

    def history(self) -> list[str]:
        return list(self._history)

    def reset(self) -> None:
        self._current_state = self._start_state
        self._history = [self._start_state]
