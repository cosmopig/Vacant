from typing import List, Dict

def diff(old: List[str], new: List[str]) -> List[Dict]:
    n = len(old)
    m = len(new)
    
    # dp[i][j] is the length of LCS of old[:i] and new[:j]
    dp = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(n):
        for j in range(m):
            if old[i] == new[j]:
                dp[i+1][j+1] = dp[i][j] + 1
            else:
                dp[i+1][j+1] = max(dp[i][j], dp[i+1][j])
    
    # Backtrack to find LCS indices
    lcs_old_indices = []
    lcs_new_indices = []
    i, j = n, m
    while i > 0 and j > 0:
        if old[i-1] == new[j-1]:
            lcs_old_indices.append(i-1)
            lcs_new_indices.append(j-1)
            i -= 1
            j -= 1
        elif dp[i][j] == dp[i][j-1]:
            j -= 1
        else:
            i -= 1
    lcs_old_indices.reverse()
    lcs_new_indices.reverse()

    pieces = []
    if not lcs_old_indices:
        pieces.append({'start': 0, 'old': old[:n], 'new': new[:m]})
    else:
        # First gap
        s_old, e_old = 0, lcs_old_indices[0]
        s_new, e_new = 0, lcs_new_indices[0]
        if s_old != e_old or s_new != e_new:
            pieces.append({'start': s_old, 'old': old[s_old:e_old], 'new': new[s_new:e_new]})
        
        # Middle gaps
        for k in range(len(lcs_old_indices) - 1):
            s_old = lcs_old_indices[k] + 1
            e_old = lcs_old_indices[k+1]
            s_new = lcs_new_indices[k] + 1
            e_new = lcs_new_indices[k+1]
            if s_old != e_old or s_new != e_new:
                pieces.append({'start': s_old, 'old': old[s_old:e_old], 'new': new[s_new:e_new]})
        
        # Last gap
        s_old = lcs_old_indices[-1] + 1
        e_old = n
        s_new = lcs_new_indices[-1] + 1
        e_new = m
        if s_old != e_old or s_new != e_new:
            pieces.append({'start': s_old, 'old': old[s_old:e_old], 'new': new[s_new:e_new]})

    # Merge adjacent pieces that are not separated by an unchanged line.
    # In the LCS approach, gaps are separated by lcs lines (which are unchanged).
    # However, we need to ensure there is at least one unchanged line between them.
    # If two gaps were adjacent, they would have been merged into one piece in our logic 
    # because we only create pieces from the "gaps" between LCS indices.
    # But wait, if a gap is empty (s_old == e_old and s_new == e_new), it's not added.
    # If two gaps are adjacent, they would be separated by an lcs line.
    # The only case where they might not be separated is at the very beginning or end.
    # But our logic handles that: Gap -1 and Gap 0 are separated by lcs_old_indices[0].
    # If there's no lcs_old_indices, we have one piece for everything.

    return pieces

def apply(old: List[str], hunks: List[Dict]) -> List[str]:
    for hunk in hunks:
        if not isinstance(hunk, dict) or len(hunk) != 3 or \
           set(hunk.keys()) != {'start', 'old', 'new'}:
            raise ValueError("Malformed hunk")
        
        start = hunk['start']
        if start < 0 or start > len(old):
            raise ValueError("Start out of bounds")
        
        if old[start : start + len(hunk['old'])] != hunk['old']:
            raise ValueError("Old lines do not match")
            
    current_end = -1
    for hunk in hunks:
        start = hunk['start']
        old_len = len(hunk['old'])
        if start < current_end: # Overlap or out of order
            raise ValueError("Pieces overlap or are out of order")
        current_end = start + old_len

    for hunk in hunks:
        start = hunk['start']
        if start + len(hunk['old']) > len(old):
            raise ValueError("Old lines reach past end")

    for hunk in hunks:
        if not hunk['old'] and not hunk['new']:
            raise ValueError("Piece is empty on both sides")

    res = []
    last_old_idx = 0
    for hunk in hunks:
        start = hunk['start']
        res.extend(old[last_old_idx : start])
        res.extend(hunk['new'])
        last_old_idx = start + len(hunk['old'])
    
    res.extend(old[last_old_idx:])
    return res
