import unittest

def diff(old, new):
    # To be implemented
    pass

def apply(old, hunks):
    # To be implemented
    pass

class TestDiffApply(unittest.TestCase):
    def test_basic_diff_apply(self):
        old = ["line1", "line2", "line3"]
        new = ["line1", "changed", "line3"]
        hunks = diff(old, new)
        self.assertEqual(apply(old, hunks), new)

    def test_multiple_changes(self):
        old = ["a", "b", "c", "d", "e"]
        new = ["a", "x", "c", "y", "e"]
        hunks = diff(old, new)
        self.assertEqual(apply(old, hunks), new)

    def test_insertion(self):
        old = ["a", "b"]
        new = ["a", "insert", "b"]
        hunks = diff(old, new)
        self.assertEqual(apply(old, hunks), new)

    def test_deletion(self):
        old = ["a", "b", "c"]
        new = ["a", "c"]
        hunks = diff(old, new)
        self.assertEqual(apply(old, hunks), new)

    def test_no_change(self):
        old = ["a", "b", "c"]
        new = ["a", "b", "c"]
        hunks = diff(old, new)
        self.assertEqual(hunks, [])
        self.assertEqual(apply(old, hunks), new)

    def test_empty_lists(self):
        old = []
        new = ["a"]
        hunks = diff(old, new)
        self.assertEqual(apply(old, hunks), new)
        
        old2 = []
        new2 = []
        hunks2 = diff(old2, new2)
        self.assertEqual(hunks2, [])
        self.assertEqual(apply(old2, hunks2), new2)

    def test_adjacent_changes_separated(self):
        # The contract says: "at least one unchanged line between the end of one piece and the start of the next"
        # This means if we have two changes separated by only 0 lines, it's not a valid diff output.
        # Wait, "at least one unchanged line between...". Let me re-read.
        # "diff returns the pieces ordered by start, with at least one unchanged line between the end of one piece and the start of the next"
        old = ["a", "b", "c", "d"]
        new = ["x", "y", "z", "w"]
        # If we just replaced everything, it's one piece.
        hunks = diff(old, new)
        self.assertEqual(len(hunks), 1)

    def test_no_redundant_boundaries(self):
        # "no piece beginning or ending with a line that is the same on both of its sides"
        # If old = ["a", "b", "c"] and new = ["a", "x", "c"], 
        # the hunk should be start=1, old=["b"], new=["x"].
        # If it was start=0, old=["a", "b"], new=["a", "x"], that's invalid because 'a' is same on both sides.
        old = ["a", "b", "c"]
        new = ["a", "x", "c"]
        hunks = diff(old, new)
        self.assertEqual(len(hunks), 1)
        self.assertEqual(hunks[0]['start'], 1)
        self.assertEqual(hunks[0]['old'], ["b"])
        self.assertEqual(hunks[0]['new'], ["x"])

    def test_apply_errors(self):
        # Piece's old is not what the old list holds at start
        with self.assertRaises(ValueError):
            apply(["a", "b"], [{"start": 0, "old": ["z"], "new": ["x"]}])
        
        # Pieces are out of order
        with self.assertRaises(ValueError):
            apply(["a", "b", "c", "d"], [{"start": 2, "old": ["c"], "new": ["x"]}, {"start": 0, "old": ["a"], "new": ["y"]}])

        # Overlap
        with self.assertRaises(ValueError):
            apply(["a", "b", "c", "d"], [{"start": 0, "old": ["a", "b"], "new": ["x"]}, {"start": 1, "old": ["b", "c"], "new": ["y"]}])

        # Reach past the end
        with self.assertRaises(ValueError):
            apply(["a", "b"], [{"start": 2, "old": [], "new": ["x"]}]) # Wait, old cannot be empty if new is not? No, start=2 is out of bounds.
            # Actually, start=2 for a list of length 2 is past the end.
        
        # Piece reaches past the end (start + len(old) > len(old))
        with self.assertRaises(ValueError):
            apply(["a", "b"], [{"start": 1, "old": ["b", "c"], "new": ["x"]}])

        # Empty on both sides
        with self.assertRaises(ValueError):
            apply(["a"], [{"start": 0, "old": ["a"], "new": []}]) # This is valid? No, wait.
            # "Either side may be empty, but not both."
            # A piece has 'old' and 'new'. If both are empty, it's invalid.
            # But if old is ["a"] and new is [], that's a deletion. That's fine.
            # The rule says "Either side may be empty, but not both." 
            # This refers to the piece itself? No, "A piece must not carry lines that did not change: not at its start, not at its end."
            # Let's re-read carefully.
            # "A piece is a dict with exactly the keys `start`, `old` and `new`. ... Either side may be empty, but not both."
            # This means (len(old) > 0 or len(new) > 0) must be true.
            # Wait, if old = ["a"] and new = [], then one side is empty, one is not. That's fine.
            # If old = [] and new = ["a"], that's also fine.
            # "not both" means we can't have old = [] AND new = [].

        with self.assertRaises(ValueError):
            apply(["a"], [{"start": 0, "old": [], "new": []}])

        # Not a dict with exactly those three keys
        with self.assertRaises(ValueError):
            apply(["a"], [{"start": 0, "old": ["a"], "new": ["x"], "extra": 1}])
        with self.assertRaises(ValueError):
            apply(["a"], [{"start": 0, "old": ["a"]}])

    def test_complex_diff(self):
        old = ["line1", "line2", "line3", "line4", "line5"]
        new = ["line1", "changed2", "line3", "removed4", "line5"]
        # Wait, if line4 is removed, the diff should be:
        # hunk 1: start=1, old=["line2"], new=["changed2"]
        # hunk 2: start=3, old=["line4"], new=[]
        hunks = diff(old, new)
        self.assertEqual(apply(old, hunks), new)

if __name__ == "__main__":
    unittest.main()
