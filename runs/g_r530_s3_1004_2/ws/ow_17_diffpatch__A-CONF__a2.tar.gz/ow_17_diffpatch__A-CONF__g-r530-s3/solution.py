def diff(old: list[str], new: list[str]) -> list[dict]:
    n_old = len(old)
    n_new = len(new)

    dp = [[0] * (n_new + 1) for _ in range(n_old + 1)]
    for i in range(n_old + 1):
        for j in range(n_new + 1):
            if i == 0 or j == 0:
                dp[i][j] = 0
            elif old[i-1] == new[j-1]:
                dp[i][j] = dp[i-1][j-1] + 1
            else:
                dp[i][j] = max(dp[i-1][j], dp[i][j-1])

    lcs_indices = []
    i, j = n_old, n_new
    while i > 0 or j > 0:
        if i > 0 and j > 0 and old[i-1] == new[j-1]:
            lcs_indices.append((i-1, j-1))
            i -= 1
            j -= 1
        elif i > 0 and (j == 0 or dp[i][j] == dp[i-1][j]):
            i -= 1
        else:
            j -= 1
    lcs_indices.reverse()

    deleted_old = [idx for idx in range(n_old) if idx not in [x[0] for x in lcs_indices]]
    inserted_new = [idx for idx in range(n_new) if idx not in [x[1] for x in lcs_indices]]

    hunks = []
    if not lcs_indices:
        # If everything is different, we need to be careful about the "no redundant boundaries" rule.
        # But since nothing is same on both sides, one big hunk should work.
        hunks.append({'start': 0, 'old': old, 'new': new})
    else:
        # Gap 0
        hunk_old = [idx for idx in deleted_old if idx < lcs_indices[0][0]]
        hunk_new = [idx for idx in inserted_new if idx < lcs_indices[0][1]]
        if hunk_old or hunk_new:
            # The start of the hunk must be such that old[start-1] != new[j-1].
            # If we have a deletion at 'prev_old + 1', then start = prev_old + 1.
            hunks.append({'start': 0, 'old': [old[idx] for idx in hunk_old], 'new': [new[idx] for idx in hunk_new]})

        # Gaps k
        for k in range(1, len(lcs_indices)):
            prev_old = lcs_indices[k-1][0]
            curr_old = lcs_indices[k][0]
            prev_new = lcs_indices[k-1][1]
            curr_new = lcs_indices[k][1]
            
            hunk_old = [idx for idx in deleted_old if prev_old < idx < curr_old]
            hunk_new = [idx for idx in inserted_new if prev_new < idx < curr_new]
            if hunk_old or hunk_new:
                # The start of the hunk must be such that old[start-1] != new[j-1].
                # If we have a deletion at 'prev_old + 1', then start = prev_old + 1.
                hunks.append({'start': prev_old + 1, 'old': [old[idx] for idx in hunk_old], 'new': [new[idx] for idx in hunk_new]})

        # Gap last
        hunk_old = [idx for idx in deleted_old if idx > lcs_indices[-1][0]]
        hunk_new = [idx for idx in inserted_new if idx > lcs_indices[-1][1]]
        if hunk_old or hunk_new:
            hunks.append({'start': lcs_indices[-1][0] + 1, 'old': [old[idx] for idx in hunk_old], 'new': [new[idx] for idx in hunk_new]})

    # Merge adjacent hunks that are not separated by an unchanged line.
    # In our case, every gap is separated by at least one lcs_index (an unchanged line).
    # So we don't need to merge anything unless a gap has no deleted old indices AND no inserted new indices? 
    # No, those wouldn't be added as hunks anyway.

    return hunks

def apply(old: list[str], hunks: list[dict]) -> list[str]:
    if not isinstance(hunks, list):
        raise ValueError("Hunks must be a list")
    for hunk in hunks:
        if not isinstance(hunk, dict) or set(hunk.keys()) != {"start", "old", "new"}:
            raise ValueError("Each hunk must be a dict with exactly 'start', 'old', and 'new' keys")
        if not (len(hunk["old"]) > 0 or len(hunk["new"]) > 0):
            raise ValueError("A piece must have either 'old' or 'new' non-empty")

    last_end = -1
    for hunk in hunks:
        start = hunk["start"]
        old_part = hunk["old"]
        new_part = hunk["new"]
        
        if start < last_end:
            raise ValueError("Pieces are out of order or overlap")
        if last_end != -1 and start < last_end + 1:
            # The contract says "at least one unchanged line between the end of one piece and the start of the next"
            # This means if there's no line in 'old' between them, it's invalid.
            raise ValueError("At least one unchanged line between pieces")

        if start < 0 or start > len(old):
            raise ValueError("Start index out of bounds")
        if start + len(old_part) > len(old):
            raise ValueError("Piece reaches past the end of the old list")
        if old[start : start + len(old_part)] != old_part:
            raise ValueError("Piece's old is not what the old list holds at start")
        last_end = start + len(old_part)

    res = []
    curr_old_idx = 0
    for hunk in hunks:
        start = hunk["start"]
        new_part = hunk["new"]
        res.extend(old[curr_old_idx : start])
        res.extend(new_part)
        curr_old_idx = start + len(hunk["old"])
    res.extend(old[curr_old_idx:])
    return res

# Let's fix the diff function to handle the "no redundant boundaries" more carefully.
