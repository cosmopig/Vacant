import re

def slugify(titles: list[str]) -> list[str]:
    slug_regex = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
    
    candidates = []
    for title in titles:
        if slug_regex.match(title):
            candidates.append(title)
        else:
            # Extract all sequences of latin letters and digits
            words = re.findall(r'[a-z0-9]+', title.lower())
            if not words:
                base = "title"
            else:
                base = "-".join(words)
            
            # Clean up the base slug (no double hyphens, no leading/trailing hyphens)
            base = re.sub(r'-+', '-', base).strip('-')
            if not base:
                base = "title"
            candidates.append(base)

    results = []
    used_slugs = set()
    
    for cand in candidates:
        slug = cand
        counter = 1
        while slug in used_slugs:
            # We need to ensure the new slug is valid.
            # If 'cand' ends with a hyphen, we should be careful.
            # But our construction ensures it doesn't.
            suffix = f"-{counter}"
            new_slug = cand + suffix
            if slug_regex.match(new_slug):
                slug = new_slug
            else:
                # This handles cases where 'cand' might end in a hyphen 
                # (though our logic currently prevents this).
                slug = f"{cand.rstrip('-')}-{counter}"
            counter += 1
        
        results.append(slug)
        used_slugs.add(slug)
        
    return results
