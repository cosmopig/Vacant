import unittest
import re
import solution

class TestSlugify(unittest.TestCase):
    def test_v01_one_slug_per_title(self):
        """Visible check 1: order kept, and an ordinary title becomes an ordinary slug."""
        SLUG = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
        titles = ["Hello, World!", "Second Post", "Third"]
        got = solution.slugify(titles)
        self.assertEqual(len(got), len(titles))
        self.assertEqual(got[0], "hello-world")
        for slug in got:
            self.assertTrue(SLUG.match(slug))

    def test_v02_already_a_slug(self):
        """Visible check 2: a title that is already a clean slug is left alone."""
        titles = ["already-a-slug", "another-one", "third-thing"]
        got = solution.slugify(titles)
        self.assertEqual(got, titles)

if __name__ == "__main__":
    unittest.main()
