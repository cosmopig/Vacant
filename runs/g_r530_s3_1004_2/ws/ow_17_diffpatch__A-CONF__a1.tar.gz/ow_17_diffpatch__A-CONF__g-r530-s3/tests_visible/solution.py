from typing import List, Dict
import difflib

def diff(old: List[str], new: List[str]) -> List[Dict]:
    s = difflib.SequenceMatcher(None, old, new)
    opcodes = s.get_opcodes()
    hunks = []
    i = 0
    while i < len(opcodes):
        tag, i1, i2, j1, j2 = opcodes[i]
        if tag == 'equal':
            i += 1
            continue
        
        # Group consecutive changes into a single hunk if they are adjacent in the old list.
        start_i = i1
        end_i = i2
        start_j = j1
        end_j = j2
        
        curr_i = i + 1
        while curr_i < len(opcodes):
            t, ni1, ni2, nj1, nj2 = opcodes[curr_i]
            if t != 'equal' and ni1 == end_i:
                end_i = ni2
                end_j = nj2
            else:
                break
            curr_i += 1
        
        h_i1, h_i2 = start_i, end_i
        h_j1, h_j2 = start_j, end_j
        
        # Shrink from left: if old[i1-1] == new[j1-1], then it's an unchanged line.
        while h_i1 > 0 and h_j1 > 0 and old[h_i1-1] == new[h_j1-1]:
            h_i1 += 1
            h_j1 += 1
        # Shrink from right: if old[i2] == new[j2], then it's an unchanged line.
        while h_i2 < len(old) and h_j2 < len(new) and old[h_i2] == new[h_j2]:
            h_i2 -= 1
            h_j2 -= 1
            
        # The hunk must not be empty on both sides.
        if h_i1 < h_i2 or h_j1 < h_j2:
            hunks.append({'start': h_i1, 'old': old[h_i1:h_i2], 'new': new[h_j1:h_j2]})
        
        i = curr_i

    return hunks

def apply(old: List[str], hunks: List[Dict]) -> List[str]:
    if not isinstance(hunks, list): raise ValueError()
    
    last_pos = 0
    for hunk in hunks:
        if not isinstance(hunk, dict) or set(hunk.keys()) != {'start', 'old', 'new'}:
            raise ValueError("Hunk must be a dict with keys 'start', 'old', and 'new'")
        
        start = hunk['start']
        old_part = hunk['old']
        new_part = hunk['new']
        
        if start < last_pos:
            raise ValueError("Pieces are out of order or overlap")
        
        if start + len(old_part) > len(old):
            raise ValueError("Piece reaches past the end of the old list")
            
        if old[start : start + len(old_part)] != old_part:
            raise ValueError("Old part does not match")
            
        if len(old_part) == 0 and len(new_part) == 0:
            raise ValueError("Piece is empty on both sides")

        last_pos = start + len(old_part)
    
    result = []
    curr_old_idx = 0
    for hunk in hunks:
        start = hunk['start']
        new_part = hunk['new']
        
        # Add unchanged lines before the hunk
        result.extend(old[curr_old_idx : start])
        # Add new lines from the hunk
        result.extend(new_part)
        # Update current old index
        curr_old_idx = start + len(hunk['old'])
    
    # Add remaining lines
    result.extend(old[curr_old_idx:])
    return result
