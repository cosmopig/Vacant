import unittest
from solution import diff, apply

class TestSolution(unittest.TestCase):
    def test_basic_diff_and_apply(self):
        old = ["line1", "line2", "line3"]
        new = ["line1", "changed", "line3"]
        hunks = diff(old, new)
        self.assertEqual(len(hunks), 1)
        self.assertEqual(hunks[0]['start'], 1)
        self.assertEqual(hunks[0]['old'], ["line2"])
        self.assertEqual(hunks[0]['new'], ["changed"])
        self.assertEqual(apply(old, hunks), new)

    def test_multiple_changes(self):
        old = ["a", "b", "c", "d", "e"]
        new = ["a", "x", "c", "y", "e"]
        hunks = diff(old, new)
        # Should have two hunks because they are separated by 'c'
        self.assertEqual(len(hunks), 2)
        self.assertEqual(apply(old, hunks), new)

    def test_adjacent_changes_grouped(self):
        old = ["a", "b", "c"]
        new = ["x", "y", "z"]
        hunks = diff(old, new)
        # Should be one hunk because they are adjacent and no unchanged line between them
        self.assertEqual(len(hunks), 1)
        self.assertEqual(apply(old, hunks), new)

    def test_no_change(self):
        old = ["a", "b", "c"]
        new = ["a", "b", "c"]
        hunks = diff(old, new)
        self.assertEqual(len(hunks), 0)
        self.assertEqual(apply(old, hunks), new)

    def test_shrink_left(self):
        # old[0] == new[0], so the hunk should not start at 0
        # If we replace ["a", "b"] with ["a", "x"], it should be just replacing ["b"] with ["x"]
        old = ["a", "b"]
        new = ["a", "x"]
        hunks = diff(old, new)
        self.assertEqual(hunks[0]['start'], 1)
        self.assertEqual(hunks[0]['old'], ["b"])
        self.assertEqual(hunks[0]['new'], ["x"])

    def test_shrink_right(self):
        # old[2] == new[2], so the hunk should not end at 2
        # If we replace ["b", "c"] with ["y", "c"], it should be just replacing ["b"] with ["y"]
        old = ["a", "b", "c"]
        new = ["a", "y", "c"]
        hunks = diff(old, new)
        self.assertEqual(hunks[0]['start'], 1)
        self.assertEqual(hunks[0]['old'], ["b"])
        self.assertEqual(hunks[0]['new'], ["y"])

    def test_apply_errors(self):
        old = ["a", "b", "c"]
        # Wrong old part
        with self.assertRaises(ValueError):
            apply(old, [{'start': 1, 'old': ["x"], 'new': ["y"]}])
        # Out of order
        with self.assertRaises(ValueError):
            apply(old, [{'start': 2, 'old': ["c"], 'new': ["z"]}, {'start': 0, 'old': ["a"], 'new': ["w"]}])
        # Overlap
        with self.assertRaises(ValueError):
            apply(old, [{'start': 0, 'old': ["a", "b"], 'new': ["x"]}, {'start': 1, 'old': ["b"], 'new': ["y"]}])
        # Past end
        with self.assertRaises(ValueError):
            apply(old, [{'start': 2, 'old': ["c", "d"], 'new': ["z"]}])
        # Empty both sides
        with self.assertRaises(ValueError):
            apply(old, [{'start': 1, 'old': [], 'new': []}])
        # Malformed hunk
        with self.assertRaises(ValueError):
            apply(old, [{'start': 1, 'wrong_key': []}])

    def test_complex_diff(self):
        old = ["line1", "line2", "line3", "line4", "line5"]
        new = ["line1", "changed2", "line3", "changed4", "line5", "line6"]
        hunks = diff(old, new)
        # Hunk 1: replace line2 with changed2
        # Hunk 2: replace line4 with changed4
        # Hunk 3: insert line6 at the end (replace empty with line6)
        self.assertEqual(len(hunks), 3)
        self.assertEqual(apply(old, hunks), new)

if __name__ == "__main__":
    unittest.main()
