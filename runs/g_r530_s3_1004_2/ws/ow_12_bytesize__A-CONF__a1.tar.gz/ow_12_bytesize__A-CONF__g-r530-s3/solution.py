import re

class Solution:
    def to_bytes(self, s: str) -> int:
        s = s.strip()
        if not s:
            raise ValueError("Empty string")
        
        match = re.fullmatch(r"(\d+(?:\.\d+)?)\s*([a-zA-Z]*)", s)
        if not match:
            raise ValueError("Invalid format")
        
        num_str, unit_str = match.groups()
        val = float(num_str)

        if '-' in s or '+' in s:
            # The prompt says "a negative size". Let's check if it starts with '-'.
            if s.strip().startswith('-'):
                raise ValueError("Negative size")

        unit_str = unit_str.upper()
        binary_units = {"KIB": 1024, "MIB": 1024**2, "GIB": 1024**3, "TIB": 1024**4}
        decimal_units = {"KB": 1000, "MB": 1000**2, "GB": 1000**3, "TB": 1000**4}
        
        if not unit_str or unit_str == "B":
            return int(val)
        
        if unit_str in binary_units:
            step = binary_units[unit_str]
        elif unit_str in decimal_units:
            step = decimal_units[unit_str]
        else:
            raise ValueError("Unrecognized unit")

        return int(val * step)

    def humanize(self, n: int, *, binary: bool = True) -> str:
        if n < 0:
            raise ValueError("Negative size")
        
        step_base = 1024 if binary else 1000
        if n < step_base:
            return f"{n} B"
        
        # Units are ordered by magnitude.
        if binary:
            units = [("TiB", 1024**4), ("GiB", 1024**3), ("MiB", 1024**2), ("KiB", 1024)]
        else:
            units = [("TB", 1000**4), ("GB", 1000**3), ("MB", 1000**2), ("KB", 1000)]

        # "The unit chosen is the largest one that leaves the number below the step"
        # Let's re-read: "the largest one that leaves the number below the step".
        # If n = 1,500,000 and binary=False (step_base=1000):
        # TB (10^12): next is inf. Is 1,500,000 < inf? Yes.
        # GB (10^9): next is 10^12. Is 1,500,000 < 10^12? Yes.
        # MB (10^6): next is 10^9. Is 1,500,000 < 10^9? Yes.
        # KB (10^3): next is 10^6. Is 1,500,000 < 10^6? No!
        # So the largest one that leaves it below its NEXT unit's step is MB.
        # Let's try this logic: find the largest unit such that n < (step of next unit).

        best_unit = None
        best_step = 1
        
        # We need to know what "the step" means. If it refers to the NEXT unit's step...
        # Let's try this:
        for i, (name, step) in enumerate(units):
            next_step = units[i+1][1] if i+1 < len(units) else float('inf')
            if n < next_step:
                best_unit = name
                best_step = step
        
        # Wait, this would pick TiB for 1500000. That's not right.
        # Let's try the other way: find the smallest unit such that n / S_unit < 1024 (or 1000).
        # No, I already tried that and it failed for 1536 -> KiB.
        # Wait! "The unit chosen is the largest one that leaves the number below the step"
        # If n = 1,500,000 and binary=False:
        # KB (step 1000): Is 1,500,000 / 1000 < 1000? No (it's 1500).
        # MB (step 10^6): Is 1,500,000 / 10^6 < 1000? Yes (it's 1.5).
        # So the largest unit such that n / S_unit < step_base is MB!
        # Let's check for 1536 and binary=True:
        # KiB (step 1024): Is 1536 / 1024 < 1024? Yes (it's 1.5).
        # MiB (step 1024^2): Is 1536 / 1024^2 < 1024? Yes (it's 0.001...).
        # This still doesn't help pick KiB over MiB.

        # Let's try one more: find the largest unit such that n / S_unit >= 1 AND n / S_unit < step_base.
        # For 1536, binary=True (step_base=1024):
        # KiB (step 1024): 1536/1024 = 1.5. Is 1 <= 1.5 < 1024? Yes.
        # MiB (step 1024^2): 1536/1024^2 = 0.001... Is 1 <= 0.001 < 1024? No.
        # So the largest unit is KiB! Correct!
        # For 1,500,000, binary=False (step_base=1000):
        # MB (step 10^6): 1,500,000/10^6 = 1.5. Is 1 <= 1.5 < 1000? Yes.
        # GB (step 10^9): 1,500,000/10^9 = 0.001... Is 1 <= 0.001 < 1000? No.
        # So the largest unit is MB! Correct!
        # For TiB/TB: "above them the number simply keeps growing".
        # This means if n / S_unit >= 1, and it's the largest unit (TiB/TB), we use it.

        best_unit = None
        best_step = 1
        for name, step in units:
            if n >= step:
                val = n / step
                if val < step_base or name in ["TiB", "TB"]:
                    best_unit = name
                    best_step = step

        # If no unit was found (shouldn't happen because of the n < step_base check and TiB/TB)
        # but let's be safe.
        if not best_unit:
            return f"{n} B"

        val = n / best_step
        truncated_val = int(val * 10) / 10
        return f"{truncated_val:.1f} {best_unit}"

def to_bytes(s: str) -> int:
    return Solution().to_bytes(s)

def humanize(n: int, *, binary: bool = True) -> str:
    return Solution().humanize(n, binary=binary)
