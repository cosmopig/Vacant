import re

def to_bytes(s: str) -> int:
    s = s.strip()
    if not s:
        raise ValueError("Empty string")
    
    match = re.fullmatch(r"(\d+(?:\.\d+)?)\s*([a-zA-Z]*)", s)
    if not match:
        raise ValueError("Invalid format")
    
    num_str, unit_str = match.groups()
    try:
        val = float(num_str)
    except ValueError:
        raise ValueError("Invalid number")

    unit_str = unit_str.upper().strip()
    if not unit_str:
        return int(val)
    
    if unit_str == "B":
        return int(val)
    
    units = {
        'KB': 1000, 'MB': 1000**2, 'GB': 1000**3, 'TB': 1000**4,
        'KIB': 1024, 'MIB': 1024**2, 'GIB': 1024**3, 'TIB': 1024**4
    }

    if unit_str not in units:
        raise ValueError("Unrecognized unit")

    step = units[unit_str]
    return int(val * step)

def humanize(n: int, *, binary: bool = True) -> str:
    if n < 0:
        raise ValueError("Negative size")
    
    if binary:
        units = [
            (1, "B"),
            (1024**1, "KiB"),
            (1024**2, "MiB"),
            (1024**3, "GiB"),
            (1024**4, "TiB")
        ]
    else:
        units = [
            (1, "B"),
            (1000**1, "KB"),
            (1000**2, "MB"),
            (1000**3, "GB"),
            (1000**4, "TB")
        ]

    chosen_unit = units[0]
    # The unit chosen is the largest one that leaves the number below the step.
    # A size with no unit at all is a count of bytes.
    # KiB, MiB, GiB and TiB step by 1024; KB, MB, GB and TB step by 1000.
    # The "step" for each unit i is the multiplier to get to the NEXT unit i+1.
    # So B's step is 1024 (binary) or 1000 (decimal).
    # KiB's step is 1024^2 (binary) or 1000^2 (decimal)? No, that doesn't make sense.
    # Let's re-read: "KiB... step by 1024". This means the multiplier between units is 1024.
    # So for binary, every unit has a step of 1024. For decimal, every unit has a step of 1000.

    step = 1024 if binary else 1000
    for i in range(len(units)):
        m, name = units[i]
        if n / m < step:
            chosen_unit = (m, name)
            break
    else:
        # If it's larger than the biggest unit, it keeps growing.
        # This means we should pick the largest unit available if n/m >= step for all i.
        # Wait, "above them the number simply keeps growing". 
        # That means TiB or TB is the last unit.
        chosen_unit = units[-1]

    m, name = chosen_unit
    val = n / m
    if m == 1 and name == "B":
        return f"{int(val)} B"
    else:
        truncated_val = int(val * 10) / 10.0
        return f"{truncated_val:.1f} {name}"

