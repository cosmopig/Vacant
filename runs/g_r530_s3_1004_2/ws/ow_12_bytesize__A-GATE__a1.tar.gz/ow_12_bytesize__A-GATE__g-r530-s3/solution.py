import re

def to_bytes(s: str) -> int:
    s = s.strip()
    if not s:
        raise ValueError("Empty string")
    
    # The number is one or more digits with at most one dot and 
    # at least one digit after it if the dot is there. Nothing else is a number.
    match = re.fullmatch(r"(\d+(?:\.\d+)?)\s*([a-zA-Z]*)", s)
    if not match:
        raise ValueError("Invalid format")
        
    num_str, unit_str = match.groups()
    try:
        val = float(num_str)
    except ValueError:
        raise ValueError("Not a number")
        
    # "negative size given to either function"
    if "-" in s:
        raise ValueError("Negative")

    units = {
        "B": (1, 1),
        "KB": (1000, 1000),
        "MB": (1000**2, 1000**2),
        "GB": (1000**3, 1000**3),
        "TB": (1000**4, 1000**4),
        "KIB": (1024, 1024),
        "MIB": (1024**2, 1024**2),
        "GIB": (1024**3, 1024**3),
        "TIB": (1024**4, 1024**4),
    }

    if not unit_str:
        return int(val)
    
    u = unit_str.upper()
    if u == "B":
        return int(val)
    
    # Check for multiple units or unrecognised units
    if u not in units:
        raise ValueError("Unknown unit")
    
    step = units[u][0]
    return int(val * step)

def humanize(n: int, binary: bool = True) -> str:
    if n < 0:
        raise ValueError("Negative")
    
    if binary:
        units = [("B", 1), ("KiB", 1024), ("MiB", 1024**2), ("GiB", 1024**3), ("TiB", 1024**4)]
    else:
        units = [("B", 1), ("KB", 1000), ("MB", 1000**2), ("GB", 1000**3), ("TB", 1000**4)]

    one_step = units[1][1]
    if n < one_step:
        return f"{n} B"

    # The unit chosen is the largest one that leaves the number below the step, 
    # except that TiB and TB are the largest units there are.
    for i in range(len(units) - 1, -1, -1):
        name, step = units[i]
        next_step = units[i+1][1] if i+1 < len(units) else float('inf')
        val = n / step
        if val >= 1 and val < next_step:
            return f"{val:.1f} {name}"
    
    # If we get here, it means n is very large (above TiB/TB)
    return f"{n / units[-1][1]:.1f} {units[-1][0]}"

