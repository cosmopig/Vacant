class Machine:
    def __init__(self, spec: dict[str, dict[str, str]], start: str):
        all_states = set(spec.keys())
        for state, transitions in spec.items():
            for target in transitions.values():
                if target not in all_states:
                    raise ValueError(f"State '{target}' is not defined in spec.")
        
        if start not in all_states:
            raise ValueError(f"Start state '{start}' is not defined in spec.")

        self._spec = spec
        self._start = start
        self._current_state = start
        self._history = [start]

    @property
    def state(self) -> str:
        return self._current_state

    def can(self, event: str) -> bool:
        return event in self._spec[self._current_state]

    def fire(self, event: str) -> str:
        if not self.can(event):
            raise ValueError(f"Invalid transition from {self._current_state} via {event}")
        
        new_state = self._spec[self._current_state][event]
        self._current_state = new_state
        self._history.append(new_state)
        return new_state

    def history(self) -> list[str]:
        return list(self._history)

    def reset(self) -> None:
        self._current_state = self._start
        self._history = [self._start]
