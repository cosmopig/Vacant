import unittest
from solution import Machine

class TestMachine(unittest.TestCase):
    def test_basic_flow(self):
        spec = {
            "start": {"go": "middle"},
            "middle": {"finish": "end"},
            "end": {}
        }
        m = Machine(spec, "start")
        self.assertEqual(m.state, "start")
        self.assertTrue(m.can("go"))
        self.assertFalse(m.can("finish"))
        
        new_state = m.fire("go")
        self.assertEqual(new_state, "middle")
        self.assertEqual(m.state, "middle")
        self.assertTrue(m.can("finish"))
        
        m.fire("finish")
        self.assertEqual(m.state, "end")
        self.assertEqual(m.history(), ["start", "middle", "end"])

    def test_invalid_transition(self):
        spec = {
            "start": {"go": "middle"},
            "middle": {"finish": "end"},
            "end": {}
        }
        m = Machine(spec, "start")
        with self.assertRaises(ValueError):
            m.fire("finish")
        self.assertEqual(m.state, "start")

    def test_reset(self):
        spec = {
            "start": {"go": "middle"},
            "middle": {"finish": "end"},
            "end": {}
        }
        m = Machine(spec, "start")
        m.fire("go")
        m.reset()
        self.assertEqual(m.state, "start")
        self.assertEqual(m.history(), ["start"])

    def test_invalid_initial_state(self):
        spec = {"a": {}}
        with self.assertRaises(ValueError):
            Machine(spec, "b")

    def test_invalid_target_state(self):
        spec = {"a": {"go": "b"}}
        with self.assertRaises(ValueError):
            Machine(spec, "a")

if __name__ == "__main__":
    unittest.main()
