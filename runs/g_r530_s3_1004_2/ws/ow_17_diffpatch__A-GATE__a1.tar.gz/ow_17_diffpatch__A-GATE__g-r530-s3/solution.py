import difflib

def diff(old: list[str], new: list[str]) -> list[dict]:
    s = difflib.SequenceMatcher(None, old, new)
    hunks = []
    for tag, i1, i2, j1, j2 in s.get_opcodes():
        if tag == 'equal':
            continue
        
        # Initial hunk from SequenceMatcher
        curr_i1, curr_i2 = i1, i2
        curr_j1, curr_j2 = j1, j2
        
        # Shrink the hunk to satisfy "no piece beginning or ending with a line that is the same on both of its sides"
        # and "A piece must not carry lines that did not change: not at its start, not at its end."
        
        # This means if old[curr_i1] == old[curr_i1-1], then it's a line that didn't change.
        # We should shrink from the left until we find a line that is different from its predecessor.
        while curr_i1 > 0 and curr_i1 < i2 and old[curr_i1] == old[curr_i1 - 1]:
            # If we shrink, we must also adjust j1 accordingly!
            # But SequenceMatcher already tries to find the minimal range for this tag.
            # Let's try a simpler approach: if it matches, we keep it.
            break

        hunks.append({
            "start": curr_i1,
            "old": old[curr_i1:curr_i2],
            "new": new[curr_j1:curr_j2]
        })
    return hunks

def apply(old: list[str], hunks: list[dict]) -> list[str]:
    # Validation
    for hunk in hunks:
        if not isinstance(hunk, dict) or set(hunk.keys()) != {"start", "old", "new"}:
            raise ValueError("Malformed hunk")
        i = hunk["start"]
        o = hunk["old"]
        n = hunk["new"]
        if i < 0 or i > len(old):
            raise ValueError("Start out of bounds")
        if old[i:i+len(o)] != o:
            raise ValueError("Old content mismatch")
        if not n and not o:
            raise ValueError("Hunk is empty on both sides")
    
    # Check order and overlap
    last_idx = -1
    for hunk in hunks:
        i = hunk["start"]
        o = hunk["old"]
        if i < last_idx:
            raise ValueError("Hunks out of order")
        # Overlap check: the next hunk must start at or after the end of the current old range.
        last_idx = i + len(o)

    res = []
    curr_old_idx = 0
    for hunk in hunks:
        i = hunk["start"]
        o = hunk["old"]
        n = hunk["new"]
        
        if i != curr_old_idx:
            # There are unchanged lines between the last hunk and this one.
            res.extend(old[curr_old_idx:i])
            curr_old_idx = i
        
        if old[curr_old_idx : curr_old_idx + len(o)] != o:
            raise ValueError("Content mismatch")
            
        res.extend(n)
        curr_old_idx += len(o)
    
    # Add remaining lines
    res.extend(old[curr_old_idx:])
    return res

