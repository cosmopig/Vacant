from solution import diff, apply

def test_basic():
    old = ["line1", "line2", "line3"]
    new = ["line1", "line2_modified", "line3"]
    hunks = diff(old, new)
    assert hunks == [{"start": 1, "old": ["line2"], "new": ["line2_modified"]}]
    assert apply(old, hunks) == new

def test_insertion():
    old = ["line1", "line3"]
    new = ["line1", "line2", "line3"]
    hunks = diff(old, new)
    assert hunks == [{"start": 1, "old": [], "new": ["line2"]}]
    assert apply(old, hunks) == new

def test_deletion():
    old = ["line1", "line2", "line3"]
    new = ["line1", "line3"]
    hunks = diff(old, new)
    assert hunks == [{"start": 1, "old": ["line2"], "new": []}]
    assert apply(old, hunks) == new

def test_replacement():
    old = ["a", "b", "c"]
    new = ["x", "y", "z"]
    hunks = diff(old, new)
    # Should be one piece because they are all different and no common neighbors
    assert len(hunks) == 1
    assert apply(old, hunks) == new

def test_no_change():
    old = ["a", "b"]
    new = ["a", "b"]
    assert diff(old, new) == []

def test_multiple_changes():
    old = ["a", "b", "c", "d", "e"]
    new = ["a", "x", "c", "y", "e"]
    hunks = diff(old, new)
    assert len(hunks) == 2
    assert apply(old, hunks) == new

def test_overlap_error():
    old = ["a", "b", "c"]
    hunks = [
        {"start": 0, "old": ["a", "b"], "new": ["x"]},
        {"start": 1, "old": ["b", "c"], "new": ["y"]}
    ]
    try:
        apply(old, hunks)
    except ValueError:
        pass
    else:
        assert False, "Should have raised ValueError for overlap"

def test_out_of_order():
    old = ["a", "b", "c"]
    hunks = [
        {"start": 2, "old": ["c"], "new": ["z"]},
        {"start": 0, "old": ["a"], "new": ["x"]}
    ]
    try:
        apply(old, hunks)
    except ValueError:
        pass
    else:
        assert False, "Should have raised ValueError for out of order"

def test_wrong_content():
    old = ["a", "b", "c"]
    hunks = [{"start": 0, "old": ["x"], "new": ["y"]}]
    try:
        apply(old, hunks)
    except ValueError:
        pass
    else:
        assert False, "Should have raised ValueError for wrong content"

def test_past_end():
    old = ["a", "b"]
    hunks = [{"start": 5, "old": [], "new": ["c"]}]
    try:
        apply(old, hunks)
    except ValueError:
        pass
    else:
        assert False, "Should have raised ValueError for past end"

def test_empty_both():
    old = ["a", "b"]
    hunks = [{"start": 0, "old": [], "new": []}]
    try:
        apply(old, hunks)
    except ValueError:
        pass
    else:
        assert False, "Should have raised ValueError for empty both"

def test_malformed():
    old = ["a", "b"]
    hunks = [{"start": 0, "wrong": []}]
    try:
        apply(old, hunks)
    except ValueError:
        pass
    else:
        assert False, "Should have raised ValueError for malformed"

if __name__ == "__main__":
    test_basic()
    test_insertion()
    test_deletion()
    test_replacement()
    test_no_change()
    test_multiple_changes()
    test_overlap_error()
    test_out_of_order()
    test_wrong_content()
    test_past_end()
    test_empty_both()
    test_malformed()
