from solution.dedupe import dedupe

def test_basic():
    records = [
        {"id": 1, "name": "Alice"},
        {"id": 2, "name": "Bob"},
        {"id": 1, "name": "Alicia"}
    ]
    assert dedupe(records, "id", policy="first") == [{"id": 1, "name": "Alice"}, {"id": 2, "name": "Bob"}]
    assert dedupe(records, "id", policy="last") == [{"id": 1, "name": "Alicia"}, {"id": 2, "name": "Bob"}]

def test_merge():
    records = [
        {"id": 1, "name": "Alice", "age": None},
        {"id": 1, "name": "Alicia", "age": 30},
        {"id": 2, "name": "Bob"}
    ]
    assert dedupe(records, "id", policy="merge") == [
        {"id": 1, "name": "Alicia", "age": 30},
        {"id": 2, "name": "Bob"}
    ]

def test_composite_key():
    records = [
        {"first": "John", "last": "Doe", "city": "NY"},
        {"first": "Jane", "last": "Smith", "city": "LA"},
        {"first": "John", "last": "Doe", "city": "SF"}
    ]
    assert dedupe(records, ["first", "last"], policy="first") == [
        {"first": "John", "last": "Doe", "city": "NY"},
        {"first": "Jane", "last": "Smith", "city": "LA"}
    ]

def test_errors():
    records = [{"id": 1, "name": "Alice"}]
    try:
        dedupe(records, "missing")
    except KeyError as e:
        assert str(e) == "'missing'"
    
    try:
        dedupe(records, "id", policy="invalid")
    except ValueError:
        pass
    else:
        raise AssertionError("Should have raised ValueError for invalid policy")

if __name__ == "__main__":
    test_basic()
    test_merge()
    test_composite_key()
    test_errors()
    print("All tests passed!")
