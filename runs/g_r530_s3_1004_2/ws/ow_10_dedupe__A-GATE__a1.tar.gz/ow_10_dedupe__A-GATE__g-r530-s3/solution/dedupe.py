from typing import List, Dict, Any, Union

def dedupe(records: List[Dict[str, Any]], key: Union[str, List[str]], policy: str = "first") -> List[Dict[str, Any]]:
    if policy not in ("first", "last", "merge"):
        raise ValueError(f"Invalid policy: {policy}")

    if isinstance(key, str):
        key_list = [key]
    else:
        key_list = key

    seen_keys = {}  # Maps the composite key tuple to its index in the final list
    result = []

    for record in records:
        # Extract and validate keys
        key_values = []
        for k in key_list:
            if k not in record:
                raise KeyError(k)
            val = record[k]
            key_values.append(val)
        
        composite_key = tuple(key_values)

        if composite_key not in seen_keys:
            # New key found, add to result as a copy
            seen_keys[composite_key] = len(result)
            result.append(record.copy())
        else:
            # Key already exists, handle policy
            idx = seen_keys[composite_key]
            existing_record = result[idx]

            if policy == "first":
                pass  # Keep the first one (already in result)
            elif policy == "last":
                result[idx] = record.copy()
            elif policy == "merge":
                # Update existing_record with non-None values from current record
                for k, v in record.items():
                    if v is not None:
                        existing_record[k] = v

    return result
