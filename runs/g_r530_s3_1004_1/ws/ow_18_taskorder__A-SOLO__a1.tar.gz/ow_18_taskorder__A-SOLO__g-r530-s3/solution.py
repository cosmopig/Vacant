def plan(jobs: dict[str, list[str]]) -> list[str]:
    # Identify all unique job names mentioned in keys or values
    all_job_names = set(jobs.keys())
    for deps in jobs.values():
        all_job_names.update(deps)

    # Build adjacency list and in-degree count
    # adj[u] = [v1, v2, ...] where u must finish before v starts
    adj = {name: [] for name in all_job_names}
    in_degree = {name: 0 for name in all_job_names}

    for job, deps in jobs.items():
        # Note: The input says "the names of the jobs it waits for"
        # So if job 'A' has deps ['B'], then B must finish before A starts.
        # This means there is an edge from B to A.
        for dep in deps:
            adj[dep].append(job)
            in_degree[job] += 1

    # Kahn's algorithm for topological sort
    # To ensure deterministic output, we use a sorted list or heap of available jobs
    available = [name for name in all_job_names if in_degree[name] == 0]
    available.sort()  # Deterministic order

    order = []
    while available:
        u = available.pop(0) # Get the first one (smallest alphabetically)
        order.append(u)

        for v in adj[u]:
            in_degree[v] -= 1
            if in_degree[v] == 0:
                # Insert into sorted list to maintain deterministic order
                import bisect
                bisect.insort(available, v)

    if len(order) != len(all_job_names):
        raise ValueError("Cycle detected or unreachable jobs")

    return order
