from typing import Callable, Dict, List

class RateLimiter:
    def __init__(self, window_s: float, max_events: int, clock: Callable[[], float]):
        if window_s <= 0 or max_events < 0:
            raise ValueError("window_s must be > 0 and max_events must be >= 0")
        
        self.window_s = window_s
        self.max_events = max_events
        self.clock = clock
        # Map of key -> list of timestamps (floats)
        self.history: Dict[str, List[float]] = {}

    def allow(self, key: str) -> bool:
        now = self.clock()
        if key not in self.history:
            self.history[key] = []
        
        cutoff = now - self.window_s
        # Filter out events that are outside (now - window_s, now]
        # Note: "left open and right closed" means > (now - window_s) AND <= now
        self.history[key] = [t for t in self.history[key] if cutoff < t <= now]
        
        if len(self.history[key]) < self.max_events:
            self.history[key].append(now)
            return True
        else:
            return False

    def retry_after(self, key: str) -> float:
        now = self.clock()
        if self.max_events == 0:
            return float("inf")
            
        if key not in self.history:
            return 0.0

        cutoff = now - self.window_s
        # Filter for events in the window (now - window_s, now]
        in_window = [t for t in self.history[key] if cutoff < t <= now]
        
        if len(in_window) < self.max_events:
            return 0.0
        
        # The one that leaves first is the smallest t such that (now - window_s) < t <= now
        leaving = min(in_window)
        return leaving + self.window_s - now

    def reset(self, key: str | None = None) -> None:
        if key is None:
            self.history.clear()
        else:
            if key in self.history:
                del self.history[key]
