import re

def render(template: str, data: dict) -> str:
    # Parse the template into tokens
    tokens = []
    i = 0
    while i < len(template):
        if template[i:i+3] == r'\{{':
            tokens.append(('literal', '{{'))
            i += 3
        elif template[i:i+2] == '{{':
            end_idx = template.find('}}', i + 2)
            if end_idx == -1:
                raise ValueError("a {{ with no }} after it")
            content = template[i+2 : end_idx].strip()
            tokens.append(('tag', content))
            i = end_idx + 2
        else:
            next_special = len(template)
            for j in range(i, len(template)):
                if template[j:j+2] == '{{':
                    next_special = min(next_special, j)
                    break
                elif template[j:j+3] == r'\{{':
                    next_special = min(next_special, j)
                    break
            tokens.append(('text', template[i:next_special]))
            i = next_special

    def get_value(path, context_data):
        if path == ".":
            return context_data['.']
        
        if path.startswith('.'):
            current = context_data['.']
            parts = path[1:].split('.')
            for part in parts:
                if not part: continue
                if isinstance(current, dict) and part in current:
                    current = current[part]
                else:
                    raise KeyError(path)
            return current
        else:
            current = context_data
            parts = path.split('.')
            for part in parts:
                if not part: continue
                if isinstance(current, dict) and part in current:
                    current = current[part]
                else:
                    raise KeyError(path)
            return current

    def render_recursive(token_list, context_data, in_block=False):
        output = []
        while token_list:
            token = token_list.pop(0)
            if token[0] == 'text':
                output.append(token[1])
            elif token[0] == 'literal':
                output.append(token[1])
            elif token[0] == 'tag':
                content = token[1]
                if not content:
                    raise ValueError("an empty placeholder")
                if content.startswith('!'):
                    continue
                elif content.startswith('#each'):
                    block_tokens = []
                    found_closing = False
                    while token_list:
                        next_token = token_list[0]
                        if next_token[0] == 'tag' and next_token[1].startswith('/each'):
                            token_list.pop(0) # remove /each
                            found_closing = True
                            break
                        else:
                            block_tokens.append(token_list.pop(0))
                    
                    if not found_closing:
                        raise ValueError("a {{#each}} that is never closed")
                    
                    for t in block_tokens:
                        if t[0] == 'tag' and t[1].startswith('#each'):
                            raise ValueError("a repeat inside a repeat")

                    list_name = content[5:].strip()
                    if not list_name:
                        # The contract says {{#each items}}. If it's just {{#each}}, 
                        # is that allowed? "a repeat over something that is not a list"
                        raise ValueError("a repeat over something that is not a list")
                    
                    if list_name not in context_data or not isinstance(context_data[list_name], list):
                        raise ValueError("a repeat over something that is not a list")
                    
                    items = context_data[list_name]
                    for item in items:
                        new_context = context_data.copy()
                        new_context['.'] = item
                        output.append(render_recursive(block_tokens, new_context, True))
                elif content.startswith('/each'):
                    if not in_block:
                        raise ValueError("a {{/each}} with no {{#each}} open")
                else:
                    if content.startswith('.'):
                        if not in_block:
                            raise ValueError("{{.}} or {{.field}} outside any block")
                    val = get_value(content, context_data)
                    output.append(str(val))
        return "".join(output)

    # The issue was that I was popping from token_list in render_recursive but 
    # the items were being processed one by one and then the block_tokens were 
    # exhausted, which is correct for non-nested blocks.
    # However, if there are multiple items in a list, we need to ensure that 
    # each item gets its own copy of the block_tokens.
    # Currently, I'm popping them out of token_list once and then passing 
    # the same (now empty) list to every recursive call for every item.

    def render_recursive_fixed(token_list, context_data, in_block=False):
        output = []
        while token_list:
            token = token_list.pop(0)
            if token[0] == 'text':
                output.append(token[1])
            elif token[0] == 'literal':
                output.append(token[1])
            elif token[0] == 'tag':
                content = token[1]
                if not content:
                    raise ValueError("an empty placeholder")
                if content.startswith('!'):
                    continue
                elif content.startswith('#each'):
                    # We need to capture the tokens for this block without popping them yet,
                    # or rather, we pop them once and then pass a copy of that list 
                    # to each recursive call.
                    block_tokens = []
                    found_closing = False
                    temp_list = token_list[:] # This is not quite right because we need to remove the /each
                    
                    # Let's do it properly: find the closing tag and extract everything in between.
                    inner_tokens = []
                    j = 0
                    while j < len(token_list):
                        next_t = token_list[j]
                        if next_t[0] == 'tag' and next_t[1].startswith('/each'):
                            # Found it!
                            found_closing = True
                            # Remove the /each from the main list
                            del token_list[j]
                            break
                        else:
                            inner_tokens.append(token_list[j])
                            j += 1
                    
                    if not found_closing:
                        raise ValueError("a {{#each}} that is never closed")
                    
                    for t in inner_tokens:
                        if t[0] == 'tag' and t[1].startswith('#each'):
                            raise ValueError("a repeat inside a repeat")

                    list_name = content[5:].strip()
                    if not list_name:
                        raise ValueError("a repeat over something that is not a list")
                    
                    if list_name not in context_data or not isinstance(context_data[list_name], list):
                        raise ValueError("a repeat over something that is not a list")
                    
                    items = context_data[list_name]
                    for item in items:
                        new_context = context_data.copy()
                        new_context['.'] = item
                        # Pass a copy of the inner tokens so each iteration has its own set
                        output.append(render_recursive_fixed(inner_tokens[:], new_context, True))
                elif content.startswith('/each'):
                    if not in_block:
                        raise ValueError("a {{/each}} with no {{#each}} open")
                else:
                    if content.startswith('.'):
                        if not in_block:
                            raise ValueError("{{.}} or {{.field}} outside any block")
                    val = get_value(content, context_data)
                    output.append(str(val))
        return "".join(output)

    # Wait, the logic for finding the closing tag and removing it from token_list 
    # is slightly different than what I had before. Let's re-implement carefully.
    # Actually, let's just use a simple approach: pop everything until /each,
    # then pass that list to each iteration.

    def render_recursive_v4(token_list, context_data, in_block=False):
        output = []
        while token_list:
            token = token_list.pop(0)
            if token[0] == 'text':
                output.append(token[1])
            elif token[0] == 'literal':
                output.append(token[1])
            elif token[0] == 'tag':
                content = token[1]
                if not content:
                    raise ValueError("an empty placeholder")
                if content.startswith('!'):
                    continue
                elif content.startswith('#each'):
                    block_tokens = []
                    found_closing = False
                    while token_list:
                        next_t = token_list[0]
                        if next_t[0] == 'tag' and next_t[1].startswith('/each'):
                            token_list.pop(0) # remove /each
                            found_closing = True
                            break
                        else:
                            block_tokens.append(token_list.pop(0))
                    
                    if not found_closing:
                        raise ValueError("a {{#each}} that is never closed")
                    
                    for t in block_tokens:
                        if t[0] == 'tag' and t[1].startswith('#each'):
                            raise ValueError("a repeat inside a repeat")

                    list_name = content[5:].strip()
                    if not list_name:
                        raise ValueError("a repeat over something that is not a list")
                    
                    if list_name not in context_data or not isinstance(context_data[list_name], list):
                        raise ValueError("a repeat over something that is not a list")
                    
                    items = context_data[list_name]
                    for item in items:
                        new_context = context_data.copy()
                        new_context['.'] = item
                        # Pass a copy of the block_tokens to each recursive call
                        output.append(render_recursive_v4(block_tokens[:], new_context, True))
                elif content.startswith('/each'):
                    if not in_block:
                        raise ValueError("a {{/each}} with no {{#each}} open")
                else:
                    if content.startswith('.'):
                        if not in_block:
                            raise ValueError("{{.}} or {{.field}} outside any block")
                    val = get_value(content, context_data)
                    output.append(str(val))
        return "".join(output)

    return render_recursive_v4(tokens, data, False)

