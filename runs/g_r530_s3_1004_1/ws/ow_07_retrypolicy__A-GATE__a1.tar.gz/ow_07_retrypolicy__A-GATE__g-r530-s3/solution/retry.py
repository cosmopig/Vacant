from typing import Callable, Any, Type

def retry(fn: Callable[[], Any], *, attempts: int, backoff_s: float, max_backoff_s: float,
           retry_on: tuple[Type[BaseException], ...], sleep: Callable[[float], None]) -> Any:
    if attempts < 1:
        raise ValueError("attempts must be at least 1")

    for k in range(1, attempts + 1):
        try:
            return fn()
        except Exception as e:
            # Check if the exception is one of the types we should retry on.
            is_retryable = any(isinstance(e, retry_type) for retry_type in retry_on)

            if not is_retryable:
                raise e

            if k == attempts:
                raise e

            delay = min(backoff_s * (2 ** (k - 1)), max_backoff_s)
            sleep(delay)
