class Router:
    def __init__(self):
        self.routes = []

    def add(self, pattern: str, name: str) -> None:
        if not pattern.startswith('/'):
            raise ValueError("Pattern must start with /")
        
        segments_raw = pattern.split('/')
        # segments_raw[0] is always "" because of leading slash
        if pattern == '/':
            segments_raw = []
        else:
            segments_raw = segments_raw[1:]

        parsed_segments = []
        for i, seg in enumerate(segments_raw):
            if not seg:
                raise ValueError("Empty segment")
            if seg.startswith('{') and seg.endswith('}'):
                inner = seg[1:-1]
                if inner.endswith('*'):
                    # The contract says {name:*}. 
                    # We need to extract 'name' from '{name:*}'.
                    # If the segment is {rest:*}, name_part should be 'rest'.
                    if ':' in inner:
                        name_part = inner[:inner.find(':')]
                    else:
                        name_part = inner[:-1]
                    
                    if not name_part:
                        raise ValueError("Empty parameter name")
                    if i != len(segments_raw) - 1:
                        raise ValueError("{name:*} must be last")
                    parsed_segments.append(('wild', name_part))
                elif inner:
                    parsed_segments.append(('param', inner))
                else:
                    raise ValueError("Empty parameter name")
            else:
                parsed_segments.append(('literal', seg))

        for p_segs, _ in self.routes:
            if p_segs == parsed_segments:
                raise ValueError(f"Pattern {pattern} already registered")

        self.routes.append((parsed_segments, name))

    def match(self, path: str) -> tuple[str, dict[str, str]] | None:
        if path == '/':
            path_parts = []
        else:
            path_parts = path.split('/')[1:]

        matches = []
        for p_segs, route_name in self.routes:
            res_params = {}
            possible = True
            curr_p = 0
            for i, (stype, sval) in enumerate(p_segs):
                if stype == 'literal':
                    if curr_p < len(path_parts) and path_parts[curr_p] == sval:
                        curr_p += 1
                    else:
                        possible = False; break
                elif stype == 'param':
                    if curr_p < len(path_parts) and path_parts[curr_p] != '':
                        res_params[sval] = path_parts[curr_p]
                        curr_p += 1
                    else:
                        possible = False; break
                elif stype == 'wild':
                    remainder = "/".join(path_parts[curr_p:])
                    if remainder:
                        res_params[sval] = remainder
                        curr_p = len(path_parts)
                    else:
                        possible = False; break
            
            if possible and curr_p == len(path_parts):
                matches.append((p_segs, route_name, res_params))

        if not matches: return None
        
        def compare(m1, m2):
            s1, n1, p1 = m1
            s2, n2, p2 = m2
            for i in range(min(len(s1), len(s2))):
                t1 = s1[i][0]
                t2 = s2[i][0]
                if t1 != t2:
                    ranks = {'literal': 0, 'param': 1, 'wild': 2}
                    return 1 if ranks[t1] < ranks[t2] else -1
            if len(s1) != len(s2):
                return 1 if len(s1) > len(s2) else -1
            return 0

        best = matches[0]
        for i in range(1, len(matches)):
            if compare(matches[i], best) > 0:
                best = matches[i]
        
        return (best[1], best[2])
