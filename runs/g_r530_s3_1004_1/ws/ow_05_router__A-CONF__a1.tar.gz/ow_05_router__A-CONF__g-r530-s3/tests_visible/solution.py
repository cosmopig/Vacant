class Router:
    def __init__(self):
        self.routes = []
        self.patterns_seen = set()

    def add(self, pattern: str, name: str):
        if not pattern.startswith('/'):
            raise ValueError("Pattern must start with /")
        
        # The rule says "A pattern begins with / and is read as segments split on /."
        # This means "/a/b" -> ["a", "b"]
        # "/" -> []
        if pattern == '/':
            raw_segments = []
        else:
            raw_segments = pattern[1:].split('/')

        parsed_segments = []
        for i, seg in enumerate(raw_segments):
            if seg.startswith('{') and seg.endswith('}'):
                inner = seg[1:-1]
                if not inner: raise ValueError("Empty parameter name")
                
                if inner.endswith(':*'):
                    if i != len(raw_segments) - 1:
                        raise ValueError("{name:*} must be last segment")
                    parsed_segments.append((2, inner[:-2]))
                else:
                    if '{' in inner or '}' in inner:
                        raise ValueError("Unmatched brace")
                    parsed_segments.append((1, inner))
            else:
                # Literal - can be empty string if it was //
                parsed_segments.append((0, seg))

        pattern_key = tuple(s[0] for s in parsed_segments)
        if pattern_key in self.patterns_seen:
            raise ValueError("Duplicate pattern")
        self.patterns_seen.add(pattern_key)

        self.routes.append({
            'name': name,
            'segments': parsed_segments,
        })

    def match(self, path: str):
        # Paths always begin with /
        if path == '/':
            path_segments = []
        else:
            path_segments = path[1:].split('/')
            
        best_match = None
        best_score = None

        for route in self.routes:
            route_segs = route['segments']
            current_params = {}
            match_possible = True
            i = 0
            
            if not path_segments and not route_segs:
                pass
            elif not path_segments and route_segs:
                # Path is "/" but pattern has segments.
                # Only matches if it's a {name:*} at the end? No, name:* must not be empty.
                match_possible = False
            else:
                for j, (type, val) in enumerate(route_segs):
                    if i >= len(path_segments):
                        # If we have more segments in pattern than path, it's not a match
                        # unless the last segment is {name:*} which handles remainder.
                        match_possible = False
                        break
                    
                    if type == 0: # Literal
                        if path_segments[i] != val:
                            match_possible = False
                            break
                        i += 1
                    elif type == 1: # {name}
                        current_params[val] = path_segments[i]
                        i += 1
                    elif type == 2: # {name:*}
                        remainder = "/".join(path_segments[i:])
                        if not remainder:
                            match_possible = False
                            break
                        current_params[val] = remainder
                        i = len(path_segments)
                        # After name:*, we must have reached the end of path_segments
                        # and there should be no more segments in route_segs.
                        if j != len(route_segs) - 1:
                            match_possible = False
                            break
                        break

            if match_possible and i == len(path_segments):
                current_score = (tuple(s[0] for s in route_segs), len(route_segs))
                
                if best_score is None or current_score < best_score:
                    best_match = (route['name'], current_params)
                    best_score = current_score

        return best_match
