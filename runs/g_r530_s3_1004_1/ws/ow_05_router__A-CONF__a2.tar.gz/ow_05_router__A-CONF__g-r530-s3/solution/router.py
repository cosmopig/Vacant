import re

class Router:
    def __init__(self):
        # List of (parsed_segments, name)
        self.routes = []

    def add(self, pattern: str, name: str) -> None:
        if not pattern.startswith('/'):
            raise ValueError("Pattern must start with /")
        
        raw_parts = pattern.split('/')
        # The rule says "A pattern begins with / and is read as segments split on /."
        # For "/a/b", parts are ["", "a", "b"]
        if raw_parts[0] == "":
            segments = raw_parts[1:]
        else:
            segments = raw_parts

        parsed_segments = []
        for i, seg in enumerate(segments):
            if not seg: # Empty segment like "//" or trailing "/"
                # The rule says "{name} ... never matches an empty segment".
                # It doesn't say literal segments can't be empty. 
                parsed_segments.append(('literal', ''))
            elif seg.startswith('{') and seg.endswith('}'):
                inner = seg[1:-1]
                if not inner:
                    raise ValueError("Empty parameter name")
                if inner.endswith(':*'):
                    param_name = inner[:-2]
                    if not param_name:
                        raise ValueError("Empty parameter name")
                    if i != len(segments) - 1:
                        raise ValueError("{name:*} must be the last segment")
                    parsed_segments.append(('wildcard', param_name))
                else:
                    param_name = inner
                    parsed_segments.append(('param', param_name))
            else:
                if '{' in seg or '}' in seg:
                    raise ValueError("Unmatched brace")
                parsed_segments.append(('literal', seg))

        # Normalization for duplicate check
        norm = tuple((type(s[0]), s[1] if s[0] == 'literal' else "PARAM") for s in parsed_segments)
        for existing_norm, _ in self.routes:
            if existing_norm == norm:
                raise ValueError("Duplicate pattern")

        self.routes.append((parsed_segments, name))

    def match(self, path: str) -> tuple[str, dict[str, str]] | None:
        path_parts = path[1:].split('/')
        best_match = None
        # specificity score: (type_score, length)
        # type_score is a tuple of scores for each segment. 
        # literal=3, param=2, wildcard=1
        best_specificity = None

        for parsed_segments, name in self.routes:
            current_params = {}
            match_found = True
            
            if not parsed_segments: # Pattern "/"
                if len(path_parts) == 1 and path_parts[0] == "":
                    match_found = True
                else:
                    match_found = False
            else:
                # Check if it's a wildcard match or exact segment match
                last_type, last_val = parsed_segments[-1]
                
                if last_type == 'wildcard':
                    num_non_wildcards = len(parsed_segments) - 1
                    if len(path_parts) > num_non_wildcards:
                        for i in range(num_non_wildcards):
                            p_type, p_val = parsed_segments[i]
                            path_seg = path_parts[i]
                            if p_type == 'literal':
                                if path_seg != p_val:
                                    match_found = False
                                    break
                            elif p_type == 'param':
                                current_params[p_val] = path_seg
                            else: # Should not happen for i < num_non_wildcards
                                match_found = False
                                break
                        if match_found:
                            remainder = "/".join(path_parts[num_non_wildcards:])
                            if remainder == "": # This happens if path is "/a/" and pattern is "/a/{b:*}"
                                match_found = False
                            else:
                                current_params[last_val] = remainder
                    else:
                        match_found = False
                else:
                    # Exact segment match
                    if len(path_parts) != len(parsed_segments):
                        match_found = False
                    else:
                        for i in range(len(parsed_segments)):
                            p_type, p_val = parsed_segments[i]
                            path_seg = path_parts[i]
                            if p_type == 'literal':
                                if path_seg != p_val:
                                    match_found = False
                                    break
                            elif p_type == 'param':
                                current_params[p_val] = path_seg
                            else: # Should not happen here
                                match_found = False
                                break
            
            if match_found:
                current_specificity = []
                for p_type, p_val in parsed_segments:
                    if p_type == 'literal': current_specificity.append(3)
                    elif p_type == 'param': current_specificity.append(2)
                    else: current_specificity.append(1)
                
                score = (tuple(current_specificity), len(parsed_segments))
                if best_specificity is None or score > best_specificity:
                    best_match = (name, current_params)
                    best_specificity = score

        return best_match
