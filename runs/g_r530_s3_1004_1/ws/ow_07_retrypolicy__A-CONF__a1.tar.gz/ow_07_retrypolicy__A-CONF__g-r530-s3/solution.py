from typing import Callable, Any

def retry(fn: Callable[[], Any], *, attempts: int, backoff_s: float, 
           max_backoff_s: float, retry_on: tuple[type[BaseException], ...],
           sleep: Callable[[float], None]) -> Any:
    if attempts < 1:
        raise ValueError("attempts must be at least 1")

    last_exception = None
    for k in range(1, attempts + 1):
        try:
            return fn()
        except BaseException as e:
            # Check if the exception is one of the types we should retry on.
            if not any(isinstance(e, t) for t in retry_on):
                raise e
            
            last_exception = e
            
            # If this was our last attempt, don't sleep and raise the original error.
            if k == attempts:
                break
            
            # Calculate backoff: min(backoff_s * 2 ** (k - 1), max_backoff_s)
            delay = min(backoff_s * (2 ** (k - 1)), max_backoff_s)
            sleep(delay)
            
    if last_exception:
        raise last_exception
