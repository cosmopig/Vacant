import re

def render(template, data):
    def get_nested(path, context, in_loop=False):
        if not path:
            raise ValueError("Empty placeholder")
        
        # Rule: {{.}} or {{.field}} outside any block -> ValueError
        if path.startswith("."):
            if not in_loop:
                raise ValueError("Dot notation outside loop")
            
            if path == ".":
                return context
            
            parts = path[1:].split(".")
            curr = context
            for p in parts:
                if not p: continue
                if isinstance(curr, dict) and p in curr:
                    curr = curr[p]
                else:
                    raise KeyError(path)
            return curr
        else:
            # Rule: names that do not begin with . are still looked up in data.
            parts = path.split(".")
            curr = context
            for p in parts:
                if not p: continue
                if isinstance(curr, dict) and p in curr:
                    curr = curr[p]
                else:
                    raise KeyError(path)
            return curr

    def parse_recursive(text, context, in_loop=False):
        result = []
        i = 0
        while i < len(text):
            if text.startswith("\\{", i):
                # Check if it's \{{ or just \{
                if i + 2 < len(text) and text[i+2] == "{":
                    result.append("{{")
                    i += 3
                else:
                    result.append("\\")
                    i += 1
            elif text.startswith("{{", i):
                j = text.find("}}", i + 2)
                if j == -1:
                    raise ValueError("Malformed placeholder")
                content = text[i+2:j].strip()
                
                if not content:
                    raise ValueError("Empty placeholder")
                
                if content.startswith("!"):
                    # Comment
                    i = j + 2
                    continue
                elif content.startswith("#each"):
                    # Loop
                    if in_loop:
                        raise ValueError("Nested #each not allowed")
                    
                    k = text.find("{{/each}}", j + 2)
                    if k == -1:
                        raise ValueError("Unclosed #each")
                    
                    loop_content = text[j+2:k]
                    # Check for nested #each in loop_content
                    if "{{#each" in loop_content:
                        raise ValueError("Nested #each not allowed")
                    
                    list_name = content[5:].strip()
                    if not list_name:
                        raise ValueError("Empty #each")
                    
                    items = context.get(list_name)
                    if not isinstance(items, list):
                        raise ValueError("Not a list")
                    
                    # Render loop content for each item
                    for item in items:
                        result.append(parse_recursive(loop_content, item, True))
                    
                    i = k + 8 # Move past {{/each}}
                else:
                    val = get_nested(content, context, in_loop)
                    result.append(str(val))
                    i = j + 2
            else:
                # Find the next occurrence of \{{ or {{
                next_tag = -1
                for offset in range(1, len(text) - i + 1):
                    sub = text[i+offset : i+offset+2]
                    if sub == "\\{":
                        # We need to see if it's \{{
                        if i+offset+2 < len(text) and text[i+offset+2] == "{":
                            next_tag = i + offset
                            break
                    elif sub == "{{":
                        next_tag = i + offset
                        break
                
                if next_tag == -1:
                    result.append(text[i:])
                    break
                else:
                    # If it's \{{, we should only append up to the backslash?
                    # No, let's just find the index of {{ and handle it in the loop.
                    # But wait, if we have text like "abc\{{def", 
                    # next_tag will be at the position of \{.
                    # If we append text[i:next_tag], we get "abc\".
                    # Then i becomes next_tag, and in the next iteration it's handled by \{{.
                    result.append(text[i:next_tag])
                    i = next_tag
        return "".join(result)

    return parse_recursive(template, data, False)
