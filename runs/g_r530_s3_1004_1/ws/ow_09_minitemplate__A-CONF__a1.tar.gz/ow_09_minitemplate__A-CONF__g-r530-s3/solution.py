import re

def render(template, data):
    # Tokenize the template into text, literals (\{{), and tags {{...}}
    tokens = []
    i = 0
    while i < len(template):
        if template[i:i+3] == "\\{{":
            tokens.append(('literal', '{{'))
            i += 3
        elif template[i:i+2] == "{{":
            end_idx = template.find("}}", i + 2)
            if end_idx == -1:
                raise ValueError("Malformed template: unclosed placeholder")
            content = template[i+2 : end_idx].strip()
            tokens.append(('tag', content))
            i = end_idx + 2
        else:
            j = i
            while j < len(template) and template[j:j+2] != "{{" and template[j:j+3] != "\\{{":
                j += 1
            tokens.append(('text', template[i:j]))
            i = j

    def resolve_path(path, context):
        parts = path.split('.')
        curr = context
        for p in parts:
            if p == '.': continue
            if isinstance(curr, dict) and p in curr:
                curr = curr[p]
            else:
                raise KeyError(path)
        return curr

    def resolve_complex_path(path, current_item, original_context):
        if path == '.':
            return current_item
        if path.startswith('.'):
            parts = path[1:].split('.')
            curr = current_item
            for p in parts:
                if isinstance(curr, dict) and p in curr:
                    curr = curr[p]
                else:
                    raise KeyError(path)
            return curr
        else:
            parts = path.split('.')
            curr = original_context
            for p in parts:
                if isinstance(curr, dict) and p in curr:
                    curr = curr[p]
                else:
                    raise KeyError(path)
            return curr

    output = []
    idx = 0
    while idx < len(tokens):
        t_type, t_val = tokens[idx]
        if t_type == 'text':
            output.append(t_val)
        elif t_type == 'literal':
            output.append(t_val)
        elif t_type == 'tag':
            if t_val.startswith('!'):
                pass
            elif t_val.startswith('#each'):
                items_key = t_val[6:].strip()
                if not items_key:
                    raise ValueError("Malformed template: empty #each")
                
                # Find the closing /each tag at this level (no nested each allowed)
                j = idx + 1
                while j < len(tokens):
                    nt_type, nt_val = tokens[j]
                    if nt_type == 'tag':
                        if nt_val == '/each':
                            break
                        if nt_val.startswith('#each'):
                            raise ValueError("Malformed template: nested #each")
                    j += 1
                
                if j == len(tokens):
                    raise ValueError("Malformed template: unclosed #each")
                
                block_tokens = tokens[idx+1 : j]
                if items_key not in data or not isinstance(data[items_key], list):
                    raise ValueError("Malformed template: #each over non-list")
                
                for item in data[items_key]:
                    for bt_type, bt_val in block_tokens:
                        if bt_type == 'text':
                            output.append(bt_val)
                        elif bt_type == 'literal':
                            output.append(bt_val)
                        elif bt_type == 'tag':
                            if bt_val.startswith('!'):
                                pass
                            else:
                                res = resolve_complex_path(bt_val, item, data)
                                output.append(str(res))
                idx = j # Skip the block and /each tag
            else:
                # Placeholder
                if not t_val:
                    raise ValueError("Malformed template: empty placeholder")
                res = resolve_path(t_val, data)
                output.append(str(res))
        idx += 1

    return "".join(output)
