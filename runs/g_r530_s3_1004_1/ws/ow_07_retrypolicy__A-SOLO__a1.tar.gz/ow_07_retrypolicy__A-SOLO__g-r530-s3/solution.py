from typing import Callable, Any

def retry(fn: Callable[[], Any], *, attempts: int, backoff_s: float, max_backoff_s: float,
           retry_on: tuple[type[BaseException], ...], sleep: Callable[[float], None]) -> Any:
    if attempts < 1:
        raise ValueError("attempts must be at least 1")

    last_exception = None
    for k in range(1, attempts + 1):
        try:
            return fn()
        except BaseException as e:
            is_retryable = any(isinstance(e, base_type) for base_type in retry_on)

            if not is_retryable:
                raise e

            last_exception = e
            if k == attempts:
                raise last_exception

            delay = min(backoff_s * (2 ** (k - 1)), max_backoff_s)
            sleep(delay)

    if last_exception:
        raise last_exception
