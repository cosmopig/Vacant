import re

class Router:
    def __init__(self):
        self.routes = [] # list of (parsed_segments, name, regex, param_names)

    def add(self, pattern: str, name: str) -> None:
        if not pattern.startswith('/'):
            raise ValueError("Pattern must start with /")
        
        # "A pattern begins with / and is read as segments split on /."
        raw_segments = pattern.split('/')
        # For "/a/b", raw_segments is ['', 'a', 'b']. 
        # The first element is always empty because of the leading slash.
        if len(raw_segments) == 1: # Case "/"
            segments = []
        else:
            segments = raw_segments[1:]

        parsed_segments = []
        for i, seg in enumerate(segments):
            # "never matches an empty segment" - this applies to the path segments.
            if not seg: continue 
            
            if seg.startswith('{') and seg.endswith('}'):
                inner = seg[1:-1]
                if inner == '*':
                    raise ValueError("Empty parameter name")
                if inner.endswith(':*'):
                    if i != len(segments) - 1:
                        raise ValueError("{name:*} must be last")
                    parsed_segments.append(('wild', inner[:-2]))
                elif inner == '': # Should not happen if we check for {:}
                     raise ValueError("Empty parameter name")
                else:
                    if '{' in inner or '}' in inner: raise ValueError("Unmatched brace")
                    parsed_segments.append(('param', inner))
            else:
                parsed_segments.append(('literal', seg))

        # Check for duplicates (different names, same structure)
        for p_seg, r_name in self.routes:
            if p_seg == parsed_segments:
                raise ValueError(f"Pattern {pattern} already registered")

        # Build regex
        regex_parts = []
        param_names = []
        for i, (type, val) in enumerate(parsed_segments):
            if type == 'literal':
                regex_parts.append(re.escape(val))
            elif type == 'param':
                param_names.append(val)
                regex_parts.append(r"([^/]+)")
            elif type == 'wild':
                param_names.append(val)
                regex_parts.append(r".*")

        # The path starts with / so we need to handle that.
        # If pattern is "/a", segments are ["a"]. Path is "/a".
        # So regex should be ^/a$ or similar.
        full_regex = "^/" + "/".join(regex_parts) + "$"
        self.routes.append((parsed_segments, name, re.compile(full_regex), param_names))

    def match(self, path: str) -> tuple[str, dict[str, str]] | None:
        best_match = None
        max_score = (-1, -1) # (specificity_tuple, num_segments)

        for p_seg, r_name, reg, param_names in self.routes:
            m = reg.match(path)
            if m:
                # Calculate specificity
                # Rank: literal=3, param=2, wild=1
                score = []
                for i, (t, v) in enumerate(p_seg):
                    if t == 'literal': score.append(3)
                    elif t == 'param': score.append(2)
                    else: score.append(1)
                
                current_score = (tuple(score), len(p_seg))
                
                if best_match is None or current_score > max_score:
                    max_score = current_score
                    best_match = (r_name, m.groups(), param_names)

        if best_match:
            name, groups, p_names = best_match
            return name, dict(zip(p_names, groups))
        return None
