from typing import Callable, Dict, List

class RateLimiter:
    def __init__(self, window_s: float, max_events: int, clock: Callable[[], float]):
        if window_s <= 0 or max_events < 0:
            raise ValueError("window_s must be > 0 and max_events must be >= 0")
        
        self.window_s = window_s
        self.max_events = max_events
        self.clock = clock
        # Map key to a list of timestamps (floats)
        self.history: Dict[str, List[float]] = {}

    def allow(self, key: str) -> bool:
        now = self.clock()
        if key not in self.history:
            self.history[key] = []
        
        # Count events in (now - window_s, now]
        count = 0
        for ts in self.history[key]:
            if (now - self.window_s) < ts <= now:
                count += 1
        
        if count < self.max_events:
            self.history[key].append(now)
            return True
        else:
            return False

    def retry_after(self, key: str) -> float:
        now = self.clock()
        if self.max_events == 0:
            return float('inf')

        if key not in self.history:
            return 0.0
        
        # Find events in the window (now - window_s, now]
        valid_events = [ts for ts in self.history[key] if (now - self.window_s) < ts <= now]
        
        if len(valid_events) < self.max_events:
            return 0.0
        
        # "leaving is the earliest counted event that has to fall out of the window before the next call can be admitted."
        # If we have N events in the window, and max_events = M, where N > M.
        # We need (N - M) events to fall out. 
        # The ones falling out will be the oldest ones in the current window.
        # The "earliest" of those is the very first one in the sorted list of valid_events.
        valid_events.sort()
        leaving = valid_events[0]
        return leaving + self.window_s - now

    def reset(self, key: str | None = None) -> None:
        if key is None:
            self.history.clear()
        elif key in self.history:
            del self.history[key]
