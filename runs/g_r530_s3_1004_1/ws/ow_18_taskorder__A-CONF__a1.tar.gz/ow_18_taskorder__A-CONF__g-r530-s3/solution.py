def plan(jobs: dict[str, list[str]]) -> list[str]:
    # Identify all unique jobs involved (keys and values in the lists)
    all_jobs = set(jobs.keys())
    for deps in jobs.values():
        for dep in deps:
            all_jobs.add(dep)

    # Build adjacency list for graph traversal
    # We want to find an order such that if A depends on B, B comes before A.
    # This is a topological sort of the dependency graph.
    # In our input 'jobs', jobs[A] = [B, C] means B and C must finish before A.
    # So there are edges B -> A and C -> A.
    adj = {job: [] for job in all_jobs}
    in_degree = {job: 0 for job in all_jobs}

    for job, deps in jobs.items():
        for dep in deps:
            # Edge is from dependency to the job that waits for it
            adj[dep].append(job)
            in_degree[job] += 1

    # Kahn's algorithm for topological sort
    # To ensure deterministic output, we use a sorted list of "ready" jobs.
    ready = [job for job in all_jobs if in_degree[job] == 0]
    ready.sort()

    order = []
    while ready:
        # Pick the smallest lexicographical job to maintain determinism
        current = ready.pop(0)
        order.append(current)

        for neighbor in adj[current]:
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                ready.append(neighbor)
                ready.sort()

    if len(order) != len(all_jobs):
        raise ValueError("Cycle detected or unreachable jobs")

    return order
