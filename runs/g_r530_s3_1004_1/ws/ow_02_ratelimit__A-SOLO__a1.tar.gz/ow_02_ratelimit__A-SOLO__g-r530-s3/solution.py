from typing import Callable, Dict, List

class RateLimiter:
    def __init__(self, window_s: float, max_events: int, clock: Callable[[], float]):
        if window_s <= 0 or max_events < 0:
            raise ValueError("window_s must be > 0 and max_events must be >= 0")
        
        self.window_s = window_s
        self.max_events = max_events
        self.clock = clock
        # Map key to a list of timestamps (floats)
        self.history: Dict[str, List[float]] = {}

    def allow(self, key: str) -> bool:
        now = self.clock()
        if key not in self.history:
            self.history[key] = []
        
        history = self.history[key]
        count = 0
        for t in history:
            if now - self.window_s < t <= now:
                count += 1
        
        if count < self.max_events:
            self.history[key].append(now)
            return True
        else:
            return False

    def retry_after(self, key: str) -> float:
        now = self.clock()
        if self.max_events == 0:
            return float("inf")
        
        if key not in self.history or not self.history[key]:
            return 0.0
        
        # Filter events in window (now - window_s, now]
        in_window = [t for t in self.history[key] if now - self.window_s < t <= now]
        count = len(in_window)
        
        if count < self.max_events:
            return 0.0
        
        # If count >= max_events, we need some to fall out.
        # The ones that will leave first are the smallest timestamps in the window.
        # We need (count - max_events + 1) events to fall out.
        # Let the sorted timestamps in the window be t_1 < t_2 < ... < t_N.
        # These will be t_1, t_2, ..., t_{count - max_events + 1}.
        # The one that leaves last among these is t_{count - max_events + 1}.
        in_window.sort()
        leaving = in_window[len(in_window) - self.max_events]
        return leaving + self.window_s - now

    def reset(self, key: str | None = None) -> None:
        if key is None:
            self.history.clear()
        elif key in self.history:
            del self.history[key]
