import re

def slugify(titles: list[str]) -> list[str]:
    """
    Converts a batch of titles into slugs.
    - Lowercase letters, digits, and hyphens only.
    - No leading/trailing hyphens, no double hyphens.
    - Unique slugs in the batch.
    - Deterministic (same input gives same output).
    - Already clean slugs are preserved if they don't collide.
    - Non-Latin or punctuation titles still get a slug.
    """
    def base_slugify(title: str) -> str:
        # Convert to lowercase and remove non-alphanumeric (except hyphens/spaces)
        s = title.lower()
        # Keep only letters (any), digits, and hyphens/spaces as placeholders
        # Actually, let's just keep a-z0-9 and treat everything else as space.
        s = re.sub(r'[^a-z0-9\s\-]', ' ', s)
        # Replace multiple spaces or hyphens with single hyphen
        s = re.sub(r'[\s\-]+', '-', s).strip('-')
        
        if not s:
            # This handles titles with no Latin letters or only punctuation.
            return "title"
        return s

    slugs = []
    seen = set()
    
    for title in titles:
        # Check if it's already a clean slug
        is_clean = bool(re.match(r"^[a-z0-9]+(?:-[a-z0-9]+)*$", title))
        base = base_slugify(title)
        
        if is_clean and base == title:
            candidate = title
        else:
            candidate = base
            
        # Collision resolution
        final_slug = candidate
        counter = 1
        while final_slug in seen:
            suffix = f"-{counter}"
            final_slug = candidate + suffix
            counter += 1
        
        slugs.append(final_slug)
        seen.add(final_slug)

    return slugs
