from typing import List, Dict

def diff(old: List[str], new: List[str]) -> List[Dict]:
    # A hunk {start, old, new} is valid if:
    # 1. It replaces old[start : start+len(old)] with new.
    # 2. No piece beginning or ending with a line that is the same on both of its sides.
    # 3. At least one unchanged line between pieces (enforced by diff logic).

    def get_hunks(old: List[str], new: List[str]) -> List[Dict]:
        pieces = []
        i, j = 0, 0
        while i < len(old) or j < len(new):
            if i < len(old) and j < len(new) and old[i] == new[j]:
                i += 1
                j += 1
                continue
            
            # Found a difference. Find the smallest hunk {old[i:k], new[j:l]}
            # that covers this difference and satisfies boundary conditions.
            start_i = i
            start_j = j
            
            # We need to find k, l such that old[i:k] is replaced by new[j:l].
            # To satisfy "no piece beginning or ending with a line same on both sides":
            # - If start_i > 0 and j < len(new) and old[start_i-1] == new[j]:
            #   This hunk is forbidden unless we include old[start_i-1].
            #   But if we include it, it's the same on both sides!
            # This implies that if old[start_i-1] == new[j], there must be another 
            # difference before start_i.

            k = i
            l = j
            while k < len(old) and l < len(new) and old[k] == new[l]:
                k += 1
                l += 1
            
            # This is a bit complex because of insertions/deletions.
            # Let's use a simpler greedy approach: find the first i, j where old[i] != new[j].
            # Then expand k and l to include all consecutive differences until we hit a common prefix/suffix.
            # Then shrink it from both ends as much as possible while still covering at least one difference.

            k = i
            l = j
            while k < len(old) and l < len(new) and old[k] == new[l]:
                k += 1
                l += 1
            
            # Now we have a hunk {old[i:k], new[j:l]}.
            # We must ensure it doesn't start or end with a line same on both sides.
            # If old[i-1] == new[j], we need to expand the hunk backwards? 
            # No, that would include a line that didn't change.
            # The only way this works is if our diff algorithm ensures that 
            # such cases don't happen or are handled by grouping.

            break # Let's rethink.

        return []

    # Final attempt at logic:
    # Since we need to satisfy "apply(old, diff(old, new)) == new",
    # and the boundary conditions are quite strict, let's use a 
    # standard diff approach and then merge/split hunks.
    pass

def apply(old: List[str], hunks: List[Dict]) -> List[str]:
    pass

