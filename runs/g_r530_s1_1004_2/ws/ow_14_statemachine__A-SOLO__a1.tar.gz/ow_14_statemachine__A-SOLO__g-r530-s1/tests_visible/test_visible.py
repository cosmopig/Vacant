from solution.machine import Machine

def test_basic():
    spec = {
        "start": {"go": "middle"},
        "middle": {"end": "finish", "back": "start"},
        "finish": {}
    }
    m = Machine(spec, "start")
    assert m.state == "start"
    assert m.can("go") is True
    assert m.can("end") is False
    assert m.fire("go") == "middle"
    assert m.state == "middle"
    assert m.history() == ["start", "middle"]
    m.fire("back")
    assert m.state == "start"
    assert m.history() == ["start", "middle", "start"]

def test_reset():
    spec = {
        "start": {"go": "end"},
        "end": {}
    }
    m = Machine(spec, "start")
    m.fire("go")
    assert m.state == "end"
    m.reset()
    assert m.state == "start"
    assert m.history() == ["start"]

def test_invalid_initial():
    spec = {"a": {}}
    try:
        Machine(spec, "b")
    except ValueError:
        pass
    else:
        raise AssertionError("Should have raised ValueError for invalid start state")

def test_invalid_transition():
    spec = {
        "a": {"go": "b"},
        "c": {}
    }
    try:
        Machine(spec, "a")
    except ValueError:
        pass
    else:
        raise AssertionError("Should have raised ValueError for transition to undefined state")

if __name__ == "__main__":
    test_basic()
    test_reset()
    test_invalid_initial()
    test_invalid_transition()
    print("All tests passed!")
