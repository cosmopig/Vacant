def dedupe(records, key, policy="first"):
    if policy not in ("first", "last", "merge"):
        raise ValueError(f"Invalid policy: {policy}")

    seen_keys = {}  # maps composite key tuple to index in result list
    result = []

    for record in records:
        key_values = []
        for k in key:
            if k not in record:
                raise KeyError(k)
            val = record[k]
            key_values.append(val)
        
        composite_key = tuple(key_values)

        if composite_key not in seen_keys:
            seen_keys[composite_key] = len(result)
            # Create a new dict to ensure we don't modify the original and return a new object.
            result.append(record.copy())
        else:
            idx = seen_keys[composite_key]
            if policy == "first":
                pass # Keep the one already in result
            elif policy == "last":
                result[idx] = record.copy()
            elif policy == "merge":
                # Field by field, value of last copy that has field and is not None
                target = result[idx]
                for k, v in record.items():
                    if v is not None and v != "" and v != [] and v != {}:
                        target[k] = v

    return result
