def dedupe(records, key, policy="first"):
    if policy not in ("first", "last", "merge"):
        raise ValueError(policy)

    keys_to_check = [key] if isinstance(key, str) else key
    seen_keys = {} # (tuple of values) -> index in result list
    result = []

    for record in records:
        current_key_values = []
        for k in keys_to_check:
            if k not in record:
                raise KeyError(k)
            current_key_values.append(record[k])
        
        key_tuple = tuple(current_key_values)

        if key_tuple not in seen_keys:
            seen_keys[key_tuple] = len(result)
            # Create a new dictionary to avoid modifying the original input
            result.append(dict(record))
        else:
            idx = seen_keys[key_tuple]
            if policy == "first":
                pass 
            elif policy == "last":
                result[idx] = dict(record)
            elif policy == "merge":
                target = result[idx]
                for k, v in record.items():
                    # The prompt says: "the value of the last copy that both has 
                    # the field and whose value is not None"
                    if v is not None:
                        if target.get(k) is None:
                            target[k] = v
    return result
