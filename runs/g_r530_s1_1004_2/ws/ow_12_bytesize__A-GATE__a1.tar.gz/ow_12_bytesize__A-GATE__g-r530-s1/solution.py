import re

def to_bytes(s: str) -> int:
    s = s.strip()
    if not s:
        raise ValueError("Empty string")
    
    # Check for negative size
    if "-" in s and s.startswith("-"):
         raise ValueError("Negative size")

    # Regex to match number and optional unit
    # Number part: one or more digits, optionally followed by a dot and at least one digit
    # Unit part: optional whitespace then letters
    match = re.fullmatch(r"(\d+(?:\.\d+)?)\s*([a-zA-Z]*)", s)
    if not match:
        raise ValueError("Invalid format")
    
    num_str, unit_str = match.groups()
    
    try:
        val = float(num_str)
    except ValueError:
        raise ValueError("Invalid number")

    # The rule says a negative size given to either function must be refused.
    if val < 0:
        raise ValueError("Negative size")

    unit_str = unit_str.strip().upper()
    
    binary_units = {"KIB": 1024, "MIB": 1024**2, "GIB": 1024**3, "TIB": 1024**4}
    decimal_units = {"KB": 1000, "MB": 1000**2, "GB": 1000**3, "TB": 1000**4}
    
    step = 1
    if unit_str == "":
        pass # Bytes
    elif unit_str == "B":
        step = 1
    elif unit_str in binary_units:
        step = binary_units[unit_str]
    elif unit_str in decimal_units:
        step = decimal_units[unit_str]
    else:
        raise ValueError("Unknown unit")

    # The result is the number multiplied by the unit's step, with the fraction dropped -- truncated toward zero, never rounded up.
    return int(val * step)

def humanize(n: int, *, binary: bool = True) -> str:
    if n < 0:
        raise ValueError("Negative size")
    
    # Special case for 0? The rules say "When the size is below one step it is printed as a whole number of bytes with the unit B"
    # For n=0, it's always below any step.
    if n == 0:
        return "0 B"

    binary_units = [("TiB", 1024**4), ("GiB", 1024**3), ("MiB", 1024**2), ("KiB", 1024)]
    decimal_units = [("TB", 1000**4), ("GB", 1000**3), ("MB", 1000**2), ("KB", 1000)]

    units = binary_units if binary else decimal_units
    
    # Find the largest unit such that n >= unit_step.
    chosen_unit = "B"
    for unit_name, unit_step in units:
        if n >= unit_step:
            chosen_unit = unit_name
            break
    
    if chosen_unit == "B":
        return f"{n} B"
    else:
        # Find the step for the chosen unit
        steps = {}
        if binary:
            steps = {"TiB": 1024**4, "GiB": 1024**3, "MiB": 1024**2, "KiB": 1024}
        else:
            steps = {"TB": 1000**4, "GB": 1000**3, "MB": 1000**2, "KB": 1000}
        step = steps[chosen_unit]
        
        val = n / step
        # The number is printed to one decimal place, keeping a trailing .0.
        return f"{val:.1f} {chosen_unit}"

class Solution:
    def to_bytes(self, s: str) -> int:
        return to_bytes(s)
    def humanize(self, n: int, *, binary: bool = True) -> str:
        return humanize(n, binary=binary)

# The contract says solution.to_bytes and solution.humanize should exist.
# In the tests, it seems they are imported from the module 'solution'.
# If I define them as functions in the module, that should work too.
