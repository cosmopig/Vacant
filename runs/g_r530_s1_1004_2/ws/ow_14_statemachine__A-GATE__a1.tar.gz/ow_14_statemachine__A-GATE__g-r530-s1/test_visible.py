import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from solution import Machine

def test_basic():
    spec = {
        "start": {"go": "middle"},
        "middle": {"end": "finish", "back": "start"},
        "finish": {}
    }
    m = Machine(spec, "start")
    assert m.state == "start"
    assert m.can("go") is True
    assert m.can("end") is False
    assert m.fire("go") == "middle"
    assert m.state == "middle"
    assert m.history() == ["start", "middle"]
    m.fire("back")
    assert m.state == "start"
    assert m.history() == ["start", "middle", "start"]

def test_reset():
    spec = {
        "start": {"go": "end"},
        "end": {}
    }
    m = Machine(spec, "start")
    m.fire("go")
    m.reset()
    assert m.state == "start"
    assert m.history() == ["start"]

def test_invalid_transitions():
    # Rule: Rules that point at a state nobody defined... should be caught when the rules are handed over
    spec = {
        "start": {"go": "missing"},
        "middle": {}
    }
    try:
        Machine(spec, "start")
    except ValueError:
        pass
    else:
        raise AssertionError("Should have raised ValueError for target state 'missing' not in spec.")

def test_invalid_start():
    spec = {"a": {}}
    try:
        Machine(spec, "b")
    except ValueError:
        pass
    else:
        raise AssertionError("Should have raised ValueError for invalid start state")

if __name__ == "__main__":
    test_basic()
    test_reset()
    test_invalid_transitions()
    test_invalid_start()
    print("All tests passed!")
