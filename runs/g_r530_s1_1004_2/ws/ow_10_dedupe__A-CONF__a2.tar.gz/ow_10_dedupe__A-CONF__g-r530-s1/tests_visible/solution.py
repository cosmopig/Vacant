from typing import List, Dict, Any, Union

def dedupe(records: List[Dict[str, Any]], key: Union[str, List[str]], policy: str = "first") -> List[Dict[str, Any]]:
    if policy not in ("first", "last", "merge"):
        raise ValueError(f"Invalid policy: {policy}")

    seen_keys = {}  # maps composite key tuple to index in result list
    result = []

    for record in records:
        key_parts = [key] if isinstance(key, str) else key
        current_key_tuple = []
        for k in key_parts:
            if k not in record:
                raise KeyError(k)
            val = record[k]
            current_key_tuple.append(val)
        
        current_key_tuple = tuple(current_key_tuple)

        if current_key_tuple not in seen_keys:
            seen_keys[current_key_tuple] = len(result)
            result.append(record.copy())
        else:
            idx = seen_keys[current_key_tuple]
            existing_record = result[idx]

            if policy == "first":
                pass  # Keep the first one already in result
            elif policy == "last":
                result[idx] = record.copy()
            elif policy == "merge":
                new_record = existing_record.copy()
                for k, v in record.items():
                    if v is not None:
                        # The requirement says: "the value of the last copy that both has the field and whose value is not None"
                        # This means if a later record has a non-None value for a key, it overwrites whatever was there before (even if it was also non-None).
                        new_record[k] = v
                result[idx] = new_record

    return result
