import re

def to_bytes(s: str) -> int:
    s = s.strip()
    if not s:
        raise ValueError("Empty string")
    
    # Number is one or more digits with at most one dot and at least one digit after it if the dot is there.
    match = re.fullmatch(r"(\d+(?:\.\d+)?)\s*([a-zA-Z]*)", s)
    if not match:
        raise ValueError("Invalid format")
        
    num_str, unit_str = match.groups()
    
    try:
        number = float(num_str)
    except ValueError:
        raise ValueError("Invalid number")

    units_binary = {
        "B": 1,
        "KIB": 1024,
        "MIB": 1024**2,
        "GIB": 1024**3,
        "TIB": 1024**4
    }
    units_decimal = {
        "B": 1,
        "KB": 1000,
        "MB": 1000**2,
        "GB": 1000**3,
        "TB": 1000**4
    }

    unit_str = unit_str.upper()
    if not unit_str:
        return int(number)
    
    if unit_str == "B":
        return int(number)
    
    # The prompt says KiB, MiB, GiB and TiB step by 1024.
    # My dictionary keys are KIB, MIB, GIB, TIB because I'm using .upper().
    # But the input might be "KiB". upper() makes it "KIB".
    # So I should check for both or adjust my dictionary.
    
    for u, step in units_binary.items():
        if unit_str == u:
            return int(number * step)
    
    for u, step in units_decimal.items():
        if unit_str == u:
            return int(number * step)

    raise ValueError("Unrecognized unit")

def humanize(n: int, *, binary: bool = True) -> str:
    if n < 0:
        raise ValueError("Negative size")
    
    if binary:
        units_list = [("B", 1), ("KiB", 1024), ("MiB", 1024**2), ("GiB", 1024**3), ("TiB", 1024**4)]
    else:
        units_list = [("B", 1), ("KB", 1000), ("MB", 1000**2), ("GB", 1000**3), ("TB", 1000**4)]

    chosen_unit = "B"
    chosen_step = 1
    for name, step in units_list:
        if n >= step:
            chosen_unit = name
            chosen_step = step
        else:
            break

    # If it's below one step (the first non-byte unit), print as bytes.
    if n < units_list[1][1]:
        return f"{n} B"
    else:
        val = n / chosen_step
        truncated_val = int(val * 10) / 10.0
        # The prompt says "keeping a trailing .0". f-string :.1f does this.
        return f"{truncated_val:.1f} {chosen_unit}"

