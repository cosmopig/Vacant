import re

def slugify(titles: list[str]) -> list[str]:
    """
    Converts a batch of titles into slugs.
    - One slug per title, same order.
    - Only lowercase letters, digits, and hyphens.
    - No leading/trailing hyphens, no double hyphens.
    - Unique slugs in the batch.
    - Deterministic (same input = same output).
    - Clean slugs are preserved if they don't collide.
    - Non-Latin or punctuation titles still get a slug.
    """

    def is_clean_slug(s: str) -> bool:
        return bool(re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", s))

    def generate_base_slug(title: str) -> str:
        # 1. Keep only lowercase letters and digits, replace others with hyphen
        res = ""
        for c in title:
            if c.isalnum():
                res += c.lower()
            else:
                res += "-"
        
        # Cleanup: remove double hyphens, leading/trailing hyphens
        res = re.sub(r'-+', '-', res)
        res = res.strip('-')
        
        if not res:
            return "slug"
        return res

    # First pass: identify the 'ideal' slug for each title
    ideals = []
    for title in titles:
        if is_clean_slug(title):
            ideals.append(title)
        else:
            ideals.append(generate_base_slug(title))

    # Second pass: resolve collisions while preserving the "already a clean slug" rule
    # A title that is already a clean slug, and that nothing else in the batch collides with, comes back exactly as it was;
    
    ideal_counts = {}
    for i in ideals:
        ideal_counts[i] = ideal_counts.get(i, 0) + 1

    final_slugs = []
    used_in_batch = set()
    
    # We need to be careful about the order of resolution to ensure determinism and correctness.
    # If multiple titles have the same "ideal" slug, we need a consistent way to pick which one stays as it is (if any) 
    # or how they are renamed.
    
    # Let's use a simple strategy:
    # For each title in order:
    #   1. If its ideal form is NOT colliding with anything else in the batch AND it was originally a clean slug,
    #      it stays as it is.
    #   2. Otherwise, we find the first available slug starting from its ideal form (with suffixes).

    for i, title in enumerate(titles):
        ideal = ideals[i]
        
        if is_clean_slug(title) and ideal_counts.get(ideal, 0) == 1:
            final_slugs.append(title)
            used_in_batch.add(title)
        else:
            candidate = ideal
            counter = 1
            while candidate in used_in_batch:
                suffix = f"-{counter}"
                # We must ensure the new candidate is a clean slug.
                # Since 'ideal' is already a clean slug (or "slug"), 
                # appending "-1", "-2" etc will always result in a clean slug.
                candidate = ideal + suffix
                counter += 1
            final_slugs.append(candidate)
            used_in_batch.add(candidate)

    return final_slugs
