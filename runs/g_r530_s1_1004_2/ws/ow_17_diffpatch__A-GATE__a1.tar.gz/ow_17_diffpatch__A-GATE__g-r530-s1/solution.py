from typing import List, Dict

def diff(old: List[str], new: List[str]) -> List[Dict]:
    # A piece is (start=i, old=o[i:k], new=n[j:l]).
    # Constraints:
    # 1. apply(old, diff) == new
    # 2. pieces ordered by start
    # 3. at least one unchanged line between end of one piece and start of next
    # 4. no piece beginning or ending with a line that is the same on both of its sides
    # 5. A piece must not carry lines that did not change: not at its start, not at its end.

    def get_hunks(o, n):
        valid_hunks = []
        for i in range(len(o)):
            for k in range(i + 1, len(o) + 1):
                for j in range(len(n)):
                    for l in range(j + 1, len(n) + 1):
                        # Rule: "no piece carries lines that did not change"
                        if i < len(o) and j < len(n) and o[i] == n[j]: continue
                        if k > i and l > j and o[k-1] == n[l-1]: continue
                        # Rule: "no piece beginning or ending with a line that is the same on both of its sides"
                        if i > 0 and j > 0 and o[i-1] == n[j-1]: continue
                        if k < len(o) and l < len(n) and o[k] == n[l]: continue
                        # Must be a change
                        if o[i:k] == n[j:l]: continue
                        valid_hunks.append((i, k, j, l))
        return valid_hunks

    all_hunks = get_hunks(old, new)
    memo = {}

    def solve(i, j):
        if i == len(old) and j == len(new):
            return []
        if (i, j) in memo:
            return memo[(i, j)]
        
        # If current lines are equal, skip them.
        if i < len(old) and j < len(new) and old[i] == new[j]:
            res = solve(i + 1, j + 1)
            memo[(i, j)] = res
            return res
        
        # Try all possible hunks that start at or after i and j.
        best_res = None
        for h_i, h_k, h_j, h_l in all_hunks:
            if h_i >= i and h_j >= j:
                # Check if there's an unchanged line between the previous hunk end (i) and this one.
                # If we are skipping lines from i to h_i-1, they must be equal in both old and new.
                if h_i > i:
                    for idx in range(i, h_i):
                        if idx < len(old) and j + (idx - i) < len(new) and old[idx] != new[j + (idx - i)]:
                            break
                    # Wait, the "at least one unchanged line" rule means if we skip lines 
                    # from i to h_i-1, there must be at least ONE such line.
                    if h_i == i: pass # This is fine, no skipped lines.
                else:
                    pass

                # Actually, the "at least one unchanged line" rule means if we have a previous hunk 
                # that ended at k_prev, then h_i >= k_prev + 2.
                # Since our recursive call solve(i, j) only happens when old[i] != new[j],
                # and the "skip equal lines" part handles the unchanged ones, we can just ensure 
                # that if there was a previous hunk ending at k_prev, then h_i >= k_prev + 2.

                # Let's simplify: a hunk (h_i, h_k, h_j, h_l) is valid from state (i, j) if:
                # 1. All lines from i to h_i-1 are equal in both old and new.
                # 2. If there was a previous hunk ending at k_prev, then h_i >= k_prev + 2.
                #    Wait, we don't know k_prev easily here. Let's add it to the state.

                pass

        return None

    # Let's try an even simpler approach: greedy with backtracking.
    # Since the constraints are so tight, there might be very few valid sequences.
    pass

