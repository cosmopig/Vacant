def dedupe(records: list[dict], key: str | list[str], policy: str = "first") -> list[dict]:
    if policy not in ("first", "last", "merge"):
        raise ValueError(f"Invalid policy: {policy}")

    keys_to_check = [key] if isinstance(key, str) else key
    seen_keys = {}  # maps tuple of values to index in result list
    result = []

    for record in records:
        try:
            current_key_values = []
            for k in keys_to_check:
                val = record[k]
                current_key_values.append(val)
            
            key_tuple = tuple(current_key_values)
        except KeyError as e:
            raise KeyError(e.args[0])

        if key_tuple not in seen_keys:
            seen_keys[key_tuple] = len(result)
            # Every dictionary in the result is a new object, not one of the inputs.
            result.append(record.copy())
        else:
            idx = seen_keys[key_tuple]
            if policy == "first":
                pass  # Keep what's already there
            elif policy == "last":
                result[idx] = record.copy()
            elif policy == "merge":
                target = result[idx]
                for k, v in record.items():
                    if v is not None:
                        target[k] = v
    return result

