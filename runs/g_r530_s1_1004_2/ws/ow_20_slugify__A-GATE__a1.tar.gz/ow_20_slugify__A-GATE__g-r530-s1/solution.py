import re

def slugify(titles: list[str]) -> list[str]:
    """
    Converts a batch of titles into slugs.
    
    Rules:
    - One slug per title, same order.
    - Only lowercase letters, digits, and hyphens.
    - No leading/trailing hyphens, no double hyphens.
    - Unique slugs in the batch.
    - Deterministic (same input -> same output).
    - Clean slugs are preserved if they don't collide.
    - Non-Latin scripts or punctuation-only titles get usable slugs.
    """
    def generate_base_slug(title: str) -> str:
        # 1. Convert to lowercase
        title = title.lower()
        # 2. Keep only a-z, 0-9 and replace everything else with hyphen
        slug = "".join(c if ('a' <= c <= 'z' or '0' <= c <= '9') else "-" for c in title)
        # 3. Remove duplicate hyphens and leading/trailing hyphens
        slug = re.sub(r'-+', '-', slug).strip('-')
        
        if not slug:
            return "a"
        
        return slug

    slugs = []
    seen = set()
    
    for title in titles:
        base_slug = generate_base_slug(title)
        
        # A "clean slug" is lowercase letters, digits and hyphens, 
        # never starts or ends with a hyphen, and never has two hyphens in a row.
        is_clean = bool(re.match(r"^[a-z0-9]+(?:-[a-z0-9]+)*$", title))
        
        current_slug = None
        if is_clean:
            # If it's clean, we prefer to keep it as is.
            if title not in seen:
                current_slug = title
            else:
                # It's a collision with another "already-a-slug" or something else
                current_slug = base_slug
        else:
            current_slug = base_slug

        # Handle collisions
        if current_slug in seen:
            counter = 1
            while True:
                suffix = f"-{counter}"
                candidate = current_slug + suffix
                if candidate not in seen:
                    current_slug = candidate
                    break
                counter += 1
        
        # Final check for the "no leading/trailing hyphens" and "no double hyphens"
        # The base slug generation already handles this, but appending a suffix might
        # introduce issues if not careful. Our suffix "-1", "-2" is safe.
        # Wait, what if current_slug was empty? generate_base_slug returns "a".
        # If "a" is taken, it becomes "a-1". Safe.

        slugs.append(current_slug)
        seen.add(current_slug)

    return slugs
