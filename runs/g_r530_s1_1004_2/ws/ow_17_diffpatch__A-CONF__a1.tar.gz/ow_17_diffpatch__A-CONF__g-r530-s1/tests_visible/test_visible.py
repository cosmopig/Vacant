import unittest
from solution import diff, apply

class TestDiffApply(unittest.TestCase):
    def test_basic_diff_apply(self):
        old = ["line1", "line2", "line3"]
        new = ["line1", "changed", "line3"]
        hunks = diff(old, new)
        self.assertEqual(apply(old, hunks), new)

    def test_empty_diff(self):
        old = ["a", "b", "c"]
        new = ["a", "b", "c"]
        self.assertEqual(diff(old, new), [])
        self.assertEqual(apply(old, []), old)

    def test_multiple_changes(self):
        old = ["a", "b", "c", "d", "e"]
        new = ["a", "x", "c", "y", "e"]
        hunks = diff(old, new)
        self.assertEqual(apply(old, hunks), new)

    def test_insertion_at_start(self):
        old = ["b", "c"]
        new = ["a", "b", "c"]
        hunks = diff(old, new)
        self.assertEqual(apply(old, hunks), new)

    def test_deletion_at_end(self):
        old = ["a", "b", "c"]
        new = ["a", "b"]
        hunks = diff(old, new)
        self.assertEqual(apply(old, hunks), new)

    def test_replacement(self):
        old = ["a", "b", "c"]
        new = ["a", "x", "y", "z", "c"]
        hunks = diff(old, new)
        self.assertEqual(apply(old, hunks), new)

    def test_no_redundant_lines(self):
        # Piece must not carry lines that did not change: not at its start, not at its end.
        # "a" is same on both sides of the change in ["a", "b"] -> ["a", "x"]
        old = ["a", "b"]
        new = ["a", "x"]
        hunks = diff(old, new)
        for hunk in hunks:
            self.assertEqual(hunk['old'], ["b"])
            self.assertEqual(hunk['new'], ["x"])

    def test_out_of_order_apply(self):
        old = ["a", "b", "c"]
        hunks = [
            {"start": 2, "old": ["c"], "new": ["z"]},
            {"start": 0, "old": ["a"], "new": ["x"]}
        ]
        with self.assertRaises(ValueError):
            apply(old, hunks)

    def test_overlapping_apply(self):
        old = ["a", "b", "c"]
        hunks = [
            {"start": 0, "old": ["a", "b"], "new": ["x"]},
            {"start": 1, "old": ["b", "c"], "new": ["y"]}
        ]
        with self.assertRaises(ValueError):
            apply(old, hunks)

    def test_wrong_content_apply(self):
        old = ["a", "b", "c"]
        hunks = [{"start": 0, "old": ["x"], "new": ["y"]}]
        with self.assertRaises(ValueError):
            apply(old, hunks)

    def test_malformed_hunk(self):
        old = ["a", "b"]
        with self.assertRaises(ValueError):
            apply(old, [{"start": 0, "new": ["x"]}]) # missing 'old'

    def test_both_sides_empty(self):
        # A piece must not be empty on both sides (meaning old and new are both empty)
        # Wait, the contract says: "Either side may be empty, but not both."
        # This refers to `old` and `new`. If both were empty, it would be a no-op.
        # Actually, if both were empty, start wouldn't move anything.
        pass

    def test_past_end(self):
        old = ["a"]
        hunks = [{"start": 1, "old": [], "new": ["b"]}] # start is at end, but old is empty?
        # Wait, if start is 1 and len(old) is 1, it's at the end.
        # If old is [], then it's replacing nothing at index 1.
        # Let's see: "when a piece reaches past the end of the old list"
        hunks = [{"start": 2, "old": ["a"], "new": ["b"]}]
        with self.assertRaises(ValueError):
            apply(old, hunks)

    def test_no_unchanged_between_pieces(self):
        # diff returns pieces with at least one unchanged line between them.
        old = ["a", "b", "c", "d", "e"]
        new = ["a", "x", "c", "y", "e"]
        hunks = diff(old, new)
        # hunks should be:
        # 1. start=1, old=["b"], new=["x"]
        # 2. start=3, old=["d"], new=["y"]
        # There is an unchanged line "c" at index 2 between them.
        self.assertEqual(len(hunks), 2)
        self.assertEqual(hunks[0]['start'], 1)
        self.assertEqual(hunks[1]['start'], 3)

if __name__ == "__main__":
    unittest.main()
