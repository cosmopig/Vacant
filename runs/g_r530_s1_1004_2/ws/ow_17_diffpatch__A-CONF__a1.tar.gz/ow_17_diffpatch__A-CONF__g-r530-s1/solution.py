import difflib

def diff(old: list[str], new: list[str]) -> list[dict]:
    matcher = difflib.SequenceMatcher(None, old, new)
    opcodes = matcher.get_opcodes()
    
    hunks = []
    i = 0
    while i < len(opcodes):
        tag, i1, i2, j1, j2 = opcodes[i]
        if tag == 'equal':
            i += 1
            continue
        
        start_idx = i
        while i < len(opcodes) and opcodes[i][0] != 'equal':
            i += 1
        
        total_i1 = opcodes[start_idx][1]
        total_i2 = opcodes[i-1][2]
        total_j1 = opcodes[start_idx][3]
        total_j2 = opcodes[i-1][4]
        
        curr_i1, curr_i2, curr_j1, curr_j2 = total_i1, total_i2, total_j1, total_j2
        
        # Shrink from the left: 
        while curr_i1 > 0 and curr_j1 > 0 and old[curr_i1-1] == new[curr_j1-1]:
            curr_i1 -= 1
            curr_j1 -= 1

        # Shrink from the right:
        while curr_i2 < len(old) and curr_j2 < len(new) and old[curr_i2] == new[curr_j2]:
            curr_i2 += 1
            curr_j2 += 1

        # Final check for redundant lines at the boundaries:
        while True:
            changed = False
            if curr_i1 < len(old) and curr_j1 < len(new) and old[curr_i1] == new[curr_j1]:
                curr_i1 += 1
                curr_j1 += 1
                changed = True
            if curr_i2 > curr_i1 and curr_j2 > curr_j1 and old[curr_i2-1] == new[curr_j2-1]:
                curr_i2 -= 1
                curr_j2 -= 1
                changed = True
            if not changed:
                break

        hunks.append({
            'start': curr_i1,
            'old': old[curr_i1:curr_i2],
            'new': new[curr_j1:curr_j2]
        })
    return hunks

def apply(old: list[str], hunks: list[dict]) -> list[str]:
    for hunk in hunks:
        if not isinstance(hunk, dict) or set(hunk.keys()) != {'start', 'old', 'new'}:
            raise ValueError("Malformed hunk")
        if not hunk['old'] and not hunk['new']:
            raise ValueError("Hunk is empty on both sides")
        if hunk['start'] < 0 or hunk['start'] > len(old):
            raise ValueError("Start out of bounds")
        if hunk['start'] + len(hunk['old']) > len(old):
            raise ValueError("Old part reaches past end")

    next_available = 0
    result = []
    for hunk in hunks:
        start = hunk['start']
        if start < next_available:
            raise ValueError("Hunks out of order or overlapping")
        
        # Add lines from old that were not part of any hunk
        result.extend(old[next_available:start])
        
        # Check if the 'old' part matches
        if old[start : start + len(hunk['old'])] != hunk['old']:
            raise ValueError("Old content mismatch")
        
        # Add new lines from this hunk
        result.extend(hunk['new'])
        
        # Update next_available to the end of the 'old' part replaced by this hunk
        next_available = start + len(hunk['old'])
    
    # Add remaining lines
    result.extend(old[next_available:])
    return result
