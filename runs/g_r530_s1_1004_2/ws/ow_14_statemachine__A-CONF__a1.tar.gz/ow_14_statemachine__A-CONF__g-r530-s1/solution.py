from typing import Dict

class Machine:
    def __init__(self, spec: Dict[str, Dict[str, str]], start: str):
        # Validate that all states in the spec are valid keys
        # and that every target state is also a key in the spec.
        all_states = set(spec.keys())
        
        if start not in all_states:
            raise ValueError(f"Starting state '{start}' is not in the specification.")

        for state, events in spec.items():
            for event, target in events.items():
                if target not in all_states:
                    raise ValueError(f"Event '{event}' in state '{state}' leads to undefined state '{target}'.")

        self._spec = spec
        self._start_state = start
        self._current_state = start
        self._history = [start]

    @property
    def state(self) -> str:
        return self._current_state

    def can(self, event: str) -> bool:
        return event in self._spec[self._current_state]

    def fire(self, event: str) -> str:
        if not self.can(event):
            raise ValueError(f"Event '{event}' is not valid for state '{self._current_state}'.")
        
        self._current_state = self._spec[self._current_state][event]
        self._history.append(self._current_state)
        return self._current_state

    def history(self) -> list[str]:
        return list(self._history)

    def reset(self) -> None:
        self._current_state = self._start_state
        self._history = [self._start_state]
