import re

class Solution:
    def to_bytes(self, s: str) -> int:
        s = s.strip()
        if not s:
            raise ValueError("Empty string")
        
        # Number is one or more digits with at most one dot and at least one digit after it if the dot is there.
        match = re.fullmatch(r"(\d+(?:\.\d+)?)\s*([a-zA-Z]*)", s)
        if not match:
            raise ValueError("Invalid format")
        
        num_str, unit_str = match.groups()
        
        try:
            number = float(num_str)
        except ValueError:
            # This shouldn't happen with the regex but good to be safe
            raise ValueError("Invalid number")

        if number < 0:
            raise ValueError("Negative size")

        unit_str = unit_str.upper()
        
        units = {
            "B": (1, 1),
            "KB": (1000, 1000),
            "KIB": (1024, 1024),
            "MB": (1000**2, 1000**2),
            "MIB": (1024**2, 1024**2),
            "GB": (1000**3, 1000**3),
            "GIB": (1024**3, 1024**3),
            "TB": (1000**4, 1000**4),
            "TIB": (1024**4, 1024**4),
        }

        if not unit_str:
            return int(number)
        
        if unit_str == "B":
            return int(number)
        
        if unit_str not in units:
            raise ValueError("Unknown unit")
        
        step = units[unit_str][0]
        # The prompt says the fraction is dropped (truncated toward zero).
        # Since number >= 0, we can use int(number * step).
        return int(number * step)

    def humanize(self, n: int, *, binary: bool = True) -> str:
        if n < 0:
            raise ValueError("Negative size")
        
        if binary:
            units = [
                (1, "B"),
                (1024, "KiB"),
                (1024**2, "MiB"),
                (1024**3, "GiB"),
                (1024**4, "TiB")
            ]
        else:
            units = [
                (1, "B"),
                (1000, "KB"),
                (1000**2, "MB"),
                (1000**3, "GB"),
                (1000**4, "TB")
            ]
        
        chosen_unit = units[0]
        for i in range(len(units)):
            step, name = units[i]
            if n >= step:
                chosen_unit = (step, name)
            else:
                break
        
        step, name = chosen_unit
        value = n / step
        
        if name == "B":
            return f"{int(value)} B"
        else:
            # One decimal place even if round. Fraction dropped (truncated toward zero).
            # Since value is positive, int(value * 10) // 10 works for truncation.
            # Wait, the prompt says "fractional byte count is not a thing, so the fraction is dropped".
            # This applies to `to_bytes`. For `humanize`, it's about how many units there are.
            # Actually, if n=1536 and binary=True: 1536 / 1024 = 1.5.
            # The result should be "1.5 KiB".
            # If value is 1.5, int(value * 10) // 10 is 1. That's not right.
            # It says "the fraction is dropped" for `to_bytes`.
            # For `humanize`, it doesn't say the fraction of the humanized value is dropped.
            # It only says "The number is printed to one decimal place".
            # Let's check: 1536 / 1024 = 1.5. One decimal place is 1.5.
            # What if it was 1.59? Should it be 1.5 or 1.6? "fractional byte count is not a thing, so the fraction is dropped".
            # This might mean we should truncate the value before printing.
            # Let's see: n=1536, step=1024, value = 1.5. Truncated to one decimal place is 1.5.
            # If value was 1.59, truncated to one decimal place would be 1.5.
            # Let's try that.

            truncated_value = int(value * 10) / 10.0
            return f"{truncated_value:.1f} {name}"

def to_bytes(s: str) -> int:
    return Solution().to_bytes(s)

def humanize(n: int, *, binary: bool = True) -> str:
    return Solution().humanize(n, binary=binary)
