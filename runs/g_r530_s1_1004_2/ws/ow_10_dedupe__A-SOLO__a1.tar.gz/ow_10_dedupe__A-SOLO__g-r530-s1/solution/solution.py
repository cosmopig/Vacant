def dedupe(records: list[dict], key: str | list[str], policy: str = "first") -> list[dict]:
    if policy not in ("first", "last", "merge"):
        raise ValueError(f"Invalid policy: {policy}")

    if isinstance(key, str):
        keys = [key]
    else:
        keys = key

    seen_keys = {}  # maps key_tuple -> index_in_result
    result = []

    for record in records:
        current_key = []
        for k in keys:
            if k not in record:
                raise KeyError(k)
            val = record[k]
            current_key.append(val)
        
        key_tuple = tuple(current_key)

        if key_tuple not in seen_keys:
            seen_keys[key_tuple] = len(result)
            # Create a new dict to ensure we don't modify the original and return a new object
            result.append(record.copy())
        else:
            idx = seen_keys[key_tuple]
            if policy == "first":
                pass  # Already have the first one
            elif policy == "last":
                result[idx] = record.copy()
            elif policy == "merge":
                target = result[idx]
                for k, v in record.items():
                    if v is not None:
                        # Requirement: "the value of the last copy that both has the field and whose value is not None"
                        # If we are merging, and current record has a non-None value for key k, 
                        # it becomes the new value in our result.
                        target[k] = v

    return result
