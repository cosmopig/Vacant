import re
import unicodedata

def get_width(text):
    return sum(2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1 for ch in text)

class Realigner:
    def __init__(self, text):
        self.lines = text.splitlines(keepends=True)
        self.result = []

    def is_separator_row(self, row_cells):
        for cell in row_cells:
            stripped = cell.strip()
            if not re.fullmatch(r':?-+:?', stripped):
                return False
        return True

    def has_column_separator(self, line):
        in_backtick = False
        for idx, char in enumerate(line):
            if char == '`':
                in_backtick = not in_backtick
                continue
            if char == '|' and not in_backtick:
                if idx == 0 or line[idx-1] != '\\':
                    return True
        return False

    def parse_cells(self, line):
        cells = []
        current_cell = ""
        in_backtick = False
        i = 0
        while i < len(line):
            char = line[i]
            if char == '`':
                in_backtick = not in_backtick
                current_cell += char
                i += 1
            elif char == '\\':
                if i + 1 < len(line) and line[i+1] == '|':
                    current_cell += line[i:i+2]
                    i += 2
                else:
                    current_cell += char
                    i += 1
            elif char == '|' and not in_backtick:
                cells.append(current_cell)
                current_cell = ""
                i += 1
            else:
                current_cell += char
                i += 1
        cells.append(current_cell)
        return cells

    def process_table(self, table_lines):
        rows = []
        for line in table_lines:
            cells = self.parse_cells(line)
            rows.append(cells)
        
        num_cols = max(len(row) for row in rows)
        col_widths = [3] * num_cols
        markers = [None] * num_cols

        for i, row in enumerate(rows):
            if i == 1: # Separator row
                for j, cell in enumerate(row):
                    stripped = cell.strip()
                    if stripped.startswith(':') and stripped.endswith(':'):
                        markers[j] = ('c', ':')
                    elif stripped.startswith(':'):
                        markers[j] = ('l', ':')
                    elif stripped.endswith(':'):
                        markers[j] = ('r', ':')
                    else:
                        markers[j] = (None, None)
                continue
            
            for j, cell in enumerate(row):
                if j < num_cols:
                    content = cell.strip()
                    col_widths[j] = max(col_widths[j], get_width(content))

        new_rows = []
        for i, row in enumerate(rows):
            if i == 1: # Separator row
                row_cells = []
                for j in range(num_cols):
                    marker = markers[j] if markers[j] else (None, None)
                    m_type, m_prefix = marker
                    w = col_widths[j]
                    if m_type == 'c': row_cells.append(":" + "-" * (w - 2) + ":")
                    elif m_type == 'l': row_cells.append(":" + "-" * (w - 1))
                    elif m_type == 'r': row_cells.append("-" * (w - 1) + ":")
                    else: row_cells.append("-" * w)
                # The rule says "Every rendered row begins with | , and ends with  |"
                # For separator rows, the joiner is also " | ".
                row_str = "| " + " | ".join(row_cells) + " |"
                new_rows.append(row_str)
            else:
                new_row = []
                for j in range(num_cols):
                    cell_content = ""
                    if j < len(row):
                        cell_content = row[j].strip()
                    w = col_widths[j]
                    c_width = get_width(cell_content)
                    padding = w - c_width
                    m_type, _ = markers[j] if markers[j] else (None, None)
                    if m_type == 'r':
                        new_row.append(" " * padding + cell_content)
                    elif m_type == 'c':
                        left_pad = padding // 2
                        right_pad = padding - left_pad
                        new_row.append(" " * left_pad + cell_content + " " * right_pad)
                    else:
                        new_row.append(cell_content + " " * padding)
                # The rule says "Every rendered row begins with | , and ends with  |"
                # And "neighbouring cells are joined by  |".
                # This means for n=2, it's "| cell1 | cell2 |"
                row_str = "| " + " | ".join(new_row) + " |"
                new_rows.append(row_str)
        
        final_rows = []
        for k in range(len(new_rows)):
            if k == len(new_rows) - 1:
                ending = table_lines[-1][-1] if table_lines else ""
                final_rows.append(new_rows[k] + ending)
            else:
                # The rule says "Each line keeps the line ending it arrived with"
                # Since we replace multiple lines with new_rows, this is slightly ambiguous.
                # However, usually tables are one row per line. 
                # If they aren't, we should probably use the ending of the corresponding original line.
                ending = table_lines[k][-1] if k < len(table_lines) else ""
                final_rows.append(new_rows[k] + ending)
        
        return "".join(final_rows)

    def solve(self):
        i = 0
        while i < len(self.lines):
            line = self.lines[i]
            if self.has_column_separator(line):
                if i + 1 < len(self.lines) and self.is_separator_row(self.parse_cells(self.lines[i+1])):
                    table_lines = []
                    j = i
                    while j < len(self.lines):
                        l = self.lines[j]
                        if not l.strip() or not self.has_column_separator(l):
                            break
                        table_lines.append(l)
                        j += 1
                    processed_table = self.process_table(table_lines)
                    self.result.extend(processed_table.splitlines(keepends=True))
                    i = j
                else:
                    self.result.append(line)
                    i += 1
            else:
                self.result.append(line)
                i += 1
        return "".join(self.result)

def realign(text):
    return Realigner(text).solve()
