from typing import Any, Dict, Optional

class Config:
    def __init__(self, data: Dict[str, Any], sources: Dict[str, str]):
        self._data = data
        self._sources = sources

    def get(self, key: str) -> Any:
        if key not in self._data:
            raise KeyError(key)
        return self._data[key]

    def source(self, key: str) -> str:
        if key not in self._sources:
            raise KeyError(key)
        return self._sources[key]

    def as_dict(self) -> Dict[str, Any]:
        return self._data.copy()

def load(defaults: Dict[str, Any], file_text: Optional[str], env: Dict[str, str]) -> Config:
    final_data = {}
    sources = {}

    # Initialize with defaults
    for key in defaults:
        final_data[key] = defaults[key]
        sources[key] = "default"

    # Process file
    if file_text is not None:
        current_section = ""
        lines = file_text.splitlines()
        for line in lines:
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            
            if stripped.startswith("[") and stripped.endswith("]"):
                # Section header like [db] -> "db."
                current_section = stripped[1:-1].strip() + "."
                continue
            
            if "=" in stripped:
                key_part, val_part = stripped.split("=", 1)
                key = (current_section + key_part).strip()
                val = val_part.strip()
                
                if key in defaults:
                    final_data[key] = convert(val, type(defaults[key]))
                    sources[key] = "file"

    # Process env
    for env_key, env_val in env.items():
        # Only names beginning with APP_ are considered
        if not env_key.startswith("APP_"):
            continue
        
        # The name is matched without regard to case. 
        # "After the prefix, __ stands for . and the rest is lowercased"
        # Example: APP_DB__PORT -> db.port
        
        raw_name = env_key[4:] # Remove APP_
        transformed_name = raw_name.replace("__", ".").lower()
        
        if transformed_name in defaults:
            final_data[transformed_name] = convert(env_val, type(defaults[transformed_name]))
            sources[transformed_name] = "env"

    return Config(final_data, sources)

def convert(value: str, target_type: type) -> Any:
    if target_type is bool:
        normalized = value.lower()
        if normalized in ("true", "1", "yes"):
            return True
        if normalized in ("false", "0", "no"):
            return False
        raise ValueError(f"Cannot convert {value} to bool")
    elif target_type is int:
        try:
            return int(value)
        except (ValueError, TypeError):
            raise ValueError(f"Cannot convert {value} to int")
    elif target_type is float:
        try:
            return float(value)
        except (ValueError, TypeError):
            raise ValueError(f"Cannot convert {value} to float")
    else: # str
        return value

