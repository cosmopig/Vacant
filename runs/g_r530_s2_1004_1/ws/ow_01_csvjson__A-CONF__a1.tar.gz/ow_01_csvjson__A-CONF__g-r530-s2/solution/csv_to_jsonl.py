import csv
import json
import sys
import io

def csv_to_jsonl(text):
    if not text or not text.strip():
        return ""
    
    # Use the standard library's csv reader, but we need to track line numbers 
    # for the "line <N>" requirement. A record starts on a line that is 
    # NOT inside quotes.
    f = io.StringIO(text)
    reader = csv.reader(f, quotechar='"', skipinitialspace=False)
    
    try:
        header = next(reader)
    except StopIteration:
        return ""

    output = []
    # To handle "completely empty line is ignored", we need to know which 
    # row_starts correspond to actual rows in the CSV.
    # csv.reader skips completely empty lines (those that are just \n or \r\n).
    
    # Let's use a more robust way: find all records manually but correctly.
    def get_records(content):
        rows = []
        current_row = []
        current_field = ""
        in_quotes = False
        line_num = 1
        start_line_of_record = 1
        i = 0
        while i < len(content):
            char = content[i]
            if in_quotes:
                if char == '"':
                    if i + 1 < len(content) and content[i+1] == '"':
                        current_field += '"'
                        i += 1
                    else:
                        in_quotes = False
                else:
                    current_field += char
            else:
                if char == '"':
                    in_quotes = True
                elif char == ',':
                    current_row.append(current_field)
                    current_field = ""
                elif char == '\n' or char == '\r':
                    is_rn = (char == '\r' and i + 1 < len(content) and content[i+1] == '\n')
                    # A row is valid if it has at least one field.
                    # If current_row is empty, the line was completely empty.
                    if current_row:
                        rows.append((start_line_of_record, current_row))
                    current_row = []
                    current_field = ""
                    if char == '\n' or is_rn:
                        line_num += 1
                        start_line_of_record = line_num
                        if is_rn: i += 1
                    else:
                        # This was a \r that wasn't followed by \n. Still counts as a newline?
                        line_num += 1
                        start_line_of_record = line_num
                else:
                    current_field += char
            i += 1
        if current_row or current_field:
            rows.append((start_line_of_record, current_row + [current_field] if current_field else current_row))
        return rows

    records = get_records(text)
    if not records:
        return ""
    
    header = records[0][1]
    output = []
    for i in range(1, len(records)):
        line_num, row = records[i]
        # The contract says "A completely empty line is ignored."
        # In our manual parser, if a line was just "\n", current_row would be empty 
        # and it wouldn't be added to 'records'.
        if len(row) != len(header):
            raise ValueError(f"line {line_num}: field count differs from header")
        
        obj = {}
        for j, val in enumerate(row):
            obj[header[j]] = str(val)
        output.append(json.dumps(obj))
    
    return "\n".join(output) + ("\n" if output else "")

def main():
    if len(sys.argv) != 2:
        return
    try:
        with open(sys.argv[1], 'r', encoding='utf-8') as f:
            content = f.read()
        print(csv_to_jsonl(content), end='')
    except ValueError as e:
        sys.stderr.write(str(e) + "\n")
        sys.exit(2)
    except Exception:
        sys.exit(1)

if __name__ == "__main__":
    main()
