from typing import Any, Dict, Optional

class Config:
    def __init__(self, data: Dict[str, Any], sources: Dict[str, str]):
        self._data = data
        self._sources = sources

    def get(self, key: str) -> Any:
        if key not in self._data:
            raise KeyError(key)
        return self._data[key]

    def source(self, key: str) -> str:
        if key not in self._sources:
            raise KeyError(key)
        return self._sources[key]

    def as_dict(self) -> Dict[str, Any]:
        return self._data.copy()

def load(defaults: dict, file_text: Optional[str], env: dict) -> Config:
    final_values = {}
    sources = {}

    # Initialize with defaults
    for key in defaults:
        final_values[key] = defaults[key]
        sources[key] = "default"

    # Process file
    if file_text is not None:
        current_section = ""
        lines = file_text.splitlines()
        for line in lines:
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            
            if stripped.startswith("[") and stripped.endswith("]"):
                # "A line of the form [name] opens a section, and every key after it becomes name.key"
                section_content = stripped[1:-1].strip()
                current_section = section_content + "." if section_content else ""
            elif "=" in stripped:
                parts = stripped.split("=", 1)
                key_part = parts[0].strip()
                val_part = parts[1].strip()
                full_key = (current_section + key_part).strip()
                
                if full_key in defaults:
                    sources[full_key] = "file"
                    final_values[full_key] = val_part

    # Process environment variables
    for env_key, env_val in env.items():
        if not env_key.startswith("APP_"):
            continue
        
        # APP_DB__PORT -> db.port
        rest = env_key[4:] # Remove APP_
        processed_key = rest.replace("__", ".").lower()
        
        if processed_key in defaults:
            sources[processed_key] = "env"
            final_values[processed_key] = env_val

    # Type conversion and finalization
    for key, default_val in defaults.items():
        if sources[key] == "default":
            continue
        
        raw_val = final_values[key]
        target_type = type(default_val)
        
        try:
            if target_type is bool:
                # "A bool accepts true, false, 1, 0, yes and no without regard to case."
                s = str(raw_val).lower()
                if s in ("true", "1", "yes"):
                    final_values[key] = True
                elif s in ("false", "0", "no"):
                    final_values[key] = False
                else:
                    raise ValueError(f"Cannot convert {raw_val} to bool")
            elif target_type is int:
                # Python's int() handles strings like "123". 
                # If it's a float string like "1.0", it raises ValueError, which is correct.
                final_values[key] = int(raw_val)
            elif target_type is float:
                # Python's float() handles strings like "123" and "1.2".
                final_values[key] = float(raw_val)
            else: # str
                final_values[key] = str(raw_val)
        except (ValueError, TypeError):
            raise ValueError(f"Cannot convert {raw_val} to {target_type}")

    return Config(final_values, sources)
