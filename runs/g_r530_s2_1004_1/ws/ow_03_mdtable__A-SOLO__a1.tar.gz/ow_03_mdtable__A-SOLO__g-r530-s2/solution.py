import re
import unicodedata

def get_width(text):
    return sum(2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1 for ch in text)

def is_separator_row(cells):
    for cell in cells:
        if not re.fullmatch(r":?-+:?$", cell):
            return False
    return True

def get_true_cells(line):
    cells = []
    current_cell = ""
    in_code = False
    escaped = False
    for char in line:
        if escaped:
            current_cell += char
            escaped = False
        elif char == '\\':
            escaped = True
        elif char == '`':
            in_code = not in_code
            current_cell += char
        elif char == '|' and not in_code:
            cells.append(current_cell)
            current_cell = ""
        else:
            current_cell += char
    cells.append(current_cell)
    return cells

def get_separators(line):
    indices = []
    in_code = False
    escaped = False
    for idx, char in enumerate(line):
        if escaped:
            escaped = False
            continue
        if char == '\\':
            escaped = True
        elif char == '`':
            in_code = not in_code
        elif char == '|' and not in_code:
            indices.append(idx)
    return indices

def process_table(table_lines):
    rows = []
    for line in table_lines:
        cells = get_true_cells(line)
        rows.append(cells)

    num_cols = max(len(row) for row in rows)
    col_widths = [3] * num_cols
    
    for row in rows:
        for j, cell in enumerate(row):
            if j < num_cols:
                # A separator cell is one that matches :?-+:?
                if not re.fullmatch(r":?-+:?$", cell):
                    w = get_width(cell.strip())
                    if w > col_widths[j]:
                        col_widths[j] = w

    processed_rows = []
    for row in rows:
        new_row_cells = []
        for j in range(num_cols):
            cell_content = ""
            is_sep = False
            if j < len(row):
                cell_content = row[j]
                if re.fullmatch(r":?-+:?$", cell_content):
                    is_sep = True
            
            if is_sep:
                # "A separator cell keeps the alignment markers it had -- ---, :---, ---:, :--: -- and its dashes are stretched or shortened so that the cell fills the column width."
                content = cell_content.strip()
                prefix = ""
                if content.startswith(":"):
                    prefix = ":"
                    content = content[1:]
                suffix = ""
                if content.endswith(":"):
                    suffix = ":"
                    content = content[:-1]
                
                remaining_width = col_widths[j] - (1 if prefix else 0) - (1 if suffix else 0)
                # "its dashes are stretched or shortened"
                new_row_cells.append(prefix + "-" * max(1, remaining_width) + suffix)
            else:
                content = cell_content.strip()
                # "Cell text is stripped of surrounding whitespace and then padded on the right to the column's width."
                new_row_cells.append(content + " " * (col_widths[j] - get_width(content)))

        # Every rendered row begins with | and ends with |
        # neighbouring cells are joined by |
        # The contract says: "Every rendered row begins with | and ends with |"
        row_str = "| " + " | ".join(new_row_cells) + " |"
        processed_rows.append(row_str)

    return processed_rows

def realign(text):
    lines = list(text.splitlines(keepends=True))
    result = []
    i = 0
    while i < len(lines):
        line = lines[i]
        # Check if we are inside a fenced code block
        if line.strip().startswith("```") or line.strip().startswith("~~~"):
            fence_type = line.strip()[:3]
            i += 1
            while i < len(lines) and not (lines[i].strip().startswith(fence_type)):
                result.append(lines[i])
                i += 1
            if i < len(lines):
                result.append(lines[i])
                i += 1
            continue

        # Check if this line starts a table
        if i + 1 < len(lines):
            line1 = lines[i]
            line2 = lines[i+1]

            sep_indices1 = get_separators(line1)
            if sep_indices1:
                cells2 = get_true_cells(line2)
                if is_separator_row(cells2):
                    table_lines = []
                    curr_idx = i
                    while curr_idx < len(lines):
                        l = lines[curr_idx]
                        if not l.strip() or not get_separators(l):
                            break
                        table_lines.append(l)
                        curr_idx += 1
                    
                    processed_rows = process_table(table_lines)
                    # "Each line keeps the line ending it arrived with"
                    # For tables, we replace multiple lines with new ones.
                    # Let's use the line ending of the first line of the table for all rows.
                    first_line_ending = lines[i][-1] if i < len(lines) and lines[i] else ""
                    if not first_line_ending: # If no newline at all
                        # But a table usually has newlines. Let's check the last line of the original block.
                        last_line = lines[curr_idx-1]
                        first_line_ending = last_line[-1] if last_line else ""

                    for row in processed_rows:
                        # If it was \r\n, keep it.
                        if first_line_ending == "\n":
                            result.append(row + "\n")
                        elif first_line_ending == "\r\n":
                            result.append(row + "\r\n")
                        else:
                            # No newline at the end of the table block? 
                            # This is unlikely for a multi-line table but possible.
                            result.append(row)
                    
                    i = curr_idx
                    continue

        result.append(lines[i])
        i += 1
    return "".join(result)

if __name__ == "__main__":
    import sys
    # This part is for testing if needed, but the contract says solution.realign(text: str) -> str
    pass
