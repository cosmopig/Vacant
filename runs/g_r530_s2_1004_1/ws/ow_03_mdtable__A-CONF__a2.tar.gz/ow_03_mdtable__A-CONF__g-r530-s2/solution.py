import unicodedata
import re

def get_width(text):
    return sum(2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1 for ch in text)

def is_separator_row(cells):
    for cell in cells:
        if not re.fullmatch(r':?-+:?', cell):
            return False
    return True

def realign(text):
    lines = text.splitlines(keepends=True)
    output = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.strip().startswith("```") or line.strip().startswith("~~~"):
            fence_type = line.strip()[:3]
            output.append(line)
            i += 1
            while i < len(lines) and not (lines[i].strip().startswith(fence_type)):
                output.append(lines[i])
                i += 1
            if i < len(lines):
                output.append(lines[i])
                i += 1
            continue

        def has_valid_sep(s):
            in_code = False
            for idx, char in enumerate(s):
                if char == '`':
                    in_code = not in_code
                elif char == '|' and not in_code:
                    if idx == 0 or s[idx-1] != '\\':
                        return True
            return False

        is_table = False
        if i + 1 < len(lines):
            l1 = lines[i]
            l2 = lines[i+1]
            if has_valid_sep(l1):
                cells = []
                curr = ""
                in_code = False
                for char in l2:
                    if char == '`':
                        in_code = not in_code
                    elif char == '|' and not in_code:
                        cells.append(curr)
                        curr = ""
                    else:
                        curr += char
                cells.append(curr)
                if is_separator_row([c.strip() for c in cells]):
                    is_table = True

        if is_table:
            table_lines = []
            while i < len(lines):
                l = lines[i]
                if not l.strip() or not has_valid_sep(l):
                    break
                table_lines.append(l)
                i += 1
            
            processed_rows = []
            for rl in table_lines:
                cells = []
                curr = ""
                in_code = False
                j = 0
                while j < len(rl):
                    char = rl[j]
                    if char == '`':
                        in_code = not in_code
                    elif char == '|' and not in_code:
                        if j > 0 and rl[j-1] == '\\':
                            curr += char
                            j += 1
                        else:
                            cells.append(curr)
                            curr = ""
                            j += 1
                    else:
                        curr += char
                        j += 1
                cells.append(curr)
                if rl.strip().startswith('|') and rl.strip().endswith('|'):
                    processed_rows.append(cells[1:-1])
                elif rl.strip().startswith('|'):
                    processed_rows.append(cells[1:])
                else:
                    processed_rows.append(cells)

            num_cols = max(len(row) for row in processed_rows)
            col_widths = [3] * num_cols
            sep_row_indices = []
            for idx, rl in enumerate(table_lines):
                cells = []
                curr = ""
                in_code = False
                j = 0
                while j < len(rl):
                    char = rl[j]
                    if char == '`':
                        in_code = not in_code
                    elif char == '|' and not in_code:
                        if j > 0 and rl[j-1] == '\\':
                            curr += char
                            j += 1
                        else:
                            cells.append(curr)
                            curr = ""
                            j += 1
                    else:
                        curr += char
                        j += 1
                cells.append(curr)
                if rl.strip().startswith('|') and rl.strip().endswith('|'):
                    cells = cells[1:-1]
                elif rl.strip().startswith('|'):
                    cells = cells[1:]
                
                if is_separator_row([c.strip() for c in cells]):
                    sep_row_indices.append(idx)

            for idx, row in enumerate(processed_rows):
                if idx not in sep_row_indices:
                    for k, cell in enumerate(row):
                        w = get_width(cell.strip())
                        col_widths[k] = max(col_widths[k], w)

            final_table_lines = []
            for idx, rl in enumerate(table_lines):
                cells = []
                curr = ""
                in_code = False
                j = 0
                while j < len(rl):
                    char = rl[j]
                    if char == '`':
                        in_code = not in_code
                    elif char == '|' and not in_code:
                        if j > 0 and rl[j-1] == '\\':
                            curr += char
                            j += 1
                        else:
                            cells.append(curr)
                            curr = ""
                            j += 1
                    else:
                        curr += char
                        j += 1
                cells.append(curr)
                if rl.strip().startswith('|') and rl.strip().endswith('|'):
                    cells = cells[1:-1]
                elif rl.strip().startswith('|'):
                    cells = cells[1:]

                row = (cells + [""] * num_cols)[:num_cols]
                rendered_cells = []
                for k, cell in enumerate(row):
                    stripped = cell.strip()
                    if idx in sep_row_indices:
                        marker_left = stripped.startswith(':')
                        marker_right = stripped.endswith(':')
                        num_dashes = col_widths[k] - (1 if marker_left else 0) - (1 if marker_right else 0)
                        if num_dashes < 1: num_dashes = 1
                        new_cell = ("" if not marker_left else ":") + ("-" * num_dashes) + ("" if not marker_right else ":")
                        rendered_cells.append(new_cell)
                    else:
                        w = get_width(stripped)
                        padding = col_widths[k] - w
                        rendered_cells.append(stripped + (" " * padding))
                
                ending = ""
                if rl.endswith('\n'):
                    ending = '\n'
                    if rl.endswith('\r\n'):
                        ending = '\r\n'
                final_table_lines.append("| " + " | ".join(rendered_cells) + " |" + ending

            output.extend(final_table_lines)
            i += len(table_lines)
        else:
            output.append(line)
            i += 1
    return "".join(output)
