import re

class Version:
    def __init__(self, version_str):
        # A version is MAJOR.MINOR.PATCH, each a run of digits, 
        # optionally followed by - and a pre-release made of dot-separated identifiers 
        # drawn from letters, digits and hyphens. Nothing else is a version.
        pattern = r'^(\d+)\.(\d+)\.(\d+)(?:-(.*))?$'
        match = re.match(pattern, version_str)
        if not match:
            raise ValueError("Invalid version format")
        
        self.major = int(match.group(1))
        self.minor = int(match.group(2))
        self.patch = int(match.group(3))
        self.pre_release = match.group(4)
        
        if self.pre_release is not None:
            # The pre-release part must be dot-separated identifiers drawn from letters, digits and hyphens.
            if not re.match(r'^[a-zA-Z0-9.-]+$', self.pre_release):
                raise ValueError("Invalid pre-release format")
            
            # Also, "Nothing else is a version" might imply that the pre-release part 
            # cannot be empty if the hyphen is present. The regex (.*) allows it to be empty.
            if self.pre_release == "":
                raise ValueError("Empty pre-release")

        self.identifiers = []
        if self.pre_release:
            self.identifiers = self.pre_release.split('.')

    def compare(self, other_str):
        other = Version(other_str)
        
        # Compare MAJOR.MINOR.PATCH
        if self.major != other.major:
            return 1 if self.major > other.major else -1
        if self.minor != other.minor:
            return 1 if self.minor > other.minor else -1
        if self.patch != other.patch:
            return 1 if self.patch > other.patch else -1
        
        # A version carrying a pre-release is older than the same version without one.
        if self.pre_release is None and other.pre_release is not None:
            return 1
        if self.pre_release is not None and other.pre_release is None:
            return -1
        
        # If both have pre-releases, compare them identifier by identifier
        if self.pre_release is not None and other.pre_release is not None:
            for i in range(min(len(self.identifiers), len(other.identifiers))):
                id1 = self.identifiers[i]
                id2 = other.identifiers[i]
                
                is_digit1 = id1.isdigit()
                is_digit2 = id2.isdigit()
                
                if is_digit1 and is_digit2:
                    val1 = int(id1)
                    val2 = int(id2)
                    if val1 != val2:
                        return 1 if val1 > val2 else -1
                elif not is_digit1 and not is_digit2:
                    if id1 != id2:
                        return 1 if id1 > id2 else -1
                else:
                    # One is all-digits, one is not. All-digit identifier is older than one that is not.
                    return -1 if is_digit1 else 1
            
            # If every shared identifier is equal, the pre-release with more identifiers is the newer one.
            if len(self.identifiers) != len(other.identifiers):
                return 1 if len(self.identifiers) > len(other.identifiers) else -1
        
        return 0

    def satisfies(self, spec):
        conditions = [c.strip() for c in spec.split(',')]
        if not conditions or any(not c for c in conditions):
            raise ValueError("Empty condition")
            
        for cond in conditions:
            # The operator can be >=, >, <=, <, ==, !=
            match = re.match(r'^([>=<]+)(.*)$', cond)
            if not match:
                raise ValueError("Invalid condition")
            
            op = match.group(1)
            other_str = match.group(2).strip()
            if not other_str:
                 raise ValueError("Missing version in condition")
            
            # The operator must be one of the allowed ones
            if op not in ['>=', '>', '<=', '<', '==', '!=']:
                raise ValueError("Unrecognised operator")

            other = Version(other_str)
            cmp = self.compare(other_str)
            
            if op == '>':
                if not (cmp == 1): return False
            elif op == '>=':
                if not (cmp >= 0): return False
            elif op == '<':
                if not (cmp == -1): return False
            elif op == '<=':
                if not (cmp <= 0): return False
            elif op == '==':
                if not (cmp == 0): return False
            elif op == '!=':
                if not (cmp != 0): return False
        return True

