from .version import Version

def compare(a, b):
    return Version(a).compare(b)

def satisfies(version, spec):
    return Version(version).satisfies(spec)

# The contract says "solution.compare" and "solution.satisfies". 
# If the test runner imports solution and calls solution.compare(), we need to expose them.
