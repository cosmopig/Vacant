import unittest
from solution import compare, satisfies, Version

class TestVersion(unittest.TestCase):
    def test_compare(self):
        self.assertEqual(compare("1.0.0", "1.0.0"), 0)
        self.assertEqual(compare("2.0.0", "1.9.9"), 1)
        self.assertEqual(compare("1.10.0", "1.9.0"), 1)
        self.assertEqual(compare("1.0.0-alpha", "1.0.0"), -1)
        self.assertEqual(compare("1.0.0-alpha", "1.0.0-beta"), -1)
        self.assertEqual(compare("1.0.0-rc.2", "1.0.0-rc.1"), 1)
        self.assertEqual(compare("1.0.0-alpha.1", "1.0.0-alpha"), 1)
        self.assertEqual(compare("1.0.0-1", "1.0.0-a"), -1)
        self.assertEqual(compare("1.0.0-rc.1", "1.0.0-rc.1"), 0)

    def test_satisfies(self):
        self.assertTrue(satisfies("1.2.3", ">1.0.0"))
        self.assertTrue(satisfies("1.2.3", ">=1.2.3"))
        self.assertTrue(satisfies("1.2.3", "==1.2.3"))
        self.assertTrue(satisfies("1.2.3", "!=1.0.0"))
        self.assertTrue(satisfies("1.2.3", "<2.0.0"))
        self.assertTrue(satisfies("1.2.3", ">=1.0.0, <2.0.0"))
        self.assertTrue(satisfies("1.2.3", " >= 1.0.0 , < 2.0.0 "))
        self.assertFalse(satisfies("1.0.0", ">1.0.0"))
        self.assertFalse(satisfies("2.0.0", "<1.0.0"))

    def test_errors(self):
        with self.assertRaises(ValueError):
            Version("1.0")
        with self.assertRaises(ValueError):
            Version("v1.0.0")
        with self.assertRaises(ValueError):
            satisfies("1.0.0", "")
        with self.assertRaises(ValueError):
            satisfies("1.0.0", "??1.0.0")

if __name__ == "__main__":
    unittest.main()
