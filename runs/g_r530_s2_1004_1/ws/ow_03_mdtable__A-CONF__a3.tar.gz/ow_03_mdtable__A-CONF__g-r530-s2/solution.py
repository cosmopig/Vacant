import unicodedata
import re

def get_width(text):
    return sum(2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1 for ch in text)

class TableRealigner:
    def __init__(self, text):
        self.lines = text.splitlines(keepends=True)

    def is_separator_row(self, row_cells):
        for cell in row_cells:
            s = cell.strip()
            if not re.fullmatch(r':?-+:??', s):
                return False
        return True

    def find_valid_pipes(self, line):
        pipes = []
        in_code = False
        i = 0
        while i < len(line):
            if line[i] == '`' and (i == 0 or line[i-1] != '\\'):
                in_code = not in_code
            elif line[i] == '|' and not in_code:
                if i == 0 or line[i-1] != '\\':
                    pipes.append(i)
            i += 1
        return pipes

    def parse_table(self, start_idx):
        lines = self.lines[start_idx:]
        if not lines: return None, start_idx
        
        first_line = lines[0]
        first_line_pipes = self.find_valid_pipes(first_line)
        if len(first_line_pipes) < 2:
            return None, start_idx + 1

        if len(lines) < 2:
            return None, start_idx + 1
        
        second_line = lines[1]
        second_line_pipes = self.find_valid_pipes(second_line)
        
        raw_cells_2 = []
        prev_p = -1
        for p in second_line_pipes:
            raw_cells_2.append(second_line[prev_p+1:p])
            prev_p = p
        raw_cells_2.append(second_line[prev_p+1:])

        if not self.is_separator_row(raw_cells_2):
            return None, start_idx + 1

        table_lines = []
        curr_idx = start_idx
        while curr_idx < len(self.lines):
            l = self.lines[curr_idx]
            if not l.strip():
                break
            pipes = self.find_valid_pipes(l)
            if len(pipes) < 2:
                break
            table_lines.append(l)
            curr_idx += 1
        
        return table_lines, curr_idx

    def process_table(self, table_lines):
        rows = []
        for line in table_lines:
            pipes = self.find_valid_pipes(line)
            cells = []
            prev_p = -1
            for p in pipes:
                cells.append(line[prev_p+1:p])
                prev_p = p
            cells.append(line[prev_p+1:])
            rows.append(cells)

        num_cols = max(len(row) for row in rows)
        col_widths = [3] * num_cols
        alignments = [0] * num_cols # 0=left, 1=center, 2=right

        for r_idx, row in enumerate(rows):
            if r_idx == 1:
                # Separator row for alignments
                sep_row = rows[1]
                for c_idx in range(num_cols):
                    cell = sep_row[c_idx].strip() if c_idx < len(sep_row) else ""
                    if cell.startswith(':') and cell.endswith(':'):
                        alignments[c_idx] = 1
                    elif cell.startswith(':'):
                        alignments[c_idx] = 0
                    elif cell.endswith(':'):
                        alignments[c_idx] = 2
            else:
                for c_idx in range(num_cols):
                    cell = row[c_idx].strip() if c_idx < len(row) else ""
                    w = get_width(cell)
                    col_widths[c_idx] = max(col_widths[c_idx], w)

        def format_cell(content, width, align):
            content = content.strip()
            w = get_width(content)
            if align == 1: # Center
                diff = width - w
                pad_l = diff // 2
                pad_r = diff - pad_l
                return (" " * pad_l) + content + (" " * pad_r)
            elif align == 2: # Right
                pad_l = width - w
                return (" " * pad_l) + content
            else: # Left
                pad_r = width - w
                return content + (" " * pad_r)

        formatted_rows = []
        for r_idx, row in enumerate(rows):
            new_row = []
            for c_idx in range(num_cols):
                cell = row[c_idx].strip() if c_idx < len(row) else ""
                if r_idx == 1:
                    sep = rows[1][c_idx].strip() if c_idx < len(rows[1]) else ""
                    marker_l = sep.startswith(':')
                    marker_r = sep.endswith(':')
                    content_width = col_widths[c_idx] - (1 if marker_l else 0) - (1 if marker_r else 0)
                    res = ""
                    if marker_l: res += ":"
                    res += "-" * content_width
                    if marker_r: res += ":"
                    new_row.append(res)
                else:
                    new_row.append(format_cell(cell, col_widths[c_idx], alignments[c_idx]))
            formatted_rows.append("| " + " | ".join(new_row) + " |")

        final_lines = []
        for r_idx in range(len(table_lines)):
            original_line = table_lines[r_idx]
            newline = ""
            if '\n' in original_line:
                newline = original_line.split('\n', 1)[1]
            final_lines.append(formatted_rows[r_idx] + newline)
        return final_lines

    def realign(self, text):
        output = []
        i = 0
        while i < len(self.lines):
            line = self.lines[i]
            if line.startswith('```') or line.startswith('~~~'):
                block_type = '```' if line.startswith('```') else '~~~'
                output.append(line)
                i += 1
                while i < len(self.lines) and not (self.lines[i].startswith(block_type)):
                    output.append(self.lines[i])
                    i += 1
                if i < len(self.lines):
                    output.append(self.lines[i])
                    i += 1
                continue

            table_data = self.parse_table(i)
            if table_data:
                table_lines, next_idx = table_data
                processed_table = self.process_table(table_lines)
                output.extend(processed_table)
                i = next_idx
            else:
                output.append(line)
                i += 1
        return "".join(output)

def realign(text):
    realigner = TableRealigner(text)
    return realigner.realign(text)
