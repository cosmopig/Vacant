import datetime
import math
import json
from typing import Iterable, Dict, List, Any

def summarize(lines: Iterable[str]) -> Dict[str, Any]:
    endpoints = {}
    bad_lines = 0
    total = 0
    
    for line in lines:
        line = line.rstrip('\n')
        if not line or line.isspace():
            continue
        
        total += 1
        parts = line.split(' ')
        
        # Check if exactly five fields
        if len(parts) != 5:
            bad_lines += 1
            continue
            
        timestamp_str, method, path, status_str, ms_str = parts
        
        # Validate timestamp
        try:
            ts_to_parse = timestamp_str.replace('Z', '+00:00')
            datetime.datetime.fromisoformat(ts_to_parse)
        except (ValueError, TypeError):
            bad_lines += 1
            continue
            
        # Validate status and ms (digits with optional leading -)
        def is_valid_num_str(s):
            if not s: return False
            if s[0] == '-':
                return len(s) > 1 and s[1:].isdigit()
            return s.isdigit()

        if not is_valid_num_str(status_str) or not is_valid_num_str(ms_str):
            bad_lines += 1
            continue
            
        try:
            status = int(status_str)
            ms = int(ms_str)
        except ValueError:
            bad_lines += 1
            continue

        if path not in endpoints:
            endpoints[path] = {"n": 0, "errors": 0, "ms_list": []}
        
        endpoints[path]["n"] += 1
        if status >= 500:
            endpoints[path]["errors"] += 1
        endpoints[path]["ms_list"].append(ms)

    result_endpoints = []
    for path, data in endpoints.items():
        n = data["n"]
        error_rate = round(data["errors"] / n, 4)
        
        # Percentiles: ceil(p / 100 * n)
        sorted_ms = sorted(data["ms_list"])
        p50_idx = math.ceil(50 / 100 * n) - 1
        p95_idx = math.ceil(95 / 100 * n) - 1
        
        # Ensure indices are within bounds (should be, but just in case)
        p50_ms = sorted_ms[max(0, min(len(sorted_ms) - 1, p50_idx))]
        p95_ms = sorted_ms[max(0, min(len(sorted_ms) - 1, p95_idx))]
        
        result_endpoints.append({
            "path": path,
            "n": n,
            "error_rate": error_rate,
            "p50_ms": p50_ms,
            "p95_ms": p95_ms
        })

    # Sort: n DESC, then path ASC
    result_endpoints.sort(key=lambda x: (-x["n"], x["path"]))

    return {
        "endpoints": result_endpoints,
        "bad_lines": bad_lines,
        "total": total
    }
