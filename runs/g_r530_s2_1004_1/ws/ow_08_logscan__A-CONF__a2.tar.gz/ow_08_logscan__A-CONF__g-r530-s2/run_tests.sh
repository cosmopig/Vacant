#!/bin/bash
# This script is already provided, but let's make sure it's executable.
chmod +x run_tests.sh
./run_tests.sh
