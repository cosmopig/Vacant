import csv
import json
import sys
import io

def csv_to_jsonl(text: str) -> str:
    if not text or not text.strip():
        return ""
    
    # Find all physical line start positions (1-based).
    line_starts = []
    pos = 0
    i = 0
    while i < len(text):
        line_starts.append(pos)
        if text[i:i+2] == '\r\n':
            pos += 2
            i += 2
        elif text[i] == '\n':
            pos += 1
            i += 1
        elif text[i] == '\r':
            # The requirement says "\n" and "\r\n" are accepted as line endings.
            # If we see \r not followed by \n, it's still a line ending in many systems.
            pos += 1
            i += 1
        else:
            i += 1

    def get_line_num(pos):
        for i, start in enumerate(line_starts):
            if pos >= start:
                return i + 1
        return len(line_starts)

    # We need to find the starting position of each record.
    # A record starts at index 0 or after a newline that is not inside quotes.
    record_starts = [0]
    in_quotes = False
    i = 0
    while i < len(text):
        char = text[i]
        if char == '"':
            # Check for escaped quote ""
            if i + 1 < len(text) and text[i+1] == '"':
                i += 2
                continue
            in_quotes = not in_quotes
            i += 1
        elif not in_quotes:
            if char == '\n' or char == '\r':
                # Found a newline outside of quotes. This is the start of a new record!
                record_starts.append(i + 1)
                if char == '\r' and i + 1 < len(text) and text[i+1] == '\n':
                    i += 2
                else:
                    i += 1
            else:
                i += 1
        else:
            i += 1

    f = io.StringIO(text)
    # We use the csv module to parse the rows correctly.
    reader = csv.reader(f)
    
    try:
        header = next(reader)
    except StopIteration:
        return ""

    # Handle duplicate headers: last occurrence wins
    header_map = {}
    for i, h in enumerate(header):
        header_map[h] = i
    
    num_cols = len(header)
    output = []
    
    current_row_idx = 0
    try:
        # We need to iterate through the rows and keep track of which record start we are on.
        for row in reader:
            if len(row) != num_cols:
                raise ValueError(f"line {get_line_num(record_starts[current_row_idx])}: field count differs from the header")
            
            # Create a dictionary for the row, using the last occurrence of each header name.
            row_dict = {}
            for i, val in enumerate(row):
                h_name = header[i]
                row_dict[h_name] = val
            
            output.append(json.dumps(row_dict))
            current_row_idx += 1
            
    except ValueError as e:
        raise e
    except Exception as e:
        # This handles cases like unclosed quotes which csv.reader might raise.
        # But we need to know WHICH record started that error.
        # The csv module doesn't make this easy. Let's see if there's a better way.
        raise ValueError(f"line {get_line_num(record_starts[current_row_idx])}: invalid input")

    return "\n".join(output) + ("\n" if output else "")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(0)
    
    try:
        with open(sys.argv[1], 'r', encoding='utf-8') as f:
            content = f.read()
        result = csv_to_jsonl(content)
        sys.stdout.write(result)
        sys.exit(0)
    except ValueError as e:
        sys.stderr.write(str(e) + "\n")
        sys.exit(2)
    except Exception:
        sys.stderr.write("line 1: unexpected error\n")
        sys.exit(2)
