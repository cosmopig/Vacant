from .csv_to_jsonl import csv_to_jsonl
import sys

def main():
    if len(sys.argv) != 2:
        return
    
    try:
        with open(sys.argv[1], 'r', encoding='utf-8') as f:
            content = f.read()
        result = csv_to_jsonl(content)
        sys.stdout.write(result)
        sys.exit(0)
    except ValueError as e:
        sys.stderr.write(str(e) + "\n")
        sys.exit(2)
    except Exception:
        # The requirements say only one line of error message should be written to stderr.
        # We don't know what the exact reason is for other exceptions, 
        # but we must follow the contract.
        sys.stderr.write("line 1: unexpected error\n")
        sys.exit(2)

if __name__ == "__main__":
    main()
