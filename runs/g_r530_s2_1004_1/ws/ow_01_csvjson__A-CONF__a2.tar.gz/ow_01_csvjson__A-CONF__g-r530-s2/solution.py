import csv
import json
import sys
import io

def csv_to_jsonl(text: str) -> str:
    if not text or not text.strip():
        return ""
    
    # Find all positions where a new line starts in the CSV file (not inside quotes).
    line_starts = []
    in_quotes = False
    i = 0
    while i < len(text):
        char = text[i]
        if char == '"':
            if in_quotes and i + 1 < len(text) and text[i+1] == '"':
                i += 1
            else:
                in_quotes = not in_quotes
        elif char == '\n' and not in_quotes:
            line_starts.append(i + 1)
        elif char == '\r' and not in_quotes:
            if i + 1 < len(text) and text[i+1] == '\n':
                line_starts.append(i + 2)
            else:
                line_starts.append(i + 1)
        i += 1

    # A record starts at index 0 or after a newline that is not inside quotes.
    chunks = []
    for k in range(len(line_starts)):
        start = line_starts[k]
        end = line_starts[k+1] if k+1 < len(line_starts) else len(text)
        chunk = text[start:end]
        # "A completely empty line is ignored." 
        if chunk == "" or chunk == "\n" or chunk == "\r\n":
            continue
        chunks.append((chunk, k))

    header = None
    all_rows = []
    for chunk, _ in chunks:
        f = io.StringIO(chunk)
        reader = csv.reader(f)
        try:
            row = next(reader)
            if header is None:
                header = row
            else:
                all_rows.append(row)
        except StopIteration:
            pass

    # Check for unclosed quotes in the entire text first as a simple check.
    in_quotes = False
    for i, char in enumerate(text):
        if char == '"':
            if i + 1 < len(text) and text[i+1] == '"':
                pass
            else:
                in_quotes = not in_quotes
    if in_quotes:
        # Find the last line start to report it.
        last_start = line_starts[-1] if line_starts else 0
        # Wait, we need the actual line number of that position.
        # Let's just find the first newline not in quotes and use its index.
        pass

    if header is None:
        return ""

    num_fields = len(header)
    output = []
    for row in all_rows:
        if len(row) != num_fields:
            # This should be handled by our chunking, but let's be safe.
            pass

    # Let's use a different approach for error handling and line numbers.
    # The csv module is great but doesn't give us start lines easily.
    # However, if we know that every newline not in quotes marks a new record...
    # We can just iterate through the chunks and find which one was broken.

    pass

