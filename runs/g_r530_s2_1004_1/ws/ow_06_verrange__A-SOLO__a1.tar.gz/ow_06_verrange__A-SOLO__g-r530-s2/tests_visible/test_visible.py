import unittest
from solution import Version, compare, satisfies

class TestVersion(unittest.TestCase):
    def test_parsing(self):
        # A version is MAJOR.MINOR.PATCH, each a run of digits, optionally followed by
        # - and a pre-release made of dot-separated identifiers drawn from letters,
        # digits and hyphens. Nothing else is a version.
        self.assertEqual(Version("1.2.3").to_tuple(), (1, 2, 3, []))
        self.assertEqual(Version("1.2.3-alpha.1").to_tuple(), (1, 2, 3, ["alpha", "1"]))
        self.assertEqual(Version("1.2.3-01").to_tuple(), (1, 2, 3, ["01"]))

    def test_compare_basic(self):
        # The three numbers are compared as numbers, most significant first.
        self.assertEqual(compare("1.9", "1.10"), -1)
        self.assertEqual(compare("1.10", "1.9"), 1)
        self.assertEqual(compare("2.0.0", "1.9.9"), 1)

    def test_compare_pre_release(self):
        # A version carrying a pre-release is older than the same version without one.
        self.assertEqual(compare("1.0.0-alpha", "1.0.0"), -1)
        # Two pre-releases of the same version also have to sort among themselves: 
        # rc.2 comes after rc.1, alpha comes before beta, and a pre-release with more parts is newer than the same pre-release with fewer.
        self.assertEqual(compare("1.0.0-rc.1", "1.0.0-rc.2"), -1)
        self.assertEqual(compare("1.0.0-alpha", "1.0.0-beta"), -1)
        self.assertEqual(compare("1.0.0-alpha.1", "1.0.0-alpha"), -1)

    def test_compare_pre_release_types(self):
        # an identifier made only of digits is compared by value, 
        # any other identifier is compared by ASCII, and
        # an all-digit identifier is older than one that is not.
        self.assertEqual(compare("1.0.0-1", "1.0.0-2"), -1)
        self.assertEqual(compare("1.0.0-a", "1.0.0-b"), -1)
        # all-digit identifier is older than one that is not (if they are otherwise same?) 
        # Wait, the rule says: "an identifier made only of digits is compared by value, 
        # any other identifier is compared by ASCII, and
        # an all-digit identifier is older than one that is not."
        self.assertEqual(compare("1.0.0-1", "1.0.0-a"), -1)

    def test_satisfies(self):
        self.assertTrue(satisfies("1.2.3", ">=1.2.0"))
        self.assertTrue(satisfies("1.2.3", ">1.2.2"))
        self.assertTrue(satisfies("1.2.3", "<=1.2.3"))
        self.assertTrue(satisfies("1.2.3", "<1.2.4"))
        self.assertTrue(satisfies("1.2.3", "==1.2.3"))
        self.assertTrue(satisfies("1.2.3", "!=1.2.4"))
        self.assertTrue(satisfies("1.2.3", ">=1.0.0, <2.0.0"))
        self.assertFalse(satisfies("1.2.3", ">1.2.4"))
        self.assertFalse(satisfies("1.2.3", "<1.2.2"))

    def test_errors(self):
        with self.assertRaises(ValueError):
            Version("1.2")
        with self.assertRaises(ValueError):
            Version("1.2.3-alpha..1")
        with self.assertRaises(ValueError):
            Version("v1.2.3")
        with self.assertRaises(ValueError):
            Version("1.2.3-")
        with self.assertRaises(ValueError):
            Version("1.2.3-alpha_beta") # hyphen is allowed, underscore is not? "letters, digits and hyphens"

if __name__ == "__main__":
    unittest.main()
