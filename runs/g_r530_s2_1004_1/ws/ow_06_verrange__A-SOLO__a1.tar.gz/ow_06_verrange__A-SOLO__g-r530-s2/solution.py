import re

class Version:
    def __init__(self, version_str):
        # A version is MAJOR.MINOR.PATCH, each a run of digits, optionally followed by
        # - and a pre-release made of dot-separated identifiers drawn from letters,
        # digits and hyphens. Nothing else is a version.
        
        match = re.fullmatch(r"(\d+)\.(\d+)\.(\d+)(?:-(.*))?", version_str)
        if not match:
            raise ValueError("Invalid version format")
        
        self.major = int(match.group(1))
        self.minor = int(match.group(2))
        self.patch = int(match.group(3))
        pre_release_str = match.group(4)
        
        if pre_release_str is None:
            self.pre_release = []
        else:
            # Pre-release made of dot-separated identifiers drawn from letters, digits and hyphens.
            # Nothing else is a version. This means the whole string after '-' must be valid.
            if not pre_release_str or any(not (('a' <= c <= 'z') or ('A' <= c <= 'Z') or ('0' <= c <= '9') or c == '-') for c in pre_release_str):
                raise ValueError("Invalid pre-release format")
            
            parts = pre_release_str.split('.')
            if any(not p for p in parts): # No empty identifiers (e.g., "alpha..1" or "-.")
                 raise ValueError("Empty identifier in pre-release")
            self.pre_release = parts

    def to_tuple(self):
        return (self.major, self.minor, self.patch, self.pre_release)

    def compare(self, other):
        if isinstance(other, str):
            other_v = Version(other)
        else:
            other_v = other

        # The three numbers are compared as numbers, most significant first.
        if self.major != other_v.major:
            return 1 if self.major > other_v.major else -1
        if self.minor != other_v.minor:
            return 1 if self.minor > other_v.minor else -1
        if self.patch != other_v.patch:
            return 1 if self.patch > other_v.patch else -1
        
        # A version carrying a pre-release is older than the same version without one.
        if not self.pre_release and other_v.pre_release:
            return 1
        if self.pre_release and not other_v.pre_release:
            return -1
        if not self.pre_release and not other_v.pre_release:
            return 0
        
        # Two pre-releases are compared identifier by identifier:
        # an identifier made only of digits is compared by value,
        # any other identifier is compared by ASCII, and
        # an all-digit identifier is older than one that is not.
        for p1, p2 in zip(self.pre_release, other_v.pre_release):
            is_p1_digit = p1.isdigit()
            is_p2_digit = p2.isdigit()
            
            if is_p1_digit and is_p2_digit:
                val1 = int(p1)
                val2 = int(p2)
                if val1 != val2:
                    return 1 if val1 > val2 else -1
            elif not is_p1_digit and not is_p2_digit:
                if p1 != p2:
                    return 1 if p1 > p2 else -1
            else:
                # One is all-digit, one is not. All-digit is older.
                return -1 if is_p1_digit else 1
        
        # If every shared identifier is equal, the pre-release with more identifiers is the newer one.
        if len(self.pre_release) != len(other_v.pre_release):
            return 1 if len(self.pre_release) > len(other_v.pre_release) else -1
        
        return 0

    def satisfies(self, spec):
        raw_conditions = spec.split(',')
        if not raw_conditions or (len(raw_conditions) == 1 and not raw_conditions[0].strip()):
            # Wait, the requirement says "a spec with an empty condition" raises ValueError.
            # If there's no comma, it's one condition. If it's empty, it's a problem.
            if not spec.strip():
                raise ValueError("Empty spec")
        
        conditions = []
        for rc in raw_conditions:
            cond = rc.strip()
            if not cond:
                raise ValueError("Empty condition")
            conditions.append(cond)

        for cond in conditions:
            match = re.fullmatch(r"(>=|<=|==|!=|>|<)\s*(\d+\.\d+\.\d+(?:-[a-zA-Z0-9.-]+)?)", cond)
            if not match:
                raise ValueError("Invalid condition")
            
            op = match.group(1)
            other_v_str = match.group(2)
            try:
                other_v = Version(other_v_str)
            except ValueError:
                raise ValueError("Invalid version in condition")

            res = self.compare(other_v)
            if op == "==":
                if res != 0: return False
            elif op == "!=":
                if res == 0: return False
            elif op == ">":
                if res <= 0: return False
            elif op == ">=":
                if res < 0: return False
            elif op == "<":
                if res >= 0: return False
            elif op == "<=":
                if res > 0: return False
        return True

def compare(a: str, b: str) -> int:
    v1 = Version(a)
    v2 = Version(b)
    return v1.compare(v2)

def satisfies(version: str, spec: str) -> bool:
    v = Version(version)
    return v.satisfies(spec)
