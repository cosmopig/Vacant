import datetime
import math
import json
from typing import Iterable, Dict, List, Any

def summarize(lines: Iterable[str]) -> Dict[str, Any]:
    endpoints = {}
    bad_lines = 0
    total = 0

    for line in lines:
        line = line.rstrip('\n')
        if not line or line.isspace():
            continue
        
        total += 1
        parts = line.split(' ')
        
        # Check if exactly five fields
        if len(parts) != 5:
            bad_lines += 1
            continue
            
        ts_str, method, path, status_str, ms_str = parts
        
        # Validate timestamp
        try:
            dt_str = ts_str.replace('Z', '+00:00')
            datetime.datetime.fromisoformat(dt_str)
        except ValueError:
            bad_lines += 1
            continue

        # Validate status and ms (digits with optional leading -)
        def is_valid_num_str(s):
            if not s: return False
            if s[0] == '-':
                return len(s) > 1 and s[1:].isdigit()
            return s.isdigit()

        if not is_valid_num_str(status_str) or not is_valid_num_str(ms_str):
            bad_lines += 1
            continue

        try:
            status = int(status_str)
            ms = int(ms_str)
        except ValueError:
            bad_lines += 1
            continue

        if path not in endpoints:
            endpoints[path] = {"n": 0, "errors": 0, "ms_list": []}
        
        endpoints[path]["n"] += 1
        if status >= 500:
            endpoints[path]["errors"] += 1
        endpoints[path]["ms_list"].append(ms)

    results = []
    for path, data in endpoints.items():
        n = data["n"]
        errors = data["errors"]
        ms_list = sorted(data["ms_list"])
        
        error_rate = round(errors / n, 4) if n > 0 else 0.0
        
        # Nearest-rank percentiles: the p-th percentile of n sorted values is the one at 1-based position ceil(p / 100 * n).
        # Since our list is 0-indexed, we subtract 1 from the result of math.ceil.
        p50_idx = math.ceil(0.50 * n) - 1
        p95_idx = math.ceil(0.95 * n) - 1
        
        # Ensure indices are within bounds (should be if n > 0)
        p50_ms = ms_list[max(0, min(p50_idx, n - 1))]
        p95_ms = ms_list[max(0, min(p95_idx, n - 1))]

        results.append({
            "path": path,
            "n": n,
            "error_rate": error_rate,
            "p50_ms": p50_ms,
            "p95_ms": p95_ms
        })

    # Sort: n DESC, then path ASC
    results.sort(key=lambda x: (-x["n"], x["path"]))

    return {
        "endpoints": results,
        "bad_lines": bad_lines,
        "total": total
    }
