import sys
import json
from solution import summarize

def main():
    if len(sys.argv) != 2:
        return
    filename = sys.argv[1]
    try:
        with open(filename, 'r') as f:
            lines = f.readlines()
        result = summarize(lines)
        print(json.dumps(result))
    except FileNotFoundError:
        pass

if __name__ == "__main__":
    main()
