import unittest
from solution import Version

class TestVersion(unittest.TestCase):
    def test_parsing(self):
        self.assertEqual(Version("1.2.3"), (1, 2, 3, []))
        self.assertEqual(Version("1.2.3-alpha.1"), (1, 2, 3, ["alpha", "1"]))
        self.assertEqual(Version("1.0.0-rc.2"), (1, 0, 0, ["rc", "2"]))

    def test_compare(self):
        self.assertEqual(Version("1.9").compare("1.10"), -1)
        self.assertEqual(Version("1.10").compare("1.9"), 1)
        self.assertEqual(Version("1.2.3").compare("1.2.3"), 0)
        self.assertEqual(Version("1.2.3-alpha").compare("1.2.3"), -1)
        self.assertEqual(Version("1.2.3").compare("1.2.3-alpha"), 1)
        # Pre-release comparison: rc.2 > rc.1
        self.assertEqual(Version("1.0.0-rc.2").compare("1.0.0-rc.1"), 1)
        # alpha < beta
        self.assertEqual(Version("1.0.0-alpha").compare("1.0.0-beta"), -1)
        # all-digit vs non-all-digit: "1" is older than "a" (if same value? no, compare by ASCII if not both digits)
        # Actually: "an all-digit identifier is older than one that is not."
        self.assertEqual(Version("1.0.0-1").compare("1.0.0-a"), -1)
        # More identifiers are newer
        self.assertEqual(Version("1.0.0-alpha.1").compare("1.0.0-alpha"), 1)

    def test_satisfies(self):
        self.assertTrue(Version("1.2.3").satisfies(">=1.2.3"))
        self.assertTrue(Version("1.2.4").satisfies(">=1.2.3"))
        self.assertTrue(Version("1.2.3").satisfies(">1.2.2"))
        self.assertTrue(Version("1.2.3").satisfies("<1.2.4"))
        self.assertTrue(Version("1.2.3").satisfies("==1.2.3"))
        self.assertTrue(Version("1.2.3").satisfies("!=1.2.4"))
        self.assertTrue(Version("1.2.3").satisfies(">=1.0.0, <2.0.0"))
        self.assertTrue(Version("1.2.3").satisfies(" >= 1.0.0 , < 2.0.0 "))
        # Pre-release check: 1.2.3 is newer than 1.2.3-alpha
        self.assertTrue(Version("1.2.3").satisfies(">1.2.3-alpha"))

if __name__ == "__main__":
    unittest.main()
