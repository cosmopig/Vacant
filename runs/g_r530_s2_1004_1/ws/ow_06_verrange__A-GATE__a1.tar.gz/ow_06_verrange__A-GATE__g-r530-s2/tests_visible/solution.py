import re

class Version:
    def __init__(self, version_str):
        # A version is MAJOR.MINOR.PATCH, each a run of digits, optionally followed by - and pre-release
        match = re.fullmatch(r"(\d+)\.(\d+)\.(\d+)(?:-(.*))?", version_str)
        if not match:
            raise ValueError("Invalid version format")
        
        self.major = int(match.group(1))
        self.minor = int(match.group(2))
        self.patch = int(match.group(3))
        
        pre_release_str = match.group(4)
        if pre_release_str is None:
            self.pre_release = []
        else:
            # Pre-release made of dot-separated identifiers drawn from letters, digits and hyphens.
            parts = pre_release_str.split('.')
            if any(not p or not re.fullmatch(r"[a-zA-Z0-9\-]+", p) for p in parts):
                raise ValueError("Invalid pre-release format")
            self.pre_release = parts

    def __eq__(self, other):
        if isinstance(other, tuple):
            return (self.major, self.minor, self.patch, self.pre_release) == other
        if not isinstance(other, Version):
            return False
        return (self.major, self.minor, self.patch, self.pre_release) == \
               (other.major, other.minor, other.patch, other.pre_release)

    def __ne__(self, other):
        return not self.__eq__(other)

    def compare(self, other_str: str) -> int:
        other = Version(other_str)
        
        # Compare MAJOR.MINOR.PATCH
        if self.major != other.major:
            return 1 if self.major > other.major else -1
        if self.minor != other.minor:
            return 1 if self.minor > other.minor else -1
        if self.patch != other.patch:
            return 1 if self.patch > other.patch else -1
        
        # A version carrying a pre-release is older than the same version without one.
        if not self.pre_release and other.pre_release:
            return 1
        if self.pre_release and not other.pre_release:
            return -1
        
        # If both have pre-releases, compare them identifier by identifier
        if self.pre_release and other.pre_release:
            for p1, p2 in zip(self.pre_release, other.pre_release):
                is_p1_digit = p1.isdigit()
                is_p2_digit = p2.isdigit()
                
                if is_p1_digit and is_p2_digit:
                    v1, v2 = int(p1), int(p2)
                    if v1 != v2:
                        return 1 if v1 > v2 else -1
                elif not is_p1_digit and not is_p2_digit:
                    if p1 != p2:
                        return 1 if p1 > p2 else -1
                else:
                    # an all-digit identifier is older than one that is not.
                    return -1 if is_p1_digit else 1
            
            # If every shared identifier is equal, the pre-release with more identifiers is the newer one.
            if len(self.pre_release) != len(other.pre_release):
                return 1 if len(self.pre_release) > len(other.pre_release) else -1
        
        return 0

    def satisfies(self, spec: str) -> bool:
        conditions = [c.strip() for c in spec.split(',')]
        if not conditions or any(not c for c in conditions):
            raise ValueError("Empty condition in spec")
            
        for cond in conditions:
            match = re.fullmatch(r"(>=|<=|>|<|==|!=)\s*(\d+\.\d+\.\d+(?:-[a-zA-Z0-9\-.]+)*)", cond)
            if not match:
                raise ValueError("Invalid condition format")
            
            op = match.group(1)
            other_version_str = match.group(2)
            res = self.compare(other_version_str)
            
            if op == "==":
                if res != 0: return False
            elif op == ">":
                if res <= 0: return False
            elif op == "<":
                if res >= 0: return False
            elif op == ">=":
                if res < 0: return False
            elif op == "<=":
                if res > 0: return False
            elif op == "!=":
                if res == 0: return False
        return True

def compare(a: str, b: str) -> int:
    return Version(a).compare(b)

def satisfies(version_str: str, spec: str) -> bool:
    return Version(version_str).satisfies(spec)
