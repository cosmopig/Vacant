import unittest
from solution import Version

class TestVersion(unittest.TestCase):
    def test_parsing(self):
        self.assertEqual(Version("1.2.3"), (1, 2, 3))
        self.assertEqual(Version("10.0.1"), (10, 0, 1))
        with self.assertRaises(ValueError):
            Version("1.a.3")
        with self.assertRaises(ValueError):
            Version("1.2.3-")
        with self.assertRaises(ValueError):
            Version("v1.2.3")

    def test_compare(self):
        self.assertEqual(Version("1.2.3").compare("1.2.3"), 0)
        self.assertEqual(Version("1.2.4").compare("1.2.3"), 1)
        self.assertEqual(Version("1.2.3").compare("1.2.4"), -1)
        self.assertEqual(Version("1.10.0").compare("1.9.0"), 1)
        self.assertEqual(Version("2.0.0").compare("1.9.9"), 1)

    def test_pre_release_basic(self):
        # A version carrying a pre-release is older than the same version without one.
        self.assertEqual(Version("1.0.0-alpha").compare("1.0.0"), -1)
        self.assertEqual(Version("1.0.0").compare("1.0.0-alpha"), 1)

    def test_pre_release_comparison(self):
        # rc.2 comes after rc.1, alpha comes before beta, and a pre-release with more parts is newer than the same pre-release with fewer.
        self.assertEqual(Version("1.0.0-rc.1").compare("1.0.0-rc.2"), -1)
        self.assertEqual(Version("1.0.0-alpha").compare("1.0.0-beta"), -1)
        # "pre-release with more parts is newer than the same pre-release with fewer"
        # Wait, if every shared identifier is equal, the pre-release with more identifiers is the newer one.
        self.assertEqual(Version("1.0.0-rc.1").compare("1.0.0-rc.1.1"), -1)

    def test_pre_release_types(self):
        # an identifier made only of digits is compared by value, any other identifier is compared by ASCII, and
        # an all-digit identifier is older than one that is not.
        # "rc.1" vs "rc.a": '1' is digit, 'a' is not. Digit < non-digit? 
        # The rule says: "an all-digit identifier is older than one that is not."
        self.assertEqual(Version("1.0.0-rc.1").compare("1.0.0-rc.a"), -1)
        # "2" vs "10": both digits, compared by value.
        self.assertEqual(Version("1.0.0-rc.2").compare("1.0.0-rc.10"), -1)
        # "alpha" vs "beta": both non-digits, compared by ASCII.
        self.assertEqual(Version("1.0.0-alpha").compare("1.0.0-beta"), -1)

    def test_satisfies(self):
        v = Version("1.2.3")
        self.assertTrue(v.satisfies(">=1.0.0"))
        self.assertTrue(v.satisfies(">1.0.0, <=2.0.0"))
        self.assertTrue(v.satisfies("==1.2.3"))
        self.assertFalse(v.satisfies(">2.0.0"))
        self.assertFalse(v.satisfies("<1.0.0"))
        self.assertFalse(v.satisfies("!=1.2.3"))

    def test_satisfies_errors(self):
        with self.assertRaises(ValueError):
            Version("1.2.3").satisfies("")
        with self.assertRaises(ValueError):
            Version("1.2.3").satisfies(">>1.0.0")
        with self.assertRaises(ValueError):
            Version("1.2.3").satisfies(">=abc")

if __name__ == "__main__":
    unittest.main()
