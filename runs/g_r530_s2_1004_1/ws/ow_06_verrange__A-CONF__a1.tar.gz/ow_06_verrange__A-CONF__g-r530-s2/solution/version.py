import re

class Version:
    def __init__(self, version_str):
        # A version is MAJOR.MINOR.PATCH, each a run of digits, optionally followed by - and a pre-release
        # Nothing else is a version.
        pattern = r"^(\d+)\.(\d+)\.(\d+)(?:-(.*))?$"
        match = re.match(pattern, version_str)
        if not match:
            raise ValueError("Invalid version format")
        
        self.major = int(match.group(1))
        self.minor = int(match.group(2))
        self.patch = int(match.group(3))
        self.pre_release = match.group(4)

    def __eq__(self, other):
        if isinstance(other, tuple):
            return (self.major, self.minor, self.patch) == other
        if not isinstance(other, Version):
            return False
        return (self.major == other.major and 
                self.minor == other.minor and 
                self.patch == other.patch and 
                self.pre_release == other.pre_release)

    def __repr__(self):
        if self.pre_release is None:
            return f"{self.major}.{self.minor}.{self.patch}"
        return f"{self.major}.{self.minor}.{self.patch}-{self.pre_release}"

    @classmethod
    def parse(cls, version_str):
        return cls(version_str)

    def compare(self, other_str):
        other = Version(other_str)
        
        # Compare MAJOR.MINOR.PATCH
        if self.major != other.major:
            return 1 if self.major > other.major else -1
        if self.minor != other.minor:
            return 1 if self.minor > other.minor else -1
        if self.patch != other.patch:
            return 1 if self.patch > other.patch else -1
        
        # A version carrying a pre-release is older than the same version without one.
        if self.pre_release is None and other.pre_release is not None:
            return 1
        if self.pre_release is not None and other.pre_release is None:
            return -1
        if self.pre_release is None and other.pre_release is None:
            return 0
        
        # Two pre-releases are compared identifier by identifier
        self_parts = self.pre_release.split('.')
        other_parts = other.pre_release.split('.')
        
        for s, o in zip(self_parts, other_parts):
            s_is_digit = s.isdigit()
            o_is_digit = o.isdigit()
            
            if s_is_digit and o_is_digit:
                sv = int(s)
                ov = int(o)
                if sv != ov:
                    return 1 if sv > ov else -1
            elif not s_is_digit and not o_is_digit:
                if s != o:
                    return 1 if s > o else -1
            else:
                # an all-digit identifier is older than one that is not.
                return -1 if s_is_digit else 1
        
        # If every shared identifier is equal, the pre-release with more identifiers is the newer one.
        if len(self_parts) != len(other_parts):
            return 1 if len(self_parts) > len(other_parts) else -1
        
        return 0

    def satisfies(self, spec):
        raw_conditions = [c.strip() for c in spec.split(',')]
        if not raw_conditions or (len(raw_conditions) == 1 and raw_conditions[0] == ""):
            raise ValueError("Empty spec")

        for rc in raw_conditions:
            if not rc:
                raise ValueError("Empty condition")
            cond = rc
            match = re.match(r"^(>=|<=|>|<|==|!=)\s*(.*)$", cond)
            if not match:
                raise ValueError("Invalid condition")
            op, v_str = match.groups()
            other_v = Version(v_str)
            res = self.compare(v_str)
            
            if op == "==":
                if res != 0: return False
            elif op == "!=":
                if res == 0: return False
            elif op == ">":
                if res <= 0: return False
            elif op == "<":
                if res >= 0: return False
            elif op == ">=":
                if res < 0: return False
            elif op == "<=":
                if res > 0: return False
        return True

# To make it work with the test_visible.py which expects solution.Version
from solution.version import Version as OriginalVersion
Version = OriginalVersion
