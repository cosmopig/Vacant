import csv
import json
import io
from solution import csv_to_jsonl

def test_basic():
    csv_data = "name,age\nAlice,30\nBob,25"
    expected = '{"name": "Alice", "age": "30"}\n{"name": "Bob", "age": "25"}\n'
    assert csv_to_jsonl(csv_data) == expected

def test_quotes():
    csv_data = 'name,quote\n"Alice","He said ""Hello"""\n'
    expected = '{"name": "Alice", "quote": "He said \"Hello\""}\n'
    assert csv_to_jsonl(csv_data) == expected

def test_newlines():
    csv_data = 'id,text\n1,"Line 1\nLine 2"\n'
    expected = '{"id": "1", "text": "Line 1\nLine 2"}\n'
    assert csv_to_jsonl(csv_data) == expected

def test_duplicate_headers():
    csv_data = "a,b,a\n1,2,3"
    expected = '{"a": "3", "b": "2"}\n'
    assert csv_to_jsonl(csv_data) == expected

def test_empty_fields():
    csv_data = "a,,c\n1,,3"
    expected = '{"a": "1", "c": "3"}\n'
    assert csv_to_jsonl(csv_data) == expected

def test_no_data():
    assert csv_to_jsonl("header1,header2\n") == ""
    assert csv_to_jsonl("") == ""

def test_invalid_count():
    try:
        csv_to_jsonl("a,b\n1")
    except ValueError as e:
        assert str(e).startswith("line 2:")

def test_unclosed_quote():
    try:
        csv_to_jsonl('a,b\n"unclosed')
    except ValueError as e:
        assert str(e).startswith("line 2:")

if __name__ == "__main__":
    test_basic()
    test_quotes()
    test_newlines()
    test_duplicate_headers()
    test_empty_fields()
    test_no_data()
    test_invalid_count()
    test_unclosed_quote()
    print("All tests passed!")
