import csv
import json
import sys
import io

def csv_to_jsonl(text: str) -> str:
    if not text or not text.strip():
        return ""
    
    # 1. Identify "real" newlines that are not inside quotes to determine record starts and line numbers.
    record_info = []  # list of (index, line_num)
    in_quotes = False
    current_line = 1
    i = 0
    record_info.append((0, 1))
    while i < len(text):
        char = text[i]
        if char == '"':
            # A quote is a toggle ONLY if it's not doubled OR if it's at the start of a field.
            # Actually, let's use a simpler rule: 
            # If we are in_quotes and see "", skip them as escaped quotes.
            # Otherwise, " toggles in_quotes.
            if in_quotes and i + 1 < len(text) and text[i+1] == '"':
                i += 2
            else:
                in_quotes = not in_quotes
                i += 1
        elif char in '\n\r':
            if not in_quotes:
                start_idx = i
                next_line = current_line + 1
                # Handle \r\n as a single newline
                if char == '\r' and i + 1 < len(text) and text[i+1] == '\n':
                    i += 2
                else:
                    i += 1
                record_info.append((start_idx, next_line))
                current_line = next_line
            else:
                i += 1
        else:
            i += 1

    # 2. Parse the CSV data using the standard library.
    f = io.StringIO(text)
    reader = csv.reader(f, quotechar='"', doublequote=True, skipinitialspace=False)
    
    try:
        header = next(reader)
    except StopIteration:
        return ""

    output = []
    current_record_idx = 0
    
    # The first record is the header (already consumed).
    for row in reader:
        while current_record_idx < len(record_info):
            start_idx, line_num = record_info[current_record_idx]
            next_start_idx = record_info[current_record_idx + 1][0] if current_record_idx + 1 < len(record_info) else len(text)
            chunk = text[start_idx:next_start_idx]
            if not chunk.strip():
                current_record_idx += 1
            else:
                break
        
        if current_record_idx >= len(record_info):
            break

        _, line_num = record_info[current_record_idx]
        
        # Validate row count.
        if len(row) != len(header):
            raise ValueError(f"line {line_num}: field count differs from the header")
        
        obj = {}
        for i in range(len(header)):
            obj[header[i]] = row[i]
        
        output.append(json.dumps(obj))
        current_record_idx += 1

    return "\n".join(output) + ("\n" if output else "")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        try:
            with open(sys.argv[1], 'r', encoding='utf-8') as f:
                content = f.read()
            print(csv_to_jsonl(content), end='')
        except ValueError as e:
            print(str(e), file=sys.stderr)
            sys.exit(2)
        except Exception:
            sys.exit(1)
    else:
        sys.exit(0)
