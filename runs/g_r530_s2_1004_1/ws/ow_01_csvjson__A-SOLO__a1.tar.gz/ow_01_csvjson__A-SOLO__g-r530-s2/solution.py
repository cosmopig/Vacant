import csv
import json
import sys
import io

def csv_to_jsonl(text):
    if not text or not text.strip():
        return ""
    
    # Use the standard csv module to parse, but we need to track line numbers correctly.
    # To do this, we can iterate through the text and find all newlines that are NOT inside quotes.
    # Then we use those positions as boundaries for records.

    def get_records(content):
        rows = []
        current_row = []
        current_field = ""
        in_quotes = False
        line_num = 1
        start_line_num = 1
        i = 0
        n = len(content)
        while i < n:
            char = content[i]
            if in_quotes:
                if char == '"':
                    if i + 1 < n and content[i+1] == '"':
                        current_field += '"'
                        i += 1
                    else:
                        in_quotes = False
                else:
                    current_field += char
            else:
                if char == '"':
                    in_quotes = True
                elif char == ',':
                    current_row.append(current_field)
                    current_field = ""
                elif char == '\n' or char == '\r':
                    # End of a record? 
                    is_empty_line = (not current_row and current_field == "")
                    if is_empty_line:
                        if char == '\r' and i + 1 < n and content[i+1] == '\n':
                            line_num += 1
                            i += 2
                        else:
                            line_num += 1
                            i += 1
                        continue
                    else:
                        current_row.append(current_field)
                        rows.append((start_line_num, current_row))
                        current_row = []
                        current_field = ""
                        if char == '\r' and i + 1 < n and content[i+1] == '\n':
                            line_num += 2 # Should be incremented by 1 for the record end, but we need to skip \r\n.
                            # Wait, if it was \r\n, then line_num should have been incremented by 1.
                            # Let's just use a simpler way to update line numbers.
                            pass
                        else:
                            line_num += 1
                        start_line_num = line_num
                        i += 1 if char != '\r' else (2 if i+1 < n and content[i+1] == '\n' else 1)
                        # This is getting complicated. Let's use a simpler approach for the whole thing.
                else:
                    current_field += char
            i += 1
        return rows

    # Actually, let's just use csv.reader and find the line numbers by counting newlines outside quotes.
    f = io.StringIO(text)
    reader = csv.reader(f, quotechar='"', doublequote=True, skipinitialspace=False)
    
    try:
        header = next(reader)
    except StopIteration:
        return ""

    num_cols = len(header)
    output = []
    
    # To get the line number of each record's start:
    # We can iterate through the text and find all newlines that are not inside quotes.
    boundaries = []
    in_quotes = False
    for i, char in enumerate(text):
        if char == '"':
            if i + 1 < len(text) and text[i+1] == '"':
                pass # doubled quote
            else:
                in_quotes = not in_quotes
        elif (char == '\n' or char == '\r') and not in_quotes:
            boundaries.append(i)
    
    # Now we have the boundaries of each record. 
    # The first record starts at index 0.
    records = []
    start = 0
    for b in boundaries:
        content_segment = text[start:b]
        if content_segment.strip():
            records.append((start, content_segment))
        # Move start to the character after the newline sequence
        if b < len(text) and text[b] == '\r' and b+1 < len(text) and text[b+1] == '\n':
            start = b + 2
        else:
            start = b + 1

    if start < len(text):
        content_segment = text[start:]
        if content_segment.strip():
            records.append((start, content_segment))
    
    if not records:
        return ""
    
    # Now parse each record using the csv module.
    header_parsed = None
    first_record_idx = -1
    for i, (pos, segment) in enumerate(records):
        try:
            parsed = list(csv.reader(io.StringIO(segment), quotechar='"', doublequote=True))
            if parsed and parsed[0]:
                header_parsed = parsed[0]
                first_record_idx = i
                break
        except Exception:
            pass

    if first_record_idx == -1:
        return ""
    
    num_cols = len(header_parsed)
    output = []
    for i, (pos, segment) in enumerate(records):
        if i == first_record_idx:
            continue
        
        try:
            parsed = list(csv.reader(io.StringIO(segment), quotechar='"', doublequote=True))
            if not parsed or not parsed[0]:
                continue
            row = parsed[0]
            if len(row) != num_cols:
                line_num = 0
                j = 0
                while j < pos:
                    if text[j] == '\n':
                        line_num += 1
                    elif text[j] == '\r' and j+1 < pos and text[j+1] == '\n':
                        line_num += 1
                        j += 1
                    j += 1
                raise ValueError(f"line {line_num + 1}: field count differs from the header")
            
            obj = {}
            for idx, val in enumerate(row):
                obj[header_parsed[idx]] = val
            output.append(json.dumps(obj))
        except ValueError as e:
            raise e
        except Exception:
            pass

    return "\n".join(output) + ("\n" if output else "")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(0)
    try:
        with open(sys.argv[1], 'r', encoding='utf-8') as f:
            content = f.read()
        print(csv_to_jsonl(content), end='')
    except ValueError as e:
        sys.stderr.write(str(e) + "\n")
        sys.exit(2)
    except Exception:
        sys.exit(1)
