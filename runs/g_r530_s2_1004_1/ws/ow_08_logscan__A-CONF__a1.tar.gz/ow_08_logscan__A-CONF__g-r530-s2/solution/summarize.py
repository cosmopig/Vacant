import datetime
import math
import json
from typing import Iterable, Dict, List, Any

def summarize(lines: Iterable[str]) -> Dict[str, Any]:
    endpoints = {}
    bad_lines = 0
    total = 0

    for line in lines:
        # Blank lines are just noise from the rotation script and should not count as anything at all.
        stripped = line.strip()
        if not stripped:
            continue
        
        total += 1
        parts = stripped.split(' ')
        
        is_bad = False
        if len(parts) != 5:
            is_bad = True
        else:
            ts_str, method, path, status_str, ms_str = parts
            
            # Check if STATUS or MS is not a run of digits with an optional leading -
            def is_valid_int(s):
                if not s: return False
                if s[0] == '-':
                    return s[1:].isdigit()
                return s.isdigit()

            if not is_valid_int(status_str) or not is_valid_int(ms_str):
                is_bad = True
            else:
                # Check if timestamp is ISO8601
                try:
                    ts_processed = ts_str.replace('Z', '+00:00')
                    datetime.datetime.fromisoformat(ts_processed)
                except (ValueError, TypeError):
                    is_bad = True

        if is_bad:
            bad_lines += 1
            continue

        # Good line processing
        status = int(status_str)
        ms = int(ms_str)
        
        if path not in endpoints:
            endpoints[path] = {"n": 0, "errors": 0, "ms_list": []}
        
        endpoints[path]["n"] += 1
        if status >= 500:
            endpoints[path]["errors"] += 1
        endpoints[path]["ms_list"].append(ms)

    result_endpoints = []
    for path, data in endpoints.items():
        n = data["n"]
        error_rate = round(data["errors"] / n, 4)
        
        # Percentiles are nearest-rank: the p-th percentile of n sorted values is the one at 1-based position ceil(p / 100 * n).
        sorted_ms = sorted(data["ms_list"])
        p50_idx = math.ceil(50 / 100 * n) - 1
        p95_idx = math.ceil(95 / 100 * n) - 1
        
        result_endpoints.append({
            "path": path,
            "n": n,
            "error_rate": error_rate,
            "p50_ms": sorted_ms[max(0, p50_idx)],
            "p95_ms": sorted_ms[max(0, p95_idx)]
        })

    # endpoints is ordered by n from large to small, and endpoints with the same n are ordered by path in ordinary string order.
    result_endpoints.sort(key=lambda x: (-x["n"], x["path"]))

    return {
        "endpoints": result_endpoints,
        "bad_lines": bad_lines,
        "total": total
    }
