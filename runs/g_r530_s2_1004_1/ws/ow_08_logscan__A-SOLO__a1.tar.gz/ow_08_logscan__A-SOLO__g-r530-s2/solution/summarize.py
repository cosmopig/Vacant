import datetime
import math
from typing import Iterable, List, Dict, Any

def summarize(lines: Iterable[str]) -> Dict[str, Any]:
    endpoints = {}
    bad_lines = 0
    total = 0

    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue
        
        total += 1
        parts = stripped.split(' ')
        
        is_bad = False
        if len(parts) != 5:
            is_bad = True
        else:
            ts_str, method, path, status_str, ms_str = parts
            
            # Check timestamp
            try:
                dt_str = ts_str.replace('Z', '+00:00')
                datetime.datetime.fromisoformat(dt_str)
            except ValueError:
                is_bad = True
            
            if is_bad:
                pass
            else:
                # Check STATUS and MS are digits with optional leading -
                def is_valid_int_str(s):
                    if not s: return False
                    if s.isdigit(): return True
                    if s.startswith('-') and len(s) > 1 and s[1:].isdigit():
                        return True
                    return False

                if not is_valid_int_str(status_str):
                    is_bad = True
                elif not is_valid_int_str(ms_str):
                    is_bad = True

            if is_bad:
                bad_lines += 1
            else:
                # Valid line
                try:
                    status = int(status_str)
                    ms = int(ms_str)
                    if path not in endpoints:
                        endpoints[path] = {"n": 0, "errors": 0, "ms_list": []}
                    
                    endpoints[path]["n"] += 1
                    if status >= 500:
                        endpoints[path]["errors"] += 1
                    endpoints[path]["ms_list"].append(ms)
                except ValueError:
                    is_bad = True
                    bad_lines += 1

    results = []
    for path, data in endpoints.items():
        n = data["n"]
        error_rate = round(data["errors"] / n, 4)
        
        # Percentiles are nearest-rank: ceil(p / 100 * n)
        ms_list = sorted(data["ms_list"])
        p50_idx = math.ceil(50 / 100 * n) - 1
        p95_idx = math.ceil(95 / 100 * n) - 1
        
        # Ensure indices are within bounds (should be if n > 0)
        p50_ms = ms_list[max(0, min(p50_idx, len(ms_list) - 1))]
        p95_ms = ms_list[max(0, min(p95_idx, len(ms_list) - 1))]

        results.append({
            "path": path,
            "n": n,
            "error_rate": error_rate,
            "p50_ms": p50_ms,
            "p95_ms": p95_ms
        })

    # Order by n (desc), then path (asc)
    results.sort(key=lambda x: (-x["n"], x["path"]))

    return {
        "endpoints": results,
        "bad_lines": bad_lines,
        "total": total
    }
