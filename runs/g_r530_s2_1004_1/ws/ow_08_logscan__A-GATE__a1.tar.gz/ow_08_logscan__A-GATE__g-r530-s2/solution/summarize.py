import datetime
import math
import json
from typing import Iterable, Dict, List, Any

def summarize(lines: Iterable[str]) -> Dict[str, Any]:
    endpoints = {}
    bad_lines = 0
    total = 0

    for line in lines:
        # The contract says "Any trailing newline is not part of the line."
        # This means we should remove it before processing.
        line = line.rstrip('\r\n')
        
        # Blank lines are noise and not counted in total or bad_lines
        if not line.strip():
            continue
        
        total += 1
        parts = line.split(' ')
        
        is_bad = False
        if len(parts) != 5:
            is_bad = True
        else:
            timestamp_str, method, path, status_str, ms_str = parts
            
            # Validate timestamp
            try:
                ts_to_parse = timestamp_str.replace('Z', '+00:00')
                datetime.datetime.fromisoformat(ts_to_parse)
            except ValueError:
                is_bad = True
            
            if is_bad:
                pass # Already marked bad
            else:
                # Validate status and ms (digits with optional leading -)
                def is_valid_num_str(s):
                    if not s: return False
                    if s[0] == '-':
                        return len(s) > 1 and s[1:].isdigit()
                    return s.isdigit()

                if not is_valid_num_str(status_str) or not is_valid_num_str(ms_str):
                    is_bad = True
            
            if is_bad:
                bad_lines += 1
                continue

            # If we reach here, the line is good.
            try:
                status = int(status_str)
                ms = int(ms_str)
            except ValueError:
                is_bad = True
                bad_lines += 1
                continue

            if path not in endpoints:
                endpoints[path] = {"n": 0, "errors": 0, "ms_list": []}
            
            endpoints[path]["n"] += 1
            if status >= 500:
                endpoints[path]["errors"] += 1
            endpoints[path]["ms_list"].append(ms)

    # Prepare results
    result_endpoints = []
    for path, data in endpoints.items():
        n = data["n"]
        error_rate = round(data["errors"] / n, 4)
        
        ms_sorted = sorted(data["ms_list"])
        # Percentiles are nearest-rank: ceil(p / 100 * n)
        p50_idx = math.ceil(50 / 100 * n) - 1
        p95_idx = math.ceil(95 / 100 * n) - 1
        
        # Ensure indices are within bounds (should be if n > 0)
        p50_ms = ms_sorted[max(0, min(p50_idx, len(ms_sorted)-1))]
        p95_ms = ms_sorted[max(0, min(p95_idx, len(ms_sorted)-1))]

        result_endpoints.append({
            "path": path,
            "n": n,
            "error_rate": error_rate,
            "p50_ms": p50_ms,
            "p95_ms": p95_ms
        })

    # Sort: primary by n (desc), secondary by path (asc)
    result_endpoints.sort(key=lambda x: (-x["n"], x["path"]))

    return {
        "endpoints": result_endpoints,
        "bad_lines": bad_lines,
        "total": total
    }
