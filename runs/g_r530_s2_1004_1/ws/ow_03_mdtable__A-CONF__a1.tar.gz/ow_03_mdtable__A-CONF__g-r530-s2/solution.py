import unicodedata
import re

def get_width(text):
    return sum(2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1 for ch in text)

def is_separator_row(cells):
    for cell in cells:
        if not re.fullmatch(r':?-+:?', cell):
            return False
    return True

def split_line(line):
    parts = []
    current_part = []
    in_code = False
    i = 0
    while i < len(line):
        char = line[i]
        if char == '\\':
            if i + 1 < len(line):
                current_part.append(line[i:i+2])
                i += 2
            else:
                current_part.append(line[i])
                i += 1
        elif char == '`':
            in_code = not in_code
            current_part.append(char)
            i += 1
        elif char == '|' and not in_code:
            parts.append("".join(current_part))
            current_part = []
            i += 1
        else:
            current_part.append(char)
            i += 1
    parts.append("".join(current_part))
    return parts

def pad_to_width(text, target_width):
    current_width = get_width(text)
    padding_needed = target_width - current_width
    if padding_needed <= 0:
        return text
    return text + (" " * padding_needed)

def process_table(table_lines):
    raw_rows = []
    for row in table_lines:
        parts = split_line(row)
        raw_rows.append(parts)

    num_cols = max(len(row) for row in raw_rows)
    col_widths = [3] * num_cols
    
    is_sep_row = []
    for row in raw_rows:
        is_sep_row.append(is_separator_row(row))

    for i, row in enumerate(raw_rows):
        if not is_sep_row[i]:
            for j, cell in enumerate(row):
                if j < num_cols:
                    clean_cell = cell.strip()
                    col_widths[j] = max(col_widths[j], get_width(clean_cell))

    realigned = []
    for i, row in enumerate(raw_rows):
        new_row_parts = []
        if is_sep_row[i]:
            for j, cell in enumerate(row):
                if j < num_cols:
                    content = cell.strip()
                    first_dash = -1
                    for k, c in enumerate(content):
                        if c == '-':
                            first_dash = k
                            break
                    last_dash = -1
                    for k in range(len(content)-1, -1, -1):
                        if content[k] == '-':
                            last_dash = k
                            break
                    
                    m_left = content[:first_dash] if first_dash != -1 else ""
                    m_right = content[last_dash+1:] if last_dash != -1 else ""
                    num_dashes = last_dash - first_dash + 1 if first_dash != -1 else 0
                    
                    target_dash_width = col_widths[j] - get_width(m_left) - get_width(m_right)
                    if target_dash_width < 0:
                        new_row_parts.append(m_left + m_right)
                    elif num_dashes > 0:
                        # The prompt says "its dashes are stretched or shortened"
                        # This means we should use the number of dashes to determine how many to stretch?
                        # No, it just says they fill the column width.
                        new_row_parts.append(m_left + "-" * target_dash_width + m_right)
                    else:
                        # If there are no dashes (e.g., ":"), we can't stretch them.
                        # But a separator row cell must match :?-+:?. 
                        # "---" matches, ":--" matches, "--:" matches, ":--:" matches.
                        # All of these have at least one dash except maybe ":" or "::"?
                        # If it's just markers, we keep them as is?
                        new_row_parts.append(m_left + m_right)
                else:
                    new_row_parts.append("")
        else:
            for j in range(num_cols):
                cell = row[j] if j < len(row) else ""
                clean_cell = cell.strip()
                padded_cell = pad_to_width(clean_cell, col_widths[j])
                new_row_parts.append(padded_cell)

        # Join the parts using the specified logic:
        # Row = "| " + C1 + " | " + C2 + ... + " |"
        if len(new_row_parts) == 0:
            realigned.append("| |")
        elif len(new_row_parts) == 1:
            realigned.append("| " + new_row_parts[0] + " |")
        else:
            # The prompt says "neighbouring cells are joined by | ".
            # And "Every rendered row begins with | and ends with |".
            # This means for two cells, it's "| C1 | C2 |"
            # Wait, if they are joined by " | ", then there is a space before the second pipe.
            # Let's see: "| C1 | C2 |"
            # The first cell is preceded by "| ". 
            # The last cell is followed by " |".
            # This means for two cells, it's "| " + C1 + " | " + C2 + " |"
            realigned.append("| " + " | ".join(new_row_parts) + " |")

    return realigned

def realign(text):
    lines = text.splitlines(keepends=True)
    processed_lines = []
    in_fence = None
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        if in_fence:
            processed_lines.append(line)
            if stripped.startswith("```") or stripped.startswith("~~~"):
                in_fence = None
            i += 1
            continue
        if stripped.startswith("```") or stripped.startswith("~~~"):
            in_fence = "```" if stripped.startswith("```") else "~~~"
            processed_lines.append(line)
            i += 1
            continue
        parts = split_line(line)
        has_sep = len(parts) > 1
        if has_sep and i + 1 < len(lines):
            next_line = lines[i+1]
            next_parts = split_line(next_line)
            if is_separator_row(next_parts):
                table_lines = [line]
                j = i + 1
                while j < len(lines):
                    curr_line = lines[j]
                    curr_parts = split_line(curr_line)
                    if not curr_line.strip() or len(curr_parts) <= 1:
                        break
                    table_lines.append(curr_line)
                    j += 1
                realigned_table = process_table(table_lines)
                processed_lines.extend(realigned_table)
                i = j
            else:
                processed_lines.append(line)
                i += 1
        else:
            processed_lines.append(line)
            i += 1
    return "".join(processed_lines)

if __name__ == "__main__":
    import sys
    print(realign(sys.stdin.read()))
