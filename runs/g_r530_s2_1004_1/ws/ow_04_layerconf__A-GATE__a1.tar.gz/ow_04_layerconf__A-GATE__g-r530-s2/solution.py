from typing import Any, Dict, Optional

class Config:
    def __init__(self, values: Dict[str, Any], sources: Dict[str, str]):
        self._values = values
        self._sources = sources

    def get(self, key: str) -> Any:
        if key not in self._values:
            raise KeyError(key)
        return self._values[key]

    def source(self, key: str) -> str:
        if key not in self._sources:
            raise KeyError(key)
        return self._sources[key]

    def as_dict(self) -> Dict[str, Any]:
        return self._values.copy()


def _parse_bool(val: str) -> bool:
    v = val.lower()
    if v in ("true", "1", "yes"):
        return True
    if v in ("false", "0", "no"):
        return False
    raise ValueError(f"Cannot convert {val} to bool")


def _parse_value(val: str, target_type: type) -> Any:
    if target_type is bool:
        return _parse_bool(val)
    try:
        # For float/int, we want to handle cases where the string might be empty or invalid
        # but also ensure it's actually a number. 
        # Note: int("10") works, float("10.5") works.
        return target_type(val)
    except (ValueError, TypeError):
        raise ValueError(f"Cannot convert {val} to {target_type}")


def load(defaults: Dict[str, Any], file_text: Optional[str], env: Dict[str, str]) -> Config:
    values = {}
    sources = {}

    # Initialize with defaults
    for k in defaults:
        values[k] = defaults[k]
        sources[k] = "default"

    # Process file
    if file_text is not None:
        current_section = ""
        lines = file_text.splitlines()
        for line in lines:
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            
            if stripped.startswith("[") and stripped.endswith("]"):
                # "A line of the form [name] opens a section, and every key after it becomes name.key"
                section_content = stripped[1:-1].strip()
                current_section = section_content + "." if section_content else ""
            elif "=" in stripped:
                parts = stripped.split("=", 1)
                key_part = parts[0].strip()
                val_part = parts[1].strip()
                
                full_key = (current_section + key_part).strip()

                if full_key in defaults:
                    try:
                        values[full_key] = _parse_value(val_part, type(defaults[full_key]))
                        sources[full_key] = "file"
                    except ValueError as e:
                        raise ValueError(str(e))

    # Process env
    for env_key, env_val in env.items():
        if env_key.upper().startswith("APP_"):
            raw_name = env_key[4:] # Remove APP_ (first 4 chars)
            processed_name = raw_name.replace("__", ".").lower()
            
            if processed_name in defaults:
                try:
                    values[processed_name] = _parse_value(env_val, type(defaults[processed_name]))
                    sources[processed_name] = "env"
                except ValueError as e:
                    raise ValueError(str(e))

    return Config(values, sources)
