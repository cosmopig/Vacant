from typing import List, Dict, Union

def dedupe(records: List[Dict], key: Union[str, List[str]], policy: str = "first") -> List[Dict]:
    if policy not in ("first", "last", "merge"):
        raise ValueError(f"Invalid policy: {policy}")

    keys_to_check = [key] if isinstance(key, str) else key
    
    seen_keys = {}  # maps tuple of key values to index in result list
    result = []

    for record in records:
        current_key_values = []
        for k in keys_to_check:
            if k not in record:
                raise KeyError(k)
            current_key_values.append(record[k])
        key_tuple = tuple(current_key_values)

        if key_tuple not in seen_keys:
            seen_keys[key_tuple] = len(result)
            # Create a new dictionary for the result (copying is required to avoid modifying inputs)
            new_record = record.copy()
            result.append(new_record)
        else:
            idx = seen_keys[key_tuple]
            existing_record = result[idx]

            if policy == "first":
                pass  # Keep existing (already first)
            elif policy == "last":
                result[idx] = record.copy()
            elif policy == "merge":
                new_merged_record = existing_record.copy()
                all_keys = set(existing_record.keys()).union(set(record.keys()))
                for k in all_keys:
                    val1 = existing_record.get(k)
                    val2 = record.get(k)
                    # Policy: "the value of the last copy that both has the field and whose value is not None."
                    # This means if val2 exists (is not None), we take it because it's the latest copy.
                    if val2 is not None:
                        new_merged_record[k] = val2
                result[idx] = new_merged_record

    return result
