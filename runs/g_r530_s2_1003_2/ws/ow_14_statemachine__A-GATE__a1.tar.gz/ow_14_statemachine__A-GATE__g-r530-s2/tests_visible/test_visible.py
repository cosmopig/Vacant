import unittest
from solution import Machine

class TestMachine(unittest.TestCase):
    def test_basic_flow(self):
        spec = {
            "start": {"go": "middle"},
            "middle": {"continue": "end"},
            "end": {}
        }
        m = Machine(spec, "start")
        self.assertEqual(m.state, "start")
        self.assertTrue(m.can("go"))
        self.assertFalse(m.can("continue"))
        
        new_state = m.fire("go")
        self.assertEqual(new_state, "middle")
        self.assertEqual(m.state, "middle")
        self.assertEqual(m.history(), ["start", "middle"])
        
        new_state = m.fire("continue")
        self.assertEqual(new_state, "end")
        self.assertEqual(m.state, "end")
        self.assertEqual(m.history(), ["start", "middle", "end"])

    def test_invalid_transition(self):
        spec = {
            "start": {"go": "middle"},
            "middle": {},
            "end": {}
        }
        m = Machine(spec, "start")
        with self.assertRaises(ValueError):
            m.fire("continue")
        self.assertEqual(m.state, "start")

    def test_reset(self):
        spec = {
            "start": {"go": "middle"},
            "middle": {},
            "end": {}
        }
        m = Machine(spec, "start")
        m.fire("go")
        m.reset()
        self.assertEqual(m.state, "start")
        self.assertEqual(m.history(), ["start"])

    def test_invalid_init(self):
        spec = {"a": {}}
        with self.assertRaises(ValueError):
            Machine(spec, "b")
        
        spec2 = {"a": {"go": "b"}}
        with self.assertRaises(ValueError):
            Machine(spec2, "a")

    def test_history_copy(self):
        spec = {
            "start": {"go": "middle"},
            "middle": {},
            "end": {}
        }
        m = Machine(spec, "start")
        m.fire("go")
        h = m.history()
        h.append("fake")
        self.assertEqual(m.history(), ["start", "middle"])

if __name__ == "__main__":
    unittest.main()
