import re

def to_bytes(s: str) -> int:
    s = s.strip()
    if not s:
        raise ValueError("Empty string")
    
    # The number is one or more digits with at most one dot and at least one digit after it if the dot is there.
    match = re.fullmatch(r"([0-9]+(?:\.[0-9]+)?)\s*([a-zA-Z]*)", s)
    if not match:
        raise ValueError("Invalid format")
    
    num_str, unit_str = match.groups()
    
    try:
        val = float(num_str)
    except ValueError:
        raise ValueError("Invalid number")

    # "a negative size given to either function" is a ValueError.
    if val < 0:
        raise ValueError("Negative size")

    unit_str = unit_str.strip().upper()
    if not unit_str or unit_str == "B":
        return int(val)
    
    # Units are matched without regard to case.
    # KiB, MiB, GiB and TiB step by 1024; KB, MB, GB and TB step by 1000; B or no unit at all means bytes.
    binary_units = {"KIB": 1024, "MIB": 1024**2, "GIB": 1024**3, "TIB": 1024**4}
    decimal_units = {"KB": 1000, "MB": 1000**2, "GB": 1000**3, "TB": 1000**4}
    
    if unit_str in binary_units:
        return int(val * binary_units[unit_str])
    elif unit_str in decimal_units:
        return int(val * decimal_units[unit_str])
    else:
        raise ValueError("Unrecognized unit")

def humanize(n: int, *, binary: bool = True) -> str:
    if n < 0:
        raise ValueError("Negative size")
    
    if n == 0:
        return "0 B"
    
    # Units
    if binary:
        steps = [1, 1024, 1024**2, 1024**3, 1024**4]
        units = ["B", "KiB", "MiB", "GiB", "TiB"]
    else:
        steps = [1, 1000, 1000**2, 1000**3, 1000**4]
        units = ["B", "KB", "MB", "GB", "TB"]

    if n < steps[1]:
        return f"{n} B"
    
    # The unit chosen is the largest one that leaves the number below the step, 
    # except that TiB and TB are the largest units there are: above them the number simply keeps growing.
    # "The Number" refers to n / step.

    chosen_idx = -1
    for i in range(len(steps)):
        v = n / steps[i]
        if i + 1 < len(steps):
            if v < (steps[i+1] / steps[i]): # Wait, "below the step" means v < next_step? No.
                # Let's re-read: "The unit chosen is the largest one that leaves the number below the step".
                pass

    # Let's try the logic that worked for all examples:
    # Find the largest unit such that n / step >= 1.0.
    chosen_idx = -1
    for i in range(len(steps)):
        if n / steps[i] >= 1.0:
            chosen_idx = i
    
    val = n / steps[chosen_idx]
    return f"{val:.1f} {units[chosen_idx]}"

