import re
import unicodedata

def slugify(titles):
    # Helper to convert a title into its base slug form
    def get_base_slug(title):
        # 1. Normalize unicode characters (e.g., accented letters to their base forms)
        normalized = unicodedata.normalize('NFKD', title).encode('ascii', 'ignore').decode('ascii')
        
        # 2. Replace non-alphanumeric characters with hyphens
        slug = re.sub(r'[^a-zA-Z0-9]+', '-', normalized)
        
        # 3. Convert to lowercase and clean up hyphens
        slug = slug.lower().strip('-')
        slug = re.sub(r'-+', '-', slug)
        
        # If the result is empty (e.g., title was only punctuation or non-latin script),
        # we need a fallback that provides a valid slug.
        if not slug:
            return "title"
        
        return slug

    slug_pattern = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")

    base_slugs = []
    is_already_clean = []
    for title in titles:
        if slug_pattern.match(title):
            base_slugs.append(title)
            is_already_clean.append(True)
        else:
            res = get_base_slug(title)
            base_slugs.append(res)
            is_already_clean.append(False)

    final_slugs = []
    used_slugs = set()
    
    # To handle the "no collision" rule correctly, we need to know if a base slug 
    # is shared by multiple titles in the batch.
    base_counts = {}
    for b in base_slugs:
        base_counts[b] = base_counts.get(b, 0) + 1

    for i in range(len(titles)):
        base = base_slugs[i]
        clean = is_already_clean[i]
        
        # Rule: "a title that is already a clean slug, and that nothing else 
        # in the batch collides with, comes back exactly as it was"
        if clean and base_counts[base] == 1:
            final_slugs.append(base)
            used_slugs.add(base)
        else:
            # Collision resolution or non-clean title
            current_slug = base
            
            # If this base is already used by a previous slug (either clean/unique or collision),
            # we need to find the next available one.
            if current_slug in used_slugs:
                counter = 1
                while f"{current_slug}-{counter}" in used_slugs:
                    counter += 1
                current_slug = f"{current_slug}-{counter}"
            else:
                # If it's not in used_slugs, but we know there are multiple titles with this base,
                # and it's the first time we see it (or at least it's not clean/unique),
                # we still want to make sure that if another title later has the same base, 
                # they don't both try to take 'base'.
                # Wait, my logic above handles this: the first one takes 'base', and subsequent ones 
                # will see it in used_slugs.
                pass

            final_slugs.append(current_slug)
            used_slugs.add(current_slug)

    return final_slugs
