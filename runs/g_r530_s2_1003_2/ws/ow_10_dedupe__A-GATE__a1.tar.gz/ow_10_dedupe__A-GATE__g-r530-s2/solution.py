from typing import List, Dict, Union

def dedupe(records: List[Dict], key: Union[str, List[str]], policy: str = "first") -> List[Dict]:
    if policy not in ("first", "last", "merge"):
        raise ValueError(f"Invalid policy: {policy}")

    keys_to_check = [key] if isinstance(key, str) else key
    
    # seen_keys maps tuple of key values to the index in the result list
    seen_keys = {}  # tuple -> int (index)
    result = []
    
    for record in records:
        current_key_values = []
        for k in keys_to_check:
            if k not in record:
                raise KeyError(k)
            current_key_values.append(record[k])
        
        key_tuple = tuple(current_key_values)
        
        if key_tuple not in seen_keys:
            # New unique key found
            seen_keys[key_tuple] = len(result)
            result.append(record.copy())
        else:
            idx = seen_keys[key_tuple]
            existing_record = result[idx]
            
            if policy == "first":
                pass  # Keep the first one we stored (already in result)
            elif policy == "last":
                result[idx] = record.copy()
            elif policy == "merge":
                new_record = existing_record.copy()
                for k, v in record.items():
                    if v is not None:
                        new_record[k] = v
                result[idx] = new_record

    return result
