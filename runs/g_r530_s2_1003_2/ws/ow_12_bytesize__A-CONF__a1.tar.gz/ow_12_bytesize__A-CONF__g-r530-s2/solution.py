import re

def to_bytes(s: str) -> int:
    s = s.strip()
    if not s:
        raise ValueError("Empty string")
    
    # The number is one or more digits with at most one dot and at least one digit after it if the dot is there. 
    # Nothing else is a number.
    match = re.fullmatch(r"(\d+(?:\.\d+)?)\s*([a-zA-Z]*)", s)
    if not match:
        raise ValueError("Invalid format")
    
    num_str, unit_str = match.groups()
    
    try:
        val = float(num_str)
    except ValueError:
        raise ValueError("Invalid number")

    if val < 0:
        raise ValueError("Negative size")

    unit_str = unit_str.upper()
    
    # Units are matched without regard to case. KiB, MiB, GiB and TiB step by 1024; KB, MB, GB and TB step by 1000; B or no unit at all means bytes.
    if not unit_str or unit_str == "B":
        step = 1
    elif unit_str in ["KIB", "MIB", "GIB", "TIB"]:
        if unit_str == "KIB": step = 1024
        elif unit_str == "MIB": step = 1024**2
        elif unit_str == "GIB": step = 1024**3
        elif unit_str == "TIB": step = 1024**4
    elif unit_str in ["KB", "MB", "GB", "TB"]:
        if unit_str == "KB": step = 1000
        elif unit_str == "MB": step = 1000**2
        elif unit_str == "GB": step = 1000**3
        elif unit_str == "TB": step = 1000**4
    else:
        raise ValueError("Unrecognised unit")

    # The result is the number multiplied by the unit's step, with the fraction dropped -- truncated toward zero, never rounded up.
    return int(val * step)

def humanize(n: int, binary: bool = True) -> str:
    if n < 0:
        raise ValueError("Negative size")
    
    if binary:
        # The unit chosen is the largest one that leaves the number below the step, 
        # except that TiB and TB are the largest units there are: above them the number simply keeps growing.
        units = [
            (1024**4, "TiB"),
            (1024**3, "GiB"),
            (1024**2, "MiB"),
            (1024**1, "KiB"),
            (1, "B")
        ]
    else:
        units = [
            (1000**4, "TB"),
            (1000**3, "GB"),
            (1000**2, "MB"),
            (1000**1, "KB"),
            (1, "B")
        ]
    
    chosen_unit = ""
    chosen_step = 1
    
    # The unit chosen is the largest one that leaves the number below the step.
    # This means we want the smallest step s such that n < s.
    # Wait, if n=512 and units are (1024, KiB), (1, B). 
    # Is 512 < 1024? Yes. So KiB is a candidate.
    # Is 512 < 1? No. So B is not a candidate.
    # The largest unit that leaves the number below the step is KiB.
    # But they want "512 B". This means my interpretation of "largest" must be wrong.
    # Let's re-read: "The unit chosen is the largest one that leaves the number below the step".
    # If n=512 and units are (1024, KiB), (1, B). 
    # Is 512 < 1024? Yes. So KiB is a candidate.
    # Is 512 < 1? No. So B is not a candidate.
    # The largest unit that leaves the number below the step is KiB.
    # But they want "512 B". This means my interpretation of "largest" must be wrong.

    # Let's try: find the smallest step s such that n >= s.
    # If n=512, steps are 1024, 1. Smallest s <= 512 is 1. Unit B. Correct!
    # If n=1024, steps are 1024, 1. Smallest s <= 1024 is 1024. Unit KiB. Correct!
    # If n=1536, steps are 1024, 1. Smallest s <= 1536 is 1024. Unit KiB. Correct!

    # Let's re-read: "The unit chosen is the largest one that leaves the number below the step"
    # If n=1536, steps are (1024^4, TiB), (1024^3, GiB), (1024^2, MiB), (1024^1, KiB), (1, B).
    # Is 1536 < 1024^4? Yes.
    # Is 1536 < 1024^3? Yes.
    # Is 1536 < 1024^2? No.
    # So the largest unit that leaves the number below the step is... MiB? No, it's GiB?
    # This still doesn't give KiB.

    # Let's try another interpretation: "The unit chosen is the smallest one such that n >= step".
    # Wait, if I have steps [1024^4, 1024^3, 1024^2, 1024^1, 1].
    # For n=1536:
    # Is 1536 >= 1024^4? No.
    # Is 1536 >= 1024^3? No.
    # Is 1536 >= 1024^2? No.
    # Is 1536 >= 1024^1? Yes. -> KiB. Correct!

    # Let's try n=512:
    # Is 512 >= 1024^4? No.
    # Is 512 >= 1024^3? No.
    # Is 512 >= 1024^2? No.
    # Is 512 >= 1024^1? No.
    # Is 512 >= 1? Yes. -> B. Correct!

    # Let's try n=1024**5:
    # Is 1024^5 >= 1024^4? Yes. -> TiB. Correct! (since it's the largest unit)

    # So the logic is: find the largest step s such that n >= s.
    # If no such step exists (n < 1), then it must be B? But n=0 should be "0 B".
    # Actually, if n=0, none of the steps are <= 0 except maybe... no, all steps are >= 1.
    # So for n=0, we need to handle it separately or ensure B is chosen.

    if n == 0:
        return "0 B"

    chosen_unit = ""
    chosen_step = 1
    
    # Order units from largest step to smallest step
    for step, unit in units:
        if n >= step:
            chosen_unit = unit
            chosen_step = step
            break
    
    # If no unit was chosen (shouldn't happen for n > 0), default to B.
    if not chosen_unit:
        chosen_unit = "B"
        chosen_step = 1

    if chosen_unit == "B":
        return f"{n} B"
    else:
        val = n / chosen_step
        # Truncate to one decimal place.
        truncated_val = int(val * 10) / 10.0
        return f"{truncated_val:.1f} {chosen_unit}"

solution = type('Solution', (), {'to_bytes': to_bytes, 'humanize': humanize})()
