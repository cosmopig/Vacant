def dedupe(records: list[dict], key: str | list[str], policy: str = "first") -> list[dict]:
    if policy not in ("first", "last", "merge"):
        raise ValueError(f"Invalid policy: {policy}")

    keys_to_check = [key] if isinstance(key, str) else key
    seen_keys = {}  # maps the tuple of values to the index in result list
    result = []

    for record in records:
        current_key_values = []
        for k in keys_to_check:
            if k not in record:
                raise KeyError(k)
            current_key_values.append(record[k])
        
        key_tuple = tuple(current_key_values)

        if key_tuple not in seen_keys:
            new_record = dict(record)
            seen_keys[key_tuple] = len(result)
            result.append(new_record)
        else:
            idx = seen_keys[key_tuple]
            if policy == "first":
                pass
            elif policy == "last":
                result[idx] = dict(record)
            elif policy == "merge":
                target_record = result[idx]
                for k, v in record.items():
                    if v is not None:
                        target_record[k] = v

    return result
