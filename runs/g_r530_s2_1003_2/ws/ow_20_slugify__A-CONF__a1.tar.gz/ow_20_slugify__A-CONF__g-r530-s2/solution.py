import re
import unicodedata

def slugify_title(title: str) -> str:
    # Normalize to NFKD and remove non-ascii characters (like accents)
    normalized = unicodedata.normalize('NFKD', title).encode('ascii', 'ignore').decode('ascii')
    # Convert to lowercase
    lower = normalized.lower()
    # Replace all non-alphanumeric with hyphens
    slug = re.sub(r'[^a-z0-9]+', '-', lower)
    # Strip leading/trailing hyphens and reduce multiple hyphens to one
    slug = slug.strip('-')
    slug = re.sub(r'-+', '-', slug)
    
    if not slug:
        return "title"
    return slug

def slugify(titles: list[str]) -> list[str]:
    clean_slug_pattern = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
    
    base_slugs = []
    for title in titles:
        if clean_slug_pattern.match(title):
            base_slugs.append(title)
        else:
            base_slugs.append(slugify_title(title))
    
    # Count occurrences of each base slug in the batch
    base_slug_counts = {}
    for b in base_slugs:
        base_slug_counts[b] = base_slug_counts.get(b, 0) + 1
        
    results = []
    used_in_batch = set()
    
    # To handle the "already a clean slug and nothing else collides" rule:
    # A title is preserved if:
    # 1. It was already a clean slug (matches pattern).
    # 2. Its base slug appears exactly once in the entire batch of base_slugs.
    
    for i, title in enumerate(titles):
        base = base_slugs[i]
        
        if clean_slug_pattern.match(title) and base_slug_counts[base] == 1:
            # This is the only time we use the original title exactly as it was.
            final_slug = base
        else:
            # Otherwise, find a unique slug by appending -1, -2, etc.
            counter = 1
            while True:
                candidate = f"{base}-{counter}"
                if candidate not in used_in_batch:
                    final_slug = candidate
                    break
                counter += 1
        
        results.append(final_slug)
        used_in_batch.add(final_slug)
        
    return results

