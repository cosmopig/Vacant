class Machine:
    def __init__(self, spec: dict[str, dict[str, str]], start: str):
        if start not in spec:
            raise ValueError(f"Start state {start} not in spec")
        for s, events in spec.items():
            for e, target in events.items():
                if target not in spec:
                    raise ValueError(f"Target state {target} for event {e} from {s} not in spec")
        self._spec = spec
        self._start_state = start
        self._current_state = None
        self._history = []
        self.reset()

    @property
    def state(self) -> str:
        return self._current_state

    def can(self, event: str) -> bool:
        return event in self._spec[self._current_state]

    def fire(self, event: str) -> str:
        if not self.can(event):
            raise ValueError(f"State {self._current_state} cannot handle event {event}")
        self._current_state = self._spec[self._current_state][event]
        self._history.append(self._current_state)
        return self._current_state

    def history(self) -> list[str]:
        return list(self._history)

    def reset(self) -> None:
        self._current_state = self._start_state
        self._history = [self._current_state]
