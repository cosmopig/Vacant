import unittest
from solution import Machine

class TestMachine(unittest.TestCase):
    def test_basic_flow(self):
        spec = {
            "start": {"go": "middle"},
            "middle": {"end": "finish"},
            "finish": {}
        }
        m = Machine(spec, "start")
        self.assertEqual(m.state, "start")
        self.assertTrue(m.can("go"))
        self.assertFalse(m.can("end"))
        
        new_state = m.fire("go")
        self.assertEqual(new_state, "middle")
        self.assertEqual(m.state, "middle")
        self.assertTrue(m.can("end"))
        
        new_state = m.fire("end")
        self.assertEqual(new_state, "finish")
        self.assertEqual(m.state, "finish")
        self.assertEqual(m.history(), ["start", "middle", "finish"])

    def test_invalid_initial_state(self):
        spec = {"a": {}}
        with self.assertRaises(ValueError):
            Machine(spec, "b")

    def test_invalid_target_state(self):
        spec = {"a": {"go": "b"}}
        with self.assertRaises(ValueError):
            Machine(spec, "a")

    def test_fire_invalid_event(self):
        spec = {
            "start": {"go": "end"},
            "end": {}
        }
        m = Machine(spec, "start")
        with self.assertRaises(ValueError):
            m.fire("jump")

    def test_reset(self):
        spec = {
            "start": {"go": "end"},
            "end": {}
        }
        m = Machine(spec, "start")
        m.fire("go")
        m.reset()
        self.assertEqual(m.state, "start")
        self.assertEqual(m.history(), ["start"])

    def test_history_copy(self):
        spec = {
            "start": {"go": "end"},
            "end": {}
        }
        m = Machine(spec, "start")
        m.fire("go")
        h = m.history()
        h.append("fake")
        self.assertEqual(m.history(), ["start", "end"])

if __name__ == "__main__":
    unittest.main()
