def dedupe(records: list[dict], key: str | list[str], policy: str = "first") -> list[dict]:
    if policy not in ("first", "last", "merge"):
        raise ValueError(f"Invalid policy: {policy}")

    keys_to_check = [key] if isinstance(key, str) else key
    seen_keys = {}  # maps tuple of values to index in result list
    result = []

    for record in records:
        # Extract the key value(s)
        key_values = []
        for k in keys_to_check:
            if k not in record:
                raise KeyError(k)
            key_values.append(record[k])
        
        key_tuple = tuple(key_values)

        if key_tuple not in seen_keys:
            # New unique key found
            seen_keys[key_tuple] = len(result)
            # Copy the record to ensure we don't modify original and result contains new objects
            new_record = record.copy()
            result.append(new_record)
        else:
            # Duplicate key found, handle based on policy
            idx = seen_keys[key_tuple]
            existing_record = result[idx]

            if policy == "first":
                pass # Keep the first one already in result
            elif policy == "last":
                result[idx] = record.copy()
            elif policy == "merge":
                # Merge fields: last copy that has field and value is not None
                all_keys = set(existing_record.keys()) | set(record.keys())
                for k in all_keys:
                    val1 = existing_record.get(k)
                    val2 = record.get(k)
                    
                    # "the value of the last copy that both has the field and whose value is not None"
                    # If val2 is NOT None, we update. 
                    if val2 is not None:
                        existing_record[k] = val2

    return result
