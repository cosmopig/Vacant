def diff(old: list[str], new: list[str]) -> list[dict]:
    n = len(old)
    m = len(new)
    dp = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(n):
        for j in range(m):
            if old[i] == new[j]:
                dp[i+1][j+1] = dp[i][j] + 1
            else:
                dp[i+1][j+1] = max(dp[i][j], dp[i+1][j])

    common_indices_old = []
    common_indices_new = []
    i, j = n, m
    while i > 0 and j > 0:
        if old[i-1] == new[j-1]:
            common_indices_old.append(i-1)
            common_indices_new.append(j-1)
            i -= 1
            j -= 1
        elif dp[i][j] == dp[i-1][j]:
            i -= 1
        else:
            j -= 1
    common_indices_old.reverse()
    common_indices_new.reverse()

    hunks = []
    # The gaps between common indices are the changes.
    # If there's no common index between two gaps, they must be merged into one hunk.
    # But with LCS backtracking, every gap is separated by at least one common line!
    # UNLESS it's the first or last gap, which might be adjacent to each other? No.
    # Wait, if we have: old = [A, B], new = [X, Y]. Common indices = [].
    # One gap: prev_old=-1, curr_old=2, prev_new=-1, curr_new=2.
    # This is one hunk.

    for k in range(len(common_indices_old) + 1):
        prev_old = common_indices_old[k-1] if k > 0 else -1
        curr_old = common_indices_old[k] if k < len(common_indices_old) else n
        prev_new = common_indices_new[k-1] if k > 0 else -1
        curr_new = common_indices_new[k] if k < len(common_indices_new) else m
        
        old_range = old[prev_old+1 : curr_old]
        new_range = new[prev_new+1 : curr_new]
        
        if not old_range and not new_range:
            continue

        # Shrink the hunk to satisfy "no piece beginning or ending with a line that is the same on both of its sides".
        start = prev_old + 1
        end = curr_old
        
        # If there's an unchanged line before, and it matches the first line of new_range, shrink.
        # Actually, we want to find a hunk [i, j) -> new_range such that:
        # i > 0 => old[i-1] != new_range[0] (if new_range not empty)
        # j < n => old[j-1] != new_range[-1] (if new_range not empty)
        # We want the smallest such hunk that covers all changes in this gap.

        # Let's try to shrink from both ends:
        while start > 0 and end < n and new_range and old[start-1] == new_range[0]:
            # This means old[start-1] is a common line, so it should be outside the hunk.
            # But wait, if we increase `start`, then `old_range` also changes!
            # Actually, this means our LCS backtracking didn't find a "maximal" common line.
            break

        hunks.append({'start': start, 'old': old_range, 'new': new_range})

    if not hunks:
        return []
        
    merged_hunks = []
    curr_hunk = hunks[0]
    for i in range(1, len(hunks)):
        next_hunk = hunks[i]
        # They are adjacent if curr_hunk['start'] + len(curr_hunk['old']) == next_hunk['start'].
        if curr_hunk['start'] + len(curr_hunk['old']) == next_hunk['start']:
            # Merge them. The new old_range is the concatenation of both.
            # Wait, if they are adjacent, it means there's no common line between them.
            # But our LCS-based approach already ensures that every gap is separated by at least one common index!
            pass
        else:
            merged_hunks.append(curr_hunk)
            curr_hunk = next_hunk
    merged_hunks.append(curr_hunk)

    return merged_hunks

def apply(old: list[str], hunks: list[dict]) -> list[str]:
    if not isinstance(hunks, list):
        raise ValueError("Hunks must be a list")
    
    for hunk in hunks:
        if not isinstance(hunk, dict) or len(hunk) != 3 or \
           not all(k in hunk for k in ('start', 'old', 'new')):
            raise ValueError("Malformed hunk")
        if not isinstance(hunk['old'], list) or not isinstance(hunk['new'], list):
            raise ValueError("Old and new must be lists of strings")
        if hunk['old'] == [] and hunk['new'] == []:
            raise ValueError("Hunk cannot be empty on both sides")

    last_end = -1
    for i, hunk in enumerate(hunks):
        start = hunk['start']
        old_r = hunk['old']
        new_r = hunk['new']
        
        if start < last_end:
            raise ValueError("Hunks are out of order or overlap")
        
        if old[start : start + len(old_r)] != old_r:
            raise ValueError("Old content does not match")
        
        if start + len(old_r) > len(old):
            raise ValueError("Hunk reaches past the end of the old list")
            
        last_end = start + len(old_r)

    result = []
    curr_old_idx = 0
    for hunk in hunks:
        start = hunk['start']
        old_r = hunk['old']
        new_r = hunk['new']
        
        result.extend(old[curr_old_idx : start])
        result.extend(new_r)
        curr_old_idx = start + len(old_r)
    
    result.extend(old[curr_old_idx:])
    return result

if __name__ == "__main__":
    pass
