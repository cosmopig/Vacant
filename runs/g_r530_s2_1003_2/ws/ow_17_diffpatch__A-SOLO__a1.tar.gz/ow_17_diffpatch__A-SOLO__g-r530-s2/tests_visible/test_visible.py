import unittest

def diff(old, new):
    # To be implemented
    pass

def apply(old, hunks):
    # To be implemented
    pass

class TestDiffApply(unittest.TestCase):
    def test_basic_diff_apply(self):
        old = ["line1", "line2", "line3"]
        new = ["line1", "line2 changed", "line3"]
        hunks = diff(old, new)
        self.assertEqual(apply(old, hunks), new)

    def test_multiple_changes(self):
        old = ["a", "b", "c", "d", "e"]
        new = ["a", "x", "c", "y", "e"]
        hunks = diff(old, new)
        self.assertEqual(apply(old, hunks), new)

    def test_insertion(self):
        old = ["a", "b"]
        new = ["a", "i", "b"]
        hunks = diff(old, new)
        self.assertEqual(apply(old, hunks), new)

    def test_deletion(self):
        old = ["a", "b", "c"]
        new = ["a", "c"]
        hunks = diff(old, new)
        self.assertEqual(apply(old, hunks), new)

    def test_replacement(self):
        old = ["a", "b", "c"]
        new = ["x", "y", "z"]
        hunks = diff(old, new)
        self.assertEqual(apply(old, hunks), new)

    def test_no_change(self):
        old = ["a", "b", "c"]
        new = ["a", "b", "c"]
        hunks = diff(old, new)
        self.assertEqual(hunks, [])
        self.assertEqual(apply(old, hunks), new)

    def test_adjacent_changes_separated(self):
        # The contract says: at least one unchanged line between the end of one piece and the start of the next
        # This means if we have "a", "b", "c" -> "x", "y", "z", it should be one hunk.
        old = ["a", "b", "c"]
        new = ["x", "y", "z"]
        hunks = diff(old, new)
        self.assertEqual(len(hunks), 1)

    def test_no_redundant_boundaries(self):
        # No piece beginning or ending with a line that is the same on both of its sides.
        # "a", "b", "c" -> "a", "x", "c" should be one hunk ["b"] replaced by ["x"].
        old = ["a", "b", "c"]
        new = ["a", "x", "c"]
        hunks = diff(old, new)
        self.assertEqual(len(hunks), 1)
        self.assertEqual(hunks[0]['old'], ["b"])
        self.assertEqual(hunks[0]['new'], ["x"])

    def test_complex_diff(self):
        old = ["line1", "line2", "line3", "line4", "line5"]
        new = ["line1", "line2 modified", "line3", "line4 removed", "line5", "line6 added"]
        hunks = diff(old, new)
        self.assertEqual(apply(old, hunks), new)

    def test_apply_errors(self):
        old = ["a", "b", "c"]
        # Wrong old content
        with self.assertRaises(ValueError):
            apply(old, [{"start": 1, "old": ["x"], "new": ["y"]}])
        # Out of order
        with self.assertRaises(ValueError):
            apply(old, [{"start": 2, "old": ["c"], "new": ["z"]}, {"start": 1, "old": ["b"], "new": ["y"]}])
        # Overlap
        with self.assertRaises(ValueError):
            apply(old, [{"start": 0, "old": ["a", "b"], "new": ["x"]}, {"start": 1, "old": ["b"], "new": ["y"]}])
        # Past end
        with self.assertRaises(ValueError):
            apply(old, [{"start": 3, "old": [], "new": ["z"]}]) # Wait, old cannot be empty if new is not? No, start=3 is past end of [0,1,2]
        # Empty both sides
        with self.assertRaises(ValueError):
            apply(old, [{"start": 1, "old": [], "new": []}])
        # Malformed dict
        with self.assertRaises(ValueError):
            apply(old, [{"start": 1, "old": ["b"], "wrong": ["y"]}])

if __name__ == "__main__":
    unittest.main()
