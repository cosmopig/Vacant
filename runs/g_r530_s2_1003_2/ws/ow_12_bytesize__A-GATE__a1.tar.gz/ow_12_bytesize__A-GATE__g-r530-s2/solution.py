import re

def to_bytes(s: str) -> int:
    s = s.strip()
    if not s:
        raise ValueError("Empty string")
    
    # Number: one or more digits with at most one dot and at least one digit after it if the dot is there.
    # Unit: B, KB, KiB, MB, MiB, GB, GiB, TB, TiB (case insensitive)
    match = re.fullmatch(r"(\d+(?:\.\d+)?)\s*([a-zA-Z]*)", s)
    if not match:
        raise ValueError("Invalid format")
    
    num_str, unit_str = match.groups()
    try:
        number = float(num_str)
    except ValueError:
        raise ValueError("Invalid number")

    # The prompt says "negative size given to either function" should be refused.
    if number < 0:
        raise ValueError("Negative size")

    unit_str = unit_str.upper()
    if not unit_str or unit_str == 'B':
        return int(number)
    
    binary_units = {
        'KIB': 1024,
        'MIB': 1024**2,
        'GIB': 1024**3,
        'TIB': 1024**4
    }
    decimal_units = {
        'KB': 1000,
        'MB': 1000**2,
        'GB': 1000**3,
        'TB': 1000**4
    }
    
    if unit_str in binary_units:
        return int(number * binary_units[unit_str])
    elif unit_str in decimal_units:
        return int(number * decimal_units[unit_str])
    else:
        raise ValueError("Unrecognized unit")

def humanize(n: int, *, binary: bool = True) -> str:
    if n < 0:
        raise ValueError("Negative size")
    if n == 0:
        return "0 B"
    
    units_binary = [('KiB', 1024), ('MiB', 1024**2), ('GiB', 1024**3), ('TiB', 1024**4)]
    units_decimal = [('KB', 1000), ('MB', 1000**2), ('GB', 1000**3), ('TB', 1000**4)]
    current_units = units_binary if binary else units_decimal
    
    smallest_step = current_units[0][1]
    if n < smallest_step:
        return f"{n} B"
    
    best_unit = None
    max_step = -1
    all_units = [('B', 1)] + current_units
    for name, step in all_units:
        val = n / step
        if val >= 1 and (val < 1024 or name in ['TiB', 'TB']):
            if step > max_step:
                max_step = step
                best_unit = (name, step)
    
    if best_unit is None:
        best_unit = ('B', 1)
        
    name, step = best_unit
    val = n / step
    # Truncate to one decimal place.
    truncated_res = int(val * 10) / 10.0
    return f"{truncated_res:.1f} {name}"
