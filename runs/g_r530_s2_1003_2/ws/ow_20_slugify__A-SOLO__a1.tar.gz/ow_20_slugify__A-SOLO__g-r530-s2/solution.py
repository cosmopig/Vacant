import re
import unicodedata

def _single_title_to_slug(title: str) -> str:
    # 1. Normalize to NFKD and remove non-spacing marks (accents)
    norm = unicodedata.normalize('NFKD', title)
    
    # 2. Replace non-alphanumeric with space, lowercase everything
    temp_slug = ""
    for char in norm:
        if char.isalnum():
            temp_slug += char.lower()
        else:
            temp_slug += " "
    
    # 3. Clean up spaces and hyphens (replace multiple spaces with a single hyphen, then strip)
    res = "-".join(s for s in temp_slug.split() if s)
    
    # If result is empty (e.g. title was "!!!"), use a fallback.
    if not res:
        res = "a"
    
    return res

def slugify(titles: list[str]) -> list[str]:
    base_slugs = []
    for title in titles:
        # Check if it's already a clean slug
        is_clean = bool(re.match(r"^[a-z0-9]+(?:-[a-z0-9]+)*$", title))
        base = _single_title_to_slug(title)
        if is_clean and base == title:
            base_slugs.append(title)
        else:
            base_slugs.append(base)
    
    final_slugs = []
    seen = set()
    for base in base_slugs:
        current_slug = base
        counter = 1
        while current_slug in seen:
            # If the original title was a clean slug and it's colliding,
            # we still need to resolve it. The rule says "comes back exactly as it was"
            # ONLY IF it doesn't collide. If it does collide, it must change.
            current_slug = f"{base}-{counter}"
            counter += 1
        final_slugs.append(current_slug)
        seen.add(current_slug)
        
    return final_slugs
