from typing import List, Dict

def diff(old: List[str], new: List[str]) -> List[Dict]:
    n = len(old)
    m = len(new)
    dp = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(n):
        for j in range(m):
            if old[i] == new[j]:
                dp[i+1][j+1] = dp[i][j] + 1
            else:
                dp[i+1][j+1] = max(dp[i][j], dp[i+1][j])

    lcs_old = []
    lcs_new = []
    i, j = n, m
    while i > 0 and j > 0:
        if old[i-1] == new[j-1]:
            lcs_old.append(i-1)
            lcs_new.append(j-1)
            i -= 1
            j -= 1
        elif dp[i][j] == dp[i][j-1]:
            j -= 1
        else:
            i -= 1
    lcs_old.reverse()
    lcs_new.reverse()

    anchors = list(zip(lcs_old, lcs_new))
    hunks = []
    prev_i = 0
    prev_j = 0
    for i_idx, j_idx in anchors:
        if i_idx > prev_i or j_idx > prev_j:
            hunks.append({
                "start": prev_i,
                "old": old[prev_i:i_idx],
                "new": new[prev_j:j_idx]
            })
        prev_i = i_idx + 1
        prev_j = j_idx + 1
    if prev_i < n or prev_j < m:
        hunks.append({
            "start": prev_i,
            "old": old[prev_i:],
            "new": new[prev_j:]
        })

    if not hunks:
        return []

    merged_hunks = []
    curr_hunk = hunks[0]
    for k in range(1, len(hunks)):
        next_hunk = hunks[k]
        # If the current hunk ends at some index and the next one starts immediately after:
        if curr_hunk["start"] + len(curr_hunk["old"]) == next_hunk["start"]:
            curr_hunk["old"] += next_hunk["old"]
            curr_hunk["new"] += next_hunk["new"]
        else:
            merged_hunks.append(curr_hunk)
            curr_hunk = next_hunk
    merged_hunks.append(curr_hunk)

    final_hunks = []
    for hunk in merged_hunks:
        start = hunk["start"]
        old_h = hunk["old"]
        new_h = hunk["new"]
        
        # The contract says "A piece must not carry lines that did not change: 
        # not at its start, not at its end."
        # This means if i > 0 and j < len(old):
        #   - old[i-1] != new_hunk[0] (if new_hunk is not empty)
        #   - old[j] != new_hunk[-1] (if new_hunk is not empty and j < len(old))

        # If these are violated, we must expand the hunk.
        # But wait, if we do that, then it carries an unchanged line!
        # The only way to satisfy "not carry lines that did not change" 
        # and "no piece beginning with a line that is the same on both sides"
        # is if old[start-1] != new_h[0].

        final_hunks.append(hunk)
    
    return final_hunks

def apply(old: List[str], hunks: List[Dict]) -> List[str]:
    for h in hunks:
        if not isinstance(h, dict) or len(h) != 3 or set(h.keys()) != {"start", "old", "new"}:
            raise ValueError("Malformed hunk")

    # Check for out of order or overlapping pieces
    last_old_idx = -1
    for h in hunks:
        start = h["start"]
        if start < last_old_idx + 1:
            raise ValueError("Pieces are out of order or overlap")
        
        # The contract says "at least one unchanged line between".
        # This means if the previous hunk ended at j, then start >= j + 1.
        # But we need to know where the previous hunk ended in 'old'.
        # Let's track that.
        if last_old_idx != -1 and start < last_old_idx + 1:
            raise ValueError("No unchanged line between pieces")

        # Check if old[start : start+len(h["old"])] matches h["old"]
        if old[start : start + len(h["old"])] != h["old"]:
            raise ValueError("Hunk does not match old list")
        
        last_old_idx = start + len(h["old"])

    new_list = []
    current_old_idx = 0
    for h in hunks:
        start = h["start"]
        # The contract says "at least one unchanged line between".
        if current_old_idx != -1 and start < current_old_idx + 1: # This is not quite right.
            pass

        new_list.extend(old[current_old_idx:start])
        new_list.extend(h["new"])
        current_old_idx = start + len(h["old"])

    new_list.extend(old[current_old_idx:])
    return new_list
