import unittest

def diff(old, new):
    # To be implemented
    pass

def apply(old, hunks):
    # To be implemented
    pass

class TestDiffApply(unittest.TestCase):
    def test_basic_diff_apply(self):
        old = ["line1", "line2", "line3"]
        new = ["line1", "line2_modified", "line3"]
        hunks = diff(old, new)
        self.assertEqual(apply(old, hunks), new)

    def test_empty_diff(self):
        old = ["a", "b", "c"]
        new = ["a", "b", "c"]
        hunks = diff(old, new)
        self.assertEqual(hunks, [])
        self.assertEqual(apply(old, hunks), new)

    def test_multiple_changes(self):
        old = ["a", "b", "c", "d", "e"]
        new = ["a", "x", "c", "y", "z"]
        hunks = diff(old, new)
        self.assertEqual(apply(old, hunks), new)

    def test_insertion(self):
        old = ["a", "b"]
        new = ["a", "insert", "b"]
        hunks = diff(old, new)
        self.assertEqual(apply(old, hunks), new)

    def test_deletion(self):
        old = ["a", "b", "c"]
        new = ["a", "c"]
        hunks = diff(old, new)
        self.assertEqual(apply(old, hunks), new)

    def test_replacement(self):
        old = ["a", "b", "c"]
        new = ["x", "y", "z"]
        hunks = diff(old, new)
        self.assertEqual(apply(old, hunks), new)

    def test_no_redundant_lines(self):
        # A piece must not carry lines that did not change: not at its start, not at its end.
        # This means if old[start-1] == old[start] and old is replaced by something starting with same line, 
        # it should be handled correctly? No, the rule says "no piece beginning or ending with a line that is the same on both of its sides".
        # Actually, it's simpler: if we have [A, B, C] -> [A, X, C], and A == old[0], then the hunk for B should not include A.
        old = ["same", "change", "same"]
        new = ["same", "changed", "same"]
        hunks = diff(old, new)
        # The hunk should only be {"start": 1, "old": ["change"], "new": ["changed"]}
        self.assertEqual(len(hunks), 1)
        self.assertEqual(hunks[0]["start"], 1)

    def test_apply_errors(self):
        old = ["a", "b", "c"]
        # Wrong old content
        with self.assertRaises(ValueError):
            apply(old, [{"start": 0, "old": ["x"], "new": ["y"]}])
        # Out of order
        with self.assertRaises(ValueError):
            apply(old, [{"start": 2, "old": ["c"], "new": ["z"]}, {"start": 0, "old": ["a"], "new": ["q"]}])
        # Overlap
        with self.assertRaises(ValueError):
            apply(old, [{"start": 0, "old": ["a", "b"], "new": ["x"]}, {"start": 1, "old": ["b"], "new": ["y"]}])
        # Past end
        with self.assertRaises(ValueError):
            apply(old, [{"start": 4, "old": [], "new": ["z"]}]) # Wait, old can't be empty if start is valid?
            # Actually the contract says: "when a piece reaches past the end of the old list"
            # If start = 3 and len(old) = 3, it's at the end. If start = 4, it's past.
        with self.assertRaises(ValueError):
            apply(old, [{"start": 3, "old": ["d"], "new": ["z"]}])
        # Empty both sides (not possible by diff but apply must check)
        with self.assertRaises(ValueError):
            apply(old, [{"start": 0, "old": [], "new": []}])
        # Malformed dict
        with self.assertRaises(ValueError):
            apply(old, [{"start": 0, "old": ["a"], "wrong_key": ["y"]}])

if __name__ == "__main__":
    unittest.main()
