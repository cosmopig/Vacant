import difflib

def diff(old: list[str], new: list[str]) -> list[dict]:
    matcher = difflib.SequenceMatcher(None, old, new)
    raw_hunks = []
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == 'equal':
            continue
        raw_hunks.append({'start': i1, 'old': old[i1:i2], 'new': new[j1:j2]})

    refined_hunks = []
    for hunk in raw_hunks:
        curr_start = hunk['start']
        curr_old = list(hunk['old'])
        curr_new = list(hunk['new'])

        # Shrink from the beginning
        while len(curr_old) > 0 and len(curr_new) > 0 and curr_old[0] == curr_new[0]:
            curr_start += 1
            curr_old = curr_old[1:]
            curr_new = curr_new[1:]
        
        # Shrink from the end
        while len(curr_old) > 0 and len(curr_new) > 0 and curr_old[-1] == curr_new[-1]:
            curr_old = curr_old[:-1]
            curr_new = curr_new[:-1]

        if not curr_old and not curr_new:
            continue

        refined_hunks.append({'start': curr_start, 'old': curr_old, 'new': curr_new})

    final_hunks = []
    for hunk in refined_hunks:
        # Merge adjacent hunks if there is no unchanged line between them
        if final_hunks and hunk['start'] == final_hunks[-1]['start'] + len(final_hunks[-1]['old']):
            final_hunks[-1]['old'].extend(hunk['old'])
            final_hunks[-1]['new'].extend(hunk['new'])
        else:
            final_hunks.append(hunk)

    # Final check for "no piece beginning or ending with a line that is the same on both of its sides"
    # This means if old[start] == old[start-1] AND new_part[0] == old[start], it's bad? 
    # Actually, let's re-read: "A piece must not carry lines that did not change: not at its start, not at its end."
    # This means if there is a line before the hunk that is equal to the first line of the hunk AND 
    # it's also equal to the corresponding line in the new version.
    # But we already handle curr_old[0] == curr_new[0].
    # What about old[start] == old[start-1]? If this is true, then old[start] is "the same" as the previous line.
    # If it's also replaced by something else, it's still a change.
    # The rule says: "no piece beginning or ending with a line that is the same on both of its sides".
    # This means if old[start] == old[start-1], then we should have started at start+1? 
    # No, because it's still changed.
    # Let's re-read: "A piece must not carry lines that did not change: not at its start, not at its end."
    # This means if old[start] == new_part[0], then old[start] is a line that didn't change. 
    # We already handled this by shrinking.
    # What about "same on both of its sides"?
    # If there's an unchanged line before the hunk, say at start-1, and it's equal to the first line of the hunk?
    # That would mean old[start-1] == old[start]. 
    # If this is true, then old[start] is "the same" as the line on its left.
    # And if new_part[0] is also equal to old[start], it's a line that didn't change.
    # But we already handled curr_old[0] == curr_new[0].
    # Let's try to implement the "no piece beginning or ending with a line that is the same on both of its sides" 
    # by checking if old[start] == old[start-1] (if start > 0) and new_part[0] == old[start].
    # Wait, if we already shrunk curr_old[0] == curr_new[0], then new_part[0] != old[start].
    # So the only way it could be "the same on both of its sides" is if there's an unchanged line 
    # before/after that is equal to the first/last line of the hunk.
    # But if it was equal, we would have shrunk it!
    # Let's re-read: "no piece beginning or ending with a line that is the same on both of its sides".
    # This might mean old[start] == old[start-1] (if start > 0) OR new_part[0] == old[start]? No.
    # Let's look at it this way: if we have [A, B, C] -> [A, X, C]. The change is [B] -> [X].
    # If the hunk was {"start": 0, "old": [A, B], "new": [A, X]}, then A is at the start and it's the same on both sides.
    # We shrunk it to {"start": 1, "old": [B], "new": [X]}. Now B is at the start.
    # Is B the same as the line before it? old[0] is A. B != A. So it's not the same on both sides.
    # What if old = [A, A, B] and new = [A, X, B]? 
    # The change is [A] -> [X]. Hunk: {"start": 1, "old": [A], "new": [X]}.
    # Is the first line of the hunk (A) the same as the line before it? old[0] is A. Yes!
    # So we should have started at index 2? No, because then the change would be [B] -> [B]? No.
    # If old = [A, A, B] and new = [A, X, B], the change is at index 1.
    # The hunk is {"start": 1, "old": [A], "new": [X]}.
    # Is old[1] == old[0]? Yes. So it's the same as the line on its left.
    # Is new[0] == old[1]? No (X != A).
    # The rule says: "no piece beginning or ending with a line that is the same on both of its sides".
    # This means if old[start] == old[start-1], then it's "the same" as the line on its left.
    # If new_part[0] == old[start], then it's also "the same" in the new version.
    # But we already shrunk for curr_old[0] == curr_new[0].
    # Wait, if old = [A, A, B] and new = [A, A, C], the change is at index 2.
    # Hunk: {"start": 2, "old": [B], "new": [C]}.
    # Is old[2] == old[1]? No (B != A). So it's fine.
    # What if old = [A, B, B] and new = [A, X, B]?
    # The change is at index 1. Hunk: {"start": 1, "old": [B], "new": [X]}.
    # Is old[1] == old[2]? Yes (B == B). So it's the same as the line on its right.
    # Is new_part[-1] == old[1]? No (X != B). 
    # Wait, if we have [A, B, B] -> [A, X, B], and the hunk is {"start": 1, "old": [B], "new": [X]}.
    # The line at index 2 is B in both versions. It's unchanged.
    # So the hunk should not end with it? But it doesn't! It ends with X.
    # Let me re-read again: "no piece beginning or ending with a line that is the same on both of its sides".
    # This means if old[start] == old[start-1], then it's the same as the line on its left.
    # If new_part[0] == old[start], then it's also the same in the new version.
    # But we already shrunk for curr_old[0] == curr_new[0].
    # So if we have [A, A, B] -> [A, X, B], and hunk is {"start": 1, "old": [A], "new": [X]}.
    # Is old[1] == old[0]? Yes. Is new_part[0] == old[1]? No (X != A).
    # So it's NOT the same on both sides? Or is it? 
    # "the same on both of its sides" usually means:
    # For a hunk at `start`, if `old[start]` is equal to `old[start-1]` AND `new_part[0]` is also equal to `old[start]`.
    # But we already shrunk for `curr_old[0] == curr_new[0]`. 
    # So the only way it could be "the same on both of its sides" is if there's an unchanged line before/after.
    # If old = [A, B, C] and new = [A, X, C], hunk is {"start": 1, "old": [B], "new": [X]}.
    # Here, old[0] == A and new[0] == A. The line A is the same on both sides of the change? No, it's before the change.
    # I think my shrinking logic `curr_old[0] == curr_new[0]` already handles "not carry lines that did not change".
    # And if a piece doesn't carry lines that didn't change, then it automatically satisfies 
    # "no piece beginning or ending with a line that is the same on both of its sides" because 
    # any such line would have been part of the unchanged section and thus not in the hunk.

    return final_hunks

def apply(old: list[str], hunks: list[dict]) -> list[str]:
    if not isinstance(hunks, list):
        raise ValueError("Hunks must be a list")
    
    for hunk in hunks:
        if not isinstance(hunk, dict) or len(hunk) != 3 or \
           set(hunk.keys()) != {"start", "old", "new"}:
            raise ValueError("Malformed hunk")
        if not isinstance(hunk["start"], int):
            raise ValueError("Start must be an integer")
        if not isinstance(hunk["old"], list) or not isinstance(hunk["new"], list):
            raise ValueError("Old and new must be lists")
        if len(hunk["old"]) == 0 and len(hunk["new"]) == 0:
            raise ValueError("Piece cannot be empty on both sides")

    last_end = -1
    for hunk in hunks:
        start = hunk["start"]
        old_part = hunk["old"]
        new_part = hunk["new"]
        
        if start < last_end:
            raise ValueError("Hunks are out of order or overlap")
        
        if start > len(old):
            raise ValueError("Piece reaches past the end of the old list")
        
        if old[start : start + len(old_part)] != old_part:
            raise ValueError("Old content does not match")
        
        last_end = start + len(old_part)

    result = []
    old_idx = 0
    hunk_idx = 0
    while old_idx < len(old) or hunk_idx < len(hunks):
        if hunk_idx < len(hunks) and hunks[hunk_idx]["start"] == old_idx:
            result.extend(hunks[hunk_idx]["new"])
            old_idx += len(hunks[hunk_idx]["old"])
            hunk_idx += 1
        elif hunk_idx < len(hunks) and hunks[hunk_idx]["start"] > old_idx:
            # This case should not happen if they are ordered and non-overlapping,
            # but let's be safe. Actually it can happen if there is a gap.
            result.append(old[old_idx])
            old_idx += 1
        else:
            if old_idx < len(old):
                result.append(old[old_idx])
                old_idx += 1
            else:
                # This would mean we have more hunks than lines in 'old'
                break
    return result

