import re

def slugify(titles: list[str]) -> list[str]:
    def clean_title(t):
        # Keep only alphanumeric and spaces, then lowercase
        s = "".join(c for c in t if c.isalnum() or c.isspace()).lower()
        # Replace non-alphanumeric with hyphens
        s = re.sub(r'[^a-z0-9]+', '-', s).strip('-')
        # Remove double hyphens
        s = re.sub(r'-+', '-', s)
        if not s:
            return "slug"
        return s

    results = []
    seen = set()
    
    for title in titles:
        is_clean = bool(re.match(r'^[a-z0-9]+(?:-[a-z0-9]+)*$', title))
        base = clean_title(title)
        
        # If it was already a clean slug and we haven't used it yet, keep it.
        if is_clean:
            candidate = title
        else:
            candidate = base
            
        final_slug = candidate
        counter = 1
        while final_slug in seen:
            suffix = f"-{counter}"
            # If the candidate already ends with a hyphen, we don't want to add another one.
            if candidate.endswith('-'):
                new_candidate = candidate + str(counter)
            else:
                new_candidate = candidate + suffix
            
            final_slug = new_candidate
            counter += 1
        
        results.append(final_slug)
        seen.add(final_slug)
        
    return results

