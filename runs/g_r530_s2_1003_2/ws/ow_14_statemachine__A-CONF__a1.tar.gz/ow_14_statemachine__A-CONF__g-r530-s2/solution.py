class Machine:
    def __init__(self, spec: dict[str, dict[str, str]], start: str):
        if start not in spec:
            raise ValueError(f"Start state {start} not in spec")
        for s, events in spec.items():
            for event, target in events.items():
                if target not in spec:
                    raise ValueError(f"Target state {target} for event {event} in state {s} not in spec")
        self._spec = spec
        self._start_state = start
        self._history = [start]

    @property
    def state(self) -> str:
        return self._history[-1]

    def can(self, event: str) -> bool:
        return event in self._spec[self.state]

    def fire(self, event: str) -> str:
        if not self.can(event):
            raise ValueError(f"State {self.state} cannot handle event {event}")
        new_state = self._spec[self.state][event]
        self._history.append(new_state)
        return new_state

    def history(self) -> list[str]:
        return list(self._history)

    def reset(self) -> None:
        self._history = [self._start_state]
