from solution import Solution

def test():
    s = Solution()
    # Basic matches
    assert s.matches("src/*.py", "src/main.py") == True
    assert s.matches("src/*.py", "src/sub/main.py") == False
    assert s.matches("**", "a/b/c") == True
    assert s.matches("**/a", "a/b/c/a") == True
    assert s.matches("src/**", "src/main.py") == True
    assert s.matches("src/**", "src/") == True
    assert s.matches("src/**", "src") == True

    # Wildcards and brackets
    assert s.matches("a?c", "abc") == True
    assert s.matches("a?c", "axc") == True
    assert s.matches("a?c", "ab1") == False
    assert s.matches("a*", "a") == True
    assert s.matches("a*", "abc") == True
    assert s.matches("a*", "") == False

    # Brackets and ranges
    assert s.matches("[abc]", "a") == True
    assert s.matches("[abc]", "b") == True
    assert s.matches("[abc]", "c") == True
    assert s.matches("[abc]", "d") == False
    assert s.matches("[a-z]", "m") == True
    assert s.matches("[a-z]", "A") == False
    # These are checked via select:
    paths = ["a", "b", "c"]
    assert s.select(["[abc]"], paths) == ["a", "b", "c"]
    assert s.select(["[!abc]", "[abc]"], paths) == ["a", "b", "c"] # [abc] puts them back

    # Nested patterns and select
    paths = ["src/main.py", "src/test.py", "lib/main.py", "docs/index.html"]
    assert s.select(["src/*.py"], paths) == ["src/main.py", "src/test.py"]
    assert s.select(["src/*.py", "!src/main.py"], paths) == ["src/test.py"]
    assert s.select(["**"], paths) == ["src/main.py", "src/test.py", "lib/main.py", "docs/index.html"]
    assert s.select(["**", "!lib/*"], paths) == ["src/main.py", "src/test.py", "docs/index.html"]

    # Edge cases for select
    paths2 = ["a/b", "c/d", "e/f"]
    assert s.select(["a/**"], paths2) == ["a/b"]
    assert s.select(["**", "!a/*"], paths2) == ["c/d", "e/f"]

    # Error cases
    try:
        s.matches("[abc", "a")
    except ValueError:
        pass
    else:
        raise AssertionError("Should have raised ValueError for unclosed [")

    try:
        s.matches("[]", "a")
    except ValueError:
        pass
    else:
        raise AssertionError("Should have raised ValueError for empty class")

if __name__ == "__main__":
    test()
