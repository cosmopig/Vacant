import re

class Solution:
    def matches(self, pattern: str, path: str) -> bool:
        pattern_segments = pattern.split('/')
        path_segments = path.split('/')
        return self._match_recursive(pattern_segments, path_segments)

    def _match_recursive(self, pattern_segments, path_segments):
        if not pattern_segments:
            return not path_segments
        
        current_p = pattern_segments[0]
        remaining_p = pattern_segments[1:]
        
        if current_p == '**':
            for i in range(len(path_segments) + 1):
                if self._match_recursive(remaining_p, path_segments[i:]):
                    return True
            return False
        else:
            if not path_segments:
                return False
            
            current_path = path_segments[0]
            if self._segment_matches(current_p, current_path):
                return self._match_recursive(remaining_p, path_segments[1:])
            else:
                return False

    def _segment_matches(self, pattern_seg, path_seg) -> bool:
        regex_parts = []
        i = 0
        while i < len(pattern_seg):
            char = pattern_seg[i]
            if char == '?':
                regex_parts.append('.')
                i += 1
            elif char == '*':
                regex_parts.append('.*')
                i += 1
            elif char == '[':
                j = i + 1
                while j < len(pattern_seg) and pattern_seg[j] != ']':
                    j += 1
                if j == len(pattern_seg):
                    raise ValueError("Unclosed [")
                
                content = pattern_seg[i+1:j]
                if not content:
                    raise ValueError("Empty class")
                
                negate = False
                if content.startswith('!'):
                    negate = True
                    content = content[1:]
                
                inner_part = ""
                k2 = 0
                while k2 < len(content):
                    if k2 + 2 < len(content) and content[k2+1] == '-' and \
                       content[k2] != '-' and content[k2+2] != '-':
                        inner_part += f"{re.escape(content[k2])}-{re.escape(content[k2+2])}"
                        k2 += 3
                    else:
                        inner_part += re.escape(content[k2])
                        k2 += 1
                
                if negate:
                    regex_parts.append(f"[^{inner_part}]")
                else:
                    regex_parts.append(f"[{inner_part}]")
                i = j + 1
            else:
                regex_parts.append(re.escape(char))
                i += 1
        
        pattern_regex = "^" + "".join(regex_parts) + "$"
        return bool(re.match(pattern_regex, path_seg))

    def select(self, patterns: list[str], paths: list[str]) -> list[str]:
        # Validate all patterns first
        for pattern in patterns:
            self._validate_pattern(pattern)
            
        selected_flags = [False] * len(paths)
        for pattern in patterns:
            is_negated = False
            if pattern.startswith('!'):
                is_negated = True
                pattern = pattern[1:]
            
            matches_this_pattern = []
            for i, path in enumerate(paths):
                if self.matches(pattern, path):
                    matches_this_pattern.append(i)
            
            if not is_negated:
                for i in matches_this_pattern:
                    selected_flags[i] = True
            else:
                for i in matches_this_pattern:
                    selected_flags[i] = False
        
        result = []
        for i, is_selected in enumerate(selected_flags):
            if is_selected:
                result.append(paths[i])
        return result

    def _validate_pattern(self, pattern: str):
        # A pattern is invalid if it has an unclosed [ or an empty class []
        for segment in pattern.split('/'):
            i = 0
            while i < len(segment):
                if segment[i] == '[':
                    j = i + 1
                    while j < len(segment) and segment[j] != ']':
                        j += 1
                    if j == len(segment):
                        raise ValueError("Unclosed [")
                    content = segment[i+1:j]
                    if not content:
                        raise ValueError("Empty class")
                    i = j + 1
                else:
                    i += 1

