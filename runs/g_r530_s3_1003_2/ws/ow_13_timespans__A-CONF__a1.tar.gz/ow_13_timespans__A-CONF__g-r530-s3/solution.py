from datetime import datetime, timezone

class Solution:
    def _parse_instant(self, instant: str) -> datetime:
        if len(instant) == 10 and instant[4] == '-': # YYYY-MM-DD
            return datetime.strptime(instant, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        elif len(instant) == 19 and instant[10] == 'T': # YYYY-MM-DDTHH:MM:SS
            return datetime.strptime(instant, "%Y-%m-%dT%H:%M:%S").replace(tzinfo=timezone.utc)
        else:
            raise ValueError(f"Invalid instant format: {instant}")

    def _format_instant(self, dt: datetime) -> str:
        return dt.strftime("%Y-%m-%dT%H:%M:%S")

    def merge(self, spans: list[tuple[str, str]]) -> list[tuple[str, str]]:
        parsed = []
        for start_str, end_str in spans:
            start = self._parse_instant(start_str)
            end = self._parse_instant(end_str)
            if end < start:
                raise ValueError(f"End {end_str} is before start {start_str}")
            parsed.append((start, end))

        # Filter out zero-length spans and sort by start time
        parsed = sorted([p for p in parsed if p[0] != p[1]], key=lambda x: x[0])
        
        if not parsed:
            return []

        merged = []
        curr_start, curr_end = parsed[0]

        for next_start, next_end in parsed[1:]:
            if next_start <= curr_end:
                curr_end = max(curr_end, next_end)
            else:
                merged.append((curr_start, curr_end))
                curr_start, curr_end = next_start, next_end
        
        merged.append((curr_start, curr_end))

        return [(self._format_instant(s), self._format_instant(e)) for s, e in merged]

    def subtract(self, spans: list[tuple[str, str]], holes: list[tuple[str, str]]) -> list[tuple[str, str]]:
        merged_spans = self.merge(spans)
        
        parsed_holes = []
        for h_start_str, h_end_str in holes:
            h_start = self._parse_instant(h_start_str)
            h_end = self._parse_instant(h_end_str)
            if h_end < h_start:
                raise ValueError(f"End {h_end_str} is before start {h_start_str}")
            parsed_holes.append((h_start, h_end))
        
        # Merge holes to simplify subtraction
        parsed_holes = sorted([p for p in parsed_holes if p[0] != p[1]], key=lambda x: x[0])
        merged_holes = []
        if parsed_holes:
            curr_h_start, curr_h_end = parsed_holes[0]
            for next_h_start, next_h_end in parsed_holes[1:]:
                if next_h_start <= curr_h_end:
                    curr_h_end = max(curr_h_end, next_h_end)
                else:
                    merged_holes.append((curr_h_start, curr_h_end))
                    curr_h_start, curr_h_end = next_h_start, next_h_end
            merged_holes.append((curr_h_start, curr_h_end))

        # Subtract merged holes from merged spans
        result = []
        for s_start_str, s_end_str in merged_spans:
            s_start = self._parse_instant(s_start_str)
            s_end = self._parse_instant(s_end_str)
            current_segments = [(s_start, s_end)]
            for h_start, h_end in merged_holes:
                next_segments = []
                for seg_start, seg_end in current_segments:
                    # If hole is completely outside segment
                    if h_end <= seg_start or h_start >= seg_end:
                        next_segments.append((seg_start, seg_end))
                    else:
                        # Hole overlaps with segment
                        if h_start > seg_start:
                            next_segments.append((seg_start, h_start))
                        if h_end < seg_end:
                            next_segments.append((h_end, seg_end))
                current_segments = next_segments
            result.extend(current_segments)

        # Final merge of the result (though it should already be merged/sorted if logic is correct)
        # But let's ensure it's sorted and unique just in case
        result = sorted([p for p in result if p[0] != p[1]], key=lambda x: x[0])
        final_merged = []
        if result:
            curr_start, curr_end = result[0]
            for next_start, next_end in result[1:]:
                if next_start <= curr_end:
                    curr_end = max(curr_end, next_end)
                else:
                    final_merged.append((curr_start, curr_end))
                    curr_start, curr_end = next_start, next_end
            final_merged.append((curr_start, curr_end))

        return [(self._format_instant(s), self._format_instant(e)) for s, e in final_merged]

    def total_seconds(self, spans: list[tuple[str, str]]) -> int:
        merged = self.merge(spans)
        total = 0
        for start_str, end_str in merged:
            start = self._parse_instant(start_str)
            end = self._parse_instant(end_str)
            total += int((end - start).total_seconds())
        return total

# The test script expects these methods to be available on the module level.
# However, it seems they are called as solution.merge(...), which means 
# if I have a class Solution and an instance 'solution', then solution.merge(...) works.
# Let's check how tests_visible.py imports it.

# Actually, let's just define the functions at module level to be safe.
def merge(spans: list[tuple[str, str]]) -> list[tuple[str, str]]:
    sol = Solution()
    return sol.merge(spans)

def subtract(spans: list[tuple[str, str]], holes: list[tuple[str, str]]) -> list[tuple[str, str]]:
    sol = Solution()
    return sol.subtract(spans, holes)

def total_seconds(spans: list[tuple[str, str]]) -> int:
    sol = Solution()
    return sol.total_seconds(spans)
