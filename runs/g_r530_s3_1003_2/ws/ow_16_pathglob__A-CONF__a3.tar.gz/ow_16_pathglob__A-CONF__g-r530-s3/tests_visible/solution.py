import re

class Solution:
    def _parse_segment(self, segment):
        if segment == "**":
            return "DOUBLE_STAR"
        parts = []
        i = 0
        while i < len(segment):
            char = segment[i]
            if char == "?":
                parts.append(("?",))
                i += 1
            elif char == "*":
                parts.append(("*",))
                i += 1
            elif char == "[":
                j = i + 1
                while j < len(segment) and segment[j] != "]":
                    j += 1
                if j == len(segment):
                    raise ValueError("Unclosed bracket")
                content = segment[i+1:j]
                if not content:
                    raise ValueError("Empty class")
                parts.append(self._parse_bracket(content))
                i = j + 1
            else:
                parts.append((char,))
                i += 1
        return parts

    def _parse_bracket(self, content):
        negate = False
        if content.startswith("!"):
            negate = True
            content = content[1:]
        chars = set()
        i = 0
        while i < len(content):
            if i + 2 < len(content) and content[i] == '-' and content[i+1].isalpha():
                start_char = content[i]
                end_char = content[i+2]
                for c in range(ord(start_char), ord(end_char) + 1):
                    chars.add(chr(c))
                i += 3
            else:
                chars.add(content[i])
                i += 1
        return ("bracket", chars, negate)

    def matches(self, pattern: str, path: str) -> bool:
        path_segments = path.split("/")
        pattern_segments = pattern.split("/")
        def match_segment(p_seg, s_seg):
            if p_seg == "**": return True
            p_parts = self._parse_segment(p_seg)
            s_chars = list(s_seg)
            memo_seg = {}
            def backtrack(p_idx, s_idx):
                state = (p_idx, s_idx)
                if state in memo_seg: return memo_seg[state]
                if p_idx == len(p_parts): return s_idx == len(s_chars)
                part = p_parts[p_idx]
                res = False
                if part[0] == "?":
                    if s_idx < len(s_chars): res = backtrack(p_idx + 1, s_idx + 1)
                elif part[0] == "*":
                    for skip in range(len(s_chars) - s_idx + 1):
                        if backtrack(p_idx + 1, s_idx + skip):
                            res = True; break
                elif part[0] == "bracket":
                    _, chars, negate = part
                    if s_idx < len(s_chars):
                        char = s_chars[s_idx]
                        is_in = char in chars
                        if (not negate and is_in) or (negate and not is_in):
                            res = backtrack(p_idx + 1, s_idx + 1)
                else:
                    if s_idx < len(s_chars) and s_chars[s_idx] == part[0]:
                        res = backtrack(p_idx + 1, s_idx + 1)
                memo_seg[state] = res
                return res
            return backtrack(0, 0)
        memo_full = {}
        def solve(p_idx, s_idx):
            state = (p_idx, s_idx)
            if state in memo_full: return memo_full[state]
            if p_idx == len(pattern_segments): return s_idx == len(path_segments)
            res = False
            p_seg = pattern_segments[p_idx]
            if p_seg == "**":
                if solve(p_idx + 1, s_idx): res = True
                else:
                    for next_s in range(s_idx + 1, len(path_segments) + 1):
                        if solve(p_idx + 1, next_s):
                            res = True; break
            else:
                if s_idx < len(path_segments):
                    if match_segment(p_seg, path_segments[s_idx]):
                        res = solve(p_idx + 1, s_idx + 1)
            memo_full[state] = res
            return res
        return solve(0, 0)

    def select(self, patterns: list[str], paths: list[str]) -> list[str]:
        for p in patterns:
            parts = p.split("/")
            for p_seg in parts:
                if p_seg == "**": continue
                i = 0
                while i < len(p_seg):
                    if p_seg[i] == "[":
                        j = p_seg.find("]", i)
                        if j == -1: raise ValueError("Unclosed bracket")
                        content = p_seg[i+1:j]
                        if not content: raise ValueError("Empty class")
                        i = j + 1
                    else: i += 1
        current_selection = [False] * len(paths)
        for p in patterns:
            if p.startswith("!"):
                sub_pattern = p[1:]
                for i, path in enumerate(paths):
                    if current_selection[i] and self.matches(sub_pattern, path):
                        current_selection[i] = False
            else:
                for i, path in enumerate(paths):
                    if not current_selection[i] and self.matches(p, path):
                        current_selection[i] = True
        return [paths[i] for i, s in enumerate(current_selection) if s]

sol = Solution()
matches = sol.matches
select = sol.select
