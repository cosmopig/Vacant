from datetime import datetime, timedelta

def parse_instant(instant: str) -> datetime:
    if len(instant) == 10 and instant[4] == '-':
        # YYYY-MM-DD
        return datetime.strptime(instant, "%Y-%m-%d")
    elif len(instant) == 19 and instant[10] == 'T':
        # YYYY-MM-DDTHH:MM:SS
        return datetime.strptime(instant, "%Y-%m-%dT%H:%M:%S")
    else:
        raise ValueError(f"Invalid instant format: {instant}")

def format_instant(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%S")

def merge(spans: list[tuple[str, str]]) -> list[tuple[str, str]]:
    parsed = []
    for start_str, end_str in spans:
        start = parse_instant(start_str)
        end = parse_instant(end_str)
        if end < start:
            raise ValueError(f"End {end_str} is before start {start_str}")
        if start == end:
            continue
        parsed.append((start, end))
    
    if not parsed:
        return []
    
    # Sort by start time
    parsed.sort()
    
    merged = []
    curr_start, curr_end = parsed[0]
    
    for i in range(1, len(parsed)):
        next_start, next_end = parsed[i]
        if next_start <= curr_end:
            curr_end = max(curr_end, next_end)
        else:
            merged.append((curr_start, curr_end))
            curr_start, curr_end = next_start, next_end
    
    merged.append((curr_start, curr_end))
    
    return [(format_instant(s), format_instant(e)) for s, e in merged]

def subtract(spans: list[tuple[str, str]], holes: list[tuple[str, str]]) -> list[tuple[str, str]]:
    # First merge the spans
    merged_spans = merge(spans)
    if not merged_spans:
        return []
    
    parsed_spans = [(parse_instant(s), parse_instant(e)) for s, e in merged_spans]
    
    # Parse and merge holes too? The contract says "every instant covered by holes removed"
    # It doesn't say the holes are tidy. But it's easier if they are.
    parsed_holes = []
    for h_start_str, h_end_str in holes:
        h_start = parse_instant(h_start_str)
        h_end = parse_instant(h_end_str)
        if h_end < h_start:
            raise ValueError(f"End {h_end_str} is before start {h_start_str}")
        if h_start == h_end:
            continue
        parsed_holes.append((h_start, h_end))
    
    if not parsed_holes:
        return merged_spans

    # Sort and merge holes to simplify subtraction
    parsed_holes.sort()
    merged_holes = []
    curr_h_start, curr_h_end = parsed_holes[0]
    for i in range(1, len(parsed_holes)):
        next_h_start, next_h_end = parsed_holes[i]
        if next_h_start <= curr_h_end:
            curr_h_end = max(curr_h_end, next_h_end)
        else:
            merged_holes.append((curr_h_start, curr_h_end))
            curr_h_start, curr_h_end = next_h_start, next_h_end
    merged_holes.append((curr_h_start, curr_h_end))

    result_spans = []
    for s_start, s_end in parsed_spans:
        current_segments = [(s_start, s_end)]
        for h_start, h_end in merged_holes:
            next_segments = []
            for seg_start, seg_end in current_segments:
                # If hole is completely outside segment
                if h_end <= seg_start or h_start >= seg_end:
                    next_segments.append((seg_start, seg_end))
                else:
                    # Hole overlaps with segment
                    if h_start > seg_start:
                        next_segments.append((seg_start, h_start))
                    if h_end < seg_end:
                        next_segments.append((h_end, seg_end))
            current_segments = next_segments
        result_spans.extend(current_segments)
    
    # The result needs to be tidy (merged and ordered). 
    # Since we processed merged_spans in order and holes are also sorted/merged, 
    # the segments should already be mostly orderly but might need a final merge-like pass 
    # if they touch. Actually, subtraction of disjoint holes from a merged span 
    # won't create new overlaps or touching spans unless we have multiple spans.
    # Let's just re-run merge on the result to be safe and ensure "shortest list".
    
    final_spans = []
    for seg_start, seg_end in result_spans:
        if seg_start == seg_end: continue
        final_spans.append((seg_start, seg_end))
    
    # Re-merge to handle cases where subtraction might have left touching spans 
    # (though with disjoint holes it shouldn't happen) or if we had multiple input spans.
    if not final_spans: return []
    final_spans.sort()
    tidy = []
    curr_s, curr_e = final_spans[0]
    for i in range(1, len(final_spans)):
        next_s, next_e = final_spans[i]
        if next_s <= curr_e:
            curr_e = max(curr_e, next_e)
        else:
            tidy.append((curr_s, curr_e))
            curr_s, curr_e = next_s, next_e
    tidy.append((curr_s, curr_e))
    
    return [(format_instant(s), format_instant(e)) for s, e in tidy]

def total_seconds(spans: list[tuple[str, str]]) -> int:
    merged = merge(spans)
    total = 0
    for start_str, end_str in merged:
        start = parse_instant(start_str)
        end = parse_instant(end_str)
        total += (end - start).total_seconds()
    return int(total)

# The test runner expects a class or functions? 
# Looking at tests_visible/test_visible.py, it imports 'solution'.
# If I define them as top-level functions and the test calls solution.merge(...), 
# then I need to put them in a Solution class OR just make sure they are accessible.
# The error was AttributeError: module 'solution' has no attribute 'merge'.
# This means it expects `solution.merge(...)`.

class Solution:
    def merge(self, spans: list[tuple[str, str]]) -> list[tuple[str, str]]:
        return merge(spans)
    def subtract(self, spans: list[tuple[str, str]], holes: list[tuple[str, str]]) -> list[tuple[str, str]]:
        return subtract(spans, holes)
    def total_seconds(self, spans: list[tuple[str, str]]) -> int:
        return total_seconds(spans)

solution = Solution()
