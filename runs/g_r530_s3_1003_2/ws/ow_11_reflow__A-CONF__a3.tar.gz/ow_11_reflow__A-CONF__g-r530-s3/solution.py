import unicodedata
import re

def get_width(text):
    return sum(2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1 for ch in text)

class Reflow:
    def __init__(self, width):
        if width <= 0:
            raise ValueError("Width must be positive")
        self.width = width

    def reflow(self, text):
        lines = text.splitlines(keepends=True)
        has_trailing_newline = text.endswith('\n')
        
        segments = []
        i = 0
        while i < len(lines):
            line = lines[i]
            if line.startswith("```"):
                block_lines = [line]
                i += 1
                while i < len(lines) and not lines[i].startswith("```"):
                    block_lines.append(lines[i])
                    i += 1
                if i < len(lines):
                    block_lines.append(lines[i])
                    i += 1
                segments.append(('code', "".join(block_lines)))
            else:
                non_code_lines = []
                while i < len(lines) and not lines[i].startswith("```"):
                    non_code_lines.append(lines[i])
                    i += 1
                segments.append(('text', "".join(non_code_lines)))

        final_output = []
        for seg_type, content in segments:
            if seg_type == 'code':
                final_output.append(content)
            else:
                raw_lines = content.splitlines()
                if not raw_lines: continue
                
                paragraphs_and_blanks = []
                current_block = []
                for line in raw_lines:
                    if line.isspace() or not line:
                        if current_block:
                            paragraphs_and_blanks.append(current_block)
                            current_block = []
                        paragraphs_and_blanks.append("") 
                    else:
                        current_block.append(line)
                if current_block:
                    paragraphs_and_blanks.append(current_block)

                for item in paragraphs_and_blanks:
                    if item == "":
                        final_output.append("\n")
                    else:
                        self._process_paragraph(item, final_output)

        result = "".join(final_output)
        if has_trailing_newline and not result.endswith('\n'):
            result += '\n'
        return result

    def _process_paragraph(self, para_lines, output):
        first_line = para_lines[0]
        stripped = first_line.lstrip()
        is_bullet = False
        if stripped.startswith("- ") or stripped.startswith("* "):
            is_bullet = True
        else:
            match = re.match(r"^\d+\.\s", stripped)
            if match:
                is_bullet = True

        first_indent = len(first_line) - len(stripped)
        marker_len = 0
        if is_bullet:
            if stripped.startswith("- "): marker_len = 3
            elif stripped.startswith("* "): marker_len = 3
            else: # digits.
                match = re.match(r"^(\d+)\.\s", stripped)
                marker_len = len(match.group(0))

        words = []
        for i, line in enumerate(para_lines):
            if i == 0:
                content_start = first_indent + (marker_len if is_bullet else 0)
                line_content = line[content_start:]
                parts = re.split(r"[\t ]+", line_content)
                words.extend([p for p in parts if p])
            else:
                content_start = (marker_len if is_bullet else first_indent)
                line_content = line[content_start:]
                parts = re.split(r"[\t ]+", line_content)
                words.extend([p for p in parts if p])

        P_cont = (marker_len if is_bullet else first_indent)
        first_line_prefix = first_line[:first_indent + (marker_len if is_bullet else 0)]

        wrapped_lines = []
        current_line_words = []
        
        word_idx = 0
        while word_idx < len(words):
            word = words[word_idx]
            w_width = get_width(word)
            
            if not wrapped_lines:
                # First wrapped line
                prefix = first_line_prefix
                p_width = get_width(prefix)
                if w_width > self.width - p_width:
                    wrapped_lines.append(prefix + word)
                    current_line_words = [word]
                else:
                    current_line_words.append(word)
            else:
                # Continuation wrapped line
                prefix = " " * P_cont
                p_width = get_width(prefix)
                if not current_line_words:
                    if w_width > self.width - p_width:
                        wrapped_lines.append(prefix + word)
                        current_line_words = [word]
                    else:
                        current_line_words.append(word)
                else:
                    # Try adding to current continuation line
                    if get_width(" ".join(current_line_words)) + 1 + w_width <= self.width - p_width:
                        current_line_words.append(word)
                    else:
                        wrapped_lines.append(prefix + " ".join(current_line_words))
                        current_line_words = [word]
            word_idx += 1
        
        if current_line_words:
            if not wrapped_lines:
                wrapped_lines.append(first_line_prefix + " ".join(current_line_words))
            else:
                wrapped_lines.append(" " * P_cont + " ".join(current_line_words))

        for wl in wrapped_lines:
            output.append(wl + "\n")

def reflow(text, width):
    return Reflow(width).reflow(text)
