import re

class Solution:
    def _get_regex(self, p_seg: str) -> str:
        if p_seg == '**':
            return None
        regex_parts = []
        i = 0
        while i < len(p_seg):
            char = p_seg[i]
            if char == '?':
                regex_parts.append('.')
            elif char == '*':
                regex_parts.append('.*')
            elif char == '[':
                end = p_seg.find(']', i)
                if end == -1:
                    raise ValueError("Unclosed bracket")
                content = p_seg[i+1:end]
                if content == "":
                    raise ValueError("Empty class")
                negate = False
                if content.startswith('!'):
                    negate = True
                    content = content[1:]
                chars = set()
                j = 0
                while j < len(content):
                    if j + 1 < len(content) and content[j+1] == '-':
                        start_char = content[j]
                        end_char = content[j+2]
                        for c in range(ord(start_char), ord(end_char) + 1):
                            chars.add(chr(c))
                        j += 3
                    else:
                        chars.add(content[j])
                        j += 1
                if negate:
                    regex_parts.append(f"[^" + "".join(sorted(list(chars))) + "]")
                else:
                    regex_parts.append(f"[{''.join(sorted(list(chars)))}]")
                i = end + 1
            else:
                regex_parts.append(re.escape(char))
                i += 1
        return "".join(regex_parts)

    def _match_segments(self, p_segs, path_segs):
        n = len(p_segs)
        m = len(path_segs)
        dp = [[False] * (m + 1) for _ in range(n + 1)]
        dp[0][0] = True

        for i in range(n):
            seg = p_segs[i]
            if seg == '**':
                found_true = False
                for j in range(m + 1):
                    if dp[i][j]:
                        found_true = True
                    elif found_true:
                        dp[i+1][j] = True
            else:
                reg = self._get_regex(seg)
                for j in range(m):
                    if dp[i][j]:
                        if re.fullmatch(reg, path_segs[j]):
                            dp[i+1][j+1] = True
        return dp[n][m]

    def matches(self, pattern: str, path: str) -> bool:
        return self._match_segments(pattern.split('/'), path.split('/'))

    def select(self, patterns: list[str], paths: list[str]) -> list[str]:
        for p in patterns:
            p_segs = p.split('/')
            for seg in p_segs:
                if seg == '**': continue
                self._get_regex(seg)

        current_selection = set()
        for p in patterns:
            if p.startswith('!'):
                sub_pattern = p[1:]
                sub_segs = sub_pattern.split('/')
                to_remove = []
                for path in current_selection:
                    if self._match_segments(sub_segs, path.split('/')):
                        to_remove.append(path)
                for r in to_remove:
                    current_selection.remove(r)
            else:
                p_segs = p.split('/')
                for path in paths:
                    if path not in current_selection:
                        if self._match_segments(p_segs, path.split('/')):
                            current_selection.add(path)
        
        result = []
        for path in paths:
            if path in current_selection:
                result.append(path)
        return result

