from solution import Solution

def test():
    sol = Solution()
    # Test matches
    assert sol.matches("src/*.py", "src/main.py") == True
    assert sol.matches("src/*.py", "src/main.pyc") == False
    assert sol.matches("src/*.py", "src/subdir/main.py") == False
    assert sol.matches("**", "") == True
    assert sol.matches("**", "a/b/c") == True
    assert sol.matches("a/**", "a/b/c") == True
    assert sol.matches("a/**", "a") == True
    assert sol.matches("a/*/c", "a/b/c") == True
    assert sol.matches("a/*/c", "a/b/d") == False
    assert sol.matches("a[bc]d", "abcd") == True
    assert sol.matches("a[bc]d", "acd") == True
    assert sol.matches("a[bd]d", "abd") == True
    assert sol.matches("a[bd]d", "acd") == False
    assert sol.matches("a[!bcd]", "af") == True
    assert sol.matches("a[a-z]", "az") == True
    assert sol.matches("a[0-9]", "a1") == True
    assert sol.matches("a[0-9]", "ax") == False

    # Test select
    paths = ["src/main.py", "src/utils.py", "tests/test_main.py", "docs/readme.md"]
    patterns = ["src/*", "!src/utils.py"]
    assert sol.select(patterns, paths) == ["src/main.py"]

    paths2 = ["a/b/c", "a/b/d", "a/x/y", "z/y/z"]
    patterns2 = ["a/**", "!a/x/y"]
    assert sol.select(patterns2, paths2) == ["a/b/c", "a/b/d"]

    paths3 = ["file1.txt", "file2.txt", "dir/file1.txt"]
    patterns3 = ["*.txt", "!dir/*"]
    assert sol.select(patterns3, paths3) == ["file1.txt", "file2.txt"]

    paths4 = ["a/b/c", "a/b/d", "a/e/f"]
    patterns4 = ["a/**", "!a/b/*"]
    assert sol.select(patterns4, paths4) == ["a/e/f"]

    # Test errors
    try:
        sol.matches("a[", "a")
    except ValueError:
        pass
    else:
        raise AssertionError("Should have raised ValueError for unclosed bracket")

    try:
        sol.matches("a[]", "a")
    except ValueError:
        pass
    else:
        raise AssertionError("Should have raised ValueError for empty class")

    print("All tests passed!")

if __name__ == "__main__":
    test()
