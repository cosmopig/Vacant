import re

AWS_KEY_REGEX = r'AKIA[A-Z0-9]{16}'
DB_URL_REGEX = r'(?:postgres|mysql|mongodb|redis|amqp)://[^/\s]+/[^/\s]*'
BEARER_TOKEN_REGEX = r'(?<=Bearer\s)[a-zA-Z0-9\-\._~+/]+(?:\.[a-zA-Z0-9\-\._~+/]+)*'

def redact(text: str) -> str:
    patterns = [AWS_KEY_REGEX, DB_URL_REGEX, BEARER_TOKEN_REGEX]
    all_matches = []
    for pattern in patterns:
        for m in re.finditer(pattern, text):
            all_matches.append(m)
    
    all_matches.sort(key=lambda x: (x.start(), -len(x.group(0))))
    
    filtered_matches = []
    last_end = -1
    for m in all_matches:
        if m.start() >= last_end:
            filtered_matches.append(m)
            last_end = m.end()

    result = []
    last_idx = 0
    for m in filtered_matches:
        result.append(text[last_idx:m.start()])
        result.append("[REDACTED]")
        last_idx = m.end()
    result.append(text[last_idx:])
    
    return "".join(result)

def findings(text: str) -> list[str]:
    patterns = [AWS_KEY_REGEX, DB_URL_REGEX, BEARER_TOKEN_REGEX]
    all_matches = []
    for pattern in patterns:
        for m in re.finditer(pattern, text):
            all_matches.append(m)
    
    all_matches.sort(key=lambda x: (x.start(), -len(x.group(0))))
    
    filtered_matches = []
    last_end = -1
    for m in all_matches:
        if m.start() >= last_end:
            filtered_matches.append(m)
            last_end = m.end()
            
    return [m.group(0) for m in filtered_matches]
