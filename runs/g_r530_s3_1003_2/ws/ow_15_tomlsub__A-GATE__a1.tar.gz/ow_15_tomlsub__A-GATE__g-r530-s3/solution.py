import re

class Solution:
    def parse(self, text: str) -> dict:
        data = {}
        current_group = data
        lines = text.splitlines()
        opened_headings = set()

        for i, line in enumerate(lines):
            line_num = i + 1
            comment_start = -1
            in_string = False
            quote_char = None
            escaped = False
            for j, char in enumerate(line):
                if escaped:
                    escaped = False
                    continue
                if char == '\\':
                    escaped = True
                    continue
                if char == '"':
                    if not in_string:
                        in_string = True
                        quote_char = '"'
                    else:
                        in_string = False
                        quote_char = None
                elif char == '#' and not in_string:
                    comment_start = j
                    break
            
            if comment_start != -1:
                line = line[:comment_start]
            
            stripped = line.strip()
            if not stripped or stripped.startswith('#'):
                continue

            if stripped.startswith('[') and stripped.endswith(']'):
                heading_content = stripped[1:-1].strip()
                parts = heading_content.split('.')
                full_path = ".".join(parts)
                
                if full_path in opened_headings:
                    raise ValueError(f"line {line_num}: heading opened twice")
                opened_headings.add(full_path)

                current_group = data
                for part in parts:
                    if not re.match(r'^[a-zA-Z0-9_-]+$', part):
                        raise ValueError(f"line {line_num}: invalid name")
                    if part not in current_group:
                        current_group[part] = {}
                    current_group = current_group[part]
            elif '=' in stripped:
                name, val_part = stripped.split('=', 1)
                name = name.strip()
                val_part = val_part.strip()

                if not re.match(r'^[a-zA-Z0-9_-]+$', name):
                    raise ValueError(f"line {line_num}: invalid name")
                if name in current_group:
                    raise ValueError(f"line {line_num}: name used twice in one group")

                parsed_val = None
                if val_part.startswith('"') and val_part.endswith('"'):
                    inner = val_part[1:-1]
                    res = ""
                    j = 0
                    while j < len(inner):
                        if inner[j] == '\\':
                            j += 1
                            if j >= len(inner): break
                            char = inner[j]
                            if char == 'n': res += '\n'
                            elif char == 't': res += '\t'
                            elif char == '"': res += '"'
                            elif char == '\\': res += '\\'
                            else: raise ValueError(f"line {line_num}: invalid escape")
                        else:
                            res += inner[j]
                        j += 1
                    parsed_val = res
                elif val_part == 'true':
                    parsed_val = True
                elif val_part == 'false':
                    parsed_val = False
                elif '.' in val_part:
                    parts = val_part.split('.')
                    if len(parts) == 2 and parts[0].isdigit() and parts[1].isdigit():
                        parsed_val = float(val_part)
                    else:
                        raise ValueError(f"line {line_num}: invalid value")
                elif val_part.replace('-', '', 1).isdigit():
                    if val_part.startswith('-'):
                        parsed_val = int(val_part[1:])
                    else:
                        parsed_val = int(val_part)
                elif val_part.startswith('[') and val_part.endswith(']'):
                    inner = val_part[1:-1].strip()
                    if not inner:
                        parsed_val = []
                    else:
                        items = [x.strip() for x in inner.split(',')]
                        first_item = items[0]
                        kind = None
                        if first_item.startswith('"') and first_item.endswith('"'):
                            kind = 'str'
                        elif first_item == 'true':
                            kind = 'bool'
                        elif first_item == 'false':
                            kind = 'bool'
                        elif first_item.replace('-', '', 1).isdigit():
                            if first_item.startswith('-'): kind = 'int'
                            else: kind = 'int'
                        elif '.' in first_item and first_item.replace('.', '', 1).isdigit():
                            kind = 'float'
                        else:
                            raise ValueError(f"line {line_num}: invalid list")
                        
                        parsed_list = []
                        for item in items:
                            if kind == 'str':
                                if not (item.startswith('"') and item.endswith('"')):
                                    raise ValueError(f"line {line_num}: mixed list")
                                inner = item[1:-1]
                                res = ""
                                j = 0
                                while j < len(inner):
                                    if inner[j] == '\\':
                                        j += 1
                                        if j >= len(inner): break
                                        char = inner[j]
                                        if char == 'n': res += '\n'
                                        elif char == 't': res += '\t'
                                        elif char == '"': res += '"'
                                        elif char == '\\': res += '\\'
                                        else: raise ValueError(f"line {line_num}: invalid escape")
                                    else:
                                        res += inner[j]
                                    j += 1
                                parsed_list.append(res)
                            elif kind == 'bool':
                                if item == 'true': parsed_list.append(True)
                                elif item == 'false': parsed_list.append(False)
                                else: raise ValueError(f"line {line_num}: mixed list")
                            elif kind == 'int':
                                if item.startswith('-'): parsed_list.append(int(item[1:]))
                                else: parsed_list.append(int(item))
                            elif kind == 'float':
                                parts = item.split('.')
                                if len(parts) == 2 and parts[0].isdigit() and parts[1].isdigit():
                                    parsed_list.append(float(item))
                                else: raise ValueError(f"line {line_num}: mixed list")
                        parsed_val = parsed_list
                else:
                    raise ValueError(f"line {line_num}: invalid value")

                current_group[name] = parsed_val

        return data

    def dumps(self, data: dict) -> str:
        lines = []
        top_keys = sorted([k for k in data.keys() if not isinstance(data[k], dict)])
        for k in top_keys:
            val = data[k]
            if isinstance(val, str):
                escaped_v = val.replace('\\', '\\\\').replace('"', '\\"')
                lines.append(f'{k} = "{escaped_v}"')
            elif isinstance(val, bool):
                lines.append(f'{k} = {"true" if val else "false"}')
            elif isinstance(val, int):
                lines.append(f'{k} = {val}')
            elif isinstance(val, float):
                s = str(val)
                if '.' in s:
                    parts = s.split('.')
                    if not (parts[0].isdigit() and parts[1].isdigit()):
                        pass
                lines.append(f'{k} = {s}')
            elif isinstance(val, list):
                if not val:
                    lines.append(f'{k} = []')
                else:
                    items = []
                    for v in val:
                        if isinstance(v, str):
                            escaped_v = v.replace('\\', '\\\\').replace('"', '\\"')
                            items.append(f'"{escaped_v}"')
                        elif isinstance(v, bool):
                            items.append("true" if v else "false")
                        elif isinstance(v, int):
                            items.append(str(v))
                        elif isinstance(v, float):
                            s = str(v)
                            if '.' in s:
                                parts = s.split('.')
                                if not (parts[0].isdigit() and parts[1].isdigit()):
                                    pass
                            items.append(s)
                        else:
                            raise ValueError("List contains invalid type")
                    lines.append(f'{k} = [{", ".join(items)}]')

        heading_keys = sorted([k for k in data.keys() if isinstance(data[k], dict)])
        for k in heading_keys:
            if lines and lines[-1] != "":
                lines.append("")
            lines.append(f"[{k}]")
            self._dump_group(data[k], lines)
            
        return "\n".join(lines).strip()

    def _dump_group(self, group, lines):
        group_names = sorted([k for k in group.keys() if not isinstance(group[k], dict)])
        for k in group_names:
            val = group[k]
            if isinstance(val, str):
                escaped_v = val.replace('\\', '\\\\').replace('"', '\\"')
                lines.append(f'{k} = "{escaped_v}"')
            elif isinstance(val, bool):
                lines.append(f'{k} = {"true" if val else "false"}')
            elif isinstance(val, int):
                lines.append(f'{k} = {val}')
            elif isinstance(val, float):
                s = str(val)
                if '.' in s:
                    parts = s.split('.')
                    if not (parts[0].isdigit() and parts[1].isdigit()):
                        pass
                lines.append(f'{k} = {s}')
            elif isinstance(val, list):
                if not val:
                    lines.append(f'{k} = []')
                else:
                    items = []
                    for v in val:
                        if isinstance(v, str):
                            escaped_v = v.replace('\\', '\\\\').replace('"', '\\"')
                            items.append(f'"{escaped_v}"')
                        elif isinstance(v, bool):
                            items.append("true" if v else "false")
                        elif isinstance(v, int):
                            items.append(str(v))
                        elif isinstance(v, float):
                            s = str(v)
                            if '.' in s:
                                parts = s.split('.')
                                if not (parts[0].isdigit() and parts[1].isdigit()):
                                    pass
                            items.append(s)
                        else:
                            raise ValueError("List contains invalid type")
                    lines.append(f'{k} = [{", ".join(items)}]')

        sub_heading_keys = sorted([k for k in group.keys() if isinstance(group[k], dict)])
        for k in sub_heading_keys:
            if lines and lines[-1] != "":
                lines.append("")
            lines.append(f"[{k}]")
            self._dump_group(group[k], lines)

parse = Solution().parse
dumps = Solution().dumps
