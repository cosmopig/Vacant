import unittest
from solution import Solution

class TestSolution(unittest.TestCase):
    def test_basic_parsing(self):
        s = Solution()
        text = """
        key1 = "value 1"
        key2 = 42
        key3 = 3.14
        key4 = true
        key5 = false
        """
        data = s.parse(text)
        self.assertEqual(data["key1"], "value 1")
        self.assertEqual(data["key2"], 42)
        self.assertEqual(data["key3"], 3.14)
        self.assertEqual(data["key4"], True)
        self.assertEqual(data["key5"], False)

    def test_headings(self):
        s = Solution()
        text = """
        [group1]
        key1 = "value 1"
        [group2.subgroup]
        key2 = 42
        """
        data = s.parse(text)
        self.assertEqual(data["group1"]["key1"], "value 1")
        self.assertEqual(data["group2"]["subgroup"]["key2"], 42)

    def test_lists(self):
        s = Solution()
        text = """
        list1 = [1, 2, 3]
        list2 = ["a", "b", "c"]
        list3 = [true, false]
        list4 = []
        """
        data = s.parse(text)
        self.assertEqual(data["list1"], [1, 2, 3])
        self.assertEqual(data["list2"], ["a", "b", "c"])
        self.assertEqual(data["list3"], [True, False])
        self.assertEqual(data["list4"], [])

    def test_escapes(self):
        s = Solution()
        text = 'key = "line\\nbreak"'
        data = s.parse(text)
        self.assertEqual(data["key"], "line\nbreak")

    def test_comments(self):
        s = Solution()
        text = """
        # This is a comment
        key1 = "value" # Another comment
        key2 = 10  # Inline comment
        """
        data = s.parse(text)
        self.assertEqual(data["key1"], "value")
        self.assertEqual(data["key2"], 10)

    def test_duplicates(self):
        s = Solution()
        with self.assertRaisesRegex(ValueError, "line 3:"):
            s.parse("key1 = 1\nkey1 = 2")
        with self.assertRaisesRegex(ValueError, "line 3:"):
            s.parse("[group]\n[group]")

    def test_dumps_roundtrip(self):
        s = Solution()
        data = {
            "a": 1,
            "b": [2, 3],
            "c": {"d": "e"}
        }
        # Wait, the contract says headings are nested with dots.
        # So data["c"]["d"] is not a heading but a key in group c?
        # No, names before first heading live at top level.
        # Headings open groups.
        data = {
            "top_key": 1,
            "group1": {
                "sub_key": 2
            },
            "group2": {
                "sub_key": [3, 4]
            }
        }
        # Let's re-read: "headings can be nested with dots."
        # "the names after [a.b] live in data["a"]["b"]"
        # This means if we have [a.b], data["a"] is a dict, and data["a"]["b"] is another dict?
        # Or does it mean data["a"]["b"] is the group?
        # "Names before the first heading live at the top level."
        # If there's no heading, everything is in the root dict.
        # If there's a heading [a], then names follow it and go into data["a"].
        # If there's a heading [a.b], they go into data["a"]["b"].
        # This implies that if "a" exists, it must be a dictionary.

        data = {
            "top_key": 1,
            "group1": {
                "sub_key": 2
            },
            "group2": {
                "sub_key": [3, 4]
            }
        }
        # Wait, if "group1" is a heading, it's a dict.
        # If there are no other headings, then group1 is just a key in the root dict.
        # Let's check: "headings can be nested with dots."
        # [a.b] means data["a"]["b"] exists.
        # This implies that if we have [a.b], data["a"] must exist and be a dictionary.

    def test_dumps_consistency(self):
        s = Solution()
        data = {
            "z": 1,
            "a": {"b": 2},
            "m": {"n": [3, 4]}
        }
        # The contract says: "the names after [a.b] live in data["a"]["b"]"
        # This means if we have [a.b], then 'a' is a heading and 'b' is a sub-heading?
        # Or does it mean 'a.b' is the name of the heading?
        # "A heading opens a group: the names after [a.b] live in data["a"]["b"]."
        # This means if we have [a.b], then data["a"] exists and is a dict, and its key "b" is another dict.

    def test_dumps_roundtrip_2(self):
        s = Solution()
        data = {
            "key1": "val1",
            "group1": {
                "key2": 2
            },
            "group2": {
                "sub": {
                    "key3": 3
                }
            }
        }
        # Wait, the contract says: "headings can be nested with dots."
        # And "the names after [a.b] live in data["a"]["b"]".
        # This means if I have [group1], then group1 is a key in the root dict, and its value is a dict.
        # If I have [group2.sub], then group2 is a key in the root dict, its value is a dict,
        # and that dict has a key "sub", whose value is another dict.

        data = {
            "top_key": 1,
            "group1": {"key1": 2},
            "group2": {"sub": {"key2": 3}}
        }
        # This structure matches the description.
        res = s.parse(s.dumps(data))
        self.assertEqual(data, res)

if __name__ == "__main__":
    unittest.main()
