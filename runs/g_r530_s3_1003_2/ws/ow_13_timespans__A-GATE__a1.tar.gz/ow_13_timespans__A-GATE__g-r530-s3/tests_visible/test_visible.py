import unittest
from solution import Solution

class TestSolution(unittest.TestCase):
    def setUp(self):
        self.sol = Solution()

    def test_merge(self):
        # Overlapping
        self.assertEqual(self.sol.merge([("2023-01-01T10:00:00", "2023-01-01T11:00:00"), ("2023-01-01T10:30:00", "2023-01-01T11:30:00")]), [("2023-01-01T10:00:00", "2023-01-01T11:30:00")])
        # Touching
        self.assertEqual(self.sol.merge([("2023-01-01T10:00:00", "2023-01-01T11:00:00"), ("2023-01-01T11:00:00", "2023-01-01T12:00:00")]), [("2023-01-01T10:00:00", "2023-01-01T12:00:00")])
        # Disjoint
        self.assertEqual(self.sol.merge([("2023-01-01T10:00:00", "2023-01-01T11:00:00"), ("2023-01-01T12:00:00", "2023-01-01T13:00:00")]), [("2023-01-01T10:00:00", "2023-01-01T11:00:00"), ("2023-01-01T12:00:00", "2023-01-01T13:00:00")])
        # Date only
        self.assertEqual(self.sol.merge([("2023-01-01", "2023-01-02"), ("2023-01-01T00:00:00", "2023-01-01T01:00:00")]), [("2023-01-01T00:00:00", "2023-01-02T00:00:00")])
        # No length
        self.assertEqual(self.sol.merge([("2023-01-01T10:00:00", "2023-01-01T10:00:00")]), [])
    
    def test_subtract(self):
        # Simple subtraction
        self.assertEqual(self.sol.subtract([("2023-01-01T10:00:00", "2023-01-01T12:00:00")], [("2023-01-01T10:30:00", "2023-01-01T11:30:00")]), [("2023-01-01T10:00:00", "2023-01-01T10:30:00"), ("2023-01-01T11:30:00", "2023-01-01T12:00:00")])
        # Subtracting whole span
        self.assertEqual(self.sol.subtract([("2023-01-01T10:00:00", "2023-01-01T12:00:00")], [("2023-01-01T10:00:00", "2023-01-01T12:00:00")]), [])
        # Subtracting overlapping holes
        self.assertEqual(self.sol.subtract([("2023-01-01T10:00:00", "2023-01-01T12:00:00")], [("2023-01-01T10:30:00", "2023-01-01T11:30:00"), ("2023-01-01T11:00:00", "2023-01-01T12:00:00")]), [("2023-01-01T10:00:00", "2023-01-01T10:30:00")])
        # Subtracting holes that don't overlap spans
        self.assertEqual(self.sol.subtract([("2023-01-01T10:00:00", "2023-01-01T11:00:00")], [("2023-01-01T12:00:00", "2023-01-01T13:00:00")]), [("2023-01-01T10:00:00", "2023-01-01T11:00:00")])

    def test_total_seconds(self):
        self.assertEqual(self.sol.total_seconds([("2023-01-01T10:00:00", "2023-01-01T10:00:10")]), 10)
        self.assertEqual(self.sol.total_seconds([("2023-01-01T10:00:00", "2023-01-01T10:00:10"), ("2023-01-01T10:00:05", "2023-01-01T10:00:15")]), 15)
        self.assertEqual(self.sol.total_seconds([("2023-01-01", "2023-01-02")]), 86400)

    def test_errors(self):
        with self.assertRaises(ValueError):
            self.sol.merge([("2023-01-01T11:00:00", "2023-01-01T10:00:00")])
        with self.assertRaises(ValueError):
            self.sol._parse_instant("invalid")
        with self.assertRaises(ValueError):
            self.sol.subtract([("2023-01-01T10:00:00", "2023-01-01T11:00:00")], [("2023-01-01T11:00:00", "2023-01-01T10:00:00")])

if __name__ == "__main__":
    unittest.main()
