from datetime import datetime, timedelta

class Solution:
    def _parse_instant(self, instant: str) -> datetime:
        if len(instant) == 10 and instant[4] == '-':
            # YYYY-MM-DD
            return datetime.strptime(instant, "%Y-%m-%d")
        elif len(instant) == 19 and instant[4] == '-' and instant[10] == 'T':
            # YYYY-MM-DDTHH:MM:SS
            return datetime.strptime(instant, "%Y-%m-%dT%H:%M:%S")
        else:
            raise ValueError(f"Invalid instant format: {instant}")

    def _format_instant(self, dt: datetime) -> str:
        return dt.strftime("%Y-%m-%dT%H:%M:%S")

    def merge(self, spans: list[tuple[str, str]]) -> list[tuple[str, str]]:
        parsed_spans = []
        for start_str, end_str in spans:
            start = self._parse_instant(start_str)
            end = self._parse_instant(end_str)
            if end < start:
                raise ValueError(f"End {end_str} is earlier than start {start_str}")
            if start == end:
                continue
            parsed_spans.append((start, end))

        if not parsed_spans:
            return []

        # Sort by start time
        parsed_spans.sort()

        merged = []
        curr_start, curr_end = parsed_spans[0]

        for i in range(1, len(parsed_spans)):
            next_start, next_end = parsed_spans[i]
            if next_start <= curr_end:
                curr_end = max(curr_end, next_end)
            else:
                merged.append((curr_start, curr_end))
                curr_start, curr_end = next_start, next_end
        
        merged.append((curr_start, curr_end))

        return [(self._format_instant(s), self._format_instant(e)) for s, e in merged]

    def subtract(self, spans: list[tuple[str, str]], holes: list[tuple[str, str]]) -> list[tuple[str, str]]:
        # First merge the input spans
        merged_spans = self.merge(spans)
        if not merged_spans:
            return []

        # Parse holes and sort them
        parsed_holes = []
        for h_start_str, h_end_str in holes:
            h_start = self._parse_instant(h_start_str)
            h_end = self._parse_instant(h_end_str)
            if h_end < h_start:
                raise ValueError(f"End {h_end_str} is earlier than start {h_start_str}")
            parsed_holes.append((h_start, h_end))
        
        # Merge holes to simplify subtraction
        if not parsed_holes:
            return merged_spans
            
        parsed_holes.sort()
        merged_holes = []
        curr_h_start, curr_h_end = parsed_holes[0]
        for i in range(1, len(parsed_holes)):
            next_h_start, next_h_end = parsed_holes[i]
            if next_h_start <= curr_h_end:
                curr_h_end = max(curr_h_end, next_h_end)
            else:
                merged_holes.append((curr_h_start, curr_h_end))
                curr_h_start, curr_h_end = next_h_start, next_h_end
        merged_holes.append((curr_h_start, curr_h_end))

        # Subtract holes from merged spans
        result = []
        for s in merged_spans:
            s_start = self._parse_instant(s[0])
            s_end = self._parse_instant(s[1])
            current_segments = [(s_start, s_end)]
            for h_start, h_end in merged_holes:
                new_segments = []
                for seg_start, seg_end in current_segments:
                    if h_end <= seg_start or h_start >= seg_end:
                        # No overlap
                        new_segments.append((seg_start, seg_end))
                    else:
                        # Overlap
                        if h_start > seg_start:
                            new_segments.append((seg_start, h_start))
                        if h_end < seg_end:
                            new_segments.append((h_end, seg_end))
                current_segments = new_segments
            result.extend(current_segments)

        # Final merge of result to ensure "shortest list" and order
        final_spans = [(self._format_instant(s), self._format_instant(e)) for s, e in result]
        return self.merge(final_spans)

    def total_seconds(self, spans: list[tuple[str, str]]) -> int:
        merged = self.merge(spans)
        total = 0
        for start_str, end_str in merged:
            start = self._parse_instant(start_str)
            end = self._parse_instant(end_str)
            total += (end - start).total_seconds()
        return int(total)

# Expose the methods at the module level as required by the tests
merge = Solution().merge
subtract = Solution().subtract
total_seconds = Solution().total_seconds
