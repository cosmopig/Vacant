import re

class Solution:
    def parse(self, text: str) -> dict:
        data = {}
        current_group = data
        lines = text.splitlines()
        seen_headings = set()

        for i, line in enumerate(lines):
            line_num = i + 1
            stripped = line.strip()
            if not stripped or stripped.startswith('#'):
                continue
            
            content_end = len(line)
            in_quotes = False
            escaped = False
            for j, char in enumerate(line):
                if escaped:
                    escaped = False
                    continue
                if char == '\\':
                    escaped = True
                elif char == '"':
                    in_quotes = not in_quotes
                elif char == '#' and not in_quotes:
                    content_end = j
                    break
            
            content = line[:content_end].strip()
            if not content:
                continue

            if content.startswith('[') and content.endswith(']'):
                heading_str = content[1:-1].strip()
                if not heading_str:
                    raise ValueError(f"line {line_num}: empty heading")
                parts = heading_str.split('.')
                for part in parts:
                    part = part.strip()
                    if not re.match(r'^[a-zA-Z0-9_-]+$', part):
                        raise ValueError(f"line {line_num}: invalid name '{part}'")
                    if part not in current_group:
                        current_group[part] = {}
                    else:
                        # If it exists and is NOT a dict, then we have a problem? 
                        pass
                
                if heading_str in seen_headings:
                    raise ValueError(f"line {line_num}: heading '{heading_str}' opened twice")
                seen_headings.add(heading_str)
                current_group = current_group[parts[-1]]
            elif '=' in content:
                name_part, val_part = content.split('=', 1)
                name = name_part.strip()
                val_str = val_part.strip()
                if not re.match(r'^[a-zA-Z0-9_-]+$', name):
                    raise ValueError(f"line {line_num}: invalid name '{name}'")
                if name in current_group:
                    raise ValueError(f"line {line_num}: name '{name}' used twice")
                
                current_group[name] = self._parse_value(val_str, line_num)
            else:
                # Check if it's a value without an equals sign? No, the contract says 
                # "A line is blank, a comment, a heading [a] or [a.b], or name = value."
                raise ValueError(f"line {line_num}: invalid line")

        return data

    def _parse_value(self, val_str, line_num):
        if not val_str:
            return "" # Should not happen based on contract

        # Check for list first
        if val_str.startswith('[') and val_str.endswith(']'):
            inner = val_str[1:-1].strip()
            if not inner:
                return []
            items = [item.strip() for item in inner.split(',')]
            kinds = []
            parsed_items = []
            for item in items:
                kind, val = self._parse_single_value(item, line_num)
                kinds.append(kind)
                parsed_items.append(val)
            
            if len(set(kinds)) > 1:
                raise ValueError(f"line {line_num}: list items must be of the same kind")
            return parsed_items

        # Other values
        kind, val = self._parse_single_value(val_str, line_num)
        return val

    def _parse_single_value(self, val_str, line_num):
        if val_str.startswith('"') and val_str.endswith('"'):
            inner = val_str[1:-1]
            res = ""
            i = 0
            while i < len(inner):
                if inner[i] == '\\':
                    if i + 1 < len(inner):
                        next_char = inner[i+1]
                        if next_char in ('"', '\\', 'n', 't'):
                            if next_char == 'n': res += '\n'
                            elif next_char == 't': res += '\t'
                            else: res += next_char
                            i += 2
                            continue
                    res += '\\'
                    i += 1
                else:
                    res += inner[i]
                    i += 1
            return "text", res
        elif val_str == "true":
            return "bool", True
        elif val_str == "false":
            return "bool", False
        elif '.' in val_str or (val_str.replace('-', '').isdigit() and '-' not in val_str):
            # Decimal or whole number
            try:
                if '.' in val_str:
                    match = re.fullmatch(r'-?\d+\.\d+', val_str)
                    if match: return "decimal", float(val_str)
                    else: raise ValueError()
                else:
                    match = re.fullmatch(r'-?\d+', val_str)
                    if match: return "int", int(val_str)
                    else: raise ValueError()
            except ValueError:
                pass
        
        raise ValueError(f"line {line_num}: invalid value '{val_str}'")

    def dumps(self, data: dict) -> str:
        lines = []
        
        # Top-level names first in name order
        sorted_top_keys = sorted([k for k in data.keys() if not isinstance(data[k], dict)])
        for k in sorted_top_keys:
            val = data[k]
            lines.append(f'{k} = {self._dumps_value(val)}')

        # Headings in name order
        sorted_headings = sorted([k for k in data.keys() if isinstance(data[k], dict)])
        for h in sorted_headings:
            lines.append("") # Blank line before each heading
            lines.append(f"[{h}]")
            self._dump_group(data[h], lines)

        return "\n".join(lines).strip()

    def _dumps_value(self, val):
        if isinstance(val, bool):
            return "true" if val else "false"
        elif isinstance(val, int):
            return str(val)
        elif isinstance(val, float):
            # Must be -?digits.digits
            s = f"{val:.10f}".rstrip('0').rstrip('.')
            if '.' not in s: 
                # This might happen if it was parsed as int but should have been decimal?
                # But parse handles float for decimals and int for whole numbers.
                pass
            return str(val)
        elif isinstance(val, str):
            # Escape quotes, backslashes, n, t
            res = val.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n').replace('\t', '\\t')
            return f'"{res}"'
        elif isinstance(val, list):
            if not val:
                return "[]"
            # Check if all items are same kind
            kinds = []
            for item in val:
                if isinstance(item, bool): kinds.append("bool")
                elif isinstance(item, int): kinds.append("int")
                elif isinstance(item, float): kinds.append("decimal")
                elif isinstance(item, str): kinds.append("text")
                else: raise ValueError("list items must be of the same kind")
            if len(set(kinds)) > 1:
                raise ValueError("list items must be of the same kind")
            
            # Check for list inside a list (not allowed)
            if any(isinstance(item, list) for item in val):
                raise ValueError("list inside a list not allowed")

            items_str = []
            for item in val:
                items_str.append(self._dumps_value(item))
            return f"[{', '.join(items_str)}]"
        else:
            raise ValueError("unsupported value type")

    def _dump_group(self, group_dict, lines):
        sorted_keys = sorted(group_dict.keys())
        for k in sorted_keys:
            if isinstance(group_dict[k], dict):
                lines.append("") # Blank line before each heading
                lines.append(f"[{k}]")
                self._dump_group(group_dict[k], lines)
            else:
                val = group_dict[k]
                lines.append(f'{k} = {self._dumps_value(val)}')

