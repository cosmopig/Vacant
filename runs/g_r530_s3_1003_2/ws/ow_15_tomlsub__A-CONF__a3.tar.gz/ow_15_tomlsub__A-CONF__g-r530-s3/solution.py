import re

class Solution:
    def parse(self, text: str) -> dict:
        data = {}
        current_group = data
        lines = text.splitlines()
        for i, line in enumerate(lines):
            line_num = i + 1
            comment_idx = -1
            in_quotes = False
            escaped = False
            for j, char in enumerate(line):
                if escaped:
                    escaped = False
                elif char == '\\':
                    escaped = True
                elif char == '"':
                    in_quotes = not in_quotes
                elif char == '#' and not in_quotes:
                    comment_idx = j
                    break
            actual_line = line[:comment_idx] if comment_idx != -1 else line
            stripped_line = actual_line.strip()
            if not stripped_line or stripped_line.startswith('#'): continue
            if stripped_line.startswith('[') and stripped_line.endswith(']'):
                heading_parts = stripped_line[1:-1].split('.')
                new_group = data
                for part in heading_parts:
                    if not re.match(r'^[a-zA-Z0-9_-]+$', part): raise ValueError(f"line {line_num}: invalid name")
                    if part not in new_group: new_group[part] = {}
                    elif isinstance(new_group[part], dict): raise ValueError(f"line {line_num}: heading opened twice")
                    new_group = new_group[part]
                current_group = new_group
            elif '=' in stripped_line:
                name, val_str = stripped_line.split('=', 1)
                name, val_str = name.strip(), val_str.strip()
                if not re.match(r'^[a-zA-Z0-9_-]+$', name): raise ValueError(f"line {line_num}: invalid name")
                if name in current_group: raise ValueError(f"line {line_num}: same setting written twice")
                current_group[name] = self._parse_value(val_str, line_num)
        return data

    def _parse_value(self, s, line_num):
        if s.startswith('"') and s.endswith('"'):
            content = s[1:-1]
            res = ""
            i = 0
            while i < len(content):
                char = content[i]
                if char == '\\':
                    i += 1
                    if i >= len(content): break
                    next_char = content[i]
                    if next_char == '"': res += '"'
                    elif next_char == '\\': res += '\\'
                    elif next_char == 'n': res += '\n'
                    elif next_char == 't': res += '\t'
                    else: res += next_char
                else: res += char
                i += 1
            return res
        if s == "true": return True
        if s == "false": return False
        if s.startswith('[') and s.endswith(']'):
            inner = s[1:-1].strip()
            if not inner: return []
            items = [it.strip() for it in inner.split(',')]
            parsed_items = [self._parse_value(it, line_num) for it in items]
            first = parsed_items[0]
            for x in parsed_items:
                if type(x) != type(first): raise ValueError(f"line {line_num}: list items must be of the same kind")
            return parsed_items
        try:
            if '.' in s: return float(s)
            return int(s)
        except ValueError: raise ValueError(f"line {line_num}: invalid value")

    def dumps(self, data: dict) -> str:
        def _dumps_value(v):
            if isinstance(v, bool): return "true" if v else "false"
            if isinstance(v, int): return str(v)
            if isinstance(v, float): return str(v)
            if isinstance(v, str):
                res = ""
                for char in v:
                    if char == '"': res += '\\"'
                    elif char == '\\': res += '\\\\'
                    elif char == '\n': res += '\\n'
                    elif char == '\t': res += '\\t'
                    else: res += char
                return f'"{res}"'
            if isinstance(v, list):
                if not v: return "[]"
                items = [self._dumps_value(x) for x in v]
                return "[" + ", ".join(items) + "]"
            raise ValueError("Cannot dump value")

        def _dump_group(d, prefix=""):
            lines = []
            values = sorted([k for k, v in d.items() if not isinstance(v, dict)])
            headings = sorted([k for k, v in d.items() if isinstance(v, dict)])
            for k in values: lines.append(f'{k} = {self._dumps_value(d[k])}')
            for k in headings:
                if lines and lines[-1] != "": lines.append("")
                full_name = f"{prefix}.{k}" if prefix else k
                lines.append(f'[{full_name}]')
                sub = _dump_group(d[k], full_name)
                if sub: lines.append(sub)
            return "\n".join(lines).strip()

        res = _dump_group(data)
        return res

parse = Solution().parse
dumps = Solution().dumps
