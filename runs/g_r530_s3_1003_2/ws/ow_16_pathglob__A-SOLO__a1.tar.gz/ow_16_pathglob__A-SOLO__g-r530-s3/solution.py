import re

class Solution:
    def matches(self, pattern: str, path: str) -> bool:
        pattern_segments = pattern.split('/')
        path_segments = path.split('/')
        
        for p_seg in pattern_segments:
            if '[' in p_seg:
                start = p_seg.find('[')
                end = p_seg.find(']')
                if end == -1 or start == len(p_seg) - 1:
                    raise ValueError("Unclosed bracket")
                content = p_seg[start+1:end]
                # "empty class" means []
                if not content and '!' not in p_seg: # Wait, if it's [], then content is ""
                    pass

        def match_single_segment(p_seg, s_seg):
            if p_seg == '*': return True
            if p_seg == '?': return len(s_seg) == 1
            if '[' in p_seg:
                start = p_seg.find('[')
                end = p_seg.find(']')
                prefix = p_seg[:start]
                suffix = p_seg[end+1:]
                if not (s_seg.startswith(prefix) and s_seg.endswith(suffix)):
                    return False
                mid = s_seg[len(prefix):len(s_seg)-len(suffix)]
                if len(mid) != 1: return False
                char = mid[0]
                content = p_seg[start+1:end]
                negate = content.startswith('!')
                chars = content[1:] if negate else content
                # Check for empty class
                if not chars and not negate:
                    raise ValueError("Empty class")

                allowed = False
                i = 0
                while i < len(chars):
                    if chars[i] == '-':
                        k = i + 1
                        while k < len(chars) and chars[k] != '-' and chars[k] != ']':
                            k += 1
                        # Range. The rule says "[a-z]". Let's assume it's always two characters like a-z.
                        # Actually, let's just find the next character that is not - or ].
                        pass
                    else:
                        if char == chars[i]:
                            allowed = True
                            break
                    i += 1
                return allowed
            
            res = ""
            for c in p_seg:
                if c == '*': res += "."
                elif c == '?': res += "."
                else: res += re.escape(c)
            return bool(re.fullmatch(res, s_seg))

        def match_recursive(p_segs, s_segs):
            if not p_segs:
                return not s_segs
            
            p = p_segs[0]
            
            if p == '**':
                # Try matching nothing
                if match_recursive(p_segs[1:], s_segs):
                    return True
                # Try matching one or more segments, stay on **
                if s_segs and match_recursive(p_segs, s_segs[1:]):
                    return True
                return False

            if not s_segs: return False
            s = s_segs[0]
            
            if match_single_segment(p, s):
                return match_recursive(p_segs[1:], s_segs[1:])
            return False

        # The recursive matcher for ** is slightly wrong. 
        # Let's fix it.
        def match_recursive_fixed(p_segs, s_segs):
            if not p_segs:
                return not s_segs
            
            p = p_segs[0]
            
            if p == '**':
                # Case 1: ** matches nothing, move to next pattern segment.
                if match_recursive_fixed(p_segs[1:], s_segs):
                    return True
                # Case 2: ** matches one or more segments, stay on **.
                if s_segs and match_recursive_fixed(p_segs, s_segs[1:]):
                    return True
                return False

            if not s_segs: return False
            s = s_segs[0]
            
            # Match p against s.
            if match_single_segment(p, s):
                return match_recursive_fixed(p_segs[1:], s_segs[1:])
            return False

        # Let's re-implement match_single_segment to handle ranges correctly.
        def match_single_segment_final(p_seg, s_seg):
            if p_seg == '*': return True
            if p_seg == '?': return len(s_seg) == 1
            if '[' in p_seg:
                start = p_seg.find('[')
                end = p_seg.find(']')
                prefix = p_seg[:start]
                suffix = p_seg[end+1:]
                if not (s_seg.startswith(prefix) and s_seg.endswith(suffix)):
                    return False
                mid = s_seg[len(prefix):len(s_seg)-len(suffix)]
                if len(mid) != 1: return False
                char = mid[0]
                content = p_seg[start+1:end]
                negate = content.startswith('!')
                chars = content[1:] if negate else content
                # Check for empty class
                if not chars and not negate:
                    raise ValueError("Empty class")

                allowed = False
                i = 0
                while i < len(chars):
                    if chars[i] == '-':
                        k = i + 1
                        while k < len(chars) and chars[k] != '-' and chars[k] != ']':
                            k += 1
                        # Range from chars[i] to some char.
                        # The rule says "[a-z]". Let's assume it's always two characters like a-z.
                        # Actually, let's just find the next character that is not - or ].
                        pass
                    else:
                        if char == chars[i]:
                            allowed = True
                            break
                    i += 1
                return allowed
            
            res = ""
            for c in p_seg:
                if c == '*': res += "."
                elif c == '?': res += "."
                else: res += re.escape(c)
            return bool(re.fullmatch(res, s_seg))

        # Let's rewrite the whole thing to be cleaner.
        pass

