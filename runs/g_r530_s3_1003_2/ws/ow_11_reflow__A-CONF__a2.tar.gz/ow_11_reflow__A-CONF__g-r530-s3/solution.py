import unicodedata
import re

def get_width(text):
    return sum(2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1 for ch in text)

class Reflow:
    def __init__(self, width):
        if width <= 0:
            raise ValueError("Width must be positive")
        self.width = width

    def reflow(self, text):
        lines = text.splitlines(keepends=True)
        output = []
        i = 0
        while i < len(lines):
            line = lines[i]
            if line.isspace():
                # "A blank line... is emitted as an empty line"
                # However, we need to preserve the number of blank lines.
                # splitlines(keepends=True) for "\n\n" gives ["\n", "\n"].
                output.append("\n")
                i += 1
                continue

            paragraph_lines = []
            j = i
            while j < len(lines) and not (lines[j].strip() == "" and lines[j] != "\n"):
                stripped = lines[j].lstrip()
                if stripped and re.match(r'^(\d+\.|\*|-)\s', stripped):
                    break
                paragraph_lines.append(lines[j])
                j += 1
            
            self._process_paragraph(paragraph_lines, output)
            i = j

        res = "".join(output)
        if not text.endswith('\n') and res.endswith('\n'):
            return res[:-1]
        return res

    def _process_paragraph(self, paragraph_lines, output):
        processed_parts = [] # List of (is_code, content)
        in_code = False
        for line in paragraph_lines:
            if line.strip().startswith("```"):
                if not in_code:
                    processed_parts.append((True, line))
                    in_code = True
                else:
                    processed_parts.append((True, line))
                    in_code = False
            elif in_code:
                processed_parts.append((True, line))
            else:
                processed_parts.append((False, line))

        first_text_line = None
        for is_code, content in processed_parts:
            if not is_code:
                first_text_line = content
                break
        
        if first_text_line is None:
            for is_code, content in processed_parts:
                output.append(content.rstrip('\r\n') + '\n')
            return

        stripped_first = first_text_line.lstrip()
        marker_match = re.match(r'^(\d+\.|\*|-)\s', stripped_first)
        
        is_bulleted = marker_match is not None
        initial_indent = first_text_line[:len(first_text_line)-len(stripped_first)]
        initial_indent_width = get_width(initial_indent)

        if is_bulleted:
            content_start_idx = -1
            for idx in range(len(first_text_line)):
                char = first_text_line[idx]
                if char.isspace(): continue
                prefix = first_text_line[:idx]
                if prefix.strip() in ["-", "*"] or re.match(r'^\d+\.', prefix.strip()):
                    continue
                content_start_idx = idx
                break
            if content_start_idx == -1: content_start_idx = 0
            bullet_indent_width = get_width(first_text_line[:content_start_idx])
        else:
            bullet_indent_width = initial_indent_width

        words = []
        for is_code, content in processed_parts:
            if not is_code:
                if content == first_text_line:
                    content_after_indent = content[len(initial_indent):]
                    words.extend(content_after_indent.split())
                else:
                    words.extend(content.split())

        if not words and first_text_line:
            output.append("\n")
            return

        current_word_idx = 0
        first_line_done = False
        
        while current_word_idx < len(words):
            if not first_line_done:
                current_line_content = ""
                while current_word_idx < len(words):
                    word = words[current_word_idx]
                    if get_width(word) > self.width:
                        output.append(initial_indent + word + "\n")
                        current_word_idx += 1
                        first_line_done = True
                        break
                    
                    space = " " if current_line_content else ""
                    if get_width(current_line_content + space + word) <= (self.width - initial_indent_width):
                        current_line_content += space + word
                        current_word_idx += 1
                    else:
                        break
                output.append(initial_indent + current_line_content + "\n")
                first_line_done = True
            else:
                current_line_content = ""
                while current_word_idx < len(words):
                    word = words[current_word_idx]
                    if get_width(word) > self.width:
                        output.append(" " * (bullet_indent_width if is_bulleted else initial_indent_width) + word + "\n")
                        current_word_idx += 1
                        break
                    
                    space = " " if current_line_content else ""
                    if get_width(current_line_content + space + word) <= (self.width - (bullet_indent_width if is_bulleted else initial_indent_width)):
                        current_line_content += space + word
                        current_word_idx += 1
                    else:
                        break
                output.append(" " * (bullet_indent_width if is_bulleted else initial_indent_width) + current_line_content + "\n")

def reflow(text: str, width: int) -> str:
    return Reflow(width).reflow(text)

