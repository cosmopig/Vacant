import re

def _get_matches(text):
    patterns = [
        # AWS Access Key ID (AKIA...) - 20 uppercase alphanumeric characters
        r'\b[A-Z0-9]{20}\b',
        # Bearer Token - after "Authorization: Bearer ", matches until space or end of line
        # We use a lookbehind for "Authorization: Bearer "
        r'(?<=Authorization: Bearer )[a-zA-Z0-9\.\-_+/]+(?=\s|$)',
        # Connection strings (postgres, mysql, mongodb, redis, amqp)
        # Format: scheme://user:pass@host:port/db
        r'[a-z]+://[^:\s]+:[^@\s]+@[^\s]+:[0-9]+/[^\s]*',
    ]

    all_matches = []
    for p in patterns:
        for m in re.finditer(p, text):
            all_matches.append(m)
            
    # Sort matches by start position (ascending), then length (descending) to handle overlaps
    all_matches.sort(key=lambda x: (x.start(), -len(x.group())))
    
    final_matches = []
    last_end = -1
    for m in all_matches:
        if m.start() >= last_end:
            final_matches.append(m)
            last_end = m.end()
            
    return final_matches

def redact(text: str) -> str:
    # If the line is already redacted, don't do anything further.
    # We check for our own placeholder "[REDACTED]".
    if "[REDACTED]" in text:
        return text

    matches = _get_matches(text)
    if not matches:
        return text

    new_res = []
    curr_pos = 0
    for m in matches:
        new_res.append(text[curr_pos:m.start()])
        new_res.append("[REDACTED]")
        curr_pos = m.end()
    new_res.append(text[curr_pos:])
    
    return "".join(new_res)

def findings(text: str) -> list[str]:
    if not text:
        return []
    
    matches = _get_matches(text)
    return [m.group() for m in matches]
