import unittest
from solution import Solution

class TestSolution(unittest.TestCase):
    def test_basic_parse_dumps(self):
        data = {
            "a": 1,
            "b": "hello",
            "c": True,
            "d": False,
            "e": 1.5,
            "f": [1, 2, 3],
            "g": ["a", "b"],
        }
        text = Solution().dumps(data)
        self.assertEqual(Solution().parse(text), data)

    def test_nested_headings(self):
        data = {
            "top": 1,
            "sub": {
                "inner": 2,
                "deep": {
                    "very_deep": 3
                }
            }
        }
        text = Solution().dumps(data)
        self.assertEqual(Solution().parse(text), data)

    def test_comments_and_whitespace(self):
        text = """
        # This is a comment
        key1 = "value with # hash"
        
        [heading]
        key2 = 42  # inline comment
        """
        data = Solution().parse(text)
        self.assertEqual(data["key1"], "value with # hash")
        self.assertEqual(data["heading"]["key2"], 42)

    def test_escapes(self):
        data = {
            "quote": "He said \"hello\"",
            "backslash": "C:\\path",
            "newline": "line1\\nline2",
            "tab": "col1\\tcol2"
        }
        text = Solution().dumps(data)
        self.assertEqual(Solution().parse(text), data)

    def test_duplicate_keys_error(self):
        text = """
        key = 1
        key = 2
        """
        with self.assertRaisesRegex(ValueError, "line 2:"):
            Solution().parse(text)

    def test_duplicate_headings_error(self):
        text = """
        [heading]
        key = 1
        [heading]
        key2 = 2
        """
        with self.assertRaisesRegex(ValueError, "line 4:"):
            Solution().parse(text)

    def test_invalid_name(self):
        text = """
        key@name = 1
        """
        with self.assertRaisesRegex(ValueError, "line 2:"):
            Solution().parse(text)

    def test_mixed_list_error(self):
        data = {"list": [1, "a"]}
        with self.assertRaises(ValueError):
            Solution().dumps(data)

    def test_nested_list_error(self):
        data = {"list": [[1]]}
        with self.assertRaises(ValueError):
            Solution().dumps(data)

if __name__ == "__main__":
    unittest.main()
