import re

class Solution:
    def _parse_value(self, val_str):
        val_str = val_str.strip()
        if not val_str:
            return None
        
        # True/False
        if val_str == "true":
            return True
        if val_str == "false":
            return False
        
        # String
        if val_str.startswith('"') and val_str.endswith('"'):
            content = val_str[1:-1]
            res = ""
            i = 0
            while i < len(content):
                char = content[i]
                if char == '\\':
                    if i + 1 >= len(content):
                        break
                    next_char = content[i+1]
                    if next_char == '"': res += '"'
                    elif next_char == '\\': res += '\\'
                    elif next_char == 'n': res += '\n'
                    elif next_char == 't': res += '\t'
                    else: res += next_char
                    i += 2
                else:
                    res += char
                    i += 1
            return res

        # List
        if val_str.startswith('[') and val_str.endswith(']'):
            content = val_str[1:-1].strip()
            if not content:
                return []
            
            items = []
            current_part = ""
            in_quotes = False
            for char in content:
                if char == '"':
                    in_quotes = not in_quotes
                    current_part += char
                elif char == ',' and not in_quotes:
                    items.append(current_part.strip())
                    current_part = ""
                else:
                    current_part += char
            if current_part.strip():
                items.append(current_part.strip())
            
            parsed_items = []
            for p in items:
                parsed_items.append(self._parse_value(p))
            
            if not parsed_items: return []
            first = parsed_items[0]
            for item in parsed_items:
                if type(item) != type(first):
                    raise ValueError("Mixed types in list")
            return parsed_items

        # Number (Decimal or Whole)
        match_decimal = re.fullmatch(r'-?\d+\.\d+', val_str)
        if match_decimal:
            return float(val_str)
        
        match_int = re.fullmatch(r'-?\d+', val_str)
        if match_int:
            return int(val_str)

        raise ValueError(f"Invalid value: {val_str}")

    def parse(self, text: str) -> dict:
        data = {}
        current_group = data
        lines = text.splitlines()
        
        headings_seen = set()
        # To keep track of the current path in the dictionary
        path_stack = []

        for i, line in enumerate(lines):
            line_num = i + 1
            stripped = line.strip()
            
            if not stripped:
                continue
            
            in_quotes = False
            comment_start = -1
            for j, char in enumerate(stripped):
                if char == '"':
                    in_quotes = not in_quotes
                elif char == '#' and not in_quotes:
                    comment_start = j
                    break
            
            content_to_process = stripped
            if comment_start != -1:
                content_to_process = stripped[:comment_start].strip()
                if not content_to_process:
                    continue

            if content_to_process.startswith('#'):
                continue

            # Heading [a.b]
            if content_to_process.startswith('[') and content_to_process.endswith(']'):
                heading_content = content_to_process[1:-1].strip()
                parts = heading_content.split('.')
                
                new_group = data
                for part in parts:
                    if not re.fullmatch(r'[a-zA-Z0-9_-]+', part):
                        raise ValueError(f"line {line_num}: Invalid name")
                    
                    if part not in new_group:
                        new_group[part] = {}
                    else:
                        if not isinstance(new_group[part], dict):
                            # This means a heading is trying to overwrite a value or vice versa?
                            pass
                    new_group = new_group[part]
                
                full_path = ".".join(parts)
                if full_path in headings_seen:
                    raise ValueError(f"line {line_num}: Duplicate heading")
                headings_seen.add(full_path)
                current_group = new_group

            # name = value
            elif '=' in content_to_process:
                name, val_part = content_to_process.split('=', 1)
                name = name.strip()
                val_str = val_part.strip()
                
                if not re.fullmatch(r'[a-zA-Z0-9_-]+', name):
                    raise ValueError(f"line {line_num}: Invalid name")
                
                # Check for duplicate key in current group
                if name in current_group:
                    raise ValueError(f"line {line_num}: Duplicate name")
                
                current_group[name] = self._parse_value(val_str)

        return data

    def dumps(self, data: dict) -> str:
        # To distinguish between headings and settings at the top level.
        # Actually, any dictionary in our `data` structure MUST be a heading group.
        # But we need to know which ones were actually intended as headings.
        # The contract says "headings can be nested with dots". 
        # This means if we have [a.b], it's a heading.
        # If we have a setting at the top level, it's just a key in `data`.
        # If we have a dictionary that is NOT a heading, what would it be?
        # The contract says "headings can be nested with dots", and 
        # "Names before the first heading live at the top level."
        # This implies everything at the top level that's not a heading is just a setting.
        # And any dictionary we encounter must have been created as part of a heading path.

        def _get_headings(d, current_path=None):
            if current_path is None:
                current_path = []
            
            headings = {}
            for k, v in d.items():
                if isinstance(v, dict):
                    # This must be a heading group.
                    new_path = current_path + [k]
                    full_path = ".".join(new_path)
                    headings[full_path] = (new_path, v)
                    # Recursively find headings in this group
                    sub_headings = _get_headings(v, new_path)
                    headings.update(sub_headings)
                else:
                    pass # Not a heading
            return headings

        top_level_settings = {}
        headings = {} # full_path -> (parts, group_dict)

        def collect(d, current_path=None):
            if current_path is None:
                current_path = []
            for k, v in d.items():
                if isinstance(v, dict):
                    new_path = current_path + [k]
                    full_path = ".".join(new_path)
                    headings[full_path] = (new_path, v)
                    collect(v, new_path)
                else:
                    if not current_path:
                        top_level_settings[k] = v
        
        collect(data)

        lines = []
        # Top-level settings
        for k in sorted(top_level_settings.keys()):
            val = top_level_settings[k]
            lines.append(f'{k} = {self._format_value(val)}')
        
        # Headings
        sorted_heading_paths = sorted(headings.keys())
        for path in sorted_heading_paths:
            lines.append("") # Blank line before each heading
            parts, group_dict = headings[path]
            lines.append("[" + ".".join(parts) + "]")
            # Now we need to write the settings for this heading.
            # But wait, if a heading is nested, like [a.b], 
            # its settings are only those directly under it?
            # Or all of them? The contract says "each heading... with its own names".
            # This usually means the immediate children of that heading group.
            
            group_dict = group_dict
            for k in sorted(group_dict.keys()):
                v = group_dict[k]
                if not isinstance(v, dict):
                    lines.append(f'{k} = {self._format_value(v)}')
        
        return "\n".join(lines)

    def _format_value(self, v):
        if v is True: return "true"
        if v is False: return "false"
        if isinstance(v, int): return str(v)
        if isinstance(v, float):
            s = str(v)
            # If it's 1.0, we want to keep it as 1.0 because the contract says -?digits.digits
            return s
        if isinstance(v, str):
            res = '"'
            i = 0
            while i < len(v):
                char = v[i]
                if char == '\\':
                    if i + 1 >= len(v): break
                    next_char = v[i+1]
                    if next_char == '"': res += '\\"'
                    elif next_char == '\\': res += '\\\\'
                    elif next_char == 'n': res += '\\n'
                    elif next_char == 't': res += '\\t'
                    else: res += '\\' + next_char
                    i += 2
                else:
                    res += char
                    i += 1
            res += '"'
            return res
        if isinstance(v, list):
            if not v: return "[]"
            items = [self._format_value(x) for x in v]
            return "[" + ", ".join(items) + "]"
        return ""

