import re

class Solution:
    def parse(self, text: str) -> dict:
        data = {}
        current_group = data
        lines = text.splitlines()
        headings_seen = set()

        def get_kind(val_str):
            if val_str == "true" or val_str == "false": return "bool"
            if val_str.startswith('"'): return "string"
            if val_str.startswith('['): return "list"
            try:
                float(val_str)
                return "number"
            except ValueError:
                pass
            return None

        def parse_value(val_str, line_num):
            val_str = val_str.strip()
            if not val_str: raise ValueError(f"line {line_num}: empty value")
            if val_str == "true": return True
            if val_str == "false": return False
            if val_str.startswith('"') and val_str.endswith('"'):
                content = val_str[1:-1]
                res = []
                i = 0
                while i < len(content):
                    if content[i] == '\\' and i + 1 < len(content):
                        char = content[i+1]
                        if char == '"': res.append('"')
                        elif char == '\\': res.append('\\')
                        elif char == 'n': res.append('\n')
                        elif char == 't': res.append('\t')
                        else: res.append(char)
                        i += 2
                    else:
                        res.append(content[i])
                        i += 1
                return "".join(res)
            if val_str.startswith('[') and val_str.endswith(']'):
                inner = val_str[1:-1].strip()
                if not inner: return []
                items = [x.strip() for x in inner.split(',')]
                kind = get_kind(items[0])
                if kind is None or kind == "list":
                    raise ValueError(f"line {line_num}: list items cannot be lists")
                parsed_items = []
                for item in items:
                    item_kind = get_kind(item)
                    if item_kind != kind:
                        raise ValueError(f"line {line_num}: mixed types in list")
                    parsed_items.append(parse_value(item, line_num))
                return parsed_items
            try:
                if '.' in val_str: return float(val_str)
                else: return int(val_str)
            except ValueError:
                raise ValueError(f"line {line_num}: invalid value")

        for i, line in enumerate(lines):
            line_num = i + 1
            content = ""
            in_quotes = False
            escaped = False
            comment_idx = -1
            for j, char in enumerate(line):
                if escaped:
                    escaped = False
                    continue
                if char == '\\':
                    escaped = True
                elif char == '"':
                    in_quotes = not in_quotes
                elif char == '#' and not in_quotes:
                    comment_idx = j
                    break
            content = line[:comment_idx] if comment_idx != -1 else line
            stripped = content.strip()
            if not stripped: continue

            if stripped.startswith('[') and stripped.endswith(']'):
                heading_path = stripped[1:-1].strip().split('.')
                new_group = data
                for part in heading_path:
                    part = part.strip()
                    if not re.match(r'^[a-zA-Z0-9_-]+$', part):
                        raise ValueError(f"line {line_num}: invalid name '{part}'")
                    if part in new_group:
                        if not isinstance(new_group[part], dict):
                            raise ValueError(f"line {line_num}: name '{part}' already used as a non-heading")
                    else:
                        new_group[part] = {}
                path_tuple = tuple(heading_path)
                if path_tuple in headings_seen:
                    raise ValueError(f"line {line_num}: heading opened twice")
                headings_seen.add(path_tuple)
                current_group = new_group
            elif '=' in stripped:
                name, val_part = stripped.split('=', 1)
                name = name.strip()
                if not re.match(r'^[a-zA-Z0-9_-]+$', name):
                    raise ValueError(f"line {line_num}: invalid name '{name}'")
                if name in current_group:
                    raise ValueError(f"line {line_num}: name '{name}' used twice in one group")
                current_group[name] = parse_value(val_part, line_num)

        return data

    def dumps(self, data: dict) -> str:
        def _format_value(val):
            if isinstance(val, bool): return "true" if val else "false"
            elif isinstance(val, int): return str(val)
            elif isinstance(val, float):
                s = str(val)
                return s[:-2] if s.endswith('.0') else s
            elif isinstance(val, str):
                res = []
                for char in val:
                    if char == '"': res.append('\\"')
                    elif char == '\\': res.append('\\\\')
                    elif char == '\n': res.append('\\n')
                    elif char == '\t': res.append('\\t')
                    else: res.append(char)
                return f'"{ "".join(res) }"'
            elif isinstance(val, list):
                if not val: return "[]"
                kind = type(val[0])
                for item in val:
                    if not isinstance(item, kind): raise ValueError("List items must be of the same kind")
                return f"[{', '.join(_format_value(i) for i in val)}]"
            else: raise ValueError("Unsupported type")

        def _dump_recursive(d, prefix=""):
            lines = []
            sorted_keys = sorted(d.keys())
            names = [k for k, v in d.items() if not isinstance(v, dict)]
            headings = {k: v for k, v in d.items() if isinstance(v, dict)}
            
            for name in sorted(names):
                lines.append(f'{name} = {self._format_value(d[name])}')
            
            sorted_h_names = sorted(headings.keys())
            for h_name in sorted_h_names:
                # If this is a nested heading, we need to handle the dots.
                # But wait, if [a.b] was parsed as data["a"]["b"], 
                # then "a" is a key in root, and its value is a dict containing "b".
                # This means when dumping root, we see "a" as a heading.
                # If "a" has children like "b", they are dumped under [a].
                # But the rule says "[a.b]" should be one heading.
                # Let's re-read: "headings can be nested with dots". 
                # This could mean that if we have [a.b], it is a single heading.
                # If my parse treats [a.b] as data["a"]["b"], then when I dump,
                # I should only see the full path? No, that's not how dicts work.
                # Let's re-think: if [a.b] is a heading, it means "a" and "b" are 
                # parts of the same heading.

            return lines

        # Actually, let's simplify. If I parse [a.b] as data["a"]["b"], 
        # then when dumping, if data["a"] is a dict, it's a heading.
        # But what if there was also a heading [a]? That would be a mistake.
        # What if the user wrote:
        # [a]
        # name = "val"
        # [a.b]
        # name2 = "val2"
        # In this case, data["a"] is a dict, and it has a key "b" which is also a dict.
        # This means my `parse` would put "name" into `data["a"]`.
        # And then [a.b] would mean `current_group` becomes `data["a"]["b"]`.
        # So data["a"] contains {"name": "val", "b": {}}.
        # When dumping, I see "a" as a heading. Its contents are dumped.
        # One of its contents is "name = val". 
        # Another content is "b", which is also a dict, so it's another heading!
        # But the output should be [a] and then [a.b]? No, that doesn't make sense.
        # If [a.b] was written, it means data["a"]["b"] exists. 
        # The only way to get [a.b] as a single heading in the output is if 
        # I don't dump "a" and then "b".

        # Let's re-read: "headings can be nested with dots".
        # This usually means that [a.b] is one heading, and it should be printed as [a.b].
        # If my `parse` puts it in data["a"]["b"], then I need to know which keys are 
        # part of a multi-part heading.

        # Let's try another approach for parse:
        # When we see [a.b], we don't just create the dicts, we also record that 
        # "a" and "b" are parts of the same heading path.
        pass

