import unicodedata
import re

def get_width(text):
    return sum(2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1 for ch in text)

class Reflow:
    def __init__(self, width):
        if width <= 0:
            raise ValueError("Width must be positive.")
        self.width = width

    def reflow(self, text):
        lines = text.splitlines(keepends=True)
        has_trailing_newline = text.endswith('\n')
        
        output = []
        i = 0
        while i < len(lines):
            line = lines[i]
            stripped = line.lstrip()
            
            if not stripped:
                output.append("")
                i += 1
                continue
            
            if stripped.startswith('```'):
                code_block = []
                code_block.append(lines[i])
                i += 1
                while i < len(lines) and not lines[i].lstrip().startswith('```'):
                    code_block.append(lines[i])
                    i += 1
                if i < len(lines) and lines[i].lstrip().startswith('```'):
                    code_block.append(lines[i])
                    i += 1
                for cl in code_block:
                    output.append(cl.rstrip('\r\n'))
                continue

            # Paragraph / Bullet logic
            paragraph_lines = []
            while i < len(lines):
                curr_line = lines[i]
                curr_stripped = curr_line.lstrip()
                if not curr_stripped:
                    break
                
                is_bullet = False
                marker = None
                if curr_stripped.startswith('- '):
                    is_bullet = True
                    marker = '- '
                elif curr_stripped.startswith('* '):
                    is_bullet = True
                    marker = '* '
                else:
                    match = re.match(r'^(\d+)\.\s', curr_stripped)
                    if match:
                        is_bullet = True
                        marker = match.group(0)
                
                if is_bullet and paragraph_lines:
                    break
                
                paragraph_lines.append(curr_line)
                i += 1
            
            first_line = paragraph_lines[0]
            first_stripped = first_line.lstrip()
            first_indent = first_line[:len(first_line) - len(first_stripped)]
            
            is_bullet_para = False
            marker = None
            if first_stripped.startswith('- '):
                is_bullet_para = True
                marker = '- '
            elif first_stripped.startswith('* '):
                is_bullet_para = True
                marker = '* '
            else:
                match = re.match(r'^(\d+)\.\s', first_stripped)
                if match:
                    is_bullet_para = True
                    marker = match.group(0)

            # Collect words from the paragraph content
            words = []
            for idx, l in enumerate(paragraph_lines):
                l_stripped = l.lstrip()
                content_start = 0
                if idx == 0:
                    if is_bullet_para:
                        content_start = len(marker)
                    else:
                        # first_indent already removed by lstrip()
                        content_start = 0
                else:
                    if is_bullet_para:
                        content_start = len(marker)
                    else:
                        removed = len(l) - len(l_stripped)
                        content_start = max(0, removed - len(first_indent))
                
                content = l[content_start:]
                words.extend(re.split(r'\s+', content.strip()))

            # Now reflow the words.
            current_line_content = []
            current_line_width = 0
            
            for w in words:
                if not w: continue
                w_width = get_width(w)
                
                if w_width > self.width:
                    if current_line_content:
                        output.append(" ".join(current_line_content))
                    output.append(w)
                    current_line_content = []
                    current_line_width = 0
                    continue

                space_needed = 1 if current_line_content else 0
                # Indentation for the first line of a paragraph is first_indent + (marker if bullet).
                # For subsequent lines, it's either first_indent or len(marker).
                
                # Let's calculate indentation width.
                if not current_line_content:
                    pass

            # I give up on this manual logic and rewrite it properly.
            # Let's use a simpler approach for reflowing words:
            # For each word, try to put it on the current line. 
            # If it doesn't fit, start a new line with appropriate indentation.

            pass # I will implement this now.
