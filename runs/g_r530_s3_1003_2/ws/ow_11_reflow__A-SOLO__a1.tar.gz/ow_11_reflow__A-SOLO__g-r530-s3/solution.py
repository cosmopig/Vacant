import unicodedata
import re

def get_width(text):
    return sum(2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1 for ch in text)

def reflow(text: str, width: int) -> str:
    if width <= 0:
        raise ValueError("Width must be positive.")

    lines = text.splitlines(keepends=True)
    output = []
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        
        if not stripped:
            output.append("")
            i += 1
            continue

        # Code block detection
        if stripped.startswith("```"):
            code_block = []
            code_block.append(line)
            i += 1
            while i < len(lines) and not lines[i].strip().startswith("```"):
                code_block.append(lines[i])
                i += 1
            if i < len(lines):
                code_block.append(lines[i])
                i += 1
            output.extend(code_block)
            continue

        # Paragraph processing
        paragraph_lines = []
        is_bullet_para = False
        marker_len = 0
        
        curr_stripped = stripped
        is_bullet = False
        if curr_stripped.startswith("- "):
            is_bullet = True
            marker_len = 2
        elif curr_stripped.startswith("* "):
            is_bullet = True
            marker_len = 2
        else:
            match = re.match(r'^(\d+)\.\s', curr_stripped)
            if match:
                is_bullet = True
                marker_len = len(match.group(0))

        # Collect all consecutive non-blank lines that are not bullets (unless it's the first line of a bullet paragraph)
        if is_bullet:
            is_bullet_para = True
            paragraph_lines.append(line)
            i += 1
            while i < len(lines):
                curr_line = lines[i]
                curr_stripped = curr_line.strip()
                if not curr_stripped:
                    break
                is_next_bullet = False
                if curr_stripped.startswith("- "):
                    is_next_bullet = True
                elif curr_stripped.startswith("* "):
                    is_next_bullet = True
                else:
                    match = re.match(r'^(\d+)\.\s', curr_stripped)
                    if match:
                        is_next_bullet = True
                if is_next_bullet:
                    break
                paragraph_lines.append(curr_line)
                i += 1
        else:
            paragraph_lines.append(line)
            i += 1
            while i < len(lines):
                curr_line = lines[i]
                curr_stripped = curr_line.strip()
                if not curr_stripped:
                    break
                is_next_bullet = False
                if curr_stripped.startswith("- "):
                    is_next_bullet = True
                elif curr_stripped.startswith("* "):
                    is_next_bullet = True
                else:
                    match = re.match(r'^(\d+)\.\s', curr_stripped)
                    if match:
                        is_next_bullet = True
                if is_next_bullet:
                    break
                paragraph_lines.append(curr_line)
                i += 1

        # Now reflow the paragraph_lines
        first_line = paragraph_lines[0]
        first_stripped = first_line.strip()
        
        target_indent_width = 0
        if is_bullet_para:
            first_non_blank = len(first_line) - len(first_line.lstrip())
            # The target indentation for continuation lines in a bullet paragraph
            # is the first character after the marker.
            target_indent_width = first_non_blank + marker_len
        else:
            # For non-bullet paragraphs, all lines have the same indentation as the first line.
            first_line_indent_str = first_line[:len(first_line)-len(first_line.lstrip())]
            target_indent_width = get_width(first_line_indent_str)

        # Collect content words from all lines in the paragraph
        content_words = []
        for idx, pline in enumerate(paragraph_lines):
            stripped = pline.strip()
            if is_bullet_para and idx == 0:
                content = stripped[marker_len:]
            else:
                content = stripped
            
            # Split content into words, but preserve pieces that don't have spaces (like URLs)
            words = re.split(r'\s+', content)
            for w in words:
                if w:
                    content_words.append((w, idx))

        # Now reflow the content_words into lines with target_indent_width
        reflowed_lines = []
        current_line_words = []
        current_line_width = 0
        
        first_line_actual_indent_width = 0
        if is_bullet_para:
            first_non_blank = len(first_line) - len(first_line.lstrip())
            first_line_actual_indent_width = first_non_blank
        else:
            first_line_indent_str = first_line[:len(first_line)-len(first_line.lstrip())]
            first_line_actual_indent_width = get_width(first_line_indent_str)

        word_idx = 0
        while word_idx < len(content_words):
            if not reflowed_lines:
                current_line_width = first_line_actual_indent_width
                if is_bullet_para:
                    marker_str = first_line[first_non_blank : first_non_blank + marker_len]
                    current_line_words.append(marker_str)
                    current_line_width += get_width(marker_str)
            else:
                current_line_width = target_indent_width

            while word_idx < len(content_words):
                word, original_idx = content_words[word_idx]
                w_width = get_width(word)
                
                # Space needed if not first word on line (and not the marker)
                space_needed = 1 if current_line_words else 0
                
                if current_line_width + space_needed + w_width <= width:
                    current_line_words.append((" " + word) if current_line_words else word)
                    current_line_width += space_needed + w_width
                    word_idx += 1
                else:
                    break
            
            reflowed_lines.append("".join(current_line_words))

        output.extend(reflowed_lines)

    # Join with newlines and handle final newline correctly
    result = "\n".join(output)
    if text.endswith("\n") and not result.endswith("\n"):
        result += "\n"
    return result

