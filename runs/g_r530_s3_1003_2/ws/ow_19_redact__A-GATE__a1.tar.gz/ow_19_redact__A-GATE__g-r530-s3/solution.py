import re

# Regex patterns for the secrets described:
AWS_KEY_PATTERN = r"AKIA[0-9A-Z]{16}"

# Bearer tokens can be dot-separated or not. 
# The example is "Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.e30.abcdef"
# We want to capture the token part after "Bearer ".
BEARER_TOKEN_PATTERN = r"Bearer\s+([a-zA-Z0-9\.\-\+\/\=\_]+)"

# Database URLs: (postgres|mysql|mongodb|redis|amqp)://...
DB_URL_PATTERN = r"(?P<proto>postgres|mysql|mongodb|redis|amqp)://[^:]+:[^@]+@[^:/]+(:[0-9]+)?/[^ ]+"

def redact(text: str) -> str:
    matches = []

    # Find AWS Keys
    for m in re.finditer(AWS_KEY_PATTERN, text):
        matches.append((m.start(), m.end(), m.group()))

    # Find Bearer Tokens
    for m in re.finditer(BEARER_TOKEN_PATTERN, text):
        token = m.group(1)
        start = m.start(1)
        end = m.end(1)
        matches.append((start, end, token))

    # Find DB URLs
    for m in re.finditer(DB_URL_PATTERN, text):
        matches.append((m.start(), m.end(), m.group()))

    # Sort matches by start position descending to replace without affecting indices of earlier ones
    # Also handle overlapping matches by choosing the longest one if they start at same position?
    matches.sort(key=lambda x: (x[0], -len(x[2])), reverse=True)

    result_str = text
    covered_indices = set()
    
    for start, end, secret in matches:
        if any(i in covered_indices for i in range(start, end)):
            continue
        
        for i in range(start, end):
            covered_indices.add(i)
        result_str = result_str[:start] + "[REDACTED]" + result_str[end:]

    return result_str

def findings(text: str) -> list[str]:
    matches = []

    # Find AWS Keys
    for m in re.finditer(AWS_KEY_PATTERN, text):
        matches.append((m.start(), m.end(), m.group()))

    # Find Bearer Tokens
    for m in re.finditer(BEARER_TOKEN_PATTERN, text):
        token = m.group(1)
        start = m.start(1)
        end = m.end(1)
        matches.append((start, end, token))

    # Find DB URLs
    for m in re.finditer(DB_URL_PATTERN, text):
        matches.append((m.start(), m.end(), m.group()))

    # Sort by start position and handle overlaps (keep longest)
    matches.sort()
    final_matches = []
    if matches:
        last_end = -1
        for start, end, secret in matches:
            if start >= last_end:
                final_matches.append(secret)
                last_end = end
            else:
                # If it overlaps, we could take the longer one? 
                # But for findings, usually they don't overlap much.
                pass

    return final_matches
