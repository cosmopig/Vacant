import re

class Solution:
    def _get_regex_for_segment(self, segment_pattern):
        if segment_pattern == "**":
            return None
        
        regex = ""
        i = 0
        while i < len(segment_pattern):
            c = segment_pattern[i]
            if c == '?':
                regex += "."
                i += 1
            elif c == '*':
                regex += ".*"
                i += 1
            elif c == '[':
                i += 1
                content = ""
                while i < len(segment_pattern) and segment_pattern[i] != ']':
                    content += segment_pattern[i]
                    i += 1
                if i >= len(segment_pattern):
                    raise ValueError("Unclosed bracket")
                if not content:
                    raise ValueError("Empty class")
                
                negate = False
                if content.startswith('!'):
                    negate = True
                    content = content[1:]
                
                chars = []
                j = 0
                while j < len(content):
                    if content[j] == '-' and j + 1 < len(content) and content[j+1] != ']':
                        start_char = content[j]
                        end_char = content[j+1]
                        chars.append(f"{re.escape(start_char)}-{re.escape(end_char)}")
                        j += 2
                    else:
                        chars.append(re.escape(content[j]))
                        j += 1
                inner = "".join(chars)
                if negate:
                    regex += f"[^{inner}]"
                else:
                    regex += f"[{inner}]"
            else:
                regex += re.escape(c)
                i += 1
        return regex

    def matches(self, pattern: str, path: str) -> bool:
        p_segs = pattern.split('/')
        path_segs = path.split('/')
        
        memo = {}
        def solve(p_i, path_i):
            state = (p_i, path_i)
            if state in memo: return memo[state]
            
            if p_i == len(p_segs):
                return path_i == len(path_segs)
            
            curr_p = p_segs[p_i]
            if curr_p == "**":
                for skip in range(len(path_segs) - path_i + 1):
                    if solve(p_i + 1, path_i + skip):
                        memo[state] = True
                        return True
            else:
                if path_i < len(path_segs):
                    regex = self._get_regex_for_segment(curr_p)
                    if re.fullmatch(regex, path_segs[path_i]):
                        res = solve(p_i + 1, path_i + 1)
                        memo[state] = res
                        return res
            
            memo[state] = False
            return False

        return solve(0, 0)

    def select(self, patterns: list[str], paths: list[str]) -> list[str]:
        for p in patterns:
            p_segs = p.split('/')
            for seg in p_segs:
                if seg == "**": continue
                i = 0
                while i < len(seg):
                    if seg[i] == '[':
                        j = i + 1
                        while j < len(seg) and seg[j] != ']':
                            j += 1
                        if j >= len(seg): raise ValueError("Unclosed bracket")
                        content = seg[i+1:j]
                        if not content: raise ValueError("Empty class")
                    else:
                        i += 1
            self._validate_pattern(p)

        selected = set()
        for p in patterns:
            if p.startswith('!'):
                sub_p = p[1:]
                to_remove = []
                for path in selected:
                    if self.matches(sub_p, path):
                        to_remove.append(path)
                for r in to_remove:
                    selected.remove(r)
            else:
                for path in paths:
                    if path not in selected and self.matches(p, path):
                        selected.add(path)
        
        result = []
        seen = set()
        for path in paths:
            if path in selected and path not in seen:
                result.append(path)
                seen.add(path)
        return result

    def _validate_pattern(self, pattern):
        # This is already handled by the loop in select but let's make it explicit if needed.
        pass
