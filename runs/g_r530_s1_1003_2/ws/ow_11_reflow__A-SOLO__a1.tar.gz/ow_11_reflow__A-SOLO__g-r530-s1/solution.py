import unicodedata
import re

def get_char_width(char):
    if unicodedata.east_asian_width(char) in ("W", "F"):
        return 2
    return 1

def get_text_width(text):
    return sum(get_char_width(c) for c in text)

class Reflow:
    def __init__(self, width):
        if width <= 0:
            raise ValueError("Width must be positive")
        self.width = width

    def reflow(self, text: str) -> str:
        lines = text.splitlines(keepends=True)
        has_trailing_newline = text.endswith('\n')
        
        segments = []
        i = 0
        while i < len(lines):
            line = lines[i]
            if line.strip().startswith("```"):
                block = []
                while i < len(lines) and not lines[i].strip().startswith("```") or (i + 1 >= len(lines)):
                    if i + 1 < len(lines) and lines[i+1].strip().startswith("```"):
                        block.append(lines[i])
                        i += 1
                        break
                    block.append(lines[i])
                    i += 1
                segments.append(("code", "".join(block)))
            else:
                content = ""
                while i < len(lines) and not lines[i].strip().startswith("```"):
                    content += lines[i]
                    i += 1
                segments.append(("text", content))

        result_lines = []
        for type, content in segments:
            if type == "code":
                result_lines.append(content)
            else:
                raw_lines = content.splitlines(keepends=True)
                if not raw_lines:
                    continue
                
                paragraphs = []
                current_para = None
                for line in raw_lines:
                    stripped = line.strip()
                    if not stripped:
                        if current_para is not None:
                            paragraphs.append(current_para)
                            current_para = None
                        paragraphs.append(line)
                    else:
                        is_bullet = False
                        marker = ""
                        if stripped.startswith("- "):
                            is_bullet = True
                            marker = "- "
                        elif stripped.startswith("* "):
                            is_bullet = True
                            marker = "* "
                        else:
                            match = re.match(r'^(\d+)\.\s', stripped)
                            if match:
                                is_bullet = True
                                marker = match.group(0)
                        
                        if is_bullet or current_para is None:
                            if current_para is not None:
                                paragraphs.append(current_para)
                            current_para = [line]
                        else:
                            current_para.append(line)
                if current_para is not None:
                    paragraphs.append(current_para)
                
                for p in paragraphs:
                    if len(p) == 1 and p[0].strip() == "":
                        result_lines.append(p[0])
                        continue
                    
                    first_line = p[0]
                    stripped_first = first_line.lstrip()
                    indentation = first_line[:len(first_line) - len(stripped_first)]
                    
                    is_bullet_para = False
                    marker = ""
                    if stripped_first.startswith("- "):
                        is_bullet_para = True
                        marker = "- "
                    elif stripped_first.startswith("* "):
                        is_bullet_para = True
                        marker = "* "
                    else:
                        match = re.match(r'^(\d+)\.\s', stripped_first)
                        if match:
                            is_bullet_para = True
                            marker = match.group(0)

                    words = []
                    for i, line in enumerate(p):
                        line_content = line.rstrip('\r\n')
                        if i == 0:
                            content = stripped_first
                        else:
                            if is_bullet_para:
                                content = line_content[len(indentation + marker):]
                            else:
                                content = line_content[len(indentation):]
                        words.extend(content.split())

                    para_result = []
                    word_idx = 0
                    while word_idx < len(words):
                        if not para_result:
                            current_indent_str = indentation
                            current_indent_width = get_text_width(indentation)
                        else:
                            if is_bullet_para:
                                current_indent_str = indentation + marker
                                current_indent_width = get_text_width(indentation + marker)
                            else:
                                current_indent_str = indentation
                                current_indent_width = get_text_width(indentation)
                        
                        line_words = []
                        line_width = 0
                        first_word_of_line = True
                        while word_idx < len(words):
                            word = words[word_idx]
                            word_width = get_text_width(word)
                            space_width = 1 if not first_word_of_line else 0
                            if current_indent_width + line_width + space_width + word_width <= self.width:
                                line_words.append(word)
                                line_width += space_width + word_width
                                first_word_of_line = False
                                word_idx += 1
                            else:
                                break
                        if not line_words:
                            word = words[word_idx]
                            para_result.append(current_indent_str + word)
                            word_idx += 1
                        else:
                            para_result.append(current_indent_str + " ".join(line_words))

                    result_lines.extend(para_result)

        final_text = "\n".join(result_lines)
        if has_trailing_newline and not final_text.endswith('\n'):
            final_text += '\n'
        return final_text

def reflow(text: str, width: int) -> str:
    rf = Reflow(width)
    return rf.reflow(text)

solution = reflow
