import unicodedata
import re

def get_char_width(char):
    if unicodedata.east_asian_width(char) in ("W", "F"):
        return 2
    return 1

def get_text_width(text):
    return sum(get_char_width(c) for c in text)

class Reflow:
    def __init__(self, width):
        if width <= 0:
            raise ValueError("Width must be positive")
        self.width = width

    def reflow(self, text: str) -> str:
        lines = text.splitlines(keepends=True)
        has_trailing_newline = text.endswith('\n')
        
        # 1. Identify code blocks and non-code segments
        segments = []
        i = 0
        while i < len(lines):
            line = lines[i]
            if line.strip().startswith("```"):
                block = []
                while i < len(lines) and not lines[i].strip().startswith("```") or (i + 1 >= len(lines)):
                    # If it's the closing fence, we stop after adding it.
                    if i + 1 < len(lines) and lines[i+1].strip().startswith("```"):
                        block.append(lines[i])
                        i += 1
                        break
                    block.append(lines[i])
                    i += 1
                segments.append(("code", "".join(block)))
            else:
                content = ""
                while i < len(lines) and not lines[i].strip().startswith("```"):
                    content += lines[i]
                    i += 1
                segments.append(("text", content))

        result_lines = []
        for type, content in segments:
            if type == "code":
                # Code blocks are emitted as is, but we need to handle the trailing newline if it's there
                # Actually splitlines(keepends=True) already preserves them.
                # But wait, if a code block was part of a larger text, 
                # and it had no newline at the end, it should still be fine.
                result_lines.append(content)
            else:
                raw_lines = content.splitlines(keepends=True)
                if not raw_lines:
                    continue
                
                # 2. Group into paragraphs and blank lines
                paragraphs = []
                current_para = None
                
                for line in raw_lines:
                    stripped = line.strip()
                    if not stripped:
                        if current_para is not None:
                            paragraphs.append(current_para)
                            current_para = None
                        paragraphs.append(line) # Keep blank lines as they are
                    else:
                        # Check if it's a bullet
                        is_bullet = False
                        marker = ""
                        if stripped.startswith("- "):
                            is_bullet = True
                            marker = "- "
                        elif stripped.startswith("* "):
                            is_bullet = True
                            marker = "* "
                        else:
                            match = re.match(r'^(\d+)\.\s', stripped)
                            if match:
                                is_bullet = True
                                marker = match.group(0)
                        
                        if is_bullet or current_para is None:
                            if current_para is not None:
                                paragraphs.append(current_para)
                            current_para = [line]
                        else:
                            current_para.append(line)
                if current_para is not None:
                    paragraphs.append(current_para)
                
                for p in paragraphs:
                    # If it's a blank line (or multiple blank lines), just add them
                    if len(p) == 1 and p[0].strip() == "":
                        result_lines.append(p[0])
                        continue
                    
                    # Process paragraph
                    first_line = p[0]
                    stripped_first = first_line.lstrip()
                    indent_len = len(first_line) - len(stripped_first)
                    
                    is_bullet_para = False
                    marker = ""
                    if stripped_first.startswith("- "):
                        is_bullet_para = True
                        marker = "- "
                    elif stripped_first.startswith("* "):
                        is_bullet_para = True
                        marker = "* "
                    else:
                        match = re.match(r'^(\d+)\.\s', stripped_first)
                        if match:
                            is_bullet_para = True
                            marker = match.group(0)

                    # Collect all words from the paragraph
                    words = []
                    for line in p:
                        # Remove trailing newline for word collection
                        line_content = line.rstrip('\r\n')
                        # The first line's indentation is special? 
                        # "Within a paragraph, runs of spaces and tabs separate words and are replaced by a single space."
                        # This means we should treat the whole paragraph as a stream of words.
                        # But wait: "The first line of a paragraph keeps the indentation it had. Continuation lines repeat that indentation..."
                        # Let's re-read carefully again. 
                        # If I have:
                        #   Line 1
                        #   Line 2
                        # The words in Line 1 and Line 2 are joined by a space?
                        # "Within a paragraph, runs of spaces and tabs separate words and are replaced by a single space."
                        # This usually means we take all non-whitespace characters as words.
                        
                        # Let's try this: collect all text from the lines in p (excluding first line's indentation) 
                        # and split into words.
                        if line == first_line:
                            content = stripped_first
                        else:
                            content = line.lstrip()
                        
                        # But wait, if it's a bullet paragraph, the continuation lines are indented to the first character after the marker.
                        # This means we need to know what that indentation is.
                        if is_bullet_para:
                            # The marker is e.g., "- " or "1. ". 
                            # The text starts after it.
                            # Let's say the first line was "- alpha"
                            # Then continuation lines should be indented to start at 'a'.
                            content = line.lstrip()
                        else:
                            content = line.lstrip()

                        # Actually, the simplest way to "replace runs of spaces and tabs with a single space" 
                        # is to join all content from the paragraph lines (excluding first line's indentation) 
                        # into one string, then split by whitespace.
                        pass
                    
                    # Let's refine this:
                    all_words = []
                    for i, line in enumerate(p):
                        line_content = line.rstrip('\r\n')
                        if i == 0:
                            # First line keeps its indentation. 
                            # We need to know the content after the indentation.
                            stripped_first = first_line.lstrip()
                            # If it's a bullet, we might want to skip the marker?
                            # "The first line of a paragraph keeps the indentation it had."
                            # This means if the first line is "  - item", 
                            # the indentation is "  ".
                            # The content is "- item".
                            content = stripped_first
                        else:
                            if is_bullet_para:
                                # Continuation lines are indented to the first character after the marker.
                                # If marker was "- ", and first line was "- alpha", 
                                # then continuation should start at 'a'.
                                # This means we need to find where 'alpha' started in the first line.
                                # Let's find the index of the first non-whitespace character after the marker.
                                # Actually, it just says "indented to the first character after the marker".
                                # If the marker is "- ", then the char after it is at index 2 (if no leading spaces).
                                # But there might be leading spaces!
                                # Let's find the position of the marker in the first line.
                                pass
                            else:
                                content = line_content.lstrip()
                        
                        # Wait, "Within a paragraph, runs of spaces and tabs separate words and are replaced by a single space."
                        # This applies to the whole paragraph's text.
                        # Let's just collect all non-whitespace sequences from all lines in p (excluding first line's indentation).
                        pass

                    # Let's try again. A paragraph is a sequence of lines.
                    # We need to extract all words from these lines.
                    # For the first line, we keep its leading whitespace as "indentation".
                    # For subsequent lines:
                    #   If it's a bullet para, they have a specific indentation.
                    #   Otherwise, they have the same indentation as the first line.
                    
                    # Let's re-read: "The first line of a paragraph keeps the indentation it had."
                    # "Continuation lines repeat that indentation, except in a bullet paragraph, where they are indented to the first character after the marker."
                    
                    # This means we need to know what the "indentation" is.
                    first_line = p[0]
                    stripped_first = first_line.lstrip()
                    indentation = first_line[:len(first_line) - len(stripped_first)]
                    
                    is_bullet_para = False
                    marker = ""
                    if stripped_first.startswith("- "):
                        is_bullet_para = True
                        marker = "- "
                    elif stripped_first.startswith("* "):
                        is_bullet_para = True
                        marker = "* "
                    else:
                        match = re.match(r'^(\d+)\.\s', stripped_first)
                        if match:
                            is_bullet_para = True
                            marker = match.group(0)

                    # Now, what is the content of the paragraph?
                    # It's all the text from p[0] (after indentation) and p[1:] (after their respective indentations).
                    # But "Within a paragraph, runs of spaces and tabs separate words and are replaced by a single space."
                    # This means we should just take all the non-whitespace characters in order.
                    # Let's see: 
                    #   Line 1
                    #   Line 2
                    # becomes "Line 1 Line 2" (with one space between them).
                    
                    # Wait, if I have:
                    # - item 1
                    #   continued
                    # The content is "item 1 continued".
                    # If it's not a bullet:
                    #   Line 1
                    #   Line 2
                    # The content is "Line 1 Line 2".
                    
                    # Let's collect all words.
                    words = []
                    for i, line in enumerate(p):
                        line_content = line.rstrip('\r\n')
                        if i == 0:
                            # First line content is everything after the indentation.
                            content = first_line[len(indentation):]
                        else:
                            if is_bullet_para:
                                # Continuation lines are indented to the first character after the marker.
                                # The marker's position in the first line (after its own indentation) 
                                # tells us where the text starts.
                                # Example: "  - item" -> indent="  ", marker="- ", text="item".
                                # Continuation lines should be indented by "  - ".
                                # Wait, "indented to the first character after the marker".
                                # If the first line is "  - item", the marker is "- ". 
                                # The char after it is 'i'.
                                # So continuation lines are indented by "  - ".
                                # Let's find the index of the first non-whitespace character in stripped_first.
                                # No, that's not right. It's the marker itself plus its indentation.
                                
                                # Let's simplify: if it's a bullet para, the continuation lines 
                                # should have an indentation equal to (indentation + marker).
                                # If it's not a bullet para, they have the same indentation as first_line.
                                pass
                            else:
                                content = line_content[len(indentation):]
                        
                        # Actually, "Within a paragraph, runs of spaces and tabs separate words 
                        # and are replaced by a single space."
                        # This means we should just take all the text from the lines (after their indentations)
                        # and join it with spaces.
                        pass

                    # Let's try this:
                    all_content = ""
                    for i, line in enumerate(p):
                        line_content = line.rstrip('\r\n')
                        if i == 0:
                            content = first_line[len(indentation):]
                        else:
                            if is_bullet_para:
                                # The indentation for continuation lines is (indentation + marker)
                                # But we need to be careful. If the first line was "  - item", 
                                # then the content of the first line is "- item".
                                # Wait, no. "The first line... keeps the indentation it had."
                                # So if it's "  - item", the indentation is "  ".
                                # The marker is "- ".
                                # The continuation lines are indented to the character after the marker.
                                # That would be "  - ".
                                content = line_content[len(indentation + marker):]
                            else:
                                content = line_content[len(indentation):]
                        
                        if i == 0:
                            all_content += content
                        else:
                            # Join with a space if there was any whitespace at the end of previous content?
                            # "runs of spaces and tabs separate words and are replaced by a single space."
                            # This means we just join all non-whitespace chunks.
                            pass

                    # Let's rethink. The simplest way to handle "runs of spaces... are replaced by a single space" 
                    # is:
                    # 1. Collect all text from the paragraph lines, respecting their indentations.
                    # 2. Replace all runs of whitespace with a single space.
                    # 3. This gives us a sequence of words.
                    # 4. Now we need to wrap these words into lines, keeping track of the indentation for each line.

                    # Let's try this:
                    words = []
                    for i, line in enumerate(p):
                        line_content = line.rstrip('\r\n')
                        if i == 0:
                            content = first_line[len(indentation):]
                        else:
                            if is_bullet_para:
                                content = line_content[len(indentation + marker):]
                            else:
                                content = line_content[len(indentation):]
                        words.extend(content.split())

                    # Now wrap the words.
                    current_line_words = []
                    current_line_width = 0
                    
                    # The first line of a paragraph keeps its indentation.
                    # Continuation lines repeat that indentation (or bullet-specific).
                    
                    # Wait, I need to know the width of the indentation too!
                    indent_width = get_text_width(indentation)
                    bullet_indent_width = get_text_width(indentation + marker) if is_bullet_para else indent_width

                    # This is still a bit complex. Let's simplify:
                    # A paragraph is wrapped such that each line starts with the correct indentation.
                    # The first line of a paragraph uses `indentation`.
                    # Subsequent lines use `indentation` (if not bullet) or `indentation + marker` (if bullet).

                    # Let's try to build the result_lines for this paragraph:
                    para_result = []
                    word_idx = 0
                    while word_idx < len(words):
                        line_words = []
                        line_width = 0
                        
                        # Determine indentation for this line
                        if not para_result: # First line of paragraph
                            current_indent_str = indentation
                            current_indent_width = indent_width
                        else: # Continuation line
                            if is_bullet_para:
                                current_indent_str = indentation + marker
                                current_indent_width = bullet_indent_width
                            else:
                                current_indent_str = indentation
                                current_indent_width = indent_width
                        
                        # Try to add words
                        while word_idx < len(words):
                            word = words[word_idx]
                            word_width = get_text_width(word)
                            
                            # If it's the first word of the line, we don't add a space before it.
                            # But wait, "No output line ends in a space."
                            # And "Within a paragraph, runs of spaces and tabs separate words and are replaced by a single space."
                            # This means if we have multiple words, they are separated by one space.
                            
                            space_width = 1 if line_words else 0
                            if current_indent_width + line_width + space_width + word_width <= self.width:
                                # If the word is too long to fit even on its own line, it overflows.
                                # "A piece that does not fit even on a line of its own is not split: 
                                # it takes a line of its own and overflows it."
                                if current_indent_width + word_width > self.width:
                                    # This word won't fit even with just the indentation.
                                    # It should take its own line (with indentation) and overflow.
                                    break # Break to next line, but this word will be first on that line.
                                else:
                                    line_words.append(word)
                                    line_width += space_width + word_width
                                    word_idx += 1
                            else:
                                break
                        
                        # If we have no words, but there's still a paragraph to process? 
                        # That shouldn't happen with the current logic.
                        if not line_words: # This happens if the first word doesn't fit even with indentation
                            word = words[word_idx]
                            para_result.append(current_indent_str + word)
                            # We don't increment word_idx because it's now on its own line (overflowing).
                            # Wait, if it overflows, it takes a line of its own and overflows it.
                            # This means the next words will start on the NEXT line.
                            word_idx += 1
                        else:
                            para_result.append(current_indent_str + " ".join(line_words))

                    # Wait, if a word is so long that even with indentation it overflows,
                    # it takes its own line and overflows. The next words should start on the NEXT line.
                    # My logic above: `if current_indent_width + word_width > self.width: break` 
                    # will make it the first word of the next line. If it still doesn't fit, 
                    # the `if not line_words:` block will handle it.
                    
                    # Let's refine that slightly to ensure we don't get stuck in an infinite loop.
                    # Actually, if a word is too long, it should be added as its own line and we move to next words.

                    # Re-refining the wrapping:
                    para_result = []
                    word_idx = 0
                    while word_idx < len(words):
                        if not para_result:
                            current_indent_str = indentation
                            current_indent_width = indent_width
                        else:
                            if is_bullet_para:
                                current_indent_str = indentation + marker
                                current_indent_width = bullet_indent_width
                            else:
                                current_indent_str = indentation
                                current_indent_width = indent_width
                        
                        line_words = []
                        line_width = 0
                        first_word_of_line = True
                        
                        while word_idx < len(words):
                            word = words[word_idx]
                            word_width = get_text_width(word)
                            space_width = 1 if not first_word_of_line else 0
                            
                            if current_indent_width + line_width + space_width + word_width <= self.width:
                                line_words.append(word)
                                line_width += space_width + word_width
                                first_word_of_line = False
                                word_idx += 1
                            else:
                                # Word doesn't fit on this line.
                                break
                        
                        if not line_words:
                            # The first word of the paragraph (or next available) is too long for its own line.
                            word = words[word_idx]
                            para_result.append(current_indent_str + word)
                            word_idx += 1
                        else:
                            para_result.append(current_indent_str + " ".join(line_words))

                    # Wait, there's one more thing: "A piece that does not fit even on a line of its own is not split"
                    # This applies to URLs and long paths. My `word = words[word_idx]` handles this 
                    # because I split by whitespace. If a URL has no spaces, it's one word.
                    
                    result_lines.extend(para_result)

        # Final assembly
        final_text = "\n".join(result_lines)
        if has_trailing_newline and not final_text.endswith('\n'):
            final_text += '\n'
        return final_text

def solution_reflow(text: str, width: int) -> str:
    rf = Reflow(width)
    return rf.reflow(text)

# To make it compatible with the test runner
solution = solution_reflow
