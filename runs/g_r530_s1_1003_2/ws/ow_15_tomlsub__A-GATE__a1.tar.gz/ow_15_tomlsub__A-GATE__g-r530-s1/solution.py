import re

class Solution:
    def parse(self, text: str) -> dict:
        data = {}
        current_group = data
        lines = text.splitlines()
        name_regex = re.compile(r'^[a-zA-Z0-9_-]+$')
        opened_headings = set()

        for i, line in enumerate(lines):
            line_num = i + 1
            comment_start = -1
            in_quotes = False
            quote_char = None
            escaped = False
            for j, char in enumerate(line):
                if escaped:
                    escaped = False
                    continue
                if char == '\\':
                    escaped = True
                elif char in ('"', "'"):
                    if not in_quotes:
                        in_quotes = True
                        quote_char = char
                    elif quote_char == char:
                        in_quotes = False
                elif char == '#' and not in_quotes:
                    comment_start = j
                    break
            
            content_line = line[:comment_start] if comment_start != -1 else line
            stripped = content_line.strip()
            if not stripped:
                continue

            if stripped.startswith('[') and stripped.endswith(']'):
                heading_content = stripped[1:-1].strip()
                if not heading_content:
                    raise ValueError(f"line {line_num}: empty heading")
                parts = heading_content.split('.')
                for p in parts:
                    if not name_regex.match(p):
                        raise ValueError(f"line {line_num}: invalid name '{p}'")
                
                heading_key = ".".join(parts)
                if heading_key in opened_headings:
                    raise ValueError(f"line {line_num}: heading opened twice")
                opened_headings.add(heading_key)

                new_group = data
                for p in parts:
                    if p not in new_group or not isinstance(new_group[p], dict):
                        new_group[p] = {}
                    new_group = new_group[p]
                current_group = new_group
            else:
                if '=' not in stripped:
                    raise ValueError(f"line {line_num}: invalid line")
                name, val_part = stripped.split('=', 1)
                name = name.strip()
                val_part = val_part.strip()
                
                if not name_regex.match(name):
                    raise ValueError(f"line {line_num}: invalid name '{name}'")
                if name in current_group:
                    raise ValueError(f"line {line_num}: name used twice")

                current_group[name] = self._parse_value(val_part, line_num)
        return data

    def _parse_value(self, val_str, line_num):
        if val_str.startswith('"') and val_str.endswith('"'):
            content = val_str[1:-1]
            res = []
            i = 0
            while i < len(content):
                char = content[i]
                if char == '\\':
                    if i + 1 >= len(content): break
                    next_char = content[i+1]
                    if next_char == '"': res.append('"')
                    elif next_char == '\\': res.append('\\')
                    elif next_char == 'n': res.append('\n')
                    elif next_char == 't': res.append('\t')
                    else: res.append(next_char)
                    i += 2
                else:
                    res.append(char)
                    i += 1
            return "".join(res)
        
        if val_str == "true": return True
        if val_str == "false": return False
        
        if val_str.startswith('[') and val_str.endswith(']'):
            content = val_str[1:-1].strip()
            if not content:
                return []
            items = []
            current_item = []
            in_quotes = False
            quote_char = None
            escaped = False
            for char in content:
                if escaped:
                    current_item.append(char)
                    escaped = False
                elif char == '\\':
                    escaped = True
                    current_item.append(char) 
                elif char in ('"', "'"):
                    if not in_quotes:
                        in_quotes = True
                        quote_char = char
                    elif quote_char == char:
                        in_quotes = False
                    current_item.append(char)
                elif char == ',' and not in_quotes:
                    items.append("".join(current_item).strip())
                    current_item = []
                else:
                    current_item.append(char)
            items.append("".join(current_item).strip())
            
            parsed_items = []
            for it in items:
                if it.startswith('"') and it.endswith('"'):
                    parsed_items.append(self._parse_value(it, line_num))
                elif it == "true": parsed_items.append(True)
                elif it == "false": parsed_items.append(False)
                else:
                    try:
                        if '.' in it:
                            parsed_items.append(float(it))
                        else:
                            parsed_items.append(int(it))
                    except ValueError:
                        parsed_items.append(it)

            if not parsed_items: return []
            first_type = type(parsed_items[0])
            if not all(isinstance(x, first_type) for x in parsed_items):
                raise ValueError(f"line {line_num}: mixed types in list")
            return parsed_items

        try:
            if '.' in val_str:
                parts = val_str.split('.')
                if len(parts) != 2 or not all(p.replace('-', '').isdigit() for p in parts):
                    raise ValueError
                return float(val_str)
            else:
                if not (val_str.replace('-', '').isdigit()):
                    raise ValueError
                return int(val_str)
        except ValueError:
            raise ValueError(f"line {line_num}: invalid value '{val_str}'")

def parse(text: str) -> dict:
    return Solution().parse(text)

def dumps(data: dict) -> str:
    lines = []
    # Top-level names first in name order. 
    # A top-level name is a key in the root dictionary that is NOT part of any heading.
    # Wait, "headings can be nested with dots". This means [a.b] creates data["a"]["b"].
    # So if we have [a], it's data["a"] = {}. If we then have a = 1, it's data["a"] = 1.
    # But the rule says "the same heading opened twice" is a mistake.
    # And "the same setting written twice in one group" is a mistake.
    # A name at the top level can be either a value or a heading.
    # If it's a heading, it will be a dict. If it's a value, it won't be a dict (or it will be an empty dict? No).
    # Actually, if we have [a], then "b = 1" is in data["a"]["b"].
    # The top level names are the keys of `data` that are NOT headings.
    # But how do we know if a key is a heading or not?
    # A heading is something that was opened with [].
    # Let's just distinguish them by whether they were created as part of a heading or as a value.
    pass

