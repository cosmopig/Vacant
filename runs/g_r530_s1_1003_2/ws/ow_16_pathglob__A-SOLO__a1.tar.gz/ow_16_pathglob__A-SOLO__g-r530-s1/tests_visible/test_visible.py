import unittest
import re

class Solution:
    def matches(self, pattern: str, path: str) -> bool:
        pattern_segments = pattern.split('/')
        path_segments = path.split('/')
        
        def get_segment_regex(p_seg):
            if p_seg == '**':
                return None
            
            regex = ""
            i = 0
            while i < len(p_seg):
                if p_seg[i] == '*':
                    regex += ".*"
                    i += 1
                elif p_seg[i] == '?':
                    regex += "."
                    i += 1
                elif p_seg[i] == '[':
                    j = i + 1
                    if j >= len(p_seg): raise ValueError("Unclosed bracket")
                    content = ""
                    while j < len(p_seg) and p_seg[j] != ']':
                        content += p_seg[j]
                        j += 1
                    if j == len(p_seg): raise ValueError("Unclosed bracket")
                    if not content: raise ValueError("Empty class")
                    
                    negate = False
                    if content.startswith('!'):
                        negate = True
                        content = content[1:]
                    
                    chars = []
                    k = 0
                    while k < len(content):
                        if k + 1 < len(content) and content[k+1] == '-':
                            start = ord(content[k])
                            end = ord(content[k+1])
                            for char_code in range(start, end + 1):
                                chars.append(chr(char_code))
                            k += 2
                        else:
                            chars.append(content[k])
                            k += 1
                    
                    if negate:
                        regex += "(?=[^" + "".join(re.escape(c) for c in chars) + "])."
                    else:
                        regex += "[" + "".join(re.escape(c) for c in chars) + "]"
                    i = j + 1
                else:
                    regex += re.escape(p_seg[i])
                    i += 1
            return "^" + regex + "$"

        def match_recursive(p_idx, path_idx):
            if p_idx == len(pattern_segments):
                return path_idx == len(path_segments)
            
            p_seg = pattern_segments[p_idx]
            
            if p_seg == '**':
                for skip in range(len(path_segments) - path_idx + 1):
                    if match_recursive(p_idx + 1, path_idx + skip):
                        return True
                return False
            else:
                if path_idx >= len(path_segments):
                    return False
                
                regex = get_segment_regex(p_seg)
                if regex is None: # Should not happen for non-** segments
                    return False
                
                return bool(re.match(regex, path_segments[path_idx]))

        return match_recursive(0, 0)

    def select(self, patterns: list[str], paths: list[str]) -> list[str]:
        for p in patterns:
            try:
                p_segs = p.split('/')
                for seg in p_segs:
                    if seg == '**': continue
                    if '[' in seg:
                        if seg.count('[') != seg.count(']'): raise ValueError("Unclosed bracket")
                        start = seg.find('[')
                        end = seg.find(']', start)
                        if end == -1: raise ValueError("Unclosed bracket")
                        content = seg[start+1:end]
                        if not content: raise ValueError("Empty class")
            except ValueError as e:
                raise e

        current_selection = [False] * len(paths)
        for p in patterns:
            if p.startswith('!'):
                sub_pattern = p[1:]
                for i, path in enumerate(paths):
                    if current_selection[i]:
                        if self.matches(sub_pattern, path):
                            current_selection[i] = False
            else:
                for i, path in enumerate(paths):
                    if not current_selection[i]:
                        if self.matches(p, path):
                            current_selection[i] = True
        
        result = []
        for i, selected in enumerate(current_selection):
            if selected:
                result.append(paths[i])
        return result

class TestSolution(unittest.TestCase):
    def setUp(self):
        self.sol = Solution()

    def test_basic_matches(self):
        self.assertTrue(self.sol.matches("src/*.py", "src/main.py"))
        self.assertFalse(self.sol.matches("src/*.py", "src/subdir/main.py"))
        self.assertTrue(self.sol.matches("src/**", "src/a/b/c.py"))
        self.assertTrue(self.sol.matches("src/**", "src/"))

    def test_wildcards(self):
        self.assertTrue(self.sol.matches("a?c", "abc"))
        self.assertFalse(self.sol.matches("a?c", "abcd"))
        self.assertTrue(self.sol.matches("a*c", "abbbc"))
        self.assertTrue(self.sol.matches("a*c", "ac"))

    def test_brackets(self):
        self.assertTrue(self.sol.matches("[abc]", "a"))
        self.assertTrue(self.sol.matches("[abc]", "b"))
        self.assertTrue(self.sol.matches("[abc]", "c"))
        self.assertFalse(self.sol.matches("[abc]", "d"))
        self.assertTrue(self.sol.matches("[a-z]", "m")
        self.assertFalse(self.sol.matches("[a-z]", "1")
        self.assertTrue(self.sol.matches("![abc]", "d")
        self.assertTrue(self.sol.matches("![abc]", "z")
        self.assertFalse(self.sol.matches("![abc]", "a")

    def test_select(self):
        paths = ["src/a.py", "src/b.py", "src/c.py", "tests/a.py"]
        patterns = ["src/*", "!src/b.py"]
        self.assertEqual(self.sol.select(patterns, paths), ["src/a.py", "src/c.py"])

    def test_errors(self):
        with self.assertRaises(ValueError):
            self.sol.matches("[abc", "a")
        with self.assertRaises(ValueError):
            self.sol.matches("[]", "a")
        with self.assertRaises(ValueError):
            self.sol.select(["[abc"], ["a"])

if __name__ == "__main__":
    unittest.main()
