from datetime import datetime, timezone

def parse_instant(instant: str) -> datetime:
    if len(instant) == 10 and instant[4] == '-':
        # YYYY-MM-DD
        return datetime.strptime(instant, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    else:
        # YYYY-MM-DDTHH:MM:SS
        try:
            return datetime.strptime(instant, "%Y-%m-%dT%H:%M:%S").replace(tzinfo=timezone.utc)
        except ValueError as e:
            raise ValueError(f"Invalid instant format: {instant}") from e

def format_instant(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%S")

def merge(spans: list[tuple[str, str]]) -> list[tuple[str, str]]:
    parsed = []
    for start_str, end_str in spans:
        try:
            start = parse_instant(start_str)
            end = parse_instant(end_str)
        except ValueError as e:
            raise ValueError(f"Invalid instant format: {start_str} or {end_str}") from e
        
        if end < start:
            raise ValueError(f"End {end_str} is before start {start_str}")
        
        parsed.append((start, end))
    
    if not parsed:
        return []
    
    # Sort by start time
    parsed.sort()
    
    merged = []
    curr_start, curr_end = parsed[0]
    for next_start, next_end in parsed[1:]:
        if next_start <= curr_end:
            curr_end = max(curr_end, next_end)
        else:
            merged.append((curr_start, curr_end))
            curr_start, curr_end = next_start, next_end
    merged.append((curr_start, curr_end))
    
    result = []
    for s, e in merged:
        if s < e:
            result.append((format_instant(s), format_instant(e)))
    return result

def subtract(spans: list[tuple[str, str]], holes: list[tuple[str, str]]) -> list[tuple[str, str]]:
    merged_spans = merge(spans)
    if not merged_spans:
        return []
    
    parsed_busy = [(parse_instant(s), parse_instant(e)) for s, e in merged_spans]
    parsed_holes = []
    for h_start, h_end in holes:
        hs = parse_instant(h_start)
        he = parse_instant(h_end)
        if he < hs:
            raise ValueError(f"End {h_end} is before start {h_start}")
        parsed_holes.append((hs, he))
    
    # Sort holes by start time
    parsed_holes.sort()
    
    result = []
    for b_start, b_end in parsed_busy:
        current_segments = [(b_start, b_end)]
        for h_start, h_end in parsed_holes:
            new_segments = []
            for s_start, s_end in current_segments:
                # If hole is completely outside segment
                if h_end <= s_start or h_start >= s_end:
                    new_segments.append((s_start, s_end))
                else:
                    # Hole overlaps with segment
                    # Part before the hole
                    if h_start > s_start:
                        new_segments.append((s_start, h_start))
                    # Part after the hole
                    if h_end < s_end:
                        new_segments.append((h_end, s_end))
            current_segments = new_segments
        
        for s, e in current_segments:
            if s < e:
                result.append((format_instant(s), format_instant(e)))
    
    # Re-merge to ensure tidiness and order (though it should already be tidy)
    final_spans = []
    for s, e in result:
        final_spans.append((parse_instant(s), parse_instant(e)))
    
    if not final_spans:
        return []
    final_spans.sort()
    
    tidy = []
    curr_start, curr_end = final_spans[0]
    for next_start, next_end in final_spans[1:]:
        if next_start <= curr_end:
            curr_end = max(curr_end, next_end)
        else:
            tidy.append((curr_start, curr_end))
            curr_start, curr_end = next_start, next_end
    tidy.append((curr_start, curr_end))
    
    return [(format_instant(s), format_instant(e)) for s, e in tidy if s < e]

def total_seconds(spans: list[tuple[str, str]]) -> int:
    merged = merge(spans)
    total = 0
    for s, e in merged:
        start = parse_instant(s)
        end = parse_instant(e)
        total += int((end - start).total_seconds())
    return total
