import re

class Solution:
    def parse(self, text: str) -> dict:
        data = {}
        current_group = data
        lines = text.splitlines()
        
        for i, line in enumerate(lines):
            line_num = i + 1
            
            comment_idx = -1
            in_string = False
            escaped = False
            for j, char in enumerate(line):
                if escaped:
                    escaped = False
                    continue
                if char == '\\':
                    escaped = True
                elif char == '"':
                    in_string = not in_string
                elif char == '#' and not in_string:
                    comment_idx = j
                    break
            
            content = line[:comment_idx] if comment_idx != -1 else line
            stripped = content.strip()
            if not stripped or stripped.startswith('#'):
                continue

            if stripped.startswith('[') and stripped.endswith(']'):
                heading_content = stripped[1:-1].strip()
                if not heading_content:
                    raise ValueError(f"line {line_num}: empty heading")
                parts = heading_content.split('.')
                new_group = data
                for part in parts:
                    part = part.strip()
                    if not re.match(r'^[a-zA-Z0-9_-]+$', part):
                        raise ValueError(f"line {line_num}: invalid name '{part}'")
                    
                    if part not in new_group:
                        new_group[part] = {}
                    else:
                        if isinstance(new_group[part], dict):
                            raise ValueError(f"line {line_num}: heading opened twice")
                    
                    new_group = new_group[part]
                current_group = new_group

            elif '=' in content:
                key, val_raw = content.split('=', 1)
                key = key.strip()
                val_raw = val_raw.strip()
                
                if not re.match(r'^[a-zA-Z0-9_-]+$', key):
                    raise ValueError(f"line {line_num}: invalid name '{key}'")
                
                if key in current_group:
                    if isinstance(current_group[key], dict):
                        pass 
                    else:
                        raise ValueError(f"line {line_num}: same setting written twice")
                
                parsed_val = self._parse_value(val_raw, line_num)
                current_group[key] = parsed_val

        return data

    def _parse_value(self, val_raw, line_num):
        if not val_raw:
            raise ValueError(f"line {line_num}: empty value")
            
        # String "..."
        if val_raw.startswith('"') and val_raw.endswith('"'):
            content = val_raw[1:-1]
            res = ""
            i = 0
            while i < len(content):
                char = content[i]
                if char == '\\':
                    if i + 1 >= len(content): raise ValueError(f"line {line_num}: trailing backslash")
                    next_char = content[i+1]
                    if next_char == '"': res += '"'
                    elif next_char == '\\': res += '\\'
                    elif next_char == 'n': res += '\n'
                    elif next_char == 't': res += '\t'
                    else: raise ValueError(f"line {line_num}: invalid escape")
                    i += 2
                else:
                    res += char
                    i += 1
            return res

        # Boolean
        if val_raw == "true": return True
        if val_raw == "false": return False

        # List [v, v]
        if val_raw.startswith('[') and val_raw.endswith(']'):
            inner = val_raw[1:-1].strip()
            if not inner:
                return []
            parts = [p.strip() for p in inner.split(',')]
            first_val = self._parse_value(parts[0], line_num)
            first_type = type(first_val)
            
            results = []
            for p in parts:
                v = self._parse_value(p, line_num)
                if type(v) != first_type:
                    raise ValueError(f"line {line_num}: list items must be of the same kind")
                results.append(v)
            return results

        # Number (Decimal or Whole)
        if '.' in val_raw:
            parts = val_raw.split('.')
            if len(parts) != 2 or not parts[0].lstrip('-').isdigit() or not parts[1].isdigit():
                raise ValueError(f"line {line_num}: invalid decimal")
            return float(val_raw)
        else:
            if val_raw.lstrip('-').isdigit():
                return int(val_raw)
            else:
                raise ValueError(f"line {line_num}: invalid number")

    def dumps(self, data: dict) -> str:
        lines = []
        
        # Top-level names first in name order
        top_keys = sorted([k for k in data.keys() if not isinstance(data[k], dict)])
        for k in top_keys:
            v = data[k]
            if isinstance(v, bool):
                val_str = "true" if v else "false"
            elif isinstance(v, int):
                val_str = str(v)
            elif isinstance(v, float):
                if v == int(v):
                    val_str = str(int(v))
                else:
                    val_str = str(v)
            elif isinstance(v, str):
                escaped = v.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n').replace('\t', '\\t')
                val_str = f'"{escaped}"'
            elif isinstance(v, list):
                if not v:
                    val_str = "[]"
                else:
                    items = []
                    for item in v:
                        if isinstance(item, bool):
                            items.append("true" if item else "false")
                        elif isinstance(item, int):
                            items.append(str(item))
                        elif isinstance(item, float):
                            f_val = item
                            if f_val == int(f_val):
                                items.append(str(int(f_val)))
                            else:
                                items.append(str(f_val))
                        elif isinstance(item, str):
                            escaped = item.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n').replace('\t', '\\t')
                            items.append(f'"{escaped}"')
                    val_str = "[" + ", ".join(items) + "]"
            else:
                raise ValueError("Unsupported type in dumps")
            lines.append(f'{k} = {val_str}')

        # Headings and their names
        heading_keys = sorted([k for k in data.keys() if isinstance(data[k], dict)])
        for k in heading_keys:
            lines.append("")
            lines.append(f"[{k}]")
            self._dump_group(data[k], lines)

        return "\n".join(lines).strip()

    def _dump_group(self, group: dict, lines: list):
        # A heading is any key that maps to a dict.
        # We need to sort all keys in this group.
        # Settings first (in name order), then headings (in name order).
        # Wait, the rule says "then each heading in name order with its own names in name order".
        # This means we should dump settings for a heading, and then sub-headings? 
        # No, it says: "top-level names first... then each heading in name order with its own names in name order"
        # Let's re-read carefully.
        # "top-level names first in name order" -> these are keys at the root of data that are NOT headings.
        # "then each heading in name order" -> these are keys at the root of data that ARE headings.
        # For each such heading, we dump its names (settings and sub-headings) in name order.
        # This is recursive.

        pass # I'll rewrite this part again to be more careful.
