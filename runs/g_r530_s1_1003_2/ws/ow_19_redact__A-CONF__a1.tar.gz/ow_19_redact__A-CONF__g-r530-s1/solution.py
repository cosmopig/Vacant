import re

def find_secrets(text):
    matches = []
    
    # 1. AWS-like keys (AKIA/ASIA followed by 16 alphanumeric characters)
    for m in re.finditer(r'\b(AKIA|ASIA)[A-Z0-9]{16}\b', text):
        matches.append((m.start(), m.end(), m.group()))

    # 2. Bearer tokens (non-whitespace after "Bearer ")
    for m in re.finditer(r'Bearer\s+([^\s,]+)', text):
        token = m.group(1)
        matches.append((m.start() + 7, m.end(), token))

    # 3. Connection strings (postgres|mysql|mongodb|redis|amqp)://[^:]+:[^@]+@[^:/]+:[0-9]+/[^ \t\n\r\f\v]+
    # We need to be careful about the colon after // and the one before @.
    for m in re.finditer(r'(?:postgres|mysql|mongodb|redis|amqp)://[^:]+:[^@]+@[^:/]+:[0-9]+/[^ \t\n\r\f\v]+', text):
        content = m.group()
        # Find the colon that is followed by something and then an @
        colon_idx = -1
        for i in range(content.find('//') + 2, len(content)):
            if content[i] == ':' and '@' in content[i:]:
                colon_idx = i
                break
        
        if colon_idx != -1:
            at_idx = content.find('@', colon_idx)
            password = content[colon_idx+1 : at_idx]
            matches.append((m.start() + colon_idx, m.start() + at_idx, password))

    # Sort matches by start position descending to replace without messing up indices
    matches.sort(key=lambda x: x[0], reverse=True)
    
    unique_matches = []
    if matches:
        last_end = float('inf')
        for start, end, val in matches:
            # If a match is contained within another or overlaps significantly, 
            # we should be careful. But for these specific patterns, they shouldn't overlap much.
            if end < last_end:
                unique_matches.append((start, end, val))
                last_end = end
    
    return unique_matches

def redact(text):
    matches = find_secrets(text)
    result = text
    # We need to replace from back to front so indices remain valid
    for start, end, _ in matches:
        result = result[:start] + "[REDACTED]" + result[end:]
    return result

def findings(text):
    matches = find_secrets(text)
    # The order of findings should probably match the order they appear in the text.
    sorted_matches = sorted(matches, key=lambda x: x[0])
    return [m[2] for m in sorted_matches]

solution = type('Solution', (), {'redact': redact, 'findings': findings})()
