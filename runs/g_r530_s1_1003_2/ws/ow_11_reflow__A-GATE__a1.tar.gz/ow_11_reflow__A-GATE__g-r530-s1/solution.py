import unicodedata
import re

def get_char_width(char):
    if unicodedata.east_asian_width(char) in ("W", "F"):
        return 2
    return 1

def get_text_width(text):
    return sum(get_char_width(c) for c in text)

class Reflow:
    def __init__(self, width):
        if width <= 0:
            raise ValueError("Width must be positive")
        self.width = width

    def reflow(self, text: str) -> str:
        lines = text.splitlines(keepends=True)
        has_final_newline = text.endswith('\n')
        
        processed_elements = []
        i = 0
        while i < len(lines):
            line = lines[i]
            if line.strip().startswith('```'):
                code_block = []
                code_block.append(line)
                i += 1
                while i < len(lines) and not lines[i].strip().startswith('```'):
                    code_block.append(lines[i])
                    i += 1
                if i < len(lines):
                    code_block.append(lines[i])
                    i += 1
                processed_elements.append(('code', code_block))
            elif not line.strip():
                processed_elements.append(('blank', line))
                i += 1
            else:
                current_para_lines = []
                while i < len(lines):
                    line = lines[i]
                    stripped = line.lstrip()
                    if not stripped:
                        break
                    
                    is_bullet = False
                    marker = ""
                    if stripped.startswith("- "):
                        is_bullet = True
                        marker = "- "
                    elif stripped.startswith("* "):
                        is_bullet = True
                        marker = "* "
                    else:
                        match = re.match(r'^(\d+)\. ', stripped)
                        if match:
                            is_bullet = True
                            marker = match.group(0)
                    
                    if is_bullet and current_para_lines:
                        processed_elements.append(('paragraph', current_para_lines))
                        current_para_lines = []
                    
                    current_para_lines.append(line)
                    i += 1
                processed_elements.append(('paragraph', current_para_lines))

        final_output = []
        for elem in processed_elements:
            if elem[0] == 'code':
                for l in elem[1]:
                    final_output.append(l)
            elif elem[0] == 'blank':
                final_output.append("")
            elif elem[0] == 'paragraph':
                para_lines = elem[1]
                first_line = para_lines[0]
                stripped_first = first_line.lstrip()
                base_indent_len = len(first_line) - len(stripped_first)
                
                is_bullet_para = False
                marker = ""
                if stripped_first.startswith("- "):
                    is_bullet_para = True
                    marker = "- "
                elif stripped_first.startswith("* "):
                    is_bullet_para = True
                    marker = "* "
                else:
                    match = re.match(r'^(\d+)\. ', stripped_first)
                    if match:
                        is_bullet_para = True
                        marker = match.group(0)

                col_after_marker = base_indent_len + len(marker) if is_bullet_para else base_indent_len
                
                words = []
                for j, l in enumerate(para_lines):
                    if j == 0:
                        content = l[col_after_marker:]
                    else:
                        if len(l) > col_after_marker:
                            content = l[col_after_marker:]
                        else:
                            content = ""
                    words.extend(content.split())

                current_para_output = []
                current_line_words = []
                current_line_width = 0 # This will be width of text ONLY (no indentation)
                
                for i, word in enumerate(words):
                    word_width = get_text_width(word)
                    if not current_line_words:
                        current_line_words.append(word)
                        current_line_width = word_width
                    else:
                        space_width = 1
                        # What's the current indentation?
                        if len(current_para_output) == 0:
                            current_indent = base_indent_len if not is_bullet_para else (base_indent_len + len(marker))
                        else:
                            current_indent = col_after_marker
                        
                        if current_line_width + space_width + word_width <= (self.width - current_indent):
                            current_line_words.append(word)
                            current_line_width += space_width + word_width
                        else:
                            # Doesn't fit, so finish the current line and start a new one with this word
                            current_para_output.append(" ".join(current_line_words))
                            current_line_words = [word]
                            current_line_width = word_width

                if current_line_words:
                    current_para_output.append(" ".join(current_line_words))
                
                final_wrapped_para = []
                for k, line in enumerate(current_para_output):
                    if k == 0:
                        indent = " " * base_indent_len
                    else:
                        indent = " " * col_after_marker
                    
                    if is_bullet_para and k == 0:
                        # The first line should have its original indentation AND its marker.
                        # We need to be careful about the space between indent and marker.
                        # Actually, let's just use the base_indent_len + marker.
                        indent = " " * base_indent_len + marker
                    
                    final_wrapped_para.append(indent + line)
                
                for l in final_wrapped_para:
                    final_output.append(l)

        result = "\n".join(final_output)
        if has_final_newline and not result.endswith('\n'):
            result += '\n'
        return result

def reflow(text: str, width: int) -> str:
    rf = Reflow(width)
    return rf.reflow(text)
