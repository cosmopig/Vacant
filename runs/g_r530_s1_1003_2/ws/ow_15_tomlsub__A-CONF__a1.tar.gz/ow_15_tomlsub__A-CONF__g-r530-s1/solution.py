import re

class Solution:
    def parse(self, text: str) -> dict:
        lines = text.splitlines()
        data = {}
        current_group = data
        headings = []  # List of (path_tuple, line_num)
        group_keys = {(): {}} # path_tuple -> {name: line_num}

        def _parse_single_value(v_str):
            if v_str == "true": return True
            if v_str == "false": return False
            if v_str.startswith('"') and v_str.endswith('"'):
                inner = v_str[1:-1]
                res = []
                idx = 0
                while idx < len(inner):
                    char = inner[idx]
                    if char == '\\':
                        if idx + 1 >= len(inner): raise ValueError("Trailing backslash")
                        next_char = inner[idx+1]
                        if next_char == '"': res.append('"')
                        elif next_char == '\\': res.append('\\')
                        elif next_char == 'n': res.append('\n')
                        elif next_char == 't': res.append('\t')
                        else: raise ValueError("Invalid escape")
                        idx += 2
                    else:
                        res.append(char)
                        idx += 1
                return "".join(res)
            if '.' in v_str:
                try: return float(v_str)
                except ValueError: raise ValueError("Invalid decimal")
            try:
                if re.match(r'^-?\d+$', v_str):
                    return int(v_str)
                else:
                    raise ValueError("Not a number")
            except ValueError:
                raise ValueError("Invalid value")

        current_path = ()
        for i, line in enumerate(lines):
            line_num = i + 1
            stripped = line.strip()
            if not stripped or stripped.startswith('#'):
                continue

            comment_idx = -1
            in_quotes = False
            escaped = False
            for j, char in enumerate(line):
                if escaped:
                    escaped = False
                    continue
                if char == '\\':
                    escaped = True
                elif char == '"':
                    in_quotes = not in_quotes
                elif char == '#' and not in_quotes:
                    comment_idx = j
                    break
            
            content = line[:comment_idx] if comment_idx != -1 else line
            stripped_content = content.strip()

            if not stripped_content:
                continue

            if stripped_content.startswith('[') and stripped_content.endswith(']'):
                path_str = stripped_content[1:-1].strip()
                parts = path_str.split('.')
                if any(not p or not re.match(r'^[a-zA-Z0-9_-]+$', p) for p in parts):
                     raise ValueError(f"line {line_num}: Invalid heading name")

                path_tuple = tuple(parts)
                for prev_path, prev_ln in headings:
                    if prev_path == path_tuple:
                        raise ValueError(f"line {line_num}: Heading opened twice")
                headings.append((path_tuple, line_num))

                current_group = data
                for part in parts:
                    if part not in current_group:
                        current_group[part] = {}
                    current_group = current_group[part]
                
                current_path = path_tuple
                if path_tuple not in group_keys:
                    group_keys[path_tuple] = {}

            elif '=' in stripped_content:
                name, val_str = stripped_content.split('=', 1)
                name = name.strip()
                val_str = val_str.strip()
                if not re.match(r'^[a-zA-Z0-9_-]+$', name):
                    raise ValueError(f"line {line_num}: Invalid name")
                
                if name in group_keys[current_path]:
                    raise ValueError(f"line {line_num}: Duplicate setting")

                # Parse value
                if val_str == "true":
                    value = True
                elif val_str == "false":
                    value = False
                elif val_str.startswith('"') and val_str.endswith('"'):
                    inner = val_str[1:-1]
                    res = []
                    idx = 0
                    while idx < len(inner):
                        char = inner[idx]
                        if char == '\\':
                            if idx + 1 >= len(inner): raise ValueError("Trailing backslash")
                            next_char = inner[idx+1]
                            if next_char == '"': res.append('"')
                            elif next_char == '\\': res.append('\\')
                            elif next_char == 'n': res.append('\n')
                            elif next_char == 't': res.append('\t')
                            else: raise ValueError("Invalid escape")
                            idx += 2
                        else:
                            res.append(char)
                            idx += 1
                    value = "".join(res)
                elif val_str.startswith('[') and val_str.endswith(']'):
                    inner = val_str[1:-1].strip()
                    if not inner:
                        value = []
                    else:
                        items = [x.strip() for x in inner.split(',')]
                        parsed_items = []
                        for item in items:
                            if item == "true": parsed_items.append(True)
                            elif item == "false": parsed_items.append(False)
                            elif item.startswith('"') and item.endswith('"'):
                                inner_item = item[1:-1]
                                res_item = []
                                idx_item = 0
                                while idx_item < len(inner_item):
                                    char_item = inner_item[idx_item]
                                    if char_item == '\\':
                                        if idx_item + 1 >= len(inner_item): raise ValueError("Trailing backslash")
                                        next_char_item = inner_item[idx_item+1]
                                        if next_char_item == '"': res_item.append('"')
                                        elif next_char_item == '\\': res_item.append('\\')
                                        elif next_char_item == 'n': res_item.append('\n')
                                        elif next_char_item == 't': res_item.append('\t')
                                        else: raise ValueError("Invalid escape")
                                        idx_item += 2
                                    else:
                                        res_item.append(char_item)
                                        idx_item += 1
                                parsed_items.append("".join(res_item))
                            elif '.' in item:
                                try: parsed_items.append(float(item))
                                except ValueError: raise ValueError("Invalid decimal")
                            else:
                                try:
                                    if re.match(r'^-?\d+$', item):
                                        parsed_items.append(int(item))
                                    else: raise ValueError("Not a number")
                                except ValueError: raise ValueError("Invalid value")
                        
                        if not parsed_items: # Should not happen with non-empty inner
                            value = []
                        else:
                            first_kind = type(parsed_items[0])
                            for p in parsed_items:
                                if type(p) != first_kind:
                                    raise ValueError("Mixed types in list")
                            value = parsed_items
                elif '.' in val_str:
                    try: value = float(val_str)
                    except ValueError: raise ValueError("Invalid decimal")
                else:
                    try:
                        if re.match(r'^-?\d+$', val_str):
                            value = int(val_str)
                        else:
                            raise ValueError("Not a number")
                    except ValueError:
                        raise ValueError("Invalid value")

                current_group[name] = value
                group_keys[current_path][name] = line_num

        return data

    def dumps(self, data: dict) -> str:
        # To ensure we only dump headings that were actually in the file, 
        # and to handle nesting correctly, let's find all paths that are dictionaries.
        # However, a dictionary could be created by [a.b] even if [a] was not there.
        # The spec says "headings can be nested with dots". This means [a.b] is one heading.
        # If we have only [a.b], then data["a"] and data["a"]["b"] are both dicts.
        # Let's assume any path that leads to a dictionary in 'data' IS a heading.
        # Wait, if I do that, then `dumps(parse(dumps(x)))` might have more headings than `x`.
        # For example, if x has [a.b], dumps(x) will have [a] and [a.b]? 
        # No, the spec says "headings can be nested with dots". This means [a.b] is one heading.
        # If we want to keep it exactly the same, we need to know which headings were in the file.
        # But we don't have that information! 
        # Let's re-read: "headings can be nested with dots... names after [a.b] live in data["a"]["b"]".
        # This means 'a' and 'b' are both parts of the heading name "a.b".
        # If we have `[a.b]`, then `data` has a dict at `data["a"]`. 
        # Does this mean `a` is also a heading? Let's see.
        # If it were, then every time we saw `[a.b]`, we would also have to dump `[a]`.
        # But if the original file only had `[a.b]`, then `dumps(parse(dumps(x)))` 
        # would have `[a]` and `[a.b]`, which is different from the original!
        # Therefore, a heading must be exactly what was in the brackets.
        # But we don't know what was in the brackets!

        pass

