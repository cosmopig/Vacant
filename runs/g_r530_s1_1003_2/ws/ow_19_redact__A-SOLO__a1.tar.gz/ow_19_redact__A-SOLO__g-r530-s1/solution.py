import re

# Regex patterns for the secrets identified in the goal
# 1. AWS Access Key ID (AKIA...) - Example: AKIAIOSFODNN7EXAMPLE (18 chars)
AWS_KEY_REGEX = re.compile(r'\b[A-Z0-9]{16,20}\b')

# 2. Bearer tokens (eyJhbGciOiJIUzI1NiJ9.e30.abcdef)
# "tokens that are not made of dot-separated parts" - this means we should catch them even if they don't have dots.
BEARER_REGEX = re.compile(r'Bearer\s+[A-Za-z0-9\.\-_]+')

# 3. Connection strings (postgres://svc:hunter2@db.internal:5432/app)
# "mysql, mongodb, redis and amqp all appear in these logs, written the same way"
DB_REGEX = re.compile(r'(?:postgres|mysql|mongodb|redis|amqp)://[^:\s]+:[^@\s]+@[^\s]+:[0-9]+/[^\s]+')

def redact(text: str) -> str:
    patterns = [AWS_KEY_REGEX, BEARER_REGEX, DB_REGEX]
    matches = []
    for pattern in patterns:
        for m in pattern.finditer(text):
            matches.append((m.start(), m.end(), m.group()))
    
    # Sort matches by start position
    matches.sort()
    
    final_redactions = []
    last_end = -1
    for start, end, val in matches:
        if start >= last_end:
            final_redactions.append((start, end))
            last_end = end
            
    # Apply redactions from back to front to keep indices valid
    result = text
    for start, end in sorted(final_redactions, key=lambda x: x[0], reverse=True):
        result = result[:start] + "[REDACTED]" + result[end:]
    return result

def findings(text: str) -> list[str]:
    patterns = [AWS_KEY_REGEX, BEARER_REGEX, DB_REGEX]
    matches = []
    for pattern in patterns:
        for m in pattern.finditer(text):
            matches.append((m.start(), m.end(), m.group()))
    
    matches.sort()
    found = []
    last_end = -1
    for start, end, val in matches:
        if start >= last_end:
            found.append(val)
            last_end = end
    return found
