import unicodedata
import re

def get_width(text):
    return sum(2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1 for ch in text)

class Reflow:
    def __init__(self, width):
        if width <= 0:
            raise ValueError("Width must be positive.")
        self.width = width

    def reflow(self, text):
        lines = text.splitlines(keepends=True)
        has_trailing_newline = text.endswith('\n')
        
        output = []
        i = 0
        while i < len(lines):
            line = lines[i]
            stripped = line.strip()
            
            if not stripped:
                output.append(line)
                i += 1
                continue
            
            # Code block detection
            if stripped.startswith('```'):
                code_block = []
                while i < len(lines):
                    l = lines[i]
                    s = l.strip()
                    if s.startswith('```') and (len(code_block) == 0 or code_block[-1].strip().startswith('```')):
                        # This is the closing fence, but we need to check if it's actually a closing one
                        # In this simple logic, we assume every ``` line starts/ends a block.
                        if len(code_block) > 0:
                            code_block.append(l)
                            break
                    code_block.append(l)
                    i += 1
                output.extend(code_block)
                continue

            # Paragraph / Bullet detection
            paragraph_lines = []
            current_para_type = None # 'bullet' or 'paragraph'
            first_line_indent = ""
            marker = ""
            
            while i < len(lines):
                l = lines[i]
                s = l.strip()
                if not s: break
                
                match = re.match(r'^(\s*)([\-\*]|\d+\.)\s+(.*)', l)
                if match and current_para_type != 'bullet':
                    # New bullet paragraph starts here
                    current_para_type = 'bullet'
                    first_line_indent = match.group(1)
                    marker = match.group(2)
                    paragraph_lines.append(l)
                elif not match and current_para_type is None:
                    # New paragraph starts here
                    current_para_type = 'paragraph'
                    first_line_indent = l[:len(l) - len(l.lstrip())]
                    paragraph_lines.append(l)
                else:
                    # Continuation line
                    paragraph_lines.append(l)
                i += 1
            
            if paragraph_lines:
                output.extend(self._reflow_paragraph(paragraph_lines, current_para_type, first_line_indent, marker))

        res = "".join(output)
        if has_trailing_newline and not res.endswith('\n'):
            res += '\n'
        return res

    def _reflow_paragraph(self, lines, p_type, indent, marker):
        first_line = lines[0]
        content_parts = []
        if p_type == 'bullet':
            match = re.match(r'^(\s*)([\-\*]|\d+\.)\s+(.*)', first_line)
            content_parts.append(match.group(3))
            for l in lines[1:]:
                s = l.strip()
                if s: content_parts.append(s)
        else:
            first_line_indent = indent
            content_parts.append(first_line[len(first_line_indent):])
            for l in lines[1:]:
                s = l.strip()
                if s: content_parts.append(s)

        full_text = " ".join(content_parts)
        words = full_text.split()
        
        reflowed_lines = []
        current_line_chars = ""
        current_line_width = 0
        
        first_line_indent_w = get_width(indent)
        continuation_indent_w = get_width(indent + marker + " ") if p_type == 'bullet' else first_line_indent_w

        is_first_line = True
        for i, word in enumerate(words):
            word_chars = [(c, 2 if unicodedata.east_asian_width(c) in ("W", "F") else 1) for c in word]
            word_w = sum(w for c, w in word_chars)
            is_atom = all(w == 1 for c, w in word_chars)

            space_w = 1 if (current_line_width > 0 and i > 0) else 0
            avail_width = self.width - (first_line_indent_w if is_first_line else continuation_indent_w)

            if current_line_width + space_w + word_w <= avail_width:
                if i > 0 and current_line_width > 0:
                    current_line_chars += " "
                    current_line_width += 1
                for c, w in word_chars:
                    current_line_chars += c
                    current_line_width += w
            else:
                if not is_atom:
                    best_break = -1
                    temp_width = current_line_width + space_w
                    for j in range(len(word_chars)):
                        char_c, char_w = word_chars[j]
                        if temp_width + char_w <= avail_width:
                            temp_width += char_w
                            if j + 1 < len(word_chars):
                                next_char_c, next_char_w = word_chars[j+1]
                                if char_w == 2 or next_char_w == 2:
                                    best_break = j
                        else:
                            break
                    
                    if best_break != -1:
                        for j in range(best_break + 1):
                            current_line_chars += word_chars[j][0]
                            current_line_width += word_chars[j][1]
                        reflowed_lines.append(self._format_line(current_line_chars, is_first_line, indent, marker, p_type))
                        current_line_chars = "".join(c[0] for c in word_chars[best_break + 1:])
                        current_line_width = sum(w for c, w in [word_chars[j] for j in range(best_break + 1, len(word_chars))])
                    else:
                        if word_w > avail_width:
                            reflowed_lines.append(self._format_line("", is_first_line, indent, marker, p_type) + word)
                            current_line_chars = ""
                            current_line_width = 0
                        else:
                            if current_line_chars:
                                reflowed_lines.append(self._format_line(current_line_chars, is_first_line, indent, marker, p_type))
                            current_line_chars = word
                            current_line_width = sum(2 if unicodedata.east_asian_width(c) in ("W", "F") else 1 for c in word)
                            is_first_line = False
                else:
                    if word_w > avail_width:
                        reflowed_lines.append(self._format_line("", is_first_line, indent, marker, p_type) + word)
                        current_line_chars = ""
                        current_line_width = 0
                    else:
                        if current_line_chars:
                            reflowed_lines.append(self._format_line(current_line_chars, is_first_line, indent, marker, p_type))
                        current_line_chars = word
                        current_line_width = sum(2 if unicodedata.east_asian_width(c) in ("W", "F") else 1 for c in word)
                        is_first_line = False

        if current_line_chars:
            reflowed_lines.append(self._format_line(current_line_chars, is_first_line, indent, marker, p_type))
        
        return "\n".join(reflowed_lines)

    def _format_line(self, content, is_first_line, indent, marker, p_type):
        if is_first_line:
            prefix = indent
        else:
            if p_type == 'bullet':
                # The bullet continuation rule says "indented to the first character after the marker"
                # This means we need to include the indentation AND the marker.
                prefix = indent + marker + " "
            else:
                prefix = indent
        return prefix + content

def reflow(text, width):
    return Reflow(width).reflow(text)

