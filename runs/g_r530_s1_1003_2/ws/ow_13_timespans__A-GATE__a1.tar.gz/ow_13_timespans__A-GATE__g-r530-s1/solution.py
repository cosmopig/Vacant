from datetime import datetime, timezone

class Solution:
    def _parse_instant(self, instant_str: str) -> datetime:
        if len(instant_str) == 10 and instant_str[4] == '-':
            # YYYY-MM-DD
            dt = datetime.strptime(instant_str, "%Y-%m-%d")
            return dt.replace(tzinfo=timezone.utc)
        elif len(instant_str) >= 10 and "T" in instant_str:
            # YYYY-MM-DDTHH:MM:SS
            dt = datetime.strptime(instant_str, "%Y-%m-%dT%H:%M:%S")
            return dt.replace(tzinfo=timezone.utc)
        else:
            raise ValueError(f"Invalid instant format: {instant_str}")

    def _format_instant(self, dt: datetime) -> str:
        return dt.strftime("%Y-%m-%dT%H:%M:%S")

    def merge(self, spans: list[tuple[str, str]]) -> list[tuple[str, str]]:
        parsed = []
        for start_str, end_str in spans:
            start = self._parse_instant(start_str)
            end = self._parse_instant(end_str)
            if end < start:
                raise ValueError(f"End {end_str} is before start {start_str}")
            parsed.append((start, end))

        # Filter out zero-length spans
        parsed = [p for p in parsed if p[0] != p[1]]
        if not parsed:
            return []

        # Sort by start time
        parsed.sort()

        merged = []
        curr_start, curr_end = parsed[0]

        for i in range(1, len(parsed)):
            next_start, next_end = parsed[i]
            if next_start <= curr_end:
                curr_end = max(curr_end, next_end)
            else:
                merged.append((curr_start, curr_end))
                curr_start, curr_end = next_start, next_end
        merged.append((curr_start, curr_end))

        return [(self._format_instant(s), self._format_instant(e)) for s, e in merged]

    def subtract(self, spans: list[tuple[str, str]], holes: list[tuple[str, str]]) -> list[tuple[str, str]]:
        merged_spans = self.merge(spans)
        merged_holes = self.merge(holes)
        
        result = []
        for s_start_str, s_end_str in merged_spans:
            s_start = self._parse_instant(s_start_str)
            s_end = self._parse_instant(s_end_str)
            current_segments = [(s_start, s_end)]
            for h_start_str, h_end_str in merged_holes:
                h_start = self._parse_instant(h_start_str)
                h_end = self._parse_instant(h_end_str)
                new_segments = []
                for seg_start, seg_end in current_segments:
                    if h_start < seg_end and h_end > seg_start:
                        if h_start > seg_start:
                            new_segments.append((seg_start, h_start))
                        if h_end < seg_end:
                            new_segments.append((h_end, seg_end))
                    else:
                        new_segments.append((seg_start, seg_end))
                current_segments = new_segments
            result.extend(current_segments)

        final_spans = []
        if not result:
            return []
        
        result.sort()
        curr_start, curr_end = result[0]
        for i in range(1, len(result)):
            next_start, next_end = result[i]
            if next_start <= curr_end:
                curr_end = max(curr_end, next_end)
            else:
                final_spans.append((curr_start, curr_end))
                curr_start, curr_end = next_start, next_end
        final_spans.append((curr_start, curr_end))

        return [(self._format_instant(s), self._format_instant(e)) for s, e in final_spans if s != e]

    def total_seconds(self, spans: list[tuple[str, str]]) -> int:
        merged = self.merge(spans)
        total = 0
        for start_str, end_str in merged:
            start = self._parse_instant(start_str)
            end = self._parse_instant(end_str)
            total += (end - start).total_seconds()
        return int(total)

solution = Solution()
