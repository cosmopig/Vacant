import unicodedata
import re

def get_width(text):
    return sum(2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1 for ch in text)

class Reflow:
    def __init__(self, width):
        if width <= 0:
            raise ValueError("Width must be positive.")
        self.width = width

    def reflow(self, text: str) -> str:
        has_trailing_newline = text.endswith('\n')
        lines = text.splitlines()
        
        elements = []
        i = 0
        while i < len(lines):
            line = lines[i]
            if not line.strip():
                blank_count = 0
                while i < len(lines) and not lines[i].strip():
                    blank_count += 1
                    i += 1
                elements.append(('blank', blank_count))
            elif line.startswith('```'):
                j = i
                code_lines = []
                while j < len(lines):
                    code_lines.append(lines[j])
                    if lines[j].startswith('```') and len(code_lines) > 1:
                        break
                    j += 1
                elements.append(('code', code_lines))
                i = j
            else:
                # A paragraph is a run of consecutive non-blank lines.
                # But each bullet marker starts a new paragraph.
                j = i
                while j < len(lines):
                    curr_line = lines[j]
                    if not curr_line.strip():
                        break
                    stripped = curr_line.lstrip()
                    is_bullet = False
                    if stripped.startswith("- ") or stripped.startswith("* "):
                        is_bullet = True
                    elif re.match(r'^\d+\.\s', stripped):
                        is_bullet = True
                    
                    # If it's a bullet and not the first line of this paragraph, 
                    # then the previous lines were one paragraph.
                    if is_bullet and j > i:
                        break
                    j += 1
                
                paragraph_lines = lines[i:j]
                elements.append(('para', paragraph_lines))
                i = j

        result_lines = []
        for el in elements:
            if el[0] == 'blank':
                for _ in range(el[1]):
                    result_lines.append("")
            elif el[0] == 'code':
                result_lines.extend(el[1])
            elif el[0] == 'para':
                para_lines = el[1]
                first_line = para_lines[0]
                indent_match = re.match(r'^(\s+)', first_line)
                initial_indent = ""
                if indent_match:
                    initial_indent = indent_match.group(1)
                
                stripped_first = first_line.lstrip()
                is_bullet_para = False
                marker_len = 0
                if stripped_first.startswith("- "):
                    is_bullet_para = True
                    marker_len = 2
                elif stripped_first.startswith("* "):
                    is_bullet_para = True
                    marker_len = 2
                elif re.match(r'^(\d+\.\s)', stripped_first):
                    m = re.match(r'^(\d+\.\s)', stripped_first)
                    if m:
                        is_bullet_para = True
                        marker_len = len(m.group(1))

                # Collect all words for this paragraph, preserving the order they appear in lines.
                words = []
                for line in para_lines:
                    stripped = line.lstrip()
                    if stripped.startswith("- ") or stripped.startswith("* "):
                        content = stripped[marker_len:]
                        words.extend(content.split())
                    elif re.match(r'^\d+\.\s', stripped):
                        m = re.match(r'^(\d+\.\s)', stripped)
                        if m:
                            content = stripped[len(m.group(1)):]
                            words.extend(content.split())
                    else:
                        # For non-bullet lines, we need to be careful about the first line's content.
                        # If it's a bullet paragraph, continuation lines are indented differently.
                        if is_bullet_para:
                            # Continuation line in a bullet paragraph
                            words.extend(stripped.split())
                        else:
                            # Non-bullet paragraph
                            words.extend(stripped.split())

                current_line = ""
                for word in words:
                    word_width = get_width(word)
                    if not current_line:
                        # First word of a line (or first word of para)
                        # If it's a bullet para, its indentation is different.
                        pass

        return "" # I will rewrite this properly now.

