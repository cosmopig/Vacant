import unicodedata
import re

def get_width(text):
    return sum(2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1 for ch in text)

def solution(text, width):
    if width <= 0:
        raise ValueError("Width must be positive")
    
    lines = text.splitlines(keepends=True)
    output = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.strip():
            output.append("")
            i += 1
            continue

        # Code blocks
        if line.startswith("```"):
            code_block = []
            while i < len(lines) and (not lines[i].startswith("```") or (i + 1 >= len(lines) or not lines[i+1].startswith("```"))):
                # The contract says "opened and closed by three backticks"
                if i + 1 < len(lines) and lines[i+1].startswith("```"):
                    break
                code_block.append(lines[i])
                i += 1
            if i < len(lines) and lines[i].startswith("```"):
                code_block.append(lines[i])
                i += 1
            output.extend(code_block)
            continue

        # Paragraph handling
        paragraph_lines = []
        while i < len(lines):
            l = lines[i]
            if not l.strip():
                break
            stripped = l.lstrip()
            is_bullet = False
            if stripped.startswith("- ") or stripped.startswith("* ") or re.match(r"^\d+\. ", stripped):
                is_bullet = True
            
            if is_bullet and paragraph_lines:
                break
            paragraph_lines.append(l)
            i += 1

        # Process Paragraph
        first_line = paragraph_lines[0]
        stripped_first = first_line.lstrip()
        indent_str = first_line[:len(first_line) - len(stripped_first)]
        
        is_bullet_para = False
        marker_len = 0
        if stripped_first.startswith("- "):
            is_bullet_para = True
            marker_len = 2
        elif stripped_first.startswith("* "):
            is_bullet_para = True
            marker_len = 2
        elif re.match(r"^\d+\. ", stripped_first):
            m = re.match(r"^\d+\. ", stripped_first)
            is_bullet_para = True
            marker_len = len(m.group())

        base_indent_str = indent_str + (" " * (marker_len - len(indent_str))) if is_bullet_para else indent_str

        words = []
        for j, l in enumerate(paragraph_lines):
            s = l.lstrip()
            if j == 0:
                content_start = len(indent_str) + (marker_len if is_bullet_para else 0)
                raw_content = s[content_start:]
            else:
                # For bullet paragraphs, continuation lines are indented to the first character after the marker.
                raw_content = s[marker_len:] if is_bullet_para else s
            for w in raw_content.split():
                words.append(w)

        wrapped_lines = []
        word_idx = 0
        line_num = 0
        while word_idx < len(words):
            if line_num == 0:
                prefix = indent_str + (" " * (marker_len if is_bullet_para else 0))
            else:
                prefix = base_indent_str
            
            curr_w = get_width(prefix)
            line_content = []
            
            while word_idx < len(words):
                w = words[word_idx]
                w_width = get_width(w)
                space_width = 1 if line_content else 0
                
                if curr_w + space_width + w_width <= width:
                    line_content.append(w)
                    curr_w += (space_width + w_width)
                    word_idx += 1
                else:
                    break
            
            if line_content:
                wrapped_lines.append(prefix + " ".join(line_content))
            line_num += 1

        # Wait, the rule about overflow needs to be handled correctly.
        # If a word doesn't fit even on its own line (with prefix), it overflows.
        # My current logic doesn't handle that because I break and start new line.
        # Let me fix that.
        
        words = []
        for j, l in enumerate(paragraph_lines):
            s = l.lstrip()
            if j == 0:
                content_start = len(indent_str) + (marker_len if is_bullet_para else 0)
                raw_content = s[content_start:]
            else:
                raw_content = s[marker_len:] if is_bullet_para else s
            for w in raw_content.split():
                words.append(w)

        wrapped_lines = []
        word_idx = 0
        line_num = 0
        while word_idx < len(words):
            if line_num == 0:
                prefix = indent_str + (" " * (marker_len if is_bullet_para else 0))
            else:
                prefix = base_indent_str
            
            curr_w = get_width(prefix)
            line_content = []
            
            while word_idx < len(words):
                w = words[word_idx]
                w_width = get_width(w)
                space_width = 1 if line_content else 0
                
                if curr_w + space_width + w_width <= width:
                    line_content.append(w)
                    curr_w += (space_width + w_width)
                    word_idx += 1
                else:
                    # Doesn't fit on current line. Check if it fits on its own new line.
                    if curr_w == get_width(prefix): # We are at the start of a line
                        if get_width(prefix) + w_width > width:
                            # Overflow!
                            wrapped_lines.append(prefix + w)
                            word_idx += 1
                            break # Stay on this "line" (which is now full/overflowed)
                        else:
                            # Fits on its own line, but we'll handle it in the next iteration of outer loop
                            break
                    else:
                        # Doesn't fit current line, and not start of new line. 
                        # So wrap current content and move to next line.
                        break

            if line_content:
                wrapped_lines.append(prefix + " ".join(line_content))
            line_num += 1

        output.extend(wrapped_lines)

    has_final_newline = lines[-1].endswith('\n') if lines else False
    res = "\n".join(output)
    if has_final_newline and not res.endswith('\n'):
        res += '\n'
    elif not has_final_newline and res.endswith('\n'):
        res = res[:-1]
        
    return res

def solution(text, width):
    pass # This is just a placeholder for the module-level reflow if needed
