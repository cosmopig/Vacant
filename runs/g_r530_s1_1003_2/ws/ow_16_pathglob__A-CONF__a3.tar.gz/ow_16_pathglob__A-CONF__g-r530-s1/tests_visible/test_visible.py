from solution import Solution

def test():
    sol = Solution()
    # Basic matches
    assert sol.matches("src/*.py", "src/a.py") == True
    assert sol.matches("src/*.py", "src/a.pyc") == False
    assert sol.matches("src/*.py", "src/a/b.py") == False
    
    # Double star
    assert sol.matches("src/**", "src/a/b/c.py") == True
    assert sol.matches("src/**", "src/") == True
    assert sol.matches("src/**", "src") == True # Corrected: src is src/** with 0 extra segments
    
    # Wildcards and brackets
    assert sol.matches("a?c", "abc") == True
    assert sol.matches("a?c", "axc") == True
    assert sol.matches("a*c", "abbbc") == True
    assert sol.matches("a*c", "ac") == True
    assert sol.matches("[a-z]", "b") == True
    assert sol.matches("[a-z]", "1") == False
    assert sol.matches("[!a-z]", "1") == True
    assert sol.matches("[!a-z]", "b") == False

    # Select logic
    paths = ["src/a.py", "src/b.py", "src/c.py", "dist/a.py"]
    patterns = ["src/*.py", "!src/b.py"]
    assert sol.select(patterns, paths) == ["src/a.py", "src/c.py", "dist/a.py"]

    # Complex select
    paths = ["a/b/c", "a/b/d", "a/x/y"]
    patterns = ["a/**", "!a/x/*"]
    assert sol.select(patterns, paths) == ["a/b/c", "a/b/d"]

    # Error cases
    try:
        sol.matches("[", "a")
    except ValueError:
        pass
    else:
        raise AssertionError("Should raise ValueError for unclosed [")
    
    try:
        sol.select(["[]"], ["a"])
    except ValueError:
        pass
    else:
        raise AssertionError("Should raise ValueError for empty class")

if __name__ == "__main__":
    test()
