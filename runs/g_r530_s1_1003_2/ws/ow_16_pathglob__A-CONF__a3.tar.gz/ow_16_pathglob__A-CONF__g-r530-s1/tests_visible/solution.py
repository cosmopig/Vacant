import re

class Solution:
    def _validate_pattern(self, pattern):
        p_segs = pattern.split("/")
        for seg in p_segs:
            stack = []
            i = 0
            while i < len(seg):
                if seg[i] == "[":
                    stack.append(i)
                    i += 1
                elif seg[i] == "]":
                    if not stack: raise ValueError("Unclosed ]")
                    start = stack.pop()
                    content = seg[start+1 : i]
                    if not content:
                        raise ValueError("Empty class")
                    i += 1
                else:
                    i += 1
            if stack: raise ValueError("Unclosed [")

    def _match_segment(self, pattern_segment, path_segment):
        n, m = len(pattern_segment), len(path_segment)
        dp = [[False] * (m + 1) for _ in range(n + 1)]
        dp[0][0] = True

        for i in range(n):
            # Handle ** inside a segment? No, the rule says "A segment that is exactly **"
            char = pattern_segment[i]
            if char == "?":
                for j in range(m):
                    if dp[i][j]:
                        dp[i+1][j+1] = True
            elif char == "*":
                # Match zero or more characters
                # First, match zero:
                for j in range(m + 1):
                    if dp[i][j]:
                        dp[i+1][j] = True
                # Then, match one or more (by staying at the same i but moving j)
                # Actually, it's easier to say:
                for j in range(m + 1):
                    if dp[i+1][j]: # already true if matched zero
                        if j > 0 and dp[i+1][j-1]: # this is wrong logic for *
                            pass
                # Let's use the standard way to match *:
                for j in range(m + 1):
                    if dp[i][j]:
                        dp[i+1][j] = True # zero
                for j in range(m):
                    if dp[i+1][j] or dp[i][j+1]: # wait, this is also not quite right.
                        pass
                # Correct way for *:
                # dp[i+1][j] is true if we can match pattern_segment[:i+1] with path_segment[:j]
                # This is true if:
                # 1. We matched pattern_segment[:i] with path_segment[:j] and current char is * (match zero)
                # 2. We matched pattern_segment[:i+1] with path_segment[:j-1] and current char is * (match one or more)
                # So:
                # dp[i+1][0] = dp[i][0]
                # for j in range(1, m + 1):
                #     dp[i+1][j] = dp[i][j] or dp[i+1][j-1]
                pass # I'll just rewrite the loop for * below.
            elif char == "[":
                # Find end of bracket
                k = i + 1
                start_neg = False
                if k < n and pattern_segment[k] == "!":
                    start_neg = True
                    k += 1
                while k < n and pattern_segment[k] != "]":
                    k += 1
                if k >= n: raise ValueError("Unclosed [")
                end_idx = k
                bracket_content = pattern_segment[i+1 : end_idx]
                if not bracket_content and not start_neg: raise ValueError("Empty class")
                
                chars = set()
                k2 = 0
                while k2 < len(bracket_content):
                    c = bracket_content[k2]
                    if c == "-":
                        if k2 + 1 < len(bracket_content):
                            start_char = bracket_content[k2]
                            end_char = bracket_content[k2+1]
                            for val in range(ord(start_char), ord(end_char) + 1):
                                chars.add(chr(val))
                            k2 += 2
                        else:
                            chars.add("-")
                            k2 += 1
                    else:
                        chars.add(c)
                        k2 += 1
                
                for j in range(m):
                    if dp[i][j]:
                        current_char = path_segment[j]
                        is_in_set = current_char in chars
                        if start_neg:
                            if not is_in_set:
                                dp[end_idx + 1][j+1] = True
                        else:
                            if is_in_set:
                                dp[end_idx + 1][j+1] = True
            else:
                for j in range(m):
                    if dp[i][j] and char == path_segment[j]:
                        dp[i+1][j+1] = True

        # Re-do the * logic properly inside the loop:
        # Let's just use a simpler DP for each character.
        # I will rewrite the whole thing to be cleaner.
        return False # Placeholder, I'll rewrite it now.

