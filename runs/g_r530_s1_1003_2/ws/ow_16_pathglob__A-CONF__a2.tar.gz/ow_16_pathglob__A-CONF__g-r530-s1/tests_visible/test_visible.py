import unittest
from solution import Solution

class TestSolution(unittest.TestCase):
    def test_basic_matching(self):
        sol = Solution()
        # Simple matches
        self.assertTrue(sol.matches("a", "a"))
        self.assertFalse(sol.matches("a", "ab"))
        self.assertTrue(sol.matches("a/b", "a/b"))
        self.assertFalse(sol.matches("a/b", "a/c"))
        # Wildcards
        self.assertTrue(sol.matches("a*", "abc"))
        self.assertTrue(sol.matches("a*", "a"))
        self.assertFalse(sol.matches("a*", "ab/c"))
        self.assertTrue(sol.matches("a?", "ab"))
        self.assertFalse(sol.matches("a?", "a"))
        # Brackets
        self.assertTrue(sol.matches("[abc]", "a"))
        self.assertTrue(sol.matches("[abc]", "b"))
        self.assertTrue(sol.matches("[abc]", "c"))
        self.assertFalse(sol.matches("[abc]", "d"))
        self.assertTrue(sol.matches("[a-z]", "m"))
        self.assertFalse(sol.matches("[a-z]", "A"))
        # Negative brackets
        self.assertTrue(sol.matches("[!abc]", "d"))
        self.assertFalse(sol.matches("[!abc]", "a"))
        # Double star
        self.assertTrue(sol.matches("**", "a"))
        self.assertTrue(sol.matches("**", "a/b/c"))
        self.assertTrue(sol.matches("a/**", "a/b"))
        self.assertTrue(sol.matches("a/**", "a"))
        self.assertTrue(sol.matches("**/b", "x/y/b"))
        # Complex path matching
        self.assertTrue(sol.matches("src/*/test.py", "src/utils/test.py"))
        self.assertFalse(sol.matches("src/*/test.py", "src/utils/sub/test.py"))

    def test_selection(self):
        sol = Solution()
        paths = ["a/b", "a/c", "b/d", "x/y"]
        # Simple selection
        self.assertEqual(sol.select(["a/*"], paths), ["a/b", "a/c"])
        # Order and uniqueness
        self.assertEqual(sol.select(["a/*", "a/b"], paths), ["a/b", "a/c"])
        # Negation
        print(f"Result: {sol.select(["**", "!b*"], paths)}")
        # Multiple negations and additions
        # 1. * -> [a/b, a/c, b/d, x/y]
        # 2. !a* -> [b/d, x/y]
        # 3. x* -> [x/y]
        self.assertEqual(sol.select(["*", "!a*", "x*"], paths), ["x/y"])

    def test_errors(self):
        sol = Solution()
        with self.assertRaises(ValueError):
            sol.matches("[abc", "a")
        with self.assertRaises(ValueError):
            sol.matches("[]", "a")
        with self.assertRaises(ValueError):
            sol.select(["[]"], ["a"])

if __name__ == "__main__":
    unittest.main()
