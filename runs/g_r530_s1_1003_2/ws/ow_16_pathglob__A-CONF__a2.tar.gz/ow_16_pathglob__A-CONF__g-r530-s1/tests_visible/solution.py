import re

class Solution:
    def _get_regex_for_segment(self, segment):
        if segment == "**":
            return "DOUBLE_STAR"
        
        res = ""
        i = 0
        while i < len(segment):
            c = segment[i]
            if c == "?":
                res += "."
            elif c == "*":
                res += ".*"
            elif c == "[":
                j = i + 1
                neg = False
                if j < len(segment) and segment[j] == "!":
                    neg = True
                    j += 1
                
                allowed_chars = set()
                k = j
                has_content = False
                while k < len(segment) and segment[k] != "]":
                    if k + 2 < len(segment) and segment[k+1] == "-" and segment[k+2] != "]":
                        start_char = segment[k]
                        end_char = segment[k+2]
                        for char_code in range(ord(start_char), ord(end_char) + 1):
                            allowed_chars.add(chr(char_code))
                        k += 3
                    else:
                        allowed_chars.add(segment[k])
                        k += 1
                    has_content = True
                if k >= len(segment):
                    raise ValueError("Unclosed [")
                if not has_content:
                    raise ValueError("Empty class")
                
                inner = ""
                for char in sorted(list(allowed_chars)):
                    inner += re.escape(char)
                
                if neg:
                    res += f"[^{inner}]"
                else:
                    res += f"[{inner}]"
                i = k + 1
            else:
                res += re.escape(c)
            i += 1
        return res

    def _validate_pattern(self, pattern):
        segments = pattern.split('/')
        for s in segments:
            if s == "**": continue
            i = 0
            while i < len(s):
                if s[i] == "[":
                    j = i + 1
                    neg = False
                    if j < len(s) and s[j] == "!":
                        neg = True
                        j += 1
                    k = j
                    while k < len(s) and s[k] != "]":
                        k += 1
                    if k >= len(s):
                        raise ValueError("Unclosed [")
                    if k == j:
                        raise ValueError("Empty class")
                    i = k + 1
                else:
                    i += 1

    def matches(self, pattern: str, path: str) -> bool:
        self._validate_pattern(pattern)
        p_segments = pattern.split('/')
        path_segments = path.split('/')
        
        regexes = []
        for s in p_segments:
            if s == "**":
                regexes.append("DOUBLE_STAR")
            else:
                regexes.append(self._get_regex_for_segment(s))

        memo = {}

        def match_recursive(p_idx, path_idx):
            state = (p_idx, path_idx)
            if state in memo: return memo[state]
            
            if p_idx == len(p_segments):
                return path_idx == len(path_segments)
            
            seg_type = regexes[p_idx]
            
            if seg_type == "DOUBLE_STAR":
                for skip in range(len(path_segments) - path_idx + 1):
                    if match_recursive(p_idx + 1, path_idx + skip):
                        memo[state] = True
                        return True
                memo[state] = False
                return False
            else:
                if path_idx >= len(path_segments):
                    memo[state] = False
                    return False
                # Match current segment
                if re.fullmatch(regexes[p_idx], path_segments[path_idx]):
                    res = match_recursive(p_idx + 1, path_idx + 1)
                    memo[state] = res
                    return res
                else:
                    memo[state] = False
                    return False

        return match_recursive(0, 0)

    def select(self, patterns: list[str], paths: list[str]) -> list[str]:
        for p in patterns:
            self._validate_pattern(p)
        
        is_selected = [False] * len(paths)
        
        # The contract says "A plain pattern adds every path that matches it; 
        # a pattern beginning with ! removes every path picked up so far that matches the rest of the pattern."
        for p in patterns:
            if p.startswith("!"):
                sub_pattern = p[1:]
                # "removes every path picked up so far that matches the rest of the pattern"
                for i, path in enumerate(paths):
                    if is_selected[i] and self.matches(sub_pattern, path):
                        is_selected[i] = False
            else:
                # "adds every path that matches it"
                for i, path in enumerate(paths):
                    if not is_selected[i] and self.matches(p, path):
                        is_selected[i] = True
        
        return [paths[i] for i, selected in enumerate(is_selected) if selected]

