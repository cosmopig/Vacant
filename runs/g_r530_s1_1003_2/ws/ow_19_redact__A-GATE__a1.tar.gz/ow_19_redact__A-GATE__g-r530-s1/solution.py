import re

# 1. AWS Keys: AKIA followed by 16 alphanumeric characters
AWS_KEY_RE = re.compile(r'\bAKIA[A-Z0-9]{16}\b')

# 2. Bearer Tokens: "Bearer " followed by a base64-like string (including dots)
BEARER_RE = re.compile(r'(Bearer\s+)([a-zA-Z0-9._\-\+\/\=\.\w]+)')

# 3. Connection Strings: [proto]://[user]:[pass]@[host]:[port]/[db]
CONN_RE = re.compile(r'\b([a-zA-Z0-9]+://)[^:\s]+:[^@\s]+@[^/\s]+(?::\d+)?(/.*)?')

def redact(text: str) -> str:
    matches = []
    for m in AWS_KEY_RE.finditer(text):
        matches.append((m.span(0), m.group(0)))
    for m in BEARER_RE.finditer(text):
        # We want to redact the token part (group 2) but keep "Bearer "?
        # The prompt says: "none of the secret text is anywhere in the result"
        # and "everything in the line that is not a secret comes back exactly as it was".
        # If "Bearer " is NOT part of the secret, we should keep it.
        matches.append((m.span(1), m.group(2)))

    for m in CONN_RE.finditer(text):
        matches.append((m.span(0), m.group(0)))

    # Sort by start index descending to replace from back to front
    matches.sort(key=lambda x: x[0][0], reverse=True)
    
    result = text
    for start, val in matches:
        if val == "[REDACTED]":
            continue
        # Check if the secret is still there (not already redacted)
        # This handles "running the pass on a line that has already been through it changes nothing"
        # because [REDACTED] won't match any of our regexes.
        result = result[:start[0]] + "[REDACTED]" + result[start[1]:]

    return result

def findings(text: str) -> list[str]:
    if not text.strip():
        return []
    secrets = []
    for m in AWS_KEY_RE.finditer(text):
        secrets.append(m.group(0))
    for m in BEARER_RE.finditer(text):
        secrets.append(m.group(2))
    for m in CONN_RE.finditer(text):
        secrets.append(m.group(0))
    return secrets
