from datetime import datetime, timedelta

def parse_instant(instant_str: str) -> datetime:
    if len(instant_str) == 10 and instant_str[4] == '-':
        # YYYY-MM-DD
        return datetime.strptime(instant_str, "%Y-%m-%d")
    elif "T" in instant_str:
        # YYYY-MM-DDTHH:MM:SS
        return datetime.strptime(instant_str, "%Y-%m-%dT%H:%M:%S")
    else:
        raise ValueError(f"Invalid instant format: {instant_str}")

def validate_span(start_str: str, end_str: str):
    start = parse_instant(start_str)
    end = parse_instant(end_str)
    if end < start:
        raise ValueError(f"End ({end_str}) is before start ({start_str})")
    return start, end

def merge(spans: list[tuple[str, str]]) -> list[tuple[str, str]]:
    parsed_spans = []
    for s, e in spans:
        s_dt, e_dt = validate_span(s, e)
        if s_dt != e_dt:
            parsed_spans.append((s_dt, e_dt))
    
    if not parsed_spans:
        return []
    
    # Sort by start time
    parsed_spans.sort()
    
    merged = []
    curr_start, curr_end = parsed_spans[0]
    
    for i in range(1, len(parsed_spans)):
        next_start, next_end = parsed_spans[i]
        if next_start <= curr_end:
            curr_end = max(curr_end, next_end)
        else:
            merged.append((curr_start, curr_end))
            curr_start, curr_end = next_start, next_end
    
    merged.append((curr_start, curr_end))
    
    return [(s.strftime("%Y-%m-%dT%H:%M:%S"), e.strftime("%Y-%m-%dT%H:%M:%S")) for s, e in merged]

def subtract(spans: list[tuple[str, str]], holes: list[tuple[str, str]]) -> list[tuple[str, str]]:
    merged_spans = merge(spans)
    
    parsed_holes = []
    for h_s, h_e in holes:
        h_s_dt, h_e_dt = validate_span(h_s, h_e)
        if h_s_dt != h_e_dt:
            parsed_holes.append((h_s_dt, h_e_dt))
    
    if not parsed_holes:
        return merged_spans

    parsed_holes.sort()
    merged_holes = []
    curr_h_start, curr_h_end = parsed_holes[0]
    for i in range(1, len(parsed_holes)):
        next_h_start, next_h_end = parsed_holes[i]
        if next_h_start <= curr_h_end:
            curr_h_end = max(curr_h_end, next_h_end)
        else:
            merged_holes.append((curr_h_start, curr_h_end))
            curr_h_start, curr_h_end = next_h_start, next_h_end
    merged_holes.append((curr_h_start, curr_h_end))

    result = []
    for s_str, e_str in merged_spans:
        s_dt = parse_instant(s_str)
        e_dt = parse_instant(e_str)
        current_segments = [(s_dt, e_dt)]
        for h_start, h_end in merged_holes:
            new_segments = []
            for seg_start, seg_end in current_segments:
                if h_end <= seg_start or h_start >= seg_end:
                    new_segments.append((seg_start, seg_end))
                else:
                    if h_start > seg_start:
                        new_segments.append((seg_start, h_start))
                    if h_end < seg_end:
                        new_segments.append((h_end, seg_end))
            current_segments = new_segments
        result.extend(current_segments)
    
    final_spans = []
    for s, e in result:
        if s != e:
            final_spans.append((s, e))
    
    if not final_spans:
        return []
    
    final_spans.sort()
    merged_final = []
    curr_start, curr_end = final_spans[0]
    for i in range(1, len(final_spans)):
        next_start, next_end = final_spans[i]
        if next_start <= curr_end:
            curr_end = max(curr_end, next_end)
        else:
            merged_final.append((curr_start, curr_end))
            curr_start, curr_end = next_start, next_end
    merged_final.append((curr_start, curr_end))
    
    return [(s.strftime("%Y-%m-%dT%H:%M:%S"), e.strftime("%Y-%m-%dT%H:%M:%S")) for s, e in merged_final]

def total_seconds(spans: list[tuple[str, str]]) -> int:
    merged = merge(spans)
    total = 0
    for s, e in merged:
        s_dt = parse_instant(s)
        e_dt = parse_instant(e)
        total += (e_dt - s_dt).total_seconds()
    return int(total)

# Instantiate the solution object for use by tests
class Solution:
    def merge(self, spans: list[tuple[str, str]]) -> list[tuple[str, str]]:
        return merge(spans)
    def subtract(self, spans: list[tuple[str, str]], holes: list[tuple[str, str]]) -> list[tuple[str, str]]:
        return subtract(spans, holes)
    def total_seconds(self, spans: list[tuple[str, str]]) -> int:
        return total_seconds(spans)

solution = Solution()
