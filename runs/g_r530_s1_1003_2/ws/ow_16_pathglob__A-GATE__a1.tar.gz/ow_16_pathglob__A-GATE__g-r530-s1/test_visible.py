import unittest
from solution import Solution

class TestSolution(unittest.TestCase):
    def setUp(self):
        self.sol = Solution()

    def test_basic_matching(self):
        self.assertTrue(self.sol.matches("a", "a"))
        self.assertFalse(self.sol.matches("a", "ab"))
        self.assertTrue(self.sol.matches("a/b", "a/b"))
        self.assertFalse(self.sol.matches("a/b", "a/c"))

    def test_wildcards(self):
        self.assertTrue(self.sol.matches("*", "abc"))
        self.assertTrue(self.sol.matches("*", ""))
        self.assertFalse(self.sol.matches("*", "a/b"))
        self.assertTrue(self.sol.matches("?", "a"))
        self.assertFalse(self.sol.matches("?", ""))
        self.assertFalse(self.sol.matches("?", "ab"))

    def test_brackets(self):
        self.assertTrue(self.sol.matches("[abc]", "a"))
        self.assertTrue(self.sol.matches("[abc]", "b"))
        self.assertTrue(self.sol.matches("[abc]", "c"))
        self.assertFalse(self.sol.matches("[abc]", "d"))
        self.assertTrue(self.sol.matches("[a-z]", "m"))
        self.assertFalse(self.sol.matches("[a-z]", "A"))
        self.assertTrue(self.sol.matches("[!abc]", "d"))
        self.assertFalse(self.sol.matches("[!abc]", "a"))

    def test_double_star(self):
        # ** matches zero or more segments
        self.assertTrue(self.sol.matches("**", ""))
        self.assertTrue(self.sol.matches("**", "a"))
        self.assertTrue(self.sol.matches("**", "a/b"))
        self.assertTrue(self.sol.matches("a/**", "a/b/c"))
        self.assertTrue(self.sol.matches("a/**", "a"))
        self.assertTrue(self.sol.matches("**/a", "b/c/a"))
        self.assertFalse(self.sol.matches("*/*", "a")) # * matches no /

    def test_select(self):
        paths = ["a/b", "a/c", "b/c", "d"]
        patterns = ["a/*", "!a/c"]
        # a/* picks up a/b, a/c
        # !a/c removes a/c
        # result: [a/b]
        self.assertEqual(self.sol.select(patterns, paths), ["a/b"])

    def test_errors(self):
        with self.assertRaises(ValueError):
            self.sol.matches("[abc", "a")
        with self.assertRaises(ValueError):
            self.sol.matches("[]", "a")

if __name__ == "__main__":
    unittest.main()
