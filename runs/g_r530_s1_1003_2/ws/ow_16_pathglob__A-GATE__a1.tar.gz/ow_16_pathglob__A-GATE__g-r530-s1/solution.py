import re

class Solution:
    def matches(self, pattern: str, path: str) -> bool:
        pattern_segments = pattern.split('/')
        path_segments = path.split('/')
        
        def get_allowed_chars(content):
            negate = False
            if content.startswith('!'):
                negate = True
                content = content[1:]
            
            allowed = set()
            k = 0
            while k < len(content):
                if k + 2 < len(content) and content[k+1] == '-':
                    start = ord(content[k])
                    end = ord(content[k+2])
                    for char_code in range(start, end + 1):
                        allowed.add(chr(char_code))
                    k += 3
                else:
                    allowed.add(content[k])
                    k += 1
            return allowed, negate

        def match_segment_v3(p_seg, s_seg):
            if p_seg == "**": return True
            
            regex_parts = []
            k = 0
            while k < len(p_seg):
                c = p_seg[k]
                if c == '?':
                    regex_parts.append('.')
                    k += 1
                elif c == '*':
                    regex_parts.append('.*')
                    k += 1
                elif c == '[':
                    j = k + 1
                    while j < len(p_seg) and p_seg[j] != ']':
                        j += 1
                    if j >= len(p_seg): raise ValueError("Unclosed bracket")
                    content = p_seg[k+1:j]
                    if not content: raise ValueError("Empty class")
                    allowed, negate = get_allowed_chars(content)
                    
                    chars_in_set = []
                    m2 = 0
                    while m2 < len(content):
                        if m2 + 2 < len(content) and content[m2+1] == '-':
                            for char_code in range(ord(content[m2]), ord(content[m2+2]) + 1):
                                chars_in_set.append(chr(char_code))
                            m2 += 3
                        else:
                            chars_in_set.append(content[m2])
                            m2 += 1
                    
                    if negate:
                        regex_parts.append("".join([f"(?!{re.escape(c)})" for c in chars_in_set]) + ".")
                    else:
                        chars_in_set = sorted(list(set(chars_in_set)))
                        regex_parts.append(f"[{''.join(re.escape(c) for c in chars_in_set)}]")
                    k = j + 1
                else:
                    regex_parts.append(re.escape(c))
                    k += 1
            return bool(re.fullmatch("".join(regex_parts), s_seg))

        memo = {}
        def solve(i, j):
            if (i, j) in memo: return memo[(i, j)]
            if i == len(pattern_segments):
                return j == len(path_segments)
            
            res = False
            p = pattern_segments[i]
            if p == "**":
                # ** matches zero segments
                if solve(i + 1, j):
                    res = True
                # ** matches one or more segments
                elif j < len(path_segments):
                    if solve(i, j + 1):
                        res = True
            else:
                if j < len(path_segments) and match_segment_v3(p, path_segments[j]):
                    res = solve(i + 1, j + 1)
            
            memo[(i, j)] = res
            return res

        for seg in pattern_segments:
            if seg == "**": continue
            bracket_count = 0
            for i, char in enumerate(seg):
                if char == '[':
                    bracket_count += 1
                elif char == ']':
                    bracket_count -= 1
            if bracket_count > 0: raise ValueError("Unclosed bracket")
            
            for i in range(len(seg)):
                if seg[i] == '[':
                    j = i + 1
                    while j < len(seg) and seg[j] != ']':
                        j += 1
                    if j == i + 1 or j >= len(seg): # Empty class [] or unclosed [
                        raise ValueError("Empty class")
                    break

        return solve(0, 0)

    def select(self, patterns: list[str], paths: list[str]) -> list[str]:
        for p in patterns:
            try:
                self.matches(p, "")
            except ValueError:
                raise ValueError()

        current_selection = [False] * len(paths)
        for p in patterns:
            is_negation = p.startswith('!')
            actual_pattern = p[1:] if is_negation else p
            for j, path in enumerate(paths):
                if self.matches(actual_pattern, path):
                    if is_negation:
                        current_selection[j] = False
                    else:
                        current_selection[j] = True
        
        return [paths[i] for i, selected in enumerate(current_selection) if selected]

# Module-level functions to satisfy the test runner's expectations
def matches(pattern: str, path: str) -> bool:
    return Solution().matches(pattern, path)

def select(patterns: list[str], paths: list[str]) -> list[str]:
    return Solution().select(patterns, paths)
