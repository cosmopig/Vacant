from solution import Solution

def test():
    sol = Solution()
    
    # Test basic matching
    assert sol.matches("src/*.py", "src/main.py") == True
    assert sol.matches("src/*.py", "src/main.pyc") == False
    assert sol.matches("src/*.py", "src/sub/main.py") == False
    
    # Test ** matching
    assert sol.matches("src/**", "src/main.py") == True
    assert sol.matches("src/**", "src/sub/main.py") == True
    assert sol.matches("src/**", "src/") == True
    assert sol.matches("src/**", "src/a/b/c/d.py") == True
    
    # Test ? and * inside segments
    assert sol.matches("file_?.txt", "file_1.txt") == True
    assert sol.matches("file_?.txt", "file_12.txt") == False
    assert sol.matches("a*b", "acb") == True
    assert sol.matches("a*b", "ab") == True
    assert sol.matches("a*b", "axxb") == True
    
    # Test [abc] and ranges
    assert sol.matches("[abc]", "a") == True
    assert sol.matches("[abc]", "b") == True
    assert sol.matches("[abc]", "c") == True
    assert sol.matches("[abc]", "d") == False
    assert sol.matches("[a-z]", "m") == True
    assert sol.matches("[0-9]", "5") == True
    assert sol.matches("[!abc]", "d") == True
    assert sol.matches("[!abc]", "a") == False
    
    # Test complex segments
    assert sol.matches("src/[a-z]*.py", "src/main.py") == True
    assert sol.matches("src/[a-z]*.py", "src/123.py") == False
    
    # Test select
    paths = ["src/main.py", "src/utils.py", "tests/test_main.py", "docs/readme.md"]
    patterns = ["src/*", "!src/utils.py"]
    assert sol.select(patterns, paths) == ["src/main.py"]

    # Test select with multiple patterns and order
    paths2 = ["a/b", "a/c", "x/y"]
    patterns2 = ["a/*", "!a/b", "x/*"]
    assert sol.select(patterns2, paths2) == ["a/c", "x/y"]

    # Test select with **
    paths3 = ["a/b/c", "a/d", "e/f"]
    patterns3 = ["a/**", "!a/b/c"]
    assert sol.select(patterns3, paths3) == ["a/d"]

    print("All tests passed!")

if __name__ == "__main__":
    test()
