import re

class Solution:
    def matches(self, pattern: str, path: str) -> bool:
        pattern_segments = pattern.split('/')
        path_segments = path.split('/')
        
        # Pre-validate all patterns for the select method (will be called by select)
        self._validate_patterns(pattern_segments)

        memo = {}

        def solve(p_idx, s_idx):
            state = (p_idx, s_idx)
            if state in memo:
                return memo[state]
            
            # If we reached the end of both pattern and path segments
            if p_idx == len(pattern_segments) and s_idx == len(path_segments):
                return True
            
            # If we reached the end of pattern but not path
            if p_idx == len(pattern_segments):
                return False
            
            p_seg = pattern_segments[p_idx]
            
            # Handle ** segment
            if p_seg == '**':
                # ** can match zero or more segments. 
                res = solve(p_idx + 1, s_idx) # Match zero segments
                if not res and s_idx < len(path_segments):
                    res = solve(p_idx, s_idx + 1) # Match one segment and stay on **
                memo[state] = res
                return res
            
            # If path is exhausted but pattern isn't (and it's not **)
            if s_idx == len(path_segments):
                return False

            match_seg = self._match_segment(p_seg, path_segments[s_idx])
            if match_seg:
                res = solve(p_idx + 1, s_idx + 1)
                memo[state] = res
                return res
            else:
                memo[state] = False
                return False

        return solve(0, 0)

    def _validate_patterns(self, segments):
        for seg in segments:
            open_brackets = 0
            for char in seg:
                if char == '[':
                    open_brackets += 1
                elif char == ']':
                    open_brackets -= 1
            if open_brackets > 0:
                raise ValueError("Unclosed [")

    def _match_segment(self, p_seg: str, s_seg: str) -> bool:
        regex_parts = []
        i = 0
        while i < len(p_seg):
            if p_seg[i] == '*':
                regex_parts.append('.*')
                i += 1
            elif p_seg[i] == '?':
                regex_parts.append('.')
                i += 1
            elif p_seg[i] == '[':
                end = p_seg.find(']', i)
                if end == -1:
                    raise ValueError("Unclosed [")
                content = p_seg[i+1:end]
                if content == "":
                    raise ValueError("Empty class")
                
                negate = False
                if content.startswith('!'):
                    negate = True
                    content = content[1:]
                
                allowed = set()
                j = 0
                while j < len(content):
                    if content[j] == '-' and j + 1 < len(content):
                        for char_code in range(ord(content[j]), ord(content[j+1]) + 1):
                            allowed.add(chr(char_code))
                        j += 2
                    else:
                        allowed.add(content[j])
                        j += 1
                
                escaped_allowed = []
                for char in sorted(list(allowed)):
                    if char == ']': escaped_allowed.append('\\]')
                    elif char == '-': escaped_allowed.append('\\-')
                    else: escaped_allowed.append(re.escape(char))
                
                chars_str = "".join(escaped_allowed)
                if negate:
                    regex_parts.append(f"[^{chars_str}]")
                else:
                    regex_parts.append(f"[{chars_str}]")
                i = end + 1
            else:
                regex_parts.append(re.escape(p_seg[i]))
                i += 1
        return bool(re.fullmatch("".join(regex_parts), s_seg))

    def select(self, patterns: list[str], paths: list[str]) -> list[str]:
        for p in patterns:
            p_segments = p.split('/')
            self._validate_patterns(p_segments)
            
        current_selected = [False] * len(paths)
        for p in patterns:
            if p.startswith('!'):
                sub_pattern = p[1:]
                for i in range(len(paths)):
                    if current_selected[i]:
                        if self.matches(sub_pattern, paths[i]):
                            current_selected[i] = False
            else:
                for i in range(len(paths)):
                    if not current_selected[i]:
                        if self.matches(p, paths[i]):
                            current_selected[i] = True
        
        return [paths[i] for i in range(len(paths)) if current_selected[i]]

