from typing import Callable, Dict, List
import collections

class RateLimiter:
    def __init__(self, window_s: float, max_events: int, clock: Callable[[], float]):
        if window_s <= 0 or max_events < 0:
            raise ValueError("window_s must be > 0 and max_events must be >= 0")
        
        self.window_s = window_s
        self.max_events = max_events
        self.clock = clock
        # Map of key -> deque of timestamps (floats)
        self.history: Dict[str, collections.deque] = {}

    def allow(self, key: str) -> bool:
        now = self.clock()
        valid_events = []
        if key in self.history:
            for ts in self.history[key]:
                if (now - self.window_s) < ts <= now:
                    valid_events.append(ts)
        
        if len(valid_events) < self.max_events:
            # Record the event
            if key not in self.history:
                self.history[key] = collections.deque()
            self.history[key].append(now)
            return True
        else:
            return False

    def retry_after(self, key: str) -> float:
        now = self.clock()
        if self.max_events == 0:
            return float("inf")
        
        if key not in self.history or not self.history[key]:
            return 0.0
        
        valid_ts = [ts for ts in self.history[key] if (now - self.window_s) < ts <= now]
        if len(valid_ts) < self.max_events:
            return 0.0
        else:
            # The earliest counted event that has to fall out of the window
            # is the smallest 'ts' among those currently in (now - window_s, now].
            # It falls out when its timestamp ts satisfies ts <= now - window_s.
            # This happens at time T = ts + window_s.
            return min(valid_ts) + self.window_s - now

    def reset(self, key: str | None = None) -> None:
        if key is None:
            self.history.clear()
        elif key in self.history:
            del self.history[key]

