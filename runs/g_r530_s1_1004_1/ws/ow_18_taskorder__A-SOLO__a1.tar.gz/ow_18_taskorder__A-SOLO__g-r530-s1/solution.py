def plan(jobs: dict[str, list[str]]) -> list[str]:
    # Collect all unique job names
    all_jobs = set(jobs.keys())
    for deps in jobs.values():
        for dep in deps:
            all_jobs.add(dep)

    # Build adjacency list and in-degree count
    # adj[u] contains jobs that depend on u
    adj = {job: [] for job in all_jobs}
    in_degree = {job: 0 for job in all_jobs}

    for job, deps in jobs.items():
        for dep in deps:
            adj[dep].append(job)
            in_degree[job] += 1

    # Kahn's algorithm for topological sort
    # To ensure deterministic output, we use a sorted list of "ready" nodes
    # or just sort the keys/nodes consistently.
    queue = [job for job in all_jobs if in_degree[job] == 0]
    queue.sort()  # Deterministic order

    result = []
    while queue:
        u = queue.pop(0)
        result.append(u)

        for v in adj[u]:
            in_degree[v] -= 1
            if in_degree[v] == 0:
                # Insert into sorted list to maintain deterministic order
                # Or just re-sort the queue if it's small, but pop(0) + sort is fine.
                queue.append(v)
                queue.sort()

    if len(result) != len(all_jobs):
        raise ValueError("Cycle detected or unreachable jobs")

    return result
