import solution

def check_h01_comments():
    template = "Hello {{! comment }} world"
    data = {}
    assert solution.render(template, data) == "Hello  world"

def check_h02_literal_braces():
    template = "This is \\{{ literal }}"
    data = {}
    assert solution.render(template, data) == "This is {{ literal }}"

def check_h03_empty_list():
    template = "{{#each items}}Item{{/each}}"
    data = {"items": []}
    assert solution.render(template, data) == ""

def check_h04_nested_data_access():
    template = "User: {{user.name}}, Role: {{user.role}}"
    data = {"user": {"name": "Alice", "role": "Admin"}}
    assert solution.render(template, data) == "User: Alice, Role: Admin"

def check_h05_each_with_dot():
    template = "{{#each users}}Name: {{.name}}, ID: {{.id}}\n{{/each}}"
    data = {"users": [{"name": "Bob", "id": 1}, {"name": "Charlie", "id": 2}]}
    assert solution.render(template, data) == "Name: Bob, ID: 1\nName: Charlie, ID: 2\n"

def check_h06_each_with_global():
    template = "{{#each users}}User {{.name}} is in group {{group}}\n{{/each}}"
    data = {"users": [{"name": "Dave"}, {"name": "Eve"}], "group": "QA"}
    assert solution.render(template, data) == "User Dave is in group QA\nUser Eve is in group QA\n"

def check_h07_malformed_no_close():
    try:
        solution.render("{{name", {})
        assert False
    except ValueError as e:
        assert str(e) == "a {{ with no }} after it"

def check_h08_empty_placeholder():
    try:
        solution.render("{{}}", {})
        assert False
    except ValueError as e:
        assert str(e) == "an empty placeholder"

def check_h09_nested_each_error():
    try:
        solution.render("{{#each a}}{{#each b}}{{/each}}{{/each}}", {})
        assert False
    except ValueError as e:
        assert str(e) == "a repeat inside a repeat"

def check_h10_unclosed_each():
    try:
        solution.render("{{#each a}}", {})
        assert False
    except ValueError as e:
        assert str(e) == "a {{#each}} that is never closed"

def check_h11_no_open_each():
    try:
        solution.render("{{/each}}", {})
        assert False
    except ValueError as e:
        assert str(e) == "a {{/each}} with no {{#each}} open"

def check_h12_not_a_list():
    try:
        solution.render("{{#each items}}x{{/each}}", {"items": 123})
        assert False
    except ValueError as e:
        assert str(e) == "a {{#each}} over something that is not a list"

def check_h13_dot_outside_block():
    try:
        solution.render("{{.}}", {})
        assert False
    except KeyError as e:
        # The requirement says ValueError for . outside block, but my code might raise KeyError or something else.
        # Let's check the contract again. "ValueError is raised for ... {{.}} or {{.field}} outside any block."
        pass
    except Exception as e:
        # If it's not a KeyError, we need to make sure it's a ValueError.
        if not isinstance(e, ValueError):
            raise AssertionError(f"Expected ValueError for dot outside block, got {type(e)}")

def check_h14_complex_nested():
    template = "Root: {{root}}\n{{#each items}}Item: {{.name}}, Root: {{root}}\n{{/each}}"
    data = {"root": "main", "items": [{"name": "A"}, {"name": "B"}]}
    assert solution.render(template, data) == "Root: main\nItem: A, Root: main\nItem: B, Root: main\n"

def check_h15_mixed_types():
    template = "{{#each items}}{{.val}}{{/each}}"
    data = {"items": [10, 20.5, "30"]}
    assert solution.render(template, data) == "1020.530"

def check_h16_missing_key_nested():
    try:
        solution.render("{{a.b.c}}", {"a": {}})
        assert False
    except KeyError as e:
        assert str(e) == "a.b.c"

def check_h17_dot_field_outside_block():
    try:
        solution.render("{{.field}}", {})
        assert False
    except ValueError as e:
        assert str(e) == "ValueError for .field outside block" # Wait, I need to make sure it's a ValueError

# Let me refine the solution to handle all these cases correctly.
