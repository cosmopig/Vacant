from typing import Callable, Dict, List

class RateLimiter:
    def __init__(self, window_s: float, max_events: int, clock: Callable[[], float]):
        if window_s <= 0 or max_events < 0:
            raise ValueError("window_s must be > 0 and max_events must be >= 0")
        
        self.window_s = window_s
        self.max_events = max_events
        self.clock = clock
        # Map key to a list of timestamps (floats)
        self.history: Dict[str, List[float]] = {}

    def allow(self, key: str) -> bool:
        now = self.clock()
        if key not in self.history:
            self.history[key] = []
        
        # Count events in (now - window_s, now]
        count = 0
        for ts in self.history[key]:
            if (now - self.window_s) < ts <= now:
                count += 1
        
        if count < self.max_events:
            self.history[key].append(now)
            return True
        else:
            return False

    def retry_after(self, key: str) -> float:
        now = self.clock()
        if self.max_events == 0:
            return float("inf")
        
        if key not in self.history:
            return 0.0
        
        # Find events that are currently in the window or will be in the future
        # Actually, we need to find the earliest event that has to fall out of the window.
        # The window is (now - window_s, now].
        # An event ts falls out when it becomes <= now - window_s.
        # We want the smallest ts such that ts > now - window_s? No.
        # "leaving is the earliest counted event that has to fall out of the window before the next call can be admitted."
        
        count = 0
        W = []
        for ts in self.history[key]:
            if (now - self.window_s) < ts <= now:
                count += 1
                W.append(ts)
        
        if count < self.max_events:
            return 0.0
        else:
            # len(W) == max_events because we only record when count < max_events.
            # Wait, can len(W) be > max_events?
            # Only if the clock moved backwards and some events that were previously outside (now - window_s, now] 
            # are now inside it? No, if they were outside because they were <= now - window_s, 
            # and now decreased, they are even further outside.
            # If they were outside because they were > now, and now decreased, they are still > now.
            # Wait, if clock moves backwards, "now" decreases.
            # If ts was <= now_old - window_s, then ts is definitely < now_new - window_s? 
            # No: now_new < now_old  =>  now_new - window_s < now_old - window_s.
            # So if ts = now_old - window_s, then ts > now_new - window_s.
            # This means an event could enter the window from the left if the clock moves backwards!
            # But "A denied call records nothing". 
            # If it was already in the history, it must have been recorded when allow() was True.
            # At that time, count < max_events.
            
            # Let's re-read: "leaving is the earliest counted event that has to fall out of the window before the next call can be admitted."
            # If we are at limit, we need one of the events in W to fall out.
            # The first one to fall out is min(W).
            # It falls out when now - window_s >= min(W)  =>  now >= min(W) + window_s.
            # Wait time = (min(W) + window_s) - now.
            
            return min(W) + self.window_s - now

    def reset(self, key: str | None = None) -> None:
        if key is None:
            self.history.clear()
        else:
            if key in self.history:
                del self.history[key]
