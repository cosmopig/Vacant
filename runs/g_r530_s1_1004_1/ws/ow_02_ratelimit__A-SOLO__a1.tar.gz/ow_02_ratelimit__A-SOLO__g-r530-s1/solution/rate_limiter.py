from typing import Callable, Dict, List

class RateLimiter:
    def __init__(self, window_s: float, max_events: int, clock: Callable[[], float]):
        if window_s <= 0 or max_events < 0:
            raise ValueError("window_s must be > 0 and max_events must be >= 0")
        
        self.window_s = window_s
        self.max_events = max_events
        self.clock = clock
        # Map key to list of timestamps (floats)
        self.history: Dict[str, List[float]] = {}

    def allow(self, key: str) -> bool:
        now = self.clock()
        if key not in self.history:
            self.history[key] = []
        
        # Filter out events that are no longer in the window (now - window_s, now]
        # The condition is event > (now - window_s) and event <= now
        # Actually, "an event counts while it falls in (now - window_s, now]"
        # This means we keep events where:
        # 1. event > now - window_s
        # 2. event <= now
        
        self.history[key] = [e for e in self.history[key] if (now - self.window_s) < e <= now]
        
        if len(self.history[key]) < self.max_events:
            self.history[key].append(now)
            return True
        else:
            return False

    def retry_after(self, key: str) -> float:
        now = self.clock()
        if key not in self.history or len(self.history[key]) < self.max_events:
            return 0.0
        
        if self.max_events == 0:
            return float("inf")
            
        # "Otherwise it returns leaving + window_s - now, where leaving is the earliest counted event that has to fall out of the window before the next call can be admitted."
        # The events are in history[key]. They are sorted by time because we append 'now' each time allow() succeeds.
        # Wait, they might not be perfectly sorted if clock moves backwards? 
        # "A clock that moves backwards is not an error: events lying in the future are simply outside (now - window_s, now]"
        # If clock moves backwards, 'now' decreases. The filter `(now - self.window_s) < e <= now` will remove some events.
        
        # Let's re-examine "leaving": 
        # It is the earliest counted event that has to fall out of the window before the next call can be admitted.
        # To admit a new call, we need history[key] to have fewer than max_events elements.
        # If it currently has max_events (or more), we need some events to fall out.
        # The ones that fall out are those where e <= now - window_s.
        # The "earliest" one that *has* to fall out is the smallest e such that e <= now - window_s.
        # Wait, if there are multiple such e, which one? 
        # Actually, any event e <= now - window_s is already "out". 
        # The next call can be admitted when an event falls out of the current window.
        # If we have max_events events in (now - window_s, now], then to admit one more, 
        # we need the oldest one in that set to fall out.
        # But if it's already in the window, it won't fall out until time passes.
        # The earliest event that *will* fall out is the smallest e such that e > now - window_s.
        # No, that's not right. 
        # Let's re-read: "leaving is the earliest counted event that has to fall out of the window before the next call can be admitted."
        # If we have max_events events in (now - window_s, now], and we want to admit one more,
        # we need one of those events to leave. The one that will leave first is the smallest e in history[key].
        # Let's check: if history[key] = [10, 12, 14] and window_s = 5 and now = 15.
        # Window is (10, 15]. Events in window are 12, 14. count=2. max_events=2.
        # To admit one more, we need an event to fall out of (now - window_s, now] = (10, 15].
        # The events currently in the window are {12, 14}.
        # They will fall out when time > 12 + 5 = 17 and time > 14 + 5 = 19.
        # Wait, "leaving" is the earliest counted event that has to fall out of the window.
        # If history[key] = [10, 12, 14], then at now=15, the events in (10, 15] are {12, 14}.
        # The one that will leave first is 12. It falls out when time > 12 + window_s = 17? No.
        # "an event counts while it falls in (now - window_s, now]"
        # So at time T, an event e counts if T - window_s < e <= T.
        # This is equivalent to: e <= T < e + window_s.
        # Wait, no. Let's re-read carefully.
        # "an event counts while it falls in (now - window_s, now]"
        # At time `now`, an event `e` counts if `now - window_s < e <= now`.
        # So for a fixed `e`, it counts during the time interval `(e, e + window_s]`.
        # Wait, that's not right. Let's re-read again.
        # "an event counts while it falls in (now - window_s, now]"
        # If I have an event at `e`, and the current time is `now`:
        # It counts if `now - window_s < e` AND `e <= now`.
        # So for a fixed `e`, it counts when `now` is in the interval `[e, e + window_s)`.
        # Wait. If `now = e`, then `now - window_s = e - window_s`. 
        # Is `e - window_s < e <= e`? Yes (if `window_s > 0`). So it counts at `now = e`.
        # As `now` increases from `e`, it continues to count as long as `now - window_s < e`, i.e., `now < e + window_s`.
        # At `now = e + window_s`, the condition `now - window_s < e` becomes `e + window_s - window_s < e`, which is `e < e`, False.
        # So it counts for `now` in `[e, e + window_s)`.
        # Wait, the requirement says "left open and right closed" for `(now - window_s, now]`.
        # This means:
        # `now - window_s < e` (left open)
        # `e <= now` (right closed)
        # So at time `now`, the events that count are those in the range `(now - window_s, now]`.
        # For a fixed event `e`, it counts when `now` is such that:
        # 1. `now - window_s < e`  => `now < e + window_s`
        # 2. `e <= now`              => `now >= e`
        # So an event `e` counts for `now` in the interval `[e, e + window_s)`.
        # Wait, this is exactly what I just wrote. Let me re-verify.
        # If `now = e`, then `now - window_s < e` is `e - window_s < e`, which is true for `window_s > 0`.
        # And `e <= now` is `e <= e`, which is true. So it counts at `now = e`.
        # If `now = e + window_s`, then `now - window_s < e` is `e < e`, which is false.
        # So it stops counting at `now = e + window_s`.
        # Thus, an event `e` counts for `now \in [e, e + window_s)`.

        # Now let's re-read "retry_after":
        # "Otherwise it returns leaving + window_s - now, where leaving is the earliest counted event that has to fall out of the window before the next call can be admitted."
        # If we have `max_events` events in history[key] that are currently counting.
        # These are the events `e` such that `now \in [e, e + window_s)`.
        # To admit one more, we need one of these to stop counting.
        # An event `e` stops counting when `now >= e + window_s`.
        # The earliest it will stop counting is at `now = e + window_s`.
        # So "leaving" is the smallest `e` among those that are currently counting.
        # Wait, if we have multiple events in history[key], some might already be out of the window.
        # We should only consider those that ARE currently counting.
        # But wait, if an event is NOT currently counting because it's too old (`now >= e + window_s`), 
        # then it has ALREADY fallen out!
        # If we have `max_events` events in the current window `(now - window_s, now]`,
        # we need one of them to fall out. The one that will fall out first is the smallest `e`.
        # Wait, if it's already fallen out, then there are fewer than `max_events` counting!
        # So "retry_after" only returns > 0 when there are AT LEAST `max_events` events in the window.
        # If there are exactly `max_events` events in the window, they are all in `(now - window_s, now]`.
        # The one that will fall out first is the smallest `e` in history[key].
        # It falls out when `now >= e + window_s`. 
        # So the time to wait is `(e + window_s) - now`.
        # Let's check: "leaving + window_s - now". If leaving is `e`, then it's `e + window_s - now`.
        # This matches!

        # Wait, there's a catch. What if an event `e` is in the future? 
        # "A clock that moves backwards is not an error: events lying in the future are simply outside (now - window_s, now]".
        # If `e > now`, it's not counting.
        # So we only care about `e` such that `now - window_s < e <= now`.
        # Among these, the smallest `e` is "leaving".

        # Let's re-verify:
        # history[key] contains all events ever recorded for this key.
        # At any `now`, we first filter it to only include `e` such that `now - window_s < e <= now`.
        # If the count of these is >= max_events, then retry_after > 0.
        # The "leaving" event is the smallest `e` in this filtered set.
        # Wait, if we have more than `max_events`, which one is "leaving"?
        # "the earliest counted event that has to fall out of the window before the next call can be admitted."
        # If we have 5 events and max_events=3, then as soon as ONE falls out, we can admit.
        # The one that falls out first is the smallest `e`.
        # So "leaving" is indeed the minimum `e` in the filtered set.

        # Wait, I should be careful about how I filter history[key]. 
        # If I filter it in-place in `allow`, does it affect `retry_after`?
        # The requirement says: "A denied call records nothing".
        # And `reset(key)` forgets the events of that key.
        # It doesn't say anything about `retry_after` modifying history.
        # However, if I filter in-place in `allow`, then `history[key]` only contains events that were counted at some point.
        # But an event might be "out" now but "in" later if the clock moves backwards!
        # "A clock that moves backwards is not an error: events lying in the future are simply outside (now - window_s, now]"
        # If I remove it from `history[key]` because it's too old, and then the clock moves back, 
        # it won't be there anymore. This seems wrong.
        # So I should probably not filter in-place unless I have to.
        # But if I don't filter in-place, `history[key]` will grow indefinitely.
        # The requirement doesn't say anything about memory limits.

        # Let's re-read: "The window slides: an event counts while it falls in (now - window_s, now]".
        # This means at any given time `now`, we look at all events ever recorded and see which ones satisfy the condition.
        # If I don't filter in-place, then for each `allow` or `retry_after` call, 
        # I should compute the set of counting events.

        counting = [e for e in self.history[key] if (now - self.window_s) < e <= now]
        if len(counting) < self.max_events:
            return 0.0
        
        if self.max_events == 0:
            return float("inf")

        leaving = min(counting)
        return leaving + self.window_s - now

    def reset(self, key: str | None = None) -> None:
        if key is None:
            self.history.clear()
        else:
            if key in self.history:
                del self.history[key]
