from typing import Dict, List

def plan(jobs: Dict[str, List[str]]) -> List[str]:
    # 1. Identify all unique job names
    all_job_names = set(jobs.keys())
    for deps in jobs.values():
        for dep in deps:
            all_job_names.add(dep)
    
    # 2. Build adjacency list and in-degree count
    # We want to represent dependencies as "A -> B" where A must finish before B starts.
    # The input is "B depends on [A]".
    adj = {name: [] for name in all_job_names}
    in_degree = {name: 0 for name in all_job_names}
    
    for job, deps in jobs.items():
        for dep in deps:
            # dep must finish before job starts
            adj[dep].append(job)
            in_degree[job] += 1
            
    # 3. Kahn's algorithm for topological sort
    # To ensure deterministic output, we use a sorted list of available jobs.
    queue = [name for name in all_job_names if in_degree[name] == 0]
    queue.sort()
    
    result = []
    while queue:
        # Always pick the lexicographically smallest job to ensure deterministic output
        current = queue.pop(0)
        result.append(current)
        
        for neighbor in adj[current]:
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                # Insert into sorted list or re-sort
                queue.append(neighbor)
                queue.sort()
                
    if len(result) != len(all_job_names):
        raise ValueError("Cycle detected or unreachable job")
        
    return result

