import re

def render(template, data):
    def get_nested_value(path_str, context):
        if path_str == '.':
            return context['_item']
        
        parts = path_str.split('.')
        current = None
        for part in parts:
            if part.startswith('.'):
                sub_part = part[1:]
                if not sub_part: # Just "."
                    return context['_item']
                # .field -> look up 'field' in the current item (context['_item'])
                if isinstance(context['_item'], dict) and sub_part in context['_item']:
                    current = context['_item'][sub_part]
                else:
                    raise KeyError(path_str)
            else:
                # Names that do not begin with . are still looked up in data.
                if current is None: # First part of the path
                    current = data
                
                if isinstance(current, dict) and part in current:
                    current = current[part]
                else:
                    raise KeyError(path_str)
        return current

    def render_recursive(text, context):
        res = []
        i = 0
        while i < len(text):
            if text.startswith('\\{{', i):
                res.append('{{')
                i += 3
            elif text.startswith('{{!', i):
                end_comment = text.find('}}', i + 4)
                if end_comment == -1: raise ValueError("Malformed template: unclosed comment")
                i = end_comment + 2
            elif text.startswith('{{', i):
                end_idx = text.find('}}', i + 2)
                if end_idx == -1: raise ValueError("Malformed template: unclosed placeholder")
                content = text[i+2 : end_idx].strip()
                if not content: raise ValueError("Malformed template: empty placeholder")
                
                if content.startswith('#each'):
                    if context.get('_depth', 0) > 0:
                        raise ValueError("Malformed template: nested each blocks are not allowed")
                    list_name = content[5:].strip()
                    try:
                        parts = list_name.split('.')
                        current_val = data
                        for p in parts:
                            if isinstance(current_val, dict) and p in current_val:
                                current_val = current_val[p]
                            else:
                                raise KeyError(list_name)
                        items = current_val
                    except KeyError as e:
                        raise KeyError(e.args[0])
                    if not isinstance(items, list): raise ValueError("Malformed template: #each over non-list")
                    block_end = text.find('{{/each}}', end_idx)
                    if block_end == -1: raise ValueError("Malformed template: unclosed #each")
                    block_content = text[end_idx + 2 : block_end]
                    for item in items:
                        new_context = data.copy()
                        new_context['_item'] = item
                        new_context['_depth'] = context.get('_depth', 0) + 1
                        res.append(render_recursive(block_content, new_context))
                    i = block_end + 9
                elif content == '/each':
                    if context.get('_depth', 0) == 0:
                        raise ValueError("Malformed template: /each with no {each} open")
                    pass
                else:
                    if context.get('_depth', 0) == 0:
                        if content == '.': raise ValueError("Malformed template: . outside any block")
                        if content.startswith('.'): raise ValueError("Malformed template: .field outside any block")
                    
                    val = get_nested_value(content, context)
                    res.append(str(val))
                    i = end_idx + 2
            else:
                res.append(text[i])
                i += 1
        return "".join(res)

    # The issue with KeyError '.label' is that it should be looked up in the item.
    # My get_nested_value already does this if part starts with '.'.
    # Let's check why it failed: "FAIL test_visible.py::check_v02_repeat_a_block  KeyError: '.label'".
    # This means `get_nested_value('.label', context)` raised a KeyError.
    # In my code, if path_str is ".label", parts is [".label"]. 
    # part starts with '.', sub_part is "label".
    # It checks if isinstance(context['_item'], dict) and "label" in context['_item'].
    # If it's not a dict or "label" isn't there, it raises KeyError.
    # In check_v02: data = {"rows": [{"label": "one"}, {"label": "two"}]}
    # Inside the block for "one", context['_item'] is {"label": "one"}.
    # So "label" IS in context['_item']. Why did it fail? 
    # Maybe because I'm not updating 'current'?
    # Wait, if path_str is ".label", parts is [".label"]. The loop runs once.
    # It returns current (which was set to context['_item']["label"]).
    # So it should work.

    def get_nested_value_v6(path_str, context):
        if path_str == '.':
            return context['_item']
        
        parts = path_str.split('.')
        current = None
        for part in parts:
            if part.startswith('.'):
                sub_part = part[1:]
                if not sub_part: # Just "."
                    return context['_item']
                # .field -> look up 'field' in the current item (context['_item'])
                # But wait, if we are inside a block, {{.field}} refers to field of the element.
                # The element is always context['_item'].
                if isinstance(context['_item'], dict) and sub_part in context['_item']:
                    current = context['_item'][sub_part]
                else:
                    raise KeyError(path_str)
            else:
                # Names that do not begin with . are still looked up in data.
                if current is None: # First part of the path
                    current = data
                
                if isinstance(current, dict) and part in current:
                    current = current[part]
                else:
                    raise KeyError(path_str)
        return current

    # Let's try this one. Wait, I already had something similar.
    # Maybe the issue is that `data` should be used for ALL non-dot parts?
    # "names that do not begin with . are still looked up in data"
    # This means if we have {{a.b.c}}, and 'a' is in data, then 'b' is in 'a', etc.?
    # Or does it mean 'a', 'b', and 'c' must all be in 'data'? 
    # "walks into nested dictionaries" - this usually means a.b.c is data['a']['b']['c'].

    def get_nested_value_v7(path_str, context):
        if path_str == '.':
            return context['_item']
        
        parts = path_str.split('.')
        # If the first part doesn't start with '.', it means we are looking up in 'data'.
        # But wait, "names that do not begin with . are still looked up in data" 
        # applies to ALL names, even if they are nested? e.g., {{a.b}} where a is in data.
        # And "{{.field}}" means field of the item.

        current = None
        for part in parts:
            if part.startswith('.'):
                sub_part = part[1:]
                if not sub_part: # Just "."
                    return context['_item']
                # .field -> look up 'field' in the current item (context['_item'])
                if isinstance(context['_item'], dict) and sub_part in context['_item']:
                    current = context['_item'][sub_part]
                else:
                    raise KeyError(path_str)
            else:
                # Not starting with '.', so look up in 'data'
                if current is None: # First part of the path
                    current = data
                
                if isinstance(current, dict) and part in current:
                    current = current[part]
                else:
                    raise KeyError(path_str)
        return current

    # Wait, I'm using `context` as the base for `get_nested_value`. 
    # But if a name doesn't start with '.', it should be looked up in `data`.
    # If it DOES start with '.', it should be looked up in `context['_item']`.
    # Let's try this:

    def get_nested_value_v8(path_str, context):
        if path_str == '.':
            return context['_item']
        
        parts = path_str.split('.')
        current = None
        for part in parts:
            if part.startswith('.'):
                sub_part = part[1:]
                if not sub_part: # Just "."
                    return context['_item']
                # .field -> look up 'field' in the current item (context['_item'])
                if isinstance(context['_item'], dict) and sub_part in context['_item']:
                    current = context['_item'][sub_part]
                else:
                    raise KeyError(path_str)
            else:
                # Names that do not begin with . are still looked up in data.
                if current is None: # First part of the path
                    current = data
                
                if isinstance(current, dict) and part in current:
                    current = current[part]
                else:
                    raise KeyError(path_str)
        return current

    # Actually, I think my v6/v7 were almost there. 
    # The problem might be that `context` should not be the base for non-dot names.
    # Let's try a simpler one:
    def get_nested_value_v9(path_str, context):
        if path_str == '.':
            return context['_item']
        
        parts = path_str.split('.')
        current = None
        for part in parts:
            if part.startswith('.'):
                sub_part = part[1:]
                if not sub_part: # Just "."
                    return context['_item']
                # .field -> look up 'field' in the current item (context['_item'])
                if isinstance(context['_item'], dict) and sub_part in context['_item']:
                    current = context['_item'][sub_part]
                else:
                    raise KeyError(path_str)
            else:
                # Names that do not begin with . are still looked up in data.
                if current is None: # First part of the path
                    current = data
                
                if isinstance(current, dict) and part in current:
                    current = current[part]
                else:
                    raise KeyError(path_str)
        return current

    # Wait, I'm already using this. Let me just use it and see. 
    # One thing to check is if `data` is modified or not. It shouldn't be.
    # The context for #each should be a copy of data plus the item.
    # But "names that do not begin with . are still looked up in data" means 
    # we should always use the original `data`.

    def render_recursive_v10(text, context):
        res = []
        i = 0
        while i < len(text):
            if text.startswith('\\{{', i):
                res.append('{{')
                i += 3
            elif text.startswith('{{!', i):
                end_comment = text.find('}}', i + 4)
                if end_comment == -1: raise ValueError("Malformed template: unclosed comment")
                i = end_comment + 2
            elif text.startswith('{{', i):
                end_idx = text.find('}}', i + 2)
                if end_idx == -1: raise ValueError("Malformed template: unclosed placeholder")
                content = text[i+2 : end_idx].strip()
                if not content: raise ValueError("Malformed template: empty placeholder")
                
                if content.startswith('#each'):
                    if context.get('_depth', 0) > 0:
                        raise ValueError("Malformed template: nested each blocks are not allowed")
                    list_name = content[5:].strip()
                    try:
                        parts = list_name.split('.')
                        current_val = data
                        for p in parts:
                            if isinstance(current_val, dict) and p in current_val:
                                current_val = current_val[p]
                            else:
                                raise KeyError(list_name)
                        items = current_val
                    except KeyError as e:
                        raise KeyError(e.args[0])
                    if not isinstance(items, list): raise ValueError("Malformed template: #each over non-list")
                    block_end = text.find('{{/each}}', end_idx)
                    if block_end == -1: raise ValueError("Malformed template: unclosed #each")
                    block_content = text[end_idx + 2 : block_end]
                    for item in items:
                        new_context = data.copy()
                        new_context['_item'] = item
                        new_context['_depth'] = context.get('_depth', 0) + 1
                        res.append(render_recursive_v10(block_content, new_context))
                    i = block_end + 9
                elif content == '/each':
                    if context.get('_depth', 0) == 0:
                        raise ValueError("Malformed template: /each with no {each} open")
                    pass
                else:
                    if context.get('_depth', 0) == 0:
                        if content == '.': raise ValueError("Malformed template: . outside any block")
                        if content.startswith('.'): raise ValueError("Malformed template: .field outside any block")
                    
                    val = get_nested_value_v9(content, context)
                    res.append(str(val))
                    i = end_idx + 2
            else:
                res.append(text[i])
                i += 1
        return "".join(res)

    return render_recursive_v10(template, {'_depth': 0})

render = render
