def plan(jobs: dict[str, list[str]]) -> list[str]:
    # Identify all unique job names involved in the input
    all_job_names = set(jobs.keys())
    for deps in jobs.values():
        for dep in deps:
            all_job_names.add(dep)

    # Build an adjacency list for the graph and calculate in-degrees
    # The goal is to find a topological sort of this graph.
    # A job depends on its prerequisites, so there's an edge from prerequisite to job.
    adj = {name: [] for name in all_job_names}
    in_degree = {name: 0 for name in all_job_names}

    for job, deps in jobs.items():
        for dep in deps:
            # Edge is from dep to job (dep must finish before job)
            adj[dep].append(job)
            in_degree[job] += 1

    # Kahn's algorithm for topological sort
    # To ensure deterministic output, we use a sorted list of available jobs.
    queue = [name for name in all_job_names if in_degree[name] == 0]
    queue.sort()
    
    result = []
    while queue:
        # Always pick the lexicographically smallest job to ensure deterministic output
        u = queue.pop(0)
        result.append(u)
        
        for v in adj[u]:
            in_degree[v] -= 1
            if in_degree[v] == 0:
                queue.append(v)
                queue.sort()

    # If result doesn't contain all jobs, there was a cycle
    if len(result) != len(all_job_names):
        raise ValueError("Cycle detected or impossible dependencies.")

    return result

