class Router:
    def __init__(self):
        # List of (parsed_segments, name)
        self.routes = []

    def add(self, pattern: str, name: str) -> None:
        if not pattern.startswith('/'):
            raise ValueError("Pattern must begin with /")

        parts = pattern.split('/')
        # parts[0] is empty because pattern starts with /
        segments = parts[1:]
        
        parsed_segments = []
        for i, seg in enumerate(segments):
            if not seg: # Handle double slashes or trailing slash? 
                # The contract says "split on /". If path is "//", segments are ["", ""].
                # But it also says "{name} ... never matches an empty segment."
                parsed_segments.append(('literal', ""))
                continue

            if seg.startswith('{') and seg.endswith('}'):
                inner = seg[1:-1]
                if not inner:
                    raise ValueError("Empty parameter name")
                
                if inner.endswith('*:'):
                    param_name = inner[:-2]
                    if param_name == "":
                        raise ValueError("Empty parameter name")
                    if i != len(segments) - 1:
                        raise ValueError("{name:*} must be the last segment")
                    parsed_segments.append(('wildcard', param_name))
                else:
                    param_name = inner
                    # Check if it contains * but not at end of name part (not allowed by {name} rule)
                    if '*' in param_name:
                         raise ValueError("Invalid parameter")
                    parsed_segments.append(('param', param_name))
            elif seg.startswith('{'):
                raise ValueError("Unmatched brace")
            else:
                parsed_segments.append(('literal', seg))

        # Check for duplicate pattern (ignoring parameter names)
        for prev_segments, _ in self.routes:
            is_same = True
            if len(prev_segments) != len(parsed_segments):
                is_same = False
            else:
                for p1, s1 in zip(prev_segments, parsed_segments):
                    type1, val1 = p1
                    type2, val2 = s1
                    if type1 != type2:
                        is_same = False
                        break
            if is_same:
                raise ValueError("Duplicate pattern")

        self.routes.append((parsed_segments, name))

    def match(self, path: str) -> tuple[str, dict[str, str]] | None:
        path_parts = path.split('/')
        # path always begins with / so path_parts[0] is empty
        path_segments = path_parts[1:]
        
        best_match = None # (route_segments, name, params)

        for route_segments, name in self.routes:
            current_params = {}
            is_match = True
            
            # Check if it matches
            for i, (type, val) in enumerate(route_segments):
                if type == 'literal':
                    if i >= len(path_segments) or path_segments[i] != val:
                        is_match = False
                        break
                elif type == 'param':
                    if i >= len(path_segments) or path_segments[i] == "":
                        is_match = False
                        break
                    current_params[val] = path_segments[i]
                elif type == 'wildcard':
                    # Wildcard must be the last segment of route_segments
                    remaining_path = "/".join(path_segments[i:])
                    if not remaining_path: # {name:*} must not be empty
                        is_match = False
                        break
                    current_params[val] = remaining_path
                    # The wildcard matches everything else, so we are done with this route.
                    break
            else:
                # If we finished the loop without breaking, it means all segments matched.
                # But if there are more path segments left, and no wildcard was used...
                if len(path_segments) > len(route_segments):
                    is_match = False

            if is_match:
                if best_match is None:
                    best_match = (route_segments, name, current_params)
                else:
                    prev_segments, _, _ = best_match
                    
                    # Rank the segments literal > param > wildcard
                    # Compare segment by segment from left
                    winner = None # 0 for first, 1 for second, 2 for tie
                    for s1, s2 in zip(route_segments, prev_segments):
                        type1, val1 = s1
                        type2, val2 = s2
                        if type1 != type2:
                            # Rank: literal (0), param (1), wildcard (2)
                            rank = {'literal': 0, 'param': 1, 'wildcard': 2}
                            if rank[type1] < rank[type2]:
                                winner = 0
                            else:
                                winner = 1
                            break
                    
                    if winner is None: # All segments so far are same type
                        if len(route_segments) > len(prev_segments):
                            winner = 0
                        elif len(route_segments) < len(prev_segments):
                            winner = 1
                        else:
                            winner = 2 # Tie

                    if winner == 0:
                        best_match = (route_segments, name, current_params)
                    # If winner is 1 or 2, best_match stays the same.

        if best_match:
            return (best_match[1], best_match[2])
        return None
