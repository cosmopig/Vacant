import re

def render(template, data):
    # 1. Tokenize the template into TEXT, LITERAL (\{{), and TAG ({{...}})
    tokens = []
    i = 0
    while i < len(template):
        if template[i:i+3] == r'\{{':
            tokens.append(('LITERAL', '{{'))
            i += 3
        elif template[i:i+2] == '{{':
            end = template.find('}}', i)
            if end == -1:
                raise ValueError("Malformed template: unclosed placeholder")
            content = template[i+2:end].strip()
            tokens.append(('TAG', content))
            i = end + 2
        else:
            next_idx = -1
            for j in range(i, len(template)):
                if template[j:j+2] == '{{':
                    next_idx = j
                    break
                if template[j:j+3] == r'\{{':
                    next_idx = j
                    break
            if next_idx == -1:
                tokens.append(('TEXT', template[i:]))
                i = len(template)
            else:
                tokens.append(('TEXT', template[i:next_idx]))
                i = next_idx

    # 2. Validate and parse the structure to handle nested each, closing tags, etc.
    def validate_and_parse(token_list):
        stack = []
        for idx, (t_type, t_val) in enumerate(token_list):
            if t_type == 'TAG':
                if t_val.startswith('#each'):
                    stack.append(idx)
                elif t_val == '/each':
                    if not stack:
                        raise ValueError("Closing repeat with nothing to close")
                    stack.pop()
        
        if stack:
            raise ValueError("Unclosed each")
        return True

    validate_and_parse(tokens)

    # 3. Recursive rendering
    def render_recursive(token_list, current_data, root_data, in_block=False):
        output = []
        idx = 0
        while idx < len(token_list):
            t_type, t_val = token_list[idx]
            if t_type == 'TEXT':
                output.append(t_val)
                idx += 1
            elif t_type == 'LITERAL':
                output.append(t_val)
                idx += 1
            elif t_type == 'TAG':
                if t_val.startswith('#each'):
                    list_name = t_val[6:].strip()
                    if list_name == '.':
                        items = current_data if isinstance(current_data, list) else None
                    else:
                        items = root_data.get(list_name) if isinstance(root_data, dict) else None
                    
                    if not isinstance(items, list):
                        raise ValueError("Repeat over non-list")
                    
                    depth = 1
                    j = idx + 1
                    while j < len(token_list) and depth > 0:
                        sub_t_type, sub_t_val = token_list[j]
                        if sub_t_type == 'TAG':
                            if sub_t_val.startswith('#each'):
                                depth += 1
                            elif sub_t_val == '/each':
                                depth -= 1
                            if depth == 0: break
                        j += 1
                    
                    for k in range(idx + 1, j):
                        if token_list[k][0] == 'TAG' and token_list[k][1].startswith('#each'):
                            raise ValueError("Repeat inside repeat")

                    block_tokens = token_list[idx+1 : j]
                    for item in items:
                        output.append(render_recursive(block_tokens, item, root_data, True))
                    idx = j
                elif t_val == '/each':
                    # Skip closing tags during rendering as they are handled by the recursion/depth logic
                    idx += 1
                elif t_val == '.':
                    if not in_block:
                        raise ValueError("{{.}} or {{.field}} outside any block")
                    output.append(str(current_data))
                    idx += 1
                else:
                    if t_val.startswith('.'):
                        if not in_block:
                            raise ValueError("{{.}} or {{.field}} outside any block")
                        base = current_data
                        path_parts = t_val[1:].split('.')
                        curr = base
                        for p in path_parts:
                            if not p: continue
                            if isinstance(curr, dict) and p in curr:
                                curr = curr[p]
                            elif isinstance(curr, list) and p.isdigit():
                                curr = curr[int(p)]
                            else:
                                raise KeyError(t_val)
                        output.append(str(curr))
                    else:
                        base = root_data
                        path_parts = t_val.split('.')
                        curr = base
                        for p in path_parts:
                            if not p: continue
                            if isinstance(curr, dict) and p in curr:
                                curr = curr[p]
                            elif isinstance(curr, list) and p.isdigit():
                                curr = curr[int(p)]
                            else:
                                raise KeyError(t_val)
                        output.append(str(curr))
                    idx += 1
            else:
                idx += 1
        return "".join(output)

    for t_type, t_val in tokens:
        if t_type == 'TAG' and not t_val:
            raise ValueError("Empty placeholder")

    return render_recursive(tokens, None, data, False)
