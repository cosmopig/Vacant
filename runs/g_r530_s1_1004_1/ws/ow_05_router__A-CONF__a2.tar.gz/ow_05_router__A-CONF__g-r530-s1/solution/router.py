import re

class Router:
    def __init__(self):
        self.routes = []

    def add(self, pattern: str, name: str) -> None:
        if not pattern.startswith('/'):
            raise ValueError("Pattern must begin with /")

        # Split path into segments, but handle the leading slash correctly
        # "/a/b" -> ["", "a", "b"] if we use split('/') on a string starting with /
        # But the contract says "read as segments split on /". 
        # Let's assume it means splitting the part after the first /.
        path_content = pattern[1:]
        if path_content == "":
            segments = [""]
        else:
            segments = path_content.split('/')

        parsed_segments = []
        for i, seg in enumerate(segments):
            if not seg:
                # This handles cases like "//" or trailing "/"
                # The contract says "A segment is one of three things: a literal, {name}, or {name:*}."
                # If it's empty, it must be a literal.
                parsed_segments.append(('literal', seg))
                continue

            if seg.startswith('{') and seg.endswith('}'):
                content = seg[1:-1]
                if content == '':
                    raise ValueError("Empty parameter name")
                
                if content.endswith(':*'):
                    param_name = content[:-2]
                    if not param_name:
                        raise ValueError("Empty parameter name")
                    if i != len(segments) - 1:
                        raise ValueError("{name:*} must be the last segment")
                    parsed_segments.append(('wildcard', param_name))
                else:
                    # Check if it's {name} or something else with braces
                    parsed_segments.append(('param', content))
            elif '{' in seg or '}' in seg:
                raise ValueError("Unmatched brace")
            else:
                parsed_segments.append(('literal', seg))

        # Re-verify unmatched braces for all segments
        for seg in segments:
            if '{' in seg or '}' in seg:
                if not (seg.startswith('{') and seg.endswith('}')):
                    raise ValueError("Unmatched brace")

        # Check for duplicates based on structure
        normalized_structure = []
        for i, (type_idx, content) in enumerate(parsed_segments):
            if type_idx == 'literal':
                normalized_structure.append(('literal', content))
            elif type_idx == 'param':
                normalized_structure.append(('param', None))
            elif type_idx == 'wildcard':
                normalized_structure.append(('wildcard', None))

        for r in self.routes:
            if r['structure'] == tuple(normalized_structure):
                raise ValueError("Duplicate pattern")

        self.routes.append({
            'pattern': pattern,
            'name': name,
            'segments': parsed_segments,
            'structure': tuple(normalized_structure)
        })

    def match(self, path: str) -> tuple[str, dict[str, str]] | None:
        # Path always begins with /
        path_content = path[1:]
        if path_content == "":
            path_segments = [""]
        else:
            path_segments = path_content.split('/')

        best_match = None
        max_specificity = (-1, -1) # (list of scores, length)

        for route in self.routes:
            route_segments = route['segments']
            current_params = {}
            match_possible = True
            
            i = 0
            # A path can match a route if it has the same number of segments
            # OR if the last segment is {name:*}.
            
            # Let's try to match.
            for j, (type_idx, content) in enumerate(route_segments):
                if i >= len(path_segments):
                    match_possible = False
                    break
                
                if type_idx == 'literal':
                    if path_segments[i] != content:
                        match_possible = False
                        break
                    i += 1
                elif type_idx == 'param':
                    if path_segments[i] == '':
                        match_possible = False
                        break
                    current_params[content] = path_segments[i]
                    i += 1
                elif type_idx == 'wildcard':
                    # Must be the last segment of route
                    remainder = "/".join(path_segments[i:])
                    if not remainder:
                        match_possible = False
                        break
                    current_params[content] = remainder
                    i = len(path_segments) # consume all
                    break
            
            # If we finished the route segments and consumed all path segments
            if match_possible and i == len(path_segments):
                # It's a match. Now check specificity.
                current_specificity = []
                for j, (type_idx, content) in enumerate(route_segments):
                    if type_idx == 'literal':
                        current_specificity.append(3)
                    elif type_idx == 'param':
                        current_specificity.append(2)
                    elif type_idx == 'wildcard':
                        current_specificity.append(1)
                
                if best_match is None:
                    best_match = (route['name'], current_params)
                    max_specificity = (current_specificity, len(route_segments))
                else:
                    best_spec = max_specificity[0]
                    winner = False
                    for s1, s2 in zip(current_specificity, best_spec):
                        if s1 != s2:
                            if s1 > s2:
                                winner = True
                            break
                    
                    if winner:
                        best_match = (route['name'], current_params)
                        max_specificity = (current_specificity, len(route_segments))
                    elif not winner: # They are equal up to the shorter one
                        if len(route_segments) > max_specificity[1]:
                            best_match = (route['name'], current_params)
                            max_specificity = (current_specificity, len(route_segments))

        return best_match
