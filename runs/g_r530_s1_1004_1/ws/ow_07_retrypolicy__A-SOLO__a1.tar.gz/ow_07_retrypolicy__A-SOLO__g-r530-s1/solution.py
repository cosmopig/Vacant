from typing import Callable, Any, Tuple

def retry(fn: Callable[[], Any], *, attempts: int, backoff_s: float, max_backoff_s: float,
           retry_on: Tuple[type[BaseException], ...], sleep: Callable[[float], None]) -> Any:
    if attempts < 1:
        raise ValueError("attempts must be at least 1")

    last_exception = None
    for k in range(1, attempts + 1):
        try:
            return fn()
        except BaseException as e:
            # Check if it's a retryable exception
            if not any(isinstance(e, cls) for cls in retry_on):
                raise e
            
            last_exception = e
            if k == attempts:
                break
            
            delay = min(backoff_s * (2 ** (k - 1)), max_backoff_s)
            sleep(delay)
    
    if last_exception is not None:
        raise last_exception
