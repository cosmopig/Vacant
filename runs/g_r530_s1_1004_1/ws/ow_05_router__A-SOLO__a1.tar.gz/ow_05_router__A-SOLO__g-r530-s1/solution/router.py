from typing import Optional, Tuple, Dict

class Router:
    def __init__(self):
        # List of (parsed_segments, name)
        self.routes = []

    def add(self, pattern: str, name: str) -> None:
        if not pattern.startswith('/'):
            raise ValueError("Pattern must begin with /")
        
        path_parts = pattern[1:].split('/')
        # If path is "/", split gives ['']. We want segments to be empty list.
        if len(path_parts) == 1 and path_parts[0] == '':
            segments = []
        else:
            segments = path_parts

        parsed_segments = []
        for i, seg in enumerate(segments):
            # The contract says "A pattern begins with / and is read as segments split on /"
            # It doesn't explicitly say how to handle // but usually it means an empty segment.
            # However, the rules for {name} say they never match an empty segment.
            if not seg:
                continue # Skip empty segments (like in //)
            
            if seg.startswith('{') and seg.endswith('}'):
                inner = seg[1:-1]
                if not inner:
                    raise ValueError("Empty parameter name")
                
                if inner.endswith(':*'):
                    param_name = inner[:-2]
                    if not param_name:
                        raise ValueError("Empty parameter name")
                    # Check if it's the last non-empty segment
                    is_last = True
                    for j in range(i + 1, len(segments)):
                        if segments[j]:
                            is_last = False
                            break
                    if not is_last:
                        raise ValueError("{name:*} must be the last segment")
                    parsed_segments.append(('wildcard', param_name))
                else:
                    param_name = inner
                    parsed_segments.append(('param', param_name))
            elif seg.startswith('{'):
                 raise ValueError("Unmatched brace")
            else:
                parsed_segments.append(('literal', seg))

        for existing_segments, _ in self.routes:
            if existing_segments == parsed_segments:
                raise ValueError(f"Pattern {pattern} already registered.")

        self.routes.append((parsed_segments, name))

    def match(self, path: str) -> Optional[Tuple[str, Dict[str, str]]]:
        path_parts = path[1:].split('/')
        if len(path_parts) == 1 and path_parts[0] == '':
            path_parts = []

        matches = []
        for segments, name in self.routes:
            current_params = {}
            is_match = True
            
            if not segments: # Root path "/"
                if not path_parts:
                    matches.append((segments, name, current_params))
                continue

            # Check if pattern matches path
            for i, (type, val) in enumerate(segments):
                if type == 'literal':
                    if i >= len(path_parts) or path_parts[i] != val:
                        is_match = False
                        break
                elif type == 'param':
                    if i >= len(path_parts) or path_parts[i] == '':
                        is_match = False
                        break
                    current_params[val] = path_parts[i]
                elif type == 'wildcard':
                    # Wildcard must be last segment and match remainder.
                    remainder = "/".join(path_parts[i:])
                    if not remainder:
                        is_match = False
                        break
                    current_params[val] = remainder
                    # Wildcard consumes everything, so we are done.
                    break
            else:
                # If loop finished without break, check if path has extra segments
                if len(path_parts) > len(segments):
                    is_match = False

            if is_match:
                matches.append((segments, name, current_params))

        if not matches:
            return None

        # Specificity logic:
        # Rank the segments literal (3), then {name} (2), then {name:*} (1).
        # Compare segment by segment from left. First difference wins.
        # If neither differs anywhere they both reach, the pattern with more segments wins.
        
        def get_score(segments):
            scores = []
            for type, val in segments:
                if type == 'literal': scores.append(3)
                elif type == 'param': scores.append(2)
                elif type == 'wildcard': scores.append(1)
            return scores

        winner = None
        for m in matches:
            m_segs, m_name, m_params = m
            if winner is None:
                winner = m
                continue
            
            w_segs, w_name, w_params = winner
            
            diff_found = False
            for i in range(min(len(m_segs), len(w_segs))):
                type1, val1 = m_segs[i]
                type2, val2 = w_segs[i]
                if type1 != type2:
                    score1 = 3 if type1 == 'literal' else (2 if type1 == 'param' else 1)
                    score2 = 3 if type2 == 'literal' else (2 if type2 == 'param' else 1)
                    if score1 > score2:
                        winner = m
                    else:
                        pass # winner stays same
                    diff_found = True
                    break
            
            if not diff_found:
                if len(m_segs) > len(w_segs):
                    winner = m
        
        return (winner[1], winner[2])
