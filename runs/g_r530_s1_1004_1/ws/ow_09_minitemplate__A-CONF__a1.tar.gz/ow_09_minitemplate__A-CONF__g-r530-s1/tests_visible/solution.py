import re

def solution(template, data):
    pos = 0
    n = len(template)

    def get_val(path_str, context):
        if not path_str:
            raise ValueError("Empty placeholder")
        
        is_relative = path_str.startswith('.')
        parts = [p for p in path_str.split('.') if p]
        
        if is_relative and not parts: # content was just "."
            if context is None:
                raise ValueError("{{.}} or {{.field}} outside any block")
            return context
        
        current = context if is_relative else data
        for part in parts:
            if not isinstance(current, dict) or part not in current:
                raise KeyError(f"{{{{{path_str}}}}}")
            current = current[part]
        return str(current)

    def render_recursive(current_data, is_inside_each):
        nonlocal pos
        res = []
        while pos < n:
            char = template[pos]
            if char == '\\':
                if pos + 1 < n and template[pos+1] == '{':
                    res.append('{{')
                    pos += 2
                else:
                    res.append('\\')
                    pos += 1
            elif template.startswith('{{', pos):
                end_idx = template.find('}}', pos)
                if end_idx == -1:
                    raise ValueError("Unclosed placeholder")
                
                content = template[pos+2:end_idx].strip()
                pos = end_idx + 2
                
                if not content:
                    raise ValueError("Empty placeholder")
                
                if content.startswith('!'):
                    continue
                elif content.startswith('#each'):
                    if is_inside_each:
                        raise ValueError("Nested each loop")
                    
                    key = content[5:].strip()
                    if not key:
                        raise ValueError("Empty #each")
                    
                    val = data[key] if not key.startswith('.') else None
                    if not isinstance(val, list):
                        raise ValueError("Not a list")
                    
                    next_each_idx = template.find('{{/each}}', pos)
                    if next_each_idx == -1:
                        raise ValueError("Unclosed #each")
                    
                    block_content = template[pos : next_each_idx - 9]
                    
                    inner_res = []
                    for item in val:
                        def render_block_with_context(temp_template, temp_data):
                            inner_pos = 0
                            inner_res_list = []
                            while inner_pos < len(temp_template):
                                char = temp_template[inner_pos]
                                if char == '\\':
                                    if inner_pos + 1 < len(temp_template) and temp_template[inner_pos+1] == '{':
                                        inner_res_list.append('{{')
                                        inner_pos += 2
                                    else:
                                        inner_res_list.append('\\')
                                        inner_pos += 1
                                elif temp_template.startswith('{{', inner_pos):
                                    e_idx = temp_template.find('}}', inner_pos)
                                    if e_idx == -1: raise ValueError("Unclosed placeholder")
                                    c = temp_template[inner_pos+2:e_idx].strip()
                                    inner_pos = e_idx + 2
                                    if not c: raise ValueError("Empty placeholder")
                                    if c.startswith('!'): continue
                                    elif c.startswith('#each'):
                                        raise ValueError("Nested each loop")
                                    else:
                                        # Inside an 'each' block, so {{.}} is allowed.
                                        inner_res_list.append(get_val(c, temp_data if c.startswith('.') else data))
                                else:
                                    inner_res_list.append(temp_template[inner_pos])
                                    inner_pos += 1
                            return "".join(inner_res_list)

                        inner_res.append(render_block_with_context(block_content, item))
                    
                    # Update pos to after {{/each}}
                    pos = next_each_idx + 9
                else:
                    if content.startswith('.') and not is_inside_each:
                        raise ValueError("{{.}} or {{.field}} outside any block")
                    res.append(get_val(content, current_data if content.startswith('.') else data))
            else:
                res.append(template[pos])
                pos += 1
        return "".join(res)

    return render_recursive(data, False)

solution = solution
