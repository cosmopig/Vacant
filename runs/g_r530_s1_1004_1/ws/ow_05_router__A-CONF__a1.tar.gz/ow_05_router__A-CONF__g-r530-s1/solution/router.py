class Router:
    def __init__(self):
        # List of (parsed_segments, name)
        self.routes = []

    def add(self, pattern: str, name: str) -> None:
        if not pattern.startswith('/'):
            raise ValueError("Pattern must begin with /")

        if pattern == "/":
            segments_raw = []
        else:
            # Remove leading slash and split by '/'
            segments_raw = pattern[1:].split('/')

        parsed_segments = []
        for i, seg in enumerate(segments_raw):
            if not seg:
                # Double slashes or trailing slash (except for root)
                # The contract says "read as segments split on /"
                # If path is "/a/", segments are ["a", ""]. 
                # Let's treat empty string as a literal.
                parsed_segments.append(('literal', seg))
            elif seg.startswith('{') and seg.endswith('}'):
                content = seg[1:-1]
                if not content:
                    raise ValueError("Empty parameter name")
                if content.endswith(':*'):
                    param_name = content[:-2]
                    if not param_name:
                        raise ValueError("Empty parameter name")
                    if i != len(segments_raw) - 1:
                        raise ValueError("{name:*} must be the last segment")
                    parsed_segments.append(('wildcard', param_name))
                else:
                    param_name = content
                    # Check if it's just {:} which is already caught by not content
                    if not param_name:
                        raise ValueError("Empty parameter name")
                    parsed_segments.append(('param', param_name))
            elif seg.startswith('{'):
                raise ValueError("Unmatched brace")
            else:
                parsed_segments.append(('literal', seg))

        # Check for duplicate patterns (differing only in parameter names)
        for existing_segments, existing_name in self.routes:
            is_same = True
            if len(existing_segments) != len(parsed_segments):
                is_same = False
            else:
                for s1, s2 in zip(existing_segments, parsed_segments):
                    type1, val1 = s1
                    type2, val2 = s2
                    if type1 != type2 or (type1 == 'literal' and val1 != val2):
                        is_same = False
                        break
            if is_same:
                raise ValueError(f"Pattern already registered: {pattern}")

        self.routes.append((parsed_segments, name))

    def match(self, path: str) -> tuple[str, dict[str, str]] | None:
        # Path always begins with /
        if path == "/":
            path_segments = []
        else:
            path_segments = path[1:].split('/')

        best_match = None # (specificity_tuple, name, params)

        for segments, name in self.routes:
            params = {}
            p_idx = 0
            possible = True
            
            if not segments:
                if not path_segments:
                    # Match! Specificity is (number of segments, segment types)
                    pass
                else:
                    continue
            else:
                # Pattern has k > 0 segments.
                # Path must have at least one segment if pattern has any? No, path could be "/".
                # But if path is "/", path_segments is [].
                if not path_segments:
                    continue

                p_idx = 0
                for i in range(len(segments)):
                    seg_type, seg_val = segments[i]
                    
                    if seg_type == 'literal':
                        if p_idx >= len(path_segments) or path_segments[p_idx] != seg_val:
                            possible = False
                            break
                        p_idx += 1
                    elif seg_type == 'param':
                        if p_idx >= len(path_segments) or not path_segments[p_idx]:
                            possible = False
                            break
                        params[seg_val] = path_segments[p_idx]
                        p_idx += 1
                    elif seg_type == 'wildcard':
                        # Wildcard must be the last segment.
                        if i != len(segments) - 1:
                            possible = False
                            break
                        # It matches all remaining path segments.
                        remaining = path_segments[p_idx:]
                        if not remaining:
                            possible = False
                            break
                        params[seg_val] = "/".join(remaining)
                        p_idx = len(path_segments)
                        break
                    else:
                        possible = False
                        break
                
                # After the loop, we must have consumed all path segments.
                if possible and p_idx == len(path_segments):
                    pass

            # Wait, I still need to handle specificity properly.
            # Let's rewrite this whole thing again with a cleaner approach for matching and specificity.
