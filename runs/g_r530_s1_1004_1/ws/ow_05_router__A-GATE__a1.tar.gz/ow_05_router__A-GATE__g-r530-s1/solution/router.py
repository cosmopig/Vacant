class Router:
    def __init__(self):
        # List of (pattern_segments, name)
        self.routes = []

    def add(self, pattern: str, name: str) -> None:
        if not pattern.startswith('/'):
            raise ValueError("Pattern must begin with /")
        
        path_parts = pattern[1:].split('/')
        segments = []
        for i, part in enumerate(path_parts):
            if part == "":
                continue
            
            if part.startswith('{') and part.endswith('}'):
                content = part[1:-1]
                if not content:
                    raise ValueError("Empty parameter name")
                
                if content.endswith(':*'):
                    param_name = content[:-2]
                    if not param_name:
                        raise ValueError("Empty parameter name")
                    # {name:*} must be the last segment
                    is_last = True
                    for j in range(i + 1, len(path_parts)):
                        if path_parts[j] != "":
                            is_last = False
                            break
                    if not is_last:
                        raise ValueError("{name:*} must be the last segment")
                    segments.append(('wildcard', param_name))
                else:
                    # Check for unmatched braces in content
                    if '{' in content or '}' in content:
                        raise ValueError("Unmatched brace")
                    segments.append(('param', content))
            elif part.startswith('{'):
                raise ValueError("Unmatched brace")
            else:
                segments.append(('literal', part))

        # Check for uniqueness (differ only in parameter names)
        for existing_segs, existing_name in self.routes:
            if len(existing_segs) == len(segments):
                match = True
                for s1, s2 in zip(existing_segs, segments):
                    type1, val1 = s1
                    type2, val2 = s2
                    if type1 != type2:
                        match = False
                        break
                    if type1 == 'literal' and val1 != val2:
                        match = False
                        break
                if match:
                    raise ValueError("Duplicate pattern")

        self.routes.append((segments, name))

    def match(self, path: str) -> tuple[str, dict[str, str]] | None:
        path_parts = path[1:].split('/')
        # The contract says paths handed to match always begin with /
        # and a pattern begins with /. 
        # If the path is "/", path_parts will be [""]
        # We should probably filter out empty parts unless it's just "/"?
        # Wait, if path is "/a/b", split('/') gives ["", "a", "b"].
        # Let's see how we handled segments in add. 
        # In add("/a"), path_parts was ["a"], and segments became [('literal', 'a')]
        # So for match, if path is "/a", path_parts is ["", "a"], we want ["a"].
        path_segments = [p for p in path_parts if p != ""]

        best_match = None # (route_segs, name, params)
        
        for route_segs, name in self.routes:
            params = {}
            match_found = True
            curr_path_idx = 0
            
            for i, (seg_type, seg_val) in enumerate(route_segs):
                if seg_type == 'literal':
                    if curr_path_idx >= len(path_segments) or path_segments[curr_path_idx] != seg_val:
                        match_found = False
                        break
                    curr_path_idx += 1
                elif seg_type == 'param':
                    if curr_path_idx >= len(path_segments):
                        match_found = False
                        break
                    params[seg_val] = path_segments[curr_path_idx]
                    curr_path_idx += 1
                elif seg_type == 'wildcard':
                    remaining_path = path_segments[curr_path_idx:]
                    if not remaining_path:
                        match_found = False
                        break
                    params[seg_val] = "/".join(remaining_path)
                    curr_path_idx = len(path_segments)
                    break
            
            # The path must be fully consumed. 
            # If the route was just "/", segments is empty, and path_segments is empty.
            if match_found and curr_path_idx == len(path_segments):
                if best_match is None:
                    best_match = (route_segs, name, params)
                else:
                    best_segs, best_name, best_params = best_match
                    winner = None # 1 for new, -1 for old
                    for s1, s2 in zip(route_segs, best_segs):
                        type1, val1 = s1
                        type2, val2 = s2
                        if type1 != type2:
                            rank = {'literal': 0, 'param': 1, 'wildcard': 2}
                            if rank[type1] < rank[type2]:
                                winner = 1
                            else:
                                winner = -1
                            break
                    
                    if winner is None:
                        if len(route_segs) > len(best_segs):
                            winner = 1
                        elif len(route_segs) < len(best_segs):
                            winner = -1
                        else:
                            winner = 0 # Should not happen
                    
                    if winner == 1:
                        best_match = (route_segs, name, params)
        
        if best_match:
            return best_match[1], best_match[2]
        return None
