import re

def render(template, data):
    # 1. Tokenize the template into text, literal {{, and tags like {{...}}
    tokens = []
    i = 0
    while i < len(template):
        if template[i:i+3] == r'\{{':
            tokens.append({'type': 'literal', 'value': '{{'})
            i += 3
        elif template[i:i+2] == '{{':
            j = i + 2
            while j < len(template) and template[j] != '}':
                j += 1
            if j >= len(template):
                raise ValueError("a {{ with no }} after it")
            content = template[i+2:j]
            tokens.append({'type': 'tag', 'content': content})
            i = j + 2
        else:
            next_idx = len(template)
            for k in range(i, len(template)):
                if template[k:k+3] == r'\{{':
                    next_idx = min(next_idx, k)
                    break
                if template[k:k+2] == '{{':
                    next_idx = min(next_idx, k)
                    break
            tokens.append({'type': 'text', 'value': template[i:next_idx]})
            i = next_idx

    def resolve_path(path, context):
        if not path or path == ".":
            return context
        parts = path.split('.')
        current = context
        for part in parts:
            if part == "": continue
            # The prompt says "names that do not begin with . are still looked up in data"
            # and "{{.}} is the element itself and {{.field}} is a field of it".
            # This means if we have something like {{user.name}}, it's looking into context (data).
            if isinstance(current, dict) and part in current:
                current = current[part]
            else:
                raise KeyError(path)
        return current

    def evaluate_recursive(token_list, context, depth=0):
        output = []
        idx = 0
        while idx < len(token_list):
            token = token_list[idx]
            if token['type'] == 'text':
                output.append(token['value'])
            elif token['type'] == 'literal':
                output.append(token['value'])
            elif token['type'] == 'tag':
                content = token['content'].strip()
                if not content:
                    raise ValueError("an empty placeholder")
                
                if content.startswith('!'):
                    idx += 1
                    continue
                elif content.startswith('#each'):
                    if depth > 0:
                        raise ValueError("a {{#each}} inside another {{#each}}")
                    
                    match = re.match(r'^#each\s+(.*)', content)
                    if not match:
                        raise ValueError("a {{#each}} that is never closed")

                    items_key = match.group(1).strip()
                    
                    j = idx + 1
                    bracket_count = 1
                    found_end = False
                    while j < len(token_list):
                        t = token_list[j]
                        if t['type'] == 'tag':
                            t_content = t['content'].strip()
                            if t_content == '/each':
                                bracket_count -= 1
                                if bracket_count == 0:
                                    found_end = True
                                    break
                            elif t_content.startswith('#each'):
                                bracket_count += 1
                        j += 1
                    
                    if not found_end:
                        raise ValueError("a {{#each}} that is never closed")
                    
                    inner_tokens = token_list[idx+1 : j]
                    
                    if items_key == ".":
                        items = context
                    else:
                        try:
                            items = resolve_path(items_key, context)
                        except KeyError as e:
                            raise KeyError(e.args[0])

                    if not isinstance(items, list):
                        raise ValueError("a repeat over something that is not a list")
                    
                    for item in items:
                        def resolve_block_path(p, d, i):
                            if p == ".": return i
                            if p.startswith("."):
                                sub = p[1:]
                                parts = sub.split('.')
                                curr = i
                                for part in parts:
                                    if not part: continue
                                    if isinstance(curr, dict) and part in curr:
                                        curr = curr[part]
                                    else:
                                        raise KeyError(p)
                                return curr
                            else:
                                try:
                                    parts = p.split('.')
                                    curr = d
                                    for part in parts:
                                        if not part: continue
                                        if isinstance(curr, dict) and part in curr:
                                            curr = curr[part]
                                        else:
                                            raise KeyError(p)
                                    return curr
                                except (KeyError, TypeError):
                                    pass

                        def eval_block_item(token_list_inner, current_data, current_item):
                            output_inner = []
                            idx_inner = 0
                            while idx_inner < len(token_list_inner):
                                token_inner = token_list_inner[idx_inner]
                                if token_inner['type'] == 'text':
                                    output_inner.append(token_inner['value'])
                                elif token_inner['type'] == 'literal':
                                    output_inner.append(token_inner['value'])
                                elif token_inner['type'] == 'tag':
                                    content_inner = token_inner['content'].strip()
                                    if not content_inner: raise ValueError("an empty placeholder")
                                    if content_inner.startswith('!'):
                                        idx_inner += 1
                                        continue
                                    elif content_inner.startswith('#each'):
                                        raise ValueError("a {{#each}} inside another {{#each}}")
                                    else:
                                        try:
                                            val = resolve_block_path(content_inner, current_data, current_item)
                                            output_inner.append(str(val))
                                        except KeyError as e:
                                            raise KeyError(e.args[0])
                                idx_inner += 1
                            return "".join(output_inner)

                        output.append(eval_block_item(inner_tokens, data, item))
                    
                    idx = j + 1
                else:
                    content = token['content'].strip()
                    if not content:
                        raise ValueError("an empty placeholder")
                    try:
                        val = resolve_path(content, context)
                        output.append(str(val))
                    except KeyError as e:
                        # Re-raising the KeyError with its original message (the path)
                        if isinstance(e, KeyError):
                            raise e
                        else:
                            raise e
            return "".join(output)

    open_eaches = []
    for i, token in enumerate(tokens):
        if token['type'] == 'tag':
            content = token['content'].strip()
            if content.startswith('#each'):
                open_eaches.append(i)
            elif content == '/each':
                if not open_eaches:
                    raise ValueError("a {{/each}} with no {{#each}} open")
                open_eaches.pop()
    if open_eaches:
        raise ValueError("a {{#each}} that is never closed")

    return evaluate_recursive(tokens, data)

