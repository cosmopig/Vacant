class Router:
    def __init__(self):
        # List of (parsed_segments, name)
        self.routes = []

    def add(self, pattern: str, name: str) -> None:
        if not pattern.startswith('/'):
            raise ValueError("Pattern must begin with /")
        
        raw_segments = pattern.split('/')
        # If pattern is "/", raw_segments is ["", ""]. 
        # Actually split("/") gives ["", ""], but we want to handle "/" as empty segments list.
        if len(raw_segments) == 1 and raw_segments[0] == "":
            segments = []
        elif len(raw_segments) == 2 and raw_segments[0] == "" and raw_segments[1] == "":
             # This handles "/" if split gives ["", ""] which it does for "/".
             # Wait, "".split("/") is [""]. "/".split("/") is ["", ""].
             # Let's check:
             pass

        # Correct way to get segments from path starting with /
        if pattern == "/":
            segments = []
        else:
            segments = pattern[1:].split('/')

        parsed_segments = []
        for i, seg in enumerate(segments):
            if not seg: # This handles "//" which is an empty segment literal ""
                # The contract says "A segment is one of three things: a literal, {name}, or {name:*}"
                # If it's "", it's a literal.
                parsed_segments.append(('literal', ''))
                continue

            if seg.startswith('{') and seg.endswith('}'):
                inner = seg[1:-1]
                if not inner:
                    raise ValueError("Empty parameter name")
                
                if inner.endswith(':*'):
                    param_name = inner[:-2]
                    if param_name == "":
                        raise ValueError("Empty parameter name")
                    if i != len(segments) - 1:
                        raise ValueError("{name:*} must be the last segment")
                    parsed_segments.append(('wildcard', param_name))
                else:
                    # Check for unmatched braces inside {name}
                    if '{' in inner or '}' in inner:
                        raise ValueError("Unmatched brace")
                    parsed_segments.append(('param', inner))
            elif seg.startswith('{') or seg.endswith('}'):
                raise ValueError("Unmatched brace")
            else:
                # Literal segment
                parsed_segments.append(('literal', seg))

        # Check for duplicates (differ only in parameter names)
        for existing_segs, _ in self.routes:
            is_same = True
            if len(existing_segs) != len(parsed_segments):
                is_same = False
            else:
                for s1, s2 in zip(existing_segs, parsed_segments):
                    type1, val1 = s1
                    type2, val2 = s2
                    if type1 != type2:
                        is_same = False
                        break
                    if type1 == 'literal' and val1 != val2:
                        is_same = False
                        break
                if is_same:
                    raise ValueError("Duplicate pattern")

        self.routes.append((parsed_segments, name))

    def match(self, path: str) -> tuple[str, dict[str, str]] | None:
        # Path always begins with /
        path_segments = path[1:].split('/') if path != "/" else []
        if path == "/":
            path_segments = []

        best_match = None
        best_score = None # Will be a list of scores

        for parsed_segs, name in self.routes:
            current_params = {}
            match_found = True
            i = 0
            
            # Special case for empty path "/" matching pattern "/"
            if not parsed_segs and not path_segments:
                match_found = True
            else:
                for j, (seg_type, seg_val) in enumerate(parsed_segs):
                    if seg_type == 'literal':
                        if i >= len(path_segments) or path_segments[i] != seg_val:
                            match_found = False
                            break
                        i += 1
                    elif seg_type == 'param':
                        if i >= len(path_segments) or not path_segments[i]:
                            match_found = False
                            break
                        current_params[seg_val] = path_segments[i]
                        i += 1
                    elif seg_type == 'wildcard':
                        # Must be the last segment in parsed_segs
                        if j != len(parsed_segs) - 1:
                            match_found = False
                            break
                        remainder = path_segments[i:]
                        if not remainder:
                            match_found = False
                            break
                        current_params[seg_val] = "/".join(remainder)
                        i = len(path_segments)
                        break
                
                # If we finished the loop but didn't consume all path segments, it's not a match
                if match_found and i != len(path_segments):
                    match_found = False

            if match_found:
                score = []
                for st, sv in parsed_segs:
                    if st == 'literal': score.append(3)
                    elif st == 'param': score.append(2)
                    else: score.append(1)
                
                if best_match is None:
                    best_match = (name, current_params, score)
                else:
                    best_score_list = best_match[2]
                    winner = 0 # 1 for current, -1 for best_match
                    for s1, s2 in zip(score, best_score_list):
                        if s1 > s2:
                            winner = 1
                            break
                        elif s1 < s2:
                            winner = -1
                            break
                    
                    if winner == 0:
                        if len(score) > len(best_score_list):
                            winner = 1
                        elif len(score) < len(best_score_list):
                            winner = -1
                    
                    if winner == 1:
                        best_match = (name, current_params, score)

        if best_match:
            return (best_match[0], best_match[1])
        return None
