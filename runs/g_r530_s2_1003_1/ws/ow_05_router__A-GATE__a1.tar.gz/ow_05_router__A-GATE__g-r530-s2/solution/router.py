class Router:
    def __init__(self):
        self.routes = []  # List of (parsed_segments, name)

    def add(self, pattern: str, name: str) -> None:
        if not pattern.startswith('/'):
            raise ValueError("Pattern must begin with /")
        
        raw_parts = pattern.split('/')
        # The contract says "read as segments split on /"
        # For "/a/b", raw_parts is ["", "a", "b"]
        # Let's assume the first empty string (from leading slash) is ignored, 
        # and trailing or double slashes are also ignored.
        raw_segments = []
        for i, seg in enumerate(raw_parts):
            if i == 0: continue # Skip leading slash
            if not seg: continue # Skip trailing or double slashes?
            raw_segments.append(seg)

        parsed_segments = []
        for i, seg in enumerate(raw_segments):
            if seg.startswith('{') and seg.endswith('}'):
                inner = seg[1:-1]
                if not inner:
                    raise ValueError("Empty parameter name")
                
                if inner.endswith(':*'):
                    param_name = inner[:-2]
                    if not param_name:
                        raise ValueError("Empty parameter name")
                    if i != len(raw_segments) - 1:
                        raise ValueError("{name:*} must be the last segment")
                    parsed_segments.append(('wildcard', param_name))
                else:
                    # {name}
                    parsed_segments.append(('param', inner))
            elif seg:
                # literal
                parsed_segments.append(('literal', seg))

        # Check for unmatched braces in any segment of the original pattern
        for i, seg in enumerate(raw_parts):
            if not seg: continue
            if '{' in seg or '}' in seg:
                if not (seg.startswith('{') and seg.endswith('}')):
                    raise ValueError("Unmatched brace")

        # Check for duplicate pattern structure
        for existing_segments, _ in self.routes:
            is_same = True
            if len(existing_segments) != len(parsed_segments):
                is_same = False
            else:
                for s1, s2 in zip(existing_segments, parsed_segments):
                    type1, val1 = s1
                    type2, val2 = s2
                    if type1 != type2 or (type1 == 'literal' and val1 != val2):
                        is_same = False
                        break
            if is_same:
                raise ValueError("Duplicate pattern")

        self.routes.append((parsed_segments, name))

    def match(self, path: str) -> tuple[str, dict[str, str]] | None:
        # Paths handed to match always begin with /
        path_parts = [s for s in path.split('/') if s]
        
        best_match = None
        best_parsed_segments = None

        for parsed_segments, name in self.routes:
            current_params = {}
            match_possible = True
            i = 0
            j = 0
            
            while i < len(parsed_segments) and j < len(path_parts):
                p_type, p_val = parsed_segments[i]
                path_seg = path_parts[j]
                
                if p_type == 'literal':
                    if p_val != path_seg:
                        match_possible = False
                        break
                    i += 1
                    j += 1
                elif p_type == 'param':
                    current_params[p_val] = path_seg
                    i += 1
                    j += 1
                elif p_type == 'wildcard':
                    # {name:*} matches the whole remainder.
                    current_params[p_val] = "/".join(path_parts[j:])
                    i += 1
                    j = len(path_parts)
                    break
            
            if match_possible and i == len(parsed_segments) and j == len(path_parts):
                if best_match is None:
                    best_match = (name, current_params)
                    best_parsed_segments = parsed_segments
                else:
                    winner = None
                    for s1, s2 in zip(best_parsed_segments, parsed_segments):
                        if s1 != s2:
                            rank_map = {'literal': 3, 'param': 2, 'wildcard': 1}
                            if rank_map[s1[0]] > rank_map[s2[0]]:
                                winner = "current"
                            elif rank_map[s1[0]] < rank_map[s2[0]]:
                                winner = "best"
                            break
                    
                    if winner is None:
                        if len(parsed_segments) > len(best_parsed_segments):
                            winner = "current"
                        elif len(parsed_segments) < len(best_parsed_segments):
                            winner = "best"
                    
                    if winner == "current":
                        best_match = (name, current_params)
                        best_parsed_segments = parsed_segments

        return best_match
