def plan(jobs: dict[str, list[str]]) -> list[str]:
    # Collect all unique job names
    all_jobs = set(jobs.keys())
    for deps in jobs.values():
        for dep in deps:
            all_jobs.add(dep)

    # Build adjacency list and in-degree count
    adj = {job: [] for job in all_jobs}
    in_degree = {job: 0 for job in all_jobs}

    for job, deps in jobs.items():
        for dep in deps:
            # The dependency 'dep' must finish before 'job' starts.
            # So there is an edge from 'dep' to 'job'.
            adj[dep].append(job)
            in_degree[job] += 1

    # Kahn's algorithm for topological sort
    # To ensure deterministic output, we use a sorted list of available jobs.
    queue = [job for job in all_jobs if in_degree[job] == 0]
    queue.sort()
    
    result = []
    while queue:
        # We pick the smallest lexicographical job to ensure determinism
        current = queue.pop(0)
        result.append(current)
        
        for neighbor in adj[current]:
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                queue.append(neighbor)
                queue.sort()

    if len(result) != len(all_jobs):
        raise ValueError("Cycle detected or impossible dependencies.")
        
    return result
