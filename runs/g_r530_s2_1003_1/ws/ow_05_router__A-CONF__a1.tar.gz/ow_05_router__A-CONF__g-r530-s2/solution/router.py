import re

class Router:
    def __init__(self):
        # List of (segments, name)
        self.routes = []
        # To check for duplicate patterns (ignoring names)
        # We store a normalized version of the segments
        self._seen_patterns = set()

    def add(self, pattern: str, name: str) -> None:
        if not pattern.startswith('/'):
            raise ValueError("Pattern must start with '/'")
        
        segments = []
        # The contract says "A pattern begins with / and is read as segments split on /."
        # If path is "/", the remaining part after "/" is "". 
        # Let's see how we should handle this. 
        if pattern == "/":
            raw_parts = []
        else:
            # The contract says "A pattern begins with / and is read as segments split on /."
            # If path is "/a/b", raw_parts are ["a", "b"].
            # If path is "/a/", raw_parts are ["a", ""].
            raw_parts = pattern[1:].split('/')
            
        for i, part in enumerate(raw_parts):
            if '{' in part or '}' in part:
                if part.startswith('{') and part.endswith('}'):
                    inner = part[1:-1]
                    if inner.endswith(':*'):
                        param_name = inner[:-2]
                        if not param_name:
                            raise ValueError("Empty parameter name")
                        # {name:*} must be last segment
                        if i != len(raw_parts) - 1:
                            raise ValueError("{name:*} must be the last segment")
                        segments.append(('wildcard', param_name))
                    else:
                        param_name = inner
                        if not param_name:
                            raise ValueError("Empty parameter name")
                        segments.append(('param', param_name))
                else:
                    raise ValueError("Unmatched brace")
            else:
                segments.append(('literal', part))

        # Check for duplicate patterns (ignoring names)
        normalized = tuple((s[0], s[1] if s[0] == 'literal' else None) for s in segments)
        if normalized in self._seen_patterns:
            raise ValueError("Duplicate pattern")
        self._seen_patterns.add(normalized)

        self.routes.append({'segments': segments, 'name': name})

    def match(self, path: str) -> tuple[str, dict[str, str]] | None:
        if not path.startswith('/'):
            return None
            
        if path == "/":
            path_parts = []
        else:
            # The contract says "Paths handed to match always begin with /."
            # If path is "/a/b", path[1:].split('/') is ["a", "b"].
            # If path is "/a/", path[1:].split('/') is ["a", ""].
            path_parts = path[1:].split('/')

        best_match = None # (name, params, segments)
        
        for route in self.routes:
            route_segments = route['segments']
            params = {}
            match_found = True
            
            # A pattern matches if its segments match path_parts.
            # {name} matches exactly one segment, never spans a /, and never matches an empty segment.
            # {name:*} matches the whole remainder of the path, may contain /, must not be empty, 
            # and may only appear as the last segment.

            for i in range(len(route_segments)):
                seg_type, seg_val = route_segments[i]
                
                if seg_type == 'literal':
                    if i >= len(path_parts) or path_parts[i] != seg_val:
                        match_found = False
                        break
                elif seg_type == 'param':
                    if i >= len(path_parts) or path_parts[i] == '':
                        match_found = False
                        break
                    params[seg_val] = path_parts[i]
                elif seg_type == 'wildcard':
                    # {name:*} matches the whole remainder of the path.
                    # It must not be empty.
                    remainder = "/".join(path_parts[i:])
                    if not remainder or i != len(route_segments) - 1:
                        match_found = False
                        break
                    params[seg_val] = remainder
                    # Since it matches the whole remainder, we are done with this route.
                    break
            else:
                # This part is reached if the loop finished without break.
                if len(path_parts) != len(route_segments):
                    match_found = False

            if match_found:
                if best_match is None:
                    best_match = (route['name'], params, route_segments)
                else:
                    best_name, best_params, best_segments = best_match
                    
                    # Compare specificity
                    winner = None # 1 for current, -1 for best_match, 0 for same
                    for i in range(max(len(route_segments), len(best_segments))):
                        s1 = route_segments[i] if i < len(route_segments) else (None, None)
                        s2 = best_segments[i] if i < len(best_segments) else (None, None)
                        
                        # If one pattern ends before the other
                        if s1[0] is None: # route ended
                            winner = 1 if len(route_segments) > len(best_segments) else -1
                            break
                        if s2[0] is None: # best_match ended
                            winner = -1 if len(route_segments) > len(best_segments) else 1
                            break
                        
                        # Compare types: literal (3), param (2), wildcard (1)
                        type_map = {'literal': 3, 'param': 2, 'wildcard': 1}
                        t1 = type_map.get(s1[0], 0)
                        t2 = type_map.get(s2[0], 0)
                        
                        if t1 != t2:
                            winner = 1 if t1 > t2 else -1
                            break
                    
                    if winner is None:
                        # They are identical in specificity, use more segments?
                        if len(route_segments) > len(best_segments):
                            winner = 1
                        elif len(route_segments) < len(best_segments):
                            winner = -1
                    
                    if winner == 1:
                        best_match = (route['name'], params, route_segments)

        if best_match:
            return best_match[0], best_match[1]
        return None
