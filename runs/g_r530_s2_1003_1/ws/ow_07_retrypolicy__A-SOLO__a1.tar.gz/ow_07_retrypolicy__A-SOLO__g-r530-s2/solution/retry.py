from typing import Callable, Any, Tuple, Type

def retry(
    fn: Callable[[], Any],
    *,
    attempts: int,
    backoff_s: float,
    max_backoff_s: float,
    retry_on: Tuple[Type[BaseException], ...],
    sleep: Callable[[float], None]
) -> Any:
    if attempts < 1:
        raise ValueError("attempts must be at least 1")

    last_exception = None
    for k in range(1, attempts + 1):
        try:
            return fn()
        except Exception as e:
            # Check if this exception is one we should retry on
            if not any(isinstance(e, t) for t in retry_on):
                raise e
            
            last_exception = e
            
            # If it's the last attempt, don't sleep, just raise
            if k == attempts:
                raise last_exception
            
            # Calculate delay
            delay = min(backoff_s * (2 ** (k - 1)), max_backoff_s)
            sleep(delay)

