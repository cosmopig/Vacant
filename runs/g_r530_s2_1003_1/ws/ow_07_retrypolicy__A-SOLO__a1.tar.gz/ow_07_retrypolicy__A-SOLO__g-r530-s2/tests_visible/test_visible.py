import unittest
import solution

class TestVisible(unittest.TestCase):
    def test_v01_retries_then_succeeds(self):
        """Visible check 1: a call that settles down on the third try returns its value."""
        calls = []
        naps = []

        def flaky():
            calls.append(1)
            if len(calls) < 3:
                raise ConnectionError("not yet")
            return "payload"

        got = solution.retry(flaky, attempts=5, backoff_s=0.5, max_backoff_s=30.0,
                             retry_on=(ConnectionError,), sleep=naps.append)
        self.assertEqual(got, "payload", "args=%r got=%r want=%r" % ("flaky, attempts=5", got, "payload"))
        self.assertEqual(len(calls), 3, "args=%r got=%r want=%r" % ("flaky, attempts=5", len(calls), 3))
        self.assertEqual(len(naps), 2, "args=%r got=%r want=%r" % ("flaky, attempts=5", naps, "two waits"))

    def test_v02_backs_off_longer(self):
        """Visible check 2: the wait grows between attempts, and there is one wait
        fewer than there are attempts."""
        naps = []

        def always_fails():
            raise TimeoutError("nope")

        try:
            solution.retry(always_fails, attempts=4, backoff_s=1.0, max_backoff_s=1000.0,
                           retry_on=(TimeoutError,), sleep=naps.append)
        except TimeoutError:
            pass
        else:
            raise AssertionError("args=%r got=%r want=%r" % ("always_fails", "returned", "TimeoutError"))
        self.assertEqual(len(naps), 3, "args=%r got=%r want=%r" % ("attempts=4", naps, "three waits"))
        for i in range(len(naps) - 1):
            self.assertTrue(naps[i] < naps[i+1], f"nap {i} ({naps[i]}) is not less than nap {i+1} ({naps[i+1]})")

    def test_v03_not_worth_retrying(self):
        """Visible check 3: a failure outside the listed kinds comes straight back."""
        calls = []
        naps = []

        def wrong_kind():
            calls.append(1)
            raise ValueError("bad argument")

        try:
            solution.retry(wrong_kind, attempts=5, backoff_s=1.0, max_backoff_s=10.0,
                           retry_on=(ConnectionError,), sleep=naps.append)
        except ValueError:
            pass
        else:
            raise AssertionError("args=%r got=%r want=%r" % ("wrong_kind", "returned", "ValueError"))
        self.assertEqual(len(calls), 1, "args=%r got=%r want=%r" % ("wrong_kind", len(calls), 1))
        self.assertEqual(naps, [], "args=%r got=%r want=%r" % ("wrong_kind", naps, []))

if __name__ == "__main__":
    unittest.main()
