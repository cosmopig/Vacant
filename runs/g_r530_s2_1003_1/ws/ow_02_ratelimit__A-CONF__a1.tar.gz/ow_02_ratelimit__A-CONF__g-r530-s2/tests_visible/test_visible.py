import unittest
from solution import RateLimiter
from typing import Callable

class TestRateLimiter(unittest.TestCase):
    def test_basic(self):
        clock = lambda: 0.0
        rl = RateLimiter(1.0, 2, clock)
        self.assertTrue(rl.allow("a"))
        self.assertTrue(rl.allow("a"))
        self.assertFalse(rl.allow("a"))
        self.assertEqual(rl.retry_after("a"), 1.0)

    def test_window_sliding(self):
        # At t=1.0, window is (0.0, 1.0]
        # allow "a" at 1.0 -> success
        # allow "a" at 2.0 -> success (since 1.0 is in (1.0, 2.0]? No, it's not)
        # Wait: window_s = 1.0. At now=2.0, window is (1.0, 2.0].
        # If we allowed at 1.0, it's NOT in (1.0, 2.0] because left is open.
        clock = lambda: 1.0
        rl = RateLimiter(1.0, 2, clock)
        self.assertTrue(rl.allow("a")) # now=1.0, events=[1.0]
        
        # Now move clock to 2.0
        clock = lambda: 2.0
        self.assertTrue(rl.allow("a")) # now=2.0, events=[1.0, 2.0]? No, 1.0 is not in (1.0, 2.0]
        # Wait, the logic says "an event counts while it falls in (now - window_s, now]".
        # At now=2.0, window_s=1.0, range is (1.0, 2.0].
        # 1.0 is NOT in (1.0, 2.0] because the left is open.
        # So valid_events for "a" should be empty? Let's check my code.
        # valid_events = [t for t in self.data[key] if now - self.window_s < t <= now]
        # 2.0 - 1.0 < 1.0 is False (1.0 < 1.0 is False). Correct.

    def test_retry_after(self):
        clock = lambda: 10.0
        rl = RateLimiter(5.0, 2, clock)
        rl.allow("a") # at 10.0
        rl.allow("a") # at 10.0
        # valid_events = [10.0, 10.0]
        # retry_after: leaving = valid_events[2-2] = valid_events[0] = 10.0
        # return 10.0 + 5.0 - 10.0 = 5.0
        self.assertEqual(rl.retry_after("a"), 5.0)

    def test_reset(self):
        clock = lambda: 1.0
        rl = RateLimiter(1.0, 1, clock)
        rl.allow("a")
        rl.reset("a")
        self.assertTrue(rl.allow("a"))
        rl.reset()
        rl.allow("b")
        rl.reset()
        self.assertTrue(rl.allow("b"))

    def test_invalid_config(self):
        clock = lambda: 1.0
        with self.assertRaises(ValueError):
            RateLimiter(0, 1, clock)
        with self.assertRaises(ValueError):
            RateLimiter(1, -1, clock)

    def test_max_events_zero(self):
        clock = lambda: 1.0
        rl = RateLimiter(1.0, 0, clock)
        self.assertFalse(rl.allow("a"))
        self.assertEqual(rl.retry_after("a"), float('inf'))

    def test_backward_clock(self):
        # now=10.0, window=5.0 -> (5.0, 10.0]
        # allow at 10.0
        # clock moves to 8.0 -> (3.0, 8.0]. 10.0 is not in it.
        clock_val = [10.0]
        def clock(): return clock_val[0]
        rl = RateLimiter(5.0, 1, clock)
        rl.allow("a") # now=10.0, events=[10.0]
        clock_val[0] = 8.0
        self.assertTrue(rl.allow("a")) # now=8.0, (3.0, 8.0]. 10.0 is not in it.

if __name__ == "__main__":
    unittest.main()
