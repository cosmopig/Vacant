from typing import Callable, Dict, List

class RateLimiter:
    def __init__(self, window_s: float, max_events: int, clock: Callable[[], float]):
        if window_s <= 0 or max_events < 0:
            raise ValueError("Invalid configuration")
        self.window_s = window_s
        self.max_events = max_events
        self.clock = clock
        self.data: Dict[str, List[float]] = {}

    def allow(self, key: str) -> bool:
        now = self.clock()
        if key not in self.data:
            self.data[key] = []
        
        # Filter events in (now - window_s, now]
        valid_events = [t for t in self.data[key] if now - self.window_s < t <= now]
        
        if len(valid_events) < self.max_events:
            self.data[key] = valid_events + [now]
            return True
        else:
            self.data[key] = valid_events
            return False

    def retry_after(self, key: str) -> float:
        now = self.clock()
        if key not in self.data or self.max_events == 0:
            return 0.0 if self.max_events > 0 else float('inf')
        
        valid_events = [t for t in self.data[key] if now - self.window_s < t <= now]
        if len(valid_events) < self.max_events:
            return 0.0
        
        # The earliest event that must fall out is the one at index (len(valid_events) - max_events)
        # Wait, if we want to admit ONE more, we need to drop the oldest of the current "full" window.
        # Actually, the rule says: "leaving + window_s - now", where leaving is the earliest 
        # counted event that has to fall out of the window before the next call can be admitted.
        # If max_events is 3 and we have [10, 11, 12] at now=13, window=5.
        # (now-window, now] = (8, 13]. All are in.
        # To admit one more, 10 must fall out. It falls out when now > 10 + 5 = 15.
        # So retry_after is 15 - 13 = 2.
        
        leaving = valid_events[len(valid_events) - self.max_events]
        return leaving + self.window_s - now

    def reset(self, key: str | None = None) -> None:
        if key is None:
            self.data.clear()
        else:
            self.data.pop(key, None)
