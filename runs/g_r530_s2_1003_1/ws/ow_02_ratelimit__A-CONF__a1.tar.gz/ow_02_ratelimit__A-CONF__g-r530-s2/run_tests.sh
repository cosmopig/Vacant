#!/bin/bash
python3 -m unittest discover -p solution.py -v .
