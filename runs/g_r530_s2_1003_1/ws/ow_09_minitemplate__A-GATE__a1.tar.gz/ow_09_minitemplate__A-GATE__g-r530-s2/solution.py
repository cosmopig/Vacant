import re

def render(template, data):
    tokens = []
    i = 0
    while i < len(template):
        if template.startswith(r"\{{", i):
            tokens.append(('literal', r"{{"))
            i += 3
        elif template.startswith("{{", i):
            end_idx = template.find("}}", i)
            if end_idx == -1:
                raise ValueError("Malformed template")
            content = template[i+2 : end_idx].strip()
            tokens.append(('tag', content))
            i = end_idx + 2
        else:
            next_pos = len(template)
            for s in ["{{", r"\{{"]:
                pos = template.find(s, i)
                if pos != -1:
                    next_pos = min(next_pos, pos)
            tokens.append(('text', template[i : next_pos]))
            i = next_pos

    def get_value(path, context):
        if path == ".":
            return context
        
        parts = path.split('.')
        # If it starts with '.', we treat it as relative to the current item (context)
        if parts[0] == '.':
            curr_val = context
            for p in parts[1:]:
                if not p: continue
                if isinstance(curr_val, dict) and p in curr_val:
                    curr_val = curr_val[p]
                else:
                    raise KeyError(f"{{{{{path}}}}}")
            return curr_val
        else:
            # Otherwise, it's absolute from the root data.
            curr_val = data
            for p in parts:
                if not p: continue
                if isinstance(curr_val, dict) and p in curr_val:
                    curr_val = curr_val[p]
                else:
                    raise KeyError(f"{{{{{path}}}}}")
            return curr_val

    def parse_and_render(token_list, current_data, depth=0):
        output = []
        idx = 0
        while idx < len(token_list):
            type, content = token_list[idx]
            if type == 'text':
                output.append(content)
                idx += 1
            elif type == 'literal':
                output.append(content)
                idx += 1
            elif type == 'tag':
                if not content:
                    raise ValueError("Empty placeholder")
                if content.startswith('#each'):
                    if depth > 0:
                        raise ValueError("Nested repeat")
                    
                    match = re.match(r'#each\s+([\w.]+)', content)
                    if not match:
                        raise ValueError("Malformed each")
                    
                    list_name = match.group(1)
                    if list_name not in current_data or not isinstance(current_data[list_name], list):
                        raise ValueError("Not a list")
                    
                    end_idx = -1
                    for j in range(idx + 1, len(token_list)):
                        if token_list[j][1] == '/each':
                            end_idx = j
                            break
                    if end_idx == -1:
                        raise ValueError("Unclosed each")
                    
                    inner_tokens = token_list[idx + 1 : end_idx]
                    for item in current_data[list_name]:
                        # Inside the block, we need both the item itself and its fields.
                        # "names that do not begin with . are still looked up in data"
                        inner_output = parse_and_render(inner_tokens, item, depth + 1)
                        output.append("".join(inner_output))
                    idx = end_idx + 1
                elif content == '/each':
                    raise ValueError("Unexpected /each")
                elif content.startswith('!'):
                    # Comment {{! anything }}
                    idx += 1
                else:
                    if depth == 0 and content.startswith('.'):
                        raise ValueError("Dot path outside block")
                    try:
                        val = get_value(content, current_data)
                        output.append(str(val))
                    except KeyError as e:
                        # The prompt says "KeyError whose single argument is the placeholder's name exactly as it was written"
                        raise e
                    idx += 1
            else:
                idx += 1
        return output

    return "".join(parse_and_render(tokens, data))

