from typing import Dict, List

def plan(jobs: Dict[str, List[str]]) -> List[str]:
    # Identify all unique job names
    all_jobs = set(jobs.keys())
    for deps in jobs.values():
        for dep in deps:
            all_jobs.add(dep)
    
    # Build adjacency list and in-degree count
    # Note: The input `jobs` is "job -> [prerequisites]"
    # We want to find an order such that prerequisites come before the job.
    # This is a topological sort on the graph where edges are prerequisite -> job.
    adj = {job: [] for job in all_jobs}
    in_degree = {job: 0 for job in all_jobs}
    
    for job, deps in jobs.items():
        for dep in deps:
            # Edge is dep -> job (dep must finish before job)
            adj[dep].append(job)
            in_degree[job] += 1
            
    # Kahn's algorithm for topological sort
    # To ensure deterministic output, we use a sorted list or heap of available jobs.
    # The goal says "running the planner twice on the same table gives the same order".
    # Sorting the initial candidates and maintaining sorted order is sufficient.
    queue = sorted([job for job in all_jobs if in_degree[job] == 0])
    result = []
    
    while queue:
        u = queue.pop(0)
        result.append(u)
        
        for v in adj[u]:
            in_degree[v] -= 1
            if in_degree[v] == 0:
                # Insert into sorted list to maintain order
                import bisect
                bisect.insort(queue, v)
                
    if len(result) != len(all_jobs):
        raise ValueError("Cycle detected or unreachable jobs")
        
    return result

