import solution

def check_unclosed_placeholder():
    try:
        solution.render("Hello {{name", {})
        assert False, "Should have raised ValueError for unclosed placeholder"
    except ValueError as e:
        assert str(e) == "Unclosed placeholder"

def check_empty_placeholder():
    try:
        solution.render("Hello {{}}", {})
        assert False, "Should have raised ValueError for empty placeholder"
    except ValueError as e:
        assert str(e) == "Empty placeholder"

def check_nested_each():
    try:
        solution.render("{{#each a}}{{#each b}}{{/each}}{{/each}}", {"a": [1]})
        assert False, "Should have raised ValueError for nested repeat"
    except ValueError as e:
        assert str(e) == "Nested repeat"

def check_unclosed_each():
    try:
        solution.render("{{#each a}}...", {"a": [1]})
        assert False, "Should have raised ValueError for unclosed each block"
    except ValueError as e:
        assert str(e) == "Unclosed each block"

def check_unopened_each():
    try:
        solution.render("...{{/each}}", {"a": [1]})
        assert False, "Should have raised ValueError for closing repeat with nothing to close"
    except ValueError as e:
        assert str(e) == "Closing repeat with nothing to close"

def check_non_list_repeat():
    try:
        solution.render("{{#each a}}...", {"a": 1})
        assert False, "Should have raised ValueError for repeat over non-list"
    except ValueError as e:
        assert str(e) == "Repeat over non-list"

def check_comment():
    res = solution.render("Hello {{! comment}} world", {})
    assert res == "Hello  world"

def check_escaped_braces():
    res = solution.render("Literal \\{{ and {{name}}", {"name": "Ann"})
    assert res == "Literal {{ and Ann"

def check_dot_path():
    data = {"items": [{"val": 1}, {"val": 2}]}
    res = solution.render("{{#each items}}{{.val}}\n{{/each}}", data)
    assert res == "1\n2\n"

def check_root_relative_in_each():
    data = {"items": [{"val": 1}, {"val": 2}], "prefix": "Pre-"}
    res = solution.render("{{#each items}}{{.val}} - {{prefix}}\n{{/each}}", data)
    assert res == "1 - Pre-\n2 - Pre-\n"

def check_nested_data():
    data = {"user": {"profile": {"name": "Bob"}}}
    res = solution.render("{{user.profile.name}}", data)
    assert res == "Bob"

def check_empty_list():
    data = {"items": []}
    res = solution.render("{{#each items}}Item{{/each}}", data)
    assert res == ""

if __name__ == "__main__":
    check_unclosed_placeholder()
    check_empty_placeholder()
    check_nested_each()
    check_unclosed_each()
    check_unopened_each()
    check_non_list_repeat()
    check_comment()
    check_escaped_braces()
    check_dot_path()
    check_root_relative_in_each()
    check_nested_data()
    check_empty_list()
