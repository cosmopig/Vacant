import re

class TemplateRenderer:
    def __init__(self, template):
        # Handle escaped braces first by replacing them with a unique sentinel
        self.template = template.replace('\\{{', '__ESCAPED_BRACE__')

    def render(self, data):
        tokens = []
        i = 0
        while i < len(self.template):
            if self.template.startswith('{{!', i):
                end_idx = self.template.find('}}', i)
                if end_idx == -1:
                    raise ValueError("Unclosed comment")
                tokens.append(('COMMENT', self.template[i+3:end_idx]))
                i = end_idx + 2
            elif self.template.startswith('{{', i):
                end_idx = self.template.find('}}', i)
                if end_idx == -1:
                    raise ValueError("Unclosed placeholder")
                content = self.template[i+2:end_idx]
                tokens.append(('TAG', content))
                i = end_idx + 2
            else:
                next_tag = self.template.find('{{', i)
                if next_tag == -1:
                    tokens.append(('TEXT', self.template[i:]))
                    break
                tokens.append(('TEXT', self.template[i:next_tag]))
                i = next_tag

        def get_val(path_str, root_data, current_item):
            path = path_str.strip()
            if not path:
                raise ValueError("Empty placeholder")
            
            if path.startswith('.'):
                # Item relative
                parts = path[1:].split('.')
                if parts == ['']: # Path was "."
                    return current_item
                val = current_item
                for p in parts:
                    if p == '': continue
                    if isinstance(val, dict) and p in val:
                        val = val[p]
                    else:
                        raise KeyError(path_str)
                return val
            else:
                # Root relative
                parts = path.split('.')
                val = root_data
                for p in parts:
                    if isinstance(val, dict) and p in val:
                        val = val[p]
                    else:
                        raise KeyError(path_str)
                return val

        def render_block(token_list, current_root_data, current_item=None):
            output = []
            idx = 0
            while idx < len(token_list):
                t_type, content = token_list[idx]
                if t_type == 'TEXT':
                    output.append(content.replace('__ESCAPED_BRACE__', '{{'))
                    idx += 1
                elif t_type == 'COMMENT':
                    idx += 1
                elif t_type == 'TAG':
                    if content.startswith('#each'):
                        match = re.match(r'^#each\s*(.*)', content)
                        if not match:
                            raise ValueError("Malformed #each tag")
                        expr = match.group(1).strip()
                        
                        if expr == "":
                            raise ValueError("Repeat over non-list")

                        try:
                            if expr.startswith('.'):
                                parts = expr[1:].split('.')
                                val = current_item
                                for p in parts:
                                    if p == '': continue
                                    val = val[p]
                            else:
                                parts = expr.split('.')
                                val = current_root_data
                                for p in parts:
                                    val = val[p]
                        except (KeyError, TypeError):
                            raise KeyError(content)

                        if not isinstance(val, list):
                            raise ValueError("Repeat over non-list")

                        sub_tokens = []
                        found_end = False
                        j = idx + 1
                        while j < len(token_list):
                            st_type, st_content = token_list[j]
                            if st_type == 'TAG':
                                if st_content.strip() == '/each':
                                    found_end = True
                                    break
                                elif st_content.startswith('#each'):
                                    raise ValueError("Nested repeat")
                            sub_tokens.append((st_type, st_content))
                            j += 1
                        
                        if not found_end:
                            raise ValueError("Unclosed each block")
                        
                        for item in val:
                            sub_output = render_block(sub_tokens, current_root_data, item)
                            output.append(sub_output)
                        
                        idx = j + 1
                    elif content == '/each':
                        raise ValueError("Closing repeat with nothing to close")
                    else:
                        val = get_val(content, current_root_data, current_item)
                        output.append(str(val))
                        idx += 1
            return "".join(output)

        return render_block(tokens, data)

def render(template, data):
    renderer = TemplateRenderer(template)
    return renderer.render(data)
