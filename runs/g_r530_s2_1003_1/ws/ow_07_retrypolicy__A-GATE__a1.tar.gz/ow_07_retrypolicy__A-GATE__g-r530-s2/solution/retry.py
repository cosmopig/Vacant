from typing import Callable, Any, Tuple, Type
import base64

def retry(fn: Callable[[], Any], *, 
           attempts: int, 
           backoff_s: float, 
           max_backoff_s: float,
           retry_on: Tuple[Type[BaseException], ...],
           sleep: Callable[[float], None]) -> Any:
    if attempts < 1:
        raise ValueError("attempts must be at least 1")

    for k in range(1, attempts + 1):
        try:
            return fn()
        except BaseException as e:
            is_retryable = any(isinstance(e, cls) for cls in retry_on)
            
            if not is_retryable:
                raise e
            
            if k == attempts:
                # Raise the original exception without sleeping.
                raise e
            
            delay = min(backoff_s * (2 ** (k - 1)), max_backoff_s)
            sleep(delay)
