from typing import Callable, Dict, List
import collections

class RateLimiter:
    def __init__(self, window_s: float, max_events: int, clock: Callable[[], float]):
        if window_s <= 0 or max_events < 0:
            raise ValueError("Invalid configuration")
        self.window_s = window_s
        self.max_events = max_events
        self.clock = clock
        self.data: Dict[str, List[float]] = {}

    def allow(self, key: str) -> bool:
        now = self.clock()
        if key not in self.data:
            self.data[key] = []
        
        # Filter events within (now - window_s, now]
        # Note: "Events lying in the future are simply outside" 
        # means we only care about those > now - window_s AND <= now
        valid_events = [t for t in self.data[key] if now - self.window_s < t <= now]
        
        if len(valid_events) < self.max_events:
            self.data[key] = valid_events + [now]
            return True
        else:
            # Update the list to only contain valid ones for consistency, 
            # though technically we don't record a denied call.
            # The contract says "denied call records nothing".
            self.data[key] = valid_events
            return False

    def retry_after(self, key: str) -> float:
        now = self.clock()
        if key not in self.data or self.max_events == 0:
            return 0.0 if self.max_events > 0 else float('inf')
        
        valid_events = [t for t in self.data[key] if now - self.window_s < t <= now]
        if len(valid_events) < self.max_events:
            return 0.0
        
        # "leaving + window_s - now" where leaving is the earliest event to fall out
        # To admit one more, we need to remove an event. The oldest one in the window
        # will be the first to expire.
        leaving = min(valid_events)
        return leaving + self.window_s - now

    def reset(self, key: str | None = None) -> None:
        if key is None:
            self.data.clear()
        else:
            self.data.pop(key, None)
