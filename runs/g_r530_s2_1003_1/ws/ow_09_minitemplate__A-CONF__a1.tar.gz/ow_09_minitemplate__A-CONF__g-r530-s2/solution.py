import re

def render(template: str, data: dict) -> str:
    def get_value(path, context):
        if path == ".":
            return context
        parts = [p.strip() for p in path.split('.') if p.strip()]
        curr = context
        for part in parts:
            if isinstance(curr, dict) and part in curr:
                curr = curr[part]
            else:
                raise KeyError(path)
        return curr

    def parse_template(text):
        tokens = []
        i = 0
        while i < len(text):
            if text.startswith(r"\{{", i):
                if text[i:i+3] == r"\{{":
                    tokens.append(('TEXT', r"\{{"))
                    i += 3
                else:
                    j = text.find("}}", i + 2)
                    if j == -1:
                        raise ValueError("a {{ with no }} after it")
                    tag_content = text[i+2 : j].strip()
                    tokens.append(('TAG', tag_content))
                    i = j + 2
            else:
                j = text.find("{{", i)
                if j == -1:
                    tokens.append(('TEXT', text[i:]))
                    break
                tokens.append(('TEXT', text[i:j]))
                i = j
        return tokens

    def parse_recursive(tokens):
        nodes = []
        while tokens:
            t_type, content = tokens.pop(0)
            if t_type == 'TEXT':
                nodes.append(('TEXT', content))
            elif t_type == 'TAG':
                if not content:
                    raise ValueError("an empty placeholder")
                if content.startswith('!'):
                    continue
                if content.startswith('#each'):
                    block_tokens = []
                    found_closing = False
                    while tokens:
                        sub_t_type, sub_content = tokens.pop(0)
                        if sub_t_type == 'TAG':
                            if sub_content == '/each':
                                found_closing = True
                                break
                            if sub_content.startswith('#each'):
                                raise ValueError("a repeat inside a repeat")
                        block_tokens.append((sub_t_type, sub_content))
                    
                    if not found_closing:
                        raise ValueError("a {{#each}} that is never closed")
                    
                    inner_nodes = parse_recursive(block_tokens)
                    list_name = content[6:].strip()
                    nodes.append(('EACH', list_name, inner_nodes))
                elif content == '/each':
                    raise ValueError("a {{/each}} with no {{#each}} open")
                else:
                    nodes.append(('PLACEHOLDER', content))
        return nodes

    tokens = parse_template(template)
    tree = parse_recursive(tokens)

    def evaluate_recursive(node, context, is_inside_each=False):
        if node[0] == 'TEXT':
            return node[1]
        elif node[0] == 'PLACEHOLDER':
            path = node[1]
            if path.startswith('.') and not is_inside_each:
                raise ValueError("{{.}} or {{.field}} outside any block")
            
            if path == ".":
                return str(context)
            
            if path.startswith('.'):
                val = get_value(path, context)
            else:
                val = get_value(path, data)
            return str(val)
        elif node[0] == 'EACH':
            list_name = node[1]
            parts = [p.strip() for p in list_name.split('.') if p.strip()]
            curr = data
            for part in parts:
                if isinstance(curr, dict) and part in curr:
                    curr = curr[part]
                else:
                    raise KeyError(list_name)
            
            if not isinstance(curr, list):
                raise ValueError("a #each over something that is not a list")
            
            result = []
            for item in curr:
                result.append(evaluate_recursive(node[2], item, is_inside_each=True))
            return "".join(result)

    return evaluate_recursive(tree, data)

