#!/bin/bash
python3 -m unittest tests_visible/test_visible.py
