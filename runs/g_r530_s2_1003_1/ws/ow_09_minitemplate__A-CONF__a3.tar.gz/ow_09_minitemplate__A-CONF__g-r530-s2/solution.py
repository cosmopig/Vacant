import re

def render(template: str, data: dict) -> str:
    placeholder = "___LITERAL_OPEN_BRACE___"
    # The contract says \{{ renders as {{ and starts no placeholder.
    # In python string literals, \ is an escape character. 
    # If the input template is a raw string r"\{{", it contains \{ and {.
    # If it's not a raw string, like "\{{", it might be just "{".
    # However, we should treat the sequence of characters \ and { as literal {{.
    template = template.replace(r"\{{", placeholder)

    def get_value(path, current_data, item=None):
        parts = path.split('.')
        current = current_data
        for part in parts:
            if not part:
                continue
            if part == '.':
                if item is None:
                    raise KeyError(".")
                current = item
            elif isinstance(current, dict) and part in current:
                current = current[part]
            else:
                # The contract says "A name the data does not have raises KeyError whose single argument 
                # is the placeholder's name exactly as it was written."
                raise KeyError(path)
        return current

    def parse_tags(tmpl):
        tokens = []
        i = 0
        while i < len(tmpl):
            if tmpl[i] == placeholder:
                tokens.append({'type': 'literal', 'val': '{{', 'pos': i})
                i += len(placeholder)
            elif tmpl[i:i+2] == "{{":
                end = tmpl.find("}}", i + 2)
                if end == -1:
                    raise ValueError("a {{ with no }} after it")
                content = tmpl[i+2 : end].strip()
                tokens.append({'type': 'tag', 'content': content, 'pos': i})
                i = end + 2
            else:
                next_tag = -1
                for j in range(i, len(tmpl)):
                    if tmpl[j] == placeholder:
                        next_tag = j
                        break
                    if tmpl[j:j+2] == "{{":
                        next_tag = j
                        break
                if next_tag == -1:
                    tokens.append({'type': 'text', 'val': tmpl[i:], 'pos': i})
                    i = len(tmpl)
                else:
                    tokens.append({'type': 'text', 'val': tmpl[i:next_tag], 'pos': i})
                    i = next_tag
        return tokens

    tokens = parse_tags(template)
    
    def render_recursive(token_idx, current_data, in_block=False):
        result = []
        while token_idx < len(tokens):
            token = tokens[token_idx]
            if token['type'] == 'text':
                result.append(token['val'])
            elif token['type'] == 'literal':
                result.append("{{")
            elif token['type'] == 'tag':
                content = token['content']
                if not content:
                    raise ValueError("an empty placeholder")
                
                if content.startswith("!"):
                    pass
                elif content.startswith("#each"):
                    match = re.match(r"^#each\s+(.*)", content)
                    if not match:
                        raise ValueError("malformed each tag")
                    list_key = match.group(1).strip()
                    
                    if in_block:
                        raise ValueError("a {{#each}} inside another {{#each}}")
                    
                    if list_key != ".":
                        if list_key not in current_data or not isinstance(current_data[list_key], list):
                            raise ValueError("a {{#each}} over something that is not a list")
                        items = current_data[list_key]
                    else:
                        if "." not in current_data or not isinstance(current_data["."], list):
                            raise ValueError("a {{#each}} over something that is not a list")
                        items = current_data["."]

                    block_content_tokens = []
                    found_closing = False
                    j = token_idx + 1
                    while j < len(tokens):
                        next_token = tokens[j]
                        if next_token['type'] == 'tag' and next_token['content'].strip() == "/each":
                            found_closing = True
                            break
                        block_content_tokens.append(next_token)
                        j += 1
                    
                    if not found_closing:
                        raise ValueError("a {{#each}} that is never closed")
                    
                    total_block_result = ""
                    for item in items:
                        def render_block_content(tokens_to_render, data_dict, current_item):
                            res = []
                            for t in tokens_to_render:
                                if t['type'] == 'text':
                                    res.append(t['val'])
                                elif t['type'] == 'literal':
                                    res.append("{{")
                                elif t['type'] == 'tag':
                                    c = t['content']
                                    if not c: raise ValueError("an empty placeholder")
                                    if c.startswith("!"):
                                        pass
                                    elif c.startswith("#each"):
                                        raise ValueError("a {{#each}} inside another {{#each}}")
                                    else:
                                        val = get_value(c, data_dict, current_item)
                                        res.append(str(val))
                            return "".join(res)
                        
                        total_block_result += render_block_content(block_content_tokens, current_data, item)
                    
                    result.append(total_block_result)
                    token_idx = j + 1
                else:
                    if content.startswith("."):
                        raise ValueError("{{.}} or {{.field}} outside any block")
                    val = get_value(content, current_data)
                    result.append(str(val))
        return "".join(result)

    return render_recursive(0, data, False)

