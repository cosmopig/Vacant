import unittest
from solution import RateLimiter
from typing import Callable

class TestRateLimiter(unittest.TestCase):
    def test_basic_allow(self):
        clock = lambda: 100.0
        rl = RateLimiter(window_s=10, max_events=2, clock=clock)
        self.assertTrue(rl.allow("a"))
        self.assertTrue(rl.allow("a"))
        self.assertFalse(rl.allow("a"))

    def test_retry_after(self):
        # At t=100, 2 events allowed in (90, 100]
        clock = lambda: 100.0
        rl = RateLimiter(window_s=10, max_events=2, clock=clock)
        rl.allow("a") # t=100
        rl.allow("a") # t=100
        # Next allow would succeed at 110 (when first event falls out)
        self.assertEqual(rl.retry_after("a"), 10.0)

    def test_sliding_window(self):
        clock = lambda: 105.0
        rl = RateLimiter(window_s=10, max_events=2, clock=clock)
        rl.allow("a") # t=100 (but clock is 105 now? No, allow uses current clock)
        # Let's be more precise:
        times = [100.0, 101.0, 102.0]
        curr_time = 0
        def mock_clock():
            nonlocal curr_time
            return curr_time
        
        rl = RateLimiter(window_s=10, max_events=2, clock=mock_clock)
        curr_time = 100.0
        rl.allow("a") # count: [100.0]
        curr_time = 101.0
        rl.allow("a") # count: [100.0, 101.0]
        self.assertFalse(rl.allow("a")) # full
        
        # At t=102, window is (92, 102]. Events are [100.0, 101.0] -> wait until 100+10 = 110
        curr_time = 102.0
        self.assertEqual(rl.retry_after("a"), 8.0) # 110 - 102

    def test_reset(self):
        clock = lambda: 100.0
        rl = RateLimiter(window_s=10, max_events=1, clock=clock)
        rl.allow("a")
        rl.reset("a")
        self.assertTrue(rl.allow("a"))
        rl.reset()
        # "b" was never there, but reset() clears all
        self.assertTrue(rl.allow("b"))

    def test_invalid_config(self):
        clock = lambda: 100.0
        with self.assertRaises(ValueError):
            RateLimiter(window_s=0, max_events=5, clock=clock)
        with self.assertRaises(ValueError):
            RateLimiter(window_s=10, max_events=-1, clock=clock)

    def test_max_events_zero(self):
        clock = lambda: 100.0
        rl = RateLimiter(window_s=10, max_events=0, clock=clock)
        self.assertFalse(rl.allow("a"))
        self.assertEqual(rl.retry_after("a"), float('inf'))

    def test_future_events_ignored(self):
        # Clock moves backwards
        times = [100.0, 90.0]
        curr_time = 0
        def mock_clock():
            nonlocal curr_time
            return curr_time
        rl = RateLimiter(window_s=10, max_events=1, clock=mock_clock)
        curr_time = 100.0
        rl.allow("a") # history: [100.0]
        curr_time = 90.0
        # window is (80, 90]. 100.0 is outside.
        self.assertTrue(rl.allow("a"))

if __name__ == "__main__":
    unittest.main()
