from typing import Callable, Dict, List

class RateLimiter:
    def __init__(self, window_s: float, max_events: int, clock: Callable[[], float]):
        if window_s <= 0 or max_events < 0:
            raise ValueError("Invalid configuration")
        self.window_s = window_s
        self.max_events = max_events
        self.clock = clock
        self.history: Dict[str, List[float]] = {}

    def allow(self, key: str) -> bool:
        now = self.clock()
        if key not in self.history:
            self.history[key] = []
        
        # Filter history to only include events in (now - window_s, now]
        valid_events = [t for t in self.history[key] if now - self.window_s < t <= now]
        self.history[key] = valid_events
        
        if len(valid_events) < self.max_events:
            self.history[key].append(now)
            return True
        return False

    def retry_after(self, key: str) -> float:
        now = self.clock()
        if key not in self.history or self.max_events == 0:
            return 0.0 if self.max_events > 0 else float('inf')
        
        valid_events = [t for t in self.history[key] if now - self.window_s < t <= now]
        if len(valid_events) < self.max_events:
            return 0.0
        
        # The earliest event that has to fall out of the window
        # is the one at index (len(valid_events) - max_events)
        leaving = valid_events[len(valid_events) - self.max_events]
        return leaving + self.window_s - now

    def reset(self, key: str | None = None) -> None:
        if key is None:
            self.history.clear()
        else:
            self.history.pop(key, None)
