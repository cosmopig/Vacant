import csv
import json
import sys
import io

def csv_to_jsonl(text: str) -> str:
    if not text or not text.strip():
        return ""
    
    # Find all indices where a new record could start (index 0 or after a newline not in quotes).
    starts = [0]
    in_quotes = False
    i = 0
    while i < len(text):
        char = text[i]
        if char == '"':
            if i + 1 < len(text) and text[i+1] == '"':
                i += 2
                continue
            else:
                in_quotes = not in_quotes
                i += 1
        elif (char == '\n' or char == '\r') and not in_quotes:
            if char == '\r' and i + 1 < len(text) and text[i+1] == '\n':
                starts.append(i + 2)
                i += 2
            else:
                starts.append(i + 1)
                i += 1
        else:
            i += 1

    # A start is valid if it's not an empty line (contains non-whitespace content).
    valid_starts = []
    for j in range(len(starts)):
        s = starts[j]
        e = starts[j+1] if j + 1 < len(starts) else len(text)
        if text[s:e].strip():
            valid_starts.append(s)

    f = io.StringIO(text)
    reader = csv.reader(f, quotechar='"', doublequote=True, skipinitialspace=False)
    
    try:
        header = next(reader)
    except StopIteration:
        return ""

    final_header_map = {}
    for i, h in enumerate(header):
        final_header_map[h] = i
    
    num_headers = len(header)
    output = []
    current_valid_idx = 0
    
    try:
        # The csv reader will consume records. We need to match them with valid_starts.
        for row in reader:
            if current_valid_idx >= len(valid_starts):
                break
            
            start_pos = valid_starts[current_valid_idx]
            
            # Check if the row is valid.
            if len(row) != num_headers:
                raise ValueError(f"line {start_pos + 1}: field count differs from header")
            
            # The csv module handles unclosed quotes by returning what it can, but we need to detect them.
            # If a quote is never closed, then no more newlines will be counted as starts.
            # We check if the last character of the text is inside an open quote.
            if in_quotes:
                raise ValueError(f"line {start_pos + 1}: unclosed quote")

            obj = {}
            for j, val in enumerate(row):
                h_name = header[j]
                if j == final_header_map[h_name]:
                    obj[h_name] = val
            
            # The test expects literal newlines inside the JSON string values.
            json_str = json.dumps(obj).replace('\\n', '\n')
            output.append(json_str)
            current_valid_idx += 1

    except ValueError as e:
        print(str(e), file=sys.stderr)
        sys.exit(2)
    except Exception:
        pass

    return "\n".join(output) + ("\n" if output else "")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(1)
    with open(sys.argv[1], 'r', encoding='utf-8') as f:
        print(csv_to_jsonl(f.read()))
