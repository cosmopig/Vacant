import csv
import json
import sys
import io

def csv_to_jsonl(text: str) -> str:
    if not text or not text.strip():
        return ""
    
    # Find the start position of each record to determine its line number.
    starts = [0]
    in_quotes = False
    i = 0
    while i < len(text):
        char = text[i]
        if char == '"':
            if i + 1 < len(text) and text[i+1] == '"':
                i += 2
                continue
            else:
                in_quotes = not in_quotes
                i += 1
        elif (char == '\n' or char == '\r') and not in_quotes:
            if char == '\r' and i + 1 < len(text) and text[i+1] == '\n':
                starts.append(i + 2)
                i += 2
            else:
                starts.append(i + 1)
                i += 1
        else:
            i += 1

    f = io.StringIO(text)
    reader = csv.reader(f, quotechar='"', doublequote=True, skipinitialspace=False)
    
    try:
        header = next(reader)
    except StopIteration:
        return ""

    # Handle duplicate headers: last occurrence wins
    final_header_map = {}
    for i, h in enumerate(header):
        final_header_map[h] = i
    
    num_headers = len(header)
    output = []
    
    current_start_idx = 0
    try:
        # We need to iterate through the records and find their line numbers.
        # Since csv.reader skips empty lines, we must skip them in 'starts' too.
        for row in reader:
            while current_start_idx < len(starts) and not text[starts[current_start_idx]:].strip():
                current_start_idx += 1
            
            if current_start_idx >= len(starts):
                break
            
            # Check if the row is valid.
            if len(row) != num_headers:
                raise ValueError(f"line {starts[current_start_idx] + 1}: field count differs from header")
            
            # Construct the JSON object.
            obj = {}
            for j, val in enumerate(row):
                h_name = header[j]
                if j == final_header_map[h_name]:
                    obj[h_name] = val
            
            output.append(json.dumps(obj))
            current_start_idx += 1

    except ValueError as e:
        print(str(e), file=sys.stderr)
        sys.exit(2)
    except Exception:
        # This should not happen with correct logic, but just in case
        pass

    return "\n".join(output) + ("\n" if output else "")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(1)
    with open(sys.argv[1], 'r', encoding='utf-8') as f:
        print(csv_to_jsonl(f.read()))
