import unittest
from solution import csv_to_jsonl

class TestCsvToJsonl(unittest.TestCase):
    def test_basic(self):
        input_data = "name,age\nAlice,30\nBob,25"
        expected = '{"name": "Alice", "age": "30"}\n{"name": "Bob", "age": "25"}\n'
        self.assertEqual(csv_to_jsonl(input_data), expected)

    def test_empty_input(self):
        self.assertEqual(csv_to_jsonl(""), "")
        self.assertEqual(csv_to_jsonl("   \n  "), "")

    def test_duplicate_headers(self):
        input_data = "name,age,name\nAlice,30,Bob"
        expected = '{"age": "30", "name": "Bob"}\n'
        self.assertEqual(csv_to_jsonl(input_data), expected)

    def test_quoted_fields(self):
        input_data = 'name,age\n"Alice, the Great",30\n"Bob ""the Builder"",25'
        expected = '{"name": "Alice, the Great", "age": "30"}\n{"name": "Bob \"the Builder\"", "age": "25"}\n'
        self.assertEqual(csv_to_jsonl(input_data), expected)

    def test_line_breaks_in_fields(self):
        input_data = 'name,comment\nAlice,"Line 1\nLine 2"'
        expected = '{"name": "Alice", "comment": "Line 1\nLine 2"}\n'
        self.assertEqual(csv_to_jsonl(input_data), expected)

    def test_missing_fields(self):
        input_data = "name,age\nAlice,"
        expected = '{"name": "Alice", "age": ""}\n'
        self.assertEqual(csv_to_jsonl(input_data), expected)

    def test_invalid_field_count(self):
        input_data = "name,age\nAlice,30,Extra"
        with self.assertRaisesRegex(ValueError, "line 2: field count differs from header"):
            csv_to_jsonl(input_data)

    def test_unclosed_quote(self):
        input_data = 'name,comment\nAlice,"Unclosed quote'
        with self.assertRaisesRegex(ValueError, "line 2: unclosed quote"):
            csv_to_jsonl(input_data)

if __name__ == "__main__":
    unittest.main()
