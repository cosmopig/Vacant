import re

class Version:
    def __init__(self, version_str):
        # Regex for MAJOR.MINOR.PATCH[-PRERELEASE]
        # MAJOR.MINOR.PATCH must be digits.
        # PRERELEASE is dot-separated identifiers of letters, digits, hyphens.
        match = re.fullmatch(r"(\d+)\.(\d+)\.(\d+)(?:-(.*))?", version_str)
        if not match:
            raise ValueError("Invalid version format")
        
        self.major = int(match.group(1))
        self.minor = int(match.group(2))
        self.patch = int(match.group(3))
        self.prerelease = match.group(4)
        
        if self.prerelease is not None:
            # Identifiers are dot-separated
            self.parts = prerelease_split(self.prerelease)
        else:
            self.parts = []

    @staticmethod
    def prerelease_split(s):
        # Split by dots, but only if they are not part of a sequence? 
        # Actually "dot-separated identifiers".
        return s.split('.')

    def __lt__(self, other):
        if self.major != other.major:
            return self.major < other.major
        if self.minor != other.minor:
            return self.minor < other.minor
        if self.patch != other.patch:
            return self.patch < other.patch
        
        # Version with pre-release is older than version without one
        if self.prerelease is None and other.prerelease is not None:
            return True
        if self.prerelease is not None and other.prerelease is None:
            return False
        
        if self.prerelease is None and other.prerelease is None:
            return False
        
        # Both have pre-releases
        for p1, p2 in zip(self.parts, other.parts):
            is_digit1 = p1.isdigit()
            is_digit2 = p2.isdigit()
            
            if is_digit1 and is_digit2:
                v1, v2 = int(p1), int(p2)
                if v1 != v2:
                    return v1 < v2
            elif not is_digit1 and not is_digit2:
                if p1 != p2:
                    return p1 < p2
            else:
                # One is digit, one is not. All-digit identifier is older than non-digit.
                return is_digit1 # True if p1 is digit (older), False if p2 is digit (p1 newer)

        # If every shared identifier is equal, the pre-release with more identifiers is the newer one.
        return len(self.parts) < len(other.parts)

    def __eq__(self, other):
        if self.major != other.major or self.minor != other.minor or self.patch != other.patch:
            return False
        if (self.prerelease is None) != (other.prerelease is None):
            return False
        if self.prerelease is None:
            return True
        return self.parts == other.parts

    def __gt__(self, other):
        return not (self < other or self == other)

class Solution:
    def compare(self, a_str: str, b_str: str) -> int:
        a = Version(a_str)
        b = Version(b_str)
        if a < b: return -1
        if a > b: return 1
        return 0

    def satisfies(self, version_str: str, spec: str) -> bool:
        v = Version(version_str)
        conditions = [c.strip() for c in spec.split(',')]
        if not conditions or any(not c for c in conditions):
            raise ValueError("Empty condition")
        
        for cond in conditions:
            match = re.fullmatch(r"(>=|<=|>|<|==|!=)\s*(.*)", cond)
            if not match:
                raise ValueError("Invalid operator or format")
            op, target_str = match.groups()
            target = Version(target_str)
            
            if op == "==":
                if v != target: return False
            elif op == "!=":
                if v == target: return False
            elif op == ">":
                if not (v > target): return False
            elif op == ">=":
                if not (v >= target): return False
            elif op == "<":
                if not (v < target): return False
            elif op == "<=":
                if not (v <= target): return False
        return True

def prerelease_split(s):
    # This was just a placeholder, let's fix it.
    pass

