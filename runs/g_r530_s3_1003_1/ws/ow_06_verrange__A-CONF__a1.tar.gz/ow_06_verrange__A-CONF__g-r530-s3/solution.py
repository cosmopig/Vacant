import re

class Version:
    def __init__(self, version_str):
        # A version is MAJOR.MINOR.PATCH, each a run of digits, optionally followed by
        # - and a pre-release made of dot-separated identifiers drawn from letters,
        # digits and hyphens. Nothing else is a version.
        match = re.fullmatch(r"(\d+)\.(\d+)\.(\d+)(?:-(.*))?", version_str)
        if not match:
            raise ValueError("Invalid version format")
        
        self.major = int(match.group(1))
        self.minor = int(match.group(2))
        self.patch = int(match.group(3))
        self.prerelease_str = match.group(4)
        
        if self.prerelease_str is not None:
            # Identifiers are dot-separated
            self.parts = self.prerelease_str.split('.')
        else:
            self.parts = []

    def __lt__(self, other):
        if self.major != other.major:
            return self.major < other.major
        if self.minor != other.minor:
            return self.minor < other.minor
        if self.patch != other.patch:
            return self.patch < other.patch
        
        # A version carrying a pre-release is older than the same version without one.
        if self.prerelease_str is None and other.prerelease_str is not None:
            return True
        if self.prerelease_str is not None and other.prerelease_str is None:
            return False
        
        # Both have pre-releases (or both don't, but we already handled the mixed case)
        if self.prerelease_str is None and other.prerelease_str is None:
            return False

        # Two pre-releases are compared identifier by identifier: 
        # an identifier made only of digits is compared by value, 
        # any other identifier is compared by ASCII, 
        # and an all-digit identifier is older than one that is not.
        for p1, p2 in zip(self.parts, other.parts):
            is_digit1 = p1.isdigit()
            is_digit2 = p2.isdigit()
            
            if is_digit1 and is_digit2:
                v1, v2 = int(p1), int(p2)
                if v1 != v2:
                    return v1 < v2
            elif not is_digit1 and not is_digit2:
                if p1 != p2:
                    return p1 < p2
            else:
                # One is digit, one is not. All-digit identifier is older than non-digit.
                # If p1 is all-digits (is_digit1=True) and p2 is not (is_digit2=False), 
                # then p1 is older, so return True.
                return is_digit1

        # If every shared identifier is equal, the pre-release with more identifiers is the newer one.
        return len(self.parts) < len(other.parts)

    def __eq__(self, other):
        if self.major != other.major or self.minor != other.minor or self.patch != other.patch:
            return False
        if (self.prerelease_str is None) != (other.prerelease_str is None):
            return False
        if self.prerelease_str is None:
            return True
        return self.parts == other.parts

    def __gt__(self, other):
        return not (self < other or self == other)

class Solution:
    def compare(self, a_str: str, b_str: str) -> int:
        a = Version(a_str)
        b = Version(b_str)
        if a < b: return -1
        if a > b: return 1
        return 0

    def satisfies(self, version_str: str, spec: str) -> bool:
        v = Version(version_str)
        conditions = [c.strip() for c in spec.split(',')]
        if not conditions or any(not c for c in conditions):
            raise ValueError("Empty condition")
        
        for cond in conditions:
            match = re.fullmatch(r"(>=|<=|>|<|==|!=)\s*(.*)", cond)
            if not match:
                # The spec could have spaces around the operator, but the regex handles it for some cases.
                # Actually, let's just check if we can find an operator at the start.
                raise ValueError("Invalid condition")
            op, target_str = match.groups()
            target = Version(target_str)
            
            if op == "==":
                if v != target: return False
            elif op == "!=":
                if v == target: return False
            elif op == ">":
                if not (v > target): return False
            elif op == ">=":
                if not (v >= target): return False
            elif op == "<":
                if not (v < target): return False
            elif op == "<=":
                if not (v <= target): return False
        return True

