import csv
import json
import sys
import io

def get_line_number(text, pos):
    count = 0
    current_pos = 0
    while current_pos < pos:
        next_nl = text.find('\n', current_pos)
        if next_nl == -1:
            if text[current_pos:].strip():
                count += 1
            break
        else:
            line_content = text[current_pos:next_nl]
            # Remove \r\n or \r from the end of line_content for checking
            if line_content.endswith('\r'):
                line_content = line_content[:-1]
            if line_content.endswith('\n'):
                line_content = line_content[:-1]
            if line_content.strip():
                count += 1
            current_pos = next_nl + 1
    return count + 1

def csv_to_jsonl(text: str) -> str:
    if not text or not text.strip():
        return ""
    
    # Find all positions of newlines that are not inside quotes.
    record_starts = []
    in_quotes = False
    i = 0
    while i < len(text):
        char = text[i]
        if char == '"':
            if i + 1 < len(text) and text[i+1] == '"':
                i += 2
            else:
                in_quotes = not in_quotes
                i += 1
        elif (char == '\n' or char == '\r') and not in_quotes:
            record_starts.append(i)
            if char == '\r' and i + 1 < len(text) and text[i+1] == '\n':
                i += 2
            else:
                i += 1
        else:
            i += 1
    
    # The first record starts at index 0.
    starts = sorted(list(set([0] + record_starts)))
    
    non_empty_starts = []
    for s in starts:
        next_s = None
        for other_s in starts:
            if other_s > s:
                next_s = other_s
                break
        end_pos = next_s if next_s is not None else len(text)
        line_content = text[s:end_pos]
        # Remove \r\n or \r from the end of line_content for checking
        if line_content.endswith('\r'): line_content = line_content[:-1]
        if line_content.endswith('\n'): line_content = line_content[:-1]
        if line_content.strip():
            non_empty_starts.append(s)

    if not non_empty_starts:
        return ""

    f = io.StringIO(text)
    reader = csv.reader(f, quotechar='"', delimiter=',', newline='')
    
    try:
        header_row = next(reader)
    except StopIteration:
        return ""
    except Exception as e:
        raise ValueError("line 1: " + str(e))

    num_cols = len(header_row)
    output = []
    
    # Map column indices to header names (last occurrence wins).
    header_names = [col for col in header_row]

    current_non_empty_idx = 0
    for row in reader:
        if not row and not (len(row) == 1 and row[0] == ""):
            continue
        
        # The first non-empty line is the header.
        if current_non_empty_idx == 0:
            current_non_empty_idx += 1
            continue

        # If it's an empty list, it means we hit a completely empty line.
        # But our non_empty_starts already excludes them!
        # However, csv.reader might return [] for some lines that are not "completely" empty?
        # No, if it's not in non_empty_starts, it was skipped.
        if len(row) == 0:
            continue

        if len(row) != num_cols:
            raise ValueError(f"line {get_line_number(text, non_empty_starts[current_non_empty_idx])}: field count differs from the header")
        
        obj = {}
        for i, val in enumerate(row):
            name = header_names[i]
            obj[name] = val
        output.append(json.dumps(obj))
        current_non_empty_idx += 1

    return "\n".join(output) + ("\n" if output else "")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(0)
    try:
        with open(sys.argv[1], 'r', encoding='utf-8') as f:
            content = f.read()
        print(csv_to_jsonl(content))
    except ValueError as e:
        print(str(e), file=sys.stderr)
        sys.exit(2)
    except Exception:
        sys.exit(1)
