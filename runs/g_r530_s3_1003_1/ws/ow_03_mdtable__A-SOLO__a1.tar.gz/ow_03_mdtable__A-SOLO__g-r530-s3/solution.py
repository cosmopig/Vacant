import unicodedata
import re

def get_width(text):
    return sum(2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1 for ch in text)

def pad_cell(text, width):
    w = get_width(text)
    return text + " " * (max(0, width - w))

class TableRealigner:
    def __init__(self, text):
        self.lines = text.splitlines(keepends=True)
        self.result = []

    def is_separator_row(self, row_cells):
        if not row_cells: return False
        for cell in row_cells:
            stripped = cell.strip()
            if not re.fullmatch(r':?-+:??', stripped):
                return False
        return True

    def get_cells(self, line):
        cells = []
        current_cell = ""
        in_code = False
        i = 0
        while i < len(line):
            char = line[i]
            if char == '`':
                in_code = not in_code
                current_cell += char
            elif char == '\\':
                current_cell += char
                if i + 1 < len(line):
                    current_cell += line[i+1]
                    i += 1
            elif char == '|' and not in_code and (i == 0 or line[i-1] != '\\'):
                cells.append(current_cell)
                current_cell = ""
            else:
                current_cell += char
            i += 1
        cells.append(current_cell)
        return cells

    def has_separator_in_line(self, line):
        in_code = False
        for j in range(len(line)):
            if line[j] == '`': in_code = not in_code
            elif line[j] == '|' and not in_code and (j == 0 or line[j-1] != '\\'):
                return True
        return False

    def realign(self):
        i = 0
        while i < len(self.lines):
            line = self.lines[i]
            has_sep = self.has_separator_in_line(line)
            
            if has_sep and i + 1 < len(self.lines):
                next_line = self.lines[i+1]
                next_cells = self.get_cells(next_line)
                if self.is_separator_row(next_cells):
                    table_lines = []
                    curr_idx = i
                    while curr_idx < len(self.lines):
                        l = self.lines[curr_idx]
                        if l.strip() == "" or not self.has_separator_in_line(l):
                            break
                        table_lines.append(l)
                        curr_idx += 1
                    
                    self.result.extend(self._process_table(table_lines))
                    i = curr_idx
                    continue
            
            self.result.append(line)
            i += 1
        return "".join(self.result)

    def _process_table(self, table_lines):
        all_rows_cells = []
        for l in table_lines:
            all_rows_cells.append(self.get_cells(l))
        
        num_cols = max(len(row) for row in all_rows_cells)
        col_widths = [3] * num_cols
        
        for row in all_rows_cells:
            # A column's width is the widest of its non-separator cells, and never less than 3.
            for j, cell in enumerate(row):
                if j < num_cols:
                    stripped = cell.strip()
                    if not self.is_separator_row([stripped]):
                        w = get_width(stripped)
                        col_widths[j] = max(col_widths[j], w)

        def stretch_sep(cell, width):
            stripped = cell.strip()
            has_start_marker = stripped.startswith(':')
            has_end_marker = stripped.endswith(':')
            num_markers = (1 if has_start_marker else 0) + (1 if has_end_marker else 0)
            num_dashes = width - num_markers
            res = ""
            if has_start_marker: res += ":"
            res += "-" * max(0, num_dashes)
            if has_end_marker: res += ":"
            return res

        final_rows = []
        for i, row in enumerate(all_rows_cells):
            cells = []
            for j in range(num_cols):
                cell = row[j] if j < len(row) else ""
                if i == 1 and self.is_separator_row([cell.strip()]):
                    stripped = cell.strip()
                    # If it's a separator cell, stretch its dashes.
                    if re.fullmatch(r':?-+:??', stripped):
                        cells.append(stretch_sep(cell, col_widths[j]))
                    else:
                        # This shouldn't happen based on the contract but for safety:
                        cells.append(pad_cell(cell.strip(), col_widths[j]))
                else:
                    cells.append(pad_cell(cell.strip(), col_widths[j]))
            final_rows.append("| " + " | ".join(cells) + " |")
        return "".join(final_rows)

def realign(text):
    realigner = TableRealigner(text)
    return realigner.realign()
