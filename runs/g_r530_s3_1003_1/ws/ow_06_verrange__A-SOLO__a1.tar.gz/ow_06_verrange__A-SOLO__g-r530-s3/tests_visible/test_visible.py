import unittest
from solution import Version, Solution

class TestVersion(unittest.TestCase):
    def test_parsing(self):
        v = Version("1.0.0")
        self.assertEqual(v.major, 1)
        self.assertEqual(v.minor, 0)
        self.assertEqual(v.patch, 0)
        self.assertEqual(v.pre_release, [])

    def test_compare_internal(self):
        # This is for internal use to ensure Version.compare works correctly
        v1 = Version("1.0.0")
        v2 = Version("0.9.9")
        self.assertEqual(v1.compare(v2), 1)

class TestSolution(unittest.TestCase):
    def test_compare(self):
        sol = Solution()
        self.assertEqual(sol.compare("1.0.0", "0.9.9"), 1)
        self.assertEqual(sol.compare("1.10.0", "1.9.0"), 1)
        self.assertEqual(sol.compare("2.0.0", "2.0.0"), 0)
        self.assertEqual(sol.compare("1.0.0-alpha", "1.0.0"), -1)
        self.assertEqual(sol.compare("1.0.0", "1.0.0-alpha"), 1)
        # Pre-release comparison: alpha < beta
        self.assertEqual(sol.compare("1.0.0-alpha", "1.0.0-beta"), -1)
        # Pre-release comparison: rc.1 < rc.2
        self.assertEqual(sol.compare("1.0.0-rc.1", "1.0.0-rc.2"), -1)
        # Pre-release comparison: numeric vs non-numeric (all-digit is older than not)
        self.assertEqual(sol.compare("1.0.0-1", "1.0.0-a"), -1)
        # Pre-release comparison: more identifiers is newer
        self.assertEqual(sol.compare("1.0.0-alpha.1", "1.0.0-alpha"), 1)

    def test_satisfies(self):
        sol = Solution()
        self.assertTrue(sol.satisfies("1.2.3", ">=1.0.0"))
        self.assertTrue(sol.satisfies("1.2.3", ">=1.0.0, <2.0.0"))
        self.assertFalse(sol.satisfies("1.2.3", "> 2.0.0"))
        self.assertTrue(sol.satisfies("1.2.3", "==1.2.3"))
        self.assertTrue(sol.satisfies("1.2.3", "!=1.2.4"))

if __name__ == "__main__":
    unittest.main()
