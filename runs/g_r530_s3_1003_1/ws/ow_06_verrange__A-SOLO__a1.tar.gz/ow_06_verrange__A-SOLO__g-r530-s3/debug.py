import re

class Version:
    def __init__(self, version_str):
        match = re.fullmatch(r"(\d+)\.(\d+)\.(\d+)(?:-(.*))?", version_str)
        if not match:
            raise ValueError("Invalid version format")
        
        self.major = int(match.group(1))
        self.minor = int(match.group(2))
        self.patch = int(match.group(3))
        self.pre_release = []
        if match.group(4) is not None:
            parts = match.group(4).split('.')
            for part in parts:
                if not part:
                    raise ValueError("Invalid pre-release identifier")
                # Pre-release identifiers are drawn from letters, digits and hyphens.
                if not re.fullmatch(r"[a-zA-Z0-9\-]+", part):
                    raise ValueError("Invalid pre-release identifier")
                self.pre_release.append(part)

    def compare(self, other):
        if not isinstance(other, Version): return 0
        
        # Compare major, minor, patch
        for attr in ['major', 'minor', 'patch']:
            val1 = getattr(self, attr)
            val2 = getattr(other, attr)
            if val1 != val2:
                return 1 if val1 > val2 else -1
        
        # Version carrying a pre-release is older than the same version without one.
        if not self.pre_release and other.pre_release:
            return 1
        if self.pre_release and not other.pre_release:
            return -1
        if not self.pre_release and not other.pre_release:
            return 0
        
        # Two pre-releases are compared identifier by identifier
        for p1, p2 in zip(self.pre_release, other.pre_release):
            is_p1_digit = p1.isdigit()
            is_p2_digit = p2.isdigit()
            
            if is_p1_digit and is_p2_digit:
                v1 = int(p1)
                v2 = int(p2)
                if v1 != v2:
                    return 1 if v1 > v2 else -1
            elif not is_p1_digit and not is_p2_digit:
                if p1 != p2:
                    return 1 if p1 > p2 else -1
            else:
                # an all-digit identifier is older than one that is not.
                return -1 if is_p1_digit else 1
        
        # If every shared identifier is equal, the pre-release with more identifiers is the newer one.
        if len(self.pre_release) != len(other.pre_release):
            return 1 if len(self.pre_release) > len(other.pre_release) else -1
        
        return 0

v1 = Version("1.0.0")
v2 = Version("0.9.9")
print(f"v1: {v1.major}.{v1.minor}.{v1.patch}")
print(f"v2: {v2.major}.{v2.minor}.{v2.patch}")
print(f"compare: {v1.compare(v2)}")
