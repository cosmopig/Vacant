import re

class Version:
    def __init__(self, version_str):
        match = re.fullmatch(r"(\d+)\.(\d+)\.(\d+)(?:-(.*))?", version_str)
        if not match:
            raise ValueError("Invalid version format")
        
        self.major = int(match.group(1))
        self.minor = int(match.group(2))
        self.patch = int(match.group(3))
        self.pre_release = []
        if match.group(4) is not None:
            parts = match.group(4).split('.')
            for part in parts:
                if not part:
                    raise ValueError("Invalid pre-release identifier")
                # Pre-release identifiers are drawn from letters, digits and hyphens.
                if not re.fullmatch(r"[a-zA-Z0-9\-]+", part):
                    raise ValueError("Invalid pre-release identifier")
                self.pre_release.append(part)

    def __repr__(self):
        return f"({self.major}, {self.minor}, {self.patch}, {self.pre_release})"

    def compare(self, other):
        if not isinstance(other, Version): return 0
        
        # Compare major, minor, patch
        for attr in ['major', 'minor', 'patch']:
            v1 = getattr(self, attr)
            v2 = getattr(other, attr)
            if v1 != v2:
                return 1 if v1 > v2 else -1
        
        # Version carrying a pre-release is older than the same version without one.
        if not self.pre_release and other.pre_release:
            return 1
        if self.pre_release and not other.pre_release:
            return -1
        if not self.pre_release and not other.pre_release:
            return 0
        
        # Two pre-releases are compared identifier by identifier
        for p1, p2 in zip(self.pre_release, other.pre_release):
            is_p1_digit = p1.isdigit()
            is_p2_digit = p2.isdigit()
            
            if is_p1_digit and is_p2_digit:
                v1 = int(p1)
                v2 = int(p2)
                if v1 != v2:
                    return 1 if v1 > v2 else -1
            elif not is_p1_digit and not is_p2_digit:
                if p1 != p2:
                    return 1 if p1 > p2 else -1
            else:
                # an all-digit identifier is older than one that is not.
                return -1 if is_p1_digit else 1
        
        # If every shared identifier is equal, the pre-release with more identifiers is the newer one.
        if len(self.pre_release) != len(other.pre_release):
            return 1 if len(self.pre_release) > len(other.pre_release) else -1
        
        return 0

class Solution:
    def compare(self, a: str, b: str) -> int:
        v1 = Version(a)
        v2 = Version(b)
        return v1.compare(v2)

    def satisfies(self, version_str: str, spec: str) -> bool:
        version = Version(version_str)
        parts = [c.strip() for c in spec.split(',')]
        if not parts or "" in parts:
            raise ValueError("Empty condition")

        for cond in parts:
            match = re.fullmatch(r"(>=|<=|==|!=|>|<)\s*(\d+\.\d+\.\d+(?:-\S*)?)", cond)
            if not match:
                raise ValueError("Invalid condition")
            
            op = match.group(1)
            other_version_str = match.group(2)
            other_version = Version(other_version_str)
            
            res = version.compare(other_version)
            
            if op == "==":
                if res != 0: return False
            elif op == "!=":
                if res == 0: return False
            elif op == ">":
                if res <= 0: return False
            elif op == ">=":
                if res < 0: return False
            elif op == "<":
                if res >= 0: return False
            elif op == "<=":
                if res > 0: return False
        return True

