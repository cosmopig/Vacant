import unittest
from solution import csv_to_jsonl

class TestCsvToJsonl(unittest.TestCase):
    def test_basic(self):
        csv = "name,age\nAlice,30\nBob,25"
        expected = '{"name": "Alice", "age": "30"}\n{"name": "Bob", "age": "25"}\n'
        self.assertEqual(csv_to_jsonl(csv), expected)

    def test_empty_input(self):
        self.assertEqual(csv_to_jsonl(""), "")

    def test_header_only(self):
        self.assertEqual(csv_to_jsonl("name,age\n"), "")

    def test_duplicate_headers(self):
        # Last occurrence wins
        csv = "id,val,id\n1,a,2"
        expected = '{"val": "a", "id": "2"}\n'
        self.assertEqual(csv_to_jsonl(csv), expected)

    def test_quoted_fields(self):
        csv = 'name,"city, state"\n"Alice ""The Great"" Smith",New York'
        expected = '{"name": "city, state"}\n{"name": "Alice \"The Great\" Smith", "city, state": "New York"}\n'
        self.assertEqual(csv_to_jsonl(csv), expected)

    def test_line_breaks_in_fields(self):
        csv = 'id,note\n1,"Line 1\nLine 2"'
        expected = '{"id": "1", "note": "Line 1\nLine 2"}\n'
        self.assertEqual(csv_to_jsonl(csv), expected)

    def test_mixed_line_endings(self):
        csv = "a,b\r\n1,2\n3,4"
        expected = '{"a": "1", "b": "2"}\n{"a": "3", "b": "4"}\n'
        self.assertEqual(csv_to_jsonl(csv), expected)

    def test_missing_values(self):
        csv = "a,b,c\n1,,3\n,2,"
        expected = '{"a": "1", "b": "", "c": "3"}\n{"a": "", "b": "2", "c": ""}\n'
        self.assertEqual(csv_to_jsonl(csv), expected)

    def test_invalid_field_count(self):
        csv = "a,b\n1,2,3"
        with self.assertRaisesRegex(ValueError, "line 2: field count mismatch"):
            csv_to_jsonl(csv)

    def test_unclosed_quote(self):
        csv = 'name,"city'
        with self.assertRaisesRegex(ValueError, "line 1: unclosed quote"):
            csv_to_jsonl(csv)

if __name__ == "__main__":
    unittest.main()
