import csv
import json
import sys
import io

def csv_to_jsonl(text: str) -> str:
    if not text or not text.strip():
        return ""

    # Find row start positions (indices in the string).
    row_starts = []
    in_quotes = False
    i = 0
    while i < len(text):
        char = text[i]
        if char == '"':
            if in_quotes and i + 1 < len(text) and text[i+1] == '"':
                i += 2
            else:
                in_quotes = not in_quotes
                i += 1
        elif char in ('\n', '\r') and not in_quotes:
            row_starts.append(i)
            if char == '\r' and i + 1 < len(text) and text[i+1] == '\n':
                i += 2
            else:
                i += 1
        else:
            i += 1
    row_starts.append(len(text))

    # Find line numbers for each row start position.
    line_numbers = []
    for pos in row_starts[:-1]:
        ln = 1
        j = 0
        while j < pos:
            if text[j] == '\n':
                ln += 1
                j += 1
            elif text[j:j+2] == '\r\n':
                ln += 1
                j += 2
            else:
                j += 1
        line_numbers.append(ln)

    header = None
    header_len = 0
    results = []

    for i in range(len(row_starts) - 1):
        start = row_starts[i]
        end = row_starts[i+1]
        
        # A completely empty line is ignored.
        if start == end:
            continue

        # The CSV reader expects a file-like object or string.
        row_content = text[start:end]
        # If it's just a newline, ignore it as "completely empty".
        if row_content == '\n' or row_content == '\r\n':
            continue

        f = io.StringIO(row_content)
        reader = csv.reader(f)
        try:
            fields = next(reader)
        except StopIteration:
            # This happens if the line is truly empty (already checked start==end).
            continue

        if not fields and not row_content.strip():
            continue

        ln = line_numbers[i]

        if header is None:
            header = fields
            header_len = len(header)
        else:
            if len(fields) != header_len:
                raise ValueError(f"line {ln}: field count mismatch")

        # Construct the JSON object.
        obj = {}
        for idx, h in enumerate(header):
            obj[h] = fields[idx]
        results.append(obj)

    return "\n".join(json.dumps(r) for r in results) + ("\n" if results else "")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(1)
    
    try:
        with open(sys.argv[1], 'r', encoding='utf-8') as f:
            content = f.read()
        print(csv_to_jsonl(content))
    except ValueError as e:
        sys.stderr.write(str(e) + "\n")
        sys.exit(2)
    except Exception:
        sys.exit(1)
