import solution

def check_v04_file_sections():
    """Check that sections are handled correctly."""
    defaults = {"db.host": "localhost", "db.port": 5432, "other.key": "val"}
    file_text = """
    [db]
    host = remote
    port = 9999
    
    # comment
    other.key = file_val
    """
    config = solution.load(defaults, file_text, {})
    assert config.get("db.host") == "remote"
    assert config.get("db.port") == 9999
    assert config.get("other.key") == "file_val"

def check_v05_env_case_insensitivity():
    """Check that environment variables are case-insensitive after APP_ prefix."""
    defaults = {"db.host": "localhost", "db.port": 5432}
    # APP_DB__PORT -> db.port
    # APP_db__host -> db.host
    env = {"APP_DB__PORT": "1000", "APP_db__host": "remote"}
    config = solution.load(defaults, None, env)
    assert config.get("db.port") == 1000
    assert config.get("db.host") == "remote"

def check_v06_ignore_typos():
    """Check that typos in keys are ignored."""
    defaults = {"valid.key": "val"}
    file_text = "invalid.key = val\nwrong.key = val"
    config = solution.load(defaults, file_text, {})
    assert config.as_dict() == {"valid.key": "val"}

def check_v07_no_file():
    """Check that None for file_text works."""
    defaults = {"key": 1}
    config = solution.load(defaults, None, {})
    assert config.get("key") == 1
    assert config.source("key") == "default"

def check_v08_float_conversion():
    """Check float conversion."""
    defaults = {"ratio": 0.5}
    file_text = "ratio = 1.234"
    config = solution.load(defaults, file_text, {})
    assert config.get("ratio") == 1.234

def check_v09_bool_conversion():
    """Check bool conversion."""
    defaults = {"enabled": True}
    file_texts = ["enabled = true", "enabled = false", "enabled = 1", "enabled = 0", "enabled = yes", "enabled = no"]
    for ft in file_texts:
        config = solution.load(defaults, ft, {})
        if "true" in ft or "1" in ft or "yes" in ft:
            assert config.get("enabled") is True
        else:
            assert config.get("enabled") is False

def check_v10_value_error():
    """Check that invalid conversions raise ValueError."""
    defaults = {"port": 80, "ratio": 0.5}
    try:
        solution.load(defaults, "port = abc", {})
    except ValueError:
        pass
    else:
        raise AssertionError("Should have raised ValueError for int conversion")

    try:
        solution.load(defaults, "ratio = abc", {})
    except ValueError:
        pass
    else:
        raise AssertionError("Should have raised ValueError for float conversion")

    try:
        solution.load(defaults, "port = 1.2", {})
    except ValueError:
        pass
    else:
        raise AssertionError("Should have raised ValueError for int conversion from float string")

if __name__ == "__main__":
    check_v04_file_sections()
    check_v05_env_case_insensitivity()
    check_v06_ignore_typos()
    check_v07_no_file()
    check_v08_float_conversion()
    check_v09_bool_conversion()
    check_v10_value_error()
