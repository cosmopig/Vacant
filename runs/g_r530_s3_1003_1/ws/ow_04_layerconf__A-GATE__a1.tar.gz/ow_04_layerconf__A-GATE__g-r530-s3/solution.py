from typing import Any, Dict, Optional

class Config:
    def __init__(self, values: Dict[str, Any], sources: Dict[str, str]):
        self._values = values
        self._sources = sources

    def get(self, key: str) -> Any:
        if key not in self._values:
            raise KeyError(key)
        return self._values[key]

    def source(self, key: str) -> str:
        if key not in self._sources:
            raise KeyError(key)
        return self._sources[key]

    def as_dict(self) -> Dict[str, Any]:
        return self._values.copy()


def _convert_value(val: str, target_type: type) -> Any:
    if target_type is bool:
        normalized = val.lower()
        if normalized in ("true", "1", "yes"):
            return True
        if normalized in ("false", "0", "no"):
            return False
        raise ValueError(f"Cannot convert {val} to bool")
    elif target_type is int:
        try:
            # The spec says a value that cannot be turned into the right kind of thing must fail loudly.
            # Python's int() handles strings like " 123 ", but not "1.0".
            return int(val)
        except ValueError:
            raise ValueError(f"Cannot convert {val} to int")
    elif target_type is float:
        try:
            return float(val)
        except ValueError:
            raise ValueError(f"Cannot convert {val} to float")
    else:
        # For str, it's already a string.
        return val


def load(defaults: Dict[str, Any], file_text: Optional[str], env: Dict[str, str]) -> Config:
    values = {}
    sources = {}

    # Initialize with defaults
    for key in defaults:
        values[key] = defaults[key]
        sources[key] = "default"

    # Process file
    if file_text is not None:
        current_section = ""
        lines = file_text.splitlines()
        for line in lines:
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            if stripped.startswith("[") and stripped.endswith("]"):
                # "A line of the form [name] opens a section, and every key after it becomes name.key"
                current_section = stripped[1:-1].strip() + "."
            elif "=" in stripped:
                parts = stripped.split("=", 1)
                key_part = parts[0].strip()
                val_part = parts[1].strip()
                
                # The spec says "every key after it becomes name.key"
                full_key = (current_section + key_part).strip()
                if full_key in defaults:
                    try:
                        converted = _convert_value(val_part, type(defaults[full_key]))
                        values[full_key] = converted
                        sources[full_key] = "file"
                    except ValueError as e:
                        raise ValueError(str(e))
            else:
                # Line that is neither of those and contains no `=` is ignored.
                continue

    # Process environment variables
    for env_key, env_val in env.items():
        if not env_key.startswith("APP_"):
            continue
        
        # APP_DB__PORT -> db.port
        # Remove prefix "APP_"
        rest = env_key[4:] # "DB__PORT"
        # Replace "__" with "." and lowercase
        normalized_key = rest.replace("__", ".").lower()
        
        if normalized_key in defaults:
            try:
                converted = _convert_value(env_val, type(defaults[normalized_key]))
                values[normalized_key] = converted
                sources[normalized_key] = "env"
            except ValueError as e:
                raise ValueError(str(e))

    return Config(values, sources)
