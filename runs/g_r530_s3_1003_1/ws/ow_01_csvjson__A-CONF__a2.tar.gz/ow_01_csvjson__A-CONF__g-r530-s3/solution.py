import csv
import json
import sys
import io

def csv_to_jsonl(text: str) -> str:
    # A completely empty line is ignored. 
    # This means we should ignore lines that contain only \n or \r\n.
    # However, if a line break is inside quotes, it's not an empty line.
    # The csv module handles this correctly. If we use csv.reader(io.StringIO(text)), 
    # and the input is:
    # row1_col1,row1_col2\n
    # \n
    # row2_col1,row2_col2\n
    # The reader will yield ['row1_col1', 'row1_col2'], then [], then ['row2_col1', 'row2_col2'].
    # We can just skip the empty lists.

    f = io.StringIO(text)
    reader = csv.reader(f)
    
    rows = []
    for row in reader:
        if row: # This handles "completely empty lines are ignored" (they result in [])
            rows.append(row)

    if not rows:
        return ""

    header = rows[0]
    header_map = {}
    for i, h in enumerate(header):
        header_map[h] = i

    # To handle "the header is line 1" and "completely empty lines are ignored",
    # we need to find the start position of each row.
    # Since csv.reader doesn't give us positions, let's use a custom approach:
    # We can iterate through the text and manually parse it? No, that's hard.
    # But wait! The contract says "the header is line 1". 
    # This means we can just count non-empty lines in the original text.
    # A content line is a line that is not completely empty (only \n or \r\n).

    lines = text.splitlines(keepends=True)
    content_line_indices = [i for i, l in enumerate(lines) if l.strip()]
    if not content_line_indices:
        return ""

    # Now we need to know which content line each row starts on.
    # We can use `csv.reader` and find the start position of each row.
    # To do this, let's wrap io.StringIO in a class that tracks the current position.
    
    class PositionTracker(io.TextIOBase):
        def __init__(self, text):
            self.text = text
            self.pos = 0
        def read(self, size=-1):
            chunk = self.text[self.pos : self.pos + size]
            self.pos += len(chunk)
            return chunk
        def readline(self):
            # This is a bit tricky because we need to handle \n and \r\n correctly.
            # But csv.reader uses .readline() or .read(). 
            # Actually, if we use read(), it will work fine for the CSV reader.
            return self.read(size=-1) # This is wrong for readline.

    # Let's try a different approach:
    # Since we need to know the line number of each row, and "completely empty lines are ignored",
    # let's just find all non-empty rows and their start positions in the original text.
    # Then for each row, its line number is (number of content lines before it) + 1.

    # To get the start position of each row:
    f = io.StringIO(text)
    reader = csv.reader(f)
    rows_with_pos = []
    
    # We can use f.tell() to get the current position.
    # But we need it BEFORE reading a row. 
    # Since csv.reader doesn't provide that, let's just find all non-empty rows and their positions manually? No.

    # Let's try this:
    # For each row in reader, the start position is f.tell() - length_of_row.
    # But we don't know the length of the row because it can span multiple lines.
    
    # Wait! I have a better idea. 
    # Let's use `csv.reader` and for each row, find its start position by searching in the text.
    # This is still hard if rows are identical.

    # Let's go back to basics:
    # "A completely empty line is ignored."
    # If we remove all lines that are just \n or \r\n from the original text, 
    # does it break anything? Yes, because of quotes.
    # But what if we only remove them if they are NOT inside quotes?
    # The `csv` module can tell us if we are inside quotes!

    # Let's try this:
    # 1. Read the text and find all "content lines" (lines that are not completely empty).
    # 2. For each content line, its number is its index + 1.
    # 3. Use `csv.reader` on the original text.
    # 4. For each row yielded by `csv.reader`:
    #    a. If it's empty (i.e., `[]`), skip it.
    #    b. Otherwise, find its start position in the original text.
    #    c. The line number is the index of the first content line that has a position >= this row's start position + 1.

    # This still requires finding the start position.
    pass
