import datetime
import math
from collections import defaultdict

def summarize(lines):
    endpoints = defaultdict(list)
    bad_lines = 0
    total = 0
    
    for line in lines:
        # The contract says "Any trailing newline is not part of the line."
        line = line.rstrip('\n')
        if not line or line.isspace():
            continue
        
        total += 1
        parts = line.split(' ')
        
        is_bad = False
        if len(parts) != 5:
            is_bad = True
        else:
            ts_str, method, path, status_str, ms_str = parts
            try:
                # ISO8601 check
                dt_str = ts_str.replace('Z', '+00:00')
                datetime.datetime.fromisoformat(dt_str)
                
                # Status and MS must be digits with optional leading -
                if not (status_str.lstrip('-').isdigit() and status_str != '-'):
                    is_bad = True
                elif not (ms_str.lstrip('-').isdigit() and ms_str != '-'):
                    is_bad = True
                else:
                    # Valid line
                    status = int(status_str)
                    ms = int(ms_str)
                    endpoints[path].append((status, ms))
            except ValueError:
                is_bad = True
        
        if is_bad:
            bad_lines += 1

    result_endpoints = []
    for path, data in endpoints.items():
        n = len(data)
        errors = sum(1 for status, ms in data if status >= 500)
        error_rate = round(errors / n, 4)
        
        # Sort ms for percentiles
        ms_list = sorted([ms for _, ms in data])
        
        def get_percentile(p):
            if n == 0: return 0
            idx = math.ceil(p / 100 * n)
            return ms_list[max(0, idx - 1)]

        result_endpoints.append({
            "path": path,
            "n": n,
            "error_rate": error_rate,
            "p50_ms": get_percentile(50),
            "p95_ms": get_percentile(95)
        })

    # Sort: n desc, path asc
    result_endpoints.sort(key=lambda x: (-x["n"], x["path"]))
    
    return {
        "endpoints": result_endpoints,
        "bad_lines": bad_lines,
        "total": total
    }
