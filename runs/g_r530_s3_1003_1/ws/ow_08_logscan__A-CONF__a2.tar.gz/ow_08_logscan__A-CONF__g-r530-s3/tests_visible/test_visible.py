# Test case with same n but different paths
2023-10-27T10:00:00Z GET /z 200 100
2023-10-27T10:00:01Z GET /a 200 100
