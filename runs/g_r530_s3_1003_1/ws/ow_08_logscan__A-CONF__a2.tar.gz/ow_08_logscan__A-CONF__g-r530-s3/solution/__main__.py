import sys
import json
from solution.summarize import summarize

if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(0)
    with open(sys.argv[1], 'r') as f:
        data = summarize(f)
    print(json.dumps(data))
