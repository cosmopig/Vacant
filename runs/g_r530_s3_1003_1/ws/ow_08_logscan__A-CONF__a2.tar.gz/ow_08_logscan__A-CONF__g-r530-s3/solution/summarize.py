import datetime
import math
import json
from typing import Iterable, Dict, List, Any

def summarize(lines: Iterable[str]) -> Dict[str, Any]:
    endpoints = {}
    bad_lines = 0
    total = 0

    for line in lines:
        line = line.strip('\n')
        if not line or line.isspace():
            continue
        
        total += 1
        parts = line.split(' ')
        
        # Check if exactly five fields
        if len(parts) != 5:
            bad_lines += 1
            continue
            
        ts_str, method, path, status_str, ms_str = parts
        
        # Validate Status and MS are digits with optional leading -
        def is_valid_num_str(s):
            if not s: return False
            if s[0] == '-':
                return s[1:].isdigit()
            return s.isdigit()

        if not (is_valid_num_str(status_str) and is_valid_num_str(ms_str)):
            bad_lines += 1
            continue
            
        # Validate ISO8601
        try:
            ts_to_parse = ts_str.replace('Z', '+00:00')
            datetime.datetime.fromisoformat(ts_to_parse)
        except ValueError:
            bad_lines += 1
            continue

        # If we reached here, the line is good
        status = int(status_str)
        ms = int(ms_str)
        
        if path not in endpoints:
            endpoints[path] = {"n": 0, "errors": 0, "ms_list": []}
        
        endpoints[path]["n"] += 1
        if status >= 500:
            endpoints[path]["errors"] += 1
        endpoints[path]["ms_list"].append(ms)

    result_endpoints = []
    for path, data in endpoints.items():
        n = data["n"]
        error_rate = round(data["errors"] / n, 4)
        
        ms_sorted = sorted(data["ms_list"])
        p50_idx = math.ceil(0.50 * n) - 1
        p95_idx = math.ceil(0.95 * n) - 1
        
        # Since we only add to endpoints if the line is good, n > 0 always.
        p50 = ms_sorted[p50_idx]
        p95 = ms_sorted[p95_idx]

        result_endpoints.append({
            "path": path,
            "n": n,
            "error_rate": error_rate,
            "p50_ms": p50,
            "p95_ms": p95
        })

    # Sort: primary n desc, secondary path asc
    result_endpoints.sort(key=lambda x: (-x["n"], x["path"]))

    return {
        "endpoints": result_endpoints,
        "bad_lines": bad_lines,
        "total": total
    }

if __name__ == "__main__":
    import sys
    import json
    
    if len(sys.argv) < 2:
        sys.exit(0)
        
    with open(sys.argv[1], 'r') as f:
        data = summarize(f)
    print(json.dumps(data))
