import unittest
from solution import Version

class TestVersion(unittest.TestCase):
    def test_compare(self):
        self.assertEqual(Version("1.2.3").compare("1.2.3"), 0)
        self.assertEqual(Version("1.2.3").compare("1.2.4"), -1)
        self.assertEqual(Version("1.2.4").compare("1.2.3"), 1)
        self.assertEqual(Version("1.10.0").compare("1.9.0"), 1)
        self.assertEqual(Version("2.0.0").compare("1.9.9"), 1)

    def test_pre_release_basic(self):
        # A version carrying a pre-release is older than the same version without one.
        self.assertEqual(Version("1.0.0-alpha").compare("1.0.0"), -1)
        self.assertEqual(Version("1.0.0").compare("1.0.0-alpha"), 1)

    def test_pre_release_comparison(self):
        # Two pre-releases of the same version also have to sort among themselves:
        # rc.2 comes after rc.1, alpha comes before beta, and a pre-release with more parts is newer than the same pre-release with fewer.
        self.assertEqual(Version("1.0.0-rc.1").compare("1.0.0-rc.2"), -1)
        self.assertEqual(Version("1.0.0-alpha").compare("1.0.0-beta"), -1)
        self.assertEqual(Version("1.0.0-a").compare("1.0.0-aa"), -1) # alpha comes before beta, but also ascii comparison

    def test_pre_release_numeric(self):
        # an identifier made only of digits is compared by value, any other identifier is compared by ASCII, and an all-digit identifier is older than one that is not.
        self.assertEqual(Version("1.0.0-1").compare("1.0.0-2"), -1)
        self.assertEqual(Version("1.0.0-alpha").compare("1.0.0-1"), 1) # alpha (non-digit) vs 1 (digit). Wait, "an all-digit identifier is older than one that is not". So 1 < alpha.

    def test_pre_release_length(self):
        # If every shared identifier is equal, the pre-release with more identifiers is the newer one.
        self.assertEqual(Version("1.0.0-rc.1").compare("1.0.0-rc.1.1"), -1)

    def test_invalid_versions(self):
        with self.assertRaises(ValueError):
            Version("1.2")
        with self.assertRaises(ValueError):
            Version("1.a.3")
        with self.assertRaises(ValueError):
            Version("v1.0.0")

if __name__ == "__main__":
    unittest.main()
