import re

class Version:
    def __init__(self, version_str):
        # A version is `MAJOR.MINOR.PATCH`, each a run of digits, optionally followed by `-` and a pre-release
        # made of dot-separated identifiers drawn from letters, digits and hyphens. Nothing else is a version.
        match = re.fullmatch(r"(\d+)\.(\d+)\.(\d+)(?:-(.*))?", version_str)
        if not match:
            raise ValueError("Invalid version format")

        self.major = int(match.group(1))
        self.minor = int(match.group(2))
        self.patch = int(match.group(3))
        self.pre_release = match.group(4)
        
        if self.pre_release is not None:
            # Pre-release must be dot-separated identifiers drawn from letters, digits and hyphens.
            # If it's empty (e.g., "1.0.0-"), it should be invalid based on the description?
            # "made of dot-separated identifiers" implies at least one identifier.
            if not self.pre_release:
                raise ValueError("Empty pre-release")
            self.pre_release_parts = self.pre_release.split('.')
        else:
            self.pre_release_parts = None

    def compare(self, other):
        # The contract says solution.compare(a: str, b: str) -> int
        # and the tests call Version("...").compare("...")
        if not isinstance(other, Version):
            other_v = Version(other)
        else:
            other_v = other

        if self.major != other_v.major:
            return 1 if self.major > other_v.major else -1
        if self.minor != other_v.minor:
            return 1 if self.minor > other_v.minor else -1
        if self.patch != other_v.patch:
            return 1 if self.patch > other_v.patch else -1

        # A version carrying a pre-release is older than the same version without one.
        if self.pre_release is None and other_v.pre_release is not None:
            return 1
        if self.pre_release is not None and other_v.pre_release is None:
            return -1

        # Both have pre-releases or both don't.
        if self.pre_release is None and other_v.pre_release is None:
            return 0

        # Two pre-releases are compared identifier by identifier:
        # an identifier made only of digits is compared by value, any other identifier is compared by ASCII,
        # and an all-digit identifier is older than one that is not.
        # If every shared identifier is equal, the pre-release with more identifiers is the newer one.

        for p1, p2 in zip(self.pre_release_parts, other_v.pre_release_parts):
            is_p1_digit = p1.isdigit()
            is_p2_digit = p2.isdigit()

            if is_p1_digit and is_p2_digit:
                v1 = int(p1)
                v2 = int(p2)
                if v1 != v2:
                    return 1 if v1 > v2 else -1
            elif not is_p1_digit and not is_p2_digit:
                if p1 != p2:
                    return 1 if p1 > p2 else -1
            else:
                # One is digit, one is not. All-digit identifier is older than one that is not.
                return -1 if is_p1_digit else 1

        if len(self.pre_release_parts) != len(other_v.pre_release_parts):
            return 1 if len(self.pre_release_parts) > len(other_v.pre_release_parts) else -1

        return 0

def satisfies(version_str: str, spec: str) -> bool:
    try:
        v = Version(version_str)
    except ValueError:
        raise ValueError("Invalid version")

    conditions = [c.strip() for c in spec.split(',')]
    if not conditions or any(not c for c in conditions):
        raise ValueError("Empty condition in spec")

    for cond in conditions:
        match = re.fullmatch(r"(>=|<=|>|<|==|!=)\s*(\d+\.\d+\.\d+(?:-[^\s,]+)*)", cond)
        if not match:
            raise ValueError("Invalid condition or operator")

        op = match.group(1)
        other_v_str = match.group(2)
        try:
            other_v = Version(other_v_str)
        except ValueError:
            raise ValueError("Invalid version in spec")

        cmp = v.compare(other_v)
        if op == "==":
            if cmp != 0: return False
        elif op == "!=":
            if cmp == 0: return False
        elif op == ">":
            if cmp <= 0: return False
        elif op == ">=":
            if cmp < 0: return False
        elif op == "<":
            if cmp >= 0: return False
        elif op == "<=":
            if cmp > 0: return False

    return True

class Solution:
    def compare(self, a: str, b: str) -> int:
        v1 = Version(a)
        v2 = Version(b)
        return v1.compare(v2)

    def satisfies(self, version: str, spec: str) -> bool:
        return satisfies(version, spec)

# Expose the functions/methods directly at the module level as well to satisfy different test styles
compare = Solution().compare
satisfies_func = Solution().satisfies

solution = Solution()
