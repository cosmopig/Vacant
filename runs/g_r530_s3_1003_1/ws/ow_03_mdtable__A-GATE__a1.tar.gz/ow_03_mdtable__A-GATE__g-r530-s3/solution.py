import unicodedata
import re

def get_width(text):
    return sum(2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1 for ch in text)

def is_separator_row(cells):
    for cell in cells:
        if not re.fullmatch(r":?-+:??", cell):
            return False
    return True

def get_cells_from_line(line):
    # A column separator is a | that is neither preceded by a backslash nor inside a span delimited by backticks.
    cells = []
    current_cell = ""
    in_backticks = False
    i = 0
    while i < len(line):
        char = line[i]
        if char == '`' and (i == 0 or line[i-1] != '\\'):
            in_backticks = not in_backticks
        
        if char == '|' and not in_backticks and (i == 0 or line[i-1] != '\\'):
            cells.append(current_cell)
            current_cell = ""
        else:
            current_cell += char
        i += 1
    cells.append(current_cell)
    return cells

def contains_sep(line):
    in_backticks = False
    for j in range(len(line)):
        if line[j] == '`' and (j == 0 or line[j-1] != '\\'):
            in_backticks = not in_backticks
        if line[j] == '|' and not in_backticks and (j == 0 or line[j-1] != '\\'):
            return True
    return False

def process_table(table_lines):
    all_raw_cells = []
    max_cols = 0
    for i, line in enumerate(table_lines):
        raw_cells = get_cells_from_line(line)
        # If the row starts and ends with a separator (pipe), those are boundary markers.
        if raw_cells and raw_cells[0] == "" and raw_cells[-1] == "":
            raw_cells = raw_cells[1:-1]
        all_raw_cells.append(raw_cells)
        max_cols = max(max_cols, len(raw_cells))

    col_widths = [3] * max_cols
    for i, raw_cells in enumerate(all_raw_cells):
        if i == 1 and is_separator_row([c.strip() for c in raw_cells]):
            continue
        for j, cell in enumerate(raw_cells):
            if j < max_cols:
                stripped = cell.strip()
                if not re.fullmatch(r":?-+:??", stripped):
                    col_widths[j] = max(col_widths[j], get_width(stripped))

    processed_lines = []
    for i, line in enumerate(table_lines):
        raw_cells = get_cells_from_line(line)
        if raw_cells and raw_cells[0] == "" and raw_cells[-1] == "":
            raw_cells = raw_cells[1:-1]
        
        cells = [c.strip() for c in raw_cells]
        while len(cells) < max_cols:
            cells.append("")
        
        cells = cells[:max_cols]

        row_parts = []
        for j, cell in enumerate(cells):
            if i == 1 and is_separator_row([c.strip() for c in get_cells_from_line(table_lines[i])]):
                sep_cell = cells[j]
                left_marker = ""
                right_marker = ""
                s = sep_cell
                if s.startswith(":"):
                    left_marker = ":"
                    s = s[1:]
                if s.endswith(":"):
                    right_marker = ":"
                    s = s[:-1]
                
                target_dash_len = col_widths[j] - len(left_marker) - len(right_marker)
                target_dash_len = max(0, target_dash_len)
                new_sep = left_marker + ("-" * target_dash_len) + right_marker
                row_parts.append(new_sep)
            else:
                content = cells[j]
                w = get_width(content)
                padding = " " * (col_widths[j] - w)
                row_parts.append(content + padding)
        
        processed_lines.append("| " + " | ".join(row_parts) + " |")
    return processed_lines

def realign(text):
    lines = text.splitlines(keepends=True)
    output = []
    in_code_block = None
    i = 0
    while i < len(lines):
        line = lines[i]
        if in_code_block:
            output.append(line)
            if line.startswith(('```', '~~~')):
                fence = line[:3]
                if fence == in_code_block:
                    in_code_block = None
            i += 1
            continue

        if line.startswith(('```', '~~~')):
            in_code_block = line[:3]
            output.append(line)
            i += 1
            continue

        if contains_sep(line) and i + 1 < len(lines):
            next_line = lines[i+1]
            next_cells = get_cells_from_line(next_line)
            # The rule: "A separator row is a row whose cells all match :?-+:??"
            if is_separator_row([c.strip() for c in next_cells]):
                table_lines = []
                curr_idx = i
                while curr_idx < len(lines):
                    l = lines[curr_idx]
                    if not l.strip() or not contains_sep(l):
                        break
                    table_lines.append(l)
                    curr_idx += 1
                
                if len(table_lines) >= 2:
                    processed = process_table(table_lines)
                    output.extend(processed)
                    i = curr_idx
                    continue
        
        output.append(line)
        i += 1

    return "".join(output)

if __name__ == "__main__":
    import sys
    pass
