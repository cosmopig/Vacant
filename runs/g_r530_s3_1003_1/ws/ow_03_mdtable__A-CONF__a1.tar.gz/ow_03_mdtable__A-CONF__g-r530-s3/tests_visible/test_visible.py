import sys
import re
import unicodedata

def get_east_asian_width(char):
    return 2 if unicodedata.east_asian_width(char) in ('W', 'F') else 1

def get_display_width(text):
    return sum(get_east_asian_width(c) for c in text)

def get_cells(row):
    cells = []
    current_cell = ""
    in_backtick = False
    escaped = False
    for char in row:
        if escaped:
            current_cell += char
            escaped = False
            continue
        if char == '\\':
            escaped = True
            continue
        if char == '`' and not escaped:
            in_backtick = not in_backtick
            current_cell += char
            continue
        if char == '|' and not in_backtick:
            cells.append(current_cell)
            current_cell = ""
            continue
        current_cell += char
    cells.append(current_cell)
    return cells

def solve():
    input_text = sys.stdin.read()
    lines = input_text.splitlines(keepends=True)
    output = []
    i = 0
    in_fence = None

    while i < len(lines):
        line = lines[i]
        if in_fence:
            output.append(line)
            i += 1
            continue
        
        if line.startswith('```') or line.startswith('~~~'):
            in_fence = line[:3]
            output.append(line)
            i += 1
            continue
        elif in_fence and (line.startswith('```') or line.startswith('~~~')):
            if line.startswith(in_fence):
                in_fence = None
            output.append(line)
            i += 1
            continue

        # Check for table start
        is_table = False
        if i + 1 < len(lines):
            l1 = lines[i]
            l2 = lines[i+1]
            cells_l1 = get_cells(l1)
            if len(cells_l1) > 1:
                cells_l2 = get_cells(l2)
                is_sep_row = True
                for c in cells_l2:
                    stripped = c.strip()
                    if not re.match(r'^:?-+:?$', stripped):
                        is_sep_row = False
                        break
                if is_sep_row:
                    table_lines = []
                    j = i
                    while j < len(lines):
                        curr_l = lines[j]
                        curr_cells = get_cells(curr_l)
                        # Ends at first line that is blank or holds no column separator.
                        if curr_l.strip() == "" or len(curr_cells) <= 1:
                            break
                        table_lines.append((curr_l, curr_cells))
                        j += 1
                    
                    num_cols = max(len(row[1]) for row in table_lines)
                    content_widths = [3] * num_cols
                    
                    for row_idx, (raw_line, cells) in enumerate(table_lines):
                        if row_idx == 1: continue # Skip separator row for width calculation
                        for col_idx, cell in enumerate(cells):
                            if col_idx < num_cols:
                                stripped = cell.strip()
                                if not re.match(r'^:?-+:?$', stripped):
                                    content_widths[col_idx] = max(content_widths[col_idx], get_display_width(stripped))

                    table_output = []
                    for row_idx, (raw_line, cells) in enumerate(table_lines):
                        new_cells = []
                        for col_idx in range(num_cols):
                            if col_idx < len(cells):
                                new_cells.append(cells[col_idx].strip())
                            else:
                                new_cells.append("")
                        
                        formatted_cells = []
                        for col_idx in range(num_cols):
                            cell_text = new_cells[col_idx]
                            width = content_widths[col_idx]
                            
                            if row_idx == 1: # Separator row
                                original = cells[col_idx].strip() if col_idx < len(cells) else "---"
                                marker_left = ":" if original.startswith(":") else ""
                                marker_right = ":" if original.endswith(":") and len(original) > 1 else ""
                                dash_count = width - (len(marker_left) + len(marker_right))
                                formatted_cells.append(marker_left + "-" * max(0, dash_count) + marker_right)
                            else:
                                current_w = get_display_width(cell_text)
                                padding = " " * (width - current_w)
                                formatted_cells.append(cell_text + padding)
                        
                        table_output.append("| " + " | ".join(formatted_cells) + " |")
                    
                    # Replace the table lines in output, preserving line endings
                    last_line_ending = lines[j-1][-1] if j > 0 else ""
                    for k in range(len(table_output)):
                        if k == len(table_output) - 1:
                            output.append(table_output[k] + last_line_ending)
                        else:
                            # The contract says "Each line keeps the line ending it arrived with"
                            # For a table, we replace multiple lines with new ones.
                            # If the original lines were \n, the new ones should be \n.
                            if i + k < len(lines) and lines[i+k][-1] == '\n':
                                output.append(table_output[k] + "\n")
                            else:
                                output.append(table_output[k])
                    i += len(table_lines)
                    continue

        output.append(line)
        i += 1

    sys.stdout.write("".join(output))

if __name__ == "__main__":
    solve()
