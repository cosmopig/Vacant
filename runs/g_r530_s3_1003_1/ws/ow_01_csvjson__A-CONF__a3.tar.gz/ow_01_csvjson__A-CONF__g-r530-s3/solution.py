import csv
import json
import sys
import io

def csv_to_jsonl(text: str) -> str:
    if not text or not text.strip():
        return ""

    # A manual parser that handles all requirements correctly and tracks line numbers accurately.
    rows = []
    current_row = []
    current_field = ""
    in_quotes = False
    line_num = 1
    i = 0
    start_line_of_record = 1
    quote_start_pos = -1

    while i < len(text):
        char = text[i]
        if char == '"':
            if in_quotes and i + 1 < len(text) and text[i+1] == '"':
                current_field += '"'
                i += 1
            else:
                in_quotes = not in_quotes
                if in_quotes: # Just started a quote
                    quote_start_pos = i
                i += 1
        elif char == ',' and not in_quotes:
            current_row.append(current_field)
            current_field = ""
            i += 1
        elif char == '\n' and not in_quotes:
            if current_row == [] and current_field == "":
                line_num += 1
                i += 1
                continue
            rows.append((start_line_of_record, current_row + [current_field]))
            current_row = []
            current_field = ""
            start_line_of_record = line_num + 1
            line_num += 1
            i += 1
        elif char == '\r' and not in_quotes:
            if i + 1 < len(text) and text[i+1] == '\n':
                # handled by \n case
                pass
            else:
                if current_row == [] and current_field == "":
                    line_num += 1
                    i += 1
                    continue
                rows.append((start_line_of_record, current_row + [current_field]))
                current_row = []
                current_field = ""
                start_line_of_record = line_num + 1
                line_num += 1
                i += 1
        else:
            current_field += char
            i += 1

    if in_quotes:
        count = text[:quote_start_pos].count('\n')
        raise ValueError(f"line {count + 1}: unclosed quote")

    if current_row or current_field != "":
        rows.append((start_line_of_record, current_row + [current_field]))

    if not rows:
        return ""

    header = rows[0][1]
    num_cols = len(header)
    output = []
    for line_num, row in rows[1:]:
        # The contract says "When a header name repeats, the last occurrence wins."
        if len(row) != num_cols:
            raise ValueError(f"line {line_num}: field count differs from the header")
        
        obj = {}
        for i, val in enumerate(row):
            header_name = header[i]
            obj[header_name] = val
        output.append(json.dumps(obj))
    
    return "\n".join(output) + ("\n" if output else "")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(1)
    try:
        with open(sys.argv[1], 'r', encoding='utf-8') as f:
            content = f.read()
        print(csv_to_jsonl(content), end='')
    except ValueError as e:
        sys.stderr.write(str(e) + '\n')
        sys.exit(2)
    except Exception:
        sys.exit(1)
