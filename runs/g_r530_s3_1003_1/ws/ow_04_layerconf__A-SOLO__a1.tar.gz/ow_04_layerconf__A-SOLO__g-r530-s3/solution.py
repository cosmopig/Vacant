from typing import Any

class Config:
    def __init__(self, defaults: dict, file_data: dict, env_data: dict):
        self._defaults = defaults
        self._values = {}
        self._sources = {}
        
        for key in defaults:
            val_file = file_data.get(key)
            val_env = env_data.get(key)
            
            if val_env is not None:
                try:
                    self._values[key] = self._convert(val_env, type(defaults[key]))
                    self._sources[key] = "env"
                except ValueError as e:
                    raise e
            elif val_file is not None:
                try:
                    self._values[key] = self._convert(val_file, type(defaults[key]))
                    self._sources[key] = "file"
                except ValueError as e:
                    raise e
            else:
                self._values[key] = defaults[key]
                self._sources[key] = "default"

    def _convert(self, value: Any, target_type: type) -> Any:
        if target_type is bool:
            s = str(value).lower()
            if s in ("true", "1", "yes"):
                return True
            if s in ("false", "0", "no"):
                return False
            raise ValueError(f"Cannot convert {value} to bool")
        
        try:
            if target_type is int:
                # If it's a float string like "1.0", int("1.0") fails.
                # But if the default is int, and we get "1.0" from file/env, 
                # should it be converted to 1? The contract says "cannot be turned into 
                # the right kind of thing must fail loudly". 
                # Usually int("1.0") fails in Python.
                return int(value)
            if target_type is float:
                return float(value)
            if target_type is str:
                return str(value)
        except (ValueError, TypeError):
            raise ValueError(f"Cannot convert {value} to {target_type}")

    @classmethod
    def load(cls, defaults: dict, file_text: str | None, env: dict) -> 'Config':
        file_data = {}
        if file_text:
            current_section = ""
            for line in file_text.splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if line.startswith("[") and line.endswith("]"):
                    current_section = line[1:-1].strip()
                elif "=" in line:
                    key_part, val_part = line.split("=", 1)
                    key = key_part.strip()
                    val = val_part.strip()
                    full_key = f"{current_section}.{key}" if current_section else key
                    if full_key in defaults:
                        file_data[full_key] = val
        
        env_data = {}
        for env_key, env_val in env.items():
            if env_key.upper().startswith("APP_"):
                # APP_DB__PORT -> db.port
                raw_name = env_key[4:] # Remove APP_
                processed_name = raw_name.replace("__", ".").lower()
                if processed_name in defaults:
                    env_data[processed_name] = env_val

        return cls(defaults, file_data, env_data)

    def get(self, key: str) -> Any:
        if key not in self._defaults:
            raise KeyError(key)
        return self._values[key]

    def source(self, key: str) -> str:
        if key not in self._defaults:
            raise KeyError(key)
        return self._sources[key]

    def as_dict(self) -> dict:
        return {k: v for k, v in self._values.items() if k in self._defaults}

# Make sure the class is accessible via solution.Config or just solution?
# The contract says "solution.load(...)". This implies load is a method of the module 
# OR it's a static/classmethod on a Config class that we need to expose.
# Looking at the tests, they call `solution.load`. 
# If I define `Config` and then `load = Config.load`, it should work.

def load(defaults: dict, file_text: str | None, env: dict) -> Config:
    return Config.load(defaults, file_text, env)

