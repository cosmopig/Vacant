import unicodedata
import re

def get_width(text):
    return sum(2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1 for ch in text)

def is_separator_row(cells):
    for cell in cells:
        stripped = cell.strip()
        if not re.fullmatch(r':?-+:?', stripped):
            return False
    return True

def split_line_into_cells(line):
    cells = []
    current_cell = ""
    in_code = False
    i = 0
    while i < len(line):
        char = line[i]
        if char == '`':
            in_code = not in_code
            current_cell += char
        elif char == '|':
            if in_code:
                current_cell += char
            elif i > 0 and line[i-1] == '\\':
                current_cell += char
            else:
                cells.append(current_cell)
                current_cell = ""
        else:
            current_cell += char
        i += 1
    cells.append(current_cell)
    return cells

def has_column_separator(line):
    in_code = False
    for idx, char in enumerate(line):
        if char == '`':
            in_code = not in_code
        elif char == '|' and not in_code:
            if idx == 0 or line[idx-1] != '\\':
                return True
    return False

class Realigner:
    def realign(self, text: str) -> str:
        lines = text.splitlines(keepends=True)
        result = []
        i = 0
        while i < len(lines):
            line = lines[i]
            stripped_line = line.strip()

            # Fenced code block check
            if stripped_line.startswith("```") or stripped_line.startswith("~~~"):
                j = i + 1
                while j < len(lines) and not (lines[j].strip().startswith("```") or lines[j].strip().startswith("~~~")):
                    result.append(lines[j])
                    j += 1
                if j < len(lines):
                    # Found closing fence.
                    pass
                result.append(lines[i]) # Opening fence
                for k in range(i+1, j):
                    result.append(lines[k])
                if j < len(lines):
                    result.append(lines[j]) # Closing fence
                i = j + 1 if j < len(lines) else i + 1
                continue

            # Table check
            cells = split_line_into_cells(line)
            if has_column_separator(line):
                if i + 1 < len(lines):
                    next_line = lines[i+1]
                    next_cells = split_line_into_cells(next_line)
                    if is_separator_row(next_cells):
                        # It's a table!
                        table_lines = []
                        curr_idx = i
                        while curr_idx < len(lines):
                            l = lines[curr_idx]
                            c_cells = split_line_into_cells(l)
                            if not l.strip() or not has_column_separator(l):
                                break
                            table_lines.append((l, c_cells))
                            curr_idx += 1
                        
                        processed_table = self._process_table(table_lines)
                        result.extend(processed_table)
                        i = curr_idx
                        continue

            result.append(line)
            i += 1
        return "".join(result)

    def _format_separator(self, sep, width):
        left_marker = ":" if sep.startswith(":") else ""
        right_marker = ":" if sep.endswith(":") else ""
        num_dashes = width - len(left_marker) - len(right_marker)
        return left_marker + ("-" * num_dashes) + right_marker

    def _process_table(self, table_lines):
        max_cols = 0
        for _, cells in table_lines:
            max_cols = max(max_cols, len(cells))
        
        col_widths = [3] * max_cols
        
        # Alignment is computed from display width...
        # A column's width is the widest of its non-separator cells, and never less than 3.
        for idx, (raw_line, cells) in enumerate(table_lines):
            if idx == 0: continue # Header
            if idx == 1: continue # Separator row
            for j, cell in enumerate(cells):
                stripped = cell.strip()
                if not re.fullmatch(r':?-+:?', stripped):
                    col_widths[j] = max(col_widths[j], get_width(stripped))

        rendered_lines = []
        for idx, (raw_line, cells) in enumerate(table_lines):
            row_cells = []
            for j, cell in enumerate(cells):
                if j >= max_cols:
                    row_cells.append("")
                else:
                    stripped = cell.strip()
                    if idx == 1 and re.fullmatch(r':?-+:?', stripped):
                        row_cells.append(self._format_separator(stripped, col_widths[j]))
                    else:
                        row_cells.append(stripped)
            while len(row_cells) < max_cols:
                row_cells.append("")
            
            line_parts = []
            for j, cell in enumerate(row_cells):
                w = get_width(cell)
                padding = col_widths[j] - w
                line_parts.append(cell + (" " * padding))
            
            rendered_lines.append("| " + " | ".join(line_parts) + " |")

        final_table_lines = []
        for k in range(len(rendered_lines)):
            original_line = table_lines[k][0]
            ending = ""
            if original_line.endswith("\r\n"): ending = "\r\n"
            elif original_line.endswith("\n"): ending = "\n"
            final_table_lines.append(rendered_lines[k] + ending)

        return final_table_lines

def realign(text: str) -> str:
    return Realigner().realign(text)

if __name__ == "__main__":
    import sys
    print(realign(sys.stdin.read()))
