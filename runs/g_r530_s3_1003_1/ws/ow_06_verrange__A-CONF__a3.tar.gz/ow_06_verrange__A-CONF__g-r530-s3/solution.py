import re

class Version:
    def __init__(self, version_str):
        # A version is MAJOR.MINOR.PATCH, each a run of digits, 
        # optionally followed by - and a pre-release made of dot-separated identifiers drawn from letters, digits and hyphens. Nothing else is a version.
        pattern = r'^(\d+)\.(\d+)\.(\d+)(?:-(.*))?$'
        match = re.match(pattern, version_str)
        if not match:
            raise ValueError("Invalid version format")
        
        self.major = int(match.group(1))
        self.minor = int(match.group(2))
        self.patch = int(match.group(3))
        self.pre_release = match.group(4)
        
        if self.pre_release is not None:
            # If there's a hyphen but nothing after it, the regex might have matched it as empty group 4.
            if self.pre_release == "":
                raise ValueError("Version ends with hyphen")
            
            parts = self.pre_release.split('.')
            self._pre_release_parts = []
            for p in parts:
                if not p or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-' for c in p):
                    raise ValueError("Invalid pre-release identifier")
                self._pre_release_parts.append(p)
        else:
            self._pre_release_parts = []

    def compare(self, other_str):
        other = Version(other_str)
        
        # The three numbers are compared as numbers, most significant first.
        if self.major != other.major:
            return 1 if self.major > other.major else -1
        if self.minor != other.minor:
            return 1 if self.minor > other.minor else -1
        if self.patch != other.patch:
            return 1 if self.patch > other.patch else -1
        
        # A version carrying a pre-release is older than the same version without one.
        if self.pre_release is None and other.pre_release is not None:
            return 1
        if self.pre_release is not None and other.pre_release is None:
            return -1
        
        # Two pre-releases of the same version also have to sort among themselves
        if self.pre_release is None and other.pre_release is None:
            return 0
        
        # Both have pre-releases
        for p1, p2 in zip(self._pre_release_parts, other._pre_release_parts):
            is_p1_digit = p1.isdigit()
            is_p2_digit = p2.isdigit()
            
            if is_p1_digit and is_p2_digit:
                v1 = int(p1)
                v2 = int(p2)
                if v1 != v2:
                    return 1 if v1 > v2 else -1
            elif not is_p1_digit and not is_p2_digit:
                if p1 != p2:
                    return 1 if p1 > p2 else -1
            else:
                # an all-digit identifier is older than one that is not.
                return -1 if is_p1_digit else 1
        
        # If every shared identifier is equal, the pre-release with more identifiers is the newer one.
        if len(self._pre_release_parts) != len(other._pre_release_parts):
            return 1 if len(self._pre_release_parts) > len(other._pre_release_parts) else -1
        
        return 0

    def satisfies(self, spec):
        conditions = [c.strip() for c in spec.split(',')]
        if not conditions or any(not c for c in conditions):
            raise ValueError("Empty condition")
        
        for cond in conditions:
            match = re.match(r'^(>=|<=|>|<|==|!=)\s*(.*)$', cond)
            if not match:
                raise ValueError("Unrecognised operator or invalid format")
            
            op = match.group(1)
            other_str = match.group(2).strip()
            other = Version(other_str)
            
            cmp = self.compare(other_str)
            
            if op == '==':
                if cmp != 0: return False
            elif op == '>':
                if cmp <= 0: return False
            elif op == '<':
                if cmp >= 0: return False
            elif op == '>=':
                if cmp < 0: return False
            elif op == '<=':
                if cmp > 0: return False
            elif op == '!=':
                if cmp == 0: return False
        return True

def compare(a: str, b: str) -> int:
    return Version(a).compare(b)

def satisfies(version: str, spec: str) -> bool:
    return Version(version).satisfies(spec)

class Solution:
    @staticmethod
    def compare(a: str, b: str) -> int:
        return Version(a).compare(b)
    
    @staticmethod
    def satisfies(version: str, spec: str) -> bool:
        return Version(version).satisfies(spec)

