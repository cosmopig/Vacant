import unittest
from solution import Version

class TestVersion(unittest.TestCase):
    def test_compare_basic(self):
        self.assertEqual(Version("1.0.0").compare("0.9.9"), 1)
        self.assertEqual(Version("1.10.0").compare("1.9.0"), 1)
        self.assertEqual(Version("2.0.0").compare("2.0.0"), 0)
        self.assertEqual(Version("1.0.0").compare("2.0.0"), -1)

    def test_pre_release_basic(self):
        # A version carrying a pre-release is older than the same version without one.
        self.assertEqual(Version("1.0.0-alpha").compare("1.0.0"), -1)
        # Two pre-releases of the same version also have to sort among themselves: rc.2 comes after rc.1, alpha comes before beta
        self.assertEqual(Version("1.0.0-rc.1").compare("1.0.0-rc.2"), -1)
        self.assertEqual(Version("1.0.0-alpha").compare("1.0.0-beta"), -1)

    def test_pre_release_complex(self):
        # an identifier made only of digits is compared by value, any other identifier is compared by ASCII, and an all-digit identifier is older than one that is not.
        self.assertEqual(Version("1.0.0-rc.1").compare("1.0.0-rc.a"), -1) # 1 is digit, a is not
        # If every shared identifier is equal, the pre-release with more identifiers is the newer one.
        self.assertEqual(Version("1.0.0-alpha.1").compare("1.0.0-alpha"), -1)

    def test_satisfies(self):
        self.assertTrue(Version("1.2.3").satisfies("> 1.0.0"))
        self.assertTrue(Version("1.2.3").satisfies(">= 1.2.3"))
        self.assertTrue(Version("1.2.3").satisfies("<= 1.5.0"))
        self.assertTrue(Version("1.2.3").satisfies("< 2.0.0"))
        self.assertTrue(Version("1.2.3").satisfies("== 1.2.3"))
        self.assertTrue(Version("1.2.3").satisfies("!= 1.0.0"))
        self.assertTrue(Version("1.2.3").satisfies("> 1.0.0, < 2.0.0"))
        self.assertTrue(Version("1.2.3").satisfies(" >= 1.0.0 , <= 1.5.0 "))

    def test_errors(self):
        with self.assertRaises(ValueError):
            Version("1.0") # Not MAJOR.MINOR.PATCH
        with self.assertRaises(ValueError):
            Version("v1.0.0")
        with self.assertRaises(ValueError):
            Version("1.0.0-alpha_beta") # Underscore not allowed
        with self.assertRaises(ValueError):
            Version("1.0.0-").satisfies("") # Empty condition
        with self.assertRaises(ValueError):
            Version("1.0.0").satisfies("unknown 1.0.0")

if __name__ == "__main__":
    unittest.main()
