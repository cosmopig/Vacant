import sys
import json
from solution import summarize

def main():
    if len(sys.argv) != 2:
        sys.exit(1)
    
    filename = sys.argv[1]
    with open(filename, 'r') as f:
        result = summarize(f)
    print(json.dumps(result))

if __name__ == "__main__":
    main()
