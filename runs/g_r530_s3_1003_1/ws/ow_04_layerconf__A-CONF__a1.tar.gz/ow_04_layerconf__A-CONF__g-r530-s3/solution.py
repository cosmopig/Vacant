from typing import Any, Dict, Optional

class Config:
    def __init__(self, defaults: Dict[str, Any], values: Dict[str, Any], sources: Dict[str, str]):
        self._defaults = defaults
        self._values = values
        self._sources = sources

    @classmethod
    def load(cls, defaults: Dict[str, Any], file_text: Optional[str], env: Dict[str, str]) -> 'Config':
        file_values = {}
        if file_text is not None:
            current_section = ""
            for line in file_text.splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if line.startswith("[") and line.endswith("]"):
                    current_section = line[1:-1].strip()
                    continue
                if "=" in line:
                    key, val = line.split("=", 1)
                    key = key.strip()
                    val = val.strip()
                    full_key = f"{current_section}.{key}" if current_section else key
                    if full_key in defaults:
                        file_values[full_key] = val

        env_values = {}
        for k, v in env.items():
            if k.startswith("APP_"):
                parts = k[4:].split("__")
                env_key = ".".join(p.lower() for p in parts)
                if env_key in defaults:
                    env_values[env_key] = v

        final_values = {}
        sources = {}
        for key in defaults:
            if key in env_values:
                try:
                    final_values[key] = cls._convert(key, env_values[key], defaults)
                    sources[key] = "env"
                except ValueError as e:
                    raise e
            elif key in file_values:
                try:
                    final_values[key] = cls._convert(key, file_values[key], defaults)
                    sources[key] = "file"
                except ValueError as e:
                    raise e
            else:
                final_values[key] = defaults[key]
                sources[key] = "default"

        return cls(defaults, final_values, sources)

    @staticmethod
    def _convert(key: str, value: str, defaults: Dict[str, Any]) -> Any:
        target_type = type(defaults[key])
        if target_type is bool:
            val_lower = value.lower()
            if val_lower in ("true", "1", "yes"):
                return True
            if val_lower in ("false", "0", "no"):
                return False
            raise ValueError(f"Cannot convert {value} to bool")
        elif target_type is int:
            try:
                return int(value)
            except ValueError:
                raise ValueError(f"Cannot convert {value} to int")
        elif target_type is float:
            try:
                return float(value)
            except ValueError:
                raise ValueError(f"Cannot convert {value} to float")
        else: # str
            return value

    def get(self, key: str) -> Any:
        if key not in self._defaults:
            raise KeyError(key)
        return self._values[key]

    def source(self, key: str) -> str:
        if key not in self._defaults:
            raise KeyError(key)
        return self._sources[key]

    def as_dict(self) -> Dict[str, Any]:
        return self._values

# Expose load at the module level to satisfy contract.load(...) if needed, 
# but usually it's better to have it on Config or just a function in solution.py.
# The contract says "solution.load", so let's make sure it exists as a function too.
def load(defaults: Dict[str, Any], file_text: Optional[str], env: Dict[str, str]) -> Config:
    return Config.load(defaults, file_text, env)
