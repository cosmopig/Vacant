import re

class Version:
    def __init__(self, version_str):
        # Regex for MAJOR.MINOR.PATCH[-PRERELEASE]
        pattern = r'^(\d+)\.(\d+)\.(\d+)(?:-(.*))?$'
        match = re.match(pattern, version_str)
        if not match:
            raise ValueError("Invalid version format")
        
        self.major = int(match.group(1))
        self.minor = int(match.group(2))
        self.patch = int(match.group(3))
        self.prerelease = match.group(4)
        
        # Validate prerelease if it exists
        if self.prerelease is not None:
            parts = self.prerelease.split('.')
            for part in parts:
                if not part or not all(c.isalnum() or c == '-' for c in part):
                    raise ValueError("Invalid prerelease identifier")

    def __lt__(self, other):
        if not isinstance(other, Version):
            return NotImplemented
        if self.major != other.major:
            return self.major < other.major
        if self.minor != other.minor:
            return self.minor < other.minor
        if self.patch != other.patch:
            return self.patch < other.patch
        
        # Version with pre-release is older than version without one
        if self.prerelease is None and other.prerelease is not None:
            return False # self (no prerelease) > other (with prerelease)
        if self.prerelease is not None and other.prerelease is None:
            return True  # self < other
        
        if self.prerelease is None and other.prerelease is None:
            return False # equal
        
        # Both have prereleases
        self_parts = self.prerelease.split('.')
        other_parts = other.prerelease.split('.')
        
        for s, o in zip(self_parts, other_parts):
            s_is_digit = s.isdigit()
            o_is_digit = o.isdigit()
            
            if s_is_digit and o_is_digit:
                sv = int(s)
                ov = int(o)
                if sv != ov:
                    return sv < ov
            elif s_is_digit: # self is digit, other is not
                return True # all-digit identifier is older than one that is not
            elif o_is_digit: # self is not, other is digit
                return False
            else: # both are non-digits
                if s != o:
                    return s < o
        
        return len(self_parts) < len(other_parts)

    def __gt__(self, other):
        if not isinstance(other, Version):
            return NotImplemented
        return other < self

    def __eq__(self, other):
        if not isinstance(other, Version):
            return False
        return (self.major == other.major and 
                self.minor == other.minor and 
                self.patch == other.patch and 
                self.prerelease == other.prerelease)

    def __le__(self, other):
        if not isinstance(other, Version):
            return NotImplemented
        return self < other or self == other

    def __ge__(self, other):
        if not isinstance(other, Version):
            return NotImplemented
        return self > other or self == other

class Solution:
    @staticmethod
    def compare(a_str, b_str):
        v1 = Version(a_str)
        v2 = Version(b_str)
        if v1 < v2: return -1
        if v1 > v2: return 1
        return 0

    @staticmethod
    def satisfies(version_str, spec):
        v = Version(version_str)
        conditions = [c.strip() for c in spec.split(',')]
        if not conditions or any(not c for c in conditions):
            raise ValueError("Empty condition")
            
        ops = {'>=': lambda x, y: x >= y, 
                '>': lambda x, y: x > y, 
                '<=': lambda x, y: x <= y, 
                '<': lambda x, y: x < y, 
                '==': lambda x, y: x == y, 
                '!=': lambda x, y: x != y}

        for cond in conditions:
            matched_op = None
            sorted_ops = sorted(ops.keys(), key=len, reverse=True)
            for op in sorted_ops:
                if cond.startswith(op):
                    matched_op = op
                    break
            
            if matched_op is None:
                raise ValueError("Unrecognised operator")
            
            v_str = cond[len(matched_op):].strip()
            if not v_str:
                raise ValueError("Missing version in condition")
            
            v2 = Version(v_str)
            
            res = False
            if matched_op == '==': res = (v == v2)
            elif matched_op == '!=': res = (v != v2)
            elif matched_op == '>':  res = (v > v2)
            elif matched_op == '<':  res = (v < v2)
            elif matched_op == '>=': res = (v >= v2)
            elif matched_op == '<=': res = (v <= v2)
            
            if not res:
                return False
        return True

