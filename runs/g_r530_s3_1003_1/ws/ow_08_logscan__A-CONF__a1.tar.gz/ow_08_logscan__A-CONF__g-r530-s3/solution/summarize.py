import datetime
import math
from collections import defaultdict
from typing import Iterable

def summarize(lines: Iterable[str]) -> dict:
    endpoints = defaultdict(list)
    bad_lines = 0
    total = 0
    
    for line in lines:
        line = line.rstrip('\n')
        if not line or line.isspace():
            continue
        
        total += 1
        parts = line.split(' ')
        
        is_bad = False
        if len(parts) != 5:
            is_bad = True
        else:
            ts_str, method, path, status_str, ms_str = parts
            try:
                # ISO8601 check
                dt_str = ts_str.replace('Z', '+00:00')
                datetime.datetime.fromisoformat(dt_str)
                
                def is_valid_num(s):
                    if s == "" or s == "-": return False
                    # Check if it's a run of digits with an optional leading -
                    # The contract says "run of digits with an optional leading -"
                    # This means something like "-123" or "123". 
                    # If there is a leading -, the rest must be all digits.
                    if s.startswith('-'):
                        return s[1:].isdigit()
                    else:
                        return s.isdigit()

                if not is_valid_num(status_str) or not is_valid_num(ms_str):
                    is_bad = True
                else:
                    # Valid line
                    status = int(status_str)
                    ms = int(ms_str)
                    endpoints[path].append((status, ms))
            except ValueError:
                is_bad = True
        
        if is_bad:
            bad_lines += 1

    results = []
    for path, data in endpoints.items():
        n = len(data)
        errors = sum(1 for s, m in data if s >= 500)
        error_rate = round(errors / n, 4)
        
        ms_list = sorted([m for s, m in data])
        p50 = ms_list[math.ceil(0.50 * n) - 1]
        p95 = ms_list[math.ceil(0.95 * n) - 1]
        
        results.append({
            "path": path,
            "n": n,
            "error_rate": error_rate,
            "p50_ms": p50,
            "p95_ms": p95
        })

    # Sort: n desc, then path asc
    results.sort(key=lambda x: (-x["n"], x["path"]))
    
    return {
        "endpoints": results,
        "bad_lines": bad_lines,
        "total": total
    }
