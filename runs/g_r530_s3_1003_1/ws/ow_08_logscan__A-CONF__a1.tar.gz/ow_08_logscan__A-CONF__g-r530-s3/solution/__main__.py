import sys
import json
from .summarize import summarize

def main():
    if len(sys.argv) != 2:
        sys.exit(1)
    with open(sys.argv[1], 'r') as f:
        print(json.dumps(summarize(f)))

if __name__ == "__main__":
    main()
