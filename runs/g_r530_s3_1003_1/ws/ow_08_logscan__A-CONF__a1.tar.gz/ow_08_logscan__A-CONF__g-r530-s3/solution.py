import sys
import json
from solution import summarize

if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(1)
    with open(sys.argv[1], 'r') as f:
        print(json.dumps(summarize(f)))
