import unicodedata
import re

def get_width(text):
    return sum(2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1 for ch in text)

def is_separator_row(cells):
    for cell in cells:
        if not re.fullmatch(r":?-+:?$", cell):
            return False
    return True

def split_line_into_cells(line, in_fenced_block=False):
    cells = []
    current_cell = ""
    in_backtick = False
    i = 0
    while i < len(line):
        char = line[i]
        if in_fenced_block:
            current_cell += char
        elif char == '`':
            in_backtick = not in_backtick
            current_cell += char
        elif in_backtick:
            current_cell += char
        elif char == '\\':
            if i + 1 < len(line):
                current_cell += line[i:i+2]
                i += 1
            else:
                current_cell += char
        elif char == '|':
            cells.append(current_cell)
            current_cell = ""
        else:
            current_cell += char
        i += 1
    cells.append(current_cell)
    return cells

def has_sep(line):
    in_backtick = False
    for idx, char in enumerate(line):
        if char == '`':
            in_backtick = not in_backtick
        elif char == '|' and not in_backtick:
            if idx == 0 or line[idx-1] != '\\':
                return True
    return False

def realign(text: str) -> str:
    lines = text.splitlines(keepends=True)
    output = []
    i = 0
    in_fenced_block = False
    fence_char = None

    while i < len(lines):
        line = lines[i]
        stripped_line = line.strip()
        
        if not in_fenced_block:
            if stripped_line.startswith("```") or stripped_line.startswith("~~~"):
                in_fenced_block = True
                fence_char = stripped_line[:3]
                output.append(line)
                i += 1
                continue
        else:
            if stripped_line.startswith(fence_char):
                in_fenced_block = False
                fence_char = None
            output.append(line)
            i += 1
            continue

        if has_sep(line) and i + 1 < len(lines):
            next_line = lines[i+1]
            next_cells = split_line_into_cells(next_line, in_fenced_block)
            if is_separator_row(next_cells):
                table_lines = []
                curr_idx = i
                while curr_idx < len(lines):
                    l = lines[curr_idx]
                    c = split_line_into_cells(l, in_fenced_block)
                    if not l.strip() or not has_sep(l):
                        break
                    table_lines.append((l, c))
                    curr_idx += 1
                
                num_cols = max(len(row[1]) for row in table_lines)
                col_widths = [3] * num_cols
                
                sep_row_indices = []
                for idx, (l, c) in enumerate(table_lines):
                    if is_separator_row(c):
                        sep_row_indices.append(idx)

                for idx, (l, cells) in enumerate(table_lines):
                    if idx not in sep_row_indices:
                        for col_idx, cell in enumerate(cells[:num_cols]):
                            w = get_width(cell.strip())
                            if w > col_widths[col_idx]:
                                col_widths[col_idx] = w
                
                new_table_lines = []
                for idx, (l, cells) in enumerate(table_lines):
                    is_sep = idx in sep_row_indices
                    row_cells = []
                    for col_idx in range(num_cols):
                        if is_sep:
                            cell_raw = cells[col_idx].strip() if col_idx < len(cells) else ""
                            m_pre = ":" if cell_raw.startswith(":") else ""
                            m_suf = ":" if (cell_raw.endswith(":") and (len(cell_raw) > 1 or not cell_raw.startswith(":"))) else ""
                            if cell_raw == ":":
                                m_pre = ":"
                                m_suf = ""
                            else:
                                m_pre = ":" if cell_raw.startswith(":") else ""
                                m_suf = ":" if cell_raw.endswith(":") and len(cell_raw) > 1 else ""

                            dash_width = col_widths[col_idx] - len(m_pre) - len(m_suf)
                            if dash_width < 0: dash_width = 0
                            cell_text = m_pre + ("-" * dash_width) + m_suf
                            row_cells.append(cell_text)
                        else:
                            cell_raw = cells[col_idx].strip() if col_idx < len(cells) else ""
                            w = get_width(cell_raw)
                            padding = " " * (max(0, col_widths[col_idx] - w))
                            row_cells.append(cell_raw + padding)
                    
                    row_str = "| " + " | ".join(row_cells) + " |"
                    new_table_lines.append(row_str + line[-1])
                
                output.extend(new_table_lines)
                i += len(table_lines)
                continue
        else:
            output.append(line)
            i += 1
    return "".join(output)

realign = realign
