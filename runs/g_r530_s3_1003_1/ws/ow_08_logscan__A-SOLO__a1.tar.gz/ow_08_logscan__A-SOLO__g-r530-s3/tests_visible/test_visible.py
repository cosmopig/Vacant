import json
from solution import summarize

def check_basic():
    lines = [
        "2023-10-27T10:00:00Z GET /api/v1/resource 200 150",
        "2023-10-27T10:00:01Z POST /api/v1/login 500 200",
        "2023-10-27T10:00:02Z GET /api/v1/resource 200 160",
        "2023-10-27T10:00:03Z GET /api/v1/other 404 50",
    ]
    result = summarize(lines)
    assert result["total"] == 4
    assert result["bad_lines"] == 0
    assert len(result["endpoints"]) == 3
    # Check sorting: /api/v1/resource (2), /api/v1/login (1), /api/v1/other (1)
    # Wait, if n is same, path order. login vs other? 'l' comes before 'o'.
    # So it should be resource, login, other.
    assert result["endpoints"][0]["path"] == "/api/v1/resource"
    assert result["endpoints"][1]["path"] == "/api/v1/login"
    assert result["endpoints"][2]["path"] == "/api/v1/other"

def check_bad_lines():
    lines = [
        "invalid line",
        "2023-10-27T10:00:00Z GET /path 200 150",
        "2023-10-27T10:00:01Z POST /path 500 abc",
        "",
        "   ",
        "2023-10-27T10:00:02Z GET /path 200 150",
    ]
    result = summarize(lines)
    # total should be 4 (invalid line, good line, bad status, empty, whitespace, good line)
    # Wait, "blank lines are just noise ... and should not count as anything at all."
    # So total is 4.
    # Bad lines: invalid line (1), bad status (2). Total bad = 2.
    assert result["total"] == 4
    assert result["bad_lines"] == 2

def check_percentiles():
    # n=3, p50 = ceil(0.5*3) = 2nd element. p95 = ceil(0.95*3) = 3rd element.
    lines = [
        "2023-10-27T10:00:00Z GET /p 200 10",
        "2023-10-27T10:00:01Z GET /p 200 20",
        "2023-10-27T10:00:02Z GET /p 200 30",
    ]
    result = summarize(lines)
    assert result["endpoints"][0]["p50_ms"] == 20
    assert result["endpoints"][0]["p95_ms"] == 30

if __name__ == "__main__":
    check_basic()
    check_bad_lines()
    check_percentiles()
