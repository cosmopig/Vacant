import sys
import json
import math
from datetime import datetime
from collections import defaultdict

def summarize(lines):
    endpoints = defaultdict(list)
    bad_lines = 0
    total = 0

    for line in lines:
        line = line.rstrip('\r\n')
        if not line or line.isspace():
            continue
        
        total += 1
        parts = line.split(' ')
        
        if len(parts) != 5:
            bad_lines += 1
            continue
            
        ts_str, method, path, status_str, ms_str = parts
        
        def is_valid_num(s):
            if not s: return False
            if s.startswith('-'):
                return s[1:].isdigit()
            return s.isdigit()

        if not is_valid_num(status_str) or not is_valid_num(ms_str):
            bad_lines += 1
            continue

        try:
            ts_fixed = ts_str
            if ts_fixed.endswith('Z'):
                ts_fixed = ts_fixed[:-1] + '+00:00'
            datetime.fromisoformat(ts_fixed)
        except ValueError:
            bad_lines += 1
            continue

        status = int(status_str)
        ms = int(ms_str)
        
        endpoints[path].append((status, ms))

    results = []
    for path, data in endpoints.items():
        n = len(data)
        errors = sum(1 for s, m in data if s >= 500)
        error_rate = round(errors / n, 4)
        
        ms_list = sorted([m for s, m in data])
        p50_idx = math.ceil(0.50 * n) - 1
        p95_idx = math.ceil(0.95 * n) - 1
        
        results.append({
            "path": path,
            "n": n,
            "error_rate": error_rate,
            "p50_ms": ms_list[p50_idx],
            "p95_ms": ms_list[p95_idx]
        })

    results.sort(key=lambda x: (-x["n"], x["path"]))

    return {
        "endpoints": results,
        "bad_lines": bad_lines,
        "total": total
    }
