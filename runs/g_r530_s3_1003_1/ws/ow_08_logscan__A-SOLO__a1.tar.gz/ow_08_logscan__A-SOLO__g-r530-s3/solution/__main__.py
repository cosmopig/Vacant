import sys
import json
from .solution import summarize

def main():
    if len(sys.argv) < 2:
        return
    with open(sys.argv[1], 'r') as f:
        print(json.dumps(summarize(f)))

if __name__ == "__main__":
    main()
