import unicodedata
import re

def get_width(text):
    return sum(2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1 for ch in text)

class TableRealigner:
    def realign(self, text: str) -> str:
        lines = text.splitlines(keepends=True)
        result = []
        i = 0
        while i < len(lines):
            line = lines[i]
            if self._is_fenced_block_start(line):
                j = i + 1
                while j < len(lines) and not self._is_fenced_block_end(lines[j]):
                    result.append(lines[j])
                    j += 1
                if j < len(lines):
                    result.append(lines[j])
                    i = j + 1
                else:
                    i = len(lines)
                continue

            if self._has_column_separator(line):
                table_lines = []
                j = i
                while j < len(lines):
                    curr_line = lines[j]
                    if not curr_line.strip() or not self._has_column_separator(curr_line):
                        break
                    table_lines.append(curr_line)
                    j += 1
                
                if len(table_lines) >= 2 and self._is_separator_row(table_lines[1]):
                    realigned_table = self._process_table(table_lines)
                    result.extend(realigned_table)
                    i = j
                else:
                    result.append(line)
                    i += 1
            else:
                result.append(line)
                i += 1
        return "".join(result)

    def _is_fenced_block_start(self, line):
        stripped = line.strip()
        return stripped.startswith("```") or stripped.startswith("~~~")

    def _is_fenced_block_end(self, line):
        stripped = line.strip()
        return stripped.startswith("```") or stripped.startswith("~~~")

    def _has_column_separator(self, line):
        in_backtick = False
        for idx, char in enumerate(line):
            if char == '`':
                in_backtick = not in_backtick
            elif char == '|' and not in_backtick:
                if idx == 0 or line[idx-1] != '\\':
                    return True
        return False

    def _split_row(self, line):
        cells = []
        in_backtick = False
        current_cell = ""
        i = 0
        while i < len(line):
            char = line[i]
            if char == '`':
                in_backtick = not in_backtick
                current_cell += char
            elif char == '|' and not in_backtick:
                if i > 0 and line[i-1] == '\\':
                    current_cell += char
                else:
                    cells.append(current_cell)
                    current_cell = ""
            else:
                current_cell += char
            i += 1
        cells.append(current_cell)
        return cells

    def _is_separator_row(self, line):
        cells = self._split_row(line)
        for cell in cells:
            stripped = cell.strip()
            if stripped == "": continue
            # The contract says :?-+:? which means any combination of :, -, and + (maybe?)
            # But standard markdown is just - and :
            if not re.fullmatch(r'^[:-]+$', stripped):
                return False
        return True

    def _process_table(self, table_lines):
        rows = []
        for line in table_lines:
            cells = self._split_row(line)
            # The contract says "Every rendered row begins with | and ends with |"
            # This means we should keep the cells as they are split.
            rows.append([c.strip() for c in cells])

        num_cols = 0
        for row in rows:
            num_cols = max(num_cols, len(row))
        
        col_widths = [3] * num_cols
        # Find widths from non-separator cells
        for row in rows:
            for i, cell in enumerate(row):
                if i < num_cols and not (cell and all(c in '-:' for c in cell)):
                    col_widths[i] = max(col_widths[i], get_width(cell))

        realigned_rows = []
        for row in rows:
            padded_row = row + [""] * (num_cols - len(row))
            new_cells = []
            for i, cell in enumerate(padded_row):
                if i < num_cols and all(c in '-:' for c in cell) and cell != "":
                    marker_start = cell.startswith(':')
                    marker_end = cell.endswith(':')
                    width = col_widths[i]
                    content_width = width - (1 if marker_start else 0) - (1 if marker_end else 0)
                    if content_width < 1: content_width = 1
                    new_cells.append(":" + "-" * content_width + ":" if marker_start and marker_end else
                                    ":" + "-" * content_width if marker_start else
                                    "-" * content_width + ":" if marker_end else
                                    "-" * content_width)
                else:
                    cell_text = padded_row[i]
                    stripped_cell = cell_text.strip()
                    width = col_widths[i]
                    padding = max(0, width - get_width(stripped_cell))
                    new_cells.append(stripped_cell + (" " * padding))

            # Row construction: "| " + padded_cell[0] + " | " + padded_cell[1] ... + " |"
            row_str = "|"
            for i, cell in enumerate(new_cells):
                if i == 0:
                    row_str += " " + cell
                else:
                    row_str += " | " + cell
            row_str += " |"
            realigned_rows.append(row_str)

        first_line_ending = table_lines[0].splitlines(keepends=True)[0][-1] if table_lines[0].splitlines(keepends=True) else ""
        return [line + first_line_ending for line in realigned_rows]

realign = TableRealigner().realign
