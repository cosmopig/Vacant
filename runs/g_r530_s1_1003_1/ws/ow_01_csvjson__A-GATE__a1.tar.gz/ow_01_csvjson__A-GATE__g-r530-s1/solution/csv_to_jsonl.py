import csv
import json
import sys
import io

def csv_to_jsonl(text: str) -> str:
    if not text or not text.strip():
        return ""
    
    # "A completely empty line is ignored."
    # This means lines that are only whitespace should be removed before we do anything else.
    lines = [line for line in text.splitlines() if line.strip()]
    if not lines:
        return ""
    
    f = io.StringIO("\n".join(lines))
    reader = csv.reader(f)
    
    try:
        header = next(reader)
    except StopIteration:
        return ""
    
    # "When a header name repeats, the last occurrence wins."
    header_indices = {}
    for i, h in enumerate(header):
        header_indices[h] = i
    
    jsonl_results = []
    # The first line of our filtered lines is the header (line 1).
    # Data rows start from "line 2".
    for i, row in enumerate(reader, start=2):
        if len(row) != len(header):
            raise ValueError(f"line {i}: field count differs from the header")
        
        obj = {}
        for j, value in enumerate(row):
            h_name = header[j]
            # Only keep the last occurrence of a header name.
            if h_name in header_indices and j == header_indices[h_name]:
                obj[h_name] = str(value)
        
        jsonl_results.append(json.dumps(obj))
    
    return "\n".join(jsonl_results) + ("\n" if jsonl_results else "")

if __name__ == "__main__":
    # The command line is driven from a shell script, so success and failure have to be distinguishable without reading the output.
    # On success the JSON Lines go to stdout and the exit code is 0. Nothing else is written to stdout.
    # On invalid input exactly one line `line <N>: <reason>` is written to stderr and the exit code is 2. Nothing is written to stdout.

    if len(sys.argv) != 2:
        sys.exit(1)
    
    try:
        with open(sys.argv[1], 'r', encoding='utf-8') as f:
            content = f.read()
        result = csv_to_jsonl(content)
        sys.stdout.write(result)
    except ValueError as e:
        sys.stderr.write(str(e) + "\n")
        sys.exit(2)
    except Exception:
        # For any other exception, we want to ensure no stack trace is shown and exit with a non-zero code.
        sys.exit(1)
