import csv
import json
import sys
import io

def csv_to_jsonl(text: str) -> str:
    # The contract says "a completely empty line is ignored".
    # However, we need to be careful about how we count lines for error reporting.
    # A record can span multiple lines if it contains a newline inside quotes.

    f = io.StringIO(text)
    reader = csv.reader(f, quotechar='"', delimiter=',', skipinitialspace=False)
    
    try:
        header = next(reader)
    except StopIteration:
        return ""

    # "When a header name repeats, the last occurrence wins."
    # This means we need to know which index corresponds to which header.
    # If there are duplicates in header, only the last one's value should be kept.
    header_len = len(header)
    
    output = []
    
    # To handle line numbers for errors:
    # We can use f.tell() if we were reading from a real file, but io.StringIO might not support it well for this purpose.
    # However, since we have the whole text as a string, we can track the position manually.
    # But csv.reader doesn't expose its current position.

    # Let's use a custom approach: 
    # We will iterate through the records and for each record, find its start position in the original text.
    # Since we know the content of each record (the fields), we could potentially search for it.
    # But that's also not reliable because values might repeat.

    # Wait! The contract says "line <N>: <reason>" where N is the 1-based line number on which the offending record starts.
    # If a record spans multiple lines, we need to know the start of THAT record.

    # Let's use a custom parser that tracks line numbers.
    # Or, let's just use csv.reader and for each row, find its starting position by 
    # keeping track of how many newlines were consumed since the last record started.

    # Actually, there is a much simpler way to get the line number:
    # We can iterate through the text and find all positions of \n.
    # Then we can use f.tell() to see where each row starts.
    # But io.StringIO's tell() returns an offset in characters (for strings).

    # Let's try this:
    # We will read the file line by line and manually parse it? No, that's hard for CSV.
    # What if we use csv.reader but wrap the string in a way that gives us the position?

    # Actually, let's just use f.tell() and see if it works with io.StringIO.
    # If not, we can use a real file-like object.
    pass

