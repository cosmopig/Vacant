from typing import Any, Dict, Optional

class Config:
    def __init__(self, defaults: Dict[str, Any], final_values: Dict[str, Any], sources: Dict[str, str]):
        self._defaults = defaults
        self._final_values = final_values
        self._sources = sources

    def get(self, key: str) -> Any:
        if key not in self._defaults:
            raise KeyError(f"Key '{key}' not found in defaults.")
        return self._final_values[key]

    def source(self, key: str) -> str:
        if key not in self._defaults:
            raise KeyError(f"Key '{key}' not found in defaults.")
        return self._sources[key]

    def as_dict(self) -> Dict[str, Any]:
        # Only return keys that are in defaults
        return {k: v for k, v in self._final_values.items() if k in self._defaults}

def load(defaults: Dict[str, Any], file_text: Optional[str], env: Dict[str, str]) -> Config:
    # final_values will store the actual values (converted to correct types)
    # sources will store where each key came from ("default", "file", or "env")
    final_values = {}
    sources = {}

    # Initialize with defaults
    for k, v in defaults.items():
        final_values[k] = v
        sources[k] = "default"

    # Process file
    if file_text is not None:
        current_section = ""
        lines = file_text.splitlines()
        for line in lines:
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            
            if stripped.startswith("[") and stripped.endswith("]"):
                # A line of the form [name] opens a section, 
                # and every key after it becomes name.key until the next section header.
                section_content = stripped[1:-1].strip()
                current_section = section_content + "." if section_content else ""
            elif "=" in stripped:
                key_part, val_part = stripped.split("=", 1)
                # The key is the current section plus the part before the first '='
                key = (current_section + key_part.strip()).strip()
                val = val_part.strip()
                
                if key in defaults:
                    final_values[key] = _convert(val, type(defaults[key]))
                    sources[key] = "file"

    # Process env
    for env_key, env_val in env.items():
        if env_key.upper().startswith("APP_"):
            # APP_DB__PORT -> db.port
            parts = env_key[4:].split("__")
            normalized_key = ".".join(p.lower() for p in parts)
            
            if normalized_key in defaults:
                final_values[normalized_key] = _convert(env_val, type(defaults[normalized_key]))
                sources[normalized_key] = "env"

    return Config(defaults, final_values, sources)

def _convert(value: str, target_type: type) -> Any:
    if target_type is bool:
        lower_val = value.lower()
        if lower_val in ("true", "1", "yes"):
            return True
        if lower_val in ("false", "0", "no"):
            return False
        raise ValueError(f"Cannot convert {value} to bool")
    elif target_type is int:
        try:
            return int(value)
        except (ValueError, TypeError):
            raise ValueError(f"Cannot convert {value} to int")
    elif target_type is float:
        try:
            return float(value)
        except (ValueError, TypeError):
            raise ValueError(f"Cannot convert {value} to float")
    else: # str
        return str(value)

if __name__ == "__main__":
    pass
