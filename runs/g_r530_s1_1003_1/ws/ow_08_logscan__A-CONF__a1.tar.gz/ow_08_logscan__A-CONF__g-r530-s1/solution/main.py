import sys
import json
from solution import summarize

def main():
    if len(sys.argv) != 2:
        return
    
    filename = sys.argv[1]
    try:
        with open(filename, 'r') as f:
            result = summarize(f)
        print(json.dumps(result))
    except Exception:
        pass

if __name__ == "__main__":
    main()
