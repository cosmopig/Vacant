import datetime
import math
import json
from typing import Iterable, Dict, List, Any

def summarize(lines: Iterable[str]) -> Dict[str, Any]:
    endpoints = {}
    bad_lines = 0
    total = 0

    for line in lines:
        # "Blank lines are just noise from the rotation script and should not count as anything at all."
        # "A line that is empty or only whitespace is not looked at: it is neither good nor bad and is not in total."
        if not line.strip():
            continue
        
        total += 1
        parts = line.split(' ')
        
        # "A line is bad when it does not have exactly five fields"
        if len(parts) != 5:
            bad_lines += 1
            continue
            
        ts_str, method, path, status_str, ms_str = parts
        
        # Validate timestamp
        try:
            dt_str = ts_str.replace('Z', '+00:00')
            datetime.datetime.fromisoformat(dt_str)
        except ValueError:
            bad_lines += 1
            continue

        # Validate status and ms (digits with optional leading -)
        def is_valid_num_str(s):
            if not s: return False
            if s[0] == '-':
                return len(s) > 1 and s[1:].isdigit()
            return s.isdigit()

        if not is_valid_num_str(status_str) or not is_valid_num_str(ms_str):
            bad_lines += 1
            continue

        try:
            status = int(status_str)
            ms = int(ms_str)
        except ValueError:
            bad_lines += 1
            continue

        if path not in endpoints:
            endpoints[path] = {"n": 0, "errors": 0, "ms_list": []}
        
        endpoints[path]["n"] += 1
        # "Failed means the server's own fault, the five-hundreds"
        if status >= 500:
            endpoints[path]["errors"] += 1
        endpoints[path]["ms_list"].append(ms)

    result_endpoints = []
    for path, data in endpoints.items():
        n = data["n"]
        # "rounded to four decimal places"
        error_rate = round(data["errors"] / n, 4)
        
        sorted_ms = sorted(data["ms_list"])
        # "the p-th percentile of n sorted values is the one at 1-based position ceil(p / 100 * n)"
        p50_idx = math.ceil(0.50 * n) - 1
        p95_idx = math.ceil(0.95 * n) - 1
        
        # Since we know n > 0, and ceil(p/100*n) is at least 1 for p>0, 
        # the index will be between 0 and n-1.
        p50_ms = sorted_ms[max(0, min(len(sorted_ms)-1, p50_idx))]
        p95_ms = sorted_ms[max(0, min(len(sorted_ms)-1, p95_idx))]

        result_endpoints.append({
            "path": path,
            "n": n,
            "error_rate": error_rate,
            "p50_ms": p50_ms,
            "p95_ms": p95_ms
        })

    # "ordered by n from large to small, and endpoints with the same n are ordered by path in ordinary string order."
    result_endpoints.sort(key=lambda x: (-x["n"], x["path"]))

    return {
        "endpoints": result_endpoints,
        "bad_lines": bad_lines,
        "total": total
    }
