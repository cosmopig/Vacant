import json
from solution import summarize

def test():
    log = [
        "2023-10-27T10:00:00Z GET /api/v1/resource 200 150",
        "2023-10-27T10:00:01Z POST /api/v1/submit 500 200",
        "2023-10-27T10:00:02Z GET /api/v1/resource 200 160",
        "2023-10-27T10:00:03Z GET /api/v1/other 404 50",
        "invalid line",
        "2023-10-27T10:00:04Z GET /api/v1/resource 200 170",
        "",
        "   ",
        "2023-10-27T10:00:05Z POST /api/v1/submit 503 300",
    ]
    result = summarize(log)
    # p50 of [200, 300] is ceil(0.5 * 2) = 1st element -> index 0 -> 200
    # Wait, I'm still getting an error. Let me print result and expected to see the difference.
    print("Result:", json.dumps(result, indent=2))
    expected = {
        "endpoints": [
            {
                "path": "/api/v1/resource",
                "n": 3,
                "error_rate": 0.0,
                "p50_ms": 160,
                "p95_ms": 170,
            },
            {
                "path": "/api/v1/submit",
                "n": 2,
                "error_rate": 1.0,
                "p50_ms": 200,
                "p95_ms": 300,
            },
            {
                "path": "/api/v1/other",
                "n": 1,
                "error_rate": 0.0,
                "p50_ms": 50,
                "p95_ms": 50,
            },
        ],
        "bad_lines": 1,
        "total": 8,
    }
    print("Expected:", json.dumps(expected, indent=2))
    assert result == expected

if __name__ == "__main__":
    test()
