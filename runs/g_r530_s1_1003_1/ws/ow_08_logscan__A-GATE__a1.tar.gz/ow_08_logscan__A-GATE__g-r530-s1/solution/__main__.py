import sys
import json
from solution import summarize

def main():
    if len(sys.argv) != 2:
        sys.exit(1)
    
    filename = sys.argv[1]
    try:
        with open(filename, 'r') as f:
            lines = f.readlines()
        result = summarize(lines)
        print(json.dumps(result))
    except Exception:
        # The contract says bad lines are not a reason to fail 0.
        # If we hit an unexpected error while reading the file, it's technically a failure,
        # but for valid files with bad lines, it must be 0.
        sys.exit(1)

if __name__ == "__main__":
    main()
