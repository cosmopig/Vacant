import datetime
import math
from collections import defaultdict
from typing import Iterable, Dict, List

def summarize(lines: Iterable[str]) -> dict:
    endpoints = defaultdict(list)
    bad_lines = 0
    total = 0

    for line in lines:
        # The contract says "Any trailing newline is not part of the line."
        # It also says blank lines are noise and should not count as anything at all.
        line = line.rstrip('\n')
        if not line or line.isspace():
            continue
        
        total += 1
        parts = line.split(' ')
        
        # A line is bad when it does not have exactly five fields
        if len(parts) != 5:
            bad_lines += 1
            continue
            
        timestamp_str, method, path, status_str, ms_str = parts
        
        # Validate timestamp
        try:
            ts = timestamp_str.replace('Z', '+00:00')
            datetime.datetime.fromisoformat(ts)
        except Exception:
            bad_lines += 1
            continue

        # Validate status and ms (digits with optional leading -)
        def is_valid_num_str(s):
            if not s: return False
            if s.startswith('-'):
                return len(s) > 1 and s[1:].isdigit()
            return s.isdigit()

        if not is_valid_num_str(status_str) or not is_valid_num_str(ms_str):
            bad_lines += 1
            continue

        try:
            status = int(status_str)
            ms = int(ms_str)
        except ValueError:
            bad_lines += 1
            continue

        endpoints[path].append((status, ms))

    result_endpoints = []
    for path, data in endpoints.items():
        n = len(data)
        errors = sum(1 for status, ms in data if status >= 500)
        error_rate = round(errors / n, 4)
        
        ms_values = sorted([ms for _, ms in data])
        
        def get_percentile(p, sorted_list):
            # p-th percentile of n sorted values is the one at 1-based position ceil(p / 100 * n)
            idx = math.ceil(p / 100 * len(sorted_list))
            return sorted_list[max(0, idx - 1)]

        p50 = get_percentile(50, ms_values)
        p95 = get_percentile(95, ms_values)

        result_endpoints.append({
            "path": path,
            "n": n,
            "error_rate": error_rate,
            "p50_ms": p50,
            "p95_ms": p95
        })

    # Sort: primary by n descending, secondary by path ascending
    result_endpoints.sort(key=lambda x: (-x["n"], x["path"]))

    return {
        "endpoints": result_endpoints,
        "bad_lines": bad_lines,
        "total": total
    }
