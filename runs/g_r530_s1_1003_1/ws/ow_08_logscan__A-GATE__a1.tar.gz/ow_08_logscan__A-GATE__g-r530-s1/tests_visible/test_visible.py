import json
from solution import summarize

def test():
    # Test case with some bad lines and different endpoints
    lines = [
        "2023-10-27T10:00:00Z GET /api/v1/resource 200 100",
        "2023-10-27T10:00:01Z GET /api/v1/resource 500 200",
        "2023-10-27T10:00:02Z POST /api/v1/submit 201 50",
        "invalid line",
        "2023-10-27T10:00:03Z GET /api/v1/resource 200 150",
        "2023-10-27T10:00:04Z POST /api/v1/submit 500 60",
        "",
        "   ",
        "2023-10-27T10:00:05Z GET /api/v1/resource 200 120",
    ]
    result = summarize(lines)
    assert result["total"] == 7
    assert result["bad_lines"] == 1
    # Endpoints:
    # /api/v1/resource: n=4, errors=1 (500), ms=[100, 200, 150, 120] -> sorted [100, 120, 150, 200]
    #   p50 = ceil(0.5 * 4) = 2nd element = 120
    #   p95 = ceil(0.95 * 4) = 4th element = 200
    # /api/v1/submit: n=2, errors=1 (500), ms=[50, 60] -> sorted [50, 60]
    #   p50 = ceil(0.5 * 2) = 1st element = 50
    #   p95 = ceil(0.95 * 2) = 2nd element = 60

    assert len(result["endpoints"]) == 2
    # Order: /api/v1/resource (n=4), then /api/v1/submit (n=2)
    assert result["endpoints"][0]["path"] == "/api/v1/resource"
    assert result["endpoints"][0]["n"] == 4
    assert result["endpoints"][0]["error_rate"] == round(1/4, 4)
    assert result["endpoints"][0]["p50_ms"] == 120
    assert result["endpoints"][0]["p95_ms"] == 200

    assert result["endpoints"][1]["path"] == "/api/v1/submit"
    assert result["endpoints"][1]["n"] == 2
    assert result["endpoints"][1]["error_rate"] == round(1/2, 4)
    assert result["endpoints"][1]["p50_ms"] == 50
    assert result["endpoints"][1]["p95_ms"] == 60

if __name__ == "__main__":
    test()
