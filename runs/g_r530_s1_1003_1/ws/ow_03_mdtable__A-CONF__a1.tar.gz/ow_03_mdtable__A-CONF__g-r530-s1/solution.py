import unicodedata
import re

def _get_width(text):
    return sum(2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1 for ch in text)

def is_separator_row(row_cells):
    for cell in row_cells:
        stripped = cell.strip()
        if not re.fullmatch(r':?-+:??', stripped):
            return False
    return True

def get_columns(line):
    cells = []
    current_cell = ""
    in_backtick = False
    i = 0
    while i < len(line):
        char = line[i]
        if char == '`':
            in_backtick = not in_backtick
            current_cell += char
        elif char == '\\':
            current_cell += char
            if i + 1 < len(line):
                current_cell += line[i+1]
                i += 1
        elif char == '|' and not in_backtick:
            cells.append(current_cell)
            current_cell = ""
        else:
            current_cell += char
        i += 1
    cells.append(current_cell)
    return cells

def process_table(table_lines):
    all_rows_cells = []
    for line in table_lines:
        all_rows_cells.append(get_columns(line))
    
    num_cols = max(len(row) for row in all_rows_cells)
    col_widths = [3] * num_cols
    alignments = [None] * num_cols 

    for row in all_rows_cells:
        for idx, cell in enumerate(row):
            if idx < num_cols:
                stripped = cell.strip()
                is_sep = False
                if re.fullmatch(r':?-+:??', stripped):
                    is_sep = True
                if not is_sep:
                    width = _get_width(stripped)
                    col_widths[idx] = max(col_widths[idx], width)

    if len(all_rows_cells) > 1:
        sep_row = all_rows_cells[1]
        for idx, cell in enumerate(sep_row):
            if idx < num_cols:
                stripped = cell.strip()
                if stripped.startswith(':') and not stripped.endswith(':'):
                    alignments[idx] = 'l'
                elif stripped.startswith(':') and stripped.endswith(':'):
                    alignments[idx] = 'c'
                elif stripped.endswith(':') and not stripped.startswith(':'):
                    alignments[idx] = 'r'
                else:
                    alignments[idx] = 'l'

    def format_cell(content, width, align):
        stripped = content.strip()
        w = _get_width(stripped)
        padding = width - w
        if padding < 0: return stripped
        if align == 'c':
            left = padding // 2
            right = padding - left
            return " " * left + stripped + " " * right
        elif align == 'r':
            return " " * padding + stripped
        else: # 'l'
            return stripped + " " * padding

    formatted_rows = []
    for row in all_rows_cells:
        row_cells = []
        for idx in range(num_cols):
            if idx < len(row):
                row_cells.append(format_cell(row[idx], col_widths[idx], alignments[idx]))
            else:
                row_cells.append(format_cell("", col_widths[idx], alignments[idx]))
        formatted_rows.append("| " + " | ".join(row_cells) + " |")

    if len(all_rows_cells) > 1:
        sep_row = all_rows_cells[1]
        new_sep_row = []
        for idx in range(num_cols):
            cell = sep_row[idx].strip() if idx < len(sep_row) else ""
            marker = ""
            if cell.startswith(':'): marker += ":"
            if cell.endswith(':'): marker += ":"
            inner = cell
            if inner.startswith(':'): inner = inner[1:]
            if inner.endswith(':'): inner = inner[:-1]
            width_for_dashes = col_widths[idx]
            if cell.startswith(':'): width_for_dashes -= 1
            if cell.endswith(':'): width_for_dashes -= 1
            new_sep_row.append(marker + "-" * max(0, width_for_dashes))
        formatted_rows[1] = "| " + " | ".join(new_sep_row) + " |"

    first_line = table_lines[0]
    ending = ""
    if first_line.endswith('\n'):
        ending = '\n' if first_line[-2:] != '\r\n' else '\r\n'
    elif first_line.endswith('\r'):
        ending = '\r'

    res = []
    for row in formatted_rows:
        res.append(row + ending)
    return "".join(res)

def realign(text):
    lines = text.splitlines(keepends=True)
    output = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.strip().startswith("```") or line.strip().startswith("~~~"):
            output.append(line)
            i += 1
            while i < len(lines) and (not lines[i].strip().startswith("```") or not lines[i].strip().startswith("~~~")):
                output.append(lines[i])
                i += 1
            if i < len(lines):
                output.append(lines[i])
                i += 1
            continue

        if i + 1 < len(lines):
            line1 = lines[i]
            line2 = lines[i+1]
            has_col_sep = False
            in_backtick = False
            for j in range(len(line1)):
                if line1[j] == '`':
                    in_backtick = not in_backtick
                elif line1[j] == '|' and not in_backtick:
                    if j == 0 or line1[j-1] != '\\':
                        has_col_sep = True
                        break
            if has_col_sep:
                cols2 = get_columns(line2)
                if is_separator_row(cols2):
                    table_lines = []
                    j = i
                    while j < len(lines):
                        curr_line = lines[j]
                        if curr_line.strip() == "":
                            break
                        has_sep_j = False
                        in_backtick_j = False
                        for k in range(len(curr_line)):
                            if curr_line[k] == '`':
                                in_backtick_j = not in_backtick_j
                            elif curr_line[k] == '|' and not in_backtick_j:
                                if k == 0 or curr_line[k-1] != '\\':
                                    has_sep_j = True
                                    break
                        if not has_sep_j:
                            break
                        table_lines.append(curr_line)
                        j += 1
                    output.extend(process_table(table_lines))
                    i = j
                    continue

        output.append(line)
        i += 1
    return "".join(output)

solution = type('Solution', (), {'realign': realign})()
