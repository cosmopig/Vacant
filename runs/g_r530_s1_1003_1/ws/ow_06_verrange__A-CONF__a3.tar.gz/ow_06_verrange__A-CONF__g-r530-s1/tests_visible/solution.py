import re

class Version:
    def __init__(self, version_str):
        # Regex for MAJOR.MINOR.PATCH[-PRERELEASE]
        pattern = r"^(\d+)\.(\d+)\.(\d+)(?:-(.*))?$"
        match = re.match(pattern, version_str)
        if not match:
            raise ValueError("Invalid version format")
        
        self.major = int(match.group(1))
        self.minor = int(match.group(2))
        self.patch = int(match.group(3))
        self.prerelease = match.group(4)

    def __lt__(self, other):
        if self.major != other.major:
            return self.major < other.major
        if self.minor != other.minor:
            return self.minor < other.minor
        if self.patch != other.patch:
            return self.patch < other.patch
        
        # Version with pre-release is older than version without one
        if self.prerelease is None and other.prerelease is not None:
            return False # self (no prerelease) > other (with prerelease)
        if self.prerelease is not None and other.prerelease is None:
            return True  # self (with prerelease) < other (no prerelease)
        if self.prerelease is None and other.prerelease is None:
            return False

        # Both have pre-releases
        parts1 = self.prerelease.split('.')
        parts2 = other.prerelease.split('.')
        
        for p1, p2 in zip(parts1, parts2):
            is_digit1 = p1.isdigit()
            is_digit2 = p2.isdigit()
            
            if is_digit1 and is_digit2:
                v1, v2 = int(p1), int(p2)
                if v1 != v2:
                    return v1 < v2
            elif not is_digit1 and not is_digit2:
                if p1 != p2:
                    return p1 < p2
            else:
                # One digit, one non-digit. All-digit identifier is older than one that is not.
                return is_digit1 # if p1 is digit, it's older (True)

        return len(parts1) < len(parts2)

    def __eq__(self, other):
        if self.major != other.major or self.minor != other.minor or self.patch != other.patch:
            return False
        if self.prerelease is None and other.prerelease is None:
            return True
        if self.prerelease is not None and other.prerelease is not None:
            # The requirement says "Two pre-releases of the same version also have to sort among themselves"
            # This implies that if they are identical strings, they are equal.
            return self.prerelease == other.prerelease
        return False

    def __gt__(self, other):
        if isinstance(other, Version):
            return not (self < other or self == other)
        return NotImplemented

class Solution:
    def compare(self, a_str: str, b_str: str) -> int:
        v1 = Version(a_str)
        v2 = Version(b_str)
        if v1 < v2: return -1
        if v1 > v2: return 1
        return 0

    def satisfies(self, version_str: str, spec: str) -> bool:
        try:
            v = Version(version_str)
        except ValueError:
            raise ValueError("Invalid version")
            
        conditions = [c.strip() for c in spec.split(',')]
        if not conditions or any(not c for c in conditions):
            raise ValueError("Empty condition")

        for cond in conditions:
            # Match operator and the rest of the string
            match = re.match(r"^(>=|<=|>|<|==|!=)\s*(.*)$", cond)
            if not match:
                raise ValueError("Invalid operator or format")
            op, req_str = match.groups()
            try:
                rv = Version(req_str)
            except ValueError:
                raise ValueError("Invalid requirement version")

            res = None
            if op == "==": res = (v == rv)
            elif op == ">=": res = not (v < rv)
            elif op == "<=": res = not (v > rv)
            elif op == ">":  res = v > rv
            elif op == "<":  res = v < rv
            elif op == "!=": res = v != rv
            
            if res is None: # Should not happen with correct regex
                raise ValueError("Invalid operator")
            if not res:
                return False
        return True

solution = Solution()
