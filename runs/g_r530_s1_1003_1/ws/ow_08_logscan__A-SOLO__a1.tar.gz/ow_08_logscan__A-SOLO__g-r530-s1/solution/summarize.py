import datetime
import math
from typing import Iterable, Dict, List, Any

def summarize(lines: Iterable[str]) -> Dict[str, Any]:
    endpoints = {}
    bad_lines = 0
    total = 0
    
    for line in lines:
        line = line.rstrip('\n')
        if not line or line.isspace():
            continue
        
        total += 1
        parts = line.split(' ')
        
        if len(parts) != 5:
            bad_lines += 1
            continue
            
        ts_str, method, path, status_str, ms_str = parts
        
        # Validate Timestamp
        try:
            iso_ts = ts_str.replace('Z', '+00:00')
            datetime.datetime.fromisoformat(iso_ts)
        except (ValueError, TypeError):
            bad_lines += 1
            continue
            
        # Validate Status and MS
        def is_valid_num_str(s):
            if not s: return False
            if s[0] == '-':
                return s[1:].isdigit()
            return s.isdigit()

        if not is_valid_num_str(status_str) or not is_valid_num_str(ms_str):
            bad_lines += 1
            continue
            
        try:
            status = int(status_str)
            ms = int(ms_str)
        except ValueError:
            bad_lines += 1
            continue

        if path not in endpoints:
            endpoints[path] = {"n": 0, "errors": 0, "ms_list": []}
        
        endpoints[path]["n"] += 1
        if status >= 500:
            endpoints[path]["errors"] += 1
        endpoints[path]["ms_list"].append(ms)

    result_endpoints = []
    for path, data in endpoints.items():
        n = data["n"]
        error_rate = round(data["errors"] / n, 4)
        
        sorted_ms = sorted(data["ms_list"])
        p50_idx = math.ceil(0.50 * n) - 1
        p95_idx = math.ceil(0.95 * n) - 1
        # Clamp indices to valid range just in case, though ceil logic should be safe for n > 0
        p50_ms = sorted_ms[max(0, min(p50_idx, n-1))]
        p95_ms = sorted_ms[max(0, min(p95_idx, n-1))]
        
        result_endpoints.append({
            "path": path,
            "n": n,
            "error_rate": error_rate,
            "p50_ms": p50_ms,
            "p95_ms": p95_ms
        })

    # Sort: primary key n (desc), secondary key path (asc)
    result_endpoints.sort(key=lambda x: (-x["n"], x["path"]))

    return {
        "endpoints": result_endpoints,
        "bad_lines": bad_lines,
        "total": total
    }
