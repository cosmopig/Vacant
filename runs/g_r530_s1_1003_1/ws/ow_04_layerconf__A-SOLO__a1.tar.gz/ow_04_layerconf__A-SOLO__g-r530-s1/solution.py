from typing import Any, Dict, Optional

class Config:
    def __init__(self, values: Dict[str, Any], sources: Dict[str, str]):
        self._values = values
        self._sources = sources

    def get(self, key: str) -> Any:
        if key not in self._values:
            raise KeyError(key)
        return self._values[key]

    def source(self, key: str) -> str:
        if key not in self._sources:
            raise KeyError(key)
        return self._sources[key]

    def as_dict(self) -> Dict[str, Any]:
        return self._values.copy()


def _convert_value(val: str, target_type: type) -> Any:
    if target_type is bool:
        normalized = val.lower()
        if normalized in ("true", "1", "yes"):
            return True
        if normalized in ("false", "0", "no"):
            return False
        raise ValueError(f"Cannot convert {val} to bool")
    
    try:
        if target_type is int:
            # Need to handle cases where float string might be passed to int
            # but the requirement says "cannot be turned into the right kind of thing must fail loudly".
            # If it's "1.0" and we want int, int("1.0") fails in Python.
            return int(val)
        if target_type is float:
            return float(val)
        if target_type is str:
            return val
        return val
    except (ValueError, TypeError) as e:
        raise ValueError(f"Cannot convert {val} to {target_type}") from e

def load(defaults: Dict[str, Any], file_text: Optional[str], env: Dict[str, str]) -> Config:
    final_values = {}
    sources = {}
    
    # Initialize with defaults
    for key in defaults:
        final_values[key] = defaults[key]
        sources[key] = "default"

    # Process file
    if file_text is not None:
        current_section = ""
        lines = file_text.splitlines()
        for line in lines:
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            
            if stripped.startswith("[") and stripped.endswith("]"):
                # Section header like [db] or [server settings]
                current_section = stripped[1:-1].strip() + "."
            elif "=" in stripped:
                key_part, val_part = stripped.split("=", 1)
                key = (current_section + key_part).strip()
                val = val_part.strip()
                
                if key in defaults:
                    try:
                        final_values[key] = _convert_value(val, type(defaults[key]))
                        sources[key] = "file"
                    except ValueError as e:
                        raise e
            else:
                # Line is neither comment/blank nor section header nor contains '='
                continue

    # Process env
    for env_key, env_val in env.items():
        if env_key.startswith("APP_"):
            # APP_DB__PORT -> db.port
            raw_name = env_key[4:] # remove APP_
            processed_name = raw_name.replace("__", ".").lower()
            
            if processed_name in defaults:
                try:
                    final_values[processed_name] = _convert_value(env_val, type(defaults[processed_name]))
                    sources[processed_name] = "env"
                except ValueError as e:
                    raise e

    return Config(final_values, sources)
