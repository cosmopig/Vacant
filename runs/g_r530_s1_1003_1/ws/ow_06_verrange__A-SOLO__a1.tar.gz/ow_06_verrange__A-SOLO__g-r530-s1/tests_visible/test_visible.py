import unittest
from solution import Version

class TestVersion(unittest.TestCase):
    def test_compare(self):
        self.assertEqual(Version("1.0.0").compare("1.0.0"), 0)
        self.assertEqual(Version("1.0.0").compare("2.0.0"), -1)
        self.assertEqual(Version("2.0.0").compare("1.0.0"), 1)
        self.assertEqual(Version("1.10.0").compare("1.9.0"), 1)
        self.assertEqual(Version("1.10.0").compare("1.10.0"), 0)

    def test_pre_release_basic(self):
        # A version carrying a pre-release is older than the same version without one.
        self.assertEqual(Version("1.0.0-alpha").compare("1.0.0"), -1)
        self.assertEqual(Version("1.0.0").compare("1.0.0-alpha"), 1)

    def test_pre_release_sorting(self):
        # Two pre-releases of the same version also have to sort among themselves: rc.2 comes after rc.1, alpha comes before beta
        self.assertEqual(Version("1.0.0-rc.1").compare("1.0.0-rc.2"), -1)
        self.assertEqual(Version("1.0.0-alpha").compare("1.0.0-beta"), -1)

    def test_pre_release_identifiers(self):
        # an identifier made only of digits is compared by value, any other identifier is compared by ASCII, and
        # an all-digit identifier is older than one that is not. If every shared identifier is equal, the pre-release with more identifiers is the newer one.
        self.assertEqual(Version("1.0.0-rc.1").compare("1.0.0-rc.2"), -1)
        # "alpha" vs "beta": ASCII comparison
        self.assertEqual(Version("1.0.0-alpha").compare("1.0.0-beta"), -1)
        # all-digit identifier is older than one that is not (e.g., "1" < "a")
        self.assertEqual(Version("1.0.0-1").compare("1.0.0-a"), -1)
        # pre-release with more parts is newer
        self.assertEqual(Version("1.0.0-rc.1.1").compare("1.0.0-rc.1"), 1)

    def test_satisfies(self):
        v = Version("1.2.3")
        self.assertTrue(v.satisfies(">= 1.0.0"))
        self.assertTrue(v.satisfies("> 1.0.0, <= 2.0.0"))
        self.assertTrue(v.satisfies("== 1.2.3"))
        self.assertTrue(v.satisfies("!= 1.0.0"))
        self.assertFalse(v.satisfies("> 2.0.0"))
        self.assertFalse(v.satisfies("< 1.0.0"))

    def test_errors(self):
        with self.assertRaises(ValueError):
            Version("1.a.0")
        with self.assertRaises(ValueError):
            Version("1.0.0-")
        with self.assertRaises(ValueError):
            Version("v1.0.0")
        with self.assertRaises(ValueError):
            Version("1.0.0.0")

        with self.assertRaises(ValueError):
            Version("1.2.3").satisfies("")
        with self.assertRaises(ValueError):
            Version("1.2.3").satisfies("invalid_op 1.2.3")
        with self.assertRaises(ValueError):
            Version("1.2.3").satisfies(">= , <= 2.0.0")

if __name__ == "__main__":
    unittest.main()
