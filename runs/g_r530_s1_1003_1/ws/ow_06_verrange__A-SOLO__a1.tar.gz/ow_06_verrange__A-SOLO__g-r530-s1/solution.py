import re

class Version:
    def __init__(self, version_str):
        # A version is MAJOR.MINOR.PATCH, each a run of digits, 
        # optionally followed by - and a pre-release made of dot-separated identifiers 
        # drawn from letters, digits and hyphens. Nothing else is a version.
        pattern = r'^(\d+)\.(\d+)\.(\d+)(?:-(.*))?$'
        match = re.match(pattern, version_str)
        if not match:
            raise ValueError("Invalid version format")
        
        self.major = int(match.group(1))
        self.minor = int(match.group(2))
        self.patch = int(match.group(3))
        self.pre_release = match.group(4)
        
        if self.pre_release is not None:
            # Check if pre-release contains only letters, digits and hyphens, 
            # separated by dots.
            parts = self.pre_release.split('.')
            for part in parts:
                if not part: # handles cases like "1.0.0--alpha" or "1.0.0-.alpha"
                    raise ValueError("Invalid pre-release identifier")
                if not re.match(r'^[a-zA-Z0-9-]+$', part):
                    raise ValueError("Invalid character in pre-release identifier")
            self.pre_release_parts = parts
        else:
            self.pre_release_parts = []

    def compare(self, other_str):
        other = Version(other_str)
        
        # Compare MAJOR.MINOR.PATCH
        if self.major != other.major:
            return 1 if self.major > other.major else -1
        if self.minor != other.minor:
            return 1 if self.minor > other.minor else -1
        if self.patch != other.patch:
            return 1 if self.patch > other.patch else -1
        
        # A version carrying a pre-release is older than the same version without one.
        if self.pre_release is None and other.pre_release is not None:
            return 1
        if self.pre_release is not None and other.pre_release is None:
            return -1
        if self.pre_release is None and other.pre_release is None:
            return 0
        
        # Two pre-releases are compared identifier by identifier
        for p1, p2 in zip(self.pre_release_parts, other.pre_release_parts):
            p1_is_digit = p1.isdigit()
            p2_is_digit = p2.isdigit()
            
            if p1_is_digit and p2_is_digit:
                v1, v2 = int(p1), int(p2)
                if v1 != v2:
                    return 1 if v1 > v2 else -1
            elif not p1_is_digit and not p2_is_digit:
                if p1 != p2:
                    return 1 if p1 > p2 else -1
            else:
                # an all-digit identifier is older than one that is not.
                return -1 if p1_is_digit else 1
        
        # If every shared identifier is equal, the pre-release with more identifiers is the newer one.
        if len(self.pre_release_parts) != len(other.pre_release_parts):
            return 1 if len(self.pre_release_parts) > len(other.pre_release_parts) else -1
        
        return 0

    def satisfies(self, spec):
        if not spec:
            raise ValueError("Empty specification")
        
        conditions = [c.strip() for c in spec.split(',')]
        for cond in conditions:
            if not cond:
                raise ValueError("Empty condition")
            
            match = re.match(r'^(>=|<=|>|<|==|!=)\s*(.*)$', cond)
            if not match:
                raise ValueError("Unrecognised operator or invalid format")
            
            op, other_str = match.groups()
            other_ver = Version(other_str)
            cmp = self.compare(other_str)
            
            if op == '==':
                if cmp != 0: return False
            elif op == '>=':
                if cmp < 0: return False
            elif op == '<=':
                if cmp > 0: return False
            elif op == '>':
                if cmp <= 0: return False
            elif op == '<':
                if cmp >= 0: return False
            elif op == '!=':
                if cmp == 0: return False
        return True

def compare(a: str, b: str) -> int:
    return Version(a).compare(b)

def satisfies(version: str, spec: str) -> bool:
    return Version(version).satisfies(spec)
