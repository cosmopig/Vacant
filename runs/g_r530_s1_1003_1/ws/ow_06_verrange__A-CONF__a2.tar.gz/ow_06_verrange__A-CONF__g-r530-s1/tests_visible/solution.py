import re

class Version:
    def __init__(self, v_str):
        match = re.fullmatch(r"(\d+)\.(\d+)\.(\d+)(?:-(.*))?", v_str)
        if not match:
            raise ValueError("Invalid version")
        self.major = int(match.group(1))
        self.minor = int(match.group(2))
        self.patch = int(match.group(3))
        self.pre = match.group(4) if match.group(4) is not None else None

    def __lt__(self, other):
        if self.major != other.major: return self.major < other.major
        if self.minor != other.minor: return self.minor < other.minor
        if self.patch != other.patch: return self.patch < other.patch
        
        # Pre-release logic
        if self.pre is None and other.pre is not None: return False # Self (no pre) > Other (has pre)
        if self.pre is not None and other.pre is None: return True  # Self (has pre) < Other (no pre)
        if self.pre is None and other.pre is None: return False
        
        parts1 = self.pre.split('.')
        parts2 = other.pre.split('.')
        for p1, p2 in zip(parts1, parts2):
            is_digit1 = p1.isdigit()
            is_digit2 = p2.isdigit()
            if is_digit1 and is_digit2:
                v1, v2 = int(p1), int(p2)
                if v1 != v2: return v1 < v2
            elif is_digit1: # digit vs non-digit (digit is older)
                return True
            elif is_digit2: # non-digit vs digit (non-digit is newer)
                return False
            else: # both non-digit
                if p1 != p2: return p1 < p2
        
        return len(parts1) < len(parts2)

    def __eq__(self, other):
        return (self.major == other.major and 
                self.minor == other.minor and 
                self.patch == other.patch and 
                self.pre == other.pre)

    def __gt__(self, other):
        if self.__eq__(other): return False
        return not (self < other)

class Solution:
    def compare(self, a_str: str, b_str: str) -> int:
        a = Version(a_str)
        b = Version(b_str)
        if a < b: return -1
        if a > b: return 1
        return 0

    def satisfies(self, version_str: str, spec: str) -> bool:
        v = Version(version_str)
        raw_parts = [p.strip() for p in spec.split(',')]
        if any(not p for p in raw_parts):
             raise ValueError("Empty condition")

        for cond in raw_parts:
            match = re.fullmatch(r"(>=|<=|>|<|==|!=)\s*(\d+\.\d+\.\d+(?:-[^\s,]+)*)", cond)
            if not match:
                raise ValueError("Invalid condition")
            op, op_v_str = match.groups()
            op_v = Version(op_v_str)
            
            res = None
            if op == "==": res = (v == op_v)
            elif op == "!=": res = (v != op_v)
            elif op == ">=": res = (v >= op_v)
            elif op == "<=": res = (v <= op_v)
            elif op == ">":  res = (v > op_v)
            elif op == "<":  res = (v < op_v)
            
            if not res: return False
        return True

