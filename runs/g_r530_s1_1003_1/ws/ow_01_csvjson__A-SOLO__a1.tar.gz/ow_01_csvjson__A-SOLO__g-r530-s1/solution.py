import csv
import json
import sys
import io

def csv_to_jsonl(text: str) -> str:
    if not text or not text.strip():
        return ""
    
    # The requirement says "A completely empty line is ignored."
    # This means lines that only contain \n, \r\n, or are truly empty should be skipped.
    # However, we must still correctly count the line numbers for the records.

    def get_records(text):
        records = []
        current_line_num = 1
        i = 0
        n = len(text)
        while i < n:
            # Skip completely empty lines (only \r and \n)
            if text[i] == '\n' or text[i] == '\r':
                if text[i] == '\r' and i + 1 < n and text[i+1] == '\n':
                    i += 2
                else:
                    i += 1
                continue
            
            start_line = current_line_num
            row = []
            current_field = ""
            in_quotes = False
            found_end = False
            
            while i < n and not found_end:
                char = text[i]
                if char == '"':
                    if in_quotes and i + 1 < n and text[i+1] == '"':
                        current_field += '"'
                        i += 2
                    else:
                        in_quotes = not in_quotes
                        i += 1
                elif char == ',' and not in_quotes:
                    row.append(current_field)
                    current_field = ""
                    i += 1
                elif (char == '\n' or char == '\r') and not in_quotes:
                    # This is the end of a record if it's not inside quotes.
                    # But wait, we need to handle \r\n as one newline.
                    row.append(current_field)
                    records.append((row, start_line))
                    if char == '\r' and i + 1 < n and text[i+1] == '\n':
                        current_line_num += 2
                        i += 2
                    else:
                        current_line_num += 1
                        i += 1
                    found_end = True
                else:
                    current_field += char
                    i += 1
            
            if not found_end and i < n:
                row.append(current_field)
                records.append((row, start_line))
        return records

    all_records = get_records(text)
    if not all_records:
        return ""
    
    header = all_records[0][0]
    data_records = all_records[1:]
    
    output = []
    for row, line_num in data_records:
        # The requirement says "a record whose field count differs from the header" is invalid.
        if len(row) != len(header):
            raise ValueError(f"line {line_num}: field count differs from the header")
        
        obj = {}
        for i, val in enumerate(row):
            h_name = header[i]
            obj[h_name] = val
        output.append(json.dumps(obj))

    return "\n".join(output) + ("\n" if output else "")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(1)
    try:
        with open(sys.argv[1], 'r', encoding='utf-8') as f:
            content = f.read()
        result = csv_to_jsonl(content)
        sys.stdout.write(result)
    except ValueError as e:
        sys.stderr.write(str(e) + "\n")
        sys.exit(2)
    except Exception as e:
        # The requirement says "not to receive a stack trace" and "success and failure have to be distinguishable".
        # For other errors, we should probably just exit with non-zero.
        sys.stderr.write(f"Error: {e}\n")
        sys.exit(1)
