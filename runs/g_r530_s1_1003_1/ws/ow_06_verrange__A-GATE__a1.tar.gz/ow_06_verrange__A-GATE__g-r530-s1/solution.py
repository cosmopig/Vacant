import re

class VersionComparator:
    def __init__(self):
        # Regex for version: MAJOR.MINOR.PATCH[-PRERELEASE]
        # PRERELEASE is dot-separated identifiers of letters, digits and hyphens.
        self.version_regex = re.compile(r'^(\d+)\.(\d+)\.(\d+)(?:-(.*))?$')

    def parse_version(self, version_str: str):
        match = self.version_regex.match(version_str)
        if not match:
            raise ValueError(f"Invalid version format: {version_str}")
        
        major = int(match.group(1))
        minor = int(match.group(2))
        patch = int(match.group(3))
        prerelease = match.group(4)
        
        prerelease_parts = []
        if prerelease is not None:
            # Identifiers are dot-separated
            parts = prerelease.split('.')
            for p in parts:
                if not p: # Should not happen based on regex but just in case
                    raise ValueError(f"Empty identifier in pre-release: {prerelease}")
                # Check if it contains only letters, digits and hyphens
                if not all(c.isdigit() or c.isalpha() or c == '-' for c in p):
                    raise ValueError(f"Invalid character in prerelease part: {p}")
                prerelease_parts.append(p)
        
        return (major, minor, patch), prerelease_parts

    def compare(self, a: str, b: str) -> int:
        v1_main, v1_pre = self.parse_version(a)
        v2_main, v2_pre = self.parse_version(b)
        
        # Compare MAJOR.MINOR.PATCH
        if v1_main > v2_main:
            return 1
        if v1_main < v2_main:
            return -1
        
        # If main parts are equal, check pre-release status
        # A version carrying a pre-release is older than the same version without one.
        has_pre1 = len(v1_pre) > 0
        has_pre2 = len(v2_pre) > 0
        
        if not has_pre1 and has_pre2:
            return 1
        if has_pre1 and not has_pre2:
            return -1
        if not has_pre1 and not has_pre2:
            return 0
        
        # Both have pre-releases
        for p1, p2 in zip(v1_pre, v2_pre):
            is_digit1 = p1.isdigit()
            is_digit2 = p2.isdigit()
            
            if is_digit1 and is_digit2:
                val1 = int(p1)
                val2 = int(p2)
                if val1 > val2: return 1
                if val1 < val2: return -1
            elif not is_digit1 and not is_digit2:
                if p1 > p2: return 1
                if p1 < p2: return -1
            else:
                # One is digit, one is not. All-digit identifier is older than one that is not.
                return -1 if is_digit1 else 1
        
        # If every shared identifier is equal, the pre-release with more identifiers is the newer one.
        if len(v1_pre) > len(v2_pre):
            return 1
        if len(v1_pre) < len(v2_pre):
            return -1
        
        return 0

    def satisfies(self, version: str, spec: str) -> bool:
        # A spec is one or more conditions separated by `,`. Surrounding whitespace on a condition is not part of it.
        if not spec.strip():
            raise ValueError("Empty spec")
            
        conditions = [c.strip() for c in spec.split(',')]
        if any(not c for c in conditions):
            raise ValueError("Empty condition in spec")
            
        v_main, v_pre = self.parse_version(version)
        
        for cond in conditions:
            match = re.match(r'^([>=<]+|==|!=)\s*(.*)$', cond)
            if not match:
                raise ValueError(f"Invalid condition format: {cond}")
            
            op = match.group(1)
            other_v_str = match.group(2).strip()
            
            if not other_v_str:
                raise ValueError("Condition missing version")
                
            ov_main, ov_pre = self.parse_version(other_v_str)
            
            comp = self.compare(version, other_v_str)
            
            satisfied = False
            if op == "==": satisfied = (comp == 0)
            elif op == ">=": satisfied = (comp >= 0)
            elif op == "<=": satisfied = (comp <= 0)
            elif op == ">":  satisfied = (comp > 0)
            elif op == "<":  satisfied = (comp < 0)
            elif op == "!=": satisfied = (comp != 0)
            else:
                raise ValueError(f"Unrecognised operator: {op}")
            
            if not satisfied:
                return False
        
        return True

compare = VersionComparator().compare
satisfies = VersionComparator().satisfies
