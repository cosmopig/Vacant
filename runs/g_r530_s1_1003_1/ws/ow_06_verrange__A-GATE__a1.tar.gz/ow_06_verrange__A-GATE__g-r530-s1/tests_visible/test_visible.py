import unittest
from solution import VersionComparator

class TestVersionComparator(unittest.TestCase):
    def test_compare_basic(self):
        vc = VersionComparator()
        self.assertEqual(vc.compare("1.0.0", "2.0.0"), -1)
        self.assertEqual(vc.compare("2.0.0", "1.0.0"), 1)
        self.assertEqual(vc.compare("1.10.0", "1.9.0"), 1)
        self.assertEqual(vc.compare("1.0.0", "1.0.0"), 0)

    def test_compare_prerelease_basic(self):
        vc = VersionComparator()
        # A version carrying a pre-release is older than the same version without one.
        self.assertEqual(vc.compare("1.0.0-alpha", "1.0.0"), -1)
        # Two pre-releases of the same version also have to sort among themselves: rc.2 comes after rc.1, alpha comes before beta
        self.assertEqual(vc.compare("1.0.0-rc.1", "1.0.0-rc.2"), -1)
        self.assertEqual(vc.compare("1.0.0-alpha", "1.0.0-beta"), -1)

    def test_compare_prerelease_complex(self):
        vc = VersionComparator()
        # an all-digit identifier is older than one that is not.
        # Wait, the rule says: "an identifier made only of digits is compared by value, any other identifier is compared by ASCII, and an all-digit identifier is older than one that is not."
        # This means if we compare "1.0.0-1" and "1.0.0-a":
        # 1 is all-digits, a is not. So 1 < a.
        self.assertEqual(vc.compare("1.0.0-1", "1.0.0-a"), -1)
        
        # If every shared identifier is equal, the pre-release with more identifiers is the newer one.
        self.assertEqual(vc.compare("1.0.0-alpha", "1.0.0-alpha.1"), -1)
        self.assertEqual(vc.compare("1.0.0-alpha.1", "1.0.0-alpha"), 1)

    def test_satisfies(self):
        vc = VersionComparator()
        self.assertTrue(vc.satisfies("1.2.3", ">=1.0.0"))
        self.assertTrue(vc.satisfies("1.2.3", ">=1.0.0, <2.0.0"))
        self.assertTrue(vc.satisfies("1.2.3", "> 1.2.2"))
        self.assertTrue(vc.satisfies("1.2.3", "==1.2.3"))
        self.assertTrue(vc.satisfies("1.2.3", "!=1.0.0"))
        self.assertFalse(vc.satisfies("1.2.3", ">2.0.0"))
        self.assertFalse(vc.satisfies("1.2.3", ">=1.2.4"))

    def test_errors(self):
        vc = VersionComparator()
        with self.assertRaises(ValueError):
            vc.compare("invalid", "1.0.0")
        with self.assertRaises(ValueError):
            vc.satisfies("1.0.0", "")
        with self.assertRaises(ValueError):
            vc.satisfies("1.0.0", "??1.0.0")

if __name__ == "__main__":
    unittest.main()
