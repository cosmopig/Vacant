import unicodedata
import re

def get_width(text):
    return sum(2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1 for ch in text)

def is_separator_row(cells):
    for cell in cells:
        if not re.fullmatch(r':?-+:?', cell):
            return False
    return True

def split_line(line):
    parts = []
    current_part = ""
    i = 0
    in_code = False
    while i < len(line):
        char = line[i]
        if char == '`':
            # Fenced code blocks: ``` or ~~~
            if i + 2 < len(line) and (line[i+1] == '`' and line[i+2] == '`') or \
               (line[i+1] == '~' and line[i+2] == '~'):
                in_code = not in_code
                current_part += line[i:i+3]
                i += 3
            else:
                # Inline code. The contract says "inside a span delimited by backticks".
                in_code = not in_code
                current_part += char
                i += 1
        elif char == '\\' and i + 1 < len(line) and line[i+1] == '|':
            current_part += line[i:i+2]
            i += 2
        elif char == '|' and not in_code:
            parts.append(current_part)
            current_part = ""
            i += 1
        else:
            current_part += char
            i += 1
    parts.append(current_part)
    return parts

def process_table(table_lines):
    num_cols = 0
    for _, parts in table_lines:
        num_cols = max(num_cols, len(parts))
    
    col_widths = [3] * num_cols
    sep_row_parts = None
    if len(table_lines) >= 2:
        _, parts = table_lines[1]
        if is_separator_row(parts):
            sep_row_parts = parts

    for idx, (line, parts) in enumerate(table_lines):
        padded_parts = list(parts)
        while len(padded_parts) < num_cols:
            padded_parts.append("")
        
        if not (idx == 1 and sep_row_parts):
            for col_idx, cell in enumerate(padded_parts):
                is_sep = False
                if sep_row_parts and col_idx < len(sep_row_parts):
                    if re.fullmatch(r':?-+:?', sep_row_parts[col_idx]):
                        is_sep = True
                
                if not is_sep:
                    w = get_width(cell.strip())
                    if w > col_widths[col_idx]:
                        col_widths[col_idx] = w

    result_lines = []
    for idx, (line, parts) in enumerate(table_lines):
        padded_parts = list(parts)
        while len(padded_parts) < num_cols:
            padded_parts.append("")
        
        new_parts = []
        for col_idx, cell in enumerate(padded_parts):
            if idx == 1 and sep_row_parts and col_idx < len(sep_row_parts):
                s = sep_row_parts[col_idx]
                left_marker = ":" if s.startswith(":") else ""
                right_marker = ":" if s.endswith(":") and (len(s) > 1 or s != ":") else ""
                if s == ":":
                    left_marker = ":"
                    right_marker = ""
                else:
                    left_marker = ":" if s.startswith(":") else ""
                    right_marker = ":" if s.endswith(":") else ""

                dashes = s.replace(":", "")
                total_width = col_widths[col_idx]
                num_dashes = total_width - len(left_marker) - len(right_marker)
                if num_dashes < 1: num_dashes = 1
                new_parts.append(left_marker + "-" * num_dashes + right_marker)
            else:
                cell_content = cell.strip()
                w = get_width(cell_content)
                padding = " " * (col_widths[col_idx] - w)
                new_parts.append(cell_content + padding)
        
        res_line = "| " + " | ".join(new_parts) + " |"
        result_lines.append(res_line + lines[idx][len(lines[idx].rstrip('\r\n'))])

    return "".join(result_lines)

def realign(text):
    lines = text.splitlines(keepends=True)
    output = []
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped_line = line.rstrip('\r\n')
        parts = split_line(stripped_line)
        if len(parts) > 1:
            if i + 1 < len(lines):
                next_line = lines[i+1]
                next_stripped = next_line.rstrip('\r\n')
                next_parts = split_line(next_stripped)
                if is_separator_row(next_parts):
                    table_lines = []
                    j = i
                    while j < len(lines):
                        curr_l = lines[j]
                        curr_s = curr_l.rstrip('\r\n')
                        curr_p = split_line(curr_s)
                        if not curr_s or len(curr_p) <= 1:
                            break
                        table_lines.append((curr_s, curr_p))
                        j += 1
                    output.append(process_table(table_lines))
                    i = j
                    continue
        output.append(line)
        i += 1
    return "".join(output)

