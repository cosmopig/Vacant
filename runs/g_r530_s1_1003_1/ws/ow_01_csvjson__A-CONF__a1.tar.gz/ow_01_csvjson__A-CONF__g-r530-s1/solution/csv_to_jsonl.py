import csv
import json
import sys
import io

def csv_to_jsonl(text: str) -> str:
    if not text or not text.strip():
        return ""
    
    # A "line" is a physical line in the input string.
    # We need to find all positions where a record starts (at index 0 or at a newline not inside quotes).
    record_starts = [] # list of (position, line_number)
    in_quotes = False
    i = 0
    line_num = 1
    while i < len(text):
        if text[i] == '"':
            # Check for double quote ""
            if in_quotes and i + 1 < len(text) and text[i+1] == '"':
                i += 2
                continue
            in_quotes = not in_quotes
            i += 1
        elif text[i] == '\n' or text[i] == '\r':
            if not in_quotes:
                record_starts.append((i, line_num))
            # Skip \r\n
            if text[i] == '\r' and i + 1 < len(text) and text[i+1] == '\n':
                i += 2
            else:
                i += 1
            line_num += 1
        else:
            i += 1
    record_starts.insert(0, (0, 1))

    f = io.StringIO(text)
    # Use newline=None to handle \n and \r\n correctly as universal newlines.
    reader = csv.reader(f, quotechar='"', delimiter=',', doublequote=True, skipinitialspace=False, newline=None)
    
    try:
        header_row = next(reader)
    except StopIteration:
        return ""

    num_cols = len(header_row)
    output = []
    
    current_record_idx = 0
    for row in reader:
        if not row: # Completely empty line is ignored.
            continue
        
        # Find the correct record start by skipping entries that correspond to completely empty lines.
        while current_record_idx < len(record_starts):
            pos, l_num = record_starts[current_record_idx]
            # If there's nothing between this newline and the next one (or end of string), it's an empty line.
            if pos + 1 < len(text) and (text[pos+1] == '\n' or text[pos+1] == '\r'):
                current_record_idx += 1
                continue
            else:
                break
        
        if current_record_idx >= len(record_starts):
            break

        _, line_num = record_starts[current_record_idx]
        
        # Check for unclosed quotes. csv.reader might not raise an error but we can check if it's at the end of a row.
        # Actually, csv.reader will raise an error or behave oddly if there's an unclosed quote.
        # Let's see what happens with an unclosed quote in csv.reader.
        
        if len(row) != num_cols:
            raise ValueError(f"line {line_num}: field count differs from header")
        
        obj = {}
        for i, val in enumerate(row):
            col_name = header_row[i]
            obj[col_name] = str(val)
        
        output.append(json.dumps(obj))
        current_record_idx += 1

    return "\n".join(output) + ("\n" if output else "")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(0)
    filename = sys.argv[1]
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            content = f.read()
        result = csv_to_jsonl(content)
        sys.stdout.write(result)
    except ValueError as e:
        sys.stderr.write(str(e) + "\n")
        sys.exit(2)
    except Exception:
        # If it's an unclosed quote, csv.reader might raise a specific error or we can catch it here.
        # But the requirement says "unclosed quote" is invalid.
        # Let's check if csv.reader raises anything for unclosed quotes.
        sys.exit(1)
