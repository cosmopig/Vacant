from .csv_to_jsonl import csv_to_jsonl
import sys

def main():
    if len(sys.argv) != 2:
        return
    filename = sys.argv[1]
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            content = f.read()
        result = csv_to_jsonl(content)
        sys.stdout.write(result)
    except ValueError as e:
        sys.stderr.write(str(e) + "\n")
        sys.exit(2)
    except Exception:
        sys.exit(1)

if __name__ == "__main__":
    main()
