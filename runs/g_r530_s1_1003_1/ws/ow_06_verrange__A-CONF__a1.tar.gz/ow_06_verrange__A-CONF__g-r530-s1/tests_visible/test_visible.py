import unittest
from solution import VersionComparator

class TestVersionComparator(unittest.TestCase):
    def test_compare_basic(self):
        self.assertEqual(VersionComparator.compare("1.0.0", "2.0.0"), -1)
        self.assertEqual(VersionComparator.compare("2.0.0", "1.0.0"), 1)
        self.assertEqual(VersionComparator.compare("1.10.0", "1.9.0"), 1)
        self.assertEqual(VersionComparator.compare("1.0.0", "1.0.0"), 0)

    def test_compare_prerelease_basic(self):
        # A version carrying a pre-release is older than the same version without one.
        self.assertEqual(VersionComparator.compare("1.0.0-alpha", "1.0.0"), -1)
        # Two pre-releases of the same version also have to sort among themselves: rc.2 comes after rc.1, alpha comes before beta
        self.assertEqual(VersionComparator.compare("1.0.0-rc.1", "1.0.0-rc.2"), -1)
        self.assertEqual(VersionComparator.compare("1.0.0-alpha", "1.0.0-beta"), -1)

    def test_compare_prerelease_complex(self):
        # an identifier made only of digits is compared by value, any other identifier is compared by ASCII, and an all-digit identifier is older than one that is not.
        # "rc" vs "rc.1": rc.1 has more identifiers, so it's newer? No, wait: "If every shared identifier is equal, the pre-release with more identifiers is the newer one."
        self.assertEqual(VersionComparator.compare("1.0.0-rc", "1.0.0-rc.1"), -1)
        # all-digit vs non-all-digit: 1 < a (ASCII 'a' is 97, digit '1' is 49? No, the rule says "an all-digit identifier is older than one that is not" if they are otherwise equal?)
        # Actually, it says "Two pre-releases are compared identifier by identifier: an identifier made only of digits is compared by value, any other identifier is compared by ASCII, and an all-digit identifier is older than one that is not."
        # This means if we compare '1' (all-digit) and 'a' (not all-digit), '1' is older.
        self.assertEqual(VersionComparator.compare("1.0.0-1", "1.0.0-a"), -1)

    def test_satisfies_basic(self):
        self.assertTrue(VersionComparator.satisfies("1.2.3", ">=1.0.0"))
        self.assertTrue(VersionComparator.satisfies("1.2.3", ">=1.0.0, <2.0.0"))
        self.assertTrue(VersionComparator.satisfies("1.2.3", "> 1.1.0, <= 1.5.0")) # Wait, 1.2.3 is not <= 1.5.0? No it is.
        # Let's re-check: 1.2.3 vs 1.5.0. 2 < 5, so 1.2.3 < 1.5.0. Correct.
        self.assertFalse(VersionComparator.satisfies("1.2.3", ">=2.0.0"))

    def test_satisfies_errors(self):
        with self.assertRaises(ValueError):
            VersionComparator.satisfies("1.2.3", "") # empty condition
        with self.assertRaises(ValueError):
            VersionComparator.satisfies("1.2.3", "invalid") # unrecognised operator or version
        with self.assertRaises(ValueError):
            VersionComparator.satisfies("not_a_version", ">=1.0.0")

if __name__ == "__main__":
    unittest.main()
