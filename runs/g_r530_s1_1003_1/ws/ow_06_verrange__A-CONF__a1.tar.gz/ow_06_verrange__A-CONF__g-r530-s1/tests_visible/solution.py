import re

class VersionComparator:
    VERSION_PATTERN = re.compile(r'^(\d+)\.(\d+)\.(\d+)(?:-([a-zA-Z0-9.-]+))?$')

    @classmethod
    def parse_version(cls, version_str):
        match = cls.VERSION_PATTERN.match(version_str)
        if not match:
            raise ValueError(f"Invalid version: {version_str}")
        major, minor, patch, prerelease = match.groups()
        return (int(major), int(minor), int(patch), prerelease)

    @classmethod
    def compare(cls, a: str, b: str) -> int:
        v1 = cls.parse_version(a)
        v2 = cls.parse_version(b)

        # Compare major, minor, patch
        for i in range(3):
            if v1[i] < v2[i]:
                return -1
            if v1[i] > v2[i]:
                return 1

        # Prerelease logic
        p1 = v1[3]
        p2 = v2[3]

        if p1 is None and p2 is not None:
            return 1
        if p1 is not None and p2 is None:
            return -1
        if p1 is None and p2 is None:
            return 0

        # Both have prereleases
        parts1 = p1.split('.')
        parts2 = p2.split('.')

        for i in range(min(len(parts1), len(parts2))):
            part1 = parts1[i]
            part2 = parts2[i]

            is_digit1 = part1.isdigit()
            is_digit2 = part2.isdigit()

            if is_digit1 and is_digit2:
                val1 = int(part1)
                val2 = int(part2)
                if val1 < val2:
                    return -1
                if val1 > val2:
                    return 1
            elif not is_digit1 and not is_digit2:
                if part1 < part2:
                    return -1
                if part1 > part2:
                    return 1
            else:
                # One is digit, one is not. All-digit identifier is older than one that is not.
                return -1 if is_digit1 else 1

        # If every shared identifier is equal, the pre-release with more identifiers is the newer one.
        if len(parts1) < len(parts2):
            return -1
        if len(parts1) > len(parts2):
            return 1

        return 0

    @classmethod
    def satisfies(cls, version: str, spec: str) -> bool:
        raw_conditions = spec.split(',')
        if not raw_conditions or any(not c.strip() for c in raw_conditions):
             raise ValueError("Empty condition")

        for cond in raw_conditions:
            cond = cond.strip()
            match = re.match(r'^(\>=|\>|\<=|\<|==|!=)\s*(.*)$', cond)
            if not match:
                raise ValueError(f"Invalid condition: {cond}")
            op, v_str = match.groups()
            v_str = v_str.strip()

            if not v_str:
                raise ValueError("Missing version in condition")

            res = cls.compare(version, v_str)
            if op == '==':
                if res != 0: return False
            elif op == '>=':
                if res < 0: return False
            elif op == '>':
                if res <= 0: return False
            elif op == '<=':
                if res > 0: return False
            elif op == '<':
                if res >= 0: return False
            elif op == '!=':
                if res == 0: return False

        return True

def compare(a: str, b: str) -> int:
    return VersionComparator.compare(a, b)

def satisfies(version: str, spec: str) -> bool:
    return VersionComparator.satisfies(version, spec)
