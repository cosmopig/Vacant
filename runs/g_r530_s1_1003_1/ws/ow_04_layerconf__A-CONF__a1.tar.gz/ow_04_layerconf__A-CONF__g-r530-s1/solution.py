class Config:
    def __init__(self, defaults, values, sources):
        self._defaults = defaults
        self._values = values
        self._sources = sources

    def get(self, key):
        if key not in self._defaults:
            raise KeyError(key)
        return self._values[key]

    def source(self, key):
        if key not in self._defaults:
            raise KeyError(key)
        return self._sources[key]

    def as_dict(self):
        # The contract says "A key that is not in defaults is ignored wherever it appears and never shows up in as_dict()"
        # This implies only keys from defaults should be in the result.
        # Also, if a default value was overwritten by file or env, it still counts as being there.
        return {k: self._values[k] for k in self._defaults}

def convert(value, target_type):
    if target_type is bool:
        val_lower = str(value).lower()
        if val_lower in ("true", "1", "yes"):
            return True
        if val_lower in ("false", "0", "no"):
            return False
        raise ValueError(f"Cannot convert {value} to bool")
    elif target_type is int:
        try:
            # Python's int() handles strings like "123". 
            # It does not handle "1.0". This matches the requirement of failing loudly for wrong types.
            return int(value)
        except (ValueError, TypeError):
            raise ValueError(f"Cannot convert {value} to int")
    elif target_type is float:
        try:
            return float(value)
        except (ValueError, TypeError):
            raise ValueError(f"Cannot convert {value} to float")
    else: # str
        return str(value)

def load(defaults, file_text, env):
    final_values = {}
    sources = {}

    # Initialize with defaults
    for k, v in defaults.items():
        final_values[k] = v
        sources[k] = "default"

    # Parse file
    file_data = {}
    if file_text:
        current_section = ""
        lines = file_text.splitlines()
        for line in lines:
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            
            if stripped.startswith("[") and stripped.endswith("]"):
                current_section = stripped[1:-1].strip()
            elif "=" in stripped:
                key_part, val_part = stripped.split("=", 1)
                key = key_part.strip()
                val = val_part.strip()
                
                full_key = f"{current_section}.{key}" if current_section else key
                if full_key in defaults:
                    file_data[full_key] = val

    # Parse env
    env_data = {}
    for k, v in env.items():
        if k.startswith("APP_"):
            # APP_DB__PORT -> db.port
            parts = k[4:].split("__")
            key = ".".join(p.lower() for p in parts)
            if key in defaults:
                env_data[key] = v

    # Apply file values (overrides default)
    for k, v in file_data.items():
        final_values[k] = convert(v, type(defaults[k]))
        sources[k] = "file"

    # Apply env values (overrides file and default)
    for k, v in env_data.items():
        final_values[k] = convert(v, type(defaults[k]))
        sources[k] = "env"

    return Config(defaults, final_values, sources)
