2023-10-27T10:00:00Z GET /api/v1/users 200 50
bad line here
2023-10-27T10:00:02Z GET /api/v1/users 200 50
2023-10-27T10:00:04Z GET /api/v1/users 200 50
