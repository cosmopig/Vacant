import sys
import json
import math
from datetime import datetime
from collections import defaultdict

def summarize(lines):
    endpoints = defaultdict(list)
    bad_lines = 0
    total = 0
    
    for line in lines:
        line = line.strip('\n')
        if not line or line.isspace():
            continue
        
        total += 1
        parts = line.split(' ')
        
        if len(parts) != 5:
            bad_lines += 1
            continue
            
        ts_str, method, path, status_str, ms_str = parts
        
        # Validate timestamp
        try:
            dt_str = ts_str.replace('Z', '+00:00')
            datetime.fromisoformat(dt_str)
        except ValueError:
            bad_lines += 1
            continue
            
        # Validate status and ms
        def is_signed_int(s):
            if not s: return False
            if s[0] == '-':
                return s[1:].isdigit()
            return s.isdigit()

        if not (is_signed_int(status_str) and is_signed_int(ms_str)):
            bad_lines += 1
            continue
            
        try:
            status = int(status_str)
            ms = int(ms_str)
        except ValueError:
            bad_lines += 1
            continue

        endpoints[path].append((status, ms))

    result_endpoints = []
    for path, data in endpoints.items():
        n = len(data)
        errors = sum(1 for s, m in data if s >= 500)
        error_rate = round(errors / n, 4)
        
        ms_list = sorted([m for s, m in data])
        p50_idx = math.ceil(0.50 * n)
        p95_idx = math.ceil(0.95 * n)
        
        # nearest-rank: 1-based position ceil(p/100 * n)
        # list is 0-indexed, so subtract 1
        p50_ms = ms_list[max(0, p50_idx - 1)]
        p95_ms = ms_list[max(0, p95_idx - 1)]
        
        result_endpoints.append({
            "path": path,
            "n": n,
            "error_rate": error_rate,
            "p50_ms": p50_ms,
            "p95_ms": p95_ms
        })

    # Sort by n desc, then path asc
    result_endpoints.sort(key=lambda x: (-x["n"], x["path"]))
    
    return {
        "endpoints": result_endpoints,
        "bad_lines": bad_lines,
        "total": total
    }

if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(0)
    with open(sys.argv[1], 'r') as f:
        print(json.dumps(summarize(f), separators=(',', ':')))
