import csv
import json
import sys
import io

def csv_to_jsonl(text: str) -> str:
    if not text or not text.strip():
        return ""
    
    # The requirement says "\n" and "\r\n" are accepted as line endings 
    # and neither survives into a parsed value. This means we should treat them 
    # as delimiters but NOT include them in the field value unless they are inside quotes.
    # Wait, "a field may be wrapped in double quotes; inside such a field ... commas 
    # and line breaks are ordinary characters."
    # This means if it's in quotes, \n IS part of the value. If it's NOT in quotes, 
    # it's a delimiter.

    def parse(content):
        records = []
        current_record = []
        current_field = ""
        in_quotes = False
        line_num = 1
        start_line_num = 1
        i = 0
        n = len(content)
        while i < n:
            char = content[i]
            if char == '"':
                if in_quotes and i + 1 < n and content[i+1] == '"':
                    current_field += '"'
                    i += 1
                else:
                    in_quotes = not in_quotes
            elif char == ',':
                if in_quotes:
                    current_field += ','
                else:
                    current_record.append(current_field)
                    current_field = ""
            elif char == '\n' or char == '\r':
                if in_quotes:
                    # Inside quotes, \n and \r are ordinary characters.
                    # But wait, the requirement says "\n" and "\r\n" are accepted as line endings 
                    # AND neither survives into a parsed value. This is slightly ambiguous.
                    # "a field may be wrapped in double quotes; inside such a field ... commas 
                    # and line breaks are ordinary characters."
                    # Let's assume that if it's in quotes, \n IS part of the value.
                    current_field += char
                else:
                    if current_record or current_field != "":
                        records.append((start_line_num, current_record + [current_field]))
                    current_record = []
                    current_field = ""
                    if char == '\n':
                        line_num += 1
                        start_line_num = line_num
                    elif char == '\r':
                        if i + 1 < n and content[i+1] == '\n':
                            line_num += 1
                            start_line_num = line_num
                            i += 1
                        else:
                            line_num += 1
                            start_line_num = line_num
            else:
                current_field += char
            i += 1
        if in_quotes:
            raise ValueError(f"line {start_line_num}: unclosed quote")
        if current_record or current_field != "":
            records.append((start_line_num, current_record + [current_field]))
        return records

    try:
        all_records = parse(text)
    except ValueError as e:
        raise e

    if not all_records:
        return ""

    header_info = all_records[0][1]
    output = []
    for line_num, row in all_records[1:]:
        if len(row) != len(header_info):
            raise ValueError(f"line {line_num}: field count differs from the header")
        obj = {}
        for i, val in enumerate(row):
            obj[header_info[i]] = val
        output.append(json.dumps(obj))

    return "\n".join(output) + ("\n" if output else "")

if __name__ == "__main__":
    input_file = sys.argv[1]
    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            content = f.read()
        result = csv_to_jsonl(content)
        sys.stdout.write(result)
    except ValueError as e:
        sys.stderr.write(str(e) + "\n")
        sys.exit(2)
    except Exception:
        sys.exit(1)

