from datetime import datetime, timezone

def parse_instant(instant: str) -> datetime:
    if len(instant) == 10 and instant[4] == '-':
        return datetime.strptime(instant, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    elif "T" in instant:
        return datetime.strptime(instant, "%Y-%m-%dT%H:%M:%S").replace(tzinfo=timezone.utc)
    else:
        raise ValueError(f"Invalid format: {instant}")

def format_instant(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%S")

def merge(spans: list[tuple[str, str]]) -> list[tuple[str, str]]:
    parsed = []
    for s, e in spans:
        start = parse_instant(s)
        end = parse_instant(e)
        if end < start: raise ValueError()
        parsed.append((start, end))
    parsed.sort()
    merged = []
    for cur_s, cur_e in parsed:
        if cur_s == cur_e: continue
        if not merged or cur_s > merged[-1][1]:
            merged.append((cur_s, cur_e))
        else:
            prev_s, prev_e = merged[-1]
            merged[-1] = (prev_s, max(prev_e, cur_e))
    return [(format_instant(s), format_instant(e)) for s, e in merged]

def subtract(spans: list[tuple[str, str]], holes: list[tuple[str, str]]) -> list[tuple[str, str]]:
    merged_spans = merge(spans)
    parsed_spans = [(parse_instant(s), parse_instant(e)) for s, e in merged_spans]
    parsed_holes = []
    for h_s, h_e in holes:
        h_start = parse_instant(h_s)
        h_end = parse_instant(h_e)
        if h_end < h_start: raise ValueError()
        parsed_holes.append((h_start, h_end))
    parsed_holes.sort()
    merged_holes = []
    for h_s, h_e in parsed_holes:
        if not merged_holes or h_s > merged_holes[-1][1]:
            merged_holes.append((h_s, h_e))
        else:
            prev_s, prev_e = merged_holes[-1]
            merged_holes[-1] = (prev_s, max(prev_e, h_e))
    result = []
    for s_start, s_end in parsed_spans:
        current_segments = [(s_start, s_end)]
        for h_start, h_end in merged_holes:
            next_segments = []
            for cur_start, cur_end in current_segments:
                if h_end <= cur_start or h_start >= cur_end:
                    next_segments.append((cur_start, cur_end))
                else:
                    if h_start > cur_start: next_segments.append((cur_start, h_start))
                    if h_end < cur_end: next_segments.append((h_end, cur_end))
            current_segments = next_segments
        result.extend(current_segments)
    result.sort()
    final_merged = []
    for start, end in result:
        if start == end: continue
        if not final_merged or start > final_merged[-1][1]:
            final_merged.append((start, end))
        else:
            prev_s, prev_e = final_merged[-1]
            final_merged[-1] = (prev_s, max(prev_e, end))
    return [(format_instant(s), format_instant(e)) for s, e in final_merged]

def total_seconds(spans: list[tuple[str, str]]) -> int:
    merged = merge(spans)
    total = 0
    for s, e in merged:
        total += (parse_instant(e) - parse_instant(s)).total_seconds()
    return int(total)
