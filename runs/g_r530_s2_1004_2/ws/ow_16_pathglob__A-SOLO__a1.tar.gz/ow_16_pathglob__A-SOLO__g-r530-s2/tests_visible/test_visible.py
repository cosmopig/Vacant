import unittest
from solution import Solution

class TestSolution(unittest.TestCase):
    def test_basic_matching(self):
        sol = Solution()
        # Simple matches
        self.assertTrue(sol.matches("a", "a"))
        self.assertFalse(sol.matches("a", "ab"))
        self.assertTrue(sol.matches("a/b", "a/b"))
        self.assertFalse(sol.matches("a/b", "a/c"))
        # Wildcards
        self.assertTrue(sol.matches("*", "abc"))
        self.assertTrue(sol.matches("*", ""))
        self.assertFalse(sol.matches("*", "a/b"))
        self.assertTrue(sol.matches("?", "a"))
        self.assertFalse(sol.matches("?", ""))
        # Brackets
        self.assertTrue(sol.matches("[abc]", "a"))
        self.assertTrue(sol.matches("[abc]", "c"))
        self.assertFalse(sol.matches("[abc]", "d"))
        self.assertTrue(sol.matches("[a-z]", "m"))
        self.assertTrue(sol.matches("[0-9]", "5"))
        self.assertFalse(sol.matches("[0-9]", "a"))
        # Negative brackets
        self.assertTrue(sol.matches("[!abc]", "d"))
        self.assertFalse(sol.matches("[!abc]", "a"))
        # Double star
        self.assertTrue(sol.matches("**", "a/b/c"))
        self.assertTrue(sol.matches("**", ""))
        self.assertTrue(sol.matches("a/**", "a/b/c"))
        self.assertTrue(sol.matches("a/**", "a"))
        self.assertFalse(sol.matches("a/*", "a/b/c"))
        # Complex paths
        self.assertTrue(sol.matches("src/*.py", "src/main.py"))
        self.assertTrue(sol.matches("src/*.py", "src/test.py"))
        self.assertFalse(sol.matches("src/*.py", "src/subdir/main.py"))

    def test_select(self):
        sol = Solution()
        paths = ["a", "a/b", "a/c", "b", "b/c"]
        # Simple inclusion
        self.assertEqual(sol.select(["a/*"], paths), ["a/b", "a/c"])
        # Inclusion with **
        self.assertEqual(sol.select(["a/**"], paths), ["a", "a/b", "a/c"])
        # Negation
        self.assertEqual(sol.select(["a/*", "!a/b"], paths), ["a/c"])
        # Order and uniqueness
        paths = ["a/b", "a/b", "a/c"]
        self.assertEqual(sol.select(["a/*"], paths), ["a/b", "a/c"])

    def test_errors(self):
        sol = Solution()
        with self.assertRaises(ValueError):
            sol.matches("[abc", "a")
        with self.assertRaises(ValueError):
            sol.matches("[]", "a")
        with self.assertRaises(ValueError):
            sol.select(["[]"], ["a"])

    def test_edge_cases(self):
        sol = Solution()
        # Empty path
        self.assertTrue(sol.matches("", ""))
        # Pattern with no segments (but not empty) - wait, split("/") on "a" is ["a"]
        # What about pattern "/"? split("/") is ["", ""]
        self.assertTrue(sol.matches("/", "/"))
        # Double star at the end of a path
        self.assertTrue(sol.matches("a/**", "a/b/c") )
        # Multiple double stars
        self.assertTrue(sol.matches("**/**", "a/b/c"))

