import re

class Solution:
    def _parse_segment(self, segment):
        if segment == "**":
            return "DOUBLE_STAR"
        
        regex = ""
        i = 0
        while i < len(segment):
            char = segment[i]
            if char == "?":
                regex += "."
                i += 1
            elif char == "*":
                regex += ".*"
                i += 1
            elif char == "[":
                j = i + 1
                if j >= len(segment):
                    raise ValueError("Unclosed [")
                
                class_content = ""
                while j < len(segment) and segment[j] != "]":
                    class_content += segment[j]
                    j += 1
                
                if j == len(segment):
                    raise ValueError("Unclosed [")
                
                if not class_content:
                    raise ValueError("Empty class")
                
                negate = False
                if class_content.startswith("!"):
                    negate = True
                    class_content = class_content[1:]
                
                chars = set()
                k = 0
                while k < len(class_content):
                    if k + 2 < len(class_content) and class_content[k+1] == '-':
                        start = class_content[k]
                        end = class_content[k+2]
                        for char_code in range(ord(start), ord(end) + 1):
                            chars.add(chr(char_code))
                        k += 3
                    else:
                        chars.add(class_content[k])
                        k += 1
                
                if negate:
                    escaped_chars = sorted(list(chars))
                    inner_regex = ""
                    for c in escaped_chars:
                        inner_regex += re.escape(c)
                    regex += f"[^{inner_regex}]"
                else:
                    sorted_chars = sorted(list(chars))
                    inner_regex = ""
                    # To keep it compact, we could use ranges, but let's just list them.
                    for c in sorted_chars:
                        inner_regex += re.escape(c)
                    regex += f"[{inner_regex}]"
                i = j + 1
            else:
                regex += re.escape(char)
                i += 1
        return regex

    def matches(self, pattern: str, path: str) -> bool:
        path_segments = path.split("/")
        pattern_segments = pattern.split("/")
        
        memo = {}
        def match_recursive(p_idx, path_idx):
            state = (p_idx, path_idx)
            if state in memo: return memo[state]
            
            if p_idx == len(pattern_segments):
                return path_idx == len(path_segments)
            
            seg = pattern_segments[p_idx]
            if seg == "**":
                for count in range(len(path_segments) - path_idx + 1):
                    if match_recursive(p_idx + 1, path_idx + count):
                        memo[state] = True
                        return True
                memo[state] = False
                return False
            else:
                if path_idx < len(path_segments):
                    seg_regex = self._parse_segment(seg)
                    if re.fullmatch(seg_regex, path_segments[path_idx]):
                        res = match_recursive(p_idx + 1, path_idx + 1)
                        memo[state] = res
                        return res
                memo[state] = False
                return False

        return match_recursive(0, 0)

    def select(self, patterns: list[str], paths: list[str]) -> list[str]:
        selected = set()
        for pattern in patterns:
            is_negate = False
            if pattern.startswith("!"):
                is_negate = True
                pattern = pattern[1:]
            
            # The rule is "a pattern beginning with ! removes every path picked up so far that matches the rest of the pattern."
            # This means we only remove paths that were ALREADY in 'selected'.
            if is_negate:
                to_remove = set()
                for path in selected:
                    if self.matches(pattern, path):
                        to_remove.add(path)
                selected -= to_remove
            else:
                # Add every path that matches the pattern to 'selected'.
                # "A plain pattern adds every path that matches it"
                for path in paths:
                    if self.matches(pattern, path):
                        selected.add(path)
        
        result = []
        seen = set()
        for path in paths:
            if path in selected and path not in seen:
                result.append(path)
                seen.add(path)
        return result

