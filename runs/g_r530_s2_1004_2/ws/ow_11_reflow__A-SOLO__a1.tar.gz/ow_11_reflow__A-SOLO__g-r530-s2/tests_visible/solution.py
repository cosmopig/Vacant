import sys
import re
import unicodedata

def get_char_width(c):
    try:
        w = unicodedata.east_asian_width(c)
        if w in ('W', 'F'):
            return 2
        return 1
    except (ImportError, AttributeError):
        if '\u4e00' <= c <= '\u9fff' or '\u3000' <= c <= '\u303f':
            return 2
        return 1

def solution(text, width):
    if width <= 0:
        raise ValueError("Width must be positive")

    lines = text.splitlines(keepends=True)
    output = []
    i = 0
    while i < len(lines):
        line = lines[i]
        # Code block
        if line.strip().startswith('```'):
            block = []
            while i < len(lines):
                block.append(lines[i])
                i += 1
                if lines[i-1].strip().startswith('```'):
                    break
            output.extend(block)
            continue

        # Blank line
        if not line.strip():
            output.append(line if line.endswith('\n') else "")
            if not line.endswith('\n') and i < len(lines):
                output[-1] += '\n'
            i += 1
            continue

        # Paragraph / Bullet logic
        para_lines = []
        while i < len(lines):
            curr_line = lines[i]
            if not curr_line.strip() or curr_line.strip().startswith('```'):
                break
            
            stripped = curr_line.lstrip()
            is_bullet = False
            if stripped.startswith('- ') or stripped.startswith('* '):
                is_bullet = True
            elif re.match(r'^\d+\.\s', stripped):
                is_bullet = True
            
            if is_bullet and para_lines:
                break
            
            para_lines.append(curr_line)
            i += 1

        first_line_raw = para_lines[0]
        stripped_first = first_line_raw.lstrip()
        
        is_bullet_para = False
        marker_len = 0
        if stripped_first.startswith('- '):
            is_bullet_para = True
            marker_len = 2
        elif stripped_first.startswith('* '):
            is_bullet_para = True
            marker_len = 2
        else:
            m = re.match(r'^(\d+)\.\s', stripped_first)
            if m:
                is_bullet_para = True
                marker_len = len(m.group(0))

        # Collect all words from the paragraph, but keep marker for first line
        words_to_process = []
        for idx, raw_line in enumerate(para_lines):
            stripped = raw_line.lstrip()
            if not stripped: continue
            
            content = stripped
            if is_bullet_para and idx > 0:
                # For continuation lines of a bullet para, the marker is NOT part of content
                if stripped.startswith('- '):
                    content = stripped[2:]
                elif stripped.startswith('* '):
                    content = stripped[2:]
                else:
                    m = re.match(r'^(\d+)\.\s', stripped)
                    if m:
                        content = stripped[len(m.group(0)):]
            words_to_process.extend(content.split())

        first_line_indent = first_line_raw[:first_line_raw.find(stripped_first)]
        
        current_word_idx = 0
        while current_word_idx < len(words_to_process):
            # Determine indentation for this line
            is_first_line_of_para = (len(output) == 0 or (output and output[-1].endswith('\n') and output[-1] != ""))
            # Wait, the blank lines might be between paragraphs. Let's just use a flag that resets every paragraph.
            pass

        # Corrected wrapping logic:
        current_para_output = []
        words_to_process = words_to_process 
        
        # We need to know if it's the first line of this paragraph in our output list.
        is_first_line_of_para = True
        while current_word_idx < len(words_to_process):
            if is_first_line_of_para:
                indent_str = first_line_indent
                # If it's a bullet para, the marker is part of the first line content
                # But we already included it in words_to_process for idx=0? 
                # Let's re-think.
                pass

    EOF
