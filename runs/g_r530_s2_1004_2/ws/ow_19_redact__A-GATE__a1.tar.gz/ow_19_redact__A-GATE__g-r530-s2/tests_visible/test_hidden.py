import solution

def check_v03_multiple_secrets():
    line = "AKIAIOSFODNN7EXAMPLE and eyJhbGciOiJIUzI1NiJ9.e30.abcdef"
    got = solution.redact(line)
    assert "AKIAIOSFODNN7EXAMPLE" not in got
    assert "eyJhbGciOiJIUzI1NiJ9.e30.abcdef" not in got
    assert "[REDACTED]" in got

def check_v04_connection_strings():
    lines = [
        "postgres://svc:hunter2@db.internal:5432/app",
        "mysql://user:pass@host:3306/db",
        "mongodb://admin:secret@mongo:27017/",
        "redis://default:password@redis:6379/",
        "amqp://guest:guest@rabbitmq:5672/"
    ]
    for line in lines:
        got = solution.redact(line)
        assert "[REDACTED]" in got
        assert "hunter2" not in got
        assert "pass" not in got

def check_v05_partial_secrets():
    # Keys with other text in them
    line = "The key is AKIAIOSFODNN7EXAMPLE and it's important."
    got = solution.redact(line)
    assert "AKIAIOSFODNN7EXAMPLE" not in got
    assert "The key is" in got

def check_v06_non_dot_tokens():
    # Tokens that are not made of dot-separated parts
    line = "Authorization: Bearer abc123xyzABC123xyzABC123xyzABC123xyz"
    got = solution.redact(line)
    assert "abc123xyzABC123xyzABC123xyzABC123xyz" not in got

def check_v07_idempotency():
    line = "postgres://svc:hunter2@db.internal:5432/app"
    once = solution.redact(line)
    twice = solution.redact(once)
    assert once == twice

def check_v08_findings_count():
    line = "AKIAIOSFODNN7EXAMPLE and AKIAIOSFODNN7EXAMPLE"
    found = solution.findings(line)
    # Wait, the goal says "a secret that appears twice in one line is gone both times".
    # And findings should return a list of secrets found. 
    # If it's there twice, should it be in findings twice? 
    # Usually yes, unless specified otherwise.
    assert len(found) == 2

def check_v09_empty_line():
    assert solution.redact("") == ""
    assert solution.findings("") == []

if __name__ == "__main__":
    check_v03_multiple_secrets()
    check_v04_connection_strings()
    check_v05_partial_secrets()
    check_v06_non_dot_tokens()
    check_v07_idempotency()
    check_v08_findings_count()
    check_v09_empty_line()
