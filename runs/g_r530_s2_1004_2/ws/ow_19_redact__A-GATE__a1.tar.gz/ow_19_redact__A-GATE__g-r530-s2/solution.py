import re

def find_secrets(text):
    secrets = []
    
    # 1. AWS Keys (AKIA...) - Let's look for AKIA or ASIA followed by 16 alphanumeric chars
    aws_pattern = r'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b'
    for m in re.finditer(aws_pattern, text):
        secrets.append(m.group())

    # 2. Connection strings (mysql://..., postgres://..., etc.)
    # Pattern: [a-z]+://[^/\s:]+:[^@\s]+@[^/\s]+:[0-9]+/[^\s]*
    conn_pattern = r'\b(?:postgres|mysql|mongodb|redis|amqp)://[^/\s:]+:[^@\s]+@[^/\s]+:[0-9]+/[^\s]*'
    for m in re.finditer(conn_pattern, text):
        secrets.append(m.group())

    # 3. Bearer tokens / JWTs (dot separated)
    jwt_pattern = r'\b[A-Za-z0-9-_]{20,}\.[A-Za-z0-9-_]{10,}\.[A-Za-z0-9-_]{10,}\b'
    for m in re.finditer(jwt_pattern, text):
        secrets.append(m.group())

    # 4. Tokens that are not made of dot-separated parts (e.g., long random strings)
    bearer_pattern = r'(?<=Bearer\s)[A-Za-z0-9\._\-\/]{20,}'
    for m in re.finditer(bearer_pattern, text):
        secrets.append(m.group())

    return secrets

def redact(text: str) -> str:
    found = find_secrets(text)
    if not found:
        return text
    
    # Sort by length descending to replace longer matches first (e.g., full connection string before just the host)
    sorted_secrets = sorted(list(set(found)), key=len, reverse=True)
    
    result = text
    for s in sorted_secrets:
        if s == "[REDACTED]": continue
        # We use a regex to replace only if it's not already part of [REDACTED]
        # Actually, since we are replacing with [REDACTED], and the secrets themselves 
        # shouldn't contain "[REDACTED]", simple replacement is mostly fine.
        result = result.replace(s, "[REDACTED]")
    
    return result

def findings(text: str) -> list[str]:
    return find_secrets(text)
