class Solution:
    def matches(self, pattern: str, path: str) -> bool:
        p_segs = pattern.split('/')
        s_segs = path.split('/')
        
        memo = {}

        def match_segment_string(p_str, s_str):
            # This function matches a single segment (no / allowed).
            m = {}
            def m_inner(pi, si):
                if (pi, si) in m: return m[(pi, si)]
                if pi == len(p_str): return si == len(s_str)
                
                char = p_str[pi]
                if char == '*':
                    for i in range(si, len(s_str) + 1):
                        if m_inner(pi + 1, i):
                            m[(pi, si)] = True
                            return True
                elif char == '?':
                    if si < len(s_str) and m_inner(pi + 1, si + 1):
                        m[(pi, si)] = True
                        return True
                elif char == '[':
                    end = p_str.find(']', pi)
                    if end == -1: raise ValueError("Unclosed [")
                    content = p_str[pi+1:end]
                    if not content: raise ValueError("Empty class")
                    negate = False
                    if content.startswith('!'):
                        negate = True
                        content = content[1:]
                    allowed = set()
                    j = 0
                    while j < len(content):
                        if j + 1 < len(content) and content[j+1] == '-':
                            start_char = content[j]
                            end_range_char = content[j+1]
                            # Range check: if start > end, the range is empty.
                            if ord(start_char) <= ord(end_range_char):
                                for char_code in range(ord(start_char), ord(end_range_char) + 1):
                                    allowed.add(chr(char_code))
                            j += 2
                        else:
                            allowed.add(content[j])
                            j += 1
                    if si < len(s_str):
                        c = s_str[si]
                        res = (c in allowed) if not negate else (c not in allowed)
                        if res and m_inner(end + 1, si + 1):
                            m[(pi, si)] = True
                            return True
                else:
                    if si < len(s_str) and p_str[pi] == s_str[si]:
                        if m_inner(pi + 1, si + 1):
                            m[(pi, si)] = True
                            return True
                m[(pi, si)] = False
                return False
            return m_inner(0, 0)

        def solve(p_idx, s_idx):
            state = (p_idx, s_idx)
            if state in memo: return memo[state]
            
            if p_idx == len(p_segs):
                return s_idx == len(s_segs)
            
            curr_p = p_segs[p_idx]
            
            if curr_p == '**':
                for i in range(s_idx, len(s_segs) + 1):
                    if solve(p_idx + 1, i):
                        memo[state] = True
                        return True
            else:
                # Handle empty segments (e.g., "a//b" -> ["a", "", "b"])
                if s_idx < len(s_segs):
                    curr_s = s_segs[s_idx]
                    try:
                        if match_segment_string(curr_p, curr_s):
                            if solve(p_idx + 1, s_idx + 1):
                                memo[state] = True
                                return True
                    except ValueError:
                        pass
                elif curr_p == "": # Pattern has an empty segment like "a//b"
                    if solve(p_idx + 1, s_idx):
                        memo[state] = True
                        return True

            memo[state] = False
            return False

        return solve(0, 0)

    def select(self, patterns: list[str], paths: list[str]) -> list[str]:
        current_selected = [False] * len(paths)
        for p in patterns:
            if p.startswith('!'):
                sub_p = p[1:]
                for i, path in enumerate(paths):
                    if current_selected[i]:
                        if self.matches(sub_p, path):
                            current_selected[i] = False
            else:
                for i, path in enumerate(paths):
                    if not current_selected[i]:
                        if self.matches(p, path):
                            current_selected[i] = True
        return [paths[i] for i, selected in enumerate(current_selected) if selected]

