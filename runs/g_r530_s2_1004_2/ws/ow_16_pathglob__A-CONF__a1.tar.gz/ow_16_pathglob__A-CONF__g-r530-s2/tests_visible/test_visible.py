from solution import Solution

def test():
    sol = Solution()
    
    # Test matches
    assert sol.matches("src/*.py", "src/main.py") == True
    assert sol.matches("src/*.py", "src/main.pyc") == False
    assert sol.matches("src/*.py", "src/sub/main.py") == False
    assert sol.matches("src/**", "src/sub/main.py") == True
    assert sol.matches("src/**", "src/") == True
    assert sol.matches("a[b-d]c", "abc") == True
    assert sol.matches("a[b-d]c", "aec") == False
    assert sol.matches("a[!b-d]c", "aec") == True
    assert sol.matches("a[!b-d]c", "abc") == False
    assert sol.matches("a?c", "abc") == True
    assert sol.matches("a?c", "abcd") == False
    assert sol.matches("a*c", "abbbc") == True
    assert sol.matches("a*c", "ac") == True
    assert sol.matches("a*c", "abc") == False

    # Test select
    paths = ["src/main.py", "src/sub/main.py", "tests/test.py", "docs/readme.md"]
    patterns1 = ["src/**", "tests/**"]
    assert sol.select(patterns1, paths) == ["src/main.py", "src/sub/main.py", "tests/test.py"]
    
    patterns2 = ["src/**", "!src/main.py"]
    assert sol.select(patterns2, paths) == ["src/sub/main.py"]

    patterns3 = ["src/**", "!src/main.py", "docs/*"]
    assert sol.select(patterns3, paths) == ["src/sub/main.py", "docs/readme.md"]

    # Test ValueError
    try:
        sol.matches("[a-z", "abc")
    except ValueError:
        pass
    else:
        raise AssertionError("Should have raised ValueError for unclosed [")

    try:
        sol.matches("[]", "a")
    except ValueError:
        pass
    else:
        raise AssertionError("Should have raised ValueError for empty class")

if __name__ == "__main__":
    test()
