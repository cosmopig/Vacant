import re

class Solution:
    def matches(self, pattern: str, path: str) -> bool:
        pattern_segments = pattern.split('/')
        path_segments = path.split('/')
        
        def match_segment_simple(p_seg, s_seg):
            regex_parts = []
            i = 0
            while i < len(p_seg):
                char = p_seg[i]
                if char == '?':
                    regex_parts.append('.')
                    i += 1
                elif char == '*':
                    # Check if it's ** - but we already know p_seg != "**" here
                    if i + 1 < len(p_seg) and p_seg[i+1] == '*':
                        break 
                    else:
                        regex_parts.append('.*')
                        i += 1
                elif char == '[':
                    j = i + 1
                    while j < len(p_seg) and p_seg[j] != ']':
                        j += 1
                    if j == len(p_seg): raise ValueError("Unclosed [")
                    content = p_seg[i+1:j]
                    if not content: raise ValueError("Empty class")
                    negate = False
                    if content.startswith('!'):
                        negate = True
                        content = content[1:]
                    class_regex = ""
                    k = 0
                    while k < len(content):
                        if k + 2 < len(content) and content[k+1] == '-':
                            start = ord(content[k])
                            end = ord(content[k+2])
                            class_regex += f"{chr(start)}-{chr(end)}"
                            k += 3
                        else:
                            class_regex += re.escape(content[k])
                            k += 1
                    if negate:
                        class_regex = f"[^{re.escape(content)}]"
                    else:
                        class_regex = f"[{class_regex}]"
                    regex_parts.append(class_regex)
                    i = j + 1
                else:
                    regex_parts.append(re.escape(char))
                    i += 1
            return re.fullmatch("".join(regex_parts), s_seg) is not None

        memo = {}
        def solve_final(p_idx, s_idx):
            if (p_idx, s_idx) in memo: return memo[(p_idx, s_idx)]
            if p_idx == len(pattern_segments) and s_idx == len(path_segments):
                return True
            if p_idx == len(pattern_segments):
                return False
            
            p_seg = pattern_segments[p_idx]
            if p_seg == "**":
                # Option 1: ** matches zero segments
                res = solve_final(p_idx + 1, s_idx)
                if not res and s_idx < len(path_segments):
                    # Option 2: ** matches one or more segments (recursive)
                    res = res or solve_final(p_idx, s_idx + 1)
                memo[(p_idx, s_idx)] = res
                return res
            else:
                if s_idx < len(path_segments):
                    if match_segment_simple(p_seg, path_segments[s_idx]):
                        res = solve_final(p_idx + 1, s_idx + 1)
                        memo[(p_idx, s_idx)] = res
                        return res
                memo[(p_idx, s_idx)] = False
                return False

        return solve_final(0, 0)

    def select(self, patterns: list[str], paths: list[str]) -> list[str]:
        selected = set()
        for pattern in patterns:
            is_negate = False
            if pattern.startswith('!'):
                is_negate = True
                pattern = pattern[1:]
            
            try:
                self._validate_pattern(pattern)
            except ValueError as e:
                raise e

            matches = []
            for path in paths:
                if self.matches(pattern, path):
                    matches.append(path)
            
            if is_negate:
                to_remove = set()
                for path in matches:
                    if path in selected:
                        to_remove.add(path)
                for path in to_remove:
                    selected.remove(path)
            else:
                for path in matches:
                    selected.add(path)
        
        result = []
        seen = set()
        for path in paths:
            if path in selected and path not in seen:
                result.append(path)
                seen.add(path)
        return result

    def _validate_pattern(self, pattern):
        segments = pattern.split('/')
        for seg in segments:
            i = 0
            while i < len(seg):
                if seg[i] == '[':
                    j = i + 1
                    while j < len(seg) and seg[j] != ']':
                        j += 1
                    if j == len(seg):
                        raise ValueError("Unclosed [")
                    content = seg[i+1:j]
                    if not content:
                        raise ValueError("Empty class")
                    i = j + 1
                else:
                    i += 1

