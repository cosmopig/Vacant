import re

class Solution:
    def parse(self, text: str) -> dict:
        data = {}
        current_group = data
        lines = text.splitlines()
        opened_headings = set()
        
        for i, line in enumerate(lines):
            line_num = i + 1
            comment_idx = -1
            in_quote = False
            escaped = False
            for j, char in enumerate(line):
                if escaped:
                    escaped = False
                    continue
                if char == '\\':
                    escaped = True
                elif char == '"':
                    in_quote = not in_quote
                elif char == '#' and not in_quote:
                    comment_idx = j
                    break
            
            content = line[:comment_idx] if comment_idx != -1 else line
            stripped = content.strip()
            if not stripped or stripped.startswith('#'):
                continue

            if stripped.startswith('[') and stripped.endswith(']'):
                heading_str = stripped[1:-1].strip()
                parts = heading_str.split('.')
                full_heading = ".".join(parts)
                if full_heading in opened_headings:
                    raise ValueError(f"line {line_num}: duplicate heading")
                opened_headings.add(full_heading)
                
                new_group = data
                for part in parts:
                    part = part.strip()
                    if not re.match(r'^[a-zA-Z0-9_-]+$', part):
                        raise ValueError(f"line {line_num}: invalid name")
                    # If a heading [a] was already there as a setting, it's a mistake?
                    # Actually, the rule says "the same heading opened twice". 
                    if part not in new_group or not isinstance(new_group[part], dict):
                        # This is where we need to be careful. If [a] was already there as a setting,
                        # it's not a duplicate heading, but the rule says "the same heading opened twice".
                        # Let's assume if it exists and is NOT a dict, it's an error? 
                        # No, let's just overwrite or something. But wait, "Names before the first heading live at the top level."
                        pass
                    new_group = new_group[part] = {}
                current_group = new_group
            elif '=' in stripped:
                name, val = stripped.split('=', 1)
                name = name.strip()
                val = val.strip()
                if not re.match(r'^[a-zA-Z0-9_-]+$', name):
                    raise ValueError(f"line {line_num}: invalid name")
                if name in current_group:
                    raise ValueError(f"line {line_num}: duplicate setting")
                current_group[name] = self._parse_value(val)

        return data

    def _parse_value(self, val):
        # String
        if val.startswith('"') and val.endswith('"'):
            content = val[1:-1]
            res = []
            i = 0
            while i < len(content):
                char = content[i]
                if char == '\\':
                    i += 1
                    if i >= len(content): break
                    next_char = content[i]
                    if next_char == '"': res.append('"')
                    elif next_char == '\\': res.append('\\')
                    elif next_char == 'n': res.append('\n')
                    elif next_char == 't': res.append('\t')
                    else: res.append(next_char)
                else:
                    res.append(char)
                i += 1
            return "".join(res)
        # Boolean
        if val == "true": return True
        if val == "false": return False
        # List
        if val.startswith('[') and val.endswith(']'):
            inner = val[1:-1].strip()
            if not inner:
                return []
            items = []
            i = 0
            while i < len(inner):
                if inner[i].isspace():
                    i += 1
                    continue
                start = i
                in_quote = False
                escaped = False
                while i < len(inner):
                    char = inner[i]
                    if escaped:
                        escaped = False
                    elif char == '\\':
                        escaped = True
                    elif char == '"' and not escaped:
                        in_quote = not in_quote
                    elif char == ',' and not in_quote:
                        break
                    i += 1
                items.append(inner[start:i].strip())
            
            parsed_items = [self._parse_value(item) for item in items]
            if not parsed_items: return []
            first_type = type(parsed_items[0])
            # Special check because bool is a subclass of int
            if first_type == bool:
                if not all(isinstance(x, bool) for x in parsed_items):
                    raise ValueError("list items must be same kind")
            elif first_type == int:
                if not all(type(x) == int for x in parsed_items):
                     raise ValueError("list items must be same kind")
            else:
                if not all(isinstance(x, first_type) for x in parsed_items):
                    raise ValueError("list items must be same kind")
            return parsed_items

        # Number (Decimal or Whole)
        try:
            if '.' in val:
                return float(val)
            else:
                return int(val)
        except ValueError:
            raise ValueError("invalid value")

    def dumps(self, data: dict) -> str:
        lines = []
        # Top-level names first
        top_level_names = sorted([k for k, v in data.items() if not isinstance(v, dict)])
        for k in top_level_names:
            lines.append(f'{k} = {self._dump_value(data[k])}')
        
        # Headings next
        headings = []
        def collect_headings(d, prefix=""):
            keys = sorted(d.keys())
            for k in keys:
                if isinstance(d[k], dict):
                    new_prefix = f"{prefix}.{k}" if prefix else k
                    headings.append((new_prefix, d[k]))
                    collect_headings(d[k], new_prefix)
        
        collect_headings(data)
        # Sort headings by their full name (the prefix).
        headings.sort(key=lambda x: x[0])
        
        for prefix, group in headings:
            lines.append("") # Blank line before each heading
            lines.append(f"[{prefix}]")
            group_names = sorted([k for k, v in group.items() if not isinstance(v, dict)])
            # Wait, "with its own names". Does this include nested headings?
            # The rule says "each heading... with its own names". 
            # This usually means only the immediate names.
            for k in group_names:
                lines.append(f'{k} = {self._dump_value(group[k])}')
        
        return "\n".join(lines)

    def _dump_value(self, v):
        if isinstance(v, bool): return "true" if v else "false"
        if isinstance(v, int): return str(v)
        if isinstance(v, float): 
            # Use .0 for whole numbers? The rule says "decimal written -?digits.digits".
            # This might mean we should avoid .0 if it's a whole number.
            # But the rule doesn't say anything about that.
            return str(v)
        if isinstance(v, str):
            res = []
            for char in v:
                if char == '"': res.append('\\"')
                elif char == '\\': res.append('\\\\')
                elif char == '\n': res.append('\\n')
                elif char == '\t': res.append('\\t')
                else: res.append(char)
            return f'"{ "".join(res) }"'
        if isinstance(v, list):
            # Rule says "a list [v, v, v] whose items are all of the same kind"
            # and "never lists themselves".
            items = []
            for item in v:
                if isinstance(item, bool): items.append("true" if item else "false")
                elif isinstance(item, int): items.append(str(item))
                elif isinstance(item, float): items.append(str(item))
                elif isinstance(item, str):
                    res = []
                    for char in item:
                        if char == '"': res.append('\\"')
                        elif char == '\\': res.append('\\\\')
                        elif char == '\n': res.append('\\n')
                        elif char == '\t': res.append('\\t')
                        else: res.append(char)
                    items.append(f'"{ "".join(res) }"')
            return f"[{', '.join(items)}]"
        raise ValueError("cannot dump")

def parse(text: str) -> dict:
    return Solution().parse(text)

def dumps(data: dict) -> str:
    return Solution().dumps(data)
