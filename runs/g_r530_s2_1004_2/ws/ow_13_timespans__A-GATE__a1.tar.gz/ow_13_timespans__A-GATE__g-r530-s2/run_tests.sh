#!/bin/bash
python3 -c "import solution; from tests_visible import test_visible; test_visible.check_v01_merge_overlaps(); test_visible.check_v02_subtract_from_an_end(); test_visible.check_v03_total()"
