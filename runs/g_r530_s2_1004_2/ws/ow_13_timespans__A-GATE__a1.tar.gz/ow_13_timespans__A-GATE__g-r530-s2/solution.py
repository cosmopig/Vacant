from datetime import datetime

class Solution:
    def _parse_instant(self, instant_str: str) -> datetime:
        if "T" in instant_str:
            try:
                return datetime.strptime(instant_str, "%Y-%m-%dT%H:%M:%S")
            except ValueError:
                raise ValueError(f"Invalid time format: {instant_str}")
        else:
            try:
                # Date only means midnight at the start of that day
                return datetime.strptime(instant_str, "%Y-%m-%d")
            except ValueError:
                raise ValueError(f"Invalid date format: {instant_str}")

    def _format_instant(self, dt: datetime) -> str:
        return dt.strftime("%Y-%m-%dT%H:%M:%S")

    def merge(self, spans: list[tuple[str, str]]) -> list[tuple[str, str]]:
        parsed = []
        for s, e in spans:
            start_dt = self._parse_instant(s)
            end_dt = self._parse_instant(e)
            if end_dt < start_dt:
                raise ValueError(f"End {e} is before start {s}")
            parsed.append((start_dt, end_dt))

        # Filter out zero-length spans and sort by start time
        parsed = sorted([p for p in parsed if p[0] != p[1]], key=lambda x: x[0])
        
        if not parsed:
            return []

        merged = []
        curr_start, curr_end = parsed[0]

        for i in range(1, len(parsed)):
            next_start, next_end = parsed[i]
            if next_start <= curr_end:
                # Overlap or touch end-to-end
                curr_end = max(curr_end, next_end)
            else:
                merged.append((curr_start, curr_end))
                curr_start, curr_end = next_start, next_end
        
        merged.append((curr_start, curr_end))

        return [(self._format_instant(s), self._format_instant(e)) for s, e in merged]

    def subtract(self, spans: list[tuple[str, str]], holes: list[tuple[str, str]]) -> list[tuple[str, str]]:
        merged_spans = self.merge(spans)
        
        parsed_holes = []
        for h_s, h_e in holes:
            h_start = self._parse_instant(h_s)
            h_end = self._parse_instant(h_e)
            if h_end < h_start:
                raise ValueError(f"End {h_e} is before start {h_s}")
            if h_start != h_end:
                parsed_holes.append((h_start, h_end))
        
        # Sort holes by start time and merge them to simplify subtraction logic
        parsed_holes = sorted(parsed_holes)
        merged_holes = []
        if parsed_holes:
            curr_h_start, curr_h_end = parsed_holes[0]
            for i in range(1, len(parsed_holes)):
                next_h_start, next_h_end = parsed_holes[i]
                if next_h_start <= curr_h_end:
                    curr_h_end = max(curr_h_end, next_h_end)
                else:
                    merged_holes.append((curr_h_start, curr_h_end))
                    curr_h_start, curr_h_end = next_h_start, next_h_end
            merged_holes.append((curr_h_start, curr_h_end))

        result_spans = []
        for s_str, e_str in merged_spans:
            s_dt = self._parse_instant(s_str)
            e_dt = self._parse_instant(e_str)
            
            current_segments = [(s_dt, e_dt)]
            
            for h_start, h_end in merged_holes:
                new_segments = []
                for seg_start, seg_end in current_segments:
                    # If hole is completely before segment
                    if h_end <= seg_start:
                        new_segments.append((seg_start, seg_end))
                    # If hole is completely after segment
                    elif h_start >= seg_end:
                        new_segments.append((seg_start, seg_end))
                    else:
                        # Overlap exists
                        if h_start > seg_start:
                            new_segments.append((seg_start, h_start))
                        if h_end < seg_end:
                            new_segments.append((h_end, seg_end))
                current_segments = new_segments
            
            for rs, re in current_segments:
                if rs != re:
                    result_spans.append((self._format_instant(rs), self._format_instant(re)))

        # Final sort and merge to ensure the result is tidy (though it should be already)
        final_spans = []
        if result_spans:
            result_spans.sort()
            curr_start, curr_end = self._parse_instant(result_spans[0][0]), self._parse_instant(result_spans[0][1])
            for i in range(1, len(result_spans)):
                next_s_str, next_e_str = result_spans[i]
                next_s, next_e = self._parse_instant(next_s_str), self._parse_instant(next_e_str)
                if next_s <= curr_end:
                    curr_end = max(curr_end, next_e)
                else:
                    final_spans.append((self._format_instant(curr_start), self._format_instant(curr_end)))
                    curr_start, curr_end = next_s, next_e
            final_spans.append((self._format_instant(curr_start), self._format_instant(curr_end)))
        else:
            final_spans = []

        return final_spans

    def total_seconds(self, spans: list[tuple[str, str]]) -> int:
        merged = self.merge(spans)
        total = 0
        for s_str, e_str in merged:
            s_dt = self._parse_instant(s_str)
            e_dt = self._parse_instant(e_str)
            total += int((e_dt - s_dt).total_seconds())
        return total

# To make it accessible as a module with attributes merge, subtract, total_seconds
merge = Solution().merge
subtract = Solution().subtract
total_seconds = Solution().total_seconds
