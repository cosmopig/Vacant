import re

# Secret types identified from logs:
# 1. AWS Keys (AKIA...) - "keys with other text in them"
#    Example: AKIAIOSFODNN7EXAMPLE
#    Pattern: [A-Z0-9]{20} or similar? Let's look at the example again.
#    Actually, it says "keys with other text in them". This might mean they are part of a larger string.
#    Wait, the goal says "the same three kinds turn up written differently: keys with other text in them"
#    This refers to AKIA...

# 2. Bearer Tokens (eyJ...) - "tokens that are not made of dot-separated parts"
#    Example: Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.e30.abcdef
#    Wait, the example IS dot-separated. But it says they turn up written differently: 
#    "tokens that are not made of dot-separated parts".
#    This means we should look for Bearer tokens regardless of dots.

# 3. Database URLs (postgres://...) - "addresses for the other stores they run -- mysql, mongodb, redis and amqp all appear in these logs, written the same way the postgres one is."
#    Example: postgres://svc:hunter2@db.internal:5432/app

patterns = [
    # AWS Keys: AKIA followed by 16 alphanumeric characters (total 20)
    # But it says "with other text in them". This might mean they are substrings of larger strings.
    # Let's try to match the example exactly first and generalize.
    r'\bAKIA[A-Z0-9]{16}\b',

    # Bearer Tokens: Authorization: Bearer [a-zA-Z0-9._\-\+]+
    # The goal says "tokens that are not made of dot-separated parts" turn up.
    # So we should match the token part after "Bearer ".
    r'Bearer\s+[a-zA-Z0-9._\-\+]+',

    # DB URLs: (postgres|mysql|mongodb|redis|amqp)://[^/\s]+/[^/\s]*
    r'(?:postgres|mysql|mongodb|redis|amqp)://[^/\s]+/[^/\s]*'
]

def redact(text: str) -> str:
    # We need to find all secrets and replace them.
    # To avoid double-redacting, we should keep track of what we've replaced.
    # But the goal says "running the pass on a line that has already been through it changes nothing further".
    # This implies our replacement for a secret shouldn't contain any other secrets and 
    # shouldn't look like one.
    
    # Let's refine the patterns to be more specific if possible, or just use them as is.
    # The goal says "none of the secret text is anywhere in the result".
    # and "everything in the line that is not a secret comes back exactly as it was".
    
    # We can find all matches and their spans.
    matches = []
    for pattern in patterns:
        for m in re.finditer(pattern, text):
            matches.append(m)
    
    # Sort matches by start position
    matches.sort(key=lambda x: x.start())
    
    # Filter out overlapping matches (keep the longest one or first one?)
    # Usually, we want to redact the largest possible secret.
    filtered_matches = []
    last_end = -1
    for m in matches:
        if m.start() >= last_end:
            filtered_matches.append(m)
            last_end = m.end()
            
    # Now we redact from back to front to keep indices valid
    result = list(text)
    findings_list = []
    for m in reversed(filtered_matches):
        secret = m.group()
        findings_list.append(secret)
        # Replace with [REDACTED] or similar
        # The goal says "none of the secret text is anywhere in the result"
        # and "everything in the line that is not a secret comes back exactly as it was".
        replacement = "[REDACTED]"
        result[m.start():m.end()] = list(replacement)
    
    return "".join(result)

def findings(text: str) -> list[str]:
    matches = []
    for pattern in patterns:
        for m in re.finditer(pattern, text):
            matches.append(m)
    matches.sort(key=lambda x: x.start())
    
    filtered_matches = []
    last_end = -1
    for m in matches:
        if m.start() >= last_end:
            filtered_matches.append(m)
            last_end = m.end()
            
    return [m.group() for m in filtered_matches]

