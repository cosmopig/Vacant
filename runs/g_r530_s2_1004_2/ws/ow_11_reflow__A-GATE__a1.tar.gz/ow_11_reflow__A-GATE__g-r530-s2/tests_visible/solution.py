import sys
import re

def get_width(char):
    if '\u4e00' <= char <= '\u9fff':
        return 2
    return 1

def reflow(text, width):
    if width <= 0:
        raise ValueError("Width must be positive")

    lines = text.splitlines(keepends=True)
    has_final_newline = text.endswith('\n')
    
    segments = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.startswith('```'):
            j = i + 1
            code_content = []
            while j < len(lines) and not lines[j].startswith('```'):
                code_content.append(lines[j])
                j += 1
            segments.append(('CODE', [lines[i]] + code_content + ([lines[j]] if j < len(lines) else [])))
            i = j + 1
        elif line.strip() == "":
            segments.append(('BLANK', [""]))
            i += 1
        else:
            current_para = []
            while i < len(lines):
                line = lines[i]
                if line.strip() == "": break
                stripped = line.lstrip()
                is_bullet = False
                marker_part = ""
                if stripped.startswith('- ') or stripped.startswith('* '):
                    is_bullet = True
                    marker_part = stripped[:2]
                elif re.match(r'^\d+\.\s', stripped):
                    is_bullet = True
                    match = re.match(r'^(\s*)([\-\*\d]+\.\s+)', line)
                    if match:
                        marker_part = match.group(2)
                
                if is_bullet and current_para:
                    segments.append(('PARA', current_para))
                    current_para = []
                
                current_para.append(line)
                i += 1
            if current_para:
                segments.append(('PARA', current_para))

    final_output = []
    for type, content in segments:
        if type == 'CODE':
            for line in content:
                final_output.append(line.rstrip('\r\n'))
        elif type == 'BLANK':
            final_output.append("")
        elif type == 'PARA':
            first_line = content[0]
            stripped = first_line.lstrip()
            indent_str = first_line[:len(first_line) - len(stripped)]
            indent_width = sum(get_width(c) for c in indent_str)
            
            is_bullet = False
            marker_part = ""
            if stripped.startswith('- ') or stripped.startswith('* '):
                is_bullet = True
                marker_part = stripped[:2]
            elif re.match(r'^\d+\.\s', stripped):
                is_bullet = True
                match = re.match(r'^(\s*)([\-\*\d]+\.\s+)', first_line)
                if match:
                    marker_part = match.group(2)

            words = []
            for idx, line in enumerate(content):
                if idx == 0:
                    base_line = line[len(indent_str):]
                else:
                    prefix = indent_str + marker_part if is_bullet else indent_str
                    base_line = line[len(prefix):] if len(line) >= len(prefix) else ""
                
                parts = re.split(r'[ \t]+', base_line)
                for p in parts:
                    if p: words.append(p)

            current_word_idx = 0
            num_words = len(words)
            while current_word_idx < num_words:
                # First line of a paragraph keeps its indentation (indent_width).
                # Continuation lines repeat it, or are indented to marker if bullet.
                # This means the first reflowed line has prefix width indent_width.
                # Subsequent reflowed lines have prefix width (indent_width + marker_width) if bullet else indent_width.

                pass # I'll just write the whole thing now.

    return ""
