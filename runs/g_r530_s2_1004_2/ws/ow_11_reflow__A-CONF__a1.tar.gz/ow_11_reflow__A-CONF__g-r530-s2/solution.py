import unicodedata
import re

def get_width(text):
    return sum(2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1 for ch in text)

class Reflow:
    def __init__(self, width):
        if width <= 0:
            raise ValueError("Width must be positive")
        self.width = width

    def reflow(self, text):
        lines = text.splitlines(keepends=True)
        output = []
        i = 0
        while i < len(lines):
            line = lines[i]
            if line.isspace():
                output.append("")
                i += 1
                continue

            paragraph_lines = []
            j = i
            while j < len(lines):
                curr_line = lines[j]
                if curr_line.isspace():
                    break
                
                stripped = curr_line.lstrip()
                is_bullet = False
                marker = ""
                if stripped.startswith("- "):
                    is_bullet = True
                    marker = "- "
                elif stripped.startswith("* "):
                    is_bullet = True
                    marker = "* "
                else:
                    match = re.match(r'^(\d+)\.\s', stripped)
                    if match:
                        is_bullet = True
                        marker = match.group(0)
                
                if is_bullet and paragraph_lines:
                    break
                paragraph_lines.append(curr_line)
                j += 1
            
            self._process_paragraph(paragraph_lines, output)
            i = j

        final_str = "\n".join(output)
        if text.endswith("\n") and not final_str.endswith("\n"):
            return final_str + "\n"
        return final_str

    def _process_paragraph(self, lines, output):
        first_line_stripped = lines[0].lstrip()
        is_bullet_para = False
        marker = ""
        if first_line_stripped.startswith("- "):
            is_bullet_para = True
            marker = "- "
        elif first_line_stripped.startswith("* "):
            is_bullet_para = True
            marker = "* "
        else:
            match = re.match(r'^(\d+)\.\s', first_line_stripped)
            if match:
                is_bullet_para = True
                marker = match.group(0)

        first_line_indent = lines[0][:len(lines[0]) - len(lines[0].lstrip())]
        continuation_indent = first_line_indent
        if is_bullet_para:
            marker_start = lines[0].find(marker)
            continuation_indent = lines[0][:marker_start] if marker_start != -1 else first_line_indent

        segments = []
        idx = 0
        while idx < len(lines):
            line = lines[idx]
            if line.startswith("```"):
                block = []
                in_c = True
                while idx < len(lines) and in_c:
                    block.append(lines[idx])
                    if lines[idx].startswith("```"):
                        in_c = False
                    idx += 1
                segments.append(('code', "".join(block)))
            else:
                curr_text_lines = []
                while idx < len(lines) and not lines[idx].isspace() and not lines[idx].startswith("```"):
                    curr_text_lines.append(lines[idx])
                    idx += 1
                segments.append(('text', "".join(curr_text_lines)))

        current_line = ""
        for i, (type, content) in enumerate(segments):
            if type == 'code':
                if current_line:
                    output.append(current_line.rstrip())
                    current_line = ""
                # Code blocks are emitted as they are, but we need to handle their newlines.
                code_lines = content.splitlines(keepends=True)
                for cl in code_lines:
                    output.append(cl.rstrip() if not cl.endswith('\n') else cl)
            else:
                words = []
                if i == 0:
                    prefix_len = len(first_line_indent)
                    if is_bullet_para:
                        marker_start = lines[0].find(marker)
                        prefix_len = marker_start if marker_start != -1 else prefix_len
                    content_after_prefix = content[prefix_len:]
                    words = content_after_prefix.split()
                else:
                    # For continuation lines, we need to handle the indentation separately from the words.
                    # The words are just sequences of non-whitespace characters.
                    # But wait, "Within a paragraph, runs of spaces and tabs separate words and are replaced by a single space."
                    words = content.split()

                to_process = []
                for w in words:
                    can_break = False
                    for k in range(1, len(w)):
                        if unicodedata.east_asian_width(w[k-1]) in ("W", "F") or \
                           unicodedata.east_asian_width(w[k]) in ("W", "F"):
                            can_break = True
                            break
                    if can_break:
                        to_process.append(w)
                    else:
                        to_process.append(('unbreakable', w))

                for item in to_process:
                    if isinstance(item, tuple): # Unbreakable word
                        word = item[1]
                        if not current_line:
                            current_line = ""
                        else:
                            current_line += " "
                        
                        # If it's the first word of a continuation line, we need to add the indentation.
                        if i > 0 and not current_line:
                            current_line += continuation_indent

                        word_width = get_width(word)
                        curr_w = get_width(current_line)
                        
                        if curr_w + word_width <= self.width:
                            current_line += word
                        else:
                            output.append(current_line.rstrip())
                            current_line = continuation_indent if i > 0 else ""
                            current_line += word
                    else: # Breakable word
                        word = item
                        while True:
                            if not current_line:
                                current_line = ""
                            else:
                                current_line += " "
                            
                            if i > 0 and not current_line:
                                current_line += continuation_indent

                            word_width = get_width(word)
                            curr_w = get_width(current_line)
                            
                            if curr_w + word_width <= self.width:
                                current_line += word
                                break
                            else:
                                best_k = 1
                                for k in range(1, len(word)):
                                    if unicodedata.east_asian_width(word[k-1]) in ("W", "F") or \
                                       unicodedata.east_asian_width(word[k]) in ("W", "F"):
                                        if get_width(current_line) + get_width(word[:k]) <= self.width:
                                            best_k = k
                                
                                if best_k == 1 and not (unicodedata.east_asian_width(word[0]) in ("W", "F") or \
                                                   unicodedata.east_asian_width(word[1]) in ("W", "F")):
                                    output.append(current_line.rstrip())
                                    current_line = continuation_indent if i > 0 else ""
                                    current_line += word
                                    break
                                else:
                                    output.append(current_line.rstrip())
                                    current_line = continuation_indent if i > 0 else ""
                                    word = word[best_k:]

        if current_line:
            output.append(current_line.rstrip())

def reflow(text, width):
    return Reflow(width).reflow(text)

