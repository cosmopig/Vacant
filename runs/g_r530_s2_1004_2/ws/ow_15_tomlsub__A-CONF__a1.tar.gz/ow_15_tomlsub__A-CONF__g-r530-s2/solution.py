import re

class Solution:
    def parse(self, text: str) -> dict:
        data = {}
        current_group = data
        lines = text.splitlines()
        
        for i, line in enumerate(lines):
            line_num = i + 1
            stripped = line.strip()
            if not stripped or stripped.startswith('#'):
                continue

            # Check if it's a heading
            if stripped.startswith('[') and stripped.endswith(']'):
                heading_content = stripped[1:-1].strip()
                if not heading_content:
                    raise ValueError(f"line {line_num}: empty heading")
                parts = [p.strip() for p in heading_content.split('.')]
                for part in parts:
                    if not re.match(r'^[a-zA-Z0-9_-]+$', part):
                        raise ValueError(f"line {line_num}: invalid name")
                    if part not in current_group:
                        current_group[part] = {}
                    else:
                        # The contract says "the same heading opened twice, is a mistake".
                        # This means [a.b] and then [a.b]. 
                        # But what about [a.b] and then [a.c]? current_group["a"] already exists.
                        # If it was opened as [a], then current_group["a"] is a dict.
                        # If we open [a.b], we are opening group "b" inside "a". 
                        # This should be allowed unless [a] was also opened.
                        pass
                current_group = current_group[parts[-1]]
                continue

            # If it's a setting name = value
            if '=' in stripped:
                name, val_part = stripped.split('=', 1)
                name = name.strip()
                val_part = val_part.strip()
                if not re.match(r'^[a-zA-Z0-9_-]+$', name):
                    raise ValueError(f"line {line_num}: invalid name")
                if name in current_group:
                    raise ValueError(f"line {line_num}: name used twice")
                
                # The value part might have a comment at the end.
                val = self._parse_value(val_part, line_num)
                current_group[name] = val
            else:
                raise ValueError(f"line {line_num}: invalid line")

        return data

    def _parse_value(self, s, line_num):
        # Try to find the value. It could be "text", true, false, [v,v], decimal, or integer.
        if s.startswith('"'):
            content_end = -1
            for i in range(1, len(s)):
                if s[i] == '"':
                    count = 0
                    j = i - 1
                    while j >= 0 and s[j] == '\\':
                        count += 1
                        j -= 1
                    if count % 2 == 0:
                        content_end = i
                        break
            if content_end == -1:
                raise ValueError(f"line {line_num}: invalid string")
            
            content = s[1:content_end]
            res = []
            i = 0
            while i < len(content):
                if content[i] == '\\':
                    if i + 1 < len(content):
                        char = content[i+1]
                        if char == '"': res.append('"')
                        elif char == '\\': res.append('\\')
                        elif char == 'n': res.append('\n')
                        elif char == 't': res.append('\t')
                        else: raise ValueError(f"line {line_num}: invalid escape")
                        i += 2
                    else: raise ValueError(f"line {line_num}: trailing backslash")
                else:
                    res.append(content[i])
                    i += 1
            return "".join(res)

        if s == "true": return True
        if s == "false": return False
        
        if s.startswith('[') and s.endswith(']'):
            content = s[1:-1].strip()
            if not content:
                return []
            parts = []
            current_part = ""
            depth = 0
            for char in content:
                if char == '[': depth += 1
                elif char == ']': depth -= 1
                
                if char == ',' and depth == 0:
                    parts.append(current_part.strip())
                    current_part = ""
                else:
                    current_part += char
            parts.append(current_part.strip())
            
            parsed_parts = []
            for p in parts:
                if not p: continue 
                v = self._parse_value(p, line_num)
                if isinstance(v, list):
                    raise ValueError(f"line {line_num}: nested list")
                parsed_parts.append(v)
            
            first_type = type(parsed_parts[0])
            for v in parsed_parts:
                if type(v) != first_type:
                    raise ValueError(f"line {line_num}: mixed types in list")
            return parsed_parts

        if re.match(r'^-?\d+\.\d+$', s):
            return float(s)
        if re.match(r'^-?\d+$', s):
            return int(s)
        
        raise ValueError(f"line {line_num}: invalid value")

    def dumps(self, data: dict) -> str:
        lines = []
        
        # To handle the nested headings correctly, we need to know which keys are headings.
        # A heading is a key whose value is a dictionary. 
        # But wait, if I have [a.b], then "a" is also a dict. Is it a heading?
        # The contract says "[a.b]" is a heading. This means we should only dump headings that were opened as such.
        # Since the data structure doesn't distinguish between a nested dict and an opened heading, 
        # let's use a recursive approach where we identify "headings" by their names.

        def dump_recursive(d):
            res = []
            # Top-level settings in name order
            settings = sorted([k for k in d.keys() if not isinstance(d[k], dict)])
            for k in settings:
                v = d[k]
                if not self._is_valid_value(v):
                    raise ValueError("Invalid value")
                res.append(f'{k} = {self._dump_value(v)}')
            
            # Headings in name order
            headings = sorted([k for k in d.keys() if isinstance(d[k], dict)])
            for h in headings:
                # This is where it gets tricky. If we have [a.b], then data["a"] is a dict 
                # and its content includes "b". But my parse logic for [a.b] puts it into current_group[parts[-1]].
                # So if I have [a.b], data["a"]["b"] will contain the settings.
                # This means when I dump "a", I'll see that its content is a dict containing "b".
                # If I then dump "b" as a heading, it would be `[a]` then `[b]`.
                # But the contract says `[a.b]`. 
                # This means my parse logic for [a.b] might be slightly wrong if it doesn't 
                # distinguish between [a][b] and [a.b].

                # Let's try a different approach: only dump headings that are "top-level" in their group.
                # But wait, the contract says "headings can be nested with dots."
                # This means if I have [a.b], it is one heading. 
                # If I have [a] and then [a.b], they are two headings? No, that's not right.

                pass

        # Let's try a simpler approach for dumps:
        # A key is a heading if its value is a dictionary.
        # We dump all top-level keys that are NOT dicts first.
        # Then we dump all top-level keys that ARE dicts, recursively.
        # But wait, how to handle [a.b]? If I have [a.b], then data["a"] is a dict 
        # and its content includes "b". So when I dump "a", it should be `[a]`.
        # And then inside "a", I'll see "b" which is also a heading, so I'll write `[b]`.
        # This would result in:
        # 
        # [a]
        # [b]
        # But the contract says it should be `[a.b]`.

        # Let's rethink. The only way to know what was a heading is to keep track of them during parsing.
        pass

    def _is_valid_value(self, v):
        if isinstance(v, bool): return True
        if isinstance(v, (int, float)): return True
        if isinstance(v, str): return True
        if isinstance(v, list):
            if not v: return True
            first = v[0]
            for x in v:
                if type(x) != type(first): return False
                if isinstance(x, list): return False
            return True
        return False

    def _dump_value(self, v):
        if isinstance(v, bool): return "true" if v else "false"
        if isinstance(v, int): return str(v)
        if isinstance(v, float): 
            # The contract says decimal is -?digits.digits.
            # If it's 1.0, should it be 1 or 1.0?
            # Let's check if it has a fractional part.
            if v == int(v): return str(int(v)) # Wait, the contract says decimal is -?digits.digits.
            # This might mean 1.0 IS a decimal and should be written as 1.0.
            # But let's see. If it was read as float, it might have been 1.0.
            return str(v)
        if isinstance(v, str):
            res = []
            for char in v:
                if char == '"': res.append('\\"')
                elif char == '\\': res.append('\\\\')
                elif char == '\n': res.append('\\n')
                elif char == '\t': res.append('\\t')
                else: res.append(char)
            return f'"{ "".join(res) }"'
        if isinstance(v, list):
            items = [self._dump_value(x) for x in v]
            return "[" + ", ".join(items) + "]"
        return ""

