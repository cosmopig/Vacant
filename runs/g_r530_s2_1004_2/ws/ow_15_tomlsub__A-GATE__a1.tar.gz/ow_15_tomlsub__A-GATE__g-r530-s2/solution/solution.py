import re

def parse(text: str) -> dict:
    data = {}
    current_group = data
    opened_headings = set()
    
    lines = text.splitlines()
    for i, line in enumerate(lines):
        line_num = i + 1
        content = line.strip()
        if not content or content.startswith("#"):
            continue

        # Check for heading [a.b]
        if content.startswith("[") and content.endswith("]"):
            heading_str = content[1:-1].strip()
            if not heading_str:
                raise ValueError(f"line {line_num}: empty heading")
            
            parts = heading_str.split(".")
            for part in parts:
                if not re.fullmatch(r"[a-zA-Z0-9_-]+", part):
                    raise ValueError(f"line {line_num}: invalid name")

            if heading_str in opened_headings:
                raise ValueError(f"line {line_num}: heading already opened")
            opened_headings.add(heading_str)

            new_group = data
            for part in parts:
                if part not in new_group:
                    new_group[part] = {}
                if not isinstance(new_group[part], dict):
                    raise ValueError(f"line {line_num}: name conflict")
                new_group = new_group[part]
            current_group = new_group
            continue

        # Check for key = value
        if "=" in content:
            key_part, val_part = content.split("=", 1)
            key = key_part.strip()
            val_raw = val_part.strip()
            
            if not re.fullmatch(r"[a-zA-Z0-9_-]+", key):
                raise ValueError(f"line {line_num}: invalid name")
            
            if key in current_group:
                raise ValueError(f"line {line_num}: duplicate key")

            # Value parsing
            value = _parse_value(val_raw, line_num)
            current_group[key] = value
        else:
            raise ValueError(f"line {line_num}: invalid line")

    return data

def _parse_value(val_raw, line_num):
    if val_raw.startswith('"') and val_raw.endswith('"'):
        inner = val_raw[1:-1]
        res = ""
        i = 0
        while i < len(inner):
            if inner[i] == "\\":
                if i + 1 < len(inner):
                    char = inner[i+1]
                    if char == '"': res += '"'
                    elif char == "\\": res += "\\"
                    elif char == "n": res += "\n"
                    elif char == "t": res += "\t"
                    else: raise ValueError(f"line {line_num}: invalid escape")
                    i += 2
                else: raise ValueError(f"line {line_num}: trailing backslash")
            else:
                res += inner[i]
                i += 1
        return res

    if val_raw == "true": return True
    if val_raw == "false": return False
    
    if val_raw.startswith("[") and val_raw.endswith("]"):
        inner = val_raw[1:-1].strip()
        if not inner:
            return []
        parts = []
        current_part = ""
        in_quotes = False
        i = 0
        while i < len(inner):
            char = inner[i]
            if char == '"':
                if i > 0 and inner[i-1] == "\\":
                    current_part += char
                else:
                    in_quotes = not in_quotes
                    current_part += char
            elif char == "," and not in_quotes:
                parts.append(current_part.strip())
                current_part = ""
            else:
                current_part += char
            i += 1
        if current_part or len(parts) == 0:
            pass
        
        if not parts and inner:
            parts = [current_part]
        elif len(parts) > 0 and (not current_part or current_part == ""):
            pass
        else:
            if current_part:
                parts.append(current_part)

        parsed_items = []
        for p in parts:
            if p == "": continue
            parsed_items.append(_parse_value(p, line_num))
        return parsed_items

    if re.fullmatch(r"-?\d+", val_raw):
        return int(val_raw)
    if re.fullmatch(r"-?\d+\.\d+", val_raw):
        return float(val_raw)

    raise ValueError(f"line {line_num}: invalid value")

def dumps(data: dict) -> str:
    lines = []
    # Top-level names first in name order (not headings)
    top_keys = sorted([k for k in data.keys() if not isinstance(data[k], dict)])
    for k in top_keys:
        lines.append(f'{k} = {_dumps_value(data[k])}')

    # Headings in name order
    heading_keys = sorted([k for k in data.keys() if isinstance(data[k], dict)])
    for k in heading_keys:
        lines.append("") # blank line before each heading
        lines.append(f"[{k}]")
        _dump_group(data[k], lines)

    return "\n".join(lines).strip()

def _dumps_value(value):
    if isinstance(value, bool):
        return "true" if value else "false"
    elif isinstance(value, int):
        return str(value)
    elif isinstance(value, float):
        s = str(value)
        if "." not in s:
            s += ".0"
        return s
    elif isinstance(value, list):
        if not value:
            return "[]"
        first_type = type(value[0])
        items = []
        for v in value:
            if type(v) != first_type:
                raise ValueError("mixed list types")
            if isinstance(v, (list, dict)):
                raise ValueError("nested lists/dicts not allowed")
            
            if isinstance(v, bool):
                items.append("true" if v else "false")
            elif isinstance(v, int):
                items.append(str(v))
            elif isinstance(v, float):
                s = str(v)
                if "." not in s: s += ".0"
                items.append(s)
            else: # string
                res = v.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n').replace('\t', '\\t')
                items.append(f'"{res}"')
        return "[" + ", ".join(items) + "]"
    elif isinstance(value, str):
        res = value.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n').replace('\t', '\\t')
        return f'"{res}"'
    else:
        raise ValueError("unsupported type")

def _dump_group(group: dict, lines: list):
    # Sort keys of this group (excluding sub-groups which are headings)
    keys = sorted([k for k in group.keys() if not isinstance(group[k], dict)])
    for k in keys:
        lines.append(f'{k} = {_dumps_value(group[k])}')
    
    # Then sub-groups (headings)
    sub_headings = sorted([k for k in group.keys() if isinstance(group[k], dict)])
    for k in sub_headings:
        lines.append("") # blank line before each heading
        # This is tricky because the data structure doesn't store full names.
        # But we know it was [a.b] and now we are inside 'a'. 
        # We need to reconstruct "a.b".
        pass

    # Re-evaluating: "headings can be nested with dots" and "data["a"]["b"]".
    # This means if I have [a.b], then a is a dict, and b is a key in that dict? 
    # No, the contract says "the names after [a.b] live in data["a"]["b"]".
    # So data["a"] = {"b": { ... }}. This means "b" is a heading too?
    # Let's re-read: "headings can be nested with dots... headings can be nested with dots."
    # If the file has [a.b], then data["a"]["b"] exists. 
    # If it also has [a.b.c], then data["a"]["b"]["c"] exists.
    # This means "a" and "b" are headings, but they might also contain other keys.

    # Let's fix the structure: a heading [a.b] means that we go into data["a"], 
    # and then create/go into data["a"]["b"].
    # If data["a"] already exists (from another heading or key), it's fine.
    # But if "a" was a value, it's an error.

    # To dump correctly: we need to know which keys are headings and what their full names are.
    pass

