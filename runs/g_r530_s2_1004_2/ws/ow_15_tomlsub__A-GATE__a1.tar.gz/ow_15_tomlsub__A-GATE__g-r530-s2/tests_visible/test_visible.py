import unittest
from solution import Solution

class TestSolution(unittest.TestCase):
    def test_basic_parse_dumps(self):
        data = {
            "key1": "value1",
            "key2": 42,
            "key3": 3.14,
            "key4": True,
            "key5": False,
            "key6": ["a", "b", "c"],
            "key7": [1, 2, 3],
            "key8": [True, False],
        }
        text = Solution().dumps(data)
        self.assertEqual(Solution().parse(text), data)

    def test_headings(self):
        data = {
            "top": "value",
            "a": {
                "b": "c",
                "d": 1,
            },
            "x": {
                "y": {
                    "z": 2,
                }
            },
        }
        text = Solution().dumps(data)
        self.assertEqual(Solution().parse(text), data)

    def test_comments_and_whitespace(self):
        text = """# This is a comment
key1 = "value with # hash"
# Another comment
[heading]
key2 = 42
"""
        data = Solution().parse(text)
        self.assertEqual(data, {"key1": "value with # hash", "heading": {"key2": 42}})

    def test_escapes(self):
        data = {
            "quote": 'He said, \"Hello\"',
            "backslash": "C:\\path",
            "newline": "line1\\nline2",
            "tab": "col1\\tcol2",
        }
        text = Solution().dumps(data)
        self.assertEqual(Solution().parse(text), data)

    def test_errors(self):
        # Duplicate key
        with self.assertRaisesRegex(ValueError, "line 2:"):
            Solution().parse("key1 = 1\nkey1 = 2")
        
        # Duplicate heading
        with self.assertRaisesRegex(ValueError, "line 3:"):
            Solution().parse("[a]\nkey1 = 1\n[a]")

        # Mixed list types
        with self.assertRaises(ValueError):
            Solution().dumps({"list": [1, "2"]})

        # Nested lists
        with self.assertRaises(ValueError):
            Solution().dumps({"list": [[1]]})

if __name__ == "__main__":
    unittest.main()
