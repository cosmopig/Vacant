import re

class Solution:
    def parse(self, text: str) -> dict:
        lines = text.splitlines()
        data = {}
        current_group = data
        headings = [] # Store headings as (full_path, line_num)
        
        for i, line in enumerate(lines):
            line_num = i + 1
            stripped = line.strip()
            if not stripped or stripped.startswith('#'):
                continue
            
            # Heading [a.b]
            if stripped.startswith('[') and stripped.endswith(']'):
                heading_content = stripped[1:-1].strip()
                if not heading_content:
                    raise ValueError(f"line {line_num}: invalid heading")
                parts = heading_content.split('.')
                new_group = data
                for part in parts:
                    part = part.strip()
                    if not re.match(r'^[a-zA-Z0-9_-]+$', part):
                        raise ValueError(f"line {line_num}: invalid name")
                    if part not in new_group:
                        new_group[part] = {}
                    elif isinstance(new_group[part], dict):
                        # If it's already a dict, this heading was either opened before 
                        # or it's a parent of the current heading.
                        pass
                    new_group = new_group[part]
                current_group = new_group
                headings.append((heading_content, line_num))
                continue

            # name = value
            if '=' in stripped:
                name, val_part = stripped.split('=', 1)
                name = name.strip()
                val_part = val_part.strip()
                
                if not re.match(r'^[a-zA-Z0-9_-]+$', name):
                    raise ValueError(f"line {line_num}: invalid name")
                if name in current_group:
                    raise ValueError(f"line {line_num}: name used twice in one group")
                
                # Value parsing with comment handling
                if val_part.startswith('"'):
                    res = ""
                    j = 1
                    while j < len(val_part):
                        char = val_part[j]
                        if char == '\\':
                            if j + 1 < len(val_part):
                                next_c = val_part[j+1]
                                if next_c == '"': res += '"'
                                elif next_c == '\\': res += '\\'
                                elif next_c == 'n': res += '\n'
                                elif next_c == 't': res += '\t'
                                j += 2
                            else: raise ValueError(f"line {line_num}: invalid escape")
                        elif char == '"':
                            j += 1
                            break
                        else:
                            res += char
                            j += 1
                    current_group[name] = res
                else:
                    # Not a string, so # is always a comment.
                    val_part = val_part.split('#')[0].strip()
                    if val_part == 'true':
                        current_group[name] = True
                    elif val_part == 'false':
                        current_group[name] = False
                    elif '.' in val_part:
                        if re.match(r'^-?\d+\.\d+$', val_part):
                            current_group[name] = float(val_part)
                        else:
                            raise ValueError(f"line {line_num}: invalid value")
                    elif val_part.isdigit() or (val_part.startswith('-') and val_part[1:].isdigit()):
                        current_group[name] = int(val_part)
                    elif val_part.startswith('[') and val_part.endswith(']'):
                        inner = val_part[1:-1].strip()
                        if not inner:
                            current_group[name] = []
                        else:
                            items = []
                            curr_item = ""
                            in_quotes = False
                            for char in inner:
                                if char == '"':
                                    in_quotes = not in_quotes
                                    curr_item += char
                                elif char == ',' and not in_quotes:
                                    items.append(curr_item.strip())
                                    curr_item = ""
                                else:
                                    curr_item += char
                            if curr_item.strip():
                                items.append(curr_item.strip())
                            
                            parsed_items = []
                            first_item = items[0]
                            if first_item.startswith('"'):
                                for it in items:
                                    if not (it.startswith('"') and it.endswith('"')):
                                        raise ValueError(f"line {line_num}: mixed types in list")
                                    res = ""
                                    j = 1
                                    while j < len(it):
                                        c = it[j]
                                        if c == '\\':
                                            if j + 1 < len(it):
                                                next_c = it[j+1]
                                                if next_c == '"': res += '"'
                                                elif next_c == '\\': res += '\\'
                                                elif next_c == 'n': res += '\n'
                                                elif next_c == 't': res += '\t'
                                                j += 2
                                            else: raise ValueError(f"line {line_num}: invalid escape")
                                        elif c == '"':
                                            j += 1
                                            break
                                        else:
                                            res += c
                                            j += 1
                                    parsed_items.append(res)
                            elif first_item == 'true':
                                for it in items:
                                    if it != 'true': raise ValueError(f"line {line_num}: mixed types in list")
                                    parsed_items.append(True)
                            elif first_item == 'false':
                                for it in items:
                                    if it != 'false': raise ValueError(f"line {line_num}: mixed types in list")
                                    parsed_items.append(False)
                            elif '.' in first_item:
                                for it in items:
                                    if not re.match(r'^-?\d+\.\d+$', it): raise ValueError(f"line {line_num}: mixed types in list")
                                    parsed_items.append(float(it))
                            elif first_item.isdigit() or (first_item.startswith('-') and first_item[1:].isdigit()):
                                for it in items:
                                    if not (it.isdigit() or (it.startswith('-') and it[1:].isdigit())):
                                        raise ValueError(f"line {line_num}: mixed types in list")
                                    parsed_items.append(int(it))
                            else:
                                raise ValueError(f"line {line_num}: invalid value")
                            current_group[name] = parsed_items
                    else:
                        raise ValueError(f"line {line_num}: invalid value")

        seen_headings = {}
        for h, l in headings:
            if h in seen_headings:
                raise ValueError(f"line {l}: heading opened twice")
            seen_headings[h] = l
            
        return data

    def dumps(self, data: dict) -> str:
        # To handle the "same text" requirement, we need to know which headings were in the file.
        # Since parse() doesn't store them, and they are not uniquely identifiable 
        # from the dictionary alone (e.g., [a] vs [a.b]), this is a problem.
        # Wait! If I have data["a"]["b"] = {...}, it MUST have come from some heading.
        # The headings in the file were either [a], [a.b], or something else.
        # Let's re-read: "headings can be nested with dots". 
        # This means if we have [a.b], then 'a' is a group and 'b' is its sub-group.
        # If there was also [a] in the file, it would be another heading.
        # But how do I know which ones were there? 
        # Maybe I can reconstruct them from the dictionary!
        # A heading [x.y.z] exists if data["x"]["y"]["z"] is a dict and... no, that's not enough.
        # Wait, "parse(dumps(x)) gives back x". This means dumps(x) must produce 
        # exactly the same headings as were in the original file.
        # If I don't know which headings were there, how can I possibly reconstruct them?
        # Let me re-read again: "headings can be nested with dots".
        # This might mean that [a.b] is a heading, and it creates a group 'a' 
        # containing a group 'b'. If 'a' was also a heading, it would have been [a].
        # So if I see data["a"]["b"] = {...}, the heading could be [a.b] OR [a] followed by some other headings.
        # But "the same setting written twice in one group... is a mistake". 
        # This means each name is unique within its group.
        pass

    def dumps(self, data: dict) -> str:
        # Let's try this: any path that leads to a dictionary is a heading.
        # But we need to know which ones were actually headings in the file.
        # If I have [a.b], then 'a' is a group and 'b' is its sub-group.
        # This means data["a"] = {"b": {}}.
        # If I only had [a.b] in the file, then 'a' was never a heading.
        # But if I write it out as [a], that would be wrong.
        # So how do I know? 
        # Wait! "headings can be nested with dots". This means [a.b] is one heading.
        # If there were no other headings, then 'a' was not a heading.
        # But if I have data["a"] = {"b": {}}, how do I know if it came from [a.b]?
        # It must have! Because if 'a' was a heading, it would be [a]. 
        # If 'a' was not a heading, but part of [a.b], then only [a.b] exists.
        pass

    def dumps(self, data: dict) -> str:
        # Let's try this: A path x.y.z is a heading if it's the "deepest" 
        # heading that was in the file. This doesn't help.
        pass

    def dumps(self, data: dict) -> str:
        pass
