import re

def _parse_segment(p_seg):
    matchers = []
    i = 0
    while i < len(p_seg):
        if p_seg[i] == '*':
            matchers.append(('*',))
            i += 1
        elif p_seg[i] == '?':
            matchers.append(('?',))
            i += 1
        elif p_seg[i] == '[':
            j = i + 1
            while j < len(p_seg) and p_seg[j] != ']':
                j += 1
            if j == len(p_seg):
                raise ValueError("Unclosed [")
            content = p_seg[i+1:j]
            if not content:
                raise ValueError("Empty class")
            negate = False
            if content.startswith('!'):
                negate = True
                content = content[1:]
            matchers.append(('class', content, negate))
            i = j + 1
        else:
            matchers.append(('char', p_seg[i]))
            i += 1
    return matchers

def matches(pattern: str, path: str) -> bool:
    p_segs = pattern.split('/')
    s_segs = path.split('/')
    
    parsed_p_segs = []
    for ps in p_segs:
        if ps == "**":
            parsed_p_segs.append("**")
        else:
            parsed_p_segs.append(_parse_segment(ps))

    def match_s_seg(matchers, s_seg):
        memo = {}
        def backtrack(m_idx, s_idx):
            if (m_idx, s_idx) in memo: return memo[(m_idx, s_idx)]
            if m_idx == len(matchers):
                return s_idx == len(s_seg)
            
            m = matchers[m_idx]
            res = False
            if m[0] == 'char':
                if s_idx < len(s_seg) and s_seg[s_idx] == m[1]:
                    res = backtrack(m_idx + 1, s_idx + 1)
            elif m[0] == '?':
                if s_idx < len(s_seg):
                    res = backtrack(m_idx + 1, s_idx + 1)
            elif m[0] == '*':
                for skip in range(len(s_seg) - s_idx + 1):
                    if backtrack(m_idx + 1, s_idx + skip):
                        res = True
                        break
            elif m[0] == 'class':
                content, negate = m[1], m[2]
                if s_idx < len(s_seg):
                    char = s_seg[s_idx]
                    in_set = False
                    k = 0
                    while k < len(content):
                        if content[k] == '-':
                            # Range: character before '-' to character after '-'
                            if k > 0 and k + 1 < len(content):
                                start_char = content[k-1]
                                end_char = content[k+1]
                                if ord(start_char) <= ord(char) <= ord(end_char):
                                    in_set = True
                                    break
                            k += 2
                        else:
                            if char == content[k]:
                                in_set = True
                                break
                            k += 1
                    res = not in_set if negate else in_set
                else:
                    res = False
            memo[(m_idx, s_idx)] = res
            return res

        return backtrack(0, 0)

    def solve_recursive(p_idx, s_idx):
        if p_idx == len(parsed_p_segs):
            return s_idx == len(s_segs)
        
        p_seg = parsed_p_segs[p_idx]
        
        if p_seg == "**":
            for skip in range(len(s_segs) - s_idx + 1):
                if solve_recursive(p_idx + 1, s_idx + skip):
                    return True
            return False
        else:
            if s_idx < len(s_segs):
                if match_s_seg(p_seg, s_segs[s_idx]):
                    return solve_recursive(p_idx + 1, s_idx + 1)
            return False

    return solve_recursive(0, 0)

def select(patterns: list[str], paths: list[str]) -> list[str]:
    selected = set()
    for pattern in patterns:
        is_negate = pattern.startswith('!')
        actual_pattern = pattern[1:] if is_negate else pattern
        
        matches_now = []
        for path in paths:
            if matches(actual_pattern, path):
                matches_now.append(path)
        
        if is_negate:
            to_remove = set()
            for path in matches_now:
                if path in selected:
                    to_remove.add(path)
            selected -= to_remove
        else:
            for path in matches_now:
                selected.add(path)
    
    result = []
    seen = set()
    for path in paths:
        if path in selected and path not in seen:
            result.append(path)
            seen.add(path)
    return result

# The contract says "solution.matches" and "solution.select". 
# So I should put them inside a class or just make sure they are accessible.
class Solution:
    def matches(self, pattern: str, path: str) -> bool:
        return matches(pattern, path)

    def select(self, patterns: list[str], paths: list[str]) -> list[str]:
        return select(patterns, paths)

solution = Solution()
