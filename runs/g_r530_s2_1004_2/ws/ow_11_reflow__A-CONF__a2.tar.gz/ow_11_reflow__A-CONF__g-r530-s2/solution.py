import unicodedata
import re

def get_width(text):
    return sum(2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1 for ch in text)

class Reflower:
    def __init__(self, width):
        if width <= 0:
            raise ValueError("Width must be positive.")
        self.width = width

    def reflow(self, text):
        lines = text.splitlines(keepends=True)
        has_trailing_newline = text.endswith('\n')
        
        blocks = []
        i = 0
        while i < len(lines):
            line = lines[i]
            if line.strip().startswith("```"):
                fence_block = []
                # A fence block ends when we find another line starting with ```
                # that is not immediately followed by another line starting with ```.
                while i < len(lines):
                    fence_block.append(lines[i])
                    i += 1
                    if i < len(lines) and lines[i].strip().startswith("```"):
                        if i + 1 >= len(lines) or not lines[i+1].strip().startswith("```"):
                            break
                blocks.append(('code', fence_block))
            else:
                content_block = []
                while i < len(lines) and not lines[i].strip().startswith("```"):
                    content_block.append(lines[i])
                    i += 1
                blocks.append(('text', content_block))

        output = []
        for btype, content in blocks:
            if btype == 'code':
                output.extend(content)
            else:
                paragraphs = []
                current_para = []
                
                for line in content:
                    stripped = line.strip()
                    if not stripped:
                        if current_para:
                            paragraphs.append(current_para)
                            current_para = []
                        else:
                            output.append("")
                        continue
                    
                    is_bullet = False
                    marker = ""
                    if stripped.startswith("- "):
                        is_bullet = True
                        marker = "- "
                    elif stripped.startswith("* "):
                        is_bullet = True
                        marker = "* "
                    else:
                        match = re.match(r'^(\d+)\. ', stripped)
                        if match:
                            is_bullet = True
                            marker = match.group(0)
                    
                    if is_bullet and current_para:
                        paragraphs.append(current_para)
                        current_para = []
                    
                    current_para.append(line)
                if current_para:
                    paragraphs.append(current_para)

                for para in paragraphs:
                    self._process_paragraph(para, output)

        res = "".join(output)
        if has_trailing_newline and not res.endswith('\n'):
            res += '\n'
        return res

    def _process_paragraph(self, lines, output):
        first_line = lines[0]
        stripped_first = first_line.lstrip()
        indent_str = first_line[:len(first_line) - len(stripped_first)]
        
        is_bullet_para = False
        marker = ""
        if stripped_first.startswith("- "):
            is_bullet_para = True
            marker = "- "
        elif stripped_first.startswith("* "):
            is_bullet_para = True
            marker = "* "
        else:
            match = re.match(r'^(\d+)\. ', stripped_first)
            if match:
                is_bullet_para = True
                marker = match.group(0)

        content_words = []
        for i, line in enumerate(lines):
            stripped = line.lstrip()
            if not stripped: continue
            
            start_idx = 0
            if is_bullet_para and i > 0:
                start_idx = len(marker)
            elif i == 0:
                if is_bullet_para:
                    start_idx = len(marker)
                else:
                    first_non_space = len(line) - len(line.lstrip())
                    start_idx = first_non_space
            else:
                start_idx = len(indent_str)
            
            content_part = line[start_idx:]
            words_in_line = content_part.split()
            for w in words_in_line:
                content_words.append(w)

        if not content_words:
            output.append(lines[0])
            return

        current_word_idx = 0
        para_line_count = 0
        while current_word_idx < len(content_words):
            if is_bullet_para and para_line_count > 0:
                indent = " " * len(marker)
            elif is_bullet_para and para_line_count == 0:
                indent = marker
            else:
                indent = indent_str

            indent_w = get_width(indent)
            remaining_w = self.width - indent_w
            
            if remaining_w < 0: # Should not happen for valid width
                output.append(indent + content_words[current_word_idx])
                current_word_idx += 1
                para_line_count += 1
                continue

            line_content = []
            current_w = 0
            while current_word_idx < len(content_words):
                w = content_words[current_word_idx]
                w_w = get_width(w)
                
                if not line_content:
                    line_content.append(w)
                    current_w = w_w
                    break
                else:
                    space_w = 1
                    if current_w + space_w + w_w <= remaining_w:
                        line_content.append(w)
                        current_w += space_w + w_w
                    else:
                        break
                current_word_idx += 1

            # If the first word was too long, it stays on its own line and we don't increment current_word_idx
            if len(line_content) == 1 and get_width(line_content[0]) > remaining_w:
                output.append(indent + line_content[0])
            else:
                output.append(indent + " ".join(line_content))
            
            para_line_count += 1

def reflow(text, width):
    return Reflower(width).reflow(text)
