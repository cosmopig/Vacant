import re

def redact(text):
    # Patterns for secrets
    # 1. AWS Keys (AKIA...) - "keys with other text in them"
    aws_pattern = r'AKIA[A-Z0-9]{16,}'
    
    # 2. Bearer Tokens: eyJ... or long base64url strings
    # "tokens that are not made of dot-separated parts"
    token_pattern = r'\b[A-Za-z0-9\-_]{32,}\b'

    # 3. Connection Strings (postgres, mysql, mongodb, redis, amqp)
    conn_pattern = r'(postgres|mysql|mongodb|redis|amqp)://[^ \n\r\t]+'

    matches = []
    for m in re.finditer(aws_pattern, text):
        matches.append((m.start(), m.end(), m.group()))
    for m in re.finditer(token_pattern, text):
        matches.append((m.start(), m.end(), m.group()))
    for m in re.finditer(conn_pattern, text):
        matches.append((m.start(), m.end(), m.group()))

    # Sort matches by start position
    matches.sort()

    # Filter out overlapping matches (keep the longest one)
    filtered_matches = []
    if matches:
        last_end = -1
        for start, end, val in matches:
            if start >= last_end:
                filtered_matches.append((start, end, val))
                last_end = end
            else:
                # If overlapping, keep the longer one
                curr_match = (start, end, val)
                prev_match = filtered_matches[-1]
                if (end - start) > (prev_match[1] - prev_match[0]):
                    filtered_matches[-1] = curr_match

    # Now redact the text and collect findings
    redacted_text = list(text)
    findings_list = []
    for start, end, val in reversed(filtered_matches):
        findings_list.append(val)
        # Replace with [REDACTED]
        redacted_text[start:end] = list("[REDACTED]")

    return "".join(redacted_text)

def findings(text):
    aws_pattern = r'AKIA[A-Z0-9]{16,}'
    token_pattern = r'\b[A-Za-z0-9\-_]{32,}\b'
    conn_pattern = r'(postgres|mysql|mongodb|redis|amqp)://[^ \n\r\t]+'

    matches = []
    for m in re.finditer(aws_pattern, text):
        matches.append((m.start(), m.end(), m.group()))
    for m in re.finditer(token_pattern, text):
        matches.append((m.start(), m.end(), m.group()))
    for m in re.finditer(conn_pattern, text):
        matches.append((m.start(), m.end(), m.group()))

    matches.sort()
    filtered_matches = []
    if matches:
        last_end = -1
        for start, end, val in matches:
            if start >= last_end:
                filtered_matches.append((start, end, val))
                last_end = end
            else:
                curr_match = (start, end, val)
                prev_match = filtered_matches[-1]
                if (end - start) > (prev_match[1] - prev_match[0]):
                    filtered_matches[-1] = curr_match
    return [m[2] for m in filtered_matches]
