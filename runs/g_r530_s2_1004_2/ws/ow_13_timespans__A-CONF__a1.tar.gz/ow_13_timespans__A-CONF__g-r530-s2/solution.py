from datetime import datetime, timedelta

class Solution:
    def _parse_instant(self, instant_str: str) -> datetime:
        if len(instant_str) == 10 and instant_str[4] == '-' and instant_str[7] == '-':
            try:
                return datetime.strptime(instant_str, "%Y-%m-%d")
            except ValueError:
                raise ValueError(f"Invalid date format: {instant_str}")
        elif "T" in instant_str:
            try:
                return datetime.strptime(instant_str, "%Y-%m-%dT%H:%M:%S")
            except ValueError:
                raise ValueError(f"Invalid time format: {instant_str}")
        else:
            raise ValueError(f"Instant must be YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS. Got: {instant_str}")

    def _format_instant(self, dt: datetime) -> str:
        return dt.strftime("%Y-%m-%dT%H:%M:%S")

    def merge(self, spans: list[tuple[str, str]]) -> list[tuple[str, str]]:
        parsed_spans = []
        for start_str, end_str in spans:
            start = self._parse_instant(start_str)
            end = self._parse_instant(end_str)
            if end < start:
                raise ValueError(f"End {end_str} is before start {start_str}")
            if start == end:
                continue
            parsed_spans.append((start, end))

        if not parsed_spans:
            return []

        parsed_spans.sort()

        merged = []
        curr_start, curr_end = parsed_spans[0]

        for i in range(1, len(parsed_spans)):
            next_start, next_end = parsed_spans[i]
            if next_start <= curr_end:
                curr_end = max(curr_end, next_end)
            else:
                merged.append((curr_start, curr_end))
                curr_start, curr_end = next_start, next_end
        
        merged.append((curr_start, curr_end))

        return [(self._format_instant(s), self._format_instant(e)) for s, e in merged]

    def subtract(self, spans: list[tuple[str, str]], holes: list[tuple[str, str]]) -> list[tuple[str, str]]:
        merged_spans = self.merge(spans)
        parsed_spans = []
        for s, e in merged_spans:
            parsed_spans.append((self._parse_instant(s), self._parse_instant(e)))

        parsed_holes = []
        for h_start_str, h_end_str in holes:
            h_start = self._parse_instant(h_start_str)
            h_end = self._parse_instant(h_end_str)
            if h_end < h_start:
                raise ValueError(f"End {h_end_str} is before start {h_start_str}")
            parsed_holes.append((h_start, h_end))
        
        if not parsed_holes:
            return merged_spans

        parsed_holes.sort()
        merged_holes = []
        curr_h_start, curr_h_end = parsed_holes[0]
        for i in range(1, len(parsed_holes)):
            next_h_start, next_h_end = parsed_holes[i]
            if next_h_start <= curr_h_end:
                curr_h_end = max(curr_h_end, next_h_end)
            else:
                merged_holes.append((curr_h_start, curr_h_end))
                curr_h_start, curr_h_end = next_h_start, next_h_end
        merged_holes.append((curr_h_start, curr_h_end))

        result_spans = []
        for s_start, s_end in parsed_spans:
            current_segments = [(s_start, s_end)]
            for h_start, h_end in merged_holes:
                new_segments = []
                for seg_start, seg_end in current_segments:
                    if h_end <= seg_start or h_start >= seg_end:
                        new_segments.append((seg_start, seg_end))
                    else:
                        if h_start > seg_start:
                            new_segments.append((seg_start, h_start))
                        if h_end < seg_end:
                            new_segments.append((h_end, seg_end))
                current_segments = new_segments
            result_spans.extend(current_segments)

        if not result_spans:
            return []
        
        result_spans.sort()
        final_merged = []
        curr_start, curr_end = result_spans[0]
        for i in range(1, len(result_spans)):
            next_start, next_end = result_spans[i]
            if next_start <= curr_end:
                curr_end = max(curr_end, next_end)
            else:
                final_merged.append((curr_start, curr_end))
                curr_start, curr_end = next_start, next_end
        final_merged.append((curr_start, curr_end))

        return [(self._format_instant(s), self._format_instant(e)) for s, e in final_merged]

    def total_seconds(self, spans: list[tuple[str, str]]) -> int:
        merged = self.merge(spans)
        total = 0
        for start_str, end_str in merged:
            start = self._parse_instant(start_str)
            end = self._parse_instant(end_str)
            total += (end - start).total_seconds()
        return int(total)

solution = Solution()
