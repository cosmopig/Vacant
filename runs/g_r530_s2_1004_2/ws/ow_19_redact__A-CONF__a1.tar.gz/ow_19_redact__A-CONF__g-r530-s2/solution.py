import re

class Solution:
    def redact(self, text: str) -> str:
        # 1. AWS Keys: AKIA followed by 16 alphanumeric characters (e.g., AKIAIOSFODNN7EXAMPLE)
        aws_key_pattern = r'\b[A-Z0-9]{20}\b'
        
        # 2. Bearer Tokens: "Bearer " followed by a token.
        #    The example was eyJhbGciOiJIUzI1NiJ9.e30.abcdef (dot separated).
        #    "tokens that are not made of dot-separated parts" also exist.
        bearer_token_pattern = r'(?<=Bearer\s)[A-Za-z0-9._\-\/]+'
        
        # 3. Connection Strings: postgres://svc:hunter2@db.internal:5432/app
        #    The goal says mysql, mongodb, redis and amqp also appear this way.
        #    Pattern: (postgres|mysql|mongodb|redis|amqp)://[^/\s\n]+
        conn_string_pattern = r'\b(postgres|mysql|mongodb|redis|amqp)://[^\s\n]+'

        patterns = [aws_key_pattern, bearer_token_pattern, conn_string_pattern]
        
        matches = []
        for p in patterns:
            for m in re.finditer(p, text):
                matches.append(m)
        
        if not matches:
            return text

        # Sort matches by start position (ascending), then by end position (descending)
        matches.sort(key=lambda x: (x.start(), -x.end()))
        
        unique_matches = []
        for m in matches:
            is_overlapping = False
            for um in unique_matches:
                if not (m.end() <= um.start() or m.start() >= um.end()):
                    is_overlapping = True
                    break
            if not is_overlapping:
                unique_matches.append(m)
        
        # Sort again by start position descending to replace from back to front
        unique_matches.sort(key=lambda x: x.start(), reverse=True)
        
        result = text
        for m in unique_matches:
            result = result[:m.start()] + "[REDACTED]" + result[m.end():]
            
        return result

    def findings(self, text: str) -> list[str]:
        aws_key_pattern = r'\b[A-Z0-9]{20}\b'
        bearer_token_pattern = r'(?<=Bearer\s)[A-Za-z0-9._\-\/]+'
        conn_string_pattern = r'\b(postgres|mysql|mongodb|redis|amqp)://[^\s\n]+'

        patterns = [aws_key_pattern, bearer_token_pattern, conn_string_pattern]
        
        matches = []
        for p in patterns:
            for m in re.finditer(p, text):
                matches.append(m)
        
        if not matches:
            return []

        # Sort matches by start position (ascending), then by end position (descending)
        matches.sort(key=lambda x: (x.start(), -x.end()))
        
        unique_matches = []
        for m in matches:
            is_overlapping = False
            for um in unique_matches:
                if not (m.end() <= um.start() or m.start() >= um.end()):
                    is_overlapping = True
                    break
            if not is_overlapping:
                unique_matches.append(m)
        
        return [m.group() for m in unique_matches]

solution = Solution()
