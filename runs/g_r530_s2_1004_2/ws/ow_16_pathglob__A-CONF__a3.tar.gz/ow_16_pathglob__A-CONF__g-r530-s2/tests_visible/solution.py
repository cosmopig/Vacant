import re

class Solution:
    def _parse_segment(self, segment):
        if segment == "**":
            return "DOUBLE_STAR"
        
        tokens = []
        i = 0
        while i < len(segment):
            char = segment[i]
            if char == "?":
                tokens.append("?")
                i += 1
            elif char == "*":
                tokens.append("*")
                i += 1
            elif char == "[":
                j = i + 1
                if j >= len(segment): raise ValueError("Unclosed [")
                negate = False
                if segment[j] == "!":
                    negate = True
                    j += 1
                
                start = j
                while j < len(segment) and segment[j] != "]":
                    j += 1
                if j >= len(segment): raise ValueError("Unclosed [")
                
                content = segment[start:j]
                if content == "" and not negate:
                    raise ValueError("Empty class")

                chars = set()
                k = start
                while k < j:
                    if segment[k] == "-":
                        if k + 1 < j:
                            for c in range(ord(segment[k]), ord(segment[k+1]) + 1):
                                chars.add(chr(c))
                            k += 2
                        else:
                            chars.add("-")
                            k += 1
                    else:
                        chars.add(segment[k])
                        k += 1
                tokens.append(("bracket", chars, negate))
                i = j + 1
            else:
                tokens.append(char)
                i += 1
        return tokens

    def matches(self, pattern: str, path: str) -> bool:
        p_segs = pattern.split("/")
        path_segs = path.split("/")
        
        memo = {}
        def solve(p_idx, path_idx):
            state = (p_idx, path_idx)
            if state in memo: return memo[state]
            
            if p_idx == len(p_segs):
                return path_idx == len(path_segs)
            
            p_seg = p_segs[p_idx]
            if p_seg == "**":
                res = False
                for i in range(len(path_segs) - path_idx + 1):
                    if solve(p_idx + 1, path_idx + i):
                        res = True
                        break
                memo[state] = res
                return res
            else:
                if path_idx < len(path_segs):
                    tokens = self._parse_segment(p_seg)
                    def match_single_seg(t_idx, s):
                        if t_idx == len(tokens): return s == ""
                        t = tokens[t_idx]
                        if t == "?":
                            return len(s) > 0 and match_single_seg(t_idx + 1, s[1:])
                        elif t == "*":
                            for i in range(len(s) + 1):
                                if match_single_seg(t_idx + 1, s[i:]): return True
                            return False
                        elif isinstance(t, tuple) and t[0] == "bracket":
                            _, chars, negate = t
                            if len(s) > 0:
                                c = s[0]
                                is_in = c in chars
                                if (negate and not is_in) or (not negate and is_in):
                                    return match_single_seg(t_idx + 1, s[1:])
                            return False
                        else:
                            return len(s) > 0 and s[0] == t and match_single_seg(t_idx + 1, s[1:])
                    
                    if match_single_seg(0, path_segs[path_idx]):
                        res = solve(p_idx + 1, path_idx + 1)
                        memo[state] = res
                        return res
                
                memo[state] = False
                return False

        return solve(0, 0)

    def select(self, patterns: list[str], paths: list[str]) -> list[str]:
        for p in patterns:
            i = 0
            while i < len(p):
                if p[i] == "[":
                    j = i + 1
                    negate = False
                    if j < len(p) and p[j] == "!":
                        negate = True
                        j += 1
                    start = j
                    while j < len(p) and p[j] != "]":
                        j += 1
                    if j >= len(p): raise ValueError("Unclosed [")
                    content = p[start:j]
                    if content == "" and not negate:
                        raise ValueError("Empty class")
                    i = j + 1
                else:
                    i += 1

        selected_indices = set()
        for p in patterns:
            is_negated = p.startswith("!")
            actual_p = p[1:] if is_negated else p
            
            matches_this_pattern = []
            for i, path in enumerate(paths):
                if self.matches(actual_p, path):
                    matches_this_pattern.append(i)
            
            if not is_negated:
                for idx in matches_this_pattern:
                    selected_indices.add(idx)
            else:
                for idx in matches_this_pattern:
                    if idx in selected_indices:
                        selected_indices.remove(idx)
        
        return [paths[i] for i in sorted(list(selected_indices))]

