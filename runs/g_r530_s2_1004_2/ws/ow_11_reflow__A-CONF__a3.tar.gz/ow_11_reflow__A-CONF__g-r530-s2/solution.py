import re
import unicodedata

def get_char_width(char):
    return 2 if unicodedata.east_asian_width(char) in ('W', 'F') else 1

def get_display_width(text):
    return sum(get_char_width(c) for c in text)

def reflow(text: str, width: int) -> str:
    if width <= 0:
        raise ValueError("Width must be positive")

    # Identify code blocks and split the text into segments.
    segments = []
    i = 0
    while i < len(text):
        if text[i:i+3] == '```':
            j = i + 3
            while j < len(text) and text[j] != '\n':
                j += 1
            fence_line = text[i:j+1]
            # Find closing fence
            k = j + 1
            while k < len(text):
                if text[k:k+3] == '```':
                    m = k + 3
                    while m < len(text) and text[m] != '\n':
                        m += 1
                    closing_fence = text[k:m+1]
                    segments.append(('code', text[i:m+1]))
                    i = m + 1
                    break
                else:
                    k += 1
            if i >= len(text): break
            continue
        else:
            j = i
            while j < len(text) and (text[j] != '`' or not (j+2 < len(text) and text[j:j+3] == '```')):
                j += 1
            segments.append(('text', text[i:j]))
            i = j

    def is_blank(line):
        return not line.strip()

    def get_bullet_marker(line):
        stripped = line.lstrip()
        if not stripped: return None
        if stripped.startswith('- ') or stripped.startswith('* '):
            return stripped[:2]
        match = re.match(r'^\d+\.\s', stripped)
        if match:
            return match.group(0)
        return None

    final_lines = []
    for seg_type, content in segments:
        if seg_type == 'code':
            # Code blocks are emitted exactly as they were (line by line).
            # But wait, "Everything inside a fenced code block ... is emitted unchanged"
            # This means we should keep it as one single unit if possible? 
            # No, usually it's per-line. Let's stick to the original lines.
            final_lines.append(content)
        else:
            lines = content.splitlines(keepends=True)
            i = 0
            while i < len(lines):
                line = lines[i]
                if is_blank(line):
                    # Blank lines are emitted as empty lines.
                    final_lines.append("")
                    i += 1
                else:
                    marker = get_bullet_marker(line)
                    first_non_blank_idx = 0
                    while first_non_blank_idx < len(line) and line[first_non_blank_idx].isspace():
                        first_non_blank_idx += 1
                    indent = line[:first_non_blank_idx]
                    
                    if marker:
                        marker_len = len(marker)
                        continuation_indent = indent + line[first_non_blank_idx:first_non_blank_idx+marker_len]
                    else:
                        continuation_indent = indent

                    para_lines = []
                    j = i
                    while j < len(lines):
                        l_j = lines[j]
                        if is_blank(l_j): break
                        m_line = get_bullet_marker(l_j)
                        if m_line: break
                        para_lines.append(l_j[first_non_blank_idx:])
                        j += 1
                    
                    all_words = []
                    for l in para_lines:
                        # "Within a paragraph, runs of spaces and tabs separate words and are replaced by a single space."
                        # This means we should treat the content of all lines in a paragraph as one stream.
                        words = re.split(r'\s+', l.strip())
                        all_words.extend([w for w in words if w])
                    
                    current_line_content = ""
                    line_count = 0
                    for word in all_words:
                        word_width = get_display_width(word)
                        if not current_line_content:
                            current_line_content = word
                        else:
                            # Try adding a space and the word.
                            if get_display_width(current_line_content + " " + word) <= width:
                                current_line_content += " " + word
                            else:
                                # Current line is full, emit it.
                                if line_count == 0:
                                    final_lines.append(indent + current_line_content)
                                else:
                                    final_lines.append(continuation_indent + current_line_content)
                                line_count += 1
                                current_line_content = word
                    
                    if current_line_content:
                        if line_count == 0:
                            final_lines.append(indent + current_line_content)
                        else:
                            final_lines.append(continuation_indent + current_line_content)
                    
                    i = j

    result = "\n".join(final_lines)
    if text.endswith('\n') and not result.endswith('\n'):
        result += '\n'
    return result
