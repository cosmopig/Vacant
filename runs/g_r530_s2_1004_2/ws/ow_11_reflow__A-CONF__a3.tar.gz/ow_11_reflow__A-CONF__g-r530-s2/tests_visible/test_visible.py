import unittest
from solution import reflow

class TestReflow(unittest.TestCase):
    def test_basic_wrapping(self):
        text = "This is a long sentence that should be wrapped to the specified width."
        # Width 20:
        # This is a long (13) - wait, let's count manually.
        # T-h-i-s (4) _ i-s (3) _ a (2) _ l-o-n-g (5) = 14.
        # s-e-n-t-e-n-c-e (8) _ t-h-a-t (5) _ s-h-o-u-l-d (7) = 20.
        # b-e (3) _ w-r-a-p-p-e-d (8) _ t-o (3) _ t-h-e (4) = 18.
        # s-p-e-c-i-f-i-e-d (9) _ w-i-d-t-h (6) . (1) = 16.
        self.assertEqual(reflow(text, 20), "This is a long\nsentence that\nshould be\nwrapped to the\nspecified width.")

    def test_blank_lines(self):
        text = "Line 1\n\n\nLine 4"
        self.assertEqual(reflow(text, 20), "Line 1\n\n\nLine 4")

    def test_bullets(self):
        # Bullet paragraph: first line indent is "* ", continuation indent is "  ".
        # Wait, the prompt says: "Continuation lines repeat that indentation, except in a bullet paragraph, where they are indented to the first character after the marker."
        # Marker is "- ". First char after marker is at index 2.
        text = "* Item one\n* Item two\n  Continuation of item one"
        # If width is 40:
        # Line 1: "* Item one" (9)
        # Line 2: "* Item two" (9)
        # Line 3: "  Continuation of item one" (25)
        self.assertEqual(reflow(text, 40), "* Item one\n* Item two\n  Continuation of item one")

    def test_code_blocks(self):
        text = "Code block:\n```python\ndef hello():\n    print('world')\n```\nBack to text."
        expected = "Code block:\n```python\ndef hello():\n    print('world')\n```\nBack to text."
        self.assertEqual(reflow(text, 20), expected)

    def test_chinese_wrapping(self):
        # Chinese characters are wide (width 2).
        # "你好世界这是测试" -> 8 columns wide.
        # If width is 6:
        # "你好" (4) + "世" (2) = 6. Fits.
        # Next is "这" (2), total 8. Doesn't fit.
        text = "你好世界这是测试"
        self.assertEqual(reflow(text, 6), "你好世界\n这是测试")

    def test_long_word(self):
        text = "This is a very long word that exceeds the width: supercalifragilisticexpialidocious"
        # Width 10. The word should stay on its own line and overflow.
        result = reflow(text, 10)
        self.assertIn("supercalifragilisticexpialidocious", result)

    def test_negative_width(self):
        with self.assertRaises(ValueError):
            reflow("test", -1)

    def test_mixed_bullets(self):
        # "digits followed by . " is a marker.
        text = "1. First item\n2. Second item\n   Continuation of second"
        # Marker for 2. is "2. ". Length 3.
        # Indent for first line: "" (no leading spaces)
        # Continuation indent: "" + "2. " = "2. "
        # Wait, the prompt says: "indented to the first character after the marker."
        # For "1. ", that's index 3. So continuation should be indented by 3 spaces?
        # Let's re-read: "Continuation lines repeat that indentation, except in a bullet paragraph, where they are indented to the first character after the marker."
        # The indentation of the *first line* is kept for other paragraphs.
        # For bullets, continuation lines are indented to the first char after the marker.
        # If "1. First item" has no leading spaces, then the first char after "1. " is at index 3.
        # So continuation should have 3 spaces? No, it means they line up with "First".
        # Let's check: "indented to the first character after the marker."
        # If the marker is "- ", and there are no leading spaces, then the text starts at index 2.
        # So continuation lines should have 2 spaces of indentation.
        pass

if __name__ == "__main__":
    unittest.main()
