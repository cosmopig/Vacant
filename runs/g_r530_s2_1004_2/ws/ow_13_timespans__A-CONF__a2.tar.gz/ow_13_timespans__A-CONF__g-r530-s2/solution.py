from datetime import datetime, timedelta

def _parse_instant(instant: str) -> datetime:
    if len(instant) == 10 and instant[4] == '-':
        # YYYY-MM-DD
        return datetime.strptime(instant, "%Y-%m-%d")
    elif len(instant) >= 16 and instant[10] == 'T':
        # YYYY-MM-DDTHH:MM:SS
        try:
            return datetime.strptime(instant, "%Y-%m-%dT%H:%M:%S")
        except ValueError:
            raise ValueError(f"Invalid instant format: {instant}")
    else:
        raise ValueError(f"Invalid instant format: {instant}")

def _validate_span(start_str: str, end_str: str) -> tuple[datetime, datetime]:
    start = _parse_instant(start_str)
    end = _parse_instant(end_str)
    if end < start:
        raise ValueError(f"End {end_str} is before start {start_str}")
    return start, end

def merge(spans: list[tuple[str, str]]) -> list[tuple[str, str]]:
    parsed = []
    for s, e in spans:
        try:
            start, end = _validate_span(s, e)
            if start != end:
                parsed.append((start, end))
        except ValueError as ve:
            raise ve

    if not parsed:
        return []

    # Sort by start time
    parsed.sort()

    merged = []
    curr_start, curr_end = parsed[0]

    for i in range(1, len(parsed)):
        next_start, next_end = parsed[i]
        if next_start <= curr_end:
            curr_end = max(curr_end, next_end)
        else:
            merged.append((curr_start, curr_end))
            curr_start, curr_end = next_start, next_end
    
    merged.append((curr_start, curr_end))

    return [(s.strftime("%Y-%m-%dT%H:%M:%S"), e.strftime("%Y-%m-%dT%H:%M:%S")) for s, e in merged]

def subtract(spans: list[tuple[str, str]], holes: list[tuple[str, str]]) -> list[tuple[str, str]]:
    # First merge the spans to get a clean base
    merged_spans = merge(spans)
    if not merged_spans:
        return []

    # Parse holes and sort them
    parsed_holes = []
    for s, e in holes:
        try:
            start, end = _validate_span(s, e)
            if start != end:
                parsed_holes.append((start, end))
        except ValueError as ve:
            raise ve
    
    parsed_holes.sort()

    # Merge the holes to simplify subtraction
    merged_holes = []
    if parsed_holes:
        curr_h_start, curr_h_end = parsed_holes[0]
        for i in range(1, len(parsed_holes)):
            next_h_start, next_h_end = parsed_holes[i]
            if next_h_start <= curr_h_end:
                curr_h_end = max(curr_h_end, next_h_end)
            else:
                merged_holes.append((curr_h_start, curr_h_end))
                curr_h_start, curr_h_end = next_h_start, next_h_end
        merged_holes.append((curr_h_start, curr_h_end))

    # Subtract merged holes from merged spans
    result = []
    for s_start_str, s_end_str in merged_spans:
        s_start = _parse_instant(s_start_str)
        s_end = _parse_instant(s_end_str)

        current_segments = [(s_start, s_end)]
        for h_start, h_end in merged_holes:
            new_segments = []
            for seg_start, seg_end in current_segments:
                # If hole is completely before segment
                if h_end <= seg_start:
                    new_segments.append((seg_start, seg_end))
                # If hole is completely after segment
                elif h_start >= seg_end:
                    new_segments.append((seg_start, seg_end))
                else:
                    # There is some overlap
                    if h_start > seg_start:
                        new_segments.append((seg_start, h_start))
                    if h_end < seg_end:
                        new_segments.append((h_end, seg_end))
            current_segments = new_segments
        
        for res_s, res_e in current_segments:
            if res_s != res_e:
                result.append((res_s.strftime("%Y-%m-%dT%H:%M:%S"), res_e.strftime("%Y-%m-%dT%H:%M:%S")))

    # Final merge of result (though it should already be merged/sorted)
    return merge(result)

def total_seconds(spans: list[tuple[str, str]]) -> int:
    merged = merge(spans)
    total = 0
    for s_str, e_str in merged:
        s = _parse_instant(s_str)
        e = _parse_instant(e_str)
        total += (e - s).total_seconds()
    return int(total)
